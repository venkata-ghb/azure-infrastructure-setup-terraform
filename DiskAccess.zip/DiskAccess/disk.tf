resource "azurerm_disk_access" "disk" {
  location            = var.location
  name                = var.disk_name
  resource_group_name = var.resource_group_name
  tags                = merge( var.tags, { name = var.disk_name })
}