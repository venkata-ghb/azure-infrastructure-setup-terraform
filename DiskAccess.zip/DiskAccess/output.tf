output "disk_id" {
  value = azurerm_disk_access.disk.id
}
output "disk_name" {
  value = azurerm_disk_access.disk.name
}