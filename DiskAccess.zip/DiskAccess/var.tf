variable "disk_name" {
  type = string
}
variable "location" {
  type = string
}
variable "tags" {
  type = map(string)
}
variable "resource_group_name" {
  type = string
}