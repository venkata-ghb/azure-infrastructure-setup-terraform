# kdata-adb-dlt

Common K-Data Databricks Delta Live Table repository

# Common DLT library

Common DLT library is under [dlt_functions](dlt_functions) folder.

This contains common template for DLT definitions

# DLT Pipeline

DLT pipelines are under [pipelines](pipelines) folder

Each pipeline will have their own folder with own notebooks and terraform files

## Terraform

Terraform definitions can be done under `pipelines/<pipelineName>` folder

Shared files will be hosted under [terraform](terraform) folder

This includes:
* [main.tf](terraform/main.tf) - contains provider, terraform version and backend definition
* [locals.tf](terraform/locals.tf) - contains shared local variables
* [variable.tf](terraform/variable.tf) - contains shared variables

During deployment, shared files will be copied over to pipeline folder

## Using common DLT library

Common DLT library can be imported to notebook by including following lines:

```python
sys.path.append("/Workspace/KDATA-DLT/dlt_functions/dltlib")
import dlt
```

## Unit test setup / Docker compose

There's a minimal unit test setup under the [tests](tests) folder. In order to run the setup, [docker compose](https://docs.docker.com/compose/) is being used.
To run the unit test setup, execute following command in terminal:

```bash
docker compose run test
```

This will take some time during the first run, as it downloads the necessary python image, installs required dependencies (eg. java for spark), and finally
executes the unit tests. On a local machine the container should be stored locally, so subsequent runs should be considerably faster.

**Note!** Should you need to change the [unit test container config](./tests/Dockerfile) you will need to rebuild the container with following command:

```bash
docker compose build test
```

The caveat for the test setup is that it does not include the actual Databricks runtime, so it's best used for pure logic testing. For actual testing of DLT pipelines,
it's recommended to use the Databricks dev environment.



## CI / CD pipeline

Each pipeline will have their own CI / CD pipeline to avoid conflicts between deployments

Creating pipeline can be automated with [createPipeline.ps1](createPipeline.ps1) powershell script. Executing the script with `pipelines/<pipelineFolder>` as parameter will create:
* `azure-pipelines.yaml` file (pipeline definition)
* CI / CD pipeline in Azure DevOps

Example usage:

```pwsh
.\createPipeline.ps1 pipelines\hps
```

Will create `azure-pipelines.yaml` file under `pipelines/hps` folder and CI / CD pipeline `kdata-adb-dlt - hps`

# Ways of working

1. Create a feature branch for your development (Databricks integration or IDE)
2. DO NOT USE DLT repo folder in Databricks for your development. Setup Git Integration for your user and develop in your own folder
3. Once finished and tested, create a pull request
4. Assign to a reviewer
5. Once reviewed, squash & merge to master
6. This will automatically create a release pipeline run in Azure Devops
7. CHECK TERRAFORM PLAN CAREFULLY before approving to deploy changes to any enviroment so that you won't deploy or destroy anything that shouldn't
8. User approval is needed to deploy to any environment, click review and approve once terraform plan is verified

CI / CD Pipeline: https://dev.azure.com/KeskoDevOps/K-Data%20Platform/_build?definitionScope=%5CK-data%5CCommon%5CDatabricks%5CDelta%20live%20tables
