import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../pipelines/sap"))

from psql_writer_logic import resolve_lookback_days


def test_empty_target_with_lookback_falls_back_to_full_read():
    assert resolve_lookback_days(lookback_days=30, max_ldt=None) is None


def test_non_empty_target_keeps_configured_lookback():
    assert resolve_lookback_days(lookback_days=30, max_ldt="2024-06-01") == 30


def test_missing_lookback_stays_disabled():
    assert resolve_lookback_days(lookback_days=None, max_ldt=None) is None