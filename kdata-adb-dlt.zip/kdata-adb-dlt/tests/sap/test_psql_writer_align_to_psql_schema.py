import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../pipelines/sap"))

import pytest
from psql_writer_logic import align_to_psql_schema
from pyspark.sql import SparkSession
from pyspark.sql.types import DecimalType, IntegerType, StringType, StructField, StructType


@pytest.fixture(scope="session")
def spark():
    return (
        SparkSession.builder.master("local")
        .appName("test_psql_writer_align_to_psql_schema")
        .getOrCreate()
    )


def test_matching_schemas_unchanged(spark):
    schema = StructType([
        StructField("id", StringType(), True),
        StructField("val", IntegerType(), True),
    ])
    df = spark.createDataFrame([("A", 1)], schema)
    psql_df = spark.createDataFrame([("A", 1)], schema)

    result = align_to_psql_schema(df, psql_df)

    assert result.columns == ["id", "val"]
    assert result.collect() == df.collect()


def test_extra_df_column_is_dropped(spark):
    df_schema = StructType([
        StructField("id", StringType(), True),
        StructField("val", IntegerType(), True),
        StructField("extra", StringType(), True),
    ])
    psql_schema = StructType([
        StructField("id", StringType(), True),
        StructField("val", IntegerType(), True),
    ])
    df = spark.createDataFrame([("A", 1, "drop_me")], df_schema)
    psql_df = spark.createDataFrame([("A", 1)], psql_schema)

    result = align_to_psql_schema(df, psql_df)

    assert result.columns == ["id", "val"]
    assert "extra" not in result.columns


def test_missing_df_column_added_as_null(spark):
    df_schema = StructType([
        StructField("id", StringType(), True),
    ])
    psql_schema = StructType([
        StructField("id", StringType(), True),
        StructField("val", IntegerType(), True),
    ])
    df = spark.createDataFrame([("A",)], df_schema)
    psql_df = spark.createDataFrame([], psql_schema)

    result = align_to_psql_schema(df, psql_df)

    assert result.columns == ["id", "val"]
    row = result.collect()[0]
    assert row["id"] == "A"
    assert row["val"] is None


def test_missing_column_has_correct_type(spark):
    df_schema = StructType([
        StructField("id", StringType(), True),
    ])
    psql_schema = StructType([
        StructField("id", StringType(), True),
        StructField("amount", DecimalType(29, 3), True),
    ])
    df = spark.createDataFrame([("A",)], df_schema)
    psql_df = spark.createDataFrame([], psql_schema)

    result = align_to_psql_schema(df, psql_df)

    amount_type = result.schema["amount"].dataType
    assert isinstance(amount_type, DecimalType)
    assert amount_type.precision == 29
    assert amount_type.scale == 3


def test_column_order_follows_psql_schema(spark):
    df_schema = StructType([
        StructField("z", StringType(), True),
        StructField("a", StringType(), True),
        StructField("m", StringType(), True),
    ])
    psql_schema = StructType([
        StructField("a", StringType(), True),
        StructField("m", StringType(), True),
        StructField("z", StringType(), True),
    ])
    df = spark.createDataFrame([("z_val", "a_val", "m_val")], df_schema)
    psql_df = spark.createDataFrame([], psql_schema)

    result = align_to_psql_schema(df, psql_df)

    assert result.columns == ["a", "m", "z"]


def test_mix_of_missing_and_extra_columns(spark):
    df_schema = StructType([
        StructField("id", StringType(), True),
        StructField("kept", StringType(), True),
        StructField("dropped", StringType(), True),
    ])
    psql_schema = StructType([
        StructField("id", StringType(), True),
        StructField("kept", StringType(), True),
        StructField("added", IntegerType(), True),
    ])
    df = spark.createDataFrame([("A", "keep_me", "drop_me")], df_schema)
    psql_df = spark.createDataFrame([], psql_schema)

    result = align_to_psql_schema(df, psql_df)

    assert result.columns == ["id", "kept", "added"]
    row = result.collect()[0]
    assert row["id"] == "A"
    assert row["kept"] == "keep_me"
    assert row["added"] is None
    assert "dropped" not in result.columns


def test_all_columns_missing_produces_all_nulls(spark):
    df_schema = StructType([
        StructField("unrelated", StringType(), True),
    ])
    psql_schema = StructType([
        StructField("id", StringType(), True),
        StructField("val", IntegerType(), True),
    ])
    df = spark.createDataFrame([("x",)], df_schema)
    psql_df = spark.createDataFrame([], psql_schema)

    result = align_to_psql_schema(df, psql_df)

    assert result.columns == ["id", "val"]
    row = result.collect()[0]
    assert row["id"] is None
    assert row["val"] is None


def test_empty_psql_schema_produces_empty_df(spark):
    df_schema = StructType([StructField("id", StringType(), True)])
    psql_schema = StructType([])
    df = spark.createDataFrame([("A",)], df_schema)
    psql_df = spark.createDataFrame([], psql_schema)

    result = align_to_psql_schema(df, psql_df)

    assert result.columns == []


def test_mixed_case_silver_columns_are_not_nulled_by_lowercase_psql_columns(spark):
    # Regression: Postgres returns column names in lowercase (loaddatetime, silverloaddatetime),
    # but silver UC tables use mixed case (LoadDateTime, SilverLoadDateTime).
    # Before the fix, the case-sensitive Python `in` check on df.columns caused these columns
    # to be treated as missing and written as NULL to Postgres.
    from pyspark.sql.types import TimestampType
    import datetime

    ts = datetime.datetime(2026, 4, 29, 7, 19, 44)

    df_schema = StructType([
        StructField("articleid", StringType(), True),
        StructField("LoadDateTime", TimestampType(), True),
        StructField("SilverLoadDateTime", TimestampType(), True),
    ])
    psql_schema = StructType([
        StructField("articleid", StringType(), True),
        StructField("loaddatetime", TimestampType(), True),
        StructField("silverloaddatetime", TimestampType(), True),
    ])
    df = spark.createDataFrame([("art-1", ts, ts)], df_schema)
    psql_df = spark.createDataFrame([], psql_schema)

    result = align_to_psql_schema(df, psql_df)

    row = result.collect()[0]
    assert row["loaddatetime"] is not None, "LoadDateTime must not be NULL after case-insensitive alignment"
    assert row["silverloaddatetime"] is not None, "SilverLoadDateTime must not be NULL after case-insensitive alignment"
    assert row["loaddatetime"] == ts
    assert row["silverloaddatetime"] == ts
