import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../pipelines/sap"))

import pytest
from psql_writer_logic import compare_psql_keys
from pyspark.sql import SparkSession
from pyspark.sql.types import IntegerType, StringType, StructField, StructType

basicSchema = StructType([
    StructField("id", StringType(), nullable=False),
    StructField("ts", StringType(), nullable=True),
    StructField("val", IntegerType(), nullable=True),
])

MAX_LDT = "2024-06-01"


@pytest.fixture(scope="session")
def spark():
    return (
        SparkSession.builder.master("local")
        .appName("test_psql_writer_compare_psql_keys")
        .getOrCreate()
    )


def ids(result):
    return {r["id"] for r in result}


# --- No lookback ---

def test_new_row_included(spark):
    # Key does not exist in psql; timestamp older than max_ldt → caught by id_filtered_df
    psql = spark.createDataFrame([("A", "2024-01-01", 1)], basicSchema)
    src  = spark.createDataFrame([("A", "2024-01-01", 1), ("B", "2024-01-01", 2)], basicSchema)

    result = ids(compare_psql_keys(src, psql, ["id"], MAX_LDT, "ts").collect())

    assert "B" in result


def test_new_row_with_fresh_timestamp_included(spark):
    # Key does not exist in psql; timestamp newer than max_ldt → caught by time_filtered_df
    psql = spark.createDataFrame([("A", "2024-01-01", 1)], basicSchema)
    src  = spark.createDataFrame([("A", "2024-01-01", 1), ("B", "2024-07-01", 2)], basicSchema)

    result = ids(compare_psql_keys(src, psql, ["id"], MAX_LDT, "ts").collect())

    assert "B" in result


def test_updated_row_included(spark):
    # Key exists in psql but source has a newer timestamp
    psql = spark.createDataFrame([("A", "2024-01-01", 1)], basicSchema)
    src  = spark.createDataFrame([("A", "2024-03-01", 2)], basicSchema)

    result = ids(compare_psql_keys(src, psql, ["id"], MAX_LDT, "ts").collect())

    assert "A" in result


def test_unchanged_row_excluded(spark):
    # Key exists, timestamps are equal → no update
    psql = spark.createDataFrame([("A", "2024-01-01", 1)], basicSchema)
    src  = spark.createDataFrame([("A", "2024-01-01", 1)], basicSchema)

    result = compare_psql_keys(src, psql, ["id"], MAX_LDT, "ts").collect()

    assert len(result) == 0


def test_older_source_row_excluded(spark):
    # Key exists but source timestamp is older than psql → no update
    psql = spark.createDataFrame([("A", "2024-05-01", 1)], basicSchema)
    src  = spark.createDataFrame([("A", "2024-01-01", 1)], basicSchema)

    result = compare_psql_keys(src, psql, ["id"], MAX_LDT, "ts").collect()

    assert len(result) == 0


def test_row_newer_than_max_ldt_included(spark):
    # Timestamp exceeds max_ldt regardless of whether key exists in psql
    psql = spark.createDataFrame([("A", "2024-01-01", 1)], basicSchema)
    src  = spark.createDataFrame([("A", "2024-09-01", 2)], basicSchema)

    result = ids(compare_psql_keys(src, psql, ["id"], MAX_LDT, "ts").collect())

    assert "A" in result


def test_empty_source_returns_empty(spark):
    psql = spark.createDataFrame([("A", "2024-01-01", 1)], basicSchema)
    src  = spark.createDataFrame([], basicSchema)

    result = compare_psql_keys(src, psql, ["id"], MAX_LDT, "ts").collect()

    assert len(result) == 0


def test_empty_psql_returns_all_source_rows(spark):
    psql = spark.createDataFrame([], basicSchema)
    src  = spark.createDataFrame([
        ("A", "2024-07-01", 1),
        ("B", "2024-08-01", 2),
    ], basicSchema)

    result = ids(compare_psql_keys(src, psql, ["id"], MAX_LDT, "ts").collect())

    assert result == {"A", "B"}


def test_multiple_key_columns(spark):
    schema = StructType([
        StructField("id1", StringType(), nullable=False),
        StructField("id2", StringType(), nullable=False),
        StructField("ts", StringType(), nullable=True),
    ])
    psql = spark.createDataFrame([("A", "X", "2024-01-01")], schema)
    src  = spark.createDataFrame([
        ("A", "X", "2024-01-01"),  # unchanged
        ("A", "Y", "2024-07-01"),  # new key combination, fresh timestamp
    ], schema)

    result = compare_psql_keys(src, psql, ["id1", "id2"], MAX_LDT, "ts").collect()
    result_keys = {(r["id1"], r["id2"]) for r in result}

    assert ("A", "Y") in result_keys
    assert ("A", "X") not in result_keys


# --- With lookback ---

def test_lookback_new_row_with_fresh_timestamp_included(spark):
    # New key, timestamp > max_ldt → caught by time_filtered_df even with lookback
    psql = spark.createDataFrame([("A", "2024-01-01", 1)], basicSchema)
    src  = spark.createDataFrame([("A", "2024-01-01", 1), ("B", "2024-07-01", 2)], basicSchema)

    result = ids(compare_psql_keys(src, psql, ["id"], MAX_LDT, "ts", lookback_days=30).collect())

    assert "B" in result


def test_lookback_updated_row_within_window_included(spark):
    # Key exists in windowed psql_df, source timestamp is newer
    psql = spark.createDataFrame([("A", "2024-05-15", 1)], basicSchema)
    src  = spark.createDataFrame([("A", "2024-05-20", 2)], basicSchema)

    result = ids(compare_psql_keys(src, psql, ["id"], MAX_LDT, "ts", lookback_days=30).collect())

    assert "A" in result


def test_lookback_old_row_not_in_window_not_treated_as_new(spark):
    # Key exists in psql but outside the lookback window (absent from psql_df).
    # Source timestamp is also old (≤ max_ldt). Without the lookback fix this would
    # return the changed rows and be a false positive.
    psql = spark.createDataFrame([], basicSchema)  # simulates windowed read returning nothing for this key
    src  = spark.createDataFrame([("A", "2024-01-01", 1)], basicSchema)

    result = compare_psql_keys(src, psql, ["id"], MAX_LDT, "ts", lookback_days=30).collect()

    assert len(result) == 0


def test_lookback_unchanged_row_excluded(spark):
    psql = spark.createDataFrame([("A", "2024-05-01", 1)], basicSchema)
    src  = spark.createDataFrame([("A", "2024-05-01", 1)], basicSchema)

    result = compare_psql_keys(src, psql, ["id"], MAX_LDT, "ts", lookback_days=30).collect()

    assert len(result) == 0
