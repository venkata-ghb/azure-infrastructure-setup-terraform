import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../pipelines/sap"))

import pytest
from psql_writer_logic import compute_diff
from pyspark.sql import SparkSession
from pyspark.sql.types import IntegerType, StringType, StructField, StructType

basicSchema = StructType([
    StructField("id", StringType(), nullable=False),
    StructField("val", IntegerType(), nullable=True),
])


@pytest.fixture(scope="session")
def spark():
    return (
        SparkSession.builder.master("local")
        .appName("test_psql_writer_compute_diff")
        .getOrCreate()
    )


def test_new_row_is_included(spark):
    prev = spark.createDataFrame([("A", 1)], ["id", "val"])
    curr = spark.createDataFrame([("A", 1), ("B", 2)], ["id", "val"])

    result = {
        r["id"]: r["changeflag"] for r in compute_diff(curr, prev, ["id"]).collect()
    }

    assert result["B"] == "iu"


def test_updated_row_is_included(spark):
    prev = spark.createDataFrame([("A", 1)], ["id", "val"])
    curr = spark.createDataFrame([("A", 2)], ["id", "val"])

    result = {
        r["id"]: r["changeflag"] for r in compute_diff(curr, prev, ["id"]).collect()
    }

    assert result["A"] == "iu"


def test_deleted_row_is_included(spark):
    prev = spark.createDataFrame([("A", 1), ("B", 2)], ["id", "val"])
    curr = spark.createDataFrame([("A", 1)], ["id", "val"])

    result = {
        r["id"]: r["changeflag"] for r in compute_diff(curr, prev, ["id"]).collect()
    }

    assert result["B"] == "d"


def test_unchanged_row_is_excluded(spark):
    prev = spark.createDataFrame([("A", 1)], ["id", "val"])
    curr = spark.createDataFrame([("A", 1)], ["id", "val"])

    result = compute_diff(curr, prev, ["id"]).collect()

    assert len(result) == 0


def test_null_to_null_is_unchanged(spark):
    prev = spark.createDataFrame([("A", None)], basicSchema)
    curr = spark.createDataFrame([("A", None)], basicSchema)

    result = compute_diff(curr, prev, ["id"]).collect()

    assert len(result) == 0

def test_handle_multiple_id_columns(spark):
    prev = spark.createDataFrame([("A", "B", 1)], ["id", "id2", "val"])
    curr = spark.createDataFrame([("A", "C", 1)], ["id", "id2", "val"])

    result = {(r["id"], r["id2"]): r["changeflag"] for r in compute_diff(curr, prev, ["id", "id2"]).collect()}

    assert result[("A", "C")] == "iu"
    assert result[("A", "B")] == "d"


def test_timestamp_cols_are_ignored(spark):
    prev = spark.createDataFrame(
        [("A", 1, "2024-01-01", "2024-02-02", "2024-03-03", "2024-04-04")],
        [
            "id",
            "val",
            "BronzeLoadDateTime",
            "SilverLoadDateTime",
            "GoldLoadDateTime",
            "psql_load_time",
        ],
    )
    curr = spark.createDataFrame(
        [("A", 1, "2024-06-01", "2026-07-01", "2026-08-01", "2026-09-01")],
        [
            "id",
            "val",
            "BronzeLoadDateTime",
            "SilverLoadDateTime",
            "GoldLoadDateTime",
            "psql_load_time",
        ],
    )

    # Only LoadDateTime changed — should be treated as unchanged
    result = compute_diff(curr, prev, ["id"]).collect()

    assert len(result) == 0


# None test schema types
noneTestSchema = StructType(
    [
        StructField("id", StringType(), nullable=False),
        StructField("val", IntegerType(), nullable=True),
        StructField("LoadDateTime", StringType(), nullable=True),
    ]
)


def test_capture_change_from_value_to_null(spark):
    prev = spark.createDataFrame([("A", 1, "2024-01-01")], noneTestSchema)
    curr = spark.createDataFrame([("A", None, "2026-06-01")], noneTestSchema)

    result = compute_diff(curr, prev, ["id"]).collect()

    assert len(result) == 1
    assert result[0]["id"] == "A"
    assert result[0]["changeflag"] == "iu"
    assert result[0]["val"] is None


def test_capture_change_from_null_to_value(spark):
    prev = spark.createDataFrame([("A", None, "2024-01-01")], noneTestSchema)
    curr = spark.createDataFrame([("A", 1, "2026-06-01")], noneTestSchema)

    # Only LoadDateTime changed — should be treated as unchanged
    result = compute_diff(curr, prev, ["id"]).collect()

    assert len(result) == 1
    assert result[0]["id"] == "A"
    assert result[0]["changeflag"] == "iu"
    assert result[0]["val"] == 1


def test_all_cols_are_keys_or_ignored_treats_row_as_unchanged(spark):
    # When every non-key column is in IGNORED_TIMESTAMP_COLS, no update can be detected
    # and the row should be treated as unchanged.
    onlyTimestampSchema = StructType([
        StructField("id", StringType(), nullable=False),
        StructField("LoadDateTime", StringType(), nullable=True),
    ])
    prev = spark.createDataFrame([("A", "2024-01-01")], onlyTimestampSchema)
    curr = spark.createDataFrame([("A", "2026-01-01")], onlyTimestampSchema)

    result = compute_diff(curr, prev, ["id"]).collect()

    assert len(result) == 0


def test_empty_curr_returns_all_prev_as_deleted(spark):
    prev = spark.createDataFrame([("A", 1), ("B", 2)], basicSchema)
    curr = spark.createDataFrame([], basicSchema)

    result = {r["id"]: r["changeflag"] for r in compute_diff(curr, prev, ["id"]).collect()}

    assert result == {"A": "d", "B": "d"}


def test_empty_prev_returns_all_curr_as_new(spark):
    prev = spark.createDataFrame([], basicSchema)
    curr = spark.createDataFrame([("A", 1), ("B", 2)], basicSchema)

    result = {r["id"]: r["changeflag"] for r in compute_diff(curr, prev, ["id"]).collect()}

    assert result == {"A": "iu", "B": "iu"}
