import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../pipelines/sap"))

from psql_writer_logic import should_force_full_reload


# --- Config default ---

def test_missing_threshold_defaults_to_zero_never_triggers():
    write_config = {}
    threshold = write_config.get("full_reload_on_rows_lower_threshold", 0)
    assert not should_force_full_reload(psql_row_count=0, threshold=threshold)


def test_threshold_present_in_config():
    write_config = {"full_reload_on_rows_lower_threshold": 500_000}
    threshold = write_config.get("full_reload_on_rows_lower_threshold", 0)
    assert threshold == 500_000


# --- Threshold logic ---

def test_row_count_below_threshold_forces_reload():
    assert should_force_full_reload(psql_row_count=100, threshold=500_000)


def test_row_count_at_threshold_does_not_force_reload():
    assert not should_force_full_reload(psql_row_count=500_000, threshold=500_000)


def test_row_count_above_threshold_does_not_force_reload():
    assert not should_force_full_reload(psql_row_count=600_000, threshold=500_000)


def test_zero_threshold_never_forces_reload():
    # threshold=0 means the feature is disabled (default)
    assert not should_force_full_reload(psql_row_count=0, threshold=0)


def test_empty_psql_table_below_threshold_forces_reload():
    assert should_force_full_reload(psql_row_count=0, threshold=1)
