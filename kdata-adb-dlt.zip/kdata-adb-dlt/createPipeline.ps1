param(
    [string]$pipelinePath
)

$pipelineFilePath = Join-Path $pipelinePath "azure-pipelines.yaml"
$pipelineRoot = "K-data/Common/Databricks/Delta live tables"
$pipelineName = "kdata-adb-dlt - $($pipelinePath.Split("/")[-1])"
$pipelineTemplate = @"
trigger:
  branches:
    include:
      - main
  paths:
    include:
      - ${pipelinePath}/

pr:
  branches:
    include:
      - main
  paths:
    include:
      - ${pipelinePath}/

pool:
  vmImage: ubuntu-latest

stages:
  - template: ../../.azure-pipelines/templates/stages/pipeline_template.yaml
    parameters:
      pipelineName: $($pipelinePath.Split("/")[-1])
      pipelinePath: ${pipelinePath}
"@


if (! (Test-Path $pipelinePath)) {
    Write-Error "Folder $pipelinePath doesn't exist"
    exit 1
}

if (! (Test-Path $pipelineFilePath)) {
    Write-Host "Creating azure-pipelines.yaml"
    $pipelineTemplate | Out-File $pipelineFilePath -Encoding utf-8
}

az pipelines show --p "K-Data Platform" --name "${pipelineName}" -o none
if ($LASTEXITCODE -ne 0) {
    Write-Host "Creating pipeline" $pipelineName

    $id=$(az pipelines create `
        --name "${pipelineName}" `
        --branch "main" `
        --folder-path "${pipelineRoot}" `
        --organization "https://dev.azure.com/KeskoDevOps/" `
        --project "K-Data Platform" `
        --repository "kesko-dev/kdata-adb-dlt" `
        --repository-type "github" `
        --service-connection "e35d1d1c-9427-4dc9-a183-1e791d64cb72" `
        --skip-first-run true `
        --yaml-path "${pipelineFilePath}" `
        --query id -o tsv)

    $url = "https://dev.azure.com/KeskoDevOps/K-Data%20Platform/_build?definitionId=$id"
    Write-Host "URL": $url
}