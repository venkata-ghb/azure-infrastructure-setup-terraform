variable ENV {
  type        = string
  description = "Short environment"
}
