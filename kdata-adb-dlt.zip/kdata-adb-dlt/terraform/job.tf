# ==============================================================================================================================================

resource databricks_job copy_uc {
  name = "copy_to_uc_${var.ENV}"

  job_cluster {
    job_cluster_key = "copy_uc_cluster"
    new_cluster {
      num_workers    = 4
      spark_version  = "17.3.x-scala2.13"
      node_type_id   = "Standard_D4s_v5"
      spark_conf     = local.global_spark_conf
      spark_env_vars = { PYSPARK_PYTHON = "/databricks/python3/bin/python3" }
      data_security_mode = "SINGLE_USER"
    }
  }

  run_as {
    service_principal_name = local.environmental[var.ENV].app_id
  }

  task {
    task_key        = "sync_uc_tables"
    job_cluster_key = "copy_uc_cluster"

    notebook_task {
      base_parameters = {
        environment   = var.ENV
        source_schema = "dlt_pim_${var.ENV}"
        source_system = "pim"
      }

      notebook_path = "/Workspace/Repos/DLT/kdata-adb-dlt/copy_to_uc"
    }
    notification_settings {
        alert_on_last_attempt      = false
        no_alert_for_canceled_runs = false
        no_alert_for_skipped_runs  = false
    }
  }
}

 # ==============================================================================================================================================