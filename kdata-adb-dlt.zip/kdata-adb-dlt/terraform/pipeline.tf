#=====================================================================================================================
resource databricks_pipeline dlt_tps {
  name = "dlt_tps"

  cluster {
    label          = "default"
    spark_env_vars = {}
    spark_conf     = local.global_spark_conf
    autoscale {
      min_workers = 1
      max_workers = 2
      mode        = "ENHANCED"
    }
  }

  library {
    notebook {
      path = "${local.repository_prefix}/pipelines/tps/dlt_tps"
    }
  }

  catalog     = "silver_${var.ENV}"
  continuous  = false
  channel     = "PREVIEW"
  development = var.ENV != "prod" ? true : false
  photon      = false
  target      = "tps"

  configuration = {
    environment     = var.ENV
    repository_path = "/Workspace/${local.repository_prefix}/pipelines/tps"
    target_schema   = "tps"
  }
}

# ===============================================================================================================================
