resource "databricks_permissions" "copy_uc" {

  job_id = databricks_job.copy_uc.id
  # DEVOPS PLATFORM
  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_PLATFORM"
    permission_level = "CAN_MANAGE"
  }

  # SP run access
  access_control {
    service_principal_name = local.environmental[var.ENV].app_id
    permission_level       = "CAN_MANAGE_RUN"
  }

  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_FUTURICEDEV"
    permission_level = "CAN_MANAGE"
  }

  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_GTKESPRODATA"
    permission_level = "CAN_MANAGE"
  }
}
