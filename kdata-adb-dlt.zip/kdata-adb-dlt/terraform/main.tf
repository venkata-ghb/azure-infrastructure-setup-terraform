terraform {
  backend "azurerm" {
    container_name = "tf-state"
  }
  required_providers {
    databricks = {
      source  = "databricks/databricks"
      version = "=1.23.0"
    }
  }

  required_version = "0.13.2"
}

provider "databricks" {
  host = lookup({
    dev  = "https://adb-2091047593743514.14.azuredatabricks.net/"
    test = "https://adb-3612313996059694.14.azuredatabricks.net/"
    prod = "https://adb-4304259352231979.19.azuredatabricks.net/"
  }, var.ENV)
}
