locals {
  environmental = {
    dev = {
      app_id             = "ef0801e8-2e83-40fe-9867-5f6182540e1a"
      datafactory_app_id = "1e2dba53-8bef-4a9c-a046-acfd8a0cee05"
      infra_app_id       = "71d636bf-cbd4-4581-ae0c-ce8524ef8421"
    }
    test = {
      app_id             = "d9f68e1d-4ab6-4d39-8988-b95b33906f7d"
      datafactory_app_id = "420deec3-7b03-46f6-8e37-8a9f113c1ea5"
      infra_app_id       = "71d636bf-cbd4-4581-ae0c-ce8524ef8421"
    }
    prod = {
      app_id             = "91cd104b-3ec1-4527-8b0c-d78897d8e9a0"
      datafactory_app_id = "b4d1ca0b-eb36-4f36-9def-038a3afd12f0"
      infra_app_id       = "fd1c2216-86f8-45c6-aecc-30e400a61a2b"
    }
  }
  global_spark_conf = {
    "fs.azure.account.auth.type"              = "OAuth"
    "fs.azure.account.oauth.provider.type"    = "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider"
    "fs.azure.account.oauth2.client.endpoint" = "https://login.microsoftonline.com/ae6e7baa-e1bf-4ef0-92a1-4eb28ec805c0/oauth2/token"
    "fs.azure.account.oauth2.client.id"       = local.environmental[var.ENV].app_id
    "fs.azure.account.oauth2.client.secret"   = "{{secrets/platform-keyvault/kdata-${var.ENV}-adb-metastore-sp}}"
    "spark.databricks.dataLineage.enabled"    = "true"
    "spark.databricks.delta.preview.enabled"  = "true"

  }
  storage_prefix    = "abfss://dlt@kdata${var.ENV}adls.dfs.core.windows.net"
  repository_prefix = "/Repos/DLT/kdata-adb-dlt"
  workspace_prefix  = "/KDATA-DLT"
  default_node      = "Standard_D4s_v5"
}
