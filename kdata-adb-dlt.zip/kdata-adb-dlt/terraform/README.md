# Terraform

Terraform is used to manage DLT pipelines and related resources (jobs, permissions etc.)

# Backend

State file is stored in `Azure Storage Account`

| env  | account name        | container | state key                 |
| ---- | ------------------- | --------- | ------------------------- |
| dev  | kdatadevtestinfrasa | tf-state  | DEV/dlt/dlt.dev.tfstate   |
| test | kdatadevtestinfrasa | tf-state  | TEST/dlt/dlt.test.tfstate |
| prod | kdataprodinfrasa    | tf-state  | dlt/dlt.prod.tfstate      |

# Host Agent

Terraform is being run with K-Data Infra Agent

| env  | agent name                     | vm name                     |
| ---- | ------------------------------ | --------------------------- |
| dev  | KDATA DevTest Infra Agent Pool | kdata-devtest-tfinfra-agent |
| test | KDATA DevTest Infra Agent Pool | kdata-devtest-tfinfra-agent |
| prod | KDATA Prod Infra Agent Pool    | kdata-prod-tfinfra-agent    |

# Running locally

To locally run terraform first ensure that you have

* network access to above backend
* relevant access to above backend with `Role based access policy` role

## Initialize terraform

### Manually

```bash
terraform init -backend-config="resource_group_name=<resource_group_name>" -backend-config="storage_account_name=<storage_name>" -backend-config="container_name=tf-state" -backend-config="key=<key>" -backend-config="subscription_id=<subscription_id>"
```

Make sure to also include `ENV` variable when running terraform commands either with `environment variable` or `tfvars` file

### Via powershell script

```pwsh
.\terraformInit.ps1 <env>
```

This will initialize terraform with correct backend and also create `vars.auto.tfvars` file with correct `ENV` variable value

# Resource naming convention

Follow these naming conventions when naming resources:

https://confluence.kesko.fi/display/KDAT/Terraform+Naming+Conventions

# CI / CD

Azure DevOps pipeline:

https://dev.azure.com/KeskoDevOps/K-Data%20Platform/_build?definitionId=1298

## Flow

1. Once changes have been merged to `main` branch the pipeline will trigger
2. Terraform plan is ran to inform changes to be applied
3. Approval is required before deployment
4. Pipeline refreshes (pulls) changes for repository
5. Terraform apply is ran to apply infra changes
6. Repeat for each environment (dev, test, prod)