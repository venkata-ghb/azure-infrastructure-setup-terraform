param(
  [Parameter(Mandatory=$true)][string][ValidateSet("dev", "test", "prod")]$env
)

switch($env) {
  "prod" {
    $resourceGroup = "K-DATA_PROD_WE_Terraform_RG"
    $storage = "kdataprodinfrasa"
    $subscription = "02147589-2a7d-4483-b5da-af70a38cea3f"
    $key = "dlt/dlt.${env}.tfstate"
    Break
  }
  default {
    $resourceGroup = "K-DATA_TEST_WE_Terraform_RG"
    $storage = "kdatadevtestinfrasa"
    $subscription = "f11ae7de-3b87-49e7-8a17-55041f3739c4"
    $key = "$($env.ToUpper())/dlt/dlt.${env}.tfstate"
  }
}

$container = "tf-state"
$vars = 'ENV = "' + $env + '"'

Remove-Item ./.terraform -Recurse -Force
$vars | Out-File ./vars.auto.tfvars
terraform init -backend-config="resource_group_name=$resourceGroup" -backend-config="storage_account_name=$storage" -backend-config="container_name=$container" -backend-config="key=$key" -backend-config="subscription_id=$subscription"
