
import dlt
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, expr, current_timestamp
import json
class dltlib:

    # Assign the existing pyspark session as a global variable in order
    # order to use it within the library functions.
    global spark
    spark = SparkSession.builder.master("local[1]").getOrCreate()

    # NOTE this library cannot be installed on DB cluster with init
    # scripts, because init scripts are executed before spark is
    # launched on the DB cluster.


    def ingest_raw_data(table, inputPath, process_cols = None, **sparkOptions):
        @dlt.table(
            name=f"bronze_{table}",
            comment="This table was created with Autoloader.",
            table_properties={"quality": "bronze", "delta.enableChangeDataFeed": "True"},
        )
        def load_dynamic_table_bronze():
            # Autoloader can infer schema for file types such as parquet, json and csv.
            df = (
                spark.readStream.format("cloudFiles")
                .options(**sparkOptions["sparkOptions"])
                .load(inputPath)
            )
            # If function call includes calculated columns, they are included into returned data frame here
            #
            if process_cols:
                for column_name, column_statement in process_cols.items():
                    df = df.withColumn(column_name, column_statement)


            df = df.withColumn("BronzeLoadDateTime", current_timestamp())

            return df


    def check_if_table_exists(table="kesko_sandbox.bronze_kunta"):
        try:
            spark.sql(f"select * from {table}")
            return True
        except:
            return False

    def create_cdc_table(schema, table, temporary=True):

        table_exists = dltlib.check_if_table_exists(f"{schema}.bronze_{table}")
        # Returning the dataframe fails on the initial run of the pipeline
        if table_exists:

            @dlt.table(name=f"cdc_{table}", temporary=temporary)
            def cdc_table():

                # Referencing the LIVE table does not return the change
                # data feed from the underlying table.
                cdc_df = (
                    spark.readStream.format("delta")
                    .option("readChangeFeed", "true")
                    .table(f"{schema}.bronze_{table}")
                )
                return cdc_df

        else:
            # Skip creating the cdc table, because the bronze table does not exist yet.
            # The bronze table will exist in the local Hive metastore on the next run
            # of this pipeline.
            pass


    def generate_expectations(
        keys=["id"],
        allowed_values={}
    ):

        # Check if primary key of the table is null
        primary_keys_not_null = {f"{key}_is_not_null": f"{key} is not null" for key in keys}

        # Check that the target column contains allowed values
        # The allowed values must be presented as a comma separated list inside parenthesis
        final_values = {
            # name of the expectation
            f"{column}_allowed_values":

            # Generate the expectation SQL snippet
            # The list of values is wrapped in single quotes.
            # The xxxxx string replacement is needed because backslashes are not allowed in f-strings.
            f"{column} in ('{'xxxxx,xxxxx'.join(list(values))}\')".replace('xxxxx', "\'")

            # Apply the string formatting for every column
            for column, values in allowed_values.items()
            if len(values)
        }

        expectations = {**primary_keys_not_null, **final_values}

        # TODO: handle integers in allowed_values

        print(json.dumps(expectations, ensure_ascii=False))
        return json.dumps(expectations, ensure_ascii=False)


    def create_silver_temp_table(
        source_table,
        target_table,
        column_mapping,
        expectations,
        use_cdc = True,
        source_system = "source_system N/A",
        bronze_load_timestamp_column_name="BronzeLoadDateTime",
        filter_column="BronzeLoadDateTime",
        apply_filter=False,
        lookback_days=None,
        live_table=True,
    ):

        @dlt.table(
            name=f"temp_{target_table}",
            comment="Temporary table for renaming columns before SCD is implemented.",
            temporary=True,
            table_properties={"quality": "temp"},
        )
        @dlt.expect_all_or_drop(json.loads(expectations))
        def load_dynamic_table_silver():

            # Generate a select expression for renaming columns
            selExpr = [
                f"{value} as {key}"
                for key, value in column_mapping.items()
            ]

            # Add a load datetime to allow identifying rows processed
            # by a single instance of the pipeline.
            load_dttm = [
                "current_timestamp() as SilverLoadDateTime",
                f"{bronze_load_timestamp_column_name} as BronzeLoadDateTime"
            ]

            # Add an identifier for the source system.
            # This is intended to be used mainly in the gold layer
            # where multiple different source systems can be combined in
            # a single table.
            source = [f"'{source_system}' as SrcID"]

            if use_cdc:
                table_prefix = "cdc"
                # DLT uses three columns with fixed names on the chage data feed.
                # They are needed for applying the SCD on the silver layer.
                cdc_column_list = [
                    f"_change_type as _change_type",
                    f"_commit_version as _commit_version",
                    f"_commit_timestamp as _commit_timestamp",
                ]
                # Append the metadata columns to a dynamic list of columns
                selExpr = selExpr + cdc_column_list + load_dttm + source
            else:
                table_prefix = "bronze"
                selExpr = selExpr + load_dttm + source

            table = f"LIVE.{table_prefix}_{source_table}" if live_table else source_table
            
            # Check for mismatch of parameters
            if apply_filter and lookback_days is None:
                raise ValueError("lookback_days must be provided when apply_filter=True")
            elif not apply_filter and lookback_days is not None:
                raise ValueError("apply_filter must be True when lookback_days is provided")
            
            # This is the default behavior that has been always used, if no lookback days are defined, or apply_filter is set to false, then the whole table is read without filtering
            df = (
                spark.readStream.format("delta")
                .option("ignoreChanges", "true")
                .table(table)
            )
            
            # This is used when apply_filter is passed as true and lookback_days is passed
            # The filter is applied on the filter_column (default=BronzeLoadDateTime)
            if apply_filter:
                df = df.filter(
                    col(filter_column)
                    >= expr(f"current_timestamp() - INTERVAL {lookback_days} DAYS")
                )

            return df.selectExpr(selExpr)


    def check_row_count(source_table, target_table, keys, column_mapping):

        key_mapping_dictionary = {key: column_mapping[key] for key in keys}
        primary_keys_not_null = {
            f"tgt_{key}_is_not_null": f"tgt_{key} is not null" for key in key_mapping_dictionary.keys()
        }

        @dlt.table(
            name=f"row_count_{target_table}",
            comment="Temporary table for row count validation.",
            temporary=True,
            table_properties={"quality": "temp"},
        )
        @dlt.expect_all_or_drop(primary_keys_not_null)
        def create_row_count_table():

            # Generate a select expression for the key columns
            # When the join expression is defined as a string, both dataframes must contain
            # the join columns with same names. Thus we duplicate the original key columns on
            # both dataframes.
            srcSelExpr = [f"{value} as {key}, {value} as src_{key}" for key, value in key_mapping_dictionary.items()]
            tgtSelExpr = [f"{key}, {key} as tgt_{key}" for key in key_mapping_dictionary.keys()]

            # Generate a join expression for row count validation
            # https://spark.apache.org/docs/3.1.2/api/python/reference/api/pyspark.sql.DataFrame.join.html
            joinExpr = [ f"{key}" for key in key_mapping_dictionary.keys() ]

            srcDF = spark.sql(f"""
                select {','.join(srcSelExpr)}
                from LIVE.{source_table}
            """)

            tgtDF = spark.sql(f"""
                select {','.join(tgtSelExpr)}
                from LIVE.{target_table}
            """)

            df = srcDF.join(tgtDF, on=joinExpr, how="left")
            return df

    def generate_duplicate_values(source_table, keys, column_mapping):

        key_mapping_dictionary = {key: column_mapping[key] for key in keys}
        selExpr = [f"{key}" for key in key_mapping_dictionary.keys()]
        selExpr.extend(list(['count(*) as num_entries']))

        @dlt.table(
            name=f"generated_duplicates_{source_table}",
            comment="Temporary table for unique key value validation.",
            temporary=True,
            table_properties={"quality": "temp"},
        )
        def create_duplicate_key_table():

            duplicateDF = spark.sql(f"""
                select {','.join(selExpr)}
                from LIVE.{source_table}
                group by all
                union all
                select {','.join(selExpr)}
                from LIVE.{source_table}
                group by all
            """)

            return duplicateDF

    def check_duplicate_values(source_table, keys, column_mapping):

        key_mapping_dictionary = {key: column_mapping[key] for key in keys}
        selExpr = [f"{key}" for key in key_mapping_dictionary.keys()]
        selExpr.extend(list(['count(*) as num_entries']))

        @dlt.table(
            name=f"unique_keys_{source_table}",
            comment="Temporary table for unique key value validation.",
            temporary=True,
            table_properties={"quality": "temp"},
        )
        @dlt.expect_all({"primary_key_is_unique": "num_entries = 1"})
        def create_duplicate_key_table():

            duplicateDF = spark.sql(f"""
                select {','.join(selExpr)}
                from LIVE.{source_table}
                group by all
            """)

            return duplicateDF

    def create_silver_table_scd1(source_system, target_table, keys, sequence_by="_commit_version"):
        dlt.create_streaming_table(f"silver_{source_system}_{target_table}")
        dlt.apply_changes(
            target=f"silver_{source_system}_{target_table}",
            source=f"temp_{target_table}",
            keys=keys,
            sequence_by=col(sequence_by),
            apply_as_deletes=expr("_change_type = 'DELETE'"),
            apply_as_truncates=expr("_change_type = 'TRUNCATE'"),
            except_column_list=["_change_type", "_commit_version", "_commit_timestamp"],
            stored_as_scd_type=1,
        )


    def create_silver_table(source_system, target_table, keys, sequence_by="BronzeLoadDateTime"):
        dlt.create_streaming_table(f"silver_{source_system}_{target_table}")
        dlt.apply_changes(
            target=f"silver_{source_system}_{target_table}",
            source=f"temp_{target_table}",
            keys=keys,
            sequence_by=col(sequence_by),
            stored_as_scd_type=1,
        )

