from setuptools import setup, find_packages

#Package metadata
name = "dltlib"
version = "0.1.7"
description = "Common functions used in DLT pipelines"

dependencies = []

setup(
    name=name,
    version=version,
    description=description,
    packages=find_packages(),
    install_requires=dependencies
)