# Databricks notebook source
# MAGIC %pip install azure-servicebus

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Imports

# COMMAND ----------

dbutils.widgets.text("env", "dev")
dbutils.widgets.text("force_run", "false") # Set manually to "true" as job parameter to force a run regardless if queue is empty or not. Default is "false"

# COMMAND ----------

import json
from azure.servicebus import ServiceBusClient
from pyspark.sql.functions import current_timestamp, lit, col
from pyspark import SparkConf, SparkContext
sc = SparkContext.getOrCreate(SparkConf().setMaster("local[*]"))
from delta.tables import DeltaTable
import version
from logger import get_logger

log = get_logger("read_pim_queue")

log.info("read_pim_queue | build: %s | sha: %s", version.BUILD_NUMBER, version.GIT_SHA)

force_run = dbutils.widgets.get("force_run").lower() == "true" # is True if == "true", else False
env = dbutils.widgets.get("env")

# Directory where bookkeeping of read messages is stored
events_directory = f"abfss://dlt@kdata{env}adls.dfs.core.windows.net/pim/events"
#Connection details to Service bus
connection_string = dbutils.secrets.get(scope='kv-kd-shared', key='pxm-kdata-sb-connectionstring')
queue_name = 'pxm-kdata-data-sbus-out-queue'


# COMMAND ----------

# Programmatically create directories if they don't exist
dbutils.fs.mkdirs(f"abfss://dlt@kdata{env}adls.dfs.core.windows.net/pim/events")
dbutils.fs.mkdirs(f"abfss://dlt@kdata{env}adls.dfs.core.windows.net/pim/backup")
dbutils.fs.mkdirs(f"abfss://dlt@kdata{env}adls.dfs.core.windows.net/pim/source")

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Reading and processing events

# COMMAND ----------

received_message_array = []

# Open connection to service bus and read all messages (urls) from queue and append to list received_message_array.
# Keep connection open for duration of max_wait_time seconds
log.info("Start queue read")
with ServiceBusClient.from_connection_string(connection_string) as client:
  with client.get_queue_receiver(queue_name, max_wait_time=30) as receiver:
    for message in receiver:
        received_message_array.append(message)
        # Mark messages as read to prevent them from going to dead-letter queue
        receiver.complete_message(message)
log.info("Message array length: %s", len(received_message_array))

# COMMAND ----------

# Query delta table in events directory to get a list of urls that have not yet been processed due to failures.
# Scanned here to see if the run needs to happen or not
log.info("Get previously failed messages with status != success from events/")
if DeltaTable.isDeltaTable(spark, events_directory):
  failed_urls_df = spark.read.format("delta").load(events_directory).filter(col("status") != "success")
  failed_urls = [row[0] for row in failed_urls_df.collect()]
else:
  failed_urls = []

# COMMAND ----------

# Process all received messages into a pyspark dataframe and store them to events directory
# New events are stored with status "unknown" which will only switch to "success" after all messages (urls) are processed. This will ensure that we don't lose data even if pipeline would fail unexpectedly.

# Convert received message URLs into a list of Row objects (dicts)
# Message url is a semantic meaning for file path in blob storage from queue
if len(received_message_array) > 0:
  log.info("Processing received messages if messages received")
  new_events = True
  row_list = [{"url": str(url)} for url in received_message_array]
  col_list = ["url"]
  # Create a DataFrame from the list of Row objects
  url_df = spark.createDataFrame(data=row_list, schema = col_list)
  url_df = (url_df.withColumn("read_timestamp", current_timestamp())
                  .withColumn("status", lit("unknown"))
          )

  (url_df.write
         .format("delta")
         .mode("append")
         .option("mergeSchema", "true")
         .mode("append")
         .save(events_directory)
  )
else:
  log.warning("No new messages received - process skipped")
  new_events = False

# COMMAND ----------


#If failed urls from previous run, combine lists and start processing with the oldest ones
url_list = []
if len(failed_urls) > 0 :
  log.info("Processing %s failed messages from previous run", len(failed_urls))
  url_list = failed_urls + received_message_array
else:
  log.info("No failed messages to process")
  url_list = received_message_array

log.info("Total urls to process: %s", len(url_list))

# COMMAND ----------
has_pending_input = len(url_list) > 0
continue_pipeline = has_pending_input or force_run
dbutils.jobs.taskValues.set("has_pending_input", has_pending_input)
dbutils.jobs.taskValues.set("continue_pipeline", continue_pipeline)

log.info("Set task value continue_pipeline to %s. Pending input in queue: %s. Force run: %s", continue_pipeline, has_pending_input, force_run)
