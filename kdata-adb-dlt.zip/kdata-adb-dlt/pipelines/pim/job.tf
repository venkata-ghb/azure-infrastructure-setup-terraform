# ==============================================================================================================================================

resource databricks_job dlt_pim_job {
  name = "dlt_pim_${var.ENV}"

  job_cluster {
    job_cluster_key = "pim-cluster"
    new_cluster {
      autoscale {
        min_workers = 2
        max_workers = 10
      }

      spark_version  = "17.3.x-scala2.13"
      node_type_id   = lookup({
        dev  = "Standard_D8ds_v5"
        test = "Standard_D8ds_v5"
        prod = "Standard_D8ds_v5"
      }, var.ENV)
      spark_conf     = local.global_spark_conf
      spark_env_vars = { PYSPARK_PYTHON = "/databricks/python3/bin/python3" }
      data_security_mode = "SINGLE_USER"
    }
  }
  schedule {
    quartz_cron_expression = lookup({
        dev  = "0 0 12 1 * ?"
        test = "0 0 * * * ?"
        prod = "0 0/30 * * * ?"
      }, var.ENV)
    timezone_id = "Europe/Helsinki"
    pause_status = lookup({
        dev  = "PAUSED"
        test = "UNPAUSED"
        prod = "UNPAUSED"
      }, var.ENV)
  }
  run_as {
    service_principal_name = local.environmental[var.ENV].app_id
  }
  timeout_seconds = 3600

  parameter {
    name    = "force_run"
    default = "false"
  }

  # Writer warmup task

  task {
    task_key        = "warmup_cluster"
    job_cluster_key = "pim-cluster"

    notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/sap/warmup_cluster"
    }
  }

  # Queue read & data processing tasks

  task {
    task_key        = "read_pim_queue"
    job_cluster_key = "pim-cluster"


     notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/pim/read_pim_queue"
      base_parameters = {
        env             = var.ENV
        table_config_path   = "/Workspace${local.workspace_prefix}/pipelines/pim"
        catalog_header  = "silver"
        uc_schema       = "pim"
        schema_prefix   = "pim"
        force_run       = "{{job.parameters.force_run}}"
      }
    }
  }

  task {
    task_key = "check_if_continue_pipeline"
    description = "Check if there is data in queue or if force_run=True"

    condition_task {
      left      = "{{tasks.read_pim_queue.values.continue_pipeline}}"
      op        = "EQUAL_TO"
      right     = "true"
    }

    depends_on {
      task_key = "read_pim_queue"
    }
  }

  task {
    task_key = "process_pim_raw_data"
    job_cluster_key = "pim-cluster"

    depends_on {
      task_key  = "check_if_continue_pipeline"
      outcome   = "true"
    }

    notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/pim/process_pim_raw_data"
      base_parameters = {
        env             = var.ENV
        table_config_path   = "/Workspace${local.workspace_prefix}/pipelines/pim"
        catalog_header  = "silver"
        uc_schema       = "pim"
        schema_prefix   = "pim"
        force_run       = "{{job.parameters.force_run}}"
      }
    }
  }

  task {
    task_key = databricks_pipeline.dlt_pim.name

    depends_on {
      task_key = "process_pim_raw_data"
    }

    pipeline_task {
      pipeline_id = databricks_pipeline.dlt_pim.id
    }
  }

  # Kesprodata tasks

  task {
    task_key        = "write_kesprodata_pim_tables"
    job_cluster_key = "pim-cluster"

    depends_on {
      task_key = databricks_pipeline.dlt_pim.name
    }

     notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/sap/psql_writer"
      base_parameters = {
        env            = var.ENV
        pipeline_path  = "/Workspace${local.workspace_prefix}/pipelines/pim"
        max_workers    = 3
        writer_config  = "kesprodata_pim_silver"
        target_database = "kesprodata"
      }
    }
  }

  # Search service bus tasks

  task {
    task_key        = "write_kespro_search_fast_data_servicebus"
    job_cluster_key = "pim-cluster"

    depends_on {
      task_key = "write_kesprodata_pim_tables"
    }

    notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/sap/search_service_bus"
      base_parameters = {
        env            = var.ENV
        pipeline_path  = "/Workspace${local.workspace_prefix}/pipelines/pim"
        max_workers    = 5
        writer_config  = "search_servicebus"
      }
    }
  }

}


# ==============================================================================================================================================


resource databricks_job backfill_pim_events {
  name = "backfill_pim_${var.ENV}"

  job_cluster {
    job_cluster_key = "pim-cluster"
    new_cluster {
      num_workers    = 4
      spark_version  = "17.3.x-scala2.13"
      node_type_id   = "Standard_D8ds_v5"
      spark_conf     = local.global_spark_conf
      spark_env_vars = { PYSPARK_PYTHON = "/databricks/python3/bin/python3" }
      data_security_mode = "SINGLE_USER"
    }
  }

  task {
    task_key        = "backfill_pim"
    job_cluster_key = "pim-cluster"


     notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/pim/backfill_pim_events"
      base_parameters = {
        environment         = var.ENV
        table_config_path   = "/Workspace${local.workspace_prefix}/pipelines/pim"
        selected_tables = "all_tables"
      }
    }
  }

}

# ==============================================================================================================================================

resource databricks_job drop_from_uc {
  name = "drop_from_uc_${var.ENV}"

  job_cluster {
    job_cluster_key = "drop_from_uc_cluster"
    new_cluster {
      num_workers    = 4
      spark_version  = "17.3.x-scala2.13"
      node_type_id   = "Standard_D4s_v5"
      spark_conf     = local.global_spark_conf
      spark_env_vars = { PYSPARK_PYTHON = "/databricks/python3/bin/python3" }
      data_security_mode = "SINGLE_USER"
    }
  }

  run_as {
    service_principal_name = local.environmental[var.ENV].app_id
  }

  task {
    task_key        = "drop_uc_tables"
    job_cluster_key = "drop_from_uc_cluster"

    notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/pim/drop_uc_tables"
    }
  }
}


# ==============================================================================================================================================


resource databricks_job create_ignore_columns_config {
  name = "create_ignore_columns_config_${var.ENV}"

  job_cluster {
    job_cluster_key = "ignore_columns_config_cluster"
    new_cluster {
      num_workers    = 4
      spark_version  = "17.3.x-scala2.13"
      node_type_id   = "Standard_D4s_v5"
      spark_conf     = local.global_spark_conf
      spark_env_vars = { PYSPARK_PYTHON = "/databricks/python3/bin/python3" }
      data_security_mode = "SINGLE_USER"
    }
  }

  task {
    task_key        = "ignore_columns_config"
    job_cluster_key = "ignore_columns_config_cluster"

  notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/pim/ignore_columns_config"
      base_parameters = {
        env            = var.ENV
        pipeline_path  = "/Workspace${local.workspace_prefix}/pipelines/pim"
        max_workers    = 3
        writer_config  = "kesprodata_pim_silver"
      }
    }

  }
}

 # ==============================================================================================================================================

resource databricks_job reload_pim {
  name = "reload_pim_schema_${var.ENV}"

  job_cluster {
    job_cluster_key = "reload_pim_schema_cluster"
    new_cluster {
      autoscale {
        min_workers = 2
        max_workers = 8
      }
      spark_version  = "17.3.x-scala2.13"
      node_type_id   = "Standard_D4s_v5"
      spark_conf     = local.global_spark_conf
      spark_env_vars = { PYSPARK_PYTHON = "/databricks/python3/bin/python3" }
      data_security_mode = "SINGLE_USER"
    }
  }

  run_as {
    service_principal_name = local.environmental[var.ENV].app_id
  }

  parameter {
    name = "tables"
    default = "None"
  }

  task {
    task_key        = "drop_uc_tables"
    job_cluster_key = "reload_pim_schema_cluster"

    notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/pim/drop_uc_tables"
      base_parameters = {
        environment   = var.ENV
        schema_name   = "pim"
        area          = "silver"
      }
    }
  }

  task {
    task_key        = "backfill_selected_tables"
    job_cluster_key = "reload_pim_schema_cluster"

    depends_on {
      task_key = "drop_uc_tables"
    }

    notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/pim/backfill_pim_events"
      base_parameters = {
        environment   = var.ENV
        delete_existing = true
        table_config_path = "/Workspace${local.workspace_prefix}/pipelines/pim"
      }
    }
  }

  task {
    task_key = databricks_pipeline.dlt_pim.name

    depends_on {
      task_key = "backfill_selected_tables"
    }

    pipeline_task {
      pipeline_id = databricks_pipeline.dlt_pim.id
      full_refresh = true
    }
  }

  task {
    task_key        = "resync_uc"
    job_cluster_key = "reload_pim_schema_cluster"

    depends_on {
      task_key = databricks_pipeline.dlt_pim.name
    }

    notebook_task {
      notebook_path = "/Repos/DLT/kdata-adb-dlt/copy_to_uc"
      base_parameters = {
        environment   = var.ENV
        source_schema = var.ENV == "prod" ? "dlt_pim_${var.ENV}" : "dlt_pim"
        source_system = "pim"
    }
 }
}
}