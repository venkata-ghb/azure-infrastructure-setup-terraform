resource "databricks_permissions" "job-dlt_pim" {

  job_id = databricks_job.dlt_pim_job.id
  # DEVOPS PLATFORM
  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_PLATFORM"
    permission_level = "CAN_MANAGE"
  }

  # SP run access
  access_control {
    service_principal_name = local.environmental[var.ENV].app_id
    permission_level       = "CAN_MANAGE_RUN"
  }

  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_FUTURICEDEV"
    permission_level = "CAN_MANAGE"
  }
  
  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_GTKESPRODATA"
    permission_level = "CAN_MANAGE"
  }
}

resource "databricks_permissions" "job-backfill_pim" {

  job_id = databricks_job.backfill_pim_events.id
  # DEVOPS PLATFORM
  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_PLATFORM"
    permission_level = "CAN_MANAGE"
  }

  # SP run access
  access_control {
    service_principal_name = local.environmental[var.ENV].app_id
    permission_level       = "CAN_MANAGE_RUN"
  }

  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_FUTURICEDEV"
    permission_level = "CAN_MANAGE"
  }

  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_GTKESPRODATA"
    permission_level = "CAN_MANAGE"
  }
}

resource "databricks_permissions" "job-create_ignore_columns_config" {

  job_id = databricks_job.create_ignore_columns_config.id
  # DEVOPS PLATFORM
  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_PLATFORM"
    permission_level = "CAN_MANAGE"
  }

  # SP run access
  access_control {
    service_principal_name = local.environmental[var.ENV].app_id
    permission_level       = "CAN_MANAGE_RUN"
  }

  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_FUTURICEDEV"
    permission_level = "CAN_MANAGE"
  }

  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_GTKESPRODATA"
    permission_level = "CAN_MANAGE"
  }
}

resource "databricks_permissions" "job-drop_from_uc" {

  job_id = databricks_job.drop_from_uc.id
  # DEVOPS PLATFORM
  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_PLATFORM"
    permission_level = "CAN_MANAGE"
  }

  # SP run access
  access_control {
    service_principal_name = local.environmental[var.ENV].app_id
    permission_level       = "CAN_MANAGE_RUN"
  }

  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_FUTURICEDEV"
    permission_level = "CAN_MANAGE"
  }

  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_GTKESPRODATA"
    permission_level = "CAN_MANAGE"
  }
}

resource "databricks_permissions" "job-reload_pim" {

  job_id = databricks_job.reload_pim.id
  # DEVOPS PLATFORM
  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_PLATFORM"
    permission_level = "CAN_MANAGE"
  }

  # SP run access
  access_control {
    service_principal_name = local.environmental[var.ENV].app_id
    permission_level       = "CAN_MANAGE_RUN"
  }

  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_FUTURICEDEV"
    permission_level = "CAN_MANAGE"
  }

  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_GTKESPRODATA"
    permission_level = "CAN_MANAGE"
  }
}