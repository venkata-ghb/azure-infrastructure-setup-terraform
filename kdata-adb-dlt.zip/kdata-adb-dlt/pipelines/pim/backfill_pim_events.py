# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC ## Imports

# COMMAND ----------

dbutils.widgets.text("table_config_path", "/Workspace/Repos/ext.firstname.lastname@kesko.fi/kdata-adb-dlt/pipelines/pim")
dbutils.widgets.text("environment", "dev")
dbutils.widgets.text("tables", "all_tables")
dbutils.widgets.text("delete_existing", "False")

# COMMAND ----------

import json
from pyspark.sql.functions import *
from pyspark.sql.types import *
from delta.tables import DeltaTable
from pyspark.sql.utils import AnalysisException
from delta import *
import concurrent.futures
import os, sys
import re
import importlib
from functools import reduce
import pyspark
from logger import get_logger

log = get_logger("backfill_pim_events")

env = dbutils.widgets.get("environment")
w_dir = dbutils.widgets.get("table_config_path")
table_config_path = f"{w_dir}/tables.json"

# Add configuration path to python path
config_path = f"{w_dir}/parsing_configs"
sys.path.append(config_path)

# Selecting tables to be reloaded.
# Options:
# all_tables : reload all tables in pim schema
# comma-separated string of tables : reload each table separated by a comma
# pim_lang_references : reload all tables in order to extract all possible lang references, but only write lang_references
selected_tables = dbutils.widgets.get("tables")
plr=False
if selected_tables != 'all_tables':
  selected_tables = selected_tables.split(",")
if selected_tables[0] == "pim_lang_references":
  plr = True
  selected_tables = 'all_tables'
delete_existing = dbutils.widgets.get("delete_existing")
events_directory = f"abfss://dlt@kdata{env}adls.dfs.core.windows.net/pim/events"
backfill_directory = f"abfss://dlt@kdata{env}adls.dfs.core.windows.net/pim/backup"

#Table configuration to get table mapping between bronze and silver layers (also opflag parsing)
with open(file=table_config_path, mode="r") as file:
  table_config = json.load(file)

# COMMAND ----------

# Programmatically create directories if they don't exist
dbutils.fs.mkdirs(f"abfss://dlt@kdata{env}adls.dfs.core.windows.net/pim/events")
# to be deleted after backup is in use in production
dbutils.fs.mkdirs(f"abfss://dlt@kdata{env}adls.dfs.core.windows.net/pim/backfill")
dbutils.fs.mkdirs(f"abfss://dlt@kdata{env}adls.dfs.core.windows.net/pim/backup")
dbutils.fs.mkdirs(f"abfss://dlt@kdata{env}adls.dfs.core.windows.net/pim/source")

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # Backup reload

# COMMAND ----------

##### Use this for Backup reload

bdf = (spark.read
           .format("json")
           .load(f"{backfill_directory}")
           .select("articles", "partitioning_timestamp")
           )

sorted_df = bdf.sort(["articles.articleid", "articles.basicData.lastModified", "partitioning_timestamp"], ascending=[True, False, False])
sorted_df = sorted_df.withColumn("sortid", col("articles.articleid"))
# Drop duplicates from the dataframe, keeping the first (latest) occurrence by descending sorting
bdf = sorted_df.dropDuplicates(["sortid"]).drop("sortid", "partitioning_timestamp").dropDuplicates()
df = bdf
# Get a list of high level elements to prevent parsing errors
cols = [col.lower() for col in df.select("articles.*").columns]

# COMMAND ----------

df = df.repartition(72)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Utils

# COMMAND ----------

def get_opflag(incoming_df, table_name):

  """
  Purpose of the get opflag function is to recognise new, changed, or deleted records. PIM always sends the current status of each record, meaning that we need to compare against silver layer table in Unity catalog, because it contains deduplicated, latest version of each table. Tables.json is in instrumental role here since naming convention between silver layer and incoming records change in DLT temp layer, so table config acts as a dictionary.

  Arguments:
  incoming_df: DataFrame containing the incoming data
  table_name: Name of the table to compare against in the silver layer
  """

  # See if table exists in silver layer. If not, mark all incoming rows as insert update ("iu").
  try:
      silver_df = spark.sql(f"select * from silver_{env}.pim.silver_pim_{table_name}")
      table_exists = True
  except AnalysisException:
      log.info("Table %s does not exist, marking all rows insert/update", table_name)
      table_exists = False

  if table_exists == True:
    #Get column mapping from tables.json for matching incoming and silver naming conventions
    with open(file=table_config_path, mode="r") as file:
      pipeline_tables = json.load(file)

    #Extract keys of each table to join incoming and silver layer
    keys = pipeline_tables.get(table_name).get("keys")
    column_mapping = pipeline_tables.get(table_name).get("column_mapping")

    #Regex pattern is added to remove any sql-commands that might be used in table config so that columns might be compared
    pattern = r"\(\s*'?([^',\)\s]+)"

    #Loaddatetime is exlucded from the comparison
    column_mapping.pop("LoadDateTime")
    column_mapping.pop("opflag")
    new_col_mapping = {}
    for key, value in column_mapping.items():
        match = re.search(pattern, value)
        if match:
            # The captured group is the first argument, considering only up to the first space or specific delimiter
            new_col_mapping[key] = match.group(1)
        else:
            # If no match, the value doesn't seem to follow the pattern of a function call
            new_col_mapping[key] = value

    #Column mapping at this point is cleaned of any sql-commands such as casts
    column_mapping = new_col_mapping

    #Key mapping selects subset of column mapping which conists of only key columns in order to join
    key_mapping = {column_mapping[k]:k for k in keys if k in column_mapping}

    # Only select records from silver df that match those of incoming df by article_id
    silver_df = silver_df.join(df.select(col("articles.articleid").alias("incoming_articleid")),
                            col("incoming_articleid") == col("articleid"),
                            "semi")

    incoming_alias = "incoming"
    silver_alias = "silver"

    #Create list for update condition based on column mappings
    condition_list = []
    for silver_col, incoming_col in column_mapping.items():
      condition = f"{incoming_alias}.{incoming_col} != {silver_alias}.{silver_col}"
      condition_list.append(condition)
    # Combine conditions into a single SQL-like query string
    condition_query = " OR ".join(condition_list)

    # Perform left join and filter to only include new or changed rows
    iu_df = incoming_df.alias(incoming_alias).join(silver_df.alias(silver_alias),
    [col(f"{incoming_alias}.{k}") == col(f"{silver_alias}.{v}") for k, v in key_mapping.items()],
    "left"
    ).where(
    (col(f"{silver_alias}.{list(key_mapping.values())[0]}").isNull()) |  # New records where silver_df has nulls
    expr(condition_query)  # Or changed records where at least one attribute differs
    ).select([col(f"{incoming_alias}.{col_name}") for col_name in incoming_df.columns]
    ).withColumn("opflag", lit("iu"))

    #Create a dataframe from incoming data that only contains change timestamps and articleid to get deleted events a change timestamp
    ldts_df = df.select("articles.articleid", col("articles.basicData.lastModified").alias("LoadDateTime"))

    # Perform left anti join for deleted ("d") records
    d_df = (silver_df.join(
        incoming_df,
        [silver_df[v] == incoming_df[k] for k,v in key_mapping.items()],
        "left_anti")
    .drop("SilverLoadDateTime")
    .drop("BronzeLoadDateTime")
    .drop("SrcID")
    .drop("LoadDateTime")
    .drop("opflag")
    )
    #Ensure that columns match incoming format
    for silver_col, incoming_col in column_mapping.items():
      d_df = d_df.withColumnRenamed(silver_col, incoming_col)

    #Join to ldts to get timestamp for delete event
    d_df = (d_df.join(ldts_df.alias("ldts"),
          "articleid", "inner")
    .select("*")
    #opflag d for deleted
    .withColumn("opflag", lit("d"))
    )
    d_df = d_df.select(iu_df.columns)

    # If there are deleted records, union them with incoming records
    if d_df.count() > 0:
      final_df = iu_df.union(d_df)
    else:
      final_df = iu_df

  else:
    final_df = incoming_df.withColumn("opflag", lit("iu"))

  return final_df.dropDuplicates()


# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Tables

# COMMAND ----------

# Get a separate list of tables that contain language references, meaning data that has translations in the event
language_tables = [table for table, config in table_config.items() if config.get("language_references")]

# COMMAND ----------

# Import all python files in the config folder
python_files = [f[:-3] for f in os.listdir(config_path) if f.endswith('.py') and f != '__init__.py']
if selected_tables != "all_tables":
    python_files = [pfilename for pfilename in python_files if pfilename in selected_tables]
else:
    python_files = [pfilename for pfilename in python_files]

parsing_functions = {}

for filename in python_files:
    # Loop through the filenames and import them with importlib
    module_name = filename
    if module_name in sys.modules:
        module = sys.modules[module_name]
        importlib.reload(module)
    else:
        module = importlib.import_module(module_name)
    func_name = f'parse_{filename}'
    #Extract parsing function parse_<table_name> from each python file
    try:
        parsing_function = getattr(module, func_name)
        parsing_functions[filename] = parsing_function
    except AttributeError:
        log.error("Function %s not found in module %s", func_name, module_name)

# COMMAND ----------

#Parallellizing table parsing from incoming data by wrapping it in a function

def parse_table(filename, df, cols, language_tables):
    log.info("Parsing table %s", filename)
    if filename not in language_tables:
        # If table does not contain language references, parse the table normally and return only one dataframe
        result_df = parsing_functions[filename](df, cols)
        return filename, result_df
    else:
        # Otherwise return two dataframes, the one with the actual data, and another with translation <table_name>_master
        final_df, special_df = parsing_functions[filename](df, cols)
        return filename, final_df, f"{filename}_master", special_df

result_dfs = {}

# COMMAND ----------

with concurrent.futures.ThreadPoolExecutor(max_workers = 5 ) as executor:
    # Call parsing functions
    future_to_filename = {executor.submit(parse_table, filename, df, cols, language_tables): filename for filename in parsing_functions}
    parsing_success = True
    for future in concurrent.futures.as_completed(future_to_filename):
        # Some parsing tables return two dataframes instead of one dataframe.
        # The other dataframe is called <table_name>_master and it contains language references.
        # Based on the number of returned dataframes, determine if the table is a language reference table
        # Resulting parsed dataframes are stored in dict result_dfs as {table_name:dataframe}
        try:
            result = future.result()
            if len(result) == 2:
                filename, result_df = result
                result_dfs[filename] = result_df
            else:
                filename, final_df, lang_filename, lang_df = result
                result_dfs[filename] = final_df
                result_dfs[lang_filename] = lang_df
        except Exception as exc:
            log.error("Generated an exception: %s", exc)
            parsing_success = False
if not parsing_success:
    raise Exception("Parsing failed: One or more parallelized items failed")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Creating lang references

# COMMAND ----------

def create_lang_references(source_df, table, table_config):
  """
  This function creates a DataFrame containing language references for a given table. Meaning that it will parse translations for any given code from <table_name>_master dataframe forming Finnish, Swedish and English translations for the code.

  Args:
  source_df (DataFrame): Source DataFrame containing the data.
  table (str): Name of the table being processed.
  table_config (dict): Configuration dictionary containing language reference details.

  Returns:
  DataFrame: DataFrame containing the language references.
  """

  schema = StructType([
    StructField("id", IntegerType(), False),
    StructField("code", StringType(), False),
    StructField("lang", StringType(), False),
    StructField("value", StringType(), False),
    StructField("source_table", StringType(), False),
    StructField("source_column", StringType(), False)
  ])

  table = table.removesuffix("_master")
  plr_master = spark.createDataFrame([], schema)
  for lref in table_config.get(table).get("language_references"):
    code = list(lref.keys())[0]
    item = list(lref.values())[0]
    lang = item.get("lang")
    value = item.get("value")
    source_table = item.get("source_table")

    lang_df = source_df.select(
      concat_ws("-", lit(source_table), lit(code), col(code), col(lang)).alias("id"),
      col(code).alias("code"),
      col(lang).alias("lang"),
      col(value).alias("value"),
      lit(source_table).alias("source_table"),
      lit(code).alias("source_column")
    )

    plr_master = plr_master.unionByName(lang_df).dropDuplicates()

  return plr_master

# COMMAND ----------

# Filter out language reference tables from result_dfs
lang_ref_tables = {key: value for key, value in result_dfs.items() if key.endswith('_master')}

# Create a list of DataFrames containing language references
plr_list = [create_lang_references(source_df, table, table_config) for table, source_df in lang_ref_tables.items()]


# Combine all language reference DataFrames into one
if len(plr_list) > 0:
  pim_lang_references = reduce(pyspark.sql.DataFrame.unionByName, plr_list)

  # Filter out rows with null or empty 'code' and remove duplicates
  pim_lang_references = (pim_lang_references.filter(col("code").isNotNull())
                                            .filter("code != ''")
                          .dropDuplicates()
                          .withColumn("LoadDateTime", current_timestamp())
                        )

  # Add the combined DataFrame to result_dfs
  if selected_tables != 'all_tables':
    pim_lang_references = pim_lang_references.filter(col("source_table").isin(selected_tables))
  result_dfs["pim_lang_references"] = pim_lang_references

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Writing to filesystem

# COMMAND ----------

if selected_tables == 'all_tables':
  if plr == False:
        tables = {key: value for key, value in result_dfs.items() if not key.endswith('_master')}
  else:
    tables = {"pim_lang_references": pim_lang_references}
else:
  # Create table list to write to data lake
  # Exclude tables that contain translations as they are already stored uniquely to pim_lang_references
  tables = {key: value for key, value in result_dfs.items() if not key.endswith('_master') if key in selected_tables}

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Writing to filesystem

# COMMAND ----------

def write_pim_to_filesystem(table):
  log.info("Begin writing table %s", table)

  write_df = tables[table]
  # Lang references does not change over time, so opflag is not needed
  if table != 'pim_lang_references':
    write_df = get_opflag(write_df, table)
    # Add partitioning columns
  write_df = (write_df.withColumn("partitioning_timestamp", current_timestamp())
          .withColumn("year", year("partitioning_timestamp"))
          .withColumn("month", month("partitioning_timestamp"))
          .withColumn("day", dayofmonth("partitioning_timestamp"))
          .drop("partitioning_timestamp")
        )

  # Write the DataFrame to the filesystem in Parquet format
  (write_df.write
    .format("parquet")
    .mode("overwrite")
    .partitionBy("year", "month", "day")
    .option("mergeSchema", "true")
    .save(f"abfss://dlt@kdata{env}adls.dfs.core.windows.net/pim/source/{table}")
  )

  # Log the completion of the writing process
  log.info("Finished writing table %s", table)

# COMMAND ----------

max_workers = 5
success = True
# Parallel write to data lake
with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
    futures = {table: executor.submit(write_pim_to_filesystem, table) for table in tables}
    concurrent.futures.wait(futures.values())

    for table_name, future in futures.items():
        if future.exception() is not None:
            success = False
            log.error("Error writing table %s: %s", table_name, future.exception())

if not success:
    raise Exception("Writing to disc failed: One or more parallelized items failed")
