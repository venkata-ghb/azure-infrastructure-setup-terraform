import logging
import sys

# Note: This is a duplicate of the logger in pipelines/sap/logger.py.
# We should consider unifying these two into a single common logger, but
# currently that would require some refactoring of the pipeline to be possible.
# Keep the two in sync.


class BoundLogger(logging.LoggerAdapter):
    """Logger that carries structured context fields through a call chain via bind()."""

    def bind(self, **kwargs) -> "BoundLogger":
        """Return a new BoundLogger with the given fields merged into existing context."""
        return BoundLogger(self.logger, {**self.extra, **kwargs})

    def process(self, msg, kwargs):
        if self.extra:
            ctx = "  " + " ".join(f"{k}={v}" for k, v in self.extra.items())
        else:
            ctx = ""
        return f"{msg}{ctx}", kwargs


def get_logger(name: str) -> BoundLogger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(logging.Formatter(
            "%(asctime)s %(levelname)-8s [%(name)s] %(message)s",
            datefmt="%Y-%m-%dT%H:%M:%S"
        ))
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
        logger.propagate = False
    return BoundLogger(logger, {})
