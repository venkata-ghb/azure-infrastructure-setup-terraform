# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC ## Imports

# COMMAND ----------

dbutils.widgets.text("table_config_path", "/Workspace/Repos/ext.teemu.mikkonen@kesko.fi/kdata-adb-dlt/pipelines/pim")
dbutils.widgets.text("env", "dev")
dbutils.widgets.text("force_run", "false") # Set manually to "true" as job parameter to force a run regardless if queue is empty or not. Default is "false"

# COMMAND ----------

import re
import requests as r
from pyspark.sql.functions import col, explode, current_timestamp, year, month, dayofmonth, first, lit, expr, concat_ws
from pyspark.sql.types import StructType, StructField, StringType, IntegerType
from pyspark import SparkConf, SparkContext
from pyspark.sql import DataFrame
import json
sc = SparkContext.getOrCreate(SparkConf().setMaster("local[*]"))
from delta.tables import DeltaTable
from functools import reduce
import importlib
from pyspark.sql.utils import AnalysisException
import concurrent.futures
import os, sys
import version
from logger import get_logger

log = get_logger("process_pim_raw_data")

log.info("process_pim_raw_data | build: %s | sha: %s", version.BUILD_NUMBER, version.GIT_SHA)

# Checking to exit notebook if force_run is enabled but queue is empty
# If queue is empty but force_run is not, then the previous condition task to check for empty que should not allow this notebook to run
has_pending_input = dbutils.jobs.taskValues.get(
    taskKey="read_pim_queue",
    key="has_pending_input",
    default=False
)
if not has_pending_input:
    dbutils.notebook.exit("No messages in Service bus queue. Exit process_pim_raw_data. Continue job run")


env = dbutils.widgets.get("env")
w_dir = dbutils.widgets.get("table_config_path")
table_config_path = f"{w_dir}/tables.json"

# Add configuration path to python path
config_path = f"{w_dir}/parsing_configs"
sys.path.append(config_path)

# Directory where bookkeeping of read messages is stored
events_directory = f"abfss://dlt@kdata{env}adls.dfs.core.windows.net/pim/events"
# Directory where messages are saved in json-format
backfill_directory = f"abfss://dlt@kdata{env}adls.dfs.core.windows.net/pim/backup"

# SAS token for blob connection
sas_token = dbutils.secrets.get(scope=f'kv-kd-shared', key='tps-shared-container-sas-token-secret')

#Table configuration to get table mapping between bronze and silver layers (also opflag parsing)
with open(file=table_config_path, mode="r") as file:
  table_config = json.load(file)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Reading and processing events

# COMMAND ----------

# Read events directory, all non-success rows (including previously failed ones)
try:
    if DeltaTable.isDeltaTable(spark, events_directory):
        url_df = (
            spark.read.format("delta")
            .load(events_directory)
            .filter(col("status") != "success")
        )
    else:
        log.error("No Delta table found at %s; nothing to process.", events_directory)

except AnalysisException:
    log.error("Events directory %s is not initialized as a Delta table; nothing to process.", events_directory)

#Form an url list to process next
url_list = [row.url for row in url_df.select("url").collect()]
log.info("Number of messages to process: %s", len(url_list))

# COMMAND ----------

# Messages contain urls to blob storage where the actual json events are stored.
# This cell runs parallelized code to effectively send get requests to blob storage and store received json-messages into a list

def fetch_url(msg):
    log.info("Fetching url: %s", msg)
    response = r.get(f"{msg}?{sas_token}", timeout=(5, 30))
    response.raise_for_status()
    return response.text

with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
    event_list = list(executor.map(fetch_url, url_list))

log.info("Finished fetching messages. Number of messages fetched: %s", len(event_list))

# COMMAND ----------

#Event list is transformed into pyspark dataframe with two columns: articles and products.
# As of now, we've only been interested in articles part, but there might be a requirement to start also processing products

json_rdd = sc.parallelize(event_list)
df = (spark.read
      .option("multiLine", "true")
      .json(json_rdd)
      .select(explode("articles").alias("articles"))
      )

# COMMAND ----------

# The goal of this block is to deduplicate the DataFrame, ensuring that for each unique 'articleid', only the single record with the most recent 'lastModified' timestamp is kept.

df = (df
      # Step 1: Sort the data using the original syntax.
      .sort(["articles.articleid", "articles.basicData.lastModified"], ascending=[True, False])

      # Step 2: Create a temporary helper column 'sortid'.
      .withColumn("sortid", col("articles.articleid"))

      # Step 3: Remove duplicate rows based on the 'sortid'.
      .dropDuplicates(["sortid"])

      # Step 4: Remove the temporary helper column as it's no longer needed.
      .drop("sortid")

      # Step 5: As a final cleanup, remove any rows that are perfect duplicates
      # across all remaining dataframe columns.
      .dropDuplicates()
     )

# Get the names of all top-level fields within the 'articles' struct and convert them to lowercase.
cols = [c.lower() for c in df.select("articles.*").columns]

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Write Incoming pim message dataframe to data lake as json
# MAGIC
# MAGIC

# COMMAND ----------

# We need to be able to re-read complete events eg. for populating new columns or tables without having PIM re-send everything
# This is why all events are stored as json-messages in the backup directory, partitioned by the data they were written on.

backup_df = (df.withColumn("partitioning_timestamp", current_timestamp())
)
backup_df =(backup_df.withColumn("year", year("partitioning_timestamp"))
                     .withColumn("month", month("partitioning_timestamp"))
                     .withColumn("day", dayofmonth("partitioning_timestamp"))
)
log.info("Write data to backup dir: %s", backfill_directory)
(backup_df.write
  .format("json")
  .partitionBy("year", "month", "day")
  .option("mergeSchema", "true")
  .mode("append")
  .save(backfill_directory)
)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Utils

# COMMAND ----------

def get_opflag(incoming_df, table_name, df):

  """
  Purpose of the get opflag function is to recognise new, changed, or deleted records. PIM always sends the current status of each record, meaning that we need to compare against silver layer table in Unity catalog, because it contains deduplicated, latest version of each table. Tables.json is in instrumental role here since naming convention between silver layer and incoming records change in DLT temp layer, so table config acts as a dictionary.

  Arguments:
  incoming_df: DataFrame containing the incoming data
  table_name: Name of the table to compare against in the silver layer
  df: DataFrame containing the current state of the table in the silver layer
  """

  log.info("Get opflag for table %s", table_name)
  # See if table exists in silver layer. If not, mark all incoming rows as insert update ("iu").
  try:
      silver_df = spark.sql(f"select * from silver_{env}.pim.silver_pim_{table_name} where opflag != 'd'")
      table_exists = True
  except AnalysisException:
      log.info("Table %s does not exist, marking all rows insert/update", table_name)
      table_exists = False

  if table_exists == True:
    #Get column mapping from tables.json for matching incoming and silver naming conventions
    with open(file=table_config_path, mode="r") as file:
      pipeline_tables = json.load(file)

    #Extract keys of each table to join incoming and silver layer
    keys = pipeline_tables.get(table_name).get("keys")
    column_mapping = pipeline_tables.get(table_name).get("column_mapping")

    #Regex pattern is added to remove any sql-commands that might be used in table config so that columns might be compared
    pattern = r"\(\s*'?([^',\)\s]+)"

    #Loaddatetime is exlucded from the comparison
    column_mapping.pop("LoadDateTime")
    new_col_mapping = {}
    for key, value in column_mapping.items():
        match = re.search(pattern, value)
        if match:
            # The captured group is the first argument, considering only up to the first space or specific delimiter
            new_col_mapping[key] = match.group(1)
        else:
            # If no match, the value doesn't seem to follow the pattern of a function call
            new_col_mapping[key] = value

    #Column mapping at this point is cleaned of any sql-commands such as casts
    column_mapping = new_col_mapping

    #Key mapping selects subset of column mapping which conists of only key columns in order to join
    key_mapping = {column_mapping[k]:k for k in keys if k in column_mapping}

    # Only select records from silver df that match those of incoming df by article_id
    silver_df = silver_df.join(df.select(col("articles.articleid").alias("incoming_articleid")),
                            col("incoming_articleid") == col("articleid"),
                            "semi")

    incoming_alias = "incoming"
    silver_alias = "silver"

    #Create list for update condition based on column mappings
    condition_list = []
    for silver_col, incoming_col in column_mapping.items():
      condition = f"{incoming_alias}.{incoming_col} != {silver_alias}.{silver_col}"
      condition_list.append(condition)
    # Combine conditions into a single SQL-like query string
    condition_query = " OR ".join(condition_list)

    # Perform left join and filter to only include new or changed rows
    iu_df = incoming_df.withColumn("opflag", lit(None)).alias(incoming_alias).join(silver_df.alias(silver_alias),
    [col(f"{incoming_alias}.{k}") == col(f"{silver_alias}.{v}") for k, v in key_mapping.items()],
    "left"
    ).where(
    (col(f"{silver_alias}.{list(key_mapping.values())[0]}").isNull()) |  # New records where silver_df has nulls
    expr(condition_query)  # Or changed records where at least one attribute differs
    ).select([col(f"{incoming_alias}.{col_name}") for col_name in incoming_df.columns]
    ).withColumn("opflag", lit("iu"))

    #Create a dataframe from incoming data that only contains change timestamps and articleid to get deleted events a change timestamp
    ldts_df = df.select("articles.articleid", col("articles.basicData.lastModified").alias("LoadDateTime"))

    # Perform left anti join for deleted ("d") records
    d_df = (silver_df.join(
        incoming_df,
        [silver_df[v] == incoming_df[k] for k,v in key_mapping.items()],
        "left_anti")
    .drop("SilverLoadDateTime")
    .drop("BronzeLoadDateTime")
    .drop("SrcID")
    .drop("LoadDateTime")
    .drop("opflag")
    )
    #Ensure that columns match incoming format
    for silver_col, incoming_col in column_mapping.items():
      d_df = d_df.withColumnRenamed(silver_col, incoming_col)

    #Join to ldts to get timestamp for delete event
    d_df = (d_df.join(ldts_df.alias("ldts"),
          "articleid", "inner")
    .select("*")
    #opflag d for deleted
    .withColumn("opflag", lit("d"))
    )
    d_df = d_df.select(iu_df.columns)

    # If there are deleted records, union them with incoming records
    if d_df.take(1):
      final_df = iu_df.union(d_df)
    else:
      final_df = iu_df

  else:
    final_df = incoming_df.withColumn("opflag", lit("iu"))

  return final_df.dropDuplicates()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Tables

# COMMAND ----------

# Get a separate list of tables that contain language references, meaning data that has translations in the event
language_tables = [table for table, config in table_config.items() if config.get("language_references")]

# COMMAND ----------

# Import all python files in the config folder
python_files = [f[:-3] for f in os.listdir(config_path) if f.endswith('.py') and f != '__init__.py']
parsing_functions = {}
log.info("Import all python files from config path: %s", config_path)
for filename in python_files:
    # Loop through the filenames and import them with importlib
    module_name = filename
    if module_name in sys.modules:
        module = sys.modules[module_name]
        importlib.reload(module)
    else:
        module = importlib.import_module(module_name)
    func_name = f'parse_{filename}'
    #Extract parsing function parse_<table_name> from each python file
    try:
        parsing_function = getattr(module, func_name)
        parsing_functions[filename] = parsing_function
    except AttributeError:
        log.error("Function %s not found in module %s", func_name, module_name)

# COMMAND ----------

#Parallellizing table parsing from incoming data by wrapping it in a function

def parse_table(filename, df, cols, language_tables):
    # This parsing is done with .py scripts from /pim/parsing_configs/
    log.info("Parsing table %s", filename)
    if filename not in language_tables:
        # If table does not contain language references, parse the table normally and return only one dataframe
        result_df = parsing_functions[filename](df, cols)
        return filename, result_df
    else:
        # Otherwise return two dataframes, the one with the actual data, and another with translation <table_name>_master
        final_df, special_df = parsing_functions[filename](df, cols)
        return filename, final_df, f"{filename}_master", special_df

result_dfs = {}

# COMMAND ----------

log.info("Start data parse")

with concurrent.futures.ThreadPoolExecutor(max_workers = 5 ) as executor:
    # Call parsing functions from parsing_configs/
    future_to_filename = {executor.submit(parse_table, filename, df, cols, language_tables): filename
                          for filename in parsing_functions}
    parsing_success = True

    # Handle threads as they complete
    for future in concurrent.futures.as_completed(future_to_filename):
        f_name = future_to_filename[future]
        # Some parsing tables return two dataframes instead of one.
        # The other dataframe is called <table_name>_master and it contains language references.
        # Based on the number of returned dataframes, determine if the table is a language reference table
        # Resulting parsed dataframes are stored in dict result_dfs as {table_name:dataframe}
        try:
            result = future.result()
            if len(result) == 2:
                filename, result_df = result
                result_dfs[filename] = result_df
            else:
                filename, final_df, lang_filename, lang_df = result
                result_dfs[filename] = final_df
                result_dfs[lang_filename] = lang_df
        except Exception as exc:
            parsing_success = False
            log.error("Generated an exception for filename %s: %s: %s", f_name, type(exc).__name__, exc)

if not parsing_success:
    raise Exception("Parsing failed: One or more parallelized items failed")

log.info("End data parse")


# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Language references for base dataframes

# COMMAND ----------

def create_lang_references(source_df, table, table_config):
    """
    Generates a LIST of language reference DataFrames from a source table.

    This refactored version avoids the slow "union in a loop" pattern by returning
    a list of DataFrames, which can be combined all at once later.

    Args:
        source_df (DataFrame): Source DataFrame containing the data.
        table (str): Name of the table being processed.
        table_config (dict): Configuration dictionary containing language reference details.

    Returns:
        DataFrame: DataFrame containing the language references.
    """
    log.info("Create lang references for table %s", table)

    config_key = table.removesuffix("_master")
    lang_dfs_list = []

    # It assumes each 'lref' dict has exactly one key-value pair.
    for lref in table_config.get(config_key, {}).get("language_references", []):
        for code, item in lref.items():
            lang = item.get("lang")
            value = item.get("value")
            source_table = item.get("source_table")

            # Create the DataFrame with the specific language transformation.
            lang_df = source_df.select(
                concat_ws("-", lit(source_table), lit(code), col(code), col(lang)).alias("id"),
                col(code).alias("code"),
                col(lang).alias("lang"),
                col(value).alias("value"),
                lit(source_table).alias("source_table"),
                lit(code).alias("source_column")
            )
            lang_dfs_list.append(lang_df)

    return lang_dfs_list

# COMMAND ----------


# Step 1: Filter for language reference tables.
lang_ref_tables = {key: value for key, value in result_dfs.items() if key.endswith('_master')}

# Step 2: Create a single, flat list of all language DataFrames from all source tables.This nested list comprehension replaces the original loop and subsequent union.
all_lang_dfs = [
    df
    for table, source_df in lang_ref_tables.items()
    for df in create_lang_references(source_df, table, table_config)
]

# Step 3: Check if any language DataFrames were created before proceeding.
if all_lang_dfs:
    # Step 4: Combine all individual DataFrames into one. This single reduce operation is used now compared to the previous unioning inside a loop.
    pim_lang_references = reduce(DataFrame.unionByName, all_lang_dfs)

    # Step 5: Perform all filtering and cleanup operations once on the final, combined DataFrame. The two .filter() calls are combined for clarity, but the logic is identical.
    pim_lang_references = (pim_lang_references
                           .filter((col("code").isNotNull()) & (col("code") != ''))
                           .dropDuplicates()
                           .withColumn("LoadDateTime", current_timestamp())
                          )

    # Step 6: Add the final DataFrame to the results dictionary.
    result_dfs["pim_lang_references"] = pim_lang_references
else:
    log.error("No language reference tables found to process.")

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Writing base dataframes to filesystem as parquet

# COMMAND ----------

# Create table list to write to data lake
# Exclude tables that contain translations as they are already stored uniquely to pim_lang_references
tables = {key: value for key, value in result_dfs.items() if not key.endswith('_master')}

# COMMAND ----------

# Write base data frames to /source/ as parquet that bronze layer tables will be ingested from

def write_pim_to_filesystem(table, df):
  log.info("Begin writing table %s", table)

  write_df = tables[table]
  # Lang references does not change over time, so opflag is not needed
  if table != 'pim_lang_references':
    write_df = get_opflag(write_df, table, df)

  # Add partitioning columns
  write_df = (write_df.withColumn("partitioning_timestamp", current_timestamp())
          .withColumn("year", year("partitioning_timestamp"))
          .withColumn("month", month("partitioning_timestamp"))
          .withColumn("day", dayofmonth("partitioning_timestamp"))
          .drop("partitioning_timestamp")
        )

  # Write the DataFrame to the filesystem in Parquet format
  (write_df.write
    .format("parquet")
    .mode("append")
    .partitionBy("year", "month", "day")
    .option("mergeSchema", "false")
    .save(f"abfss://dlt@kdata{env}adls.dfs.core.windows.net/pim/source/{table}")
  )

  # Log the completion of the writing process
  log.info("Finished writing table %s", table)

# COMMAND ----------

max_workers = 5
success = True
log.info("Start write to datalake")

# Parallel write to data lake
with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
    # Launch threads and create dict from results
    futures_to_table = {executor.submit(write_pim_to_filesystem, table, df): table
               for table in tables}

    # Handle threads as they complete
    for future in concurrent.futures.as_completed(futures_to_table):
        table_nme = futures_to_table[future]
        try:
            future.result()
        except Exception as exc:
            success = False
            log.error("Error writing table %s: %s: %s", table_nme, type(exc).__name__, exc)

if not success:
    raise Exception("Writing to disc failed: One or more parallelized items failed")

log.info("End write to datalake")

# COMMAND ----------

# url_df is one created from pim queue messages
# Message url is a semantic meaning for file path in blob storage from queue

# Update the status of URLs and remove duplicates
url_df = (url_df.withColumn("new_status", lit("success"))
              .groupBy("url", "read_timestamp", "status")
              .agg(first("new_status").alias("new_status"))
              .dropDuplicates(["url"])
              )

# Load the Delta table
events = DeltaTable.forPath(spark, events_directory)

# Merge the new URL data into the Delta table, updating the status to success if whole notebook has been succesfully processed
(
    events.alias("t")
    .merge(
        url_df.alias("s"),
        "t.url = s.url AND t.status NOT IN ('success')"
    )
    .whenMatchedUpdate(
        condition="s.new_status IS NOT NULL",
        set={"status": "s.new_status"}
    )
    .execute()
)

# COMMAND ----------

# Optimize events delta table
event_delta = DeltaTable.forPath(spark, events_directory)
event_delta.optimize().executeCompaction()
