# Databricks notebook source
from pyspark.sql.functions import col, lit, max, desc, current_timestamp
from pyspark.sql.types import StringType, NumericType, BooleanType
import json
import time
import os
from logger import get_logger

log = get_logger("ignore_columns_config")

# COMMAND ----------

dbutils.widgets.text("env", "dev")
dbutils.widgets.text("pipeline_path", "/Workspace/Repos/ext.teemu.mikkonen@kesko.fi/kdata-adb-dlt/pipelines/sap")
dbutils.widgets.text("max_workers", "5")
dbutils.widgets.text("writer_config", "kesprodata_pim_silver")

# COMMAND ----------

env = dbutils.widgets.get("env")
pipeline_path = dbutils.widgets.get("pipeline_path")
max_workers = int(dbutils.widgets.get("max_workers"))
writer_config_name = f"writer_config_{dbutils.widgets.get('writer_config')}"

# COMMAND ----------

#Read writer config file
config_filepath = f"{pipeline_path}/config_files/{writer_config_name}.json"
log.info("Read config filepath: %s", config_filepath)
if not os.path.exists(config_filepath):
    raise FileNotFoundError(f"Config file not found: {config_filepath}")
with open(file=config_filepath, mode="r") as file:
    writer_config = json.load(file)

#Read table config file
target_table_config_path = f"{pipeline_path}/config_files/{writer_config.get('table_config_filename')}.json"
log.info("Read config for target file: %s", target_table_config_path)
with open(file=target_table_config_path, mode="r") as file:
    target_tables = json.load(file)

# COMMAND ----------

#Get connection details from config
conn_details = writer_config.get("connection_credentials")
user = dbutils.secrets.get(scope="kv-kd-shared", key = conn_details.get("user_key"))
pw = dbutils.secrets.get(scope="kv-kd-shared", key = conn_details.get("pw_key"))
host = dbutils.secrets.get(scope="kv-kd-shared", key = conn_details.get("host_key"))
database_name = conn_details.get("database_name")

#Get writer options from config
writer_options = writer_config.get("writer_options")
catalog_header = writer_options.get("catalog_header")
catalog = f"{catalog_header}_{env}"
uc_schema = writer_options.get("uc_schema")
schema_prefix = writer_options.get("schema_prefix")
timestamp_col = writer_options.get("timestamp_col")

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Functions

# COMMAND ----------

def read_source_information(table):
  log.info("Read source information for table: %s from database: %s", table, database_name)
  df = (spark.read
    .format("postgresql")
    .option("dbtable", table)
    .option("host", host)
    .option("port", 5432)
    .option("database", database_name)
    .option("user", user)
    .option("password", pw)
    .load()
  )

  max_loaddatetime = df.agg(max(col(timestamp_col))).collect()[0][0]
  schema = df.columns

  return max_loaddatetime, schema, df

# COMMAND ----------

def ignore_columns(table_name: str, table_config: dict) -> dict:
    ignore_columns = []

    # Fetch table information from config
    table_name = f"{schema_prefix}_table"
    target_schema_name = target.get("target_schema")
    target_table_name = target.get("target_name")

    # Full naming of table, including catalogs and schemas in KData and PSQL
    source_table = f"{catalog}.{uc_schema}.{schema_prefix}_{table}"
    target_table = f"{target_schema_name}.{target_table_name}"

    max_ldt, schema, psql_df = read_source_information(target_table)

    #Read source table from Unity Catalog
    silver_df = (spark.read
            .format("delta")
            .option("ignoreChanges", "true")
            .table(source_table)
            )

    ignore_field_names = ["sapid", "gtin", "opflag", "loaddatetime","silverloaddatetime","sequence","type","language"]

    #list columns that contain only null or empty values in the silver table or in the PostgreSQL table
    total_rows_silver = silver_df.count()
    total_rows_psql = psql_df.count()
    for column in psql_df.columns:
        if column in ignore_field_names:
            continue
        else:
            dtype_silver = silver_df.schema[column].dataType
            dtype_psql = psql_df.schema[column].dataType
            if not isinstance(dtype_silver, BooleanType) and not isinstance(dtype_psql, BooleanType):
                if isinstance(dtype_silver, StringType) or isinstance(dtype_psql, StringType):
                    empty_rows_silver=silver_df.filter(col(column).isNull() | (col(column) == "")).count()
                    empty_rows_psql=psql_df.filter(col(column).isNull() | (col(column) == "")).count()
                elif isinstance(dtype_silver, NumericType) or isinstance(dtype_psql, NumericType):
                    empty_rows_silver = silver_df.filter(col(column).isNull()).count()
                    empty_rows_psql = psql_df.filter(col(column).isNull()).count()
                if total_rows_silver > 0 and empty_rows_silver == total_rows_silver and total_rows_psql > 0 and empty_rows_psql == total_rows_psql:
                    ignore_columns.append(column)


    #Remove key-like columns and date column from comparison
    #Remove columns that might exist in source tables that are not relevant for comparison
    for col_name in ignore_field_names:
        ignore_columns.append(col_name)

    return table, target_table_name, ignore_columns


# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Execution

# COMMAND ----------

results = []
for table, target in target_tables.items():
    result  = ignore_columns(table, target)
    results.append(result)

output_json = {}

for silver_table, psql_table, columns in results:
    output_json[silver_table] = {
        "table_name": psql_table,
        "columns": columns
    }

#print output
log.info("%s", output_json)

#save information into json file
#with open("ignore_columns.json", "w") as f:
#    json.dump(output_json, f, indent=2)
