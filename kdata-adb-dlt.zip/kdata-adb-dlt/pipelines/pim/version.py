# This file is overwritten during CI. Local/manual runs will show these placeholder values.
BUILD_NUMBER = "local"
GIT_SHA = "local"
