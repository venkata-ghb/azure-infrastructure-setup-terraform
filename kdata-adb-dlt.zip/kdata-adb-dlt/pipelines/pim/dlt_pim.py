# Databricks notebook source
import json
import sys
import time
from pyspark.sql.functions import *
from pyspark.sql.types import *
from datetime import datetime, timezone
from logger import get_logger
import version

log = get_logger("dlt_pim")

log.info("dlt_pim | build: %s | sha: %s", version.BUILD_NUMBER, version.GIT_SHA)

# COMMAND ----------


#Workspace/Repos/DLT/kdata-adb-dlt/dlt_functions/dltlib # This it the adb repo/ path to dltlib that doesnt sync by just running dlt_functions/ in devops pipeline
lib_path = "/Workspace/KDATA-DLT/dlt_functions/dltlib"
sys.path.insert(0, lib_path)
from dltlib import *
# import dltlib as dltlib_module
# import inspect
# print(dltlib_module.__file__)
# print("createsilver_temp signature:")
# print(inspect.signature(dltlib_module.dltlib.create_silver_temp_table))
# print("syspath:")
# print(sys.path[:10])

# COMMAND ----------

options = {"cloudFiles.format": "parquet"}
env = spark.conf.get("environment")
inputPath = f"abfss://dlt@kdata{env}adls.dfs.core.windows.net/pim/source"
#process_cols = {"LoadDateTime": col("AEDATTM").cast(TimestampType())}
#target_schema = "dlt_sapacr_test"
target_schema = spark.conf.get("target_schema") # schema in the local hive metastore
source_system = "pim"
lookback_days = int(spark.conf.get("lookback_days", "60"))
filter_column = "BronzeLoadDateTime"
apply_filter = True

# COMMAND ----------

pipeline_path = spark.conf.get("repository_path")
table_config_path = f"{pipeline_path}/tables.json"
with open(file=table_config_path, mode="r") as file:
    pipeline_tables = json.load(file)

# COMMAND ----------

log.info("Start bronze ingest")
for table in pipeline_tables.keys():
    log.info("Ingesting table %s to bronze", table)
    # Create the bronze tables from the /source/ dataframe files created in read_pim_que from source jsons
    dltlib.ingest_raw_data(
      table=table,
      sparkOptions=options,
      inputPath=f"{inputPath}/{table}"
    )
log.info("End bronze ingest")

# COMMAND ----------

log.info("Start silver processing with lookback_days %s, apply_filter %s, filter_column %s", lookback_days, apply_filter, filter_column)
for source_table, target_table in pipeline_tables.items():
  if target_table.get("process_silver"):
    trgt_table = target_table['target']
    log.info("Processing temp_silver for table %s from table %s", source_table, trgt_table)
    dltlib.create_silver_temp_table(
          source_table=source_table,
          target_table=trgt_table,
          column_mapping=target_table["column_mapping"],
          expectations=dltlib.generate_expectations(
              keys=target_table["keys"],
              allowed_values=target_table["allowed_values"]
          ),
          lookback_days = lookback_days,
          apply_filter = apply_filter,
          filter_column = filter_column,
          use_cdc = False,
          source_system = 'pim'
      )
    log.info("Processing silver for table %s from table %s", source_table, trgt_table)
    dltlib.create_silver_table(
          source_system='pim',
          target_table=trgt_table,
          keys=target_table["keys"],
          sequence_by="LoadDateTime"
      )
log.info("End silver processing")
