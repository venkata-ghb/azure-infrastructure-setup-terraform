resource databricks_pipeline dlt_pim {
  name = "dlt_pim"

  cluster {
    label          = "default"
    spark_env_vars = {}
    spark_conf = local.global_spark_conf
    autoscale {
      min_workers = 2
      max_workers = 8
      mode        = "ENHANCED"
    }
  }

  library {
    notebook {
      path = "${local.workspace_prefix}/pipelines/pim/dlt_pim"
    }
  }

  storage     = "abfss://dlt@kdata${var.ENV}adls.dfs.core.windows.net/pim/"
  continuous  = false
  channel     = "CURRENT"
  development = var.ENV == "dev" ? true : false
  photon      = true
  target      = var.ENV == "prod" ? "dlt_pim_${var.ENV}" : "dlt_pim"

  configuration = {
    environment     = var.ENV
    repository_path = "/Workspace${local.workspace_prefix}/pipelines/pim"
    target_schema   = var.ENV == "prod" ? "dlt_pim" : "dlt_pim"
    lookback_days   = "60"
  }
}
