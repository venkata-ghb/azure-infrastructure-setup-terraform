# Databricks notebook source
from logger import get_logger

log = get_logger("drop_uc_tables")

dbutils.widgets.text(name="environment",defaultValue="dev")
dbutils.widgets.text(name="schema_name",defaultValue="pim")
dbutils.widgets.text(name="area",defaultValue="silver")
dbutils.widgets.text(name="tables",defaultValue="")
environment = dbutils.widgets.get("environment")
area = dbutils.widgets.get("area")
source_system = dbutils.widgets.get("schema_name")
tables = dbutils.widgets.get("tables")

source_schema = f"{area}_{environment}.{source_system}"

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Drop UC tables

# COMMAND ----------

#input tables without silver_pim -prefix
source_df = spark.sql(f"show tables in {source_schema}")
source_tables = [data[1] for data in source_df.collect()]
if tables == "":
  selected_tables = []
  dbutils.notebook.exit("No tables selected")
if tables == "all_tables":
  selected_tables = source_tables
else:
  if area == 'silver':
      selected_tables = [f"{area}_{source_system}_{table_name}" if not table_name.startswith("__") else table_name for table_name in dbutils.widgets.get("tables").split(",")]
  else:
    selected_tables = [f"{area}_{table_name}" for table_name in dbutils.widgets.get("tables").split(",")]


# COMMAND ----------

for table in selected_tables:
  if table in source_tables:
    table_designation = f"{source_schema}.{table}"
    if area == 'silver':
      if not table.startswith("__"):
        spark.sql(f"drop view {table_designation}")
        log.info("Dropped table %s", table_designation)
      else:
        spark.sql(f"drop table {table_designation}")
        log.info("Dropped table %s", table_designation)
    else:
      log.info("Dropped table %s", table)
      spark.sql(f"drop table {table_designation}")
