from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_materials(df, cols):
    materials_schema = StructType([
        StructField("sapid", StringType(), True),
        StructField("ean", StringType(), True),
        StructField("LoadDateTime", StringType(), True),
        StructField("articleid", StringType(), True),
        StructField("materialCode", StringType(), True),
        StructField("materialCountryCode", StringType(), True),
        StructField("materialWeight", StringType(), True),
        StructField("rawMaterialCode", StringType(), True),
        StructField("RawMaterialContentPercentage", StringType(), True)
    ])

    if df.select("articles.sapid", explode(col("articles.ingredients.materials")).alias("materials_array")).count() != 0:

        materials = (df.select("articles.sapid",
                    "articles.basicdata.ean",
                    col("articles.basicData.lastModified").alias("LoadDateTime"),
                    col("articles.articleid").alias("articleid"),
                    explode(col("articles.ingredients.materials")).alias("materials_array")
                    )
        .select("*",
                "materials_array.materialCode",
                "materials_array.materialCountryCode",
                "materials_array.materialWeight",
                "materials_array.rawMaterialCode",
                "materials_array.RawMaterialContentPercentage"
                )
        .drop("materials_array")
        .dropDuplicates()
        )
            
    else:
        materials = spark.createDataFrame([], materials_schema)
    return materials
