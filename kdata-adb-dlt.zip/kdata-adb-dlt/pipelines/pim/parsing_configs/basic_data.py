from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_basic_data(df, cols):
    basic_data_master = (df.select("articles.sapid",
                                "articles.basicdata.ean",
                                col("articles.basicData.lastModified").alias("LoadDateTime"),
                                col("articles.articleid").alias("articleid"),
                                col("articles.basicdata.showinweb"),
                                col("articles.basicdata.productlifecyclecode"),
                                col("articles.basicdata.productlifecycle"),                        
                                #col("articles.basicdata.additionalean"),
                                col("articles.basicdata.internalcode"),
                                col("articles.basicdata.currentstatus"),
                                col("articles.basicdata.lastmodified"),
                                col("articles.basicdata.lastmodified_synkka"),
                                col("articles.basicdata.isprivatelabel"),
                                col("articles.basicdata.brandname"),
                                col("articles.basicdata.subbrand"),
                                col("articles.basicdata.brandid"),
                                col("articles.basicdata.subbrandid"),
                                col("articles.basicdata.brandname_synkka"),
                                col("articles.basicdata.subbrand_synkka"),
                                col("articles.basicdata.brandowner_synkka"),
                                col("articles.basicdata.brandownergln_synkka"),
                                col("articles.basicdata.productfamily"),
                                col("articles.basicdata.productfamilyname_synkka"),
                                col("articles.basicdata.productfamilyidentification_synkka"),
                                col("articles.basicdata.articlecategorycode"),
                                col("articles.basicdata.articlecategory"),
                                col("articles.basicdata.hasvariableweight"),
                                col("articles.basicdata.variableweightallowabledeviationpercentage"),
                                col("articles.basicdata.distributionchannel"),
                                col("articles.basicdata.distributionchannelcode"),
                                col("articles.basicdata.distributionchanneltrade"),
                                col("articles.basicdata.distributionchanneltradecode"),
                                col("articles.basicdata.newarticlefrom"),
                                col("articles.basicdata.newarticleend"),
                                col("articles.basicdata.source"),
                                col("articles.basicdata.suppliersarticlenumber"),
                                col("articles.basicdata.hasalarm"),
                                col("articles.basicdata.discontinueddate"),
                                col("articles.basicdata.countryoforigincode"), # Key to lang references
                                col("articles.basicdata.countryoforigincodeiso"),
                                col("articles.basicdata.structuregroupcode"),
                                col("articles.basicdata.structuregroup"),
                                col("articles.basicdata.gpCategoryName"),
                                col("articles.basicdata.gpccategorycode"),
                                explode(col("articles.basicdata.countryoforiginlang")).alias("coo_lang_array"))
                        .select("*", 
                                col("coo_lang_array.lang").alias("coo_lang"),
                                col("coo_lang_array.val.value")[0].alias("countryOfOrigin"),
                        )
                        .drop("coo_lang_array")
    )
    basic_data = (basic_data_master.drop("coo_lang")
                                .drop("countryOfOrigin")
                                .dropDuplicates()
    )

    return basic_data, basic_data_master
