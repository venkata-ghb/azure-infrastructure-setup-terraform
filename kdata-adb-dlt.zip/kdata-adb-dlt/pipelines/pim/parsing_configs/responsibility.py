from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_responsibility(df, cols):
  


    responsibility_schema = StructType([
        StructField("sapid", StringType(), True),
        StructField("ean", StringType(), True),
        StructField("LoadDateTime", StringType(), True),
        StructField("articleid", StringType(), True),
        StructField("animalWelfareCode", StringType(), True),
        StructField("carbonFootPrint", StringType(), True),
        StructField("carbonFootPrintCompensation", StringType(), True),
        StructField("coalNeutral", StringType(), True),
        StructField("consumerUnitsRecyclingInstructions", StringType(), True),
        StructField("containsGeneticallyModifiedIngredients", StringType(), True),
        StructField("containsGeneticallyModifiedIngredientsCode", StringType(), True),
        StructField("deforestation", StringType(), True),
        StructField("domestic", BooleanType(), True),
        StructField("energyConsumption", StringType(), True),
        StructField("geneticallyModifiedOrganism", StringType(), True),
        StructField("organic", BooleanType(), True),
        StructField("palmOilResponsibility", StringType(), True),
        StructField("palmOilResponsibilityCode", StringType(), True),
        StructField("postHarvestTreatmentChemical", StringType(), True),
        StructField("postHarvestTreatmentChemicalCode", StringType(), True),
        StructField("preservationType", StringType(), True),
        StructField("preservationTypeCode", StringType(), True),
        StructField("soyResponsibility", StringType(), True),
        StructField("soyResponsibilityCode", StringType(), True),
        StructField("sustainabilityFeatureCode", StringType(), True),
        StructField("typeOfOrganicProduct", StringType(), True),
        StructField("typeOfOrganicProductCode", StringType(), True),
        StructField("vegan", BooleanType(), True),
        StructField("veganExtended", BooleanType(), True),
        StructField("waterFootPrint", StringType(), True),
        StructField("responsibility_lang", StringType(), True),
        StructField("type_of_organic_product", StringType(), True),
        StructField("soy_responsibility", StringType(), True),
        StructField("palm_oil_responsibility", StringType(), True),
        StructField("preservation_type", StringType(), True),
        StructField("post_harvest_treatment_chemical", StringType(), True),
        StructField("importClassificationValueSAP", StringType(), True),
        StructField("directEmission", StringType(), True),
        StructField("indirecetEmission", StringType(), True),
        StructField("ownImport", StringType(), True),
        StructField("cbamProductCode", StringType(), True),
        StructField("productCertifiedWood", StringType(), True),
        StructField("packagingCertifiedWoodMaterial", StringType(), True),
        StructField("amountOfCertifiedMaterial", StringType(), True),
        StructField("supProductCode", StringType(), True),
        StructField("supPackagingCode", StringType(), True),
        StructField("supCategoryProductCode", StringType(), True),
        StructField("supCategoryPackagingCode", StringType(), True),
        StructField("packagingRecycledWoodMaterial", StringType(), True),
        StructField("amountOfSUPPlasticReduced", StringType(), True),
        StructField("wildCaughtOrFarmedFishAndShellfishCode", StringType(), True),
        StructField("fishSpeciesScientificName", StringType(), True),
        StructField("woodScientificName", StringType(), True),
        StructField("sup_category_product", StringType(), True),
        StructField("sup_category_packaging", StringType(), True),
        StructField("wild_caught_or_farmed_fish_and_shellfish", StringType(), True),
        StructField("animal_welfare", StringType(), True),
    ])

    if 'responsibility' not in cols:
        responsibility_master = spark.createDataFrame([], responsibility_schema)
    else:
        responsibility_master = (df.select("articles.sapid",
                                        "articles.basicdata.ean",
                                        col("articles.basicData.lastModified").alias("LoadDateTime"),
                                        col("articles.articleid").alias("articleid"),
                                         "articles.responsibility.animalWelfareCode",
                                        "articles.responsibility.carbonFootPrint",
                                        "articles.responsibility.carbonFootPrintCompensation",
                                        "articles.responsibility.coalNeutral",
                                        "articles.responsibility.consumerUnitsRecyclingInstructions",
                                        "articles.responsibility.containsGeneticallyModifiedIngredients",
                                        "articles.responsibility.containsGeneticallyModifiedIngredientsCode",
                                        "articles.responsibility.deforestation",
                                        "articles.responsibility.domestic",
                                        "articles.responsibility.energyConsumption",
                                        "articles.responsibility.geneticallyModifiedOrganism",
                                        "articles.responsibility.organic",
                                        "articles.responsibility.palmOilResponsibility",
                                        "articles.responsibility.palmOilResponsibilityCode",
                                        "articles.responsibility.postHarvestTreatmentChemical",
                                        "articles.responsibility.postHarvestTreatmentChemicalCode",
                                        "articles.responsibility.preservationType",
                                        "articles.responsibility.preservationTypeCode",
                                        "articles.responsibility.soyResponsibility",
                                        "articles.responsibility.soyResponsibilityCode",
                                        "articles.responsibility.sustainabilityFeatureCode",
                                        "articles.responsibility.typeOfOrganicProduct",
                                        "articles.responsibility.typeOfOrganicProductCode",
                                        "articles.responsibility.vegan",
                                        "articles.responsibility.veganExtended",
                                        "articles.responsibility.waterFootPrint",
                                        "articles.responsibility.importClassificationValueSAP",
                                        "articles.responsibility.directEmission",
                                        "articles.responsibility.indirecetEmission",
                                        "articles.responsibility.ownImport",
                                        "articles.responsibility.cbamProductCode",
                                        "articles.responsibility.productCertifiedWood",
                                        "articles.responsibility.packagingCertifiedWoodMaterial",
                                        "articles.responsibility.amountOfCertifiedMaterial",
                                        "articles.responsibility.supProductCode",
                                        "articles.responsibility.supPackagingCode",
                                        "articles.responsibility.supCategoryProductCode",
                                        "articles.responsibility.supCategoryPackagingCode",
                                        "articles.responsibility.packagingRecycledWoodMaterial",
                                        "articles.responsibility.amountOfSUPPlasticReduced",
                                        "articles.responsibility.wildCaughtOrFarmedFishAndShellfishCode",
                                        "articles.responsibility.fishSpeciesScientificName",
                                        "articles.responsibility.woodScientificName",
                                        explode("articles.responsibility.responsibilitylang").alias("responsibility_lang_array"))
                                    .select("*",
                                            col("responsibility_lang_array.lang").alias("responsibility_lang"),
                                            col("responsibility_lang_array.val.value")[0].alias("type_of_organic_product"),
                                            col("responsibility_lang_array.val.value")[1].alias("soy_responsibility"),
                                            col("responsibility_lang_array.val.value")[2].alias("palm_oil_responsibility"),
                                            col("responsibility_lang_array.val.value")[3].alias("preservation_type"),
                                            col("responsibility_lang_array.val.value")[4].alias("post_harvest_treatment_chemical"),
                                            col("responsibility_lang_array.val.value")[6].alias("sup_category_product"),
                                            col("responsibility_lang_array.val.value")[7].alias("sup_category_packaging"),
                                            col("responsibility_lang_array.val.value")[8].alias("wild_caught_or_farmed_fish_and_shellfish"),
                                            col("responsibility_lang_array.val.value")[9].alias("animal_welfare")
                                            )
                                    .drop("responsibility_lang_array")
                                    .drop("responsibilityLang")
                                    .drop("organicCertifications")
                        )

    responsibility = (responsibility_master.drop("responsibility_lang")
                                    .drop("type_of_organic_product")
                                    .drop("soy_responsibility")
                                    .drop("palm_oil_responsibility")
                                    .drop("preservation_type")
                                    .drop("post_harvest_treatment_chemical")
                                    .drop("sup_category_product")
                                    .drop("sup_category_packaging")
                                    .drop("wild_caught_or_farmed_fish_and_shellfish")
                                    .drop("animal_welfare")
                                    .dropDuplicates())

    return responsibility, responsibility_master
