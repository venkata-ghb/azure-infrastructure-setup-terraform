from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_packaging_markings(df, cols):

    packaging_schema = StructType([
        StructField("sapid", StringType(), True),
        StructField("ean", StringType(), True),
        StructField("LoadDateTime", StringType(), True),
        StructField("articleid", StringType(), True),
        StructField("packagingMarkedLabelAccreditation", StringType(), True),
        StructField("packagingmarkedlabelaccreditationcode", StringType(), True),
        StructField("tradeitemdateonpackagingtypecode", StringType(), True),
        StructField("tradeItemDateOnPackagingType", StringType(), True),
        StructField("packagingMarkedLanguageCode", StringType(), True),
        StructField("packagingMarkedLanguage", StringType(), True),
        StructField("hasBatchNumber", StringType(), True),
        StructField("isPackagingMarkedReturnable", StringType(), True),
        StructField("isPriceOnPack", StringType(), True),
        StructField("pm_lang", StringType(), True),
        StructField("packaging_marked_label_accreditation", StringType(), True),
        StructField("packaging_marked_language", StringType(), True),
        StructField("trade_item_date_on_packaging_type", StringType(), True)
    ])
    if 'packaging' not in cols:
        packaging_markings_master = spark.createDataFrame([], packaging_schema)
        
    if df.select("articles.sapid", explode("articles.packaging.packagingMarkings")).count() != 0:

        packaging_markings_master = (df.select("articles.sapid",
                                    "articles.basicdata.ean",
                                    col("articles.basicData.lastModified").alias("LoadDateTime"),
                                    "articles.articleid",
                                    explode(col("articles.packaging.packagingMarkings")).alias("pm_array")
                                    )
                                    .select("*",
                                            "pm_array.packagingMarkedLabelAccreditation",
                                            "pm_array.packagingmarkedlabelaccreditationcode",
                                            explode(col("pm_array.packagingMarkedLabelAccreditationLang")).alias("pm_lang_array"),
                                            "pm_array.tradeitemdateonpackagingtypecode",
                                            "pm_array.tradeItemDateOnPackagingType",
                                            "pm_array.packagingMarkedLanguageCode",
                                            "pm_array.packagingMarkedLanguage",
                                            "pm_array.hasBatchNumber",
                                            "pm_array.isPackagingMarkedReturnable",
                                            "pm_array.isPriceOnPack"
                                            )
                                    .select("*",
                                            col("pm_lang_array.lang").alias("pm_lang"),
                                            col("pm_lang_array.val.value")[0].alias("packaging_marked_label_accreditation"),
                                            col("pm_lang_array.val.value")[1].alias("packaging_marked_language"),
                                            col("pm_lang_array.val.value")[2].alias("trade_item_date_on_packaging_type"))
                                    .drop("pm_array")
                                    .drop("pm_lang_array")
                                    )
    else:
        packaging_markings_master = spark.createDataFrame([], packaging_schema)
    
    packaging_markings = (packaging_markings_master.drop("pm_lang")
                        .drop("packaging_marked_label_accreditation")
                        .drop("packaging_marked_language")
                        .drop("trade_item_date_on_packaging_type")
                    ).dropDuplicates()

    return packaging_markings, packaging_markings_master
