from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_organic_certifications(df, cols):
    organic_certifications_schema = StructType([
        StructField("sapid", StringType(), True),
        StructField("ean", StringType(), True),
        StructField("LoadDateTime", StringType(), True),
        StructField("articleid", StringType(), True),
        StructField("organiccertificationidentification", StringType(), True),
        StructField("organiccertificationeffectiveenddatetime", StringType(), True),
        StructField("organiccertificationeffectivestartdatetime", StringType(), True),
        StructField("organicclaimagencyname", StringType(), True)
    ])

    if 'responsibility' not in cols:
        organic_certifications = spark.createDataFrame([], organic_certifications_schema)
    else:
        if df.select("articles.sapid", explode("articles.responsibility.organicCertifications")).count() != 0:
            organic_certifications = (df.select("articles.sapid",
                                                "articles.basicdata.ean",
                                                col("articles.basicData.lastModified").alias("LoadDateTime"),
                                                col("articles.articleid").alias("articleid"),
                                                explode("articles.responsibility.organicCertifications").alias("organic_certs_array"))
                                            .select("*",
                                                col("organic_certs_array.organiccertificationidentification"),
                                                col("organic_certs_array.organiccertificationeffectiveenddatetime"),
                                                col("organic_certs_array.organiccertificationeffectivestartdatetime"),
                                                col("organic_certs_array.organicclaimagencyname"))
                                            .drop("organic_certs_array")
                                            .dropDuplicates()
                                            )
        else:
            organic_certifications = spark.createDataFrame([], organic_certifications_schema)
    return organic_certifications
