from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_product_provenance_statement(df,cols):
        provenance_statement_schema = StructType([
                StructField("sapid", StringType(), True),
                StructField("ean", StringType(), True),
                StructField("LoadDateTime", StringType(), True),
                StructField("articleid", StringType(), True),
                StructField("languageID", StringType(), nullable=True),            
                StructField("product_provenance_statement", StringType(), True)
        ])

        if df.select("articles.sapid", explode("articles.productactivity")).count() != 0:
                provenance_statement_master = (df.select("articles.sapid",
                                        "articles.basicdata.ean",
                                        col("articles.basicData.lastModified").alias("LoadDateTime"),
                                        col("articles.articleid").alias("articleid"),
                                        explode(col("articles.productactivity")).alias("product_activity_array"))
                                        )
                if "productActivityCode" not in provenance_statement_master.select("*", "product_activity_array.*").columns:
                        provenance_statement_master = spark.createDataFrame([], provenance_statement_schema)


                else:

                        provenance_statement_master = (provenance_statement_master.select("*",
                                                                        explode(col("product_activity_array.productactivityprovenancestatementlang")).alias("pa_prov_lang_array"))
                                                                        .select("*",
                                                                                col("pa_prov_lang_array.lang").alias("languageID"),
                                                                                col("pa_prov_lang_array.val.value")[0].alias("product_provenance_statement")
                                                                        )
                                                                        .drop("pa_prov_lang_array")
                                                                        .drop("product_activity_array"))
        else:
                provenance_statement_master = spark.createDataFrame([], provenance_statement_schema)

        return provenance_statement_master