from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_ingredients_rawmaterial(df,cols):
        if df.select("articles.sapid", explode("articles.ingredients.rawMaterial").alias("ingredients_rawmaterial_array")).count() != 0:

                ingredients_rawmaterial = (df.select("articles.sapid",
                                        "articles.basicdata.ean",
                                        col("articles.basicData.lastModified").alias("LoadDateTime"),
                                        "articles.articleid",
                                        explode("articles.ingredients.rawMaterial").alias("ingredients_rawmaterial_array")
                                        )
                                        .select("*",
                                                col("ingredients_rawmaterial_array.rawMaterialUsedInPreparationWeight").alias("rawmaterial_used_in_preparation_weight"),
                                                col("ingredients_rawmaterial_array.rawMaterialUsedInPreparationWeightUOMCode").alias("rawmaterial_used_in_preparation_weight_uom_code"),
                                                explode("ingredients_rawmaterial_array.rawMaterialLang").alias("ingredients_rawmaterial_lang_array"))
                                        .select("*",
                                                "ingredients_rawmaterial_lang_array.lang",
                                                explode("ingredients_rawmaterial_lang_array.val").alias("ingredients_rawmaterial_val_array")
                                        )
                                        .select("*",
                                                "ingredients_rawmaterial_val_array.description",
                                                "ingredients_rawmaterial_val_array.value")
                                        .drop("ingredients_rawmaterial_array")
                                        .drop("ingredients_rawmaterial_lang_array")
                                        .drop("ingredients_rawmaterial_val_array")
                                        )

                ir_master = (ingredients_rawmaterial.groupby("sapid",
                                                        "ean",
                                                        "LoadDateTime",
                                                        "articleid",
                                                        "rawmaterial_used_in_preparation_weight",
                                                        "rawmaterial_used_in_preparation_weight_uom_code",
                                                        "lang"
                                                        ).pivot("description").agg({"value": "first"})
                        )
        else: 
                ir_schema = StructType([
                        StructField("sapid",StringType(),True),
                        StructField("ean",StringType(),True),
                        StructField("LoadDateTime",StringType(),True),
                        StructField("articleid",StringType(),True),
                        StructField("rawmaterial_used_in_preparation_weight",StringType(),True),
                        StructField("rawmaterial_used_in_preparation_weight_uom_code",StringType(),True),
                        StructField("lang",StringType(),True),
                        StructField("rawMaterialUsedInPreparationWeightUOM",StringType(),True)
                        ])
                ir_master = spark.createDataFrame([],  ir_schema)

        ir_drop = (ir_master.drop("rawMaterialUsedInPreparationWeightUOM")
                                .drop("lang")
                                ).dropDuplicates()
        return ir_drop, ir_master