from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_nutritional_information(df, cols):
    gn_schema = StructType([
                StructField("ean", StringType(), False),
                StructField("LoadDateTime", StringType(), False),
                StructField("articleid", StringType(), False),
                StructField("nutrientBasisQuantityDescription", ArrayType(StructType([
                    StructField("element", StringType(), False),
                    StructField("dailyValueIntakeReference", StringType(), False),
                    StructField("language", StringType(), False)
                ])), True),
                StructField("nutritionalClaims", ArrayType(StringType()), True),
                StructField("nutritionalExtra", ArrayType(StructType([
                    StructField("element", StringType(), False),
                    StructField("claimDescription", StringType(), False),
                    StructField("language", StringType(), False),
                    StructField("nutritionalClaim", StringType(), False)
                ])), True),
                StructField("eggsFreeGlobal", StringType(), True),
                StructField("glutenFreeGlobal", StringType(), True),
                StructField("lactoseFreeGlobal", StringType(), True),
                StructField("milkFreeGlobal", StringType(), True),
                StructField("veganFreeGlobal", StringType(), True)
                ])
    if 'nutritionalinformation' in cols:
        global_nutrients = (df.select("articles.sapid",
                                "articles.basicdata.ean",
                                col("articles.basicData.lastModified").alias("LoadDateTime"),
                                col("articles.articleid").alias("articleid"),
                                "articles.nutritionalInformation.globalNutrients",
                                "articles.nutritionalInformation.nutrientBasisQuantityDescription",
                                "articles.nutritionalInformation.nutritionalClaims",
                                "articles.nutritionalInformation.nutritionalExtra",
                                "articles.nutritionalInformation.nutritionalInformation"
                                )
                        .select("*", explode("globalNutrients").alias("global_nutrients_array"))
                        .select("*",
                                "global_nutrients_array.eggsFreeGlobal",
                                "global_nutrients_array.glutenFreeGlobal",
                                "global_nutrients_array.lactoseFreeGlobal",
                                "global_nutrients_array.milkFreeGlobal",
                                "global_nutrients_array.veganFreeGlobal")
                        .drop("globalNutrients")
                        .drop("global_nutrients_array"))
        
    else:
        global_nutrients = spark.createDataFrame([], gn_schema)
        
    if global_nutrients.select("*", explode("nutritionalInformation").alias("nutritional_information_array")).count() != 0:
        nutritional_information_master = (global_nutrients.select("sapid",
                                                                    "ean",
                                                                    "articleid",
                                                                    "LoadDateTime",
                                                                    explode("nutritionalInformation").alias("nutritional_information_array"))
                                                            .select("*",
                                                                "nutritional_information_array.dailyValueIntakePercent",
                                                                "nutritional_information_array.measurementPrecisionCode",
                                                                "nutritional_information_array.nutrientBasisQuantity",
                                                                "nutritional_information_array.nutrientBasisActual",
                                                                "nutritional_information_array.nutrientBasisQuantityUOMCode",
                                                                "nutritional_information_array.nutrientSequence",
                                                                "nutritional_information_array.nutrientType",
                                                                "nutritional_information_array.nutrientTypeCode",
                                                                "nutritional_information_array.nutrientTypeLang",
                                                                "nutritional_information_array.preparationStateCode",
                                                                "nutritional_information_array.quantityContained",
                                                                "nutritional_information_array.quantityContainedUOMCode",
                                                                "nutritional_information_array.quantityContainedUOMCodeDescription"
                                                                )
                                                            .drop("nutritionalInformation")
                                                            .drop("nutritional_information_array")
                                                            .drop("nutritionalExtra")
                                                            .drop("nutrientBasisQuantityDescription")
                                                            .select("*", explode("nutrientTypeLang").alias("nutrient_type_array"))
                                                            .select("*",
                                                                    col("nutrient_type_array.lang").alias("nutrient_type_language"),
                                                                    explode("nutrient_type_array.val").alias("nutrient_type_values"))
                                                            .select("*", 
                                                                    col("nutrient_type_values.description").alias("nutrient_type_description"),
                                                                    col("nutrient_type_values.value").alias("nutrient_type_value"))
                                                            .drop("nutrient_type_array")
                                                            .drop("nutrient_type_values")
                                                            .drop("nutrientType")
                                                            )
        ni_master = (nutritional_information_master.groupby('sapid',
                                            'ean',
                                            'LoadDateTime',
                                            'articleid',
                                            'dailyValueIntakePercent',
                                            'measurementPrecisionCode',
                                            'nutrientBasisQuantity',
                                            'nutrientBasisActual',
                                            'nutrientBasisQuantityUOMCode',
                                            'nutrientSequence',
                                            'nutrientTypeCode',
                                            'preparationStateCode',
                                            'quantityContained',
                                            'quantityContainedUOMCode',
                                            'quantityContainedUOMCodeDescription',
                                            'nutrient_type_language')
                                    .pivot("nutrient_type_description").agg({"nutrient_type_value": "first"})
                                )
    else:
        nutritional_information_schema = StructType([StructField('sapid', StringType(), True),
                                            StructField('ean', StringType(), True),
                                            StructField("articleid", StringType(), False),
                                            StructField('dailyValueIntakePercent', StringType(), True),
                                            StructField('measurementPrecisionCode', StringType(), True),
                                            StructField('nutrientBasisQuantity', StringType(), True),
                                            StructField('nutrientBasisActual', StringType(), True),
                                            StructField('nutrientBasisQuantityUOMCode', StringType(), True),
                                            StructField('nutrientSequence', StringType(),True),
                                            StructField('nutrientTypeCode', StringType(), True),
                                            StructField('preparationStateCode', StringType(), True),
                                            StructField('quantityContained', StringType(), True),
                                            StructField('quantityContainedUOMCode', StringType(), True),
                                            StructField('quantityContainedUOMCodeDescription', StringType(), True),
                                            StructField('nutrient_type_language', StringType(), True),
                                            StructField('nutrientType', StringType(), True),
                                            StructField('nutritional_information', StringType(), True),
                                            StructField('LoadDateTime', StringType(), True),
                                            StructField('preparationState', StringType(), True),
                                            StructField('measurementPrecision', StringType(), True),
                                            StructField('nutrientBasisQuantityUOM', StringType(), True),
                                            StructField('quantityContainedUOM', StringType(), True)])
        ni_master = spark.createDataFrame([], nutritional_information_schema)

    nutritional_information = (ni_master.select("sapid",
                                                "ean",
                                                "articleid",
                                                "dailyValueIntakePercent",
                                                "measurementPrecisionCode",
                                                "nutrientBasisQuantity",
                                                "nutrientBasisActual",
                                                "nutrientBasisQuantityUOMCode",
                                                "nutrientSequence",
                                                "nutrientTypeCode",
                                                "preparationStateCode",
                                                "quantityContained",
                                                "quantityContainedUOMCode",
                                                "quantityContainedUOMCodeDescription",
                                                "LoadDateTime")                                           
                            ).dropDuplicates()
    return nutritional_information, ni_master
