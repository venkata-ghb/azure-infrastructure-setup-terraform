from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *


def parse_product_ingredient_details_actions(df, cols):

    pid_master_schema = StructType([
    StructField("sapid", StringType(), nullable=False),
    StructField("ean", StringType(), nullable=False),
    StructField("LoadDateTime", StringType(), nullable=False),
    StructField("articleid", StringType(), nullable=False),
    StructField("ingredientCountryOfActivityCode", StringType(), nullable=False),
    StructField("ingredientProductActivityTypeCode", StringType(), nullable=False),
    StructField("sequence", StringType(), nullable=False),
    StructField("lang", StringType(), nullable=False),
    StructField("ingredientProductActivityType", StringType(), nullable=False),
    StructField("ingredientCountryOfActivity", StringType(), nullable=False),
    StructField("ingredient_detail", StringType(), nullable=False)
    ])

    sub_tables = [
        "rearing",
        "assembly",
        "milking",
        "bottling",
        "catchzone",
        "birth",
        "slaughter",
        "importation",
        "lastprocessing",
        "farming",
        "cutter",
        "huntedgathered",
    ]

    master_dfs = {}
    publish_dfs = {}

    for table in sub_tables:
        if df.select("articles.sapid", explode("articles.ingredients.ingredient")).count() != 0:
            pid_nested_master = (
                df.select(
                    "articles.sapid",
                    "articles.basicdata.ean",
                    col("articles.basicData.lastModified").alias("LoadDateTime"),
                    col("articles.articleid").alias("articleid"),
                    explode("articles.ingredients.ingredient").alias("ingredient_array"),
                )
                .select("*", explode(f"ingredient_array.{table}").alias("ingredient_action_array"))
                .select(
                    "*",
                    col("ingredient_action_array.ingredientCountryOfActivity").alias(
                        "ingredientCountryOfActivityName"
                    ),
                    "ingredient_action_array.ingredientCountryOfActivityCode",
                    col("ingredient_action_array.ingredientProductActivityType").alias(
                        "ingredientProductActivityTypeName"
                    ),
                    "ingredient_action_array.ingredientProductActivityTypeCode",
                    "ingredient_action_array.sequence",
                    explode("ingredient_action_array.ingredientProductActivityLang").alias(
                        "ipa_lang_array"
                    ),
                )
                .select(
                    "*",
                    "ipa_lang_array.lang",
                    col("ipa_lang_array.val")[0]["value"].alias(
                        "ingredientProductActivityType"
                    ),
                    col("ipa_lang_array.val")[1]["value"].alias(
                        "ingredientCountryOfActivity"
                    ),
                )
                .drop("ingredient_array")
                .drop("ingredient_action_array")
                .drop("ipa_lang_array")
                #.withColumn("ingredient_detail", lit(table))
                .dropDuplicates()
            )

            pid_nested = pid_nested_master.select(
                "sapid",
                "ean",
                "LoadDateTime",
                "articleid",
                "ingredientCountryOfActivityCode",
                "ingredientProductActivityTypeCode",
                "sequence",
                #"ingredient_detail",
            )
            master_dfs[table] = pid_nested_master
            publish_dfs[table] = pid_nested
        else:
            master_df = spark.createDataFrame([], pid_master_schema)
            publish_df = master_df.select("sapid",
                                        "ean",
                                        "LoadDateTime",
                                        "articleid",
                                        "ingredientCountryOfActivityCode",
                                        "ingredientProductActivityTypeCode",
                                        "sequence")
                                        #"ingredient_detail")
            return publish_df, master_df

    publish_df = None
    master_df = None
    for df_name, pid in master_dfs.items():
        if master_df is None:
            master_df = pid
        else:
            master_df = master_df.unionByName(pid, allowMissingColumns=False)
    master_df = master_df.dropDuplicates()

    for df_name, pid in publish_dfs.items():
        if publish_df is None:
            publish_df = pid
        else:
            publish_df = publish_df.unionByName(pid, allowMissingColumns=False)
    publish_df = publish_df.dropDuplicates()

    return publish_df, master_df