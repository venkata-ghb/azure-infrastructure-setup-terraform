from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_product_yield(df, cols):
    if df.select("articles.sapid", explode("articles.instructions.productyield")).count() != 0:

        product_yield_master = (df.select("articles.sapid",
                                "articles.basicdata.ean",
                                col("articles.basicData.lastModified").alias("LoadDateTime"),
                                "articles.articleid",
                                explode("articles.instructions.productyield").alias("productyield_array")
                                )
                        .select("*",
                                "productyield_array.productyieldtypecode",
                                "productyield_array.productyieldtype",
                                "productyield_array.preparationtypecode",
                                "productyield_array.preparationtype",
                                "productyield_array.productyield",
                                "productyield_array.productyielduom",
                                "productyield_array.productyieldvariationpercentage",
                                explode("productyield_array.productyieldlang").alias("productyield_lang_array")
                                )
                        .select("*",
                                col("productyield_lang_array.lang").alias("py_lang"),
                                col("productyield_lang_array.val.value")[0].alias("product_yield_type"),
                                col("productyield_lang_array.val.value")[1].alias("preparation_type"),
                                col("productyield_lang_array.val.value")[2].alias("product_yield_uom"))
                        .drop("productyield_array")
                        .drop("productyield_lang_array")
                        )
    else:
        py_schema = StructType([
        StructField("ean", StringType(), True),
        StructField("sapid", StringType(), True),
        StructField("LoadDateTime", StringType(), True),
        StructField("articleid", StringType(), True),
        StructField("productyieldtypecode", StringType(), True),
        StructField("productyieldtype", StringType(), True),
        StructField("preparationtypecode", StringType(), True),
        StructField("preparationtype", StringType(), True),
        StructField("productyield", StringType(), True),
        StructField("productyielduom", StringType(), True),
        StructField("productyieldvariationpercentage", StringType(), True),
        StructField("py_lang", StringType(), True),
        StructField("product_yield_type", StringType(), True),
        StructField("preparation_type", StringType(), True),
        StructField("product_yield_uom", StringType(), True)
        ])

        product_yield_master = spark.createDataFrame([], py_schema)

    product_yield = (product_yield_master.drop("py_lang")
                        .drop("product_yield_type")
                        .drop("preparation_type")
                        .drop("product_yield_uom")
                    ).dropDuplicates()
    return product_yield, product_yield_master
