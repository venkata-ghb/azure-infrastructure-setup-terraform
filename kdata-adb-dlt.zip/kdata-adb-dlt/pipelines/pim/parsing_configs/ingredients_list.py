from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_ingredients_list(df, cols):
  ingredients_list_schema = StructType([
      StructField("sapid", StringType(), False),
      StructField("ean", StringType(), False),
      StructField("LoadDateTime", StringType(), False),
      StructField("articleid", StringType(), False),
      StructField("lang", StringType(), False),
      StructField("ingredients", StringType(), False)
  ])

  if 'ingredients' not in cols:
    ingredients_list = spark.createDataFrame([], ingredients_list_schema)
  else:
    ingredients_list = (df.select("articles.sapid",
                              "articles.basicdata.ean",
                              col("articles.basicData.lastModified").alias("LoadDateTime"),
                              col("articles.articleid").alias("articleid"),
                              explode("articles.ingredients.ingredientList").alias("ingredient_list"))
                    .select("*", explode("ingredient_list.ingredientStatementLang").alias("ingredient_statement_array"))
                    .select("*", "ingredient_statement_array.lang", explode("ingredient_statement_array.val").alias("ingredient_statements"))
                    .select("*", col("ingredient_statements.value").alias("ingredients"))
                    .drop("ingredient_statements")
                    .drop("ingredient_statement_array")
                    .drop("ingredient_list")
                  ).dropDuplicates()
    return ingredients_list
