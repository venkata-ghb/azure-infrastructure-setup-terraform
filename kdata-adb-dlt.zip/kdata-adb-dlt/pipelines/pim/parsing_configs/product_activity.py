from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_product_activity(df, cols):
        product_activity_schema = StructType([
                StructField("sapid", StringType(), True),
                StructField("ean", StringType(), True),
                StructField("LoadDateTime", StringType(), True),
                StructField("articleid", StringType(), True),
                StructField("productactivitycode", StringType(), True),
                StructField("countryofactivitycode", StringType(), True),
                StructField("pa_lang", StringType(), True),
                StructField("product_activity", StringType(), True),
                StructField("country_of_activity", StringType(), True)
        ])

        if df.select("articles.sapid", explode("articles.productactivity")).count() != 0:
                product_activity_master = (df.select("articles.sapid",
                                        "articles.basicdata.ean",
                                        col("articles.basicData.lastModified").alias("LoadDateTime"),
                                        col("articles.articleid").alias("articleid"),
                                        explode(col("articles.productactivity")).alias("product_activity_array"))
                                        )
                if "productActivityCode" not in product_activity_master.select("*", "product_activity_array.*").columns:
                        product_activity_master = spark.createDataFrame([], product_activity_schema)
                else:
                        product_activity_master = (product_activity_master.select("*",
                                                                        col("product_activity_array.productactivitycode"),
                                                                        col("product_activity_array.countryofactivitycode"),
                                                                        explode(col("product_activity_array.productactivitydescriptionslang")).alias("pa_lang_array"))
                                                                        .select("*",
                                                                                col("pa_lang_array.lang").alias("pa_lang"),
                                                                                col("pa_lang_array.val.value")[0].alias("product_activity"),
                                                                                col("pa_lang_array.val.value")[1].alias("country_of_activity"),
                                                                        )
                                                                        .drop("pa_lang_array")
                                                                        .drop("product_activity_array"))
                
        else:
                product_activity_master = spark.createDataFrame([], product_activity_schema)


        product_activity = (product_activity_master.drop("pa_lang")
                                        .drop("product_activity")
                                        .drop("country_of_activity")
                                        .dropDuplicates()
                )
        return product_activity, product_activity_master
