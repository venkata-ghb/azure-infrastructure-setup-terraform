from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_certifications(df, cols):

  certification_schema = StructType([
    StructField("sapid", StringType(), True),
    StructField("ean", StringType(), True),
    StructField("LoadDateTime", StringType(), True),
    StructField("articleid", StringType(), True),
    StructField("certification", StringType(), True),
    StructField("certificationAgency", StringType(), True),
    StructField("certificationDate", StringType(), True),
    StructField("certificationIdentification", StringType(), True),
    StructField("certificationValue", StringType(), True),
    StructField("certificationEndDate", StringType(), True),
    StructField("certificationStartDate", StringType(), True)
  ])
  if df.select(col("articles.sapid"), explode("articles.certifications")).count() != 0:
    certifications = (df.select(col("articles.sapid").alias("sapid"), 
            col("articles.basicdata.ean").alias("ean"),
            col("articles.basicData.lastModified").alias("LoadDateTime"),
            col("articles.articleid").alias("articleid"),
            explode("articles.certifications").alias("certifications_array"))
            .select("*",
                    "certifications_array.certification",
                    "certifications_array.certificationAgency",
                    "certifications_array.certificationDate",
                    "certifications_array.certificationIdentification",
                    "certifications_array.certificationValue",
                    "certifications_array.certificationEndDate",
                    "certifications_array.certificationStartDate")
            .drop("certifications_array")
            .dropDuplicates()
          )
  else:
    certifications = spark.createDataFrame([], certification_schema)

  return certifications
