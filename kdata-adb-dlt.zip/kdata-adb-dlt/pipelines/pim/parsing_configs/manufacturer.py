from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_manufacturer(df, cols):
    manufacturer_schema = StructType([
        StructField("sapid", StringType(), True),
        StructField("ean", StringType(), True),
        StructField("LoadDateTime", StringType(), True),
        StructField("articleid", StringType(), True),
        StructField("commissionedBy", StringType(), True),
        StructField("manufacturer", StringType(), True),
        StructField("manufacturerDistric", StringType(), True),
        StructField("manufacturerGLN", StringType(), True)
        ])

    if 'manufacturer' not in cols:
        manufacturer = spark.createDataFrame([], manufacturer_schema)
    else:
        manufacturer = (df.select("articles.sapid",
                                    "articles.basicdata.ean",
                                    col("articles.basicData.lastModified").alias("LoadDateTime"),
                                    "articles.articleid",
                                    col("articles.manufacturer.commissionedBy"),
                                    col("articles.manufacturer.manufacturer"),
                                    col("articles.manufacturer.manufacturerDistric"),
                                    col("articles.manufacturer.manufacturerGLN")
                                )
                    ).dropDuplicates()
    return manufacturer
