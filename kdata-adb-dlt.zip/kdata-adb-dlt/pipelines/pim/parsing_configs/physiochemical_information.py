from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_physiochemical_information(df, cols):
    if df.select("articles.sapid", explode("articles.physiochemicalInformation")).count() != 0:
        physiochemical_information_master = (df.select("articles.sapid",
                                                    "articles.basicdata.ean",
                                                    col("articles.basicData.lastModified").alias("LoadDateTime"),
                                                    col("articles.articleid").alias("articleid"),
                                                    explode("articles.physiochemicalInformation").alias("pc_array"))
                                            .select("*",
                                                    col("pc_array.physiochemicalCharacteristicFeatureCode"),
                                                    col("pc_array.physiochemicalCharacteristicValue"),
                                                    col("pc_array.physiochemicalCharacteristicValueUOMCode"),
                                                    explode(col("pc_array.physiochemicalCharacteristicLang")).alias("pc_lang_array"))  
                                            .select("*",
                                                    col("pc_lang_array.lang").alias("pc_lang"),
                                                    col("pc_lang_array.val.value")[0].alias("physiochemicalcharasteristicfeature"),
                                                    col("pc_lang_array.val.value")[1].alias("physiochemicalcharasteristicvalueuom")
                                            )
                                            .drop("pc_array")
                                            .drop("pc_lang_array"))
    else:
        physiochemical_information_schema = StructType([
                                            StructField("sapid", StringType(), True),
                                            StructField("ean", StringType(), True),
                                            StructField("LoadDateTime", StringType(), True),
                                            StructField("articleid", StringType(), True),
                                            StructField("physiochemicalCharacteristicFeatureCode", StringType(), True),
                                            StructField("physiochemicalCharacteristicValue", StringType(), True),
                                            StructField("physiochemicalCharacteristicValueUOMCode", StringType(), True),
                                            StructField("pc_lang", StringType(), True),
                                            StructField("physiochemicalcharasteristicfeature", StringType(), True),
                                            StructField("physiochemicalcharasteristicvalueuom", StringType(), True)
                                            ])

        physiochemical_information_master = spark.createDataFrame([], physiochemical_information_schema)

    physiochemical_information = (physiochemical_information_master.drop("pc_lang")
                            .drop("physiochemicalcharasteristicfeature")
                            .drop("physiochemicalcharasteristicvalueuom")
                            .dropDuplicates())
    return physiochemical_information, physiochemical_information_master
