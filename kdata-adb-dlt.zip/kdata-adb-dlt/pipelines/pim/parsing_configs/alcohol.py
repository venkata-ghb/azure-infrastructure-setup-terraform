from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_alcohol(df,cols):
    if df.select("articles.sapid", explode("articles.alcohol")).count() != 0:
        a_master = (df.select("articles.sapid",
                                "articles.basicdata.ean",
                                col("articles.basicData.lastModified").alias("LoadDateTime"),
                                "articles.articleid",
                                explode("articles.alcohol").alias("alcohol_array")
                                )
                        .select("*",
                                "alcohol_array.subregion",
                                "alcohol_array.sugarcontent",
                                "alcohol_array.sugarcontentuomcode",
                                "alcohol_array.percentageofalcoholbyvolume",
                                "alcohol_array.degreeoforiginalwort",
                                "alcohol_array.vintner",
                                "alcohol_array.vintage",
                                "alcohol_array.alcoholbeveragetypecode",
                                "alcohol_array.alcoholicbeveragecolourcode",
                                "alcohol_array.sweetnesslevelofalcoholicbeveragecode",
                                "alcohol_array.originofwinecode",
                                "alcohol_array.alcoholicbeverageagecode",
                                "alcohol_array.alcoholicbeverageageuomcode",
                                "alcohol_array.acidityofwineingramsperlitre",
                                "alcohol_array.winebodycode",
                                "alcohol_array.tanninscode",
                                "alcohol_array.wineaciditycode",
                                explode("alcohol_array.alcohollang").alias("alcohol_lang_array"))
                        .select("*",
                                "alcohol_lang_array.lang",
                                explode("alcohol_lang_array.val").alias("alcohol_val_array"))
                        .select("*",
                                "alcohol_val_array.*")
                        .drop("alcohol_array")
                        .drop("alcohol_lang_array")
                        .drop("alcohol_val_array")
        )

        alcohol_master = a_master.groupby("sapid",
                                        "ean",
                                        "LoadDateTime",
                                        "articleid",
                                        "subregion",
                                        "sugarcontent",
                                        "sugarcontentuomcode",
                                        "percentageofalcoholbyvolume",
                                        "degreeoforiginalwort",
                                        "vintner",
                                        "vintage",
                                        "alcoholbeveragetypecode",
                                        "alcoholicbeveragecolourcode",
                                        "sweetnesslevelofalcoholicbeveragecode",
                                        "originofwinecode",
                                        "alcoholicbeverageagecode",
                                        "alcoholicbeverageageuomcode",
                                        "acidityofwineingramsperlitre",
                                        "winebodycode",
                                        "tanninscode",
                                        "wineaciditycode",
                                        "lang",
                                        ).pivot("description").agg({"value": "first"})
    else:
        alcohol_schema = StructType([
        StructField("sapid", StringType(), True),
        StructField("ean", StringType(), True),
        StructField("LoadDateTime", StringType(), True),
        StructField("articleid", StringType(), True),
        StructField("subregion", StringType(), True),
        StructField("sugarcontent", StringType(), True),
        StructField("sugarcontentuomcode", StringType(), True),
        StructField("percentageofalcoholbyvolume", StringType(), True),
        StructField("degreeoforiginalwort", StringType(), True),
        StructField("vintner", StringType(), True),
        StructField("vintage", StringType(), True),
        StructField("alcoholbeveragetypecode", StringType(), True),
        StructField("alcoholicbeveragecolourcode", StringType(), True),
        StructField("sweetnesslevelofalcoholicbeveragecode", StringType(), True),
        StructField("originofwinecode", StringType(), True),
        StructField("alcoholicbeverageagecode", StringType(), True),
        StructField("alcoholicbeverageageuomcode", StringType(), True),
        StructField("acidityofwineingramsperlitre", StringType(), True),
        StructField("lang", StringType(), True),
        StructField("alcoholBeverageType", StringType(), True),
        StructField("alcoholicBeverageAge", StringType(), True),
        StructField("alcoholicBeverageAgeUOM", StringType(), True),
        StructField("alcoholicBeverageColour", StringType(), True),
        StructField("originOfWine", StringType(), True),
        StructField("sugarContentUOM", StringType(), True),
        StructField("sweetnessLevelOfAlcoholicBeverage", StringType(), True),
        StructField("winebodycode", StringType(), True),
        StructField("tanninscode", StringType(), True),
        StructField("wineaciditycode", StringType(), True),
        StructField("winebody", StringType(), True),
        StructField("tannins", StringType(), True),
        StructField("wineacidity", StringType(), True)
        ])
        alcohol_master = spark.createDataFrame([], alcohol_schema)

    alcohol = (alcohol_master.select("sapid",
                            "ean",
                            "LoadDateTime",
                            "articleid",
                            "subregion",
                            "sugarcontent",
                            "sugarcontentuomcode",
                            "percentageofalcoholbyvolume",
                            "degreeoforiginalwort",
                            "vintner",
                            "vintage",
                            "alcoholbeveragetypecode",
                            "alcoholicbeveragecolourcode",
                            "sweetnesslevelofalcoholicbeveragecode",
                            "originofwinecode",
                            "alcoholicbeverageagecode",
                            "alcoholicbeverageageuomcode",
                            "acidityofwineingramsperlitre",
                            "winebodycode",
                            "tanninscode",
                            "wineaciditycode")
    ).dropDuplicates()
    return alcohol, alcohol_master
