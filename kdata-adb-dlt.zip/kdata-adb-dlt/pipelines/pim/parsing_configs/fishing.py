from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_fishing(df, cols):
    if df.select("articles.sapid", explode("articles.fishing").alias("fishing_array")).count() != 0:

        fishing_master = (df.select("articles.sapid",
                                "articles.basicdata.ean",
                                col("articles.basicData.lastModified").alias("LoadDateTime"),
                                "articles.articleid",
                                explode("articles.fishing").alias("fishing_array")
                                )
                        .select("*",
                                col("fishing_array.speciesforfisherystatisticspurposesname").alias("speciesforfisherystatisticspurposesmainname"),
                                "fishing_array.speciesforfisherystatisticspurposescode",
                                col("fishing_array.speciesforfisherystatisticspurposes").alias("speciesforfisherystatisticspurposesvalue"),
                                "fishing_array.catchmethodcode",
                                col("fishing_array.catchmethod").alias("catchmethodname"),
                                "fishing_array.catchareacode",
                                col("fishing_array.catcharea").alias("catchareaname"),
                                "fishing_array.catchcountrycode",
                                "fishing_array.productionmethodforfishandseafoodcode",
                                col("fishing_array.productionmethodforfishandseafood").alias("productionMethodForFishAndSeafoodname"),
                                "fishing_array.storagestatecode",
                                col("fishing_array.storagestate").alias("storagestatename"),
                                explode(col("fishing_array.fishinglang")).alias("fishing_lang_array")
                                )
                        .select("*",
                                "fishing_lang_array.lang",
                                explode("fishing_lang_array.val").alias("fishing_val_array"),
                                )
                        .select("*",
                                 "fishing_val_array.description",
                                 "fishing_val_array.value")
                        .drop("fishing_array")
                        .drop("fishing_lang_array")
                        .drop("fishing_val_array")
        )
        f_master = fishing_master.groupby("sapid",
                                        "ean",
                                        "LoadDateTime",
                                        "articleid",
                                        "speciesforfisherystatisticspurposesmainname",
                                        "speciesforfisherystatisticspurposescode",
                                        "speciesforfisherystatisticspurposesvalue",
                                        "catchmethodcode",
                                        "catchmethodname",
                                        "catchareacode",
                                        "catchareaname",
                                        "catchcountrycode",
                                        "productionmethodforfishandseafoodcode",
                                        "productionmethodforfishandseafoodname",
                                        "storagestatecode",
                                        "storagestatename",
                                        "lang").pivot("description").agg({"value": "first"})
    else: 
            fishing_schema = StructType([
            StructField("sapid", StringType(), True),
            StructField("ean", StringType(), True),
            StructField("LoadDateTime", StringType(), True),
            StructField("articleid", StringType(), True),
            StructField("speciesforfisherystatisticspurposesmainname", StringType(), True),
            StructField("speciesforfisherystatisticspurposescode", StringType(), True),
            StructField("speciesforfisherystatisticspurposesvalue", StringType(), True),
            StructField("catchmethodcode", StringType(), True),
            StructField("catchmethodname", StringType(), True),
            StructField("catchareacode", StringType(), True),
            StructField("catchareaname", StringType(), True),
            StructField("catchcountrycode", StringType(), True),
            StructField("productionmethodforfishandseafoodcode", StringType(), True),
            StructField("productionmethodforfishandseafoodname", StringType(), True),
            StructField("storagestatecode", StringType(), True),
            StructField("storagestatename", StringType(), True),
            StructField("lang", StringType(), True),
            StructField("catchArea", StringType(), True),
            StructField("catchCountry", StringType(), True),
            StructField("catchMethod", StringType(), True),
            StructField("productionMethodForFishAndSeafood", StringType(), True),
            StructField("speciesForFisheryStatisticsPurposes", StringType(), True),
            StructField("storageState", StringType(), True)
            ])

            f_master = spark.createDataFrame([], fishing_schema)

    fishing = (f_master.drop("lang")
                    .drop("catchCountry")
                    .drop("catchMethod")
                    .drop("productionMethodForFishAndSeafood")
                    .drop("speciesForFisheryStatisticsPurposes")
                    .drop("speciesForFisheryStatisticsPurposesName")
                    .drop("storageState")
                    .drop("catcharea")
                    .withColumnRenamed("speciesforfisherystatisticspurposesvalue", "speciesforfisherystatisticspurposes")
            ).dropDuplicates()
    
    return fishing, f_master
