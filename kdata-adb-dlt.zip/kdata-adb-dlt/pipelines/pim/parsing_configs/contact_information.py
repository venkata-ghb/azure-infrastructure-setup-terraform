from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_contact_information(df, cols):
    if df.select("articles.sapid", explode("articles.contactinformation")).count() != 0:
        contact_information_master = (df.select("articles.sapid",
                                                "articles.basicdata.ean",
                                                col("articles.basicData.lastModified").alias("LoadDateTime"),
                                                col("articles.articleid").alias("articleid"),
                                                explode(col("articles.contactinformation")).alias("contact_information_array"))
                                    .select("*",
                                            "contact_information_array.contactName",
                                            "contact_information_array.contactTypeCode",
                                            "contact_information_array.communicationValueWebsite",
                                            "contact_information_array.communicationValueTelephone",
                                            "contact_information_array.communicationValueSocialMedia",
                                            "contact_information_array.communicationValueEmail",
                                            "contact_information_array.communicationValueMobile",
                                            explode(col("contact_information_array.contactInfoLang")).alias("contact_info_lang_array"))
                                    .select("*",
                                            explode(col("contact_information_array.contactTypeLang")).alias("contact_type_lang_array"))
                                    .select("*",
                                            col("contact_info_lang_array.lang").alias("language"),
                                            col("contact_info_lang_array.val.value").alias("contact_info"),
                                            col("contact_type_lang_array.lang").alias("ct_lang"),
                                            col("contact_type_lang_array.val.value").alias("contact_type"))
                                    .drop("contact_information_array")
                                    .drop("contact_info_lang_array")
                                    .drop("contact_type_lang_array")
                                    .dropDuplicates()
                                    )

    else:
        contact_information_schema = StructType([
                StructField("sapid", StringType(), True),
                StructField("ean", StringType(), True),
                StructField("LoadDateTime", StringType(), True),
                StructField("articleid", StringType(), True),
                StructField("contactName", StringType(), True),
                StructField("contactTypeCode", StringType(), True),
                StructField("communicationValueWebsite", StringType(), True),
                StructField("communicationValueTelephone", StringType(), True),
                StructField("communicationValueSocialMedia", StringType(), True),
                StructField("communicationValueEmail", StringType(), True),
                StructField("communicationValueMobile", StringType(), True),
                StructField("language", StringType(), True),
                StructField("contact_info", StringType(), True),
                StructField("ct_lang", StringType(), True),
                StructField("contact_type", StringType(), True)
                ])

        contact_information_master = spark.createDataFrame([], contact_information_schema)

    contact_information = (contact_information_master.drop("ct_lang")
                                                    .drop("contact_type")
                                                    .dropDuplicates())
    return contact_information, contact_information_master
