from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_preparation_instructions(df, cols):
        if df.select("articles.sapid", explode("articles.instructions.preparationinstructions")).count() != 0:
                preparation_instructions = (df.select("articles.sapid",
                                        "articles.basicdata.ean",
                                        col("articles.basicData.lastModified").alias("LoadDateTime"),
                                        "articles.articleid",
                                        explode("articles.instructions.preparationinstructions").alias("preparationinstructions_array")
                                        )
                                .select("*",
                                        "preparationinstructions_array.preparationtype",
                                        "preparationinstructions_array.preparationtypecode",
                                        "preparationinstructions_array.minoptimumconsumptiontemperature",
                                        "preparationinstructions_array.minoptimumconsumptiontemperatureuom",
                                        "preparationinstructions_array.minoptimumconsumptiontemperatureuomcode",
                                        "preparationinstructions_array.maxoptimumconsumptiontemperature",
                                        "preparationinstructions_array.maxoptimumconsumptiontemperatureuom",
                                        "preparationinstructions_array.maxoptimumconsumptiontemperatureuomcode",
                                        explode("preparationinstructions_array.preparationInstructionsLang").alias("preparationinstrcutions_lang_array")
                                        )
                                .select("*",
                                        col("preparationinstrcutions_lang_array.lang").alias("language"),
                                        col("preparationinstrcutions_lang_array.val.value")[0].alias("preparation_instructions"),
                                        col("preparationinstrcutions_lang_array.val.value")[1].alias("serving_suggestion"))
                                .drop("preparationinstructions_array")
                                .drop("preparationinstrcutions_lang_array")
                                .dropDuplicates()
                                )
        else:
                prep_schema = StructType([
                        StructField("sapid", StringType(), True),
                        StructField("ean", StringType(), True),
                        StructField("LoadDateTime", StringType(), True),
                        StructField("articleid", StringType(), True),
                        StructField("preparationtype", StringType(), True),
                        StructField("preparationtypecode", StringType(), True),
                        StructField("minoptimumconsumptiontemperature", StringType(), True),
                        StructField("minoptimumconsumptiontemperatureuom", StringType(), True),
                        StructField("minoptimumconsumptiontemperatureuomcode", StringType(), True),
                        StructField("maxoptimumconsumptiontemperature", StringType(), True),
                        StructField("maxoptimumconsumptiontemperatureuom", StringType(), True),
                        StructField("maxoptimumconsumptiontemperatureuomcode", StringType(), True),
                        StructField("language", StringType(), True),
                        StructField("preparation_instructions", StringType(), True),
                        StructField("serving_suggestion", StringType(), True)
                ])
                preparation_instructions = spark.createDataFrame([], prep_schema)
        
        return preparation_instructions
