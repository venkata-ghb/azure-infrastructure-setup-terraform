from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_hazards_statements(df, cols):
    if df.select("articles.sapid", explode("articles.hazardstatements").alias("hazardstatement_array")).count() != 0:

        hazards_statements = (df.select("articles.sapid",
                                        "articles.basicdata.ean",
                                        col("articles.basicData.lastModified").alias("LoadDateTime"),
                                        "articles.articleid",
                                        explode("articles.hazardstatements").alias("hazardstatement_array"))
                                .select("*",
                                        "hazardstatement_array.hazardStatementCode",
                                        explode("hazardstatement_array.hazardStatementAdditionalInfosLang").alias("hazard_additional_info_array")
                                )
                                .select("*",
                                        "hazard_additional_info_array.hazardStatement",
                                        "hazard_additional_info_array.hazardStatementAdditionalInfo",
                                        "hazard_additional_info_array.language"
                                        )
                                .drop("hazardstatement_array")
                                .drop("hazard_additional_info_array")
                                .dropDuplicates()
                                )

    else:
            hazard_statements_schema = StructType([
            StructField("sapid", StringType(), True),
            StructField("ean", StringType(), True),
            StructField("articleid", StringType(), True),
            StructField("LoadDateTime", StringType(), True),
            StructField("hazardStatementCode", StringType(), True),
            StructField("hazardStatement", StringType(), True),
            StructField("hazardStatementAdditionalInfo", StringType(), True),
            StructField("language", StringType(), True)
            ])

            hazards_statements = spark.createDataFrame([], hazard_statements_schema)
    return hazards_statements
