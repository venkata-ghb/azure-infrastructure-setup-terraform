from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_product_ingredient_details(df,cols):
  pid_schema = StructType([
    StructField("sapid", StringType(), nullable=False),
    StructField("ean", StringType(), nullable=False),
    StructField("LoadDateTime", StringType(), nullable=False),
    StructField("articleid", StringType(), nullable=False),
    StructField("sequence", StringType(), nullable=False),
    StructField("contentpercentage", StringType(), nullable=False),
    StructField("preservationtechniquecode", StringType(), nullable=False),
    StructField("growingmethodcode", StringType(), nullable=False),
    StructField("grapevarietycode", StringType(), nullable=False),
    StructField("lang", StringType(), nullable=False),
    StructField("ingredientName", StringType(), nullable=False),
    StructField("preservationTechnique", StringType(), nullable=False),
    StructField("growingMethod", StringType(), nullable=False),
    StructField("grapeVariety", StringType(), nullable=False)
  ])

  if df.select("articles.sapid", explode("articles.ingredients.ingredient")).count() != 0:
    product_ingredient_details = (df.select("articles.sapid",
                                    "articles.basicdata.ean",
                                    col("articles.basicData.lastModified").alias("LoadDateTime"),
                                    col("articles.articleid").alias("articleid"),
                                    explode("articles.ingredients.ingredient").alias("ingredient_array")
                                    )
                                    .select("*",
                                            "ingredient_array.sequence",
                                            "ingredient_array.contentpercentage",
                                            "ingredient_array.preservationtechniquecode",
                                            "ingredient_array.growingmethodcode",
                                            "ingredient_array.grapevarietycode",
                                            explode("ingredient_array.ingredientlang").alias("ingredientlang_array")
                                    )
                                    .select("*",
                                            "ingredientlang_array.lang",
                                            col("ingredientlang_array.val")[0]["value"].alias("ingredientName"),
                                            col("ingredientlang_array.val")[1]["value"].alias("preservationTechnique"),
                                            col("ingredientlang_array.val")[2]["value"].alias("growingMethod"),
                                            col("ingredientlang_array.val")[3]["value"].alias("grapeVariety"),
                                            )
                                    .drop("ingredient_array")
                                    .drop("ingredientlang_array")
                                    .dropDuplicates()
                                    )
  else:
    product_ingredient_details = spark.createDataFrame([], pid_schema)

  return product_ingredient_details
