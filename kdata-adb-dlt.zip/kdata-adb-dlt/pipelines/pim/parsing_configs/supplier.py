from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_supplier(df, cols):
    supplier_schema = StructType([
        StructField("sapid", StringType(), True),
        StructField("ean", StringType(), True),
        StructField("LoadDateTime", StringType(), True),
        StructField("articleid", StringType(), True),
        StructField("mainSupplierSAPID", StringType(), True),
        StructField("supplierGLN", StringType(), True),
        StructField("supplierName", StringType(), True)
    ])
    if 'supplier' not in cols:
        supplier = spark.createDataFrame([], supplier_schema)
    else:
        supplier = df.select("articles.sapid",
                            "articles.basicdata.ean",
                            col("articles.basicData.lastModified").alias("LoadDateTime"),
                            col("articles.articleid").alias("articleid"),
                            "articles.supplier.*").dropDuplicates()
    return supplier
