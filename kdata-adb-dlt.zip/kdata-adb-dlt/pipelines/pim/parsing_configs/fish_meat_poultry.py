from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_fish_meat_poultry(df,cols):
        if df.select("articles.sapid", explode("articles.dairyFishMeatPoultry").alias("fmp_array")).count() != 0:

                fish_meat_poultry_master = (df.select("articles.sapid",
                                        "articles.basicdata.ean",
                                        col("articles.basicData.lastModified").alias("LoadDateTime"),
                                        "articles.articleid",
                                        explode("articles.dairyFishMeatPoultry").alias("fmp_array")
                                        )
                                        .select("*",
                                                "fmp_array.fishMeatPoultryTypeCode",
                                                col("fmp_array.fishMeatPoultryType").alias("fishMeatPoultryTypeName"),
                                                "fmp_array.minimumFishMeatPoultryContent",
                                                "fmp_array.minimumFishMeatPoultryContentUOMCode",
                                                explode("fmp_array.fishMeatPoultryLang").alias("fmp_lang_array"))
                                        .select("*",
                                                "fmp_lang_array.lang",
                                                explode("fmp_lang_array.val").alias("fmp_val_array")
                                        )
                                        .select("*",
                                                "fmp_val_array.description",
                                                "fmp_val_array.value")
                                        .drop("fmp_array")
                                        .drop("fmp_lang_array")
                                        .drop("fmp_val_array")
                                        )

                fmp_master = (fish_meat_poultry_master.groupby("sapid",
                                                        "ean",
                                                        "LoadDateTime",
                                                        "articleid",
                                                        "fishMeatPoultryTypeCode",
                                                        "fishMeatPoultryTypeName",
                                                        "minimumFishMeatPoultryContent",
                                                        "minimumFishMeatPoultryContentUOMCode",
                                                        "lang"
                                                        ).pivot("description").agg({"value": "first"})
                        )
        else: 
                fmp_schema = StructType([
                        StructField("sapid",StringType(),True),
                        StructField("ean",StringType(),True),
                        StructField("LoadDateTime",StringType(),True),
                        StructField("articleid",StringType(),True),
                        StructField("fishMeatPoultryTypeCode",StringType(),True),
                        StructField("fishMeatPoultryTypeName",StringType(),True),
                        StructField("minimumFishMeatPoultryContent",StringType(),True),
                        StructField("minimumFishMeatPoultryContentUOMCode",StringType(),True),
                        StructField("lang",StringType(),True),
                        StructField("fishMeatPoultryType",StringType(),True),
                        StructField("minimumFishMeatPoultryContentUOM",StringType(),True)
                        ])
                fmp_master = spark.createDataFrame([],  fmp_schema)

        fish_meat_poultry = (fmp_master.drop("minimumFishMeatPoultryContentUOM")
                                .drop("lang")
                                .drop("fishMeatPoultryType")
                                .withColumnRenamed("fishMeatPoultryTypeName", "fishMeatPoultryType")
                                ).dropDuplicates()
        return fish_meat_poultry, fmp_master
