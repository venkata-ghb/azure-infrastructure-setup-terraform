from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_additional_classification(df, cols):
    additional_classification_schema = StructType([
                                        StructField("sapid", StringType(), True),
                                        StructField("ean", StringType(), True),
                                        StructField("LoadDateTime", StringType(), True),
                                        StructField("articleid", StringType(), True),
                                        StructField("additionaltradeitemclassificationcodelistcode", StringType(), True),
                                        StructField("additionaltradeitemclassificationcodevalue", StringType(), True),
                                        StructField("cpvcode", StringType(), True),
                                        StructField("unspsccode", StringType(), True),
                                        StructField("eudirectivecode", StringType(), True),
                                        StructField("eumeddevicecode", StringType(), True),
                                        StructField("valviraclassificationcode", StringType(), True),
                                        StructField("valviraclassification", StringType(), True),
                                        StructField("valvirapackagingcode", StringType(), True),
                                        StructField("valvirapackaging", StringType(), True),
                                        StructField("valviraproductgroupcode", StringType(), True),
                                        StructField("valviraproductgroup", StringType(), True),
                                        StructField("valviralang", StringType(), True),
                                        StructField("valvira_classification", StringType(), True),
                                        StructField("valvira_packaging", StringType(), True),
                                        StructField("valvira_product_group", StringType(), True)
                                    ])

    if 'additionalclassification' not in cols:
        additional_classification_master = spark.createDataFrame([], additional_classification_schema)
    else:
        additional_classification_master = (df.select("articles.sapid",
                            "articles.basicdata.ean",
                            col("articles.basicData.lastModified").alias("LoadDateTime"),
                            col("articles.articleid").alias("articleid"),
                            col("articles.additionalclassification.additionaltradeitemclassificationcodelistcode"),
                            col("articles.additionalclassification.additionaltradeitemclassificationcodevalue"),
                            col("articles.additionalclassification.cpvcode"),
                            col("articles.additionalclassification.unspsccode"),
                            col("articles.additionalclassification.eudirectivecode"),
                            col("articles.additionalclassification.eumeddevicecode"),
                            col("articles.additionalclassification.valviraclassificationcode"),
                            col("articles.additionalclassification.valviraclassification"),
                            col("articles.additionalclassification.valvirapackagingcode"),
                            col("articles.additionalclassification.valvirapackaging"),
                            col("articles.additionalclassification.valviraproductgroupcode"),
                            col("articles.additionalclassification.valviraproductgroup"),
                            explode(col("articles.additionalclassification.valviralang")).alias("valvira_lang_array"))  
                    .select("*", 
                            col("valvira_lang_array.lang").alias("valviralang"),
                            col("valvira_lang_array.val.value")[0].alias("valvira_classification"),
                            col("valvira_lang_array.val.value")[1].alias("valvira_packaging"),
                            col("valvira_lang_array.val.value")[2].alias("valvira_product_group"),
                    )
                    .drop("valvira_lang_array")
            )

    additional_classification = (additional_classification_master.drop("valviralang")
                            .drop("valvira_classification")
                            .drop("valvira_packaging")
                            .drop("valvira_product_group")
                            .dropDuplicates()
    )
    return additional_classification, additional_classification_master
