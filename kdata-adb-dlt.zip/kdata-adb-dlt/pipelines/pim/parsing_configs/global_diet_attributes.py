from pyspark.sql.functions import explode, col
from pyspark.sql.types import StructType, StringType, BooleanType, StructField


def parse_global_diet_attributes(df, cols):
    global_nutrients_schema=StructType([
                StructField("sapid", StringType(), False),
                StructField("ean", StringType(), False),
                StructField("LoadDateTime", StringType(), False),
                StructField("articleid", StringType(), False),
                StructField("eggsFreeGlobal", BooleanType(), False),
                StructField("glutenFreeGlobal", BooleanType(), False),
                StructField("lactoseFreeGlobal", BooleanType(), False),
                StructField("milkFreeGlobal", BooleanType(), False),
                StructField("veganFreeGlobal", BooleanType(), False),
                StructField("alcoholFreeGlobal", BooleanType(), False),
                StructField("fatFreeGlobal", BooleanType(), False),
                StructField("lowFatGlobal", BooleanType(), False),
                StructField("saltFreeGlobal", BooleanType(), False),
                StructField("lowSaltFreeGlobal", BooleanType(), False),
                StructField("sugarFreeGlobal", BooleanType(), False),
                StructField("lowSugarGlobal", BooleanType(), False)
                ])

    if 'nutritionalinformation' in cols:
        global_nutrients = (df.select("articles.sapid",
                                "articles.basicdata.ean",
                                col("articles.basicData.lastModified").alias("LoadDateTime"),
                                col("articles.articleid").alias("articleid"),
                                "articles.nutritionalInformation.globalNutrients"
                                )
                        .select("*", explode("globalNutrients").alias("global_nutrients_array"))
                        .select("*",
                                "global_nutrients_array.eggsFreeGlobal",
                                "global_nutrients_array.glutenFreeGlobal",
                                "global_nutrients_array.lactoseFreeGlobal",
                                "global_nutrients_array.milkFreeGlobal",
                                "global_nutrients_array.veganFreeGlobal",
                                "global_nutrients_array.alcoholFreeGlobal",
                                "global_nutrients_array.fatFreeGlobal",
                                "global_nutrients_array.lowFatGlobal",
                                "global_nutrients_array.saltFreeGlobal",
                                "global_nutrients_array.lowSaltFreeGlobal",
                                "global_nutrients_array.sugarFreeGlobal",
                                "global_nutrients_array.lowSugarGlobal"
                                )
                        .drop("globalNutrients")
                        .drop("global_nutrients_array"))
    else:
        global_nutrients = spark.createDataFrame([], global_nutrients_schema)

    return global_nutrients



 