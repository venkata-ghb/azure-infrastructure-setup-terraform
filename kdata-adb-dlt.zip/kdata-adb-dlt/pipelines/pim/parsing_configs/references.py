from pyspark.sql.functions import col, explode_outer, explode, expr
from pyspark.sql.types import StructField, StringType, StructType #, ArrayType

def parse_references(df, cols):
    # Ingest schema, kept commented just in case
    # reference_ingest_schema = StructType([
    #         StructField("type", StringType(), True),
    #         StructField("referencedId", StringType(), True),
    #         StructField("referenceEan", StringType(), True),
    #         StructField("referenceEan", StringType(), True),
    #         StructField("quantity", StringType(), True),
    #         StructField("uom", StringType(), True),
    #         StructField("displayOrder", StringType(), True),
    #         StructField("referencedTradeItemTypeCode", StringType(), True),
    #         StructField("referencedTradeItemType", StringType(), True),
    #         StructField("referencedTradeItemGtin", StringType(), True),
    #         StructField("referencedLang", ArrayType(
    #             StructType([
    #                 StructField("lang", StringType(), True),
    #                 StructField("val", ArrayType(
    #                     StructType([
    #                         StructField("description", StringType(), True),
    #                         StructField("value", StringType(), True),
    #                     ])
    #                 ), True)
    #             ])
    #         ), True)
    #     ])
    # # Normalizes the articles.references array to fixed schema from the passed df
    # # Missing reference fields always exist as nullable columns. Downstream will filter/explode etc on this safely
    # df = df.withColumn(
    #         "articles",
    #         col("articles").withField(
    #             "references",
    #             col("articles.references").cast(ArrayType(reference_ingest_schema))
    #         )
    #     )

    # Output schema
    references_schema = StructType([
        StructField("sapid", StringType(), True),
        StructField("ean", StringType(), True),
        StructField("LoadDateTime", StringType(), True),
        StructField("articleid", StringType(), True),
        StructField("type", StringType(), True),
        StructField("referencedId", StringType(), True),
        StructField("referenceEan", StringType(), True),
        StructField("quantity", StringType(), True),
        StructField("uom", StringType(), True),
        StructField("displayOrder", StringType(), True),
        StructField("referencedTradeItemTypeCode", StringType(), True),
        StructField("referencedTradeItemType", StringType(), True),
        StructField("referencedTradeItemGtin", StringType(), True),
        StructField("referenced_trade_item_type", StringType(), True),
        StructField("references_lang", StringType(), True),
    ])

    # Check for missing data, espwecially completely missing columns (not empty or null) in src data
    # Just checking for referenceEan in addition should cover all other missing field cases, because referenceEan is always missing in the observed cases
    pass_data = False
    has_references = "references" in cols
    if has_references:
        ref_fields = {f.name for f in df.schema["articles"].dataType["references"].dataType.elementType.fields}
        has_referenceId = "referenceId" in ref_fields
        has_referenceEan = "referenceEan" in ref_fields
        # referenceId can exist as a lonely column in the src object, so we need to check for both
        pass_data = has_referenceId and has_referenceEan

    if not pass_data:
        # references = spark.createDataFrame([], references_schema)
        references = df.sparkSession.createDataFrame([], references_schema)
        references_master = references

    else:
        references_master = (
            df
            .withColumn(
                "ref_items", expr("filter(articles.references, x -> x.referencedId IS NOT NULL AND x.referencedId != '' and x.referencedTradeItemTypeCode IS NULL )"),
            )
            .withColumn(
                "trade_items", expr("filter(articles.references, x -> x.referencedTradeItemTypeCode IS NOT NULL and x.referencedId IS NULL)"),
            )
            .withColumn("trade_items_exploded", explode_outer("trade_items"))
            .withColumn("exploded", explode_outer("ref_items"))
        )
        references_master =  references_master.filter(col("exploded").isNotNull())
        references_master = (
            references_master.select(
                "articles.sapid",
                "articles.basicdata.ean",
                col("articles.basicData.lastModified").alias("LoadDateTime"),
                col("articles.articleid").alias("articleid"),
                col("exploded.type").alias("type"),
                col("exploded.referencedId").alias("referencedId"),
                col("exploded.referenceEan"),
                col("exploded.quantity").alias("quantity"),
                col("exploded.UOM").alias("UOM"),
                col("exploded.displayOrder").alias("displayOrder"),
                col("trade_items_exploded.referencedTradeItemTypeCode").alias(
                    "referencedTradeItemTypeCode"
                ),
                col("trade_items_exploded.referencedTradeItemType").alias(
                    "referencedTradeItemType"
                ),
                col("trade_items_exploded.referencedTradeItemGtin").alias(
                    "referencedTradeItemGtin"
                ),
                explode("trade_items_exploded.referencedLang").alias("reflang_array"),
            )
            .select(
                "*",
                col("reflang_array.lang").alias("references_lang"),
                explode("reflang_array.val").alias("reflang_lang_array"),
            )
            .select(
                "*",
                col("reflang_lang_array.value").alias("referenced_trade_item_type"),
            )
            .drop("reflang_array")
            .drop("reflang_lang_array")
            .dropDuplicates()
        )

    references = (
        references_master.drop("references_lang")
        .drop("referenced_trade_item_type")
        .dropDuplicates()
    )

    return references, references_master