from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_dairy_juice_dry_matter_content(df, cols):
    dairy_juice_dry_matter_content = (df.select("articles.sapid",
                              "articles.basicdata.ean",
                              col("articles.basicData.lastModified").alias("LoadDateTime"),
                              "articles.articleid",
                              explode("articles.contamination").alias("contamination_array")
                              )
                            .select("*",
                                    "contamination_array.fatInMilkContent",
                                    "contamination_array.fatPercentageInDryMatter",
                                    "contamination_array.fatPercentageInDryMatterMeasurementPrecisionCode",
                                    "contamination_array.isHomogenised",
                                    "contamination_array.juiceContentPercentage"
                            )
                            .drop("contamination_array")
                            ).dropDuplicates()
    return dairy_juice_dry_matter_content
