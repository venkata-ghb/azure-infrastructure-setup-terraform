from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_temperatures(df, cols):
  temperatures_schema = StructType([
    StructField("sapid", IntegerType(), False),
    StructField("ean", IntegerType(), False),
    StructField("LoadDateTime", StringType(), False),
    StructField("articleid", StringType(), False),
    StructField("tradeItemTemperatureConditionTypeCode", StringType(), False)
  ])

  if 'temperatures' not in cols:
    temperatures = spark.createDataFrame([], temperatures_schema)
  if df.select("articles.sapid", explode("articles.temperatures").alias("temps_array")).count() != 0:
    temperatures = (df.select(col("articles.sapid").alias("sapid"), 
		                          col("articles.basicdata.ean").alias("ean"),
		                          col("articles.basicData.lastModified").alias("LoadDateTime"),
		                          col("articles.articleid").alias("articleid"),
		                          explode("articles.temperatures").alias("temps_array"))
                      .select("*", "temps_array.tradeItemTemperatureConditionTypeCode")
	                    .drop("temps_array")
                      .dropDuplicates()
                    )
  else:
    temperatures= spark.createDataFrame([], temperatures_schema)

  return temperatures