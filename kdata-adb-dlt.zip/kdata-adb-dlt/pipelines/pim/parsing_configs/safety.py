from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_safety(df, cols):
        safety_schema = StructType([
                        StructField("sapid", StringType(), True),
                        StructField("ean", StringType(), True),
                        StructField("LoadDateTime", StringType(), True),
                        StructField("articleid", StringType(), True),
                        StructField("exactph", StringType(), True),
                        StructField("sdssheetnumber", StringType(), True),
                        StructField("issubstanceofveryhighconcern", StringType(), True),
                        StructField("istradeitemreachrelevant", StringType(), True),
                        StructField("ghssignalwordscode", StringType(), True),
                        StructField("ghssymboldescriptioncode", StringType(), True),
                        StructField("reachnumber", StringType(), True),
                        StructField("chemicalingredientscheme", StringType(), True),
                        StructField("chemicalingredientidentification", StringType(), True),
                        StructField("chemicalingredientconcentration", StringType(), True),
                        StructField("chemicalingredientconcentrationuomcode", StringType(), True),
                        StructField("ghsSignalWords", StringType(), True),
                        StructField("ghsSymbolDescription", StringType(), True),
                        StructField("lang", StringType(), True)
                        ])
        if 'safety' not in cols:
                s_master = spark.createDataFrame([], safety_schema)
        else:
                safety_master = (df.select("articles.sapid",
                                        "articles.basicdata.ean",
                                        col("articles.basicData.lastModified").alias("LoadDateTime"),
                                        "articles.articleid",
                                        "articles.safety.exactph",
                                        "articles.safety.sdssheetnumber",
                                        "articles.safety.issubstanceofveryhighconcern",
                                        "articles.safety.istradeitemreachrelevant",
                                        "articles.safety.ghssignalwordscode",
                                        col("articles.safety.ghssignalwords").alias("ghsSignalWordsName"),
                                        "articles.safety.ghssymboldescriptioncode",
                                        col("articles.safety.ghssymboldescription").alias("ghssymboldescriptionname"),
                                        "articles.safety.reachnumber",
                                        "articles.safety.chemicalingredientscheme",
                                        "articles.safety.chemicalingredientidentification",
                                        "articles.safety.chemicalingredientconcentration",
                                        "articles.safety.chemicalingredientconcentrationuomcode",
                                        explode("articles.safety.ghslang").alias("ghs_lang_array")
                                        )
                                .select("*",
                                        "ghs_lang_array.lang",
                                        explode("ghs_lang_array.val").alias("ghs_val_array")
                                )
                                .select("*",
                                        "ghs_val_array.description",
                                        "ghs_val_array.value")
                                .drop("ghs_lang_array")
                                .drop("ghs_val_array")
                                )

                s_master = safety_master.groupby("sapid",
                                                "ean",
                                                "LoadDateTime",
                                                "articleid",
                                                "exactph",
                                                "sdssheetnumber",
                                                "issubstanceofveryhighconcern",
                                                "istradeitemreachrelevant",
                                                "ghssignalwordscode",
                                                "ghssignalwordsname",
                                                "ghssymboldescriptioncode",
                                                "ghssymboldescriptionname",
                                                "reachnumber",
                                                "chemicalingredientscheme",
                                                "chemicalingredientidentification",
                                                "chemicalingredientconcentration",
                                                "chemicalingredientconcentrationuomcode",
                                                "lang").pivot("description").agg({"value": "first"})

        safety = (s_master.drop("lang")
                        .drop("chemicalIngredientConcentrationUOM")
                        .drop("ghsSignalWordsName")
                        .drop("ghsSignalWords")
                        .drop("ghsSymbolDescriptionName")
                        .drop("ghsSymbolDescription")
                ).dropDuplicates()

        return safety, s_master
