from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_consumer_instructions(df, cols):
    consumer_instructions_master = (df.select("articles.sapid",
                                        "articles.basicdata.ean",
                                        col("articles.basicData.lastModified").alias("LoadDateTime"),
                                        "articles.articleid",
                                        explode("articles.instructions.instructionsLang").alias("instructions_lang_array")
                                        )
                                        .select("*",
                                        "instructions_lang_array.lang",
                                        explode("instructions_lang_array.val").alias("instuctions_val_array")
                                        )
                                        .select("*",
                                        "instuctions_val_array.description",
                                        "instuctions_val_array.value",
                                        )
                                        .drop("instructions_lang_array")
                                        .drop("instuctions_val_array")
                                )
    consumer_instructions = consumer_instructions_master.groupby("sapid",
                                                    "ean",
                                                    "LoadDateTime",
                                                    "articleid",
                                                    "lang").pivot("description").agg({"value": "first"}).dropDuplicates()
    return consumer_instructions
