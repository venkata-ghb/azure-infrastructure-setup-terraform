from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_names_and_descriptions(df, cols):
    names_and_descriptions_master = (df.select("articles.sapid",
                                                "articles.basicdata.ean",
                                                col("articles.basicData.lastModified").alias("LoadDateTime"),
                                                col("articles.articleid").alias("articleid"),
                                                explode(col("articles.namesAndDescriptions")).alias("nad_array")
                                                ).select("*",
                                                        "nad_array.lang",
                                                        explode("nad_array.val").alias("nad_val_array"))
                                                .select("*",
                                                        "nad_val_array.description",
                                                        col("nad_val_array.value"))
                                                .drop("nad_array")
                                                .drop("nad_val_array")
                                                    )
    names_and_descriptions = (names_and_descriptions_master.groupby("sapid",
                                                                "ean",
                                                                "LoadDateTime",
                                                                "articleid",
                                                                "lang")
                                                                .pivot("description").agg({"value": "first"})
                                                            .select("sapid",
                                                                    "ean",
                                                                    "LoadDateTime",
                                                                    "articleid",
                                                                    "lang",
                                                                    "POSName",
                                                                    "bTobDescription",
                                                                    "descriptiveSize",
                                                                    "fullProductName",
                                                                    "functionalName",
                                                                    "keywords",
                                                                    "logisticalUnitName",
                                                                    "marketingName",
                                                                    "marketingText",
                                                                    "materialList",
                                                                    "productName",
                                                                    "regulatedProductName",
                                                                    "salesDescriptionLong",
                                                                    "salesDescriptionShort",
                                                                    "shelfLabelName",
                                                                    "shortMarketingText",
                                                                    "tradeItemFeatureBenefit",
                                                                    "tradeItemSustainabilityStatement",
                                                                    "variantDescription"
                                                                    )
                                ).dropDuplicates()
    return names_and_descriptions
