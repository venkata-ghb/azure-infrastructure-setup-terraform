from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_place_of_item_activity(df, cols):

  poia_schema = StructType([
    StructField("sapid", StringType(), True),
    StructField("ean", StringType(), True),
    StructField("LoadDateTime", StringType(), True),
    StructField("articleid", StringType(), True),
    StructField("importClassificationValue", StringType(), True),
    StructField("importClassificationTypeCode", StringType(), True),
    StructField("importClassificationType", StringType(), True),
    StructField("statisticalReportingMeasurement", StringType(), True),
    StructField("statisticalReportingMeasurementUnit", StringType(), True),
    StructField("statisticalReportingMeasurementUnitCode", StringType(), True),
    StructField("ImportClassificationIntrastat", StringType(), True)
  ])
  
  if df.select("articles.sapid", explode("articles.placeOfItemActivity")).count() != 0:
    place_of_item_activity = (df.select("articles.sapid",
                            "articles.basicdata.ean",
                            col("articles.basicData.lastModified").alias("LoadDateTime"),
                            col("articles.articleid").alias("articleid"),
                            explode("articles.placeOfItemActivity").alias("poia_array")
                            )
                            .select("*",
                                    "poia_array.importClassificationValue",
                                    "poia_array.importClassificationTypeCode",
                                    "poia_array.importClassificationType",
                                    "poia_array.statisticalReportingMeasurement",
                                    "poia_array.statisticalReportingMeasurementUnit",
                                    "poia_array.statisticalReportingMeasurementUnitCode",
                                    "poia_array.ImportClassificationIntrastat")
                              .drop("poia_array")
                              .dropDuplicates()
                              )
  else:
    place_of_item_activity = spark.createDataFrame([], poia_schema)

  return place_of_item_activity
