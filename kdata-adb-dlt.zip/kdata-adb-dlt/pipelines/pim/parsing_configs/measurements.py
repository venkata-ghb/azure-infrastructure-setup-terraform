from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_measurements(df, cols):
    measurements_schema = StructType([
        StructField("sapid", StringType(), False),
        StructField("ean", StringType(), False),
        StructField("LoadDateTime", StringType(), False),
        StructField("articleid", StringType(), False),
        StructField("volume", StringType(), True),
        StructField("height", StringType(), True),
        StructField("width", StringType(), True),
        StructField("length", StringType(), True),
        StructField("netcontent", StringType(), True),
        StructField("netweight", StringType(), True),
        StructField("grosscontent", StringType(), True),
        StructField("grossweight", StringType(), True),
        StructField("diameter", StringType(), True),
        StructField("averageweight", StringType(), True),
        StructField("compositionwidth", StringType(), True),
        StructField("compositiondepth", StringType(), True),
        StructField("dimensionuomcode", StringType(), True),
        StructField("weightuomcode", StringType(), True),
        StructField("averageweightuomcode", StringType(), True),
        StructField("contentuomcode", StringType(), True),
        StructField("diameteruomcode", StringType(), True),
        StructField("individualunitmax", StringType(), True),
        StructField("individualunitmin", StringType(), True),
        StructField("individualunitmaxuomcode", StringType(), True),
        StructField("drainedweight", StringType(), True),
        StructField("drainedweightuomcode", StringType(), True),
        StructField("drainedweightuomname", StringType(), True),
        StructField("dimension_lang", StringType(), True)
    ])

    if 'measurements' not in cols:
        measurements = spark.createDataFrame([], measurements_schema)
    else:

        measurements_master = (df.select("articles.sapid",
                                    "articles.basicdata.ean",
                                    col("articles.basicData.lastModified").alias("LoadDateTime"),
                                    col("articles.articleid").alias("articleid"),
                                    col("articles.measurements.volume"),
                                    col("articles.measurements.height"),
                                    col("articles.measurements.width"),
                                    col("articles.measurements.length"),
                                    col("articles.measurements.netcontent"),
                                    col("articles.measurements.netweight"),
                                    col("articles.measurements.grosscontent"),
                                    col("articles.measurements.grossweight"),
                                    col("articles.measurements.diameter"),
                                    col("articles.measurements.averageweight"),
                                    col("articles.measurements.compositionwidth"),
                                    col("articles.measurements.compositiondepth"),
                                    col("articles.measurements.dimensionuomcode"),
                                    col("articles.measurements.weightuomcode"),
                                    col("articles.measurements.averageweightuomcode"),
                                    col("articles.measurements.contentuomcode"),
                                    col("articles.measurements.diameteruomcode"),
                                    col("articles.measurements.individualunitmax"),
                                    col("articles.measurements.individualunitmin"),
                                    col("articles.measurements.individualunitmaxuomcode"),
                                    col("articles.measurements.individualunitminuomcode"),
                                    col("articles.measurements.drainedweight"),
                                    col("articles.measurements.drainedweightuom").alias("drainedweightuomname"),
                                    col("articles.measurements.drainedweightuomcode"),
                                    explode(col("articles.measurements.dimensionlang")).alias("dimension_lang_array")
                                    )
                                    .select("*",
                                            col("dimension_lang_array.lang").alias("dimension_lang"),
                                            col("dimension_lang_array.val.value")[0].alias("drainedweightuom")
                                            )
                                    .drop("dimension_lang_array")
                                    .dropDuplicates()
                                )
        
    measurements = measurements_master.drop("dimension_lang").drop("drainedweightuom").dropDuplicates()

    return measurements, measurements_master
