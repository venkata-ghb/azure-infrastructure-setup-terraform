from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_organism_classification(df, cols):
    organism_classification_schema = StructType([
        StructField("sapid", StringType(), True),
        StructField("ean", StringType(), True),
        StructField("LoadDateTime", StringType(), True),
        StructField("articleid", StringType(), True),
        StructField("genus", StringType(), True),
        StructField("species", StringType(), True),
    ])

    if df.select("articles.sapid", explode(col("articles.ingredients.materials")).alias("materials_array")).count() != 0:

        organism_classification = (df.select("articles.sapid",
                                "articles.basicdata.ean",
                                col("articles.basicData.lastModified").alias("LoadDateTime"),
                                col("articles.articleid").alias("articleid"),
                                explode("articles.organismClassification").alias("oc_array")
                                )
                        .select("*",
                                "oc_array.genus",
                                "oc_array.species"
                            )
                        .drop("oc_array")
                        .dropDuplicates()
                    )
            
    else:
        organism_classification = spark.createDataFrame([], organism_classification_schema)
    return organism_classification
