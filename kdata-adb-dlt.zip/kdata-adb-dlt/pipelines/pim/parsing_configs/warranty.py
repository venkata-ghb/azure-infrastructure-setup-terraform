from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_warranty(df, cols):
    warranty = (df.select("articles.sapid",
                              "articles.basicdata.ean",
                              col("articles.basicData.lastModified").alias("LoadDateTime"),
                              col("articles.articleid").alias("articleid"),
                              col("articles.warranty.warrantyperiod"),
                              col("articles.warranty.warrantyPeriodUOMCode"),
                              col("articles.warranty.warrantytype"),
                              explode(col("articles.warranty.warrantyLang")).alias("warranty_lang_array"))  
                      .select("*",
                              col("warranty_lang_array.lang").alias("warranty_lang"),
                              col("warranty_lang_array.val.value")[0].alias("warrantydescription"),
                              col("warranty_lang_array.val.value")[1].alias("warrantyperioduom"),
                      )
                      .drop("warranty_lang_array")
    )

    return warranty
