from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_additional_trade_item_description(df,cols):
    additional_trade_item_description = (df.select("articles.sapid",
                              "articles.basicdata.ean",
                              col("articles.basicData.lastModified").alias("LoadDateTime"),
                              "articles.articleid",
                              explode(col("articles.additionaltradeitemdescription")).alias("tid_array"))
                    .select("*",
                            "tid_array.lang",
                            col("tid_array.val.value")[0].alias("additionalTradeItemDescription"))
                    .drop("tid_array")
    ).dropDuplicates()
    return additional_trade_item_description
