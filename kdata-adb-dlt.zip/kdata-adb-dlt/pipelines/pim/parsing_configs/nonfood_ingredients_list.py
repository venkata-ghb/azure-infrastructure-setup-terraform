from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_nonfood_ingredients_list(df, cols):
    nonfood_ingredients_list = (df.select("articles.sapid",
                              "articles.basicdata.ean",
                              col("articles.basicData.lastModified").alias("LoadDateTime"),
                              "articles.articleid",
                              explode(col("articles.ingredients.nonfoodingredientlist")).alias("nf_array")
                                )
                       .select("*",
                                explode("nf_array.nonfoodIngredientStatementLang").alias("nf_statement_array")
                        )
                       .select("*", 
                               "nf_statement_array.lang",
                                col("nf_statement_array.val.value")[0].alias("nonFoodIngredient"))
                       .drop("nf_array").drop("nf_statement_array")).dropDuplicates()

    return nonfood_ingredients_list
