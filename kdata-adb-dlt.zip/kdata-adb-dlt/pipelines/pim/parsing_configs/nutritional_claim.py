from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_nutritional_claim(df, cols):
    gn_schema = StructType([
                StructField("ean", StringType(), False),
                StructField("LoadDateTime", StringType(), False),
                StructField("articleid", StringType(), False),
                StructField("nutrientBasisQuantityDescription", ArrayType(StructType([
                    StructField("element", StringType(), False),
                    StructField("dailyValueIntakeReference", StringType(), False),
                    StructField("language", StringType(), False)
                ])), True),
                StructField("nutritionalClaims", ArrayType(StringType()), True),
                StructField("nutritionalExtra", ArrayType(StructType([
                    StructField("element", StringType(), False),
                    StructField("claimDescription", StringType(), False),
                    StructField("language", StringType(), False),
                    StructField("nutritionalClaim", StringType(), False)
                ])), True),
                StructField("eggsFreeGlobal", StringType(), True),
                StructField("glutenFreeGlobal", StringType(), True),
                StructField("lactoseFreeGlobal", StringType(), True),
                StructField("milkFreeGlobal", StringType(), True),
                StructField("veganFreeGlobal", StringType(), True)
                ])
    if 'nutritionalinformation' in cols:
        global_nutrients = (df.select("articles.sapid",
                                "articles.basicdata.ean",
                                col("articles.basicData.lastModified").alias("LoadDateTime"),
                                col("articles.articleid").alias("articleid"),
                                "articles.nutritionalInformation.globalNutrients",
                                "articles.nutritionalInformation.nutrientBasisQuantityDescription",
                                "articles.nutritionalInformation.nutritionalClaims",
                                "articles.nutritionalInformation.nutritionalExtra",
                                "articles.nutritionalInformation.nutritionalInformation"
                                )
                        .select("*", explode("globalNutrients").alias("global_nutrients_array"))
                        .select("*",
                                "global_nutrients_array.eggsFreeGlobal",
                                "global_nutrients_array.glutenFreeGlobal",
                                "global_nutrients_array.lactoseFreeGlobal",
                                "global_nutrients_array.milkFreeGlobal",
                                "global_nutrients_array.veganFreeGlobal")
                        .drop("globalNutrients")
                        .drop("global_nutrients_array"))
        
    else:
        global_nutrients = spark.createDataFrame([], gn_schema)
                
    if global_nutrients.select("*", explode("nutritionalClaims").alias("nutritional_claims_array")).count() != 0:
        nutritional_claims_master = (global_nutrients.select("*", explode("nutritionalClaims").alias("nutritional_claims_array"))
                                            .select("*", 
                                                    "nutritional_claims_array.claimMarkedOnPackageCode",
                                                    "nutritional_claims_array.nutritionalClaimNutrientElementCode",
                                                    "nutritional_claims_array.nutritionalClaimTypeCode",
                                                    "nutritional_claims_array.nutritionalClaimTypeCodeLang",
                                                    explode("nutritional_claims_array.nutritionalClaimTypeCodeLang").alias("nc_typecode_array"))
                                            .select("*", 
                                                    col("nc_typecode_array.lang").alias("nutritional_claim_lang"),
                                                    col("nc_typecode_array.val")[0].getItem("value").alias("nutritional_claim_typecode_lang"),
                                                    col("nc_typecode_array.val")[1].getItem("value").alias("nutritional_claim_element"),
                                                    )
                                            .drop("nutritionalClaims")
                                            .drop("nutritional_claims_array")
                                            .drop("nutritionalClaimTypeCodeLang")
                                            .drop("nc_typecode_array")
                                    )
    else:
        nutritional_claim_schema = StructType([StructField('sapid', StringType(), True), 
                                                StructField('ean', StringType(), True),
                                                StructField("articleid", StringType(), False), 
                                                StructField('claimMarkedOnPackageCode', StringType(), True), 
                                                StructField('nutritionalClaimNutrientElementCode', StringType(), True), 
                                                StructField('nutritionalClaimTypeCode', StringType(), True),
                                                StructField('nutritional_claim_lang', StringType(), True),
                                                StructField('nutritional_claim_typecode_lang', StringType(), True),
                                                StructField('nutritional_claim_element', StringType(), True),
                                                StructField('LoadDateTime', StringType(), True)])
        nutritional_claims_master = spark.createDataFrame([], nutritional_claim_schema)

    nutritional_claim = (nutritional_claims_master.select("sapid",
                                    "ean",
                                    "articleid",
                                    "claimMarkedOnPackageCode",
                                    "nutritionalClaimNutrientElementCode",
                                    "nutritionalClaimTypeCode",
                                    "LoadDateTime"
                                    ).dropDuplicates()
                        )   
    return nutritional_claim, nutritional_claims_master
