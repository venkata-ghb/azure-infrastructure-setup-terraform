from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_allergens(df, cols):

  allergens_schema = StructType([
    StructField("sapid", IntegerType(), False),
    StructField("ean", IntegerType(), False),
    StructField("LoadDateTime", StringType(), False),
    StructField("articleid", StringType(), False),
    StructField("allergenDataProvided", StringType(), False),
    StructField("allergenSpecificationAgency", StringType(), False),
    StructField("allergenSpecificationName", StringType(), False),
    StructField("allergenTypeCode", StringType(), False),
    StructField("levelOfContainmentCode", StringType(), False),
    StructField("allergen_language", StringType(), False),
    StructField("level_of_containment", StringType(), False),
    StructField("allergen", StringType(), False)
  ])

  allergens_cols = ["allergenDataProvided",
                    "allergenLang",
                    "allergenSpecificationAgency",
                    "allergenSpecificationName",
                    "allergenTypeCode",
                    "levelOfContainmentCode"]
  parse_allergenlang = True

  allergens_master = (df.select(col("articles.sapid").alias("sapid"), 
                              col("articles.basicdata.ean").alias("ean"),
                              col("articles.basicData.lastModified").alias("LoadDateTime"),
                              col("articles.articleid").alias("articleid"),
                              explode("articles.allergens").alias("allergens_array"))
                      )
  allergens_master = allergens_master.select("*", "allergens_array.*")
  allergens_array_cols = allergens_master.columns
  for column in allergens_cols:
    if column not in allergens_array_cols:
      if column == 'allergenLang':
        parse_allergenlang = False
      allergens_master = allergens_master.withColumn(column, lit(None).cast('string'))

  allergens_master = (allergens_master.select("sapid",
                                              "ean",
                                              "LoadDateTime",
                                              "articleid",
                                              "allergenDataProvided",
                                              "allergenLang",
                                              "allergenSpecificationAgency",
                                              "allergenSpecificationName",
                                              "allergenTypeCode",
                                              "levelOfContainmentCode"
                                              )
                        )
  if parse_allergenlang:
    allergens_master = (allergens_master.select("*", explode("allergenLang").alias("allergen_lang_array"))
                        .select("*",
                                col("allergen_lang_array.lang").alias("allergen_language"),
                                col("allergen_lang_array.val").alias("allergen_val_array")
                                )
                        .select("*",
                                  col("allergen_val_array.value")[1].alias("level_of_containment"),
                                  col("allergen_val_array.value")[0].alias("allergen"))
                    .drop("allergenLang")
                    .drop("allergens_array")
                    .drop("allergen_lang_array")
                    .drop("allergen_val_array")
                    ).dropDuplicates()
  else:
    allergens_master = spark.createDataFrame([], allergens_schema)

  allergens = (allergens_master.select("sapid",
                                        "ean",
                                        "articleid",
                                        "allergenTypeCode",
                                        "levelOfContainmentCode",
                                        "allergenDataProvided",
                                        "allergenSpecificationAgency",
                                        "allergenSpecificationName",
                                        "LoadDateTime")
                ).dropDuplicates()
  
  return allergens, allergens_master