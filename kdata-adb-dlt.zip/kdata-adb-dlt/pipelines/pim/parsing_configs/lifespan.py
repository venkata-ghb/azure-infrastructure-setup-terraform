from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_lifespan(df, cols):
    if df.select("articles.sapid", explode("articles.instructions.lifespan")).count() != 0:

        lifespan_master = (df.select("articles.sapid",
                                "articles.basicdata.ean",
                                col("articles.basicData.lastModified").alias("LoadDateTime"),
                                "articles.articleid",
                                explode("articles.instructions.lifespan").alias("lifespan_array")
                                )
                        .select("*",
                                "lifespan_array.minProductLifespanFromArrival",
                                col("lifespan_array.minProductLifespanFromArrivalUOM").alias("minProductLifespanFromArrivalUOMName"),
                                "lifespan_array.minProductLifespanFromProduction",
                                col("lifespan_array.minProductLifespanFromProductionUOM").alias("minProductLifespanFromProductionUOMName"),
                                "lifespan_array.openedTradeItemLifespan",
                                col("lifespan_array.openedTradeItemLifespanUOM").alias("openedTradeItemLifespanUOMName"),
                                explode("lifespan_array.lifespanlang").alias("lifespan_lang_array")
                                )
                        .select("*",
                                "lifespan_lang_array.lang",
                                explode("lifespan_lang_array.val").alias("lifespan_val_array")
                                )
                        .select("*",
                                "lifespan_val_array.description",
                                "lifespan_val_array.value")
                        .drop("lifespan_array")
                        .drop("lifespan_lang_array")
                        .drop("lifespan_val_array")
                        )

        ls_master = lifespan_master.groupby("ean",
                                        "sapid",
                                        "LoadDateTime",
                                        "articleid",
                                        "minProductLifespanFromArrival",
                                        "minProductLifespanFromArrivalUOMName",
                                        "minProductLifespanFromProduction",
                                        "minProductLifespanFromProductionUOMName",
                                        "openedTradeItemLifespan",
                                        "openedTradeItemLifespanUOMName",
                                        "lang").pivot("description").agg({"value": "first"})
    else:
            ls_schema = StructType([
            StructField("ean", StringType(), True),
            StructField("sapid", StringType(), True),
            StructField("LoadDateTime", StringType(), True),
            StructField("articleid", StringType(), True),
            StructField("minProductLifespanFromArrival", StringType(), True),
            StructField("minProductLifespanFromArrivalUOMName", StringType(), True),
            StructField("minProductLifespanFromProduction", StringType(), True),
            StructField("minProductLifespanFromProductionUOMName", StringType(), True),
            StructField("openedTradeItemLifespan", StringType(), True),
            StructField("openedTradeItemLifespanUOMName", StringType(), True),
            StructField("lang", StringType(), True),
            StructField("minProductLifespanFromArrivalUOM", StringType(), True),
            StructField("minProductLifespanFromProductionUOM", StringType(), True),
            StructField("openedTradeItemLifespanUOM", StringType(), True)
            ])

            ls_master = spark.createDataFrame([], ls_schema)

    lifespan = (ls_master.drop("lang")
                        .drop("minProductLifespanFromArrivalUOM")
                        .drop("minProductLifespanFromProductionUOM")
                        .drop("openedTradeItemLifespanUOM")
                        ).dropDuplicates()
    return lifespan, ls_master
