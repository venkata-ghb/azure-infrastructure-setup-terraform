from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_precautionary_statements(df, cols):
    if df.select("articles.sapid", explode("articles.precautionarystatement").alias("precautionary_array")).count() != 0:
        precautionary_statements = (df.select("articles.sapid",
                                            "articles.basicdata.ean",
                                            col("articles.basicData.lastModified").alias("LoadDateTime"),
                                            "articles.articleid",
                                explode("articles.precautionarystatement").alias("precautionary_array")
                                )
                                .select("*",
                                        "precautionary_array.precautionaryStatementCode",
                                        explode("precautionary_array.precautionaryStatementAdditionalInfosLang").alias("precautionary_additional_info")
                                        )
                                .select("*",
                                        "precautionary_additional_info.language",
                                        "precautionary_additional_info.precautionaryStatement",
                                        "precautionary_additional_info.precautionaryStatementAdditionalInfo")
                                .drop("precautionary_array")
                                .drop("precautionary_additional_info")
        )

    else:
            precautionary_statements_schema = StructType([
            StructField("sapid", StringType(), True),
            StructField("ean", StringType(), True),
            StructField("articleid", StringType(), True),
            StructField("LoadDateTime", StringType(), True),
            StructField("precautionaryStatementCode", StringType(), True),
            StructField("precautionaryStatement", StringType(), True),
            StructField("precautionaryStatementAdditionalInfo", StringType(), True),
            StructField("language", StringType(), True)
            ])

            precautionary_statements = spark.createDataFrame([], precautionary_statements_schema)

    return precautionary_statements
