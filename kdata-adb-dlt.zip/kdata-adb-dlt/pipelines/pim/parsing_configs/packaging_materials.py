from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_packaging_materials(df, cols):
    packaging_materials_schema = StructType([
        StructField("sapid", StringType(), True),
        StructField("ean", StringType(), True),
        StructField("LoadDateTime", StringType(), True),
        StructField("articleid", StringType(), True),
        StructField("packagingCompositeMaterialCompositionQuantity", StringType(), True),
        StructField("packagingCompositeMaterialCompositionQuantityUOMCode", StringType(), True),
        StructField("packagingCompositeMaterialTypeCode", StringType(), True),
        StructField("packagingLabel", StringType(), True),
        StructField("packagingLabelCode", StringType(), True),
        StructField("isPackagingMaterialRecoverable", StringType(), True),
        StructField("packagingLabelCoverage", StringType(), True),
        StructField("packagingMaterialCompositionQuantity", StringType(), True),
        StructField("packagingMaterialCompositionQuantityUOM", StringType(), True),
        StructField("packagingMaterialCompositionQuantityUOMCode", StringType(), True),
        StructField("packagingMaterialElementCode", StringType(), True),
        StructField("packagingMaterialType", StringType(), True),
        StructField("packagingMaterialTypeCode", StringType(), True),
        StructField("packagingType", StringType(), True),
        StructField("packagingTypeCode", StringType(), True)
    ])

    if df.select("articles.sapid", explode(col("articles.packaging.packagingMaterials")).alias("pm_array")).count() != 0:

        packaging_materials = (df.select("articles.sapid",
                    "articles.basicdata.ean",
                    col("articles.basicData.lastModified").alias("LoadDateTime"),
                    col("articles.articleid").alias("articleid"),
                    explode(col("articles.packaging.packagingMaterials")).alias("pm_array")
                    )
        .select("*",
                "pm_array.packagingCompositeMaterialCompositionQuantity",
                "pm_array.packagingCompositeMaterialCompositionQuantityUOMCode",
                "pm_array.packagingCompositeMaterialTypeCode",
                "pm_array.packagingLabel",
                "pm_array.packagingLabelCode",
                "pm_array.isPackagingMaterialRecoverable",
                "pm_array.packagingLabelCoverage",
                "pm_array.packagingMaterialCompositionQuantity",
                "pm_array.packagingMaterialCompositionQuantityUOM",
                "pm_array.packagingMaterialCompositionQuantityUOMCode",
                "pm_array.packagingMaterialElementCode",
                "pm_array.packagingMaterialType",
                "pm_array.packagingMaterialTypeCode",
                "pm_array.packagingType",
                "pm_array.packagingTypeCode"
                )
        .drop("pm_array")
        .dropDuplicates()
        )
            
    else:
        packaging_materials = spark.createDataFrame([], packaging_materials_schema)
    return packaging_materials
