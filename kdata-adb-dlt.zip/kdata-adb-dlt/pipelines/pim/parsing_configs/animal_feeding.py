from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_animal_feeding(df, cols):
    animal_feeding_schema = StructType([
                            StructField("sapid", StringType(), True),
                            StructField("ean", StringType(), True),
                            StructField("LoadDateTime", StringType(), True),
                            StructField("articleid", StringType(), True),
                            StructField("targetedconsumptionbycode", StringType(), True),
                            StructField("feedtypecode", StringType(), True),
                            StructField("lang", StringType(), True),
                            StructField("animalNutritionalClaim", StringType(), True),
                            StructField("feedAdditiveStatement", StringType(), True),
                            StructField("feedAnalyticalConstituentsStatement", StringType(), True),
                            StructField("feedCompositionStatement", StringType(), True),
                            StructField("feedType", StringType(), True),
                            StructField("feedingInstructions", StringType(), True),
                            StructField("targetedConsumptionBy", StringType(), True),
                        ])

    if df.select("articles.sapid", explode("articles.animalfeeding")).count() != 0:

        animal_feeding_master = (df.select("articles.sapid",
                                "articles.basicdata.ean",
                                col("articles.basicData.lastModified").alias("LoadDateTime"),
                                "articles.articleid",
                                explode("articles.animalfeeding").alias("animal_feeding_array")
                                )
                                .select("*",
                                        "animal_feeding_array.targetedconsumptionbycode",
                                        "animal_feeding_array.feedtypecode",
                                        explode("animal_feeding_array.claimsstatementsinstructionslang").alias("claimsstatementsinstructions_lang_array")
                                )
                                .select("*",
                                        "claimsstatementsinstructions_lang_array.lang",
                                        explode("claimsstatementsinstructions_lang_array.val").alias("claimsstatementsinstructions_val_array"))
                                .select("*",
                                        "claimsstatementsinstructions_val_array.description",
                                        "claimsstatementsinstructions_val_array.value")
                                .drop("animal_feeding_array")
                                .drop("claimsstatementsinstructions_lang_array")
                                .drop("claimsstatementsinstructions_val_array")
                        )
        
        animal_feeding = animal_feeding_master.groupby("sapid",
              "ean",
              "LoadDateTime",
              "articleid",
              "targetedconsumptionbycode",
              "feedtypecode",
              "lang").pivot("description").agg({"value": "first"}).dropDuplicates()
    else: 
        animal_feeding = spark.createDataFrame([], animal_feeding_schema)
    return animal_feeding
