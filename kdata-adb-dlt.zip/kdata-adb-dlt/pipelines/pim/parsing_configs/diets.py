from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_diets(df, cols):
  diets_schema = StructType([
      StructField("sapid", StringType(), False),
      StructField("ean", StringType(), False),
      StructField("LoadDateTime", StringType(), False),
      StructField("articleid", StringType(), False),
      StructField("dietSubCode", StringType(), False),
      StructField("dietSubCodeCode", StringType(), False),
      StructField("dietType", StringType(), False),
      StructField("dietTypeCode", StringType(), False),
      StructField("dietTypeDescription", StringType(), False),
      StructField("lang", StringType(), False),
      StructField("diet_value", StringType(), False),
      StructField("diet_sub_code", StringType(), False)
    ])
  
  diets_cols = ["dietSubCode",
                "dietSubCodeCode",
                "dietType",
                "dietTypeCode",
                "dietTypeDescription",
                "dietTypeLang"]
  parse_diettypelang = True

  if df.select("articles.sapid", explode("articles.diets")).count() != 0:
    diets_master = (df.select("articles.sapid",
                            "articles.basicdata.ean",
                            col("articles.basicData.lastModified").alias("LoadDateTime"),
                            col("articles.articleid").alias("articleid"),
                            explode("articles.diets").alias("diets_array")
                            ))
    diets_master = diets_master.select("*", "diets_array.*")
    diets_array_cols = diets_master.columns
    for column in diets_cols:
      if column not in diets_array_cols:
        if column == 'dietTypeLang':
          parse_diettypelang = False
        diets_master = diets_master.withColumn(column, lit(None).cast('string'))

    diets_master = (diets_master.select("sapid",
                                        "ean",
                                        "LoadDateTime",
                                        "articleid",
                                        "dietSubCode",
                                        "dietSubCodeCode",
                                        "dietType",
                                        "dietTypeCode",
                                        "dietTypeDescription",
                                        "dietTypeLang",
                                        "language")
                      )
    if parse_diettypelang:
      diets_master = (diets_master.select("*", explode("dietTypeLang").alias("diettypelang_array"))
                                    .select("*",
                                            "diettypelang_array.lang",
                                            "diettypelang_array.val")
                                    .select("*", explode("val").alias("diettypelang_val_array"))
                                    .select("*", col("diettypelang_array.val.value")[0].alias("diet_value"))
                                    .select("*", col("diettypelang_array.val.value")[1].alias("diet_sub_code"))
                                    .drop("diets_array")
                                    .drop("diettypelang_array")
                                    .drop("diettypelang_val_array")
                                    .drop("dietTypeLang")
                                    .drop("val")
                                    .drop("language")
                                    .dropDuplicates()
                      )
    else:
      diets_master = (diets_master.withColumn("lang", lit(None))
                                  .withColumn("diet_value", lit(None))
                                  .withColumn("diet_sub_code", lit(None))
                                  .drop("dietTypeLang")
                                  .drop("language")
                      )
  else:
    diets_master = spark.createDataFrame([], diets_schema)

  diets = (diets_master.drop("lang")
                      .drop("diet_value")
                      .drop("diet_sub_code")
                      )
  return diets, diets_master
