from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_fineli(df, cols):
    if df.select("articles.sapid", explode("articles.fineli")).count() != 0:
        fineli_master = (df.select("articles.sapid",
                                "articles.basicdata.ean",
                                col("articles.basicData.lastModified").alias("LoadDateTime"),
                                col("articles.articleid").alias("articleid"),
                                explode(col("articles.fineli")).alias("fineli_array"))
                        .select("*",
                                "fineli_array.shrinkagefromproduction",
                                "fineli_array.fineliID",
                                explode("fineli_array.fineliLang").alias("fineli_lang_array"))
                        .select("*",
                                col("fineli_lang_array.lang").alias("f_lang"),
                                explode("fineli_lang_array.val").alias("fineli_val_array"))
                        .select("*",
                                col("fineli_val_array.value").alias("fineli_name"))
                        .drop("fineli_lang_array")
                        .drop("fineli_val_array")
                        .drop("fineli_array"))
                        
    else:
            fineli_schema = StructType([
                    StructField("sapid", StringType(), True),
                    StructField("ean", StringType(), True),
                    StructField("articleid", StringType(), True),
                    StructField("LoadDateTime", StringType(), True),
                    StructField("fineliID", StringType(), True),
                    StructField("f_lang", StringType(), True),
                    StructField("fineli_name", StringType(), True)
            ])

            fineli_master = spark.createDataFrame([], fineli_schema)

    fineli = (fineli_master.drop("f_lang")
                    .drop("fineli_name")
                    .filter(col("fineliID") != '')
                    .dropDuplicates())
    return fineli, fineli_master
