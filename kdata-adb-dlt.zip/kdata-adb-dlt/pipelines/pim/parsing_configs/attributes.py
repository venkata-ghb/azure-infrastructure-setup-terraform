from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_attributes(df,cols):
        attributes_schema = StructType([
        StructField("sapid", StringType(), nullable=True),
        StructField("ean", StringType(), nullable=True),
        StructField("LoadDateTime", StringType(), nullable=True),
        StructField("articleid", StringType(), nullable=True),
        StructField("attributeID", StringType(), nullable=True),
        StructField("attributeKeyName", StringType(), nullable=True),
        StructField("attributeName", StringType(), nullable=True),
        StructField("attributePurpose", StringType(), nullable=True),
        StructField("attributeUnit", StringType(), nullable=True),
        StructField("attributeValue", StringType(), nullable=True),
        StructField("languageID", StringType(), nullable=True)
        ])

        if df.select("articles.sapid", explode("articles.attributes")).count() != 0: 

                attributes = (df.select("articles.sapid",
                                        "articles.basicdata.ean",
                                        col("articles.basicData.lastModified").alias("LoadDateTime"),
                                        col("articles.articleid").alias("articleid"),
                                        explode("articles.attributes").alias("attributes_array")
                                        )
                                .select("*",
                                        "attributes_array.attributeID",
                                        "attributes_array.attributeKeyName",
                                        "attributes_array.attributeName",
                                        "attributes_array.attributePurpose",
                                        "attributes_array.attributeUnit",
                                        "attributes_array.attributeValue",
                                        when(col("attributes_array.languageID").isin(["se", "ruotsi", "swedish"]), 'sv')
                                        .when(col("attributes_array.languageID").isin(["english", "englanti"]), 'en')
                                        .when(col("attributes_array.languageID").isin(["suomi", "finnish"]), 'fi')
                                        .otherwise(col("attributes_array.languageID")).alias("languageID"),
                                        )
                                .drop("attributes_array")
                                ).dropDuplicates()
        else:
                attributes = spark.createDataFrame([], attributes_schema)

        return attributes