from pyspark.sql.functions import *
from pyspark.sql.types import *
from databricks.sdk.runtime import *

def parse_e_numbers(df, cols):
    if df.select("articles.sapid", explode("articles.ingredients.enumbers").alias("en_array")).count() != 0:

        e_numbers_master = (df.select("articles.sapid",
                                "articles.basicdata.ean",
                                col("articles.basicData.lastModified").alias("LoadDateTime"),
                                "articles.articleid",
                                explode(col("articles.ingredients.enumbers")).alias("en_array")
                                )
                        .select("*",
                                "en_array.eNumberCode",
                                "en_array.levelOfContainmentCode",
                                explode(col("en_array.eNumberLang")).alias("en_lang_array")
                                )
                        .select("*",
                                "en_lang_array.lang",
                                explode(col("en_lang_array.val")).alias("en_lang_val_array")
                                )
                        .select("*",
                                "en_lang_val_array.description",
                                col("en_lang_val_array.value")
                        )
                        .drop("en_lang_array")
                        .drop("en_lang_val_array")
                        .drop("en_array")
                        )
        en_master = e_numbers_master.groupby("sapid",
                                        "ean",
                                        "LoadDateTime",
                                        "articleid",
                                        "eNumberCode",
                                        "levelOfContainmentCode",
                                        "lang"                                    
                                        ).pivot("description").agg({"value": "first"})
    else:
        e_numbers_schema = StructType([
            StructField("sapid", StringType(), True),
            StructField("ean", StringType(), True),
            StructField("LoadDateTime", StringType(), True),
            StructField("articleid", StringType(), True),
            StructField("eNumberCode", StringType(), True),
            StructField("levelOfContainmentCode", StringType(), True),
            StructField("lang", StringType(), True),
            StructField("eNumber", StringType(), True),
            StructField("levelOfContainment", StringType(), True)
        ])
        en_master = spark.createDataFrame([], e_numbers_schema)

    e_numbers = (en_master.drop("levelOfContainment")
                        .filter("lang = 'fi'")
                        .drop("lang")
                ).dropDuplicates()
    return e_numbers, en_master
