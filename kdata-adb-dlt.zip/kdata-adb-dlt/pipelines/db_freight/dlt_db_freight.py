# Databricks notebook source
# MAGIC %md
# MAGIC # Imports

# COMMAND ----------

import dlt
import json

# COMMAND ----------

# MAGIC %md
# MAGIC ## Import DLT pipeline functions

# COMMAND ----------

repository_path = spark.conf.get("repository_path")
sys.path.append(f"{repository_path}/dlt_functions/dltlib")	
from dltlib import *

# COMMAND ----------

# MAGIC %md
# MAGIC # Pipeline configuration

# COMMAND ----------

inputPath = f"abfss://testcontainer@unitycatalogextstor.dfs.core.windows.net/db_freight/" 
process_cols = {}
source_system = "db_freight"
target_schema = spark.conf.get("target_schema") 
sparkOptions = {
  "cloudFiles.format": "csv",
  "header": "true",
  "delimiter": ";"
} 

# COMMAND ----------

# The processing rules for the bronze and silver layers are written
# in a single json file in the dlt repository.

pipeline_path = f"{repository_path}/pipelines/{source_system}"
table_config_path = f"{pipeline_path}/tables.json"
with open(file=table_config_path, mode="r") as file:
    pipeline_tables = json.load(file)

# COMMAND ----------

# MAGIC %md
# MAGIC # Execution

# COMMAND ----------

# MAGIC %md
# MAGIC ## Bronze

# COMMAND ----------

for table in pipeline_tables.keys():
    # Create the bronze tables.
    dltlib.ingest_raw_data(
      table=table, 
      sparkOptions=sparkOptions, 
      inputPath=inputPath
    )


# COMMAND ----------

# MAGIC %md
# MAGIC ## Silver

# COMMAND ----------

for source_table, target_table in pipeline_tables.items():
    if dltlib.check_if_table_exists(table=f"main.{target_schema}.bronze_{table}"):
        dltlib.create_silver_temp_table(
            source_table=source_table,
            target_table=target_table["silver_table"],
            column_mapping=target_table["column_mapping"],
            expectations=dltlib.generate_expectations(
                keys=target_table["keys"], 
                allowed_values=target_table["allowed_values"]
            ),
            use_cdc=False,
            source_system=source_system,
        )

        dltlib.check_row_count(
            source_table=f"bronze_{source_table}",
            target_table=f"temp_{target_table['silver_table']}",
            column_mapping=target_table["column_mapping"],
            keys=target_table["keys"]
        )

        dltlib.generate_duplicate_values(
            source_table=f"temp_{target_table['silver_table']}", 
            column_mapping=target_table["column_mapping"],
            keys=target_table["keys"]
        )

        dltlib.check_duplicate_values(
            source_table=f"generated_duplicates_temp_{target_table['silver_table']}", 
            column_mapping=target_table["column_mapping"],
            keys=target_table["keys"]
        )

        dltlib.create_silver_table(
            source_system=source_system,
            target_table=target_table["silver_table"],
            keys=target_table["keys"],
        )
