resource databricks_pipeline dlt_kruoka_store {
  name = "dlt_kruoka_store"

  cluster {
    label               = "default"
    spark_env_vars      = {}
    spark_conf          = local.global_spark_conf
    node_type_id        = local.default_node
    driver_node_type_id = local.default_node
    autoscale {
      min_workers = 1
      max_workers = 2
      mode        = "ENHANCED"
    }
  }

  library {
    notebook {
      path = "${local.workspace_prefix}/pipelines/kruoka_store/dlt_kruoka_store"
    }
  }

  storage     = "${local.storage_prefix}/kruoka/kruoka_store/"
  continuous  = false
  channel     = "CURRENT"
  development = var.ENV != "prod" ? true : false
  photon      = false
  target      = "dlt_kruoka"

  configuration = {
    environment     = var.ENV
    repository_path = "/Workspace${local.workspace_prefix}"
    target_schema   = "dlt_kruoka"
  }
}

