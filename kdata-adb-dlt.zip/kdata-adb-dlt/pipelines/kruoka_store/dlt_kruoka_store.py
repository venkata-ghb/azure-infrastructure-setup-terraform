# Databricks notebook source
import json

# COMMAND ----------

import sys
import os
repository_path = spark.conf.get("repository_path")

sys.path.append(os.path.abspath(f"{repository_path}/dlt_functions/dltlib"))
from dltlib import *
from pyspark.sql.types import *
import pyspark.sql.functions as F
from pyspark.sql.functions import from_json,to_json, explode
from pyspark.sql.functions import when, col, count, max, current_timestamp, expr
import pyspark

# COMMAND ----------

env = spark.conf.get("environment") # integration environment
inputPath = f"abfss://raw@kdata{env}adls.dfs.core.windows.net/natural/KRUOKA/Store/"
process_cols = {}
target_schema = spark.conf.get("target_schema") # schema in the local hive metastore
source_system = "kruoka"
table = "kruoka_store"

pipeline_path = spark.conf.get("repository_path")
table_config_path = f"{pipeline_path}/pipelines/kruoka_store/tables.json"
with open(file=table_config_path, mode="r") as file:
    pipeline_tables = json.load(file)

# COMMAND ----------

json_schema = StructType([ \
                StructField("areaId", LongType(), True), \
                StructField("areaName", StringType(), True), \
                StructField("deliveryMethod", StringType(), True), \
                    StructField("columns",ArrayType(StructType([ \
                         StructField("header", StructType([ \
                             StructField("date", StringType(), True), \
                             StructField("isException", BooleanType(), True)])), \
                         StructField("rows", ArrayType(StructType([ \
                             StructField("allowAlcohol", BooleanType(), True), \
                             StructField("areaId", LongType(), True), \
                             StructField("areaName", StringType(), True), \
                             StructField("availableCapacity", LongType(), True), \
                             StructField("capacity", LongType(), True), \
                             StructField("cutOffHoursBefore", LongType(), True), \
                             StructField("cutOffTime", StringType(), True), \
                             StructField("date", StringType(), True), \
                             StructField("deliveryMethod", StringType(), True), \
                             StructField("endLocalTime", StringType(), True), \
                             StructField("endTime", StringType(), True), \
                             StructField("exception", BooleanType(), True), \
                             StructField("originalCapacity", LongType(), True), \
                                 StructField("prices",ArrayType(StructType([ \
                                     StructField("ean", StringType(), True), \
                                     StructField("minPrice", LongType(), True)])), True), \
                             StructField("slotSpecId", LongType(), True), \
                             StructField("startLocalTime", StringType(), True), \
                             StructField("startTime", StringType(), True), \
                             StructField("storeId", StringType(), True), \
                             StructField("validFrom", StringType(), True), \
                             StructField("validTo", StringType(), True), \
                             StructField("weekday", LongType(), True), \
                                                                  ])),True)])))])

# COMMAND ----------

def ingest_raw_data(table, inputPath, process_cols = None, **sparkOptions):
        @dlt.table(
            name=f"bronze_{table}",
            comment="This table was created with Autoloader.",
            table_properties={"quality": "bronze", "delta.enableChangeDataFeed": "True"},
        )
        def load_table_bronze():
            rawdf = (
                spark.readStream.format("cloudFiles")
                .option("cloudFiles.format", "json")
                .option("multiline","true")
                .schema(json_schema)
                .load(inputPath)
            ) 
            if process_cols:
              for column_name, column_statement in process_cols.items():
                rawdf = rawdf.withColumn(column_name, column_statement)
            rawdf = rawdf.withColumn("BronzeLoadDateTime", current_timestamp())
            return rawdf

# COMMAND ----------

#Create the bronze table.
ingest_raw_data(
  table=f"{table}", 
  inputPath=f"{inputPath}"
)

# COMMAND ----------

def FlattenData(source_table):

  @dlt.table(
    name="bronze_store_main",
    comment="Kruoka store main bronze table",
    table_properties={"quality": "temp"}
  )
  def load_table_bronze_store_main():
    df = (
      spark.readStream.format("delta")
      .option("ignoreChanges", "true")
      .table(f"LIVE.{source_table}")
      )
    store_main_df= df.select("areaId", "areaName", "deliveryMethod", "BronzeLoadDateTime")
    return ( 
      store_main_df
    )
    
    
  @dlt.table(
    name="bronze_store_rows",
    comment="Kruoka store rows bronze table",
    table_properties={"quality": "temp"}
  )
  def load_table_bronze_store_rows():
    df = (
      spark.readStream.format("delta")
      .option("ignoreChanges", "true")
      .table(f"LIVE.{source_table}")
      )
    
    df_store_rows_json = df.select(col("areaId").alias("areaId"),
                                   col("BronzeLoadDateTime").alias("BronzeLoadDateTime"),
                                         explode("columns").alias("columns")).select(col("areaId").alias("areaId"),col("BronzeLoadDateTime").alias("BronzeLoadDateTime"),explode("columns.rows").alias("rows"))
    
    df_store_rows = df_store_rows_json.select("areaId",
                                                  "rows.allowAlcohol",
                                                  "rows.areaName",
                                                  "rows.availableCapacity",
                                                  "rows.capacity", 
                                                  "rows.cutOffHoursBefore",
                                                  "rows.cutOffTime",
                                                  "rows.date",
                                                  "rows.deliveryMethod",
                                                  "rows.endLocalTime",
                                                  "rows.endTime",
                                                  "rows.exception",
                                                  "rows.originalCapacity",
                                                  "rows.slotSpecId",
                                                  "rows.startLocalTime",
                                                  "rows.startTime",
                                                  "rows.storeId",
                                                  "rows.validFrom",
                                                  "rows.validTo",
                                                  "rows.weekday",
                                                  "BronzeLoadDateTime").distinct()
    return ( 
      df_store_rows
    )
    
    
    
  @dlt.table(
    name="bronze_store_rows_prices",
    comment="Kruoka store rows prices bronze table",
    table_properties={"quality": "temp"}
  )
  def load_table_bronze_store_rows_prices():
    df = (
      spark.readStream.format("delta")
      .option("ignoreChanges", "true")
      .table(f"LIVE.{source_table}")
      )
    
    df_store_rows_prices_json = df.select(col("BronzeLoadDateTime").alias("BronzeLoadDateTime"),explode("columns").alias("columns")).select(col("BronzeLoadDateTime").alias("BronzeLoadDateTime"),explode("columns.rows").alias("rows")).select(col("BronzeLoadDateTime").alias("BronzeLoadDateTime"),col("rows.slotSpecId").alias("slotSpecId"),explode("rows.prices").alias("prices"))
    
    df_store_rows_prices = df_store_rows_prices_json.select("slotSpecId",
                                                                "prices.ean",
                                                                "prices.minPrice",
                                                                "BronzeLoadDateTime").distinct()
    return ( 
      df_store_rows_prices
    )

# COMMAND ----------

#Flatten data
if dltlib.check_if_table_exists(f"{target_schema}.bronze_{table}"):
    FlattenData(source_table=f"bronze_{table}")

# COMMAND ----------

for source_table, target_table in pipeline_tables.items():
  if target_table.get("process_silver") == "True":
    if dltlib.check_if_table_exists(f"{target_schema}.bronze_{source_table}"):
            dltlib.create_cdc_table(
              schema="dlt_kruoka",
              table=f"{source_table}", 
              temporary=True
            )

# COMMAND ----------

for source_table, target_table in pipeline_tables.items():
  if target_table.get("process_silver") == "True":
    if dltlib.check_if_table_exists(f"{target_schema}.bronze_{source_table}"):
            dltlib.create_silver_temp_table(
                source_table=source_table,
                target_table=target_table["target"],
                column_mapping=target_table["column_mapping"],
                expectations=dltlib.generate_expectations(
                  keys=target_table["keys"],
                  allowed_values=target_table["allowed_values"]
              ),
                use_cdc = True,
                source_system = "kruoka"
            )

            dltlib.create_silver_table_scd1(
              source_system=source_system,
              target_table=target_table["target"], 
              keys=target_table["keys"]
          )
