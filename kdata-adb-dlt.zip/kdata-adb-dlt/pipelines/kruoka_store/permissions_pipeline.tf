resource "databricks_permissions" "pipeline-dlt_kruoka_store" {
  pipeline_id = databricks_pipeline.dlt_kruoka_store.id

  # DEVOPS PLATFORM
  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_PLATFORM"
    permission_level = "CAN_RUN"
  }
}
