resource databricks_job dlt_kruoka {
  name = "dlt_kruoka_${var.ENV}"

  schedule {
    quartz_cron_expression = "43 0 5 * * ?"
    timezone_id = "Europe/Helsinki"
    pause_status = "UNPAUSED"
  }

  pipeline_task {
    pipeline_id = databricks_pipeline.dlt_kruoka_store.id
  }
}
