# ==============================================================================================================================================


resource databricks_job kespro_laskenta_job {
  name = "kespro_laskenta_${var.ENV}"

  job_cluster {
    job_cluster_key = "kespro-laskenta-cluster"
    new_cluster {
      num_workers    = 4
      spark_version  = "17.3.x-scala2.13"
      node_type_id   = "Standard_D8s_v5"
      spark_conf     = local.global_spark_conf
      spark_env_vars = { PYSPARK_PYTHON = "/databricks/python3/bin/python3" }
    }
  }
  schedule {
    quartz_cron_expression = "0 0 6 6 * ?"
    timezone_id = "Europe/Helsinki"
    pause_status = "UNPAUSED"
  }
  timeout_seconds = 3600

  task {
    task_key        = "write_kesprodata_misc_tables"
    job_cluster_key = "kespro-laskenta-cluster"

     notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/kespro_laskenta/kespro_laskenta_psql_writer"
      base_parameters = {
        env             = var.ENV
        pipeline_path   = "/Workspace${local.workspace_prefix}/pipelines/kespro_laskenta"
      }
    }
  }

}
