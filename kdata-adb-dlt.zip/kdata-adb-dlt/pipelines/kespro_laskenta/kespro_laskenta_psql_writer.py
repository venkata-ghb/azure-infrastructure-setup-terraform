# Databricks notebook source
from pyspark.sql.functions import col, lit, max, desc, current_timestamp, to_date, concat
import json
import time
from datetime import datetime, timezone

# COMMAND ----------

dbutils.widgets.text("env", "dev")
env = dbutils.widgets.get("env")

# COMMAND ----------

#Get connection details for current kespro-data from config
user = dbutils.secrets.get(scope="kesprodata-keys", key='kesprodata-databricks-writer-username')
pw = dbutils.secrets.get(scope="kesprodata-keys", key='postgresql-databricks-writer-password')
host = dbutils.secrets.get(scope="kesprodata-keys", key='kesprodata-postgres-fqdn')
database_name = "kesprodata"

#Get connection details for new kespro-data from config
kd_user = dbutils.secrets.get(scope="kv-kd-shared", key = 'kesprodata-databricks-writer-username')
kd_pw = dbutils.secrets.get(scope="kv-kd-shared", key = 'postgresql-databricks-writer-password')
kd_host = dbutils.secrets.get(scope="kv-kd-shared", key = 'kesprodata-postgres-fqdn')
kd_database_name = "kesprodata"

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Functions

# COMMAND ----------

def iso_now():
    return datetime.now(timezone.utc).isoformat()

def read_source_information(table):
  print(f"[{iso_now()}] Read source information for table {table}")
  start_time = time.time()
  df = (spark.read
    .format("postgresql")
    .option("dbtable", table)
    .option("host", kd_host)
    .option("port", 5432)
    .option("database", kd_database_name)
    .option("user", kd_user)
    .option("password", kd_pw)
    .load(table)
    )

  schema = df.columns
  print(f"[{iso_now()}] Source information retrieved")

  return schema

# COMMAND ----------

def psql_data_write(df, write_mode, target_table, host, database_name, user, pw, port=5432, batch_size=50000, num_partitions=4):

    print(f"[{iso_now()}] Write to target table {target_table}. Write mode: {write_mode}")
    
    psql_writer = (df.write
        .format("postgresql")
        .option("dbtable", target_table)
        .option("host", host)
        .option("port", port)
        .option("database", database_name)
        .option("user", user)
        .option("password", pw)
        .option("batchSize", batch_size)
        .option("numPartitions", num_partitions)        
    )

    psql_writer = psql_writer.mode("overwrite").option("truncate", "true")

    psql_writer.save()

    print(f"[{iso_now()}] Write complete")

# COMMAND ----------

def write_kespro_laskenta_table():

  start_time = time.time()

  target_schema_name = "kespro_misc"
  target_table_name = "yearly_compensation_customers"

  source_table = f"abfss://raw@kdata{env}adls.dfs.core.windows.net/natural/KESPROLASKENTA/kespro_compensation_yearly_amount"
  target_table = f"{target_schema_name}.{target_table_name}"

  schema = read_source_information(target_table)
  
  print(f"[{iso_now()}] Reading source table {source_table}")
  
  df = (
          spark.read
          .format("parquet")
          .load(source_table)
          .withColumnRenamed("Tilausasiakasnro", "customer_id")
        )
  
  df = df.withColumn("load_date", to_date(concat(col("year"), lit("-"), col("month"), lit("-") , col("day")), "y-M-d"))
  df = df.withColumn("source_load_datetime", current_timestamp())

  df = (df.select(*schema).dropDuplicates(["customer_id"])
                          .orderBy(desc("load_date"))
      )
  
  write_mode = "overwrite"
  df.cache()
  rows_written = df.count()
  
  print(f"[{iso_now()}] Target Table: {target_table} | Mode: {write_mode} | Rows identified: {rows_written:,}")

  if rows_written == 0:
      print(f"[{iso_now()}] WARNING: Table {target_table} or {source_table} is empty. Overwrite with truncate=true will leave the Postgres table empty.")
      return
    
  psql_data_write(df, write_mode, target_table, host, database_name, user, pw)
  psql_data_write(df, write_mode, target_table, kd_host, kd_database_name, kd_user, kd_pw)

  end_time = time.time()
  final_time = end_time - start_time
  print(f"[{iso_now()}] Completed {target_table}: {rows_written:,} rows uploaded in {final_time:.2f} seconds")

  

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Execution

# COMMAND ----------

write_kespro_laskenta_table()
