# Databricks notebook source
import json
import os
import sys
# COMMAND ----------

repository_path = spark.conf.get("repository_path")

sys.path.append(os.path.abspath(f"{repository_path}/dlt_functions/dltlib"))
from dltlib import *
from pyspark.sql.types import *
from pyspark.sql.functions import  explode, col, current_timestamp, when, first

# COMMAND ----------

env = spark.conf.get("environment") # integration environment
inputPath = f"abfss://raw@kdata{env}adls.dfs.core.windows.net/natural/KKYLA/stage/surveys/"
target_schema = spark.conf.get("target_schema") # schema in the local hive metastore
source_system = "kkyla"
table = "kkyla_surveys"

pipeline_path = spark.conf.get("repository_path")
table_config_path = f"{pipeline_path}/pipelines/kkyla/tables.json"
with open(file=table_config_path, mode="r") as file:
    pipeline_tables = json.load(file)

# COMMAND ----------

json_schema = StructType([ \
    StructField("CreationDate", TimestampType(), True), \
    StructField("IsPublished", BooleanType(), True), \
    StructField("Status", StringType(), True), \
    StructField("SurveyAnswers", ArrayType(StructType([ \
        StructField("RespondentAnswers", ArrayType(StructType([ \
            StructField("Keywords",StringType(),True), \
            StructField("Label",StringType(),True), \
            StructField("QuestionAnswers", ArrayType(StructType([ \
                StructField("AnswerFile",StringType(),True), \
                StructField("AnswerOptionId",StringType(),True), \
                StructField("AttahedTextFieldValue",StringType(),True), \
                StructField("OptionAnswer",StringType(),True), \
                StructField("OptionId",StringType(),True), \
                StructField("QuestionOptionId",StringType(),True), \
                StructField("RowText",StringType(),True)])), True), \
            StructField("QuestionId",StringType(),True), \
            StructField("QuestionTitle",StringType(),True), \
            StructField("QuestionTypeId",StringType(),True), \
            StructField("QuestionTypeName",StringType(),True)])), True), \
        StructField("RespondentEmail",StringType(),True), \
        StructField("RespondentId",StringType(),True), \
        StructField("ResponseDate",TimestampType(),True), \
        StructField("ResponseId",StringType(),True), \
        StructField("ResponseLanguageId",StringType(),True)])),True), \
    StructField("SurveyId", StringType(), True), \
    StructField("SurveyTitle", StringType(), True)])

# COMMAND ----------

def flatten_data(raw_df):
    ''' Flatten the nested json data'''

    flattened_df = (
         raw_df
         .withColumn("SurveryFields", explode("SurveyAnswers"))
         .withColumn("RespondentFields", explode("SurveryFields.RespondentAnswers"))
         .withColumn("QuestionFields", explode("RespondentFields.QuestionAnswers"))
         .select(
             "*",
             "SurveryFields.*",
             "RespondentFields.*",
             "QuestionFields.*"
         )
         .drop(
             "SurveyAnswers",
             "RespondentAnswers",
             "QuestionAnswers",
             "SurveryFields",
             "RespondentFields",
             "QuestionFields",
             "year",
             "month",
             "date"
         )
     )

    return flattened_df
    

# COMMAND ----------

def ingest_raw_data(table, inputPath, process_cols = None, **sparkOptions):
        @dlt.table(
            name=f"bronze_{table}",
            comment="This table was created with Autoloader.",
            table_properties={"quality": "bronze", "delta.enableChangeDataFeed": "True"},
        )
        def load_table_bronze():
            raw_df = (
                spark.readStream.format("cloudFiles")
                .option("cloudFiles.format", "json")
                .schema(json_schema)
                .load(inputPath)
            ) 
            raw_df = flatten_data(raw_df)
            raw_df = raw_df.withColumn("BronzeLoadDateTime", current_timestamp())
            return raw_df

# COMMAND ----------

#Create the bronze table.
ingest_raw_data(
  table=f"{table}", 
  inputPath=f"{inputPath}"
)

# COMMAND ----------

def create_silver_temp_table(
        source_table,
        target_table,
        column_mapping,
        expectations,
        temp_kid_table,
        source_system = "source_system N/A",
        bronze_load_timestamp_column_name="BronzeLoadDateTime",
        live_table=True
    ):
        
        @dlt.table(
            name=temp_kid_table,
            comment="Temporary table containing KID for surveys",
            temporary=True,
        )

        def load_temporary_kid_table():
            table_prefix = "bronze"
            table = f"LIVE.{table_prefix}_{source_table}" if live_table else source_table

            return (
                spark.table(table)
                    .withColumn('survey_id', expr("nvl(SurveyId, '-1')"))
                    .withColumn('respondent_id', expr("nvl(RespondentId, '-1')"))
                    .withColumn('response_id', expr("nvl(ResponseId, '-1')"))
                    .withColumn("kid", expr("CASE WHEN QuestionTitle == 'KID' THEN OptionAnswer ELSE NULL END"))
                    .groupBy("BronzeLoadDateTime", "survey_id", "respondent_id", "response_id").agg(first("kid").alias("kid"))
                    .dropDuplicates()
            )


        @dlt.table(
            name=f"temp_{target_table}",
            comment="Temporary table for renaming columns before SCD is implemented.",
            temporary=True,
            table_properties={"quality": "temp"},
        )
        
        def load_dynamic_table_silver():
            
            # Generate a select expression for renaming columns
            selExpr = [
                f"{value} as {key}"
                for key, value in column_mapping.items()
            ]
            
            # Add a load datetime to allow identifying rows processed
            # by a single instance of the pipeline. 
            load_dttm = [
                "current_timestamp() as SilverLoadDateTime",
                f"{bronze_load_timestamp_column_name} as BronzeLoadDateTime"   
            ]

            # Add an identifier for the source system. 
            # This is intended to be used mainly in the gold layer
            # where multiple different source systems can be combined in
            # a single table.
            source = [f"'{source_system}' as SrcID"]

            table_prefix = "bronze"
            selExpr = selExpr + load_dttm + source
            
            table = f"LIVE.{table_prefix}_{source_table}" if live_table else source_table

            df = (
                spark.readStream.format("delta")
                .option("ignoreChanges", "true")
                .table(table)
            )

            # Handling null values in the key columns
            df = df.withColumn('survey_id', when(col('SurveyId').isNull(),'-1').otherwise(col('SurveyId'))) \
                    .withColumn('respondent_id', when(col('RespondentId').isNull(),'-1').otherwise(col('RespondentId'))) \
                    .withColumn('response_id', when(col('ResponseId').isNull(),'-1').otherwise(col('ResponseId')))
            
            # Load data from temporary kid table
            kid_table_name = f"LIVE.{temp_kid_table}"
            kid_df = spark.read.table(kid_table_name)   

            # Join main and KID Dataframe, to create the derived KID Column
            df = df.join(kid_df,
                      ["survey_id", "respondent_id", "response_id", "BronzeLoadDateTime"],
                      "left"
                     ).drop("survey_id","respondent_id","response_id")

            return df.selectExpr(selExpr)
        

# COMMAND ----------

def create_silver_tables(
          source_table,
          expectations,
          use_cdc = True,
          live_table=True   
    ):
     
     @dlt.table(
          name=f"kkyla_background_surveys",
          comment="Silver Table",
          table_properties={"quality": "silver"},
          )
     
     def load_dynamic_table_silver_background_surveys():
          
          table_prefix = "temp"
          table = f"LIVE.{table_prefix}_{source_table}" if live_table else source_table
          df = (
                spark.readStream.format("delta")
                .option("ignoreChanges", "true")
                .table(table)
            )
          
          df = df.filter(col('survey_id') == '3dd419b9-e93c-47bc-9bd2-233df508ad34')

          return df
     
     @dlt.table(
          name=f"kkyla_surveys",
          comment="Silver Table",
          table_properties={"quality": "silver"},
          )
     
     def load_dynamic_table_silver_surveys():
          
          table_prefix = "temp"
          table = f"LIVE.{table_prefix}_{source_table}" if live_table else source_table
          df = (
                spark.readStream.format("delta")
                .option("ignoreChanges", "true")
                .table(table)
            )
          
          df = df.filter(col('survey_id') != '3dd419b9-e93c-47bc-9bd2-233df508ad34')

          return df

# COMMAND ----------

for source_table, target_table in pipeline_tables.items():
  if target_table.get("process_silver") == "True":
    if dltlib.check_if_table_exists(f"{target_schema}.bronze_{source_table}") and target_table.get("target") == "kkyla_surveys":
            create_silver_temp_table(
                 source_table=source_table,
                 target_table=target_table["target"],
                 column_mapping=target_table["column_mapping"],
                 temp_kid_table = "temp_kkyla_kid",
                 expectations=dltlib.generate_expectations(
                      keys=target_table["keys"],
                      allowed_values=target_table["allowed_values"]
                      ),
                 source_system = "kkyla"
                 )
            
            create_silver_tables(
                 source_table,
                 expectations=dltlib.generate_expectations(
                      keys=target_table["keys"],
                      allowed_values=target_table["allowed_values"]
                      ),
                 live_table=True 
                 )
