resource "databricks_permissions" "pipeline-dlt_kkyla_surveys" {
  pipeline_id = databricks_pipeline.dlt_kkyla_surveys.id

  # DEVOPS PLATFORM
  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_PLATFORM"
    permission_level = "CAN_MANAGE"
  }

  # Data Factory
  access_control {
    service_principal_name = local.environmental[var.ENV].datafactory_app_id
    permission_level       = "CAN_RUN"
  }
}

