# ===============================================================================================================================
# kkyla dlt pipeline
# ===============================================================================================================================
resource databricks_pipeline dlt_kkyla_surveys {
  name = "dlt_kkyla_surveys"

  cluster {
    label               = "default"
    spark_env_vars      = {}
    spark_conf          = local.global_spark_conf
    node_type_id        = local.default_node
    driver_node_type_id = local.default_node
    autoscale {
      min_workers = 1
      max_workers = 2
      mode        = "ENHANCED"
    }
  }

  library {
    notebook {
      path = "${local.workspace_prefix}/pipelines/kkyla/dlt_kkyla_surveys"
    }
  }

  storage     = "${local.storage_prefix}/kkyla/surveys/"
  continuous  = false
  channel     = "CURRENT"
  development = var.ENV == "dev" ? true : false
  photon      = false
  target      = "dlt_kkyla"

  configuration = {
    environment     = var.ENV
    repository_path = "/Workspace${local.workspace_prefix}"
    target_schema   = "dlt_kkyla"
  }
}

