resource databricks_pipeline dlt_mintec {
  name = "dlt_mintec"

  cluster {
    label               = "default"
    spark_env_vars      = {}
    spark_conf          = local.global_spark_conf
    node_type_id        = local.default_node
    driver_node_type_id = local.default_node
    autoscale {
      min_workers = 1
      max_workers = 2
      mode        = "ENHANCED"
    }
  }

  library {
    notebook {
      path = "${local.workspace_prefix}/pipelines/mintec/dlt_mintec"
    }
  }

  catalog     = "silver_${var.ENV}"
  continuous  = false
  channel     = "PREVIEW"
  development = var.ENV != "prod" ? true : false
  photon      = false
  target      = "mintec"

  configuration = {
    environment     = var.ENV
    repository_path = "/Workspace${local.workspace_prefix}/pipelines/mintec"
    target_schema   = "dlt_mintec"
  }
}
