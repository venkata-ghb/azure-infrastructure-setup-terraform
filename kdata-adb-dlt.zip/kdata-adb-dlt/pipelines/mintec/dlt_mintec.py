# Databricks notebook source
# MAGIC %md
# MAGIC # Install dlt functions

# COMMAND ----------

sys.path.append("/Workspace/Repos/DLT/kdata-adb-dlt/dlt_functions/dltlib")

# COMMAND ----------

# MAGIC %md
# MAGIC # Imports

# COMMAND ----------

import dlt
import json
from pyspark.sql.functions import col, expr, current_timestamp
from pyspark.sql.types import TimestampType

# COMMAND ----------

from dltlib import *

# COMMAND ----------

# MAGIC %md
# MAGIC # Execution

# COMMAND ----------

options = {"cloudFiles.format": "parquet"}
env = spark.conf.get("environment")
process_cols = {}
target_schema = spark.conf.get("target_schema") # schema in the local hive metastore
source_system = "mintec"
input_path = f"abfss://raw@kdata{env}adls.dfs.core.windows.net/natural/mintec/deltalake/"
process_cols = {}

# The processing rules for the bronze and silver layers are written
# in a single json file in the dlt repository.
pipeline_path = spark.conf.get("repository_path")
table_config_path = f"{pipeline_path}/tables.json"
with open(file=table_config_path, mode="r") as file:
    pipeline_tables = json.load(file)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Ingest raw data to bronze layer

# COMMAND ----------

# MAGIC %md
# MAGIC Bronze execution currently handled with data factory `Mintec-API_to_Stage_to_Bronze_delta` pipeline

# COMMAND ----------

# MAGIC %md
# MAGIC ## Process data from bronze to silver

# COMMAND ----------

for source_table, target_table in pipeline_tables.items():
  if target_table.get("process_silver"):
    dltlib.create_silver_temp_table(
      source_table=f"bronze_{env}.mintec.{source_table}",
      target_table=target_table["target"],
      column_mapping=target_table["column_mapping"],
      expectations=dltlib.generate_expectations(
        keys=target_table["keys"],
        allowed_values=target_table["allowed_values"]
      ),
      use_cdc=False,
      source_system=source_system,
      bronze_load_timestamp_column_name="LoadDateTime",
      live_table=False,
    )
    dltlib.create_silver_table(
      source_system=source_system,
      target_table=target_table["target"],
      keys=target_table["keys"]
    )
