# Databricks notebook source
dbutils.widgets.text(name="env",defaultValue="dev")
dbutils.widgets.text(name="customer_ids",defaultValue="")

# COMMAND ----------

env = dbutils.widgets.get("env")
customer_ids = dbutils.widgets.get("customer_ids")
customer_id_list = customer_ids.split(",")

# COMMAND ----------

customer_data_path = f"abfss://raw@kdata{env}adls.dfs.core.windows.net/natural/GTSAPACR/KNA1"
table_name = f"bronze_dev.sap_sapuska.bronze_KNA1_gdpr"

# COMMAND ----------

from pyspark.sql.functions import col, md5, rand, concat, lit, hex
from pyspark.sql.utils import AnalysisException
from logger import get_logger

log = get_logger("gdpr_customer_removal")

# COMMAND ----------

customer_ids_str = dbutils.widgets.get("customer_ids")
customer_id_list = customer_ids_str.split(",")
log.info("Customer IDs from widget: %s", customer_ids)
log.info("Customer IDs as list: %s", customer_id_list)

quoted_customer_ids = [f"'{cid.strip()}'" for cid in customer_id_list]
in_clause = ", ".join(quoted_customer_ids)
log.info("Customer IDs in_clause: %s", in_clause)

sql_query = f"""
UPDATE bronze_{env}.sap_sapuska.bronze_KNA1_gdpr
SET STCD1 = SUBSTR(md5(STCD1), 1, 32),
SORTL = SUBSTR(md5(SORTL), 1, 32),
BronzeLoadDateTime = current_timestamp()
WHERE KUNNR IN ({in_clause})
"""

try:
    _ = spark.read.table(table_name)
    log.info("OK: %s exists", table_name)

    try:
        # execute gdpr removal only if the table exists
        spark.sql(sql_query)
    except (AnalysisException, Py4JJavaError, Exception) as e:
        log.error("SQL execution failed: %s", str(e))

except AnalysisException:
    log.error("%s does not exist", table_name)
