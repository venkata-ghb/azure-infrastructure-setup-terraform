# Databricks notebook source
from pyspark.sql.functions import *
import json
import time

# COMMAND ----------

dbutils.widgets.text("env", "dev")
dbutils.widgets.text("uc_schema", "sap_sapuska")

env = dbutils.widgets.get("env")
uc_schema = dbutils.widgets.get("uc_schema")

# COMMAND ----------
##
user = dbutils.secrets.get(scope="kv-kd-shared", key='kesprodata-databricks-writer-username')
pw = dbutils.secrets.get(scope="kv-kd-shared", key='postgresql-databricks-writer-password')
host = dbutils.secrets.get(scope="kv-kd-shared", key='kesprodata-postgres-fqdn')
database_name = "kesprodata"

# COMMAND ----------

  df = (spark.read
    .format("postgresql")
    .option("dbtable", "publish.contract_products")
    .option("host", host)
    .option("port", 5432)
    .option("database", database_name)
    .option("user", user)
    .option("password", pw)
    .load()
    )
df = df.drop("surrogate_key", "date_range")
df.createOrReplaceTempView("contract_product_temp")

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS gold_${env}.${uc_schema}.gold_contract_products (
# MAGIC   sapuska_code long,
# MAGIC   order_unit string,
# MAGIC   valid_from date,
# MAGIC   valid_to date,
# MAGIC   distribution_channel string,
# MAGIC   contract string,
# MAGIC   customer_id string,
# MAGIC   agreement_group string,
# MAGIC   customer_chain string,
# MAGIC   price_condition_value string,
# MAGIC   currency string,
# MAGIC   price_list string,
# MAGIC   price_condition_type string,
# MAGIC   condition_record_number string,
# MAGIC   data_lake_source string,
# MAGIC   load_date_time timestamp,
# MAGIC   _dbt_loaded_at timestamp,
# MAGIC   source_load_datetime timestamp,
# MAGIC   batch_number long,
# MAGIC   composite_ranges string,
# MAGIC   parent_ranges string
# MAGIC )
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC INSERT OVERWRITE gold_${env}.${uc_schema}.gold_contract_products SELECT * FROM contract_product_temp
