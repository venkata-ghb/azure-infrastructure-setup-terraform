from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col, lit

IGNORED_TIMESTAMP_COLS = (
    "LoadDateTime",
    "SilverLoadDateTime",
    "BronzeLoadDateTime",
    "GoldLoadDateTime",
    "psql_load_time",
)


def should_force_full_reload(psql_row_count: int, threshold: int) -> bool:
    return threshold > 0 and psql_row_count < threshold


def resolve_lookback_days(lookback_days: int | None, max_ldt) -> int | None:
    """Resolve the effective lookback window.
    If a lookback is configured but the target table is empty (`max_ldt is None`),
    disable the lookback (return None) so downstream compare logic treats the read as a full read.
    """
    return None if (lookback_days and max_ldt is None) else lookback_days


def compare_psql_keys(
    df: DataFrame,
    psql_df: DataFrame,
    keys: list,
    max_ldt,
    timestamp_col: str,
    lookback_days=None,
) -> DataFrame:
    """
    Compares records between the source DataFrame and the PostgreSQL DataFrame based on keys and timestamps.
    If key does not exist: insert new records. If key exists, update record if source timestamp exceeds targets'

    parameters:
    df: Source DataFrame
    psql_df: PostgreSQL DataFrame
    keys: Table keys used for joining
    max_ldt: Maximum LoadDateTime from the PostgreSQL table
    timestamp_col: Name of the timestamp column
    lookback_days: If set, psql_df is windowed and cannot be used to detect new keys — new rows are
                   captured by time_filtered_df instead (DLT guarantees fresh timestamps on new rows)

    returns DataFrame with compared records
    """
    # Records that have later timestamp than currently largest timestamp in the table
    time_filtered_df = df.filter(col(timestamp_col) > max_ldt)

    # Records that exist in the psql table but have a newer update in the source table
    existing_df = (
        df.alias("sdf")
        .join(psql_df.alias("pdf"), keys, "inner")
        .filter(f"sdf.{timestamp_col} > pdf.{timestamp_col}")
        .select("sdf.*")
    )

    if lookback_days:
        # psql_df is windowed, so a left_anti join would falsely assume all missing
        # records are new. Only use the new rows for the writer.
        compared_df = time_filtered_df.unionByName(existing_df)
    else:
        # Records that do not exist in the psql table but exist in the source table
        id_filtered_df = df.join(psql_df, keys, "left_anti")
        compared_df = (
            time_filtered_df.unionByName(id_filtered_df)
            .unionByName(existing_df)
        )

    return compared_df.dropDuplicates()


def align_to_psql_schema(df: DataFrame, psql_df: DataFrame) -> DataFrame:
    """
    Aligns a DataFrame to the schema of the PostgreSQL target table.

    Columns present in the DataFrame but absent from psql_df are dropped.
    Columns present in psql_df but absent from the DataFrame are added as null,
    cast to the matching type from psql_df. Column order follows psql_df.

    parameters:
    df: Source DataFrame
    psql_df: DataFrame representing the PostgreSQL target table (provides schema)

    returns DataFrame aligned to psql_df schema
    """
    # Postgres has only lowercase col names. The ADB silver names are
    # PascalCase (e.g. LoadDateTime).
    # The set operations (previously df_cols = set(df.columns)) caused these to
    # be simply dropped, as they didn't match the expected.
    #
    # Use case-insensitive comparison instead.
    df_cols_lower = {c.lower() for c in df.columns}
    select_exprs = [
        col(c) if c.lower() in df_cols_lower
        else lit(None).cast(psql_df.schema[c].dataType).alias(c)
        for c in psql_df.columns
    ]
    return df.select(select_exprs)


def compute_diff(curr_df: DataFrame, prev_df: DataFrame, keys: list) -> DataFrame:
    """
    Computes the difference between the current and previous version of a table.

    New rows (exist in curr, not in prev) and updated rows (exist in both, with changed
    non-key/non-timestamp columns) are flagged as 'iu'. Rows that existed in prev but not
    in curr are flagged as 'd'.

    parameters:
    curr_df: DataFrame representing the current version of the table
    prev_df: DataFrame representing the previous version of the table
    keys: column names used as join keys

    returns DataFrame with a 'changeflag' column ('iu' or 'd')
    """
    cols = curr_df.columns
    where_clauses = [
        f"NOT(curr_df.{col} <=> prev_df.{col})"
        for col in cols
        if col not in keys
        if col not in IGNORED_TIMESTAMP_COLS
    ]
    where_clause = " OR ".join(where_clauses)

    new_rows_df = (
        curr_df.alias("curr_df")
        .join(prev_df.alias("prev_df"), keys, "left_anti")
        .withColumn("changeflag", lit("iu"))
    )

    if where_clauses:
        updated_rows_df = (
            curr_df.alias("curr_df")
            .join(prev_df.alias("prev_df"), keys, "inner")
            .filter(where_clause)
            .select("curr_df.*")
            .withColumn("changeflag", lit("iu"))
        )
    else:
        updated_rows_df = (
            SparkSession.getActiveSession()
            .createDataFrame([], curr_df.schema)
            .withColumn("changeflag", lit("iu"))
        )

    deleted_rows_df = (
        prev_df.alias("prev_df")
        .join(curr_df.alias("curr_df"), keys, "left_anti")
        .withColumn("changeflag", lit("d"))
    )

    return (
        new_rows_df
        .unionByName(updated_rows_df)
        .unionByName(deleted_rows_df)
        .dropDuplicates()
    )
