# Databricks notebook source
from logger import get_logger

log = get_logger("warmup_cluster")

log.info("Try to warm up Spark resources")
