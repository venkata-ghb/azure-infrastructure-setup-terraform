# Databricks notebook source
import json
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

from pyspark.sql import DataFrame
from pyspark.sql.functions import col, current_timestamp, desc, lit
from pyspark.sql.types import *

from psql_writer_logic import align_to_psql_schema, compare_psql_keys, compute_diff, resolve_lookback_days, should_force_full_reload
import version
from logger import get_logger

log = get_logger("psql_writer")

log.info("psql_writer | build: %s | sha: %s", version.BUILD_NUMBER, version.GIT_SHA)

# COMMAND ----------

# Note! If you are running these notebooks on your own environment, the parameters on the second place are read. The job pipelines are using the values from the pipelines configuration.

dbutils.widgets.text("env", "dev")
dbutils.widgets.text(
    "pipeline_path", "/Workspace/Users/your.name@kesko.fi/kdata-adb-dlt/pipelines/sap"
)
dbutils.widgets.text("max_workers", "5")
dbutils.widgets.text("writer_config", "kesprodata_sap_silver")
dbutils.widgets.text("target_database", "default_placeholder")  # This is a placeholder. The actual value is set in the job configuration as per target

# COMMAND ----------

env = dbutils.widgets.get("env")
pipeline_path = dbutils.widgets.get("pipeline_path")
max_workers = int(dbutils.widgets.get("max_workers"))
writer_config_name = f"writer_config_{dbutils.widgets.get('writer_config')}"
ignore_table_config_path = f"{pipeline_path}/config_files/ignore_columns.json"
target_database = dbutils.widgets.get("target_database")

# COMMAND ----------

# Read writer config file
if not os.path.exists(f"{pipeline_path}/config_files/{writer_config_name}.json"):
    raise FileNotFoundError(
        f"Config file not found: {pipeline_path}/config_files/{writer_config_name}.json"
    )
with open(
    file=f"{pipeline_path}/config_files/{writer_config_name}.json", mode="r"
) as file:
    writer_config = json.load(file)

# Read table config file
target_table_config_path = (
    f"{pipeline_path}/config_files/{writer_config.get('table_config_filename')}.json"
)
with open(file=target_table_config_path, mode="r") as file:
    target_tables = json.load(file)

# Read ignore table config file
if not os.path.exists(ignore_table_config_path):
    raise FileNotFoundError(f"Config file not found: {ignore_table_config_path}")

if (
    os.path.exists(ignore_table_config_path)
    and os.path.getsize(ignore_table_config_path) > 0
):
    with open(file=ignore_table_config_path, mode="r") as file:
        ignore_table_config = json.load(file)

# COMMAND ----------

# Get the target database configs
target_db_list = []

if target_database == "kesprodata":
    # Get connection details from config
    conn_details = writer_config.get("connection_credentials")
    old_secret_scope = conn_details.get("secret_scope")
    user = dbutils.secrets.get(scope=old_secret_scope, key=conn_details.get("user_key"))
    pw = dbutils.secrets.get(scope=old_secret_scope, key=conn_details.get("pw_key"))
    host = dbutils.secrets.get(scope=old_secret_scope, key=conn_details.get("host_key"))

    # Get connection details for new kespro-data from config
    kd_conn_details = writer_config.get("kespro-data_connection_credentials")
    new_secret_scope = kd_conn_details.get("secret_scope")
    db_user = dbutils.secrets.get(scope=new_secret_scope, key=kd_conn_details.get("user_key"))
    db_pw = dbutils.secrets.get(scope=new_secret_scope, key=kd_conn_details.get("pw_key"))
    db_host = dbutils.secrets.get(scope=new_secret_scope, key=kd_conn_details.get("host_key"))

    database_name = kd_conn_details.get("database_name") # same for both

    target_db_list = [
        {
            "db_name": "old_kesprodata",
            "host": host,
            "port": 5432,
            "database": database_name,
            "user": user,
            "password": pw,
        },
        {
            "db_name": "new_kesprodata",
            "host": db_host,
            "port": 5432,
            "database": database_name,
            "user": db_user,
            "password": db_pw,
        },
    ]

elif target_database == "kespro_availability_service":
    # Get connection details from config
    conn_details = writer_config.get("connection_credentials")
    secret_scope = conn_details.get("secret_scope")
    db_user = dbutils.secrets.get(scope=secret_scope, key=conn_details.get("user_key"))
    db_pw = dbutils.secrets.get(scope=secret_scope, key=conn_details.get("pw_key"))
    db_host = dbutils.secrets.get(scope=secret_scope, key=conn_details.get("host_key"))
    database_name = conn_details.get("database_name")

elif target_database == "kespro_price_service":
    # Get connection details from config
    conn_details = writer_config.get("connection_credentials")
    secret_scope = conn_details.get("secret_scope")
    db_user = dbutils.secrets.get(scope=secret_scope, key=conn_details.get("user_key"))
    db_pw = dbutils.secrets.get(scope=secret_scope, key=conn_details.get("pw_key"))
    db_host = dbutils.secrets.get(scope=secret_scope, key=conn_details.get("host_key"))
    database_name = conn_details.get("database_name")

else:
    raise ValueError(
        "Target database is not set. Please set the target_database in the jobs task terraform configuration or replace placeholder if running notebook manually"
    )


# COMMAND ----------

# Get writer options from config
writer_options = writer_config.get("writer_options")
catalog_header = writer_options.get("catalog_header")
catalog = f"{catalog_header}_{env}"
uc_schema = writer_options.get("uc_schema")
schema_prefix = writer_options.get("schema_prefix")
timestamp_col = writer_options.get("timestamp_col")
write_mode = writer_options.get("write_mode")
write_timestamp_col = writer_options.get("write_timestamp_col")


# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Functions

# COMMAND ----------


def read_max_loaddatetime(table:str, log=log):
    fn_log = log.bind(fn="read_max_loaddatetime")
    start_time = time.time()
    max_loaddatetime = (
        spark.read.format("postgresql")
        .option("dbtable", f'(SELECT MAX("{timestamp_col}") AS max_ldt FROM {table}) t')
        .option("host", db_host)
        .option("port", 5432)
        .option("database", database_name)
        .option("user", db_user)
        .option("password", db_pw)
        .load()
        .collect()[0][0]
    )
    fn_log.info(
        "Max LoadDateTime: %s (read in %s seconds)",
        max_loaddatetime, round(time.time() - start_time, 2)
    )
    return max_loaddatetime


def read_deduplicated_source_information(
    table:str, keys:list, timestamp_col:str, filter_conditions:str=None, lookback_days:int=None, log=log
):
    """
    Read source information from the postgres database.

    parameters:
    table: Name of the table
    keys: List of key columns for deduplication
    timestamp_col: Name of the timestamp column used for deduplication
    filter_conditions: Optional SQL WHERE clause for filtering
    lookback_days: Optional number of days to limit the scan window. When set, only reads records within the last N days.

    returns max_loaddatetime, schema, df, lookback_days (lookback_days returned to caller to keep the rest of the logic consistent in case of fallback to full read)
    """
    fn_log = log.bind(fn="read_deduplicated_source_information")
    start_time = time.time()
    key_str = ", ".join([f'"{k}"' for k in keys])

    where_parts = []
    if filter_conditions:
        where_parts.append(filter_conditions)
    if lookback_days:
        where_parts.append(
            f"\"{timestamp_col}\" >= NOW() - INTERVAL '{lookback_days} days'"
        )

    where_clause = f"WHERE {' AND '.join(where_parts)}" if where_parts else ""

    pushdown_query = f"""
    (
        SELECT DISTINCT ON ({key_str}) *
        FROM {table}
        {where_clause}
        ORDER BY {key_str}, "{timestamp_col}" DESC
    ) AS deduplicated_source
    """

    fn_log.info(
        "Reading deduplicated source with lookback: %s, filter: %s",
        lookback_days if lookback_days else 'None',
        filter_conditions if filter_conditions else 'None'
    )

    df = (
        spark.read.format("postgresql")
        .option("dbtable", pushdown_query)
        .option("host", db_host)
        .option("port", 5432)
        .option("database", database_name)
        .option("user", db_user)
        .option("password", db_pw)
        # Optimization: Tell Spark to fetch more rows per trip
        .option("fetchsize", "100000")
        .load()
    )

    max_loaddatetime = read_max_loaddatetime(table, log=fn_log)

    effective_lookback_days = resolve_lookback_days(lookback_days, max_loaddatetime)

    # Fallback: if the table is truly empty (truncated), retry without lookback to write all rows.
    # An empty lookback window on a non-empty table is not the same — max_loaddatetime is None
    # only when the entire table has no rows.
    if effective_lookback_days is None and lookback_days is not None:
        fn_log.warning("Table appears to be empty (truncated). Falling back to full read.")
        return read_deduplicated_source_information(
            table, keys, timestamp_col, filter_conditions, lookback_days=effective_lookback_days, log=log
        )

    schema = df.columns
    fn_log.info("Read deduplicated source in %s seconds", round(time.time() - start_time, 2))

    # Return the effective lookback_days (may be None after fallback) so callers can apply correct compare logic.
    return max_loaddatetime, schema, df, effective_lookback_days


def read_source_information(table:str, log=log):
    """
    Read source information from the postgres database.
    This method will essentially read the entire table into a DataFrame for later processing.

    parameters:
    table: Name of the table

    returns max_loaddatetime, schema, df
    """
    fn_log = log.bind(fn="read_source_information")
    start_time = time.time()
    fn_log.info("Read psql source information")

    max_loaddatetime = read_max_loaddatetime(table, log=fn_log)

    start_time = time.time()
    fn_log.info("Load psql source table data")
    df = (
        spark.read.format("postgresql")
        .option("dbtable", table)
        .option("host", db_host)
        .option("port", 5432)
        .option("database", database_name)
        .option("user", db_user)
        .option("password", db_pw)
        .load()
    )
    fn_log.info("Loaded psql source table data in %s seconds", round(time.time() - start_time, 2))

    schema = df.columns

    return max_loaddatetime, schema, df


# COMMAND ----------


def semi_empty_rows_check(silver_df: DataFrame, psql_df: DataFrame, table: str, keys: list, log=log) -> DataFrame:
    """
    Checks for semi-empty rows in the silver DataFrame compared to the PostgreSQL DataFrame.
    Semi-empty rows are those that have never had any other value besides null or empty string,
    but if a column has had a value previously, an empty or null row will be written to PSQL.
    A predefined list of fields - ignore_table_config - will be excluded from the review.

    parameters:
    silver_df: Silver DataFrame
    psql_df: PostgreSQL DataFrame
    table: Name of the table
    table_config: Configuration dictionary for the table

    Returns:
    DataFrame with filtered rows
    """

    def get_ignored_columns(table_name: str, ignore_table_config: dict) -> set:
        """Returns the columns to be excluded, as defined in the configuration, based on the name of the Silver table"""
        ignore_table_config = ignore_table_config.get(table_name, {})
        return set(ignore_table_config.get("columns", []))

    fn_log = log.bind(fn="semi_empty_rows_check")
    fn_log.info("Check semi-empty rows")
    all_columns = psql_df.columns
    compare_columns = [column for column in all_columns if column not in keys]

    # Remove columns that are not in psql_df
    compare_columns = [
        column for column in compare_columns if column in psql_df.columns
    ]

    # Remove columns that contain only null or empty values in the silver table or in the PostgreSQL table
    ignored_columns = get_ignored_columns(table, ignore_table_config)
    fn_log.info("Columns ignored from filtering: %s", ignored_columns)
    for colname in ignored_columns:
        if colname in compare_columns:
            compare_columns.remove(colname)
    if compare_columns:
        fn_log.info(
            "Columns that require filtering (if column is boolean, it is excluded from filtering): %s",
            compare_columns
        )
    new_rows_df = silver_df.alias("sdf").join(psql_df.alias("pdf"), keys, "leftanti")
    existing_rows_df = (
        silver_df.alias("sdf").join(psql_df.alias("pdf"), keys, "inner").select("sdf.*")
    )

    # Write conditions for semi empty rows. Meaning that we filter out rows that have never had any other value besides null or empty string
    # However, if column has had value previously, empty or null row will be written to postgres

    conditions = [
        col(f"sdf.{column}").isNotNull() & (col(f"sdf.{column}") != "")
        if not isinstance(
            silver_df.schema[column].dataType, BooleanType
        )  # Checking if column is not boolean, boolean comparisons causes crashing
        else col(f"sdf.{column}").isNotNull()
        for column in compare_columns
    ]
    condition = conditions[0] if conditions else None
    # Very verbose, and overflows the entire ADB logging. Enable only for debugging.
    fn_log.debug("Conditions: %s", conditions)

    # If no columns have conditions for filtering, then semi empty row check is not needed
    # Return same df without filtering
    ## This is left for debugging unnecessary semi-empty checks but does nothing currently
    if not conditions:
        fn_log.info("No semi_empty_rows_check conditions found. No check required")
        # return new_rows_df.unionByName(existing_rows_df)

    for c in conditions[1:]:
        condition = condition | c

    filtered_df = new_rows_df.filter(condition)

    # This section calculates and prints the impact of the filtering step. This is done to understand the impact of this step better.

    # Count the number of rows that were kept after applying the filter.
    kept_rows_after_filter = filtered_df.count()

    fn_log.info("New rows kept after semi-empty filter: %s", f"{kept_rows_after_filter:,}")
    return filtered_df.unionByName(existing_rows_df)


# COMMAND ----------


def union_tables_without_semi_empty_check(silver_df: DataFrame, psql_df: DataFrame, table: str, keys: list, log=log) -> DataFrame:
    """
    NOTE: This function includes the unioning of old and new data from semi_empty_rows_check for cases that do not require semi-empty rows check.
    Since the unioning seems to only be included inside this function and all tables are using this check, use this if you dont want the semi_empty_rows_check

    Union the silver DataFrame compared with the PostgreSQL DataFrame.
    Semi-empty rows are those that have never had any other value besides null or empty string,
    but if a column has had a value previously, an empty or null row will be written to PSQL.
    A predefined list of fields - ignore_table_config - will be excluded from the review.

    parameters:
    silver_df: Silver DataFrame
    psql_df: PostgreSQL DataFrame
    table: Name of the table
    table_config: Configuration dictionary for the table

    Returns:
    DataFrame with no filters
    """
    fn_log = log.bind(fn="union_tables_without_semi_empty_check")
    fn_log.info("Union tables without semi-empty rows check")
    new_rows_df = silver_df.alias("sdf").join(psql_df.alias("pdf"), keys, "leftanti")
    existing_rows_df = (
        silver_df.alias("sdf").join(psql_df.alias("pdf"), keys, "inner").select("sdf.*")
    )

    return new_rows_df.unionByName(existing_rows_df)


# COMMAND ----------


def create_table_version_diff(df: DataFrame, table: str, keys: list, psql_df: DataFrame, write_config: dict, log=log) -> DataFrame:
    """
    Extracts the two latest versions of the given table using Databricks table versioning
    and prepares a WHERE clause for detecting inserted or updated rows.

    parameters:
    table: Name of the table in format catalog.schema.table_name
    keys: table keys that are used to join the table with itself
    psql_df: the dataframe mapping to the source table in postgres
    write_config: dict of additional configs for the writing

    returns df with changeflag column
    """
    fn_log = log.bind(fn="create_table_version_diff")
    fn_log.info("Create table version diff")
    table_name = table.split(".")[2]

    # Apply full-reload threshold: if psql row count is below the configured minimum,
    # override write_mode to overwrite so stale/sparse target tables get rebuilt cleanly.
    reload_threshold = write_config.get("full_reload_on_rows_lower_threshold", 0) if write_config else 0
    psql_row_count = psql_df.count()
    if should_force_full_reload(psql_row_count, reload_threshold):
        fn_log.info(
            "psql row count (%s) below threshold (%s), forcing full reload (overwrite, changeflag: iu)",
            format(psql_row_count, "_"),
            format(reload_threshold, "_")
        )
        return df.withColumn("changeflag", lit("iu"))

    # Get the latest two versions from Delta table history
    history_df = spark.sql(f"DESCRIBE HISTORY {table}")
    latest_versions = (
        history_df.select("version").orderBy("version", ascending=False).limit(2)
    )

    # Read the latest two versions of the table
    version_list = [row["version"] for row in latest_versions.collect()]

    if len(version_list) < 2:
        raise ValueError(f"Not enough versions available for table {table_name}")
    # Read current and previous version of table utilising delta table time travel
    curr_df = df
    prev_df = spark.read.option("versionAsOf", version_list[1]).table(table)

    return compute_diff(curr_df, prev_df, keys)


# COMMAND ----------


def psql_data_write(
    trgt_name: str,
    df: DataFrame,
    write_mode: str,
    target_table: str,
    host: str,
    database_name: str,
    user: str,
    pw: str,
    port: int = 5432,
    batch_size: int = 100000,
    num_partitions: int = 16,
    log=log,
):
    """Write passed df to postgres. Port, batch_size and num_partitions defined by defaults but can be overwritten if required"""
    fn_log = log.bind(fn="psql_data_write")
    fn_log.info("Start write to table: %s in databse %s. Write mode: %s", target_table, trgt_name, write_mode)

    psql_writer = (
        df.write.format("postgresql")
        .option("dbtable", target_table)
        .option("host", host)
        .option("port", port)
        .option("database", database_name)
        .option("user", user)
        .option("password", pw)
        .option("batchSize", batch_size)
        .option("numPartitions", num_partitions)
        .option("sslmode", "require")
    )

    if write_mode == "overwrite":
        psql_writer = psql_writer.mode("overwrite").option("truncate", "true")
    else:
        psql_writer = psql_writer.mode("append")

    psql_writer.save()
    fn_log.info("Write ok to table: %s in database: %s", target_table, trgt_name)
    return True  # On Exception, exception raised is returned to as_completed and re-raised upon result()


# COMMAND ----------


def prepare_write(df: DataFrame, target_table: str, write_mode: str, target_dbs: list, log=log):
    """Prepares concurrent psql writes into target databases according to targets dictionary list for the passed target table"""
    fn_log = log.bind(fn="prepare_write")
    fn_log.info("Prepare write")
    db_write_success = True  # tracks overall status of both writes
    db_results = {
        t["db_name"]: {} for t in target_dbs
    }  # init with db_names, tracks per db write results
    max_wrkrs = max(len(target_dbs), 2)
    fn_log.info("MAX WORKERS: %s", max_wrkrs)
    with ThreadPoolExecutor(max_workers=max_wrkrs) as ex:
        # Start threads
        futu_to_db = {
            ex.submit(
                psql_data_write,
                t["db_name"],
                df,
                write_mode,
                target_table,
                t["host"],
                t["database"],
                t["user"],
                t["password"],
                log=fn_log,
            ): t["db_name"]
            for t in target_dbs
        }  # -> Dict like {Future: db_name}
        # Check results as threads complete
        for fut in as_completed(futu_to_db):
            db_name = futu_to_db[fut]
            try:
                _ = (
                    fut.result()
                )  # var is not needed, only used to check for Exceptions during write
                db_results[db_name][target_table] = True
            except Exception as e:
                # Also catches exceptions returned to and re-raised by future.result()
                db_write_success = False
                db_results[db_name][target_table] = False
                fn_log.error(
                    "Unexpected Error reading results to target '%s'. Error: %s: %s",
                    db_name, type(e).__name__, e
                )

    fn_log.info(
        "All DB writes success status: %s. Per database write results: %s",
        db_write_success, db_results
    )
    # Return load info for main process for handling/aggregated failure logging
    return db_write_success, db_results


# COMMAND ----------


def write_psql_tables(table: str, target: dict, target_dbs: list = []):
    fn_log = log.bind(table=table, fn="write_psql_tables")
    fn_log.info("Processing table")
    # Fetch table information from config
    start_time = time.time()
    # table_name = f"{schema_prefix}_table"
    target_schema_name = target.get("target_schema")
    target_table_name = target.get("target_name")
    filter_conditions = target.get("filter_conditions")
    filter_columns = target.get("filter_columns")
    lookback_days = target.get("lookback_days")

    # Get list of write options for the table
    keys = [key for key in target.get("keys")]
    write_options = target.get("write_options")
    write_config = target.get("write_config", {})

    # Full naming of table, including catalogs and schemas in KData and PSQL
    source_table = f"{catalog}.{uc_schema}.{schema_prefix}_{table}"
    target_table = f"{target_schema_name}.{target_table_name}"

    # Fetch target information, max loaddatetime, schema of table in PSQL, and the PSQL table as df
    if "compare_keys" in write_options:
        max_ldt, schema, psql_df, lookback_days = read_deduplicated_source_information(
            target_table, keys, timestamp_col, filter_conditions, lookback_days, log=fn_log
        )
    else:
        max_ldt, schema, psql_df = read_source_information(target_table, log=fn_log)
        # Reading only the latest change for each record based on keys
        sorted_pdf = psql_df.orderBy(*keys, desc(timestamp_col))
        psql_df = sorted_pdf.dropDuplicates(keys)

    target_has_rows = max_ldt is not None
    fn_log.info("Target table max LoadDateTime: %s. Target has rows: %s", max_ldt, target_has_rows) if target_has_rows else fn_log.info("Target table '%s' appears to be empty. No max LoadDateTime value found. Some filter conditions will not be applied", table)

    # Read source table from Unity Catalog
    df = spark.read.format("delta").option("ignoreChanges", "true").table(source_table)

    if "create_table_version_diff" in write_options and target_has_rows:
        df = create_table_version_diff(df, source_table, keys, psql_df, write_config, log=fn_log)

    # If write timestamp is specified, add that column with current timestamp
    if write_timestamp_col:
        fn_log.info("Writing timestamp col")
        df = df.withColumn(write_timestamp_col, current_timestamp())

    # Filtering
    if "semi_empty_rows_check" in write_options:
        # Checking for semi empty rows, filtering out rows that have originally been null
        df = semi_empty_rows_check(df, psql_df, table, keys, log=fn_log)
    if "union_tables_without_semi_empty_check" in write_options and target_has_rows:
        # If no semi_empty check, but need to union new and old data and filter with compare_keys after
        df = union_tables_without_semi_empty_check(df, psql_df, table, keys, log=fn_log)

    if "compare_keys" in write_options and target_has_rows:
        # Persist psql_df to optimize the following join operations,
        # since psql_df is used multiple times in the compare_psql_keys function
        psql_df.cache()
        fn_log.info("Compare psql keys")
        df = compare_psql_keys(df, psql_df, keys, max_ldt, timestamp_col, lookback_days)

    if "higher_max_timestamp" in write_options and target_has_rows:
        if max_ldt != None:
            fn_log.info(
                "Filter higher_max_timestamp: Only keep records where silver timestamp '%s' > '%s' (psql max_ldt)",
                timestamp_col, max_ldt
            )
            df = df.filter(col(timestamp_col) > max_ldt)

    # Select and where clauses to source table.
    # By default, selecting all columns present in target table in PSQL, without where conditions
    # Both can be overridden from target config
    if filter_columns:
        df = df.select(filter_columns)
    else:
        df = align_to_psql_schema(df, psql_df)

    # Filter with where clause in table config
    if filter_conditions:
        df = df.filter(filter_conditions)

    ### Writing

    df = df.dropDuplicates()
    df.cache()
    rows_written = df.count()
    fn_log.info("Mode: %s | Rows identified: %s", write_mode, f"{rows_written:,}")

    if rows_written == 0 and write_mode == "overwrite":
        fn_log.warning("Table is empty. Overwrite with truncate=true will leave the Postgres table empty.")
        return rows_written, "Empty", {}

    db_load_status = True
    db_load_dict = {}
    try:
        # Check target_database to determine if write to multiple dbs is required and call the correct function accordingly
        if target_database == "kesprodata":
            # prepare_write for multiple dbs or direct psql_data_write for single db
            db_load_status, db_load_dict = prepare_write(
                df, target_table, write_mode, target_dbs
            )
            # db_load_status = psql_data_write("old_kesprodata", df, write_mode, target_table, host, database_name, user, pw,) #old
            # db_load_status = psql_data_write("new_kesprodata", df, write_mode, target_table, kd_host, kd_database_name, kd_user, kd_pw) #new
        else:
            # For those cases that do not have multiple db writes required ie. price service and availability service
            print(f"Starting to write to target_database: {target_database}. target table: {target_table}")
            # Below row has pass database_name twice due to the temporary 2 db writes to kesprodata to keep thefunction call logic consistent
            db_load_status = psql_data_write(database_name, df, write_mode, target_table, db_host, database_name, db_user, db_pw)
    finally:
        df.unpersist()
        psql_df.unpersist()

    end_time = time.time()
    final_time = end_time - start_time
    fn_log.info(
        "Completed: %s rows uploaded in %.2f seconds. Status: %s",
        f"{rows_written:,}", final_time, db_load_status
    )
    # Return info about table-level process and db-level writes for handling/aggregated failure logging
    return rows_written, db_load_status, db_load_dict


# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Execution

# COMMAND ----------

log.info("Start run")
write_success = True
row_counts = {}
db_fails_list = []  # Currently adds Falses only for tables with errors
start_time = time.time()

with ThreadPoolExecutor(max_workers=max_workers) as executor:
    # Start threads
    futures = {
        executor.submit(write_psql_tables, table, target, target_db_list): table
        for table, target in target_tables.items()
    }  # -> Dict like {Future: db_name}
    # Check results as threads complete
    for future in as_completed(futures):
        table = futures[future]
        try:
            count, table_load_status, dbs_load_rslt_dict = future.result()
            row_counts[table] = count
            if table_load_status is False:
                # This handles Exceptions from db-write threads that were already handled in prepare_write() if literal False is returned
                write_success = False
                db_fails_list.append(dbs_load_rslt_dict)
                log.error(
                    "Error writing to table %s. Status %s. Per database results so far: %s",
                    table, table_load_status, dbs_load_rslt_dict
                )
        except Exception as e:
            # Also catches exceptions returned to and re-raised by future.result() from table-level threads
            write_success = False
            db_fails_list.append(
                {"table": table, "error": f"Unexpected Error: {type(e).__name__}: {e}"}
            )
            log.error(
                "Unexpected Error while reading table results. No status returned for %s: %s: %s",
                table, type(e).__name__, e
            )

log.info("All writes done. Write_success status: %s", write_success)

# Print summary
if write_success:
    total_rows = sum(row_counts.values())
    log.info("\n" + "=" * 50)
    log.info("Upload Summary")
    log.info("=" * 50)
    for table, count in row_counts.items():
        log.info("  %s: %s rows", table, f"{count:,}")
    log.info("-" * 50)
    log.info("Total: %s rows across %s tables", f"{total_rows:,}", len(row_counts))
    log.info("=" * 50 + "\n")

# Print list of dicts with failures from table and db-level threads and raise Exception
if not write_success:
    log.error("Per database load status failed: %s", db_fails_list)
    raise Exception("One or more parallelized items failed")

log.info("End run")
