resource databricks_job dlt_sapacr {
  name = "dlt_sapacr_${var.ENV}"

  # Cluster configs

  job_cluster {
    job_cluster_key = "sapacr-cluster"
    new_cluster {
      autoscale {
        min_workers = 2
        max_workers = 10
      }
      spark_version  = "17.3.x-scala2.13"
      node_type_id   = lookup({
        dev  = "Standard_D4s_v5"
        test = "Standard_D8s_v5"
        prod = "Standard_D8s_v5"
      }, var.ENV)
      spark_conf     = local.global_spark_conf
      spark_env_vars = { PYSPARK_PYTHON = "/databricks/python3/bin/python3" }
      data_security_mode = "SINGLE_USER"
    }
  }
  schedule {
    quartz_cron_expression = lookup({
        dev  = "0 0 6 * * ?"
        test = "0 30 * * * ?"
        prod = "0 0/30 * * * ?"
      }, var.ENV)
    timezone_id            = "Europe/Helsinki"
    pause_status           = "UNPAUSED"
  }
  run_as {
    service_principal_name = local.environmental[var.ENV].app_id
  }
  timeout_seconds = 3600

  # Bronze & silver load tasks

  task {
    task_key = databricks_pipeline.dlt_sapacr_external.name

    pipeline_task {
      pipeline_id = databricks_pipeline.dlt_sapacr_external.id
    }
  }

  # Writer warmup task

  task {
    task_key        = "warmup_cluster"
    job_cluster_key = "sapacr-cluster"

    notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/sap/warmup_cluster"
    }
  }

  # Gold tasks

  task {
    task_key        = "write_gold_tables"
    job_cluster_key = "sapacr-cluster"

    depends_on {
      task_key = "dlt_sapacr_external"
    }

    notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/sap/create_gold_tables_sap"
      base_parameters = {
        env = var.ENV
        config_path = "/Workspace${local.workspace_prefix}/pipelines/sap/gold_table_scripts"
      }
    }
  }

  # Kesprodata tasks

  task {
    task_key        = "write_kesprodata_gold_tables"
    job_cluster_key = "sapacr-cluster"

    depends_on {
      task_key = "write_gold_tables"
    }

    notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/sap/psql_writer"
      base_parameters = {
        env            = var.ENV
        pipeline_path  = "/Workspace${local.workspace_prefix}/pipelines/sap"
        max_workers    = 5
        writer_config  = "kesprodata_sap_gold"
        target_database = "kesprodata"
      }
    }
  }

  task {
    task_key        = "write_kesprodata_silver_tables"
    job_cluster_key = "sapacr-cluster"

    depends_on {
      task_key = "dlt_sapacr_external"
    }

    notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/sap/psql_writer"
      base_parameters = {
        env            = var.ENV
        pipeline_path  = "/Workspace${local.workspace_prefix}/pipelines/sap"
        max_workers    = 5
        writer_config  = "kesprodata_sap_silver"
        target_database = "kesprodata"
      }
    }
  }

  # Search service bus tasks

  task {
    task_key        = "write_kespro_search_fast_data_servicebus"
    job_cluster_key = "sapacr-cluster"

    depends_on {
      task_key = "write_kesprodata_silver_tables"
    }

    notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/sap/search_service_bus"
      base_parameters = {
        env            = var.ENV
        pipeline_path  = "/Workspace${local.workspace_prefix}/pipelines/sap"
        max_workers    = 5
        writer_config  = "search_servicebus"
      }
    }
  }

  # Price service tasks

  task {
    task_key        = "write_kespro_price_service_silver_tables"
    job_cluster_key = "sapacr-cluster"

    depends_on {
      task_key = "dlt_sapacr_external"
    }

    notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/sap/psql_writer"
      base_parameters = {
        env            = var.ENV
        pipeline_path  = "/Workspace${local.workspace_prefix}/pipelines/sap"
        max_workers    = 5
        writer_config  = "kespro_price_service_sap_silver"
        target_database = "kespro_price_service"
      }
    }
  }

  task {
    task_key        = "write_kespro_price_service_gold_tables"
    job_cluster_key = "sapacr-cluster"

    depends_on {
      task_key = "write_gold_tables"
    }

    notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/sap/psql_writer"
      base_parameters = {
        env            = var.ENV
        pipeline_path  = "/Workspace${local.workspace_prefix}/pipelines/sap"
        max_workers    = 5
        writer_config  = "kespro_price_service_sap_gold"
        target_database = "kespro_price_service"
      }
    }
  }

  # Availability service tasks

  task {
    task_key        = "write_kespro_availability_service_silver_tables"
    job_cluster_key = "sapacr-cluster"

    depends_on {
      task_key = "dlt_sapacr_external"
    }

    notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/sap/psql_writer"
      base_parameters = {
        env            = var.ENV
        pipeline_path  = "/Workspace${local.workspace_prefix}/pipelines/sap"
        max_workers    = 5
        writer_config  = "kespro_availability_service_sap_silver"
        target_database = "kespro_availability_service"
      }
    }
  }
}

# ==============================================================================================================================================


resource databricks_job gdpr_customer_removal {
  name = "gdpr_customer_removal_${var.ENV}"

  job_cluster {
    job_cluster_key = "gdpr_customer"
    new_cluster {
      num_workers    = 4
      spark_version  = "17.3.x-scala2.13"
      node_type_id   = "Standard_D4s_v5"
      spark_conf     = local.global_spark_conf
      spark_env_vars = { PYSPARK_PYTHON = "/databricks/python3/bin/python3" }
      data_security_mode = "SINGLE_USER"
    }
  }

  task {
    task_key        = "gdpr_customer_removal"
    job_cluster_key = "gdpr_customer"

     notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/sap/gdpr_customer_removal"
      base_parameters = {
        env             = var.ENV
		    customer_ids    = ""
      }
    }
  }

  task {
    task_key = "${databricks_pipeline.dlt_sapacr_kna1_external.name}"
    pipeline_task {
      pipeline_id = databricks_pipeline.dlt_sapacr_kna1_external.id
    }
    depends_on {
      task_key = "gdpr_customer_removal"
    }
  }
}

# ==============================================================================================================================================

resource databricks_job gold_contractproduct {
  name = "load_gold_contractproduct_${var.ENV}"

  job_cluster {
    job_cluster_key = "contractproduct"
    new_cluster {
      num_workers    = 4
      spark_version  = "17.3.x-scala2.13"
      node_type_id   = "Standard_D4s_v5"
      spark_conf     = local.global_spark_conf
      spark_env_vars = { PYSPARK_PYTHON = "/databricks/python3/bin/python3" }
      data_security_mode = "SINGLE_USER"
    }
  }
  schedule {
    quartz_cron_expression = "0 0 4 * * ?"
    timezone_id = "Europe/Helsinki"
    pause_status = "UNPAUSED"
  }

  task {
    task_key        = "gold_contractproduct"
    job_cluster_key = "contractproduct"


     notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/sap/gold_contractproduct"
      base_parameters = {
        env             = var.ENV
        uc_schema       = "sap_sapuska"
      }
    }
  }

}

# ==============================================================================================================================================

resource databricks_job rewrite_gold_schema {
  name = "rewrite_gold_schema_${var.ENV}"

  job_cluster {
    job_cluster_key = "rewrite_gold"
    new_cluster {
      num_workers    = 4
      spark_version  = "17.3.x-scala2.13"
      node_type_id   = "Standard_D4s_v5"
      spark_conf     = local.global_spark_conf
      spark_env_vars = { PYSPARK_PYTHON = "/databricks/python3/bin/python3" }
      data_security_mode = "SINGLE_USER"
    }
  }

  task {
    task_key        = "rewrite_gold_schema"
    job_cluster_key = "rewrite_gold"

     notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/sap/rewrite_gold_schema"
      base_parameters = {
        env             = var.ENV
        uc_schema       = "sap_sapuska"
      }
    }
  }

  task {
    task_key        = "write_gold_tables"
    job_cluster_key = "rewrite_gold"

    depends_on {
      task_key = "rewrite_gold_schema"
    }

    notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/sap/create_gold_tables_sap"
      base_parameters = {
        env = var.ENV
      }
    }
  }

}
