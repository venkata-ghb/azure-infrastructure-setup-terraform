resource "databricks_permissions" "job-dlt_sapacr" {
  job_id = databricks_job.dlt_sapacr.id

  # DEVOPS PLATFORM
  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_PLATFORM"
    permission_level = "CAN_MANAGE"
  }

  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_FUTURICEDEV"
    permission_level = "CAN_MANAGE"
  }

  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_GTKESPRODATA"
    permission_level = "CAN_MANAGE"
  }

}

resource "databricks_permissions" "job-gdpr_customer_removal" {

  job_id = databricks_job.gdpr_customer_removal.id
  # DEVOPS PLATFORM
  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_PLATFORM"
    permission_level = "CAN_MANAGE"
  }

  # SP run access
  access_control {
    service_principal_name = local.environmental[var.ENV].app_id
    permission_level       = "CAN_MANAGE_RUN"
  }

  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_FUTURICEDEV"
    permission_level = "CAN_MANAGE"
  }

  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_GTKESPRODATA"
    permission_level = "CAN_MANAGE"
  }

}


resource "databricks_permissions" "job-gold_contractproduct" {

  job_id = databricks_job.gold_contractproduct.id
  # DEVOPS PLATFORM
  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_PLATFORM"
    permission_level = "CAN_MANAGE"
  }

  # SP run access
  access_control {
    service_principal_name = local.environmental[var.ENV].app_id
    permission_level       = "CAN_MANAGE_RUN"
  }

  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_FUTURICEDEV"
    permission_level = "CAN_MANAGE"
  }

  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_GTKESPRODATA"
    permission_level = "CAN_MANAGE"
  }

}

resource "databricks_permissions" "job-rewrite_gold_schema" {
  job_id = databricks_job.rewrite_gold_schema.id

  # DEVOPS PLATFORM
  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_PLATFORM"
    permission_level = "CAN_MANAGE"
  }

  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_FUTURICEDEV"
    permission_level = "CAN_MANAGE"
  }

  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_GTKESPRODATA"
    permission_level = "CAN_MANAGE"
  }

}
