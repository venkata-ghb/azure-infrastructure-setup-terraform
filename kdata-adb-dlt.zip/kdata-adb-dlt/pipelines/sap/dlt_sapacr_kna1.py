# Databricks notebook source
import sys
lib_path = "/Workspace/KDATA-DLT/dlt_functions/dltlib"
sys.path.insert(0, lib_path)


# COMMAND ----------

import dlt
import json
from pyspark.sql.functions import col, expr, current_timestamp
from pyspark.sql.types import TimestampType

# COMMAND ----------

from dltlib import *

# COMMAND ----------

options = {"cloudFiles.format": "parquet"}
env = spark.conf.get("environment")
inputPath = f"abfss://raw@kdata{env}adls.dfs.core.windows.net/natural/GTSAPACR/KNA1"
process_cols = {
    "LoadDateTime": col("AEDATTM").cast(TimestampType())
}

target_schema = spark.conf.get("target_schema") # schema in the local hive metastore
source_system = "gtsap"

# The processing rules for the bronze and silver layers are written
# in a single json file in the dlt repository.
pipeline_path = spark.conf.get("repository_path")
table_config_path = f"{pipeline_path}/kna1.json"
with open(file=table_config_path, mode="r") as file:
    pipeline_tables = json.load(file)

# COMMAND ----------

for table in pipeline_tables.keys():
    # Create the bronze tables
    dltlib.ingest_raw_data(
      table=table,
      sparkOptions=options,
      inputPath=f"{inputPath}",
      process_cols = process_cols
    )

    # Create the cdc tables by reading the change data feed of the bronze tables.
    dltlib.create_cdc_table(
      schema=target_schema,
      table=table,
      temporary=True
    )

# COMMAND ----------

for source_table, target_table in pipeline_tables.items():
  if target_table.get("process_silver"):
    # Tables cannot be loaded to silver layer if the bronze layer tables do not
    # exist before the pipeline starts. The first instance of the pipeline generates the bronze tables,
    # the second instance generates the cdc table,
    # temporary table and the silver table.
    if dltlib.check_if_table_exists(f"{target_schema}.bronze_{source_table}"):
        dltlib.create_silver_temp_table(
          source_table=source_table,
          target_table=target_table["target"],
          column_mapping=target_table["column_mapping"],
          expectations=dltlib.generate_expectations(
              keys=target_table["keys"],
              allowed_values=target_table["allowed_values"]
          ),
          use_cdc = True,
          source_system = 'GTSAP'
      )

    dltlib.create_silver_table_scd1(
        source_system=source_system,
        target_table=target_table["target"],
        keys=target_table["keys"],
        sequence_by="BronzeLoadDateTime"
    )
