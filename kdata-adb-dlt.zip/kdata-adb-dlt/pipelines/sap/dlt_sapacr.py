# Databricks notebook source
# MAGIC %md
# MAGIC # Install dlt functions

# COMMAND ----------

import sys
lib_path = "/Workspace/KDATA-DLT/dlt_functions/dltlib"
sys.path.insert(0, lib_path)

# COMMAND ----------

# MAGIC %md
# MAGIC # Imports

# COMMAND ----------

import dlt
import json
from pyspark.sql.functions import col
from pyspark.sql.types import TimestampType
from logger import get_logger
import version

log = get_logger("dlt_sapacr")

log.info("dlt_sapacr | build: %s | sha: %s", version.BUILD_NUMBER, version.GIT_SHA)

# COMMAND ----------

from dltlib import *

# COMMAND ----------

# MAGIC %md
# MAGIC # Execution

# COMMAND ----------

options = {"cloudFiles.format": "parquet"}
env = spark.conf.get("environment")
inputPath = f"abfss://raw@kdata{env}adls.dfs.core.windows.net/natural/GTSAPACR/"
process_cols = {
    "LoadDateTime": col("AEDATTM").cast(TimestampType())
}
lookback_days = 60
filter_column = "BronzeLoadDateTime"
apply_filter = True

target_schema = spark.conf.get("target_schema") # schema in the local hive metastore
source_system = "gtsap"

# The processing rules for the bronze and silver layers are written
# in a single json file in the dlt repository.
pipeline_path = spark.conf.get("repository_path")
table_config_path = f"{pipeline_path}/tables.json"
log.info(f"Read table config path: {table_config_path}")
with open(file=table_config_path, mode="r") as file:
    pipeline_tables = json.load(file)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Ingest raw data to bronze layer

# COMMAND ----------
log.info("Start bronze ingest")
for table in pipeline_tables.keys():
    # Create the bronze tables.
    log.info(f"Create bronze table: {table}")
    dltlib.ingest_raw_data(
      table=table,
      sparkOptions=options,
      inputPath=f"{inputPath}/{table}",
      process_cols = process_cols
    )
log.info("End bronze ingest")
# COMMAND ----------

# MAGIC %md
# MAGIC ## Process data from bronze to silver

# COMMAND ----------

# Hae asetus: halutaanko käyttää CDF:ää tässä ajossa
#use_cdc = spark.conf.get("dlt_use_cdc", "false").lower() == "true"
log.info("Start silver processing with lookback_days %s, apply_filter %s, filter_column %s", lookback_days, apply_filter, filter_column)
for source_table, target_table in pipeline_tables.items():
  if target_table.get("process_silver"):
    log.info(f"Process silver from source_table: {source_table}. Target table: {target_table['target']}")
    dltlib.create_silver_temp_table(
          source_table=source_table,
          target_table=target_table["target"],
          column_mapping=target_table["column_mapping"],
          expectations=dltlib.generate_expectations(
              keys=target_table["keys"],
              allowed_values=target_table["allowed_values"]
          ),
          lookback_days = lookback_days,
          apply_filter = apply_filter,
          filter_column = filter_column,
          use_cdc = False,
          source_system = 'GTSAP'
      )
    dltlib.create_silver_table(
          source_system=source_system,
          target_table=target_table["target"],
          keys=target_table["keys"],
          sequence_by="LoadDateTime"
      )
log.info("End silver processing")
