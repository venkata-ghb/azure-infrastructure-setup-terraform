# Databricks notebook source
# MAGIC %md
# MAGIC # Install dlt functions

# COMMAND ----------

import sys
lib_path = "/Workspace/KDATA-DLT/dlt_functions/dltlib"
sys.path.insert(0, lib_path)

# COMMAND ----------

# MAGIC %md
# MAGIC # Imports

# COMMAND ----------

import dlt
import json
from pyspark.sql.functions import col, expr, current_timestamp
from pyspark.sql.types import TimestampType
from logger import get_logger

log = get_logger("dlt_confluent_sapacr")

# COMMAND ----------

from dltlib import *

# COMMAND ----------

# MAGIC %md
# MAGIC # Execution

# COMMAND ----------

options = {"cloudFiles.format": "parquet"}
env = spark.conf.get("environment")
inputPath = f"abfss://raw@kdata{env}adlsexternal.dfs.core.windows.net/natural/CONFLUENT/"
process_cols = {"LoadDateTime": col("KAFKA_ROWTIME").cast(TimestampType())}
target_schema = spark.conf.get("target_schema") # schema in the local hive metastore
source_system = "gtsap"

lookback_days = 60
filter_column = "BronzeLoadDateTime"
apply_filter = True

# The processing rules for the bronze and silver layers are written
# in a single json file in the dlt repository.
pipeline_path = spark.conf.get("repository_path")
table_config_path = f"{pipeline_path}/confluent_tables.json"
log.info("Read table config path: %s", table_config_path)
with open(file=table_config_path, mode="r") as file:
    pipeline_tables = json.load(file)

# COMMAND ----------
log.info("Start bronze ingest")
def ingest_raw_data(table, inputPath, process_cols = None, **sparkOptions):
    @dlt.table(
        name=f"bronze_{table}",
        comment="This table was created with Autoloader.",
        table_properties={"quality": "bronze", "delta.enableChangeDataFeed": "True"},
    )
    def load_dynamic_table_bronze():
        # Autoloader can infer schema for file types such as parquet, json and csv.
        df = (
            spark.readStream.format("cloudFiles")
            .options(**sparkOptions["sparkOptions"])
            .option("cloudFiles.schemaHints", "KAFKA_ROWTIME TIMESTAMP")
            .load(inputPath)
        )
        # If function call includes calculated columns, they are included into returned data frame here
        #
        if process_cols:
            for column_name, column_statement in process_cols.items():
                df = df.withColumn(column_name, column_statement)


        df = df.withColumn("BronzeLoadDateTime", current_timestamp())

        return df
log.info("End bronze ingest")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Ingest raw data to bronze layer

# COMMAND ----------

for table in pipeline_tables.keys():
    # Create the bronze tables.
    log.info("Create bronze table: %s", table)
    ingest_raw_data(
      table=table,
      sparkOptions=options,
      inputPath=f"{inputPath}/{table}",
      process_cols = process_cols
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Process data from bronze to silver

# COMMAND ----------
log.info("Start silver processing with lookback_days %s, apply_filter %s, filter_column %s", lookback_days, apply_filter, filter_column)
for source_table, target_table in pipeline_tables.items():
  if target_table.get("process_silver"):
    log.info("Process silver from source_table: %s. Target table: %s", source_table, target_table['target'])

    dltlib.create_silver_temp_table(
          source_table=source_table,
          target_table=target_table["target"],
          column_mapping=target_table["column_mapping"],
          expectations=dltlib.generate_expectations(
              keys=target_table["keys"],
              allowed_values=target_table["allowed_values"]
          ),
          lookback_days = lookback_days,
          apply_filter = apply_filter,
          filter_column = filter_column,
          use_cdc = False,
          source_system = 'GTSAP'
      )
    dltlib.create_silver_table(
          source_system=source_system,
          target_table=target_table["target"],
          keys=target_table["keys"],
          sequence_by="LoadDateTime"
      )
log.info("End silver processing")
