# Databricks notebook source
import os
import concurrent.futures
import time
from logger import get_logger

log = get_logger("create_gold_tables_sap")

dbutils.widgets.text(name="env",defaultValue="dev")
dbutils.widgets.text("config_path", "/Workspace/Repos/DLT/kdata-adb-dlt/pipelines/sap/gold_table_scripts")
env = dbutils.widgets.get("env")
config_path = dbutils.widgets.get("config_path")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Create Gold tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Initialize tables

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists gold_${env}.sap_sapuska.gold_merchandise_hierarchy (
# MAGIC   merchandise_category string,
# MAGIC   merchandise_category_reference_product int,
# MAGIC   merchandise_management_system_class_type int,
# MAGIC   segment_short_description_fi string,
# MAGIC   merchandise_category_long_description_fi string,
# MAGIC   segment_short_description_sv string,
# MAGIC   merchandise_category_long_description_sv string,
# MAGIC   segment_short_description_en string,
# MAGIC   merchandise_category_long_description_en string,
# MAGIC   upper_level_merchandise_hierarchy_id string,
# MAGIC   lvl string,
# MAGIC   GoldLoadDateTime timestamp
# MAGIC )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table: product_global_basic_data

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists gold_${env}.sap_sapuska.gold_product_global_basic_data (
# MAGIC     product_sap_id bigint,
# MAGIC     base_unit string,
# MAGIC     primary_base_unit_gtin string,
# MAGIC     order_unit string,
# MAGIC     primary_order_unit_gtin string,
# MAGIC     quantity_of_base_units_in_order_unit decimal(10,3),
# MAGIC     logistic_variant_link_to_base_unit_gtin string,
# MAGIC     logistic_variant_link_to_base_unit_product_sap_id string,
# MAGIC     multipack_link_to_single_product_gtin string,
# MAGIC     multipack_link_to_single_product_sap_id string,
# MAGIC     amount_of_single_products_in_multipack int,
# MAGIC     short_description_fi_order_unit string,
# MAGIC     product_marketing_name_sap_fi string,
# MAGIC     default_vendor_in_global_product_master string,
# MAGIC     vendor_name_1 string,
# MAGIC     vendor_product_id string,
# MAGIC     vendor_country string,
# MAGIC     product_country_of_origin string,
# MAGIC     brand_id int,
# MAGIC     brand_description string,
# MAGIC     sub_brand_id int,
# MAGIC     sub_brand_description string,
# MAGIC     product_family_id int,
# MAGIC     product_family_name string,
# MAGIC     assortment_list_type_id string,
# MAGIC     product_type string,
# MAGIC     product_category string,
# MAGIC     merchandise_category_segment string,
# MAGIC     merchandise_category_level_3_sub_category string,
# MAGIC     merchandise_category_level_2 string,
# MAGIC     gt_kespro_kcm_product_in_product_master_vksk int,
# MAGIC     height_of_base_unit decimal(10,3),
# MAGIC     width_of_base_unit decimal(10,3),
# MAGIC     length_of_base_unit decimal(10,3),
# MAGIC     unit_of_dimensions string,
# MAGIC     net_weight_base_unit decimal(10,3),
# MAGIC     gross_weight_base_unit decimal(10,3),
# MAGIC     unit_of_weight string,
# MAGIC     net_content decimal(10,3),
# MAGIC     comparison_price_number_of_units string,
# MAGIC     gross_content decimal(10,3),
# MAGIC     creation_date_of_sap_product date,
# MAGIC     purchase_blocking_status_global string,
# MAGIC     purchase_blocking_valid_from date,
# MAGIC     sales_blocking_status_global string,
# MAGIC     sales_blocking_valid_from date,
# MAGIC     discontinuation_reason_id string,
# MAGIC     discontinuation_date date,
# MAGIC     pda_ordering_block string,
# MAGIC     alcohol_license_level string,
# MAGIC     tobacco_license_level string,
# MAGIC     tobacco_license_eu string,
# MAGIC     self_care_product string,
# MAGIC     age_limit int,
# MAGIC     accounting_level string,
# MAGIC     purchasing_group_id_global string,
# MAGIC     purchasing_group_name string,
# MAGIC     vat_classification_code string,
# MAGIC     fruits_and_vegetables_sort_code string,
# MAGIC     replaced_product_sap_id string,
# MAGIC     global_deletion_flag string,
# MAGIC     novelty_product_valid_from date,
# MAGIC     transportation_group string,
# MAGIC     kesko_exclusive_sale_product string,
# MAGIC     exclusive_sale_start_date date,
# MAGIC     exclusive_sale_end_date date,
# MAGIC     prelaunch_indicator string,
# MAGIC     prelaunch_start_date date,
# MAGIC     prelaunch_end_date date,
# MAGIC     purchasing_method string,
# MAGIC     imported_by_kesko string,
# MAGIC     pricing_reference_product string,
# MAGIC     pricing_profile_generic_product string,
# MAGIC     alcohol_percentage decimal(10,2),
# MAGIC     dilution_factor int,
# MAGIC     price_type_forced_global string,
# MAGIC     opflag string,
# MAGIC     GoldLoadDateTime timestamp,
# MAGIC     LoadDateTime timestamp
# MAGIC )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table: product_additional_taxes_and_surcharges

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists gold_${env}.sap_sapuska.gold_product_additional_taxes_and_surcharges (
# MAGIC   product_sap_id bigint,
# MAGIC   condition_type string,
# MAGIC   unit_of_measure string,
# MAGIC   calculated_tax_value_for_product_uom decimal(12,6),
# MAGIC   fixed_condition_value_rate decimal(12,6),
# MAGIC   numerator_for_conversion_to_base_units_of_measure int,
# MAGIC   denominator_for_conversion_to_base_units_of_measure int,
# MAGIC   condition_currency_or_percent_sap string,
# MAGIC   valid_from date,
# MAGIC   valid_to date,
# MAGIC   tax_class_product string,
# MAGIC   load_date_time timestamp,
# MAGIC   GoldLoadDateTime timestamp
# MAGIC )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table: product_bill_of_material

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS gold_${env}.sap_sapuska.gold_bom_bill_of_material (
# MAGIC   parent_sap_product_id BIGINT,
# MAGIC   parent_uom_where_bom_is_linked STRING,
# MAGIC   parent_primary_gtin_where_bom_is_linked STRING,
# MAGIC   site_id STRING,
# MAGIC   bom_id STRING,
# MAGIC   bom_usage_type INT,
# MAGIC   bom_version_id STRING,
# MAGIC   sequence_number_of_bom_line INT,
# MAGIC   component_sap_product_id BIGINT,
# MAGIC   component_base_unit STRING,
# MAGIC   component_primary_gtin STRING,
# MAGIC   component_quantity_in_BOM DECIMAL(10, 3),
# MAGIC   creation_date DATE,
# MAGIC   created_by STRING,
# MAGIC   change_date DATE,
# MAGIC   changed_by STRING,
# MAGIC   bom_component_valid_from DATE,
# MAGIC   bom_item_type STRING,
# MAGIC   bom_line_number INT,
# MAGIC   component_scrap_percentage DECIMAL(5, 2),
# MAGIC   product_category STRING,
# MAGIC   opflag STRING,
# MAGIC   load_date_time timestamp,
# MAGIC   GoldLoadDateTime TIMESTAMP
# MAGIC )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table: contract_product

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS gold_${env}.sap_sapuska.gold_contract_product (
# MAGIC   aekey STRING,
# MAGIC   client STRING,
# MAGIC   application STRING,
# MAGIC   condition_type STRING,
# MAGIC   sales_organization INT,
# MAGIC   distribution_channel INT,
# MAGIC   customer_chain STRING,
# MAGIC   customer_group STRING,
# MAGIC   price_list STRING,
# MAGIC   site STRING,
# MAGIC   customer_number STRING,
# MAGIC   sales_office STRING,
# MAGIC   agreement_group_1 STRING,
# MAGIC   product_sap_id STRING,
# MAGIC   uom STRING,
# MAGIC   valid_to DATE,
# MAGIC   valid_from DATE,
# MAGIC   condition_record_number STRING,
# MAGIC   condition_value_rate DECIMAL(10, 2),
# MAGIC   condition_currency_or_percent_sap STRING,
# MAGIC   fixed_condition_value_rate DECIMAL(10,2),
# MAGIC   contract_exists BOOLEAN,
# MAGIC   LoadDateTime TIMESTAMP,
# MAGIC   Opflag STRING,
# MAGIC   GoldLoadDateTime TIMESTAMP
# MAGIC )

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### Run queries

# COMMAND ----------

#Read gold script files and store in dictionary
query_files = [filename for filename in os.listdir(config_path) if filename.endswith(".sql")]
queries = {}
for filename in query_files:
 with open(f"{config_path}/{filename}") as query_string:
   # Set correct environment based on widget value
   queries[filename.removesuffix(".sql")] = query_string.read().replace("${env}", env)
   query_string.close()

# COMMAND ----------

#Wrap in function to parallellize

def run_gold_script(query_name):
    start_time = time.time()
    log.info("Write query_name %s with script from: '%s'", query_name, config_path)
    spark.sql(queries.get(query_name))
    end_time = time.time()
    elapsed_time = round(end_time - start_time, 2)
    log.info("Writing %s complete, duration: %s seconds", query_name, elapsed_time)

# COMMAND ----------

success = True
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
    futures = {query_name: executor.submit(run_gold_script, query_name) for query_name in list(queries.keys())}
    concurrent.futures.wait(futures.values())

    for query_name, future in futures.items():
        if future.exception() is not None:
            success = False
            log.error("Error inserting to table %s: %s", query_name, future.exception())

if not success:
    raise Exception("Writing to gold table failed: One or more parallelized items failed")

# COMMAND ----------

# MAGIC %md
# MAGIC
