resource databricks_pipeline dlt_sapacr_external {
  name = "dlt_sapacr_external"

  cluster {
    label          = "default"
    spark_env_vars = {}
    spark_conf = local.global_spark_conf
    autoscale {
      min_workers = lookup({
        dev  = 1
        test = 2
        prod = 2
      }, var.ENV)
      max_workers = lookup({
        dev  = 2
        test = 8
        prod = 8
      }, var.ENV)
      mode = "ENHANCED"
    }
  }

  library {
    notebook {
      path = "${local.workspace_prefix}/pipelines/sap/dlt_sapacr"
    }
  }

  library {
    notebook {
      path = "${local.workspace_prefix}/pipelines/sap/dlt_confluent_sapacr"
    }
  }

  storage     = "abfss://raw@kdata${var.ENV}adls.dfs.core.windows.net/natural/GTSAPACR/"
  continuous  = false
  channel     = "CURRENT"
  development = var.ENV == "dev" ? true : false
  photon      = false
  target      = var.ENV == "prod" ? "dlt_sapacr_${var.ENV}" : "dlt_sapacr_test"

  configuration = {
    environment     = var.ENV
    repository_path = "/Workspace${local.workspace_prefix}/pipelines/sap"
    target_schema   = var.ENV == "prod" ? "dlt_sapacr" : "dlt_sapacr_test"
  }
}


resource databricks_pipeline dlt_sapacr_kna1_external {
  name = "dlt_sapacr_kna1_external"

  cluster {
    label          = "default"
    spark_env_vars = {}
    spark_conf = local.global_spark_conf
    autoscale {
      min_workers = lookup({
        dev  = 1
        test = 2
        prod = 2
      }, var.ENV)
      max_workers = lookup({
        dev  = 2
        test = 8
        prod = 8
      }, var.ENV)
      mode = "ENHANCED"
    }
  }

  library {
    notebook {
      path = "${local.workspace_prefix}/pipelines/sap/dlt_sapacr_kna1"
    }
  }

  storage     = "abfss://raw@kdata${var.ENV}adls.dfs.core.windows.net/natural/GTSAPACR/"
  continuous  = false
  channel     = "CURRENT"
  development = var.ENV == "dev" ? true : false
  photon      = false
  target      = var.ENV == "prod" ? "dlt_sapacr_kna1_${var.ENV}" : "dlt_sapacr_kna1_test"

  configuration = {
    environment     = var.ENV
    repository_path = "/Workspace${local.workspace_prefix}/pipelines/sap"
    target_schema   = var.ENV == "prod" ? "dlt_sapacr_kna1" : "dlt_sapacr_kna1_test"
  }
}
