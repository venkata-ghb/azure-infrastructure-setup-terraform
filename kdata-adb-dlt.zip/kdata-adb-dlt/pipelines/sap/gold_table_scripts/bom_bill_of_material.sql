INSERT OVERWRITE gold_${env}.sap_sapuska.gold_bom_bill_of_material

with bom as (
  select
    cast(ltrim('0', pb.parent_sap_product_id) as bigint) as parent_sap_product_id,
    case 
      when bu.bom_usage_type = 7
        then parent_uom.uom_commercial
      else parent_mara_base_uom.uom_commercial
    end as parent_uom_where_bom_is_linked,
    case 
      when bu.bom_usage_type = 7
        then uom.primary_gtin
      else parent_bd.primary_base_unit_gtin
    end as parent_primary_gtin_where_bom_is_linked,
    pb.site_id,
    pb.bom_id,
    cast(pb.bom_usage_type as INT),
    pb.bom_version_id,
    cast(bi.sequence_number_of_bom_line as INT),
    bi.component_sap_product_id,
    component.uom_commercial as component_base_unit,
    component_bd.primary_base_unit_gtin as component_primary_gtin,
    cast(bi.component_quantity_in_BOM as DECIMAL(10,3)),
    cast(pb.creation_date as DATE),
    pb.created_by,
    cast(pb.change_date as DATE),
    pb.changed_by,
    cast(bis.bom_component_valid_from as DATE),
    bi.bom_item_type,
    cast(bi.bom_line_number as INT),
    cast(bi.component_scrap_percentage as DECIMAL(5, 2)),
    parent_bd.product_category,
    pb.opflag,
    greatest(
      pb.loaddatetime,
      bh.loaddatetime,
      bis.loaddatetime,
      bu.loaddatetime,
      bi.loaddatetime,
      component_bd.loaddatetime,
      parent_bd.loaddatetime,
      uom.loaddatetime
    ) as load_date_time
  from silver_${env}.sap_sapuska.silver_gtsap_product_to_bom_link pb
  inner join silver_${env}.sap_sapuska.silver_gtsap_bom_header bh
    on bh.bom_id = pb.bom_id
    and bh.bom_version_id = pb.bom_version_id
    and bh.opflag != 'D'
  inner join silver_${env}.sap_sapuska.silver_gtsap_bom_item_selection bis
    on bis.bom_category = bh.bom_category
    and bis.bom_id = bh.bom_id
    and bis.bom_version_id = bh.bom_version_id
    and bis.opflag != 'D'
  left join silver_${env}.sap_sapuska.silver_gtsap_bom_link_to_uom bu
    on pb.parent_sap_product_id = bu.parent_sap_product_id
    and pb.bom_usage_type = bu.bom_usage_type
    and bu.bom_version_id = bis.bom_version_id
    and bu.opflag != 'D'
  inner join silver_${env}.sap_sapuska.silver_gtsap_bom_items bi
    on bi.bom_category = bis.bom_category
    and bi.bom_id = bis.bom_id
    and bi.bom_item_id = bis.bom_item_id
    and bi.opflag != 'D'
  left join silver_${env}.sap_sapuska.silver_gtsap_units_of_measures_language_specific parent_uom 
    on parent_uom.uom_sap_technical = bu.uom_to_which_bom_version_is_linked
    and parent_uom.language = 'U'
  left join silver_${env}.sap_sapuska.silver_gtsap_units_of_measures_language_specific parent_mara_base_uom
    on parent_mara_base_uom.uom_sap_technical = bh.parent_base_unit 
    and parent_mara_base_uom.language = 'U'
  left join silver_${env}.sap_sapuska.silver_gtsap_units_of_measures_language_specific component
    on component.uom_sap_technical = bi.component_base_unit  
    and component.language = 'U'
  inner join silver_${env}.sap_sapuska.silver_gtsap_product_global_basic_data component_bd
    on component_bd.product_sap_id = bi.component_sap_product_id
    and component_bd.opflag != 'D'
  inner join silver_${env}.sap_sapuska.silver_gtsap_product_global_basic_data as parent_bd
    on parent_bd.product_sap_id = pb.parent_sap_product_id
    and parent_bd.opflag != 'D'
  left join silver_${env}.sap_sapuska.silver_gtsap_product_units_of_measures uom
    on uom.product_sap_id = pb.parent_sap_product_id 
    and uom.unit_of_measure = parent_bd.order_unit
    and bu.uom_to_which_bom_version_is_linked = uom.unit_of_measure
    and uom.opflag != 'D'
)

select distinct
*,
current_timestamp as GoldLoadDateTime
from bom 