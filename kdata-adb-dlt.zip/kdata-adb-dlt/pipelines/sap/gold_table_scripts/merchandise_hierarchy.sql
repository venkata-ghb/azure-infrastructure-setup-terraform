INSERT OVERWRITE gold_${env}.sap_sapuska.gold_merchandise_hierarchy

with mc as (
    select chd.class_id,
        chd.internal_class_id,
        chd.merchandise_management_system_class_type,
        mcs.merchandise_category_reference_product,
        chd.LoadDateTime
    from silver_${env}.sap_sapuska.silver_gtsap_class_header_data chd
        left join silver_${env}.sap_sapuska.silver_gtsap_merchandise_category_segment_and_reference_product mcs
        on chd.class_id = mcs.merchandise_category_segment
    where class_type = '026'
        and merchandise_management_system_class_type in (0, 1)
),
--Language-specific CTEs
fi_desc as (
    select sdl.merchandise_category_segment,
        sdl.segment_short_description_20_char,
        sdl.segment_long_description_60_char,
        sdl.language
    from silver_${env}.sap_sapuska.silver_gtsap_merchandise_category_segment_descriptions_by_language sdl
    where language = 'U'
),
se_desc as (
    select sdl.merchandise_category_segment,
        sdl.segment_short_description_20_char,
        sdl.segment_long_description_60_char,
        sdl.language
    from silver_${env}.sap_sapuska.silver_gtsap_merchandise_category_segment_descriptions_by_language sdl
    where language = 'V'
),
en_desc as (
    select sdl.merchandise_category_segment,
        sdl.segment_short_description_20_char,
        sdl.segment_long_description_60_char,
        sdl.language
    from silver_${env}.sap_sapuska.silver_gtsap_merchandise_category_segment_descriptions_by_language sdl
    where language = 'E'
),
cod_fi as (
    select internal_class_id,
        description,
        language
    from silver_${env}.sap_sapuska.silver_gtsap_class_object_descriptions_by_language
    where language = 'U'
),
cod_sv as (
    select internal_class_id,
        description,
        language
    from silver_${env}.sap_sapuska.silver_gtsap_class_object_descriptions_by_language
    where language = 'V'
),
cod_en as (
    select internal_class_id,
        description,
        language
    from silver_${env}.sap_sapuska.silver_gtsap_class_object_descriptions_by_language
    where language = 'E'
),
olc_alias as (
    select *
    from silver_${env}.sap_sapuska.silver_gtsap_object_linkage_to_class olc
        left join silver_${env}.sap_sapuska.silver_gtsap_class_header_data as ALIAS1
        on olc.internal_class_id = ALIAS1.internal_class_id
    where ALIAS1.class_type = '026'
        and object_or_class_indicator = 'K'
)
select
    mc.class_id as merchandise_category,
    cast(mc.merchandise_category_reference_product as INT),
    cast(mc.merchandise_management_system_class_type as INT),
    fd.segment_short_description_20_char as segment_short_description_fi,
    case
        when mc.merchandise_management_system_class_type = 1 then fd.segment_long_description_60_char
        when mc.merchandise_management_system_class_type = 0 then cod_fi.description
    end as merchandise_category_long_description_fi,
    sd.segment_short_description_20_char as segment_short_description_sv,
    case
        when mc.merchandise_management_system_class_type = 1 then sd.segment_long_description_60_char
        when mc.merchandise_management_system_class_type = 0 then cod_sv.description
    end as merchandise_category_long_description_sv,
    ed.segment_short_description_20_char as segment_short_description_en,
    case
        when mc.merchandise_management_system_class_type = 1 then ed.segment_long_description_60_char
        when mc.merchandise_management_system_class_type = 0 then cod_en.description
    end as merchandise_category_long_description_en,
    olc_alias.class_id as upper_level_merchandise_hierarchy_id,
    case
        when length(olc_alias.class_id) = 1 then 4
        when length(mc.class_id) = 1 then 5
        when length(mc.class_id) = 4 then 1
        when length(mc.class_id) = 3 then 2
        else 3
    end as lvl,
    current_timestamp as GoldLoadDateTime
from mc
    left join fi_desc fd on mc.class_id = fd.merchandise_category_segment
    left join se_desc sd on mc.class_id = sd.merchandise_category_segment
    left join en_desc ed on mc.class_id = ed.merchandise_category_segment
    left join cod_fi on mc.internal_class_id = cod_fi.internal_class_id
    left join cod_sv on mc.internal_class_id = cod_sv.internal_class_id
    left join cod_en on mc.internal_class_id = cod_en.internal_class_id
    left join olc_alias on mc.internal_class_id = olc_alias.object