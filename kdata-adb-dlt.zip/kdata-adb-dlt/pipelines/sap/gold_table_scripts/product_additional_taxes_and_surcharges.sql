INSERT OVERWRITE gold_${env}.sap_sapuska.gold_product_additional_taxes_and_surcharges

with global_product_data_with_uom as (
  select
    pd.*,
    numerator_for_conversion_to_base_units_of_measure,
    denominator_for_conversion_to_base_units_of_measure,
    uom.unit_of_measure,
    greatest(
      pd.LoadDateTime,
      uom.loaddatetime
    ) as load_date_time,

    -- pre-calculate helper values for the maths below
    pd.base_unit = uom.unit_of_measure as product_is_base_unit,
    pd.order_unit = uom.unit_of_measure as product_is_order_unit,
    nullif(trim(pd.ser_classification), '') is not null as product_is_ser_product,
    pd.imported_by_kesko = 'X' as product_is_imported_by_kesko,
    (numerator_for_conversion_to_base_units_of_measure / denominator_for_conversion_to_base_units_of_measure) as base_unit_conversion_factor,
    net_content::decimal(38,18) as precise_net_content,
    dilution_factor::decimal(38,18) as precise_dilution_factor,
    (alcohol_percentage::decimal(38,18) / 100.0::decimal(38,18)) as alcohol_ratio
    --
  from silver_${env}.sap_sapuska.silver_gtsap_product_global_basic_data pd
  inner join silver_${env}.sap_sapuska.silver_gtsap_product_units_of_measures uom
    on pd.product_sap_id = uom.product_sap_id and (
      pd.base_unit = uom.unit_of_measure -- join on base unit
      or
      pd.order_unit = uom.unit_of_measure -- join on order unit
    )
  where
    pd.opflag != "D" and
    uom.opflag != "D"
), filtered_taxclass as (
  select
    condition_type,
    condition_record_number,
    tax_class_product,
    valid_from,
    valid_to,
    loaddatetime
  from silver_${env}.sap_sapuska.silver_gtsap_a526_country_taxclass_for_customer_and_product
  where country = "FI"
  and tax_class_customer = "1"
  and opflag != "D"
), condition_values as (
  select
    condition_record_number,
    condition_currency_or_percent_sap,
    case
      when condition_currency_or_percent_sap = 'EUR' then condition_value_rate::decimal(38,18)
      when condition_currency_or_percent_sap = 'EUR3' then (condition_value_rate::decimal(38,18) / 10.0)
      when condition_currency_or_percent_sap = 'EUR4' then (condition_value_rate::decimal(38,18) / 100.0)
    end as fixed_condition_value_rate,
    pricing_unit_of_measure,
    calculation_type,
    opflag,
    loaddatetime
  from silver_${env}.sap_sapuska.silver_gtsap_price_conditions_values_and_item_data
  where opflag != "D"
), ZRVV_alcohol_and_sugar_excise_tax as (
  select
    cc.product_sap_id,
    condition_type,
    unit_of_measure,
    pc.fixed_condition_value_rate,
    pricing_unit_of_measure,
    pc.condition_currency_or_percent_sap,
    numerator_for_conversion_to_base_units_of_measure,
    denominator_for_conversion_to_base_units_of_measure,
    valid_from,
    valid_to,
    tx.tax_class_product,
    -- Multiply the value with
    fixed_condition_value_rate * base_unit_conversion_factor *
    -- ... one of the below
    case
      when excise_tax_id_zvv in ('1', '2', '3', '4', '5', '6', 'J', 'W')
      then pd.precise_net_content
      when cc.excise_tax_id_zvv in ('7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'L', 'N', 'P')
      then (pd.precise_net_content * alcohol_ratio)
      when cc.excise_tax_id_zvv in ('S', 'T', 'U', 'V', 'X', 'Y')
      then (pd.precise_net_content * (1.0 + pd.precise_dilution_factor))
      when cc.excise_tax_id_zvv in ('M', 'K')
      then pd.net_weight_base_unit
    end as calculated_tax_value_for_product_uom,
    --
    greatest(
      tx.loaddatetime,
      pc.loaddatetime,
      cc.loaddatetime,
      pd.load_date_time
    ) as load_date_time
  from filtered_taxclass tx
  inner join condition_values pc using (condition_record_number)
  inner join silver_${env}.sap_sapuska.silver_gtsap_product_tax_classification_codes cc
  on (tx.tax_class_product = cc.excise_tax_id_zvv)
  and cc.opflag != "D"
  and cc.country = "FI"
  inner join global_product_data_with_uom pd using (product_sap_id)
  where tx.condition_type = "ZRVV"
), ZRKM_beverage_container_tax as (
  select
    cc.product_sap_id,
    condition_type,
    unit_of_measure,
    pc.fixed_condition_value_rate,
    pricing_unit_of_measure,
    pc.condition_currency_or_percent_sap,
    numerator_for_conversion_to_base_units_of_measure,
    denominator_for_conversion_to_base_units_of_measure,
    valid_from,
    valid_to,
    tx.tax_class_product,
    case
      when cc.beverage_container_tax_id_zkm != '0'
      then fixed_condition_value_rate * base_unit_conversion_factor * pd.net_content
      else pc.fixed_condition_value_rate
    end as calculated_tax_value_for_product_uom,
    greatest(
      tx.loaddatetime,
      pc.loaddatetime,
      cc.loaddatetime,
      load_date_time,
      pd.load_date_time
    ) as load_date_time
  from filtered_taxclass tx
  inner join condition_values pc using (condition_record_number)
  inner join silver_${env}.sap_sapuska.silver_gtsap_product_tax_classification_codes cc
    on (tx.tax_class_product = cc.beverage_container_tax_id_zkm)
      and cc.opflag != "D"
      and cc.country = "FI"
  inner join global_product_data_with_uom pd using (product_sap_id)
  where tx.condition_type = "ZRKM"
), ZRST_sttv_control_fee as (
  select
    cc.product_sap_id,
    condition_type,
    unit_of_measure,
    pc.fixed_condition_value_rate,
    pricing_unit_of_measure,
    pc.condition_currency_or_percent_sap,
    numerator_for_conversion_to_base_units_of_measure,
    denominator_for_conversion_to_base_units_of_measure,
    valid_from,
    valid_to,
    tx.tax_class_product,
    case
      when cc.sttv_container_contro_fee_id_zstt != '0'
      then fixed_condition_value_rate * base_unit_conversion_factor
      else fixed_condition_value_rate
    end as calculated_tax_value_for_product_uom,
    greatest(
      tx.loaddatetime,
      pc.loaddatetime,
      cc.loaddatetime,
      pd.load_date_time
    ) as load_date_time
  from filtered_taxclass tx
  inner join condition_values pc
    using (condition_record_number)
  inner join silver_${env}.sap_sapuska.silver_gtsap_product_tax_classification_codes cc
    on (tx.tax_class_product = cc.sttv_container_contro_fee_id_zstt)
      and cc.opflag != "D"
      and cc.country = "FI"
  inner join global_product_data_with_uom pd using (product_sap_id)
  where tx.condition_type = "ZRST"
), ZRTK_recycling_fee_for_cans as (
  select
    cc.product_sap_id,
    condition_type,
    unit_of_measure,
    pc.fixed_condition_value_rate,
    pricing_unit_of_measure,
    pc.condition_currency_or_percent_sap,
    numerator_for_conversion_to_base_units_of_measure,
    denominator_for_conversion_to_base_units_of_measure,
    valid_from,
    valid_to,
    tx.tax_class_product,
    case
      when cc.recycling_fee_metal_ztkm != '0'
      then fixed_condition_value_rate * base_unit_conversion_factor
      else fixed_condition_value_rate
    end as calculated_tax_value_for_product_uom,
    greatest(
      tx.loaddatetime,
      pc.loaddatetime,
      cc.loaddatetime,
      pd.load_date_time
    ) as load_date_time
  from filtered_taxclass tx
  inner join condition_values pc
    using (condition_record_number)
  inner join silver_${env}.sap_sapuska.silver_gtsap_product_tax_classification_codes cc
    on (tx.tax_class_product = cc.recycling_fee_metal_ztkm)
      and cc.opflag != "D"
      and cc.country = "FI"
  inner join global_product_data_with_uom pd using (product_sap_id)
  where tx.condition_type = "ZRTK"
), ZRKL_recycling_fee_for_glass_bottles as (
  select
    cc.product_sap_id,
    condition_type,
    unit_of_measure,
    pc.fixed_condition_value_rate,
    pricing_unit_of_measure,
    pc.condition_currency_or_percent_sap,
    numerator_for_conversion_to_base_units_of_measure,
    denominator_for_conversion_to_base_units_of_measure,
    valid_from,
    valid_to,
    tx.tax_class_product,
    case
      when cc.recycling_fee_glass_ztkl != '0'
      then fixed_condition_value_rate * base_unit_conversion_factor
      else fixed_condition_value_rate
    end as calculated_tax_value_for_product_uom,
    greatest(
      tx.loaddatetime,
      pc.loaddatetime,
      cc.loaddatetime,
      pd.load_date_time
    ) as load_date_time
  from filtered_taxclass tx
  inner join condition_values pc using (condition_record_number)
  inner join silver_${env}.sap_sapuska.silver_gtsap_product_tax_classification_codes cc
    on (tx.tax_class_product = cc.recycling_fee_glass_ztkl)
      and cc.opflag != "D"
      and cc.country = "FI"
  inner join global_product_data_with_uom pd using (product_sap_id)
  where tx.condition_type = "ZRKL"
), ZSER_recycling_fee_for_electric_applicances as (
select
  pd.product_sap_id,
  scpu.condition_type,
  unit_of_measure,
  -- Actual tax value calculation
  fixed_condition_value_rate *
  case
    when pc.calculation_type = 'C' and pd.product_is_base_unit
      then 1 -- Use the value as is
    when pc.calculation_type = 'C' and pd.product_is_order_unit
      then pd.base_unit_conversion_factor
    when pc.calculation_type = 'E' and pd.product_is_base_unit
      then pd.net_weight_base_unit
    when pc.calculation_type = 'E' and pd.product_is_order_unit
      then (
        pd.net_weight_base_unit * pd.base_unit_conversion_factor
      )
    else
     -1 -- This is the fallthrough condition. We should never end up here.
  end as calculated_tax_value_for_product_uom,

  fixed_condition_value_rate,
  numerator_for_conversion_to_base_units_of_measure,
  denominator_for_conversion_to_base_units_of_measure,
  condition_currency_or_percent_sap,
  valid_from,
  valid_to,
  null as tax_class_product,
  greatest(
    scpu.loaddatetime,
    pc.loaddatetime,
    pd.load_date_time
  ) as load_date_time
from
  global_product_data_with_uom pd
  inner join silver_${env}.sap_sapuska.silver_gtsap_a608_ser_class_per_uom scpu
    on scpu.ser_class = pd.ser_classification and scpu.base_unit_of_measure = pd.base_unit
  inner join condition_values pc using (condition_record_number)
where
  scpu.application = 'V' and -- Only include ser classes for sales, not purchase (M)
  pd.product_is_ser_product and
  scpu.condition_type in ('ZSER', 'ZSE2') and
  pc.calculation_type in ('C', 'E') and
  (
    (pd.product_is_imported_by_kesko and scpu.condition_type = 'ZSER')
    or
    ((not pd.product_is_imported_by_kesko) and scpu.condition_type = 'ZSE2')
  )
),
condition_unions as (
  select
    product_sap_id,
    condition_type,
    unit_of_measure,
    calculated_tax_value_for_product_uom,
    fixed_condition_value_rate,
    numerator_for_conversion_to_base_units_of_measure,
    denominator_for_conversion_to_base_units_of_measure,
    condition_currency_or_percent_sap,
    valid_from,
    valid_to,
    tax_class_product,
    load_date_time
  from ZRVV_alcohol_and_sugar_excise_tax
  union all
  select
    product_sap_id,
    condition_type,
    unit_of_measure,
    calculated_tax_value_for_product_uom,
    fixed_condition_value_rate,
    numerator_for_conversion_to_base_units_of_measure,
    denominator_for_conversion_to_base_units_of_measure,
    condition_currency_or_percent_sap,
    valid_from,
    valid_to,
    tax_class_product,
    load_date_time
  from ZRKM_beverage_container_tax
  union all
  select
    product_sap_id,
    condition_type,
    unit_of_measure,
    calculated_tax_value_for_product_uom,
    fixed_condition_value_rate,
    numerator_for_conversion_to_base_units_of_measure,
    denominator_for_conversion_to_base_units_of_measure,
    condition_currency_or_percent_sap,
    valid_from,
    valid_to,
    tax_class_product,
    load_date_time
  from ZRST_sttv_control_fee
  union all
  select
    product_sap_id,
    condition_type,
    unit_of_measure,
    calculated_tax_value_for_product_uom,
    fixed_condition_value_rate,
    numerator_for_conversion_to_base_units_of_measure,
    denominator_for_conversion_to_base_units_of_measure,
    condition_currency_or_percent_sap,
    valid_from,
    valid_to,
    tax_class_product,
    load_date_time
  from ZRTK_recycling_fee_for_cans
  union all
  select
    product_sap_id,
    condition_type,
    unit_of_measure,
    calculated_tax_value_for_product_uom,
    fixed_condition_value_rate,
    numerator_for_conversion_to_base_units_of_measure,
    denominator_for_conversion_to_base_units_of_measure,
    condition_currency_or_percent_sap,
    valid_from,
    valid_to,
    tax_class_product,
    load_date_time
  from ZRKL_recycling_fee_for_glass_bottles
  union all
  select
    product_sap_id,
    condition_type,
    unit_of_measure,
    calculated_tax_value_for_product_uom,
    fixed_condition_value_rate,
    numerator_for_conversion_to_base_units_of_measure,
    denominator_for_conversion_to_base_units_of_measure,
    condition_currency_or_percent_sap,
    valid_from,
    valid_to,
    tax_class_product,
    load_date_time
  from ZSER_recycling_fee_for_electric_applicances
)
select distinct
  cast(ltrim('0', product_sap_id) as bigint) as product_sap_id,
  condition_type,
  t006a1.uom_commercial as unit_of_measure,
  cast(calculated_tax_value_for_product_uom as DECIMAL(12,6)),
  cast(fixed_condition_value_rate as DECIMAL(12,6)),
  cast(numerator_for_conversion_to_base_units_of_measure as INT),
  cast(denominator_for_conversion_to_base_units_of_measure as INT),
  condition_currency_or_percent_sap,
  cast(valid_from as DATE),
  cast(valid_to as DATE),
  tax_class_product,
  load_date_time,
  current_timestamp as GoldLoadDateTime
from condition_unions cu
left join silver_${env}.sap_sapuska.silver_gtsap_units_of_measures_language_specific t006a1
  on cu.unit_of_measure = t006a1.uom_sap_technical
  and t006a1.language = 'U'