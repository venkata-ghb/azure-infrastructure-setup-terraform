INSERT OVERWRITE gold_${env}.sap_sapuska.gold_contract_product

with contract as (
  select
    a611.aekey,
    a611.client,
    a611.application,
    a611.condition_type,
    a611.sales_organization,
    a611.distribution_channel,
    null as customer_chain,
    null as customer_group,
    null as price_list,
    null as site,
    a611.customer_number,
    null as sales_office,
    null as agreement_group_1,
    a611.product_sap_id,
    a611.uom,
    cast(a611.valid_to as date),
    cast(a611.valid_from as date),
    a611.condition_record_number,
    cv.condition_value_rate,
    cv.condition_currency_or_percent_sap,
    case
      when cv.exclusion_and_kespro_netprice_indicator ='X' then true
      else false
    end as contract_exists,
    a611.LoadDateTime,
    a611.Opflag
  from silver_${env}.sap_sapuska.silver_gtsap_a611_chain_customer_product_uom a611
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_header ch 
  on a611.condition_record_number = ch.condition_record_number
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_values_and_item_data cv 
  on a611.condition_record_number = cv.condition_record_number
  where sales_organization = 8000
  and distribution_channel in (80, 81, 85, 88)
  and a611.condition_type in ("ZKH1", "ZKH2", "ZKH3")
  union all
  select
    a610.aekey,
    a610.client,
    a610.application,
    a610.condition_type,
    a610.sales_organization,
    a610.distribution_channel,
    null as customer_chain,
    null as customer_group,
    null as price_list,
    a610.site,
    a610.customer_number,
    null as sales_office,
    null as agreement_group_1,
    a610.product_sap_id,
    a610.uom,
    cast(a610.valid_to as date),
    cast(a610.valid_from as date),
    a610.condition_record_number,
    cv.condition_value_rate,
    cv.condition_currency_or_percent_sap,
    true as contract_exists,
    a610.LoadDateTime,
    a610.Opflag
  from silver_${env}.sap_sapuska.silver_gtsap_a610_chain_site_customer_product_uom a610
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_header ch 
  on a610.condition_record_number = ch.condition_record_number
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_values_and_item_data cv 
  on a610.condition_record_number = cv.condition_record_number
  where sales_organization = 8000
  and distribution_channel in (80, 81, 85, 88)
  and a610.condition_type in ("ZKH1", "ZKH2", "ZKH3")
  union all
  select
    a545.aekey,
    a545.client,
    a545.application,
    a545.condition_type,
    a545.sales_organization,
    a545.distribution_channel,
    null as customer_chain,
    null as customer_group,
    null as price_list,
    null as site,
    null as customer_number,
    null as sales_office,
    a545.agreement_group_1,
    a545.product_sap_id,
    a545.uom,
    a545.valid_to,
    a545.valid_from,
    a545.condition_record_number,
    cv.condition_value_rate,
    cv.condition_currency_or_percent_sap,
    case
      when a545.condition_type = 'ZKH2' and cv.exclusion_and_kespro_netprice_indicator ='X' then true
      when a545.condition_type = 'ZKH3' then true
      else false
    end as contract_exists, 
    a545.LoadDateTime,
    a545.Opflag
  from silver_${env}.sap_sapuska.silver_gtsap_a545_chain_agreement_product_uom a545
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_header ch 
  on a545.condition_record_number = ch.condition_record_number
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_values_and_item_data cv 
  on a545.condition_record_number = cv.condition_record_number
  where sales_organization = 8000
  and distribution_channel in (80, 81, 85, 88)
  and a545.condition_type in ("ZKH1", "ZKH2", "ZKH3")
  union all
  select
    a541.aekey,
    a541.client,
    a541.application,
    a541.condition_type,
    a541.sales_organization,
    a541.distribution_channel,
    null as customer_chain,
    null as customer_group,
    null as price_list,
    a541.site,
    null as customer_number,
    null as sales_office,
    a541.agreement_group_1,
    a541.product_sap_id,
    a541.uom,
    a541.valid_to,
    a541.valid_from,
    a541.condition_record_number,
    cv.condition_value_rate,
    cv.condition_currency_or_percent_sap,
    true as contract_exists,
    a541.LoadDateTime,
    a541.Opflag
  from silver_${env}.sap_sapuska.silver_gtsap_a541_chain_site_agreement_product_uom a541
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_header ch 
  on a541.condition_record_number = ch.condition_record_number
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_values_and_item_data cv 
  on a541.condition_record_number = cv.condition_record_number
  where sales_organization = 8000
  and distribution_channel in (80, 81, 85, 88)
  and a541.condition_type in ("ZKH1", "ZKH2", "ZKH3")
  union all
  select
    a546.aekey,
    a546.client,
    a546.application,
    a546.condition_type,
    a546.sales_organization,
    a546.distribution_channel,
    null as customer_chain,
    a546.customer_group,
    null as price_list,
    null as site,
    null as customer_number,
    a546.sales_office,
    null as agreement_group_1,
    a546.product_sap_id,
    a546.uom,
    a546.valid_to,
    a546.valid_from,
    a546.condition_record_number,
    cv.condition_value_rate,
    cv.condition_currency_or_percent_sap,
    case
      when cv.exclusion_and_kespro_netprice_indicator ='X' then true
      else false
    end as contract_exists,
    a546.LoadDateTime,
    a546.Opflag
  from silver_${env}.sap_sapuska.silver_gtsap_a546_chain_customer_group_sales_office_product_uom a546
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_header ch 
  on a546.condition_record_number = ch.condition_record_number
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_values_and_item_data cv 
  on a546.condition_record_number = cv.condition_record_number
  where sales_organization = 8000
  and distribution_channel in (80, 81, 85, 88)
  and a546.condition_type in ("ZKH1", "ZKH2", "ZKH3")
  union all
  select
    a547.aekey,
    a547.client,
    a547.application,
    a547.condition_type,
    a547.sales_organization,
    a547.distribution_channel,
    null as customer_chain,
    a547.customer_group,
    null as price_list,
    null as site,
    null as customer_number,
    null as sales_office,
    null as agreement_group_1,
    a547.product_sap_id,
    a547.uom,
    a547.valid_to,
    a547.valid_from,
    a547.condition_record_number,
    cv.condition_value_rate,
    cv.condition_currency_or_percent_sap,
    case
      when cv.exclusion_and_kespro_netprice_indicator ='X' then true
      else false
    end as contract_exists,
    a547.LoadDateTime,
    a547.Opflag
  from silver_${env}.sap_sapuska.silver_gtsap_a547_chain_customer_group_product_uom a547
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_header ch 
  on a547.condition_record_number = ch.condition_record_number
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_values_and_item_data cv 
  on a547.condition_record_number = cv.condition_record_number
  where sales_organization = 8000
  and distribution_channel in (80, 81, 85, 88)
  and a547.condition_type in ("ZKH1", "ZKH2", "ZKH3")
  union all
  select
    a542.aekey,
    a542.client,
    a542.application,
    a542.condition_type,
    a542.sales_organization,
    a542.distribution_channel,
    null as customer_chain,
    a542.customer_group,
    null as price_list,
    a542.site,
    null as customer_number,
    null as sales_office,
    null as agreement_group_1,
    a542.product_sap_id,
    a542.uom,
    a542.valid_to,
    a542.valid_from,
    a542.condition_record_number,
    cv.condition_value_rate,
    cv.condition_currency_or_percent_sap,
    true as contract_exists,
    a542.LoadDateTime,
    a542.Opflag
  from silver_${env}.sap_sapuska.silver_gtsap_a542_chain_site_customer_group_product_uom a542
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_header ch 
  on a542.condition_record_number = ch.condition_record_number
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_values_and_item_data cv 
  on a542.condition_record_number = cv.condition_record_number
  where sales_organization = 8000
  and distribution_channel in (80, 81, 85, 88)
  and a542.condition_type in ("ZKH1", "ZKH2", "ZKH3")
  union all
  select
    a548.aekey,
    a548.client,
    a548.application,
    a548.condition_type,
    a548.sales_organization,
    a548.distribution_channel,
    a548.customer_chain,
    null as customer_group,
    null as price_list,
    null as site,
    null as customer_number,
    null as sales_office,
    null as agreement_group_1,
    a548.product_sap_id,
    a548.uom,
    a548.valid_to,
    a548.valid_from,
    a548.condition_record_number,
    cv.condition_value_rate,
    cv.condition_currency_or_percent_sap,
    case
      when a548.condition_type = 'ZKH2' and cv.exclusion_and_kespro_netprice_indicator ='X' then true
      when a548.condition_type = 'ZKH3' then true
      else false
    end as contract_exists, 
    a548.LoadDateTime,
    a548.Opflag
  from silver_${env}.sap_sapuska.silver_gtsap_a548_chain_customer_chain_product_uom a548
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_header ch 
  on a548.condition_record_number = ch.condition_record_number
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_values_and_item_data cv 
  on a548.condition_record_number = cv.condition_record_number
  where sales_organization = 8000
  and distribution_channel in (80, 81, 85, 88)
  and a548.condition_type in ("ZKH1", "ZKH2", "ZKH3")
  union all
  select
    a549.aekey,
    a549.client,
    a549.application,
    a549.condition_type,
    a549.sales_organization,
    a549.distribution_channel,
    null as customer_chain,
    null as customer_group,
    a549.price_list,
    null as site,
    null as customer_number,
    a549.sales_office,
    null as agreement_group_1,
    a549.product_sap_id,
    a549.uom,
    a549.valid_to,
    a549.valid_from,
    a549.condition_record_number,
    cv.condition_value_rate,
    cv.condition_currency_or_percent_sap,
    case
      when cv.exclusion_and_kespro_netprice_indicator ='X' then true
      else false
    end as contract_exists,
    a549.LoadDateTime,
    a549.Opflag
  from silver_${env}.sap_sapuska.silver_gtsap_a549_chain_price_list_sales_office_product_uom a549
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_header ch 
  on a549.condition_record_number = ch.condition_record_number
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_values_and_item_data cv 
  on a549.condition_record_number = cv.condition_record_number
  where sales_organization = 8000
  and distribution_channel in (80, 81, 85, 88)
  and a549.condition_type in ("ZKH1", "ZKH2", "ZKH3")
  union all
  select
    a544.aekey,
    a544.client,
    a544.application,
    a544.condition_type,
    a544.sales_organization,
    a544.distribution_channel,
    null as customer_chain,
    null as customer_group,
    a544.price_list,
    a544.site,
    null as customer_number,
    null as sales_office,
    null as agreement_group_1,
    a544.product_sap_id,
    a544.uom,
    a544.valid_to,
    a544.valid_from,
    a544.condition_record_number,
    cv.condition_value_rate,
    cv.condition_currency_or_percent_sap,
    true as contract_exists,
    a544.LoadDateTime,
    a544.Opflag
  from silver_${env}.sap_sapuska.silver_gtsap_a544_chain_site_price_list_product_uom a544
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_header ch 
  on a544.condition_record_number = ch.condition_record_number
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_values_and_item_data cv 
  on a544.condition_record_number = cv.condition_record_number
  where sales_organization = 8000
  and distribution_channel in (80, 81, 85, 88)
  and a544.condition_type in ("ZKH1", "ZKH2", "ZKH3")
  union all
  select
    a155.aekey,
    a155.client,
    a155.application,
    a155.condition_type,
    a155.sales_organization,
    a155.distribution_channel,
    null as customer_chain,
    null as customer_group,
    a155.price_list,
    null as site,
    null as customer_number,
    null as sales_office,
    null as agreement_group_1,
    a155.product_sap_id,
    a155.uom,
    a155.valid_to,
    a155.valid_from,
    a155.condition_record_number,
    cv.condition_value_rate,
    cv.condition_currency_or_percent_sap,
    case
      when cv.exclusion_and_kespro_netprice_indicator ='X' then true
      else false
    end as contract_exists,
    a155.LoadDateTime,
    a155.Opflag
  from silver_${env}.sap_sapuska.silver_gtsap_a155_chain_price_list_product_uom a155
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_header ch 
  on a155.condition_record_number = ch.condition_record_number
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_values_and_item_data cv 
  on a155.condition_record_number = cv.condition_record_number
  where sales_organization = 8000
  and distribution_channel in (80, 81, 85, 88)
  and a155.condition_type in ("ZKH1", "ZKH2", "ZKH3")
  union all
  select
    a564.aekey,
    a564.client,
    a564.application,
    a564.condition_type,
    a564.sales_organization,
    a564.distribution_channel,
    null as customer_chain,
    null as customer_group,
    null as price_list,
    null as site,
    null as customer_number,
    a564.sales_office,
    null as agreement_group_1,
    a564.product_sap_id,
    a564.uom,
    a564.valid_to,
    a564.valid_from,
    a564.condition_record_number,
    cv.condition_value_rate,
    cv.condition_currency_or_percent_sap,
    case
      when cv.exclusion_and_kespro_netprice_indicator ='X' then true
      else false
    end as contract_exists,
    a564.LoadDateTime,
    a564.Opflag
  from silver_${env}.sap_sapuska.silver_gtsap_a564_chain_sales_office_product_uom a564
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_header ch 
  on a564.condition_record_number = ch.condition_record_number
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_values_and_item_data cv 
  on a564.condition_record_number = cv.condition_record_number
  where sales_organization = 8000
  and distribution_channel in (80, 81, 85, 88)
  and a564.condition_type in ("ZKH1", "ZKH2", "ZKH3")
  union all
  select
    a071.aekey,
    a071.client,
    a071.application,
    a071.condition_type,
    a071.sales_organization,
    a071.distribution_channel,
    null as customer_chain,
    null as customer_group,
    null as price_list,
    a071.site,
    null as customer_number,
    null as sales_office,
    null as agreement_group_1,
    a071.product_sap_id,
    a071.uom,
    a071.valid_to,
    a071.valid_from,
    a071.condition_record_number,
    cv.condition_value_rate,
    cv.condition_currency_or_percent_sap,
    case
      when a071.condition_type = 'ZKH3' then true
      else false
    end as contract_exists,
    a071.LoadDateTime,
    a071.Opflag
  from silver_${env}.sap_sapuska.silver_gtsap_a071_chain_site_product_uom a071
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_header ch 
  on a071.condition_record_number = ch.condition_record_number
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_values_and_item_data cv 
  on a071.condition_record_number = cv.condition_record_number
  where sales_organization = 8000
  and distribution_channel in (80, 81, 85, 88)
  and a071.condition_type in ("ZKH1", "ZKH2", "ZKH3")
  union all
  select
    a073.aekey,
    a073.client,
    a073.application,
    a073.condition_type,
    a073.sales_organization,
    a073.distribution_channel,
    null as customer_chain,
    null as customer_group,
    null as price_list,
    null as site,
    null as customer_number,
    null as sales_office,
    null as agreement_group_1,
    a073.product_sap_id,
    a073.uom,
    a073.valid_to,
    a073.valid_from,
    a073.condition_record_number,
    cv.condition_value_rate,
    cv.condition_currency_or_percent_sap,
    case
      when a073.condition_type = 'ZKH2' and cv.exclusion_and_kespro_netprice_indicator ='X' then true
      when a073.condition_type = 'ZKH3' then true
      else false
    end as contract_exists, 
    a073.LoadDateTime,
    a073.Opflag
  from silver_${env}.sap_sapuska.silver_gtsap_a073_chain_product_uom a073
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_header ch 
  on a073.condition_record_number = ch.condition_record_number
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_values_and_item_data cv 
  on a073.condition_record_number = cv.condition_record_number
  where sales_organization = 8000
  and distribution_channel in (80, 81, 85, 88)
  and a073.condition_type in ("ZKH1", "ZKH2", "ZKH3")
  union all
  select
    a118.aekey,
    a118.client,
    a118.application,
    a118.condition_type,
    null as sales_organization,
    null as distribution_channel,
    null as customer_chain,
    null as customer_group,
    null as price_list,
    null as site,
    null as customer_number,
    null as sales_office,
    null as agreement_group_1,
    a118.product_sap_id,
    null as uom,
    a118.valid_to,
    a118.valid_from,
    a118.condition_record_number,
    cv.condition_value_rate,
    cv.condition_currency_or_percent_sap,
    false as contract_exists,
    a118.LoadDateTime,
    a118.Opflag
  from silver_${env}.sap_sapuska.silver_gtsap_a118_empties_prices_product_specific a118
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_header ch 
  on a118.condition_record_number = ch.condition_record_number
  inner join silver_${env}.sap_sapuska.silver_gtsap_price_conditions_values_and_item_data cv 
  on a118.condition_record_number = cv.condition_record_number
  where a118.condition_type in ("ZKH1", "ZKH2", "ZKH3")
)

select distinct
  c.aekey,
  c.client,
  c.application,
  c.condition_type,
  cast(c.sales_organization as INT) as sales_organization,
  cast(c.distribution_channel as INT) as distribution_channel,
  c.customer_chain,
  c.customer_group,
  c.price_list,
  c.site,
  c.customer_number,
  c.sales_office,
  c.agreement_group_1,
  c.product_sap_id,
  t006a1.uom_commercial,
  cast(c.valid_to as DATE) as valid_to,
  cast(c.valid_from as DATE) as valid_from,
  c.condition_record_number,
  cast(c.condition_value_rate as DECIMAL(10, 2)) as condition_value_rate,
  c.condition_currency_or_percent_sap,
  cast(case 
      when condition_currency_or_percent_sap = 'EUR'
      then condition_value_rate 
      when condition_currency_or_percent_sap = 'EUR3'
      then condition_value_rate / 10
      when condition_currency_or_percent_sap = 'EUR4' 
      then condition_value_rate / 100
  end as DECIMAL(10,2)) as fixed_condition_value_rate,
  cast(c.contract_exists as BOOLEAN) as contract_exists,
  c.LoadDateTime TIMESTAMP,
  c.Opflag STRING,
  current_timestamp as GoldLoadDateTime
from contract c
left join silver_${env}.sap_sapuska.silver_gtsap_units_of_measures_language_specific t006a1
  on c.uom = t006a1.uom_sap_technical
  and t006a1.language = 'U'
where c.Opflag != 'D'