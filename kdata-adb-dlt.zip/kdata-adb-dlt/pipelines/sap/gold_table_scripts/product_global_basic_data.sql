INSERT OVERWRITE gold_${env}.sap_sapuska.gold_product_global_basic_data

with units_of_measures as (
    select
        product_sap_id,
        uom_commercial as unit_of_measure,
        primary_gtin as primary_order_unit_gtin,
        (numerator_for_conversion_to_base_units_of_measure::real / denominator_for_conversion_to_base_units_of_measure::real) 
        as quantity_of_base_units_in_order_unit,
        uom.LoadDateTime as uom_loaddatetime,
        t006a1.LoadDateTime as uomls_loaddatetime
    from silver_${env}.sap_sapuska.silver_gtsap_product_units_of_measures uom
    left join silver_${env}.sap_sapuska.silver_gtsap_units_of_measures_language_specific t006a1
        on uom.unit_of_measure = t006a1.uom_sap_technical
        and t006a1.language = 'U'
), 
conversions as (
    select
        pg.product_sap_id,
        t006a1.uom_commercial as base_unit,
        case 
            when pg.order_unit = '' 
            then t006a1.uom_commercial
            else t006a2.uom_commercial
        end as order_unit,
        t006a3.uom_commercial as unit_of_content,
        t006a4.uom_commercial as unit_of_weight
    from silver_${env}.sap_sapuska.silver_gtsap_product_global_basic_data as pg
        left join silver_${env}.sap_sapuska.silver_gtsap_units_of_measures_language_specific t006a1
        on pg.base_unit = t006a1.uom_sap_technical
        and t006a1.language = 'U'
        left join silver_${env}.sap_sapuska.silver_gtsap_units_of_measures_language_specific t006a2
        on pg.order_unit = t006a2.uom_sap_technical
        and t006a2.language = 'U'
        left join silver_${env}.sap_sapuska.silver_gtsap_units_of_measures_language_specific t006a3
        on pg.unit_of_content = t006a3.uom_sap_technical
        and t006a3.language = 'U'
        left join silver_${env}.sap_sapuska.silver_gtsap_units_of_measures_language_specific t006a4
        on pg.unit_of_weight = t006a4.uom_sap_technical
        and t006a4.language = 'U'
), 
logistic_variant_link as (
    select
        pg.product_sap_id,
        gt.product_sap_id as logistic_variant_link_to_base_unit_product_sap_id,
        gt.LoadDateTime as gt_loaddatetime
    from silver_${env}.sap_sapuska.silver_gtsap_product_global_basic_data as pg
        left join silver_${env}.sap_sapuska.silver_gtsap_product_gtins_all as gt
        on gt.unit_of_measure = pg.base_unit and pg.logistic_variant_link_to_base_unit_gtin = gt.gtin
), 
multipack_link as (
    select
        pg.product_sap_id,
        gt.product_sap_id as multipack_link_to_single_product_sap_id
    from silver_${env}.sap_sapuska.silver_gtsap_product_global_basic_data as pg
        left join silver_${env}.sap_sapuska.silver_gtsap_product_gtins_all as gt
        on pg.gtin_of_single_product_in_multipack = gt.gtin
), 
label as (
    select distinct
        pg.product_sap_id,
        case 
            when mn.product_marketing_name = '' or mn.product_marketing_name is null 
            then sd.language
            else mn.language
        end as language,
        mn.product_marketing_name as product_marketing_name_sap_fi,
        sd.product_short_description_40char as short_description_fi_order_unit,
        sd.LoadDateTime as sd_loaddatetime,
        mn.LoadDateTime as mn_loaddatetime
    from silver_${env}.sap_sapuska.silver_gtsap_product_global_basic_data as pg
        left join silver_${env}.sap_sapuska.silver_gtsap_product_short_descriptions_40char as sd
        on pg.product_sap_id = sd.product_sap_id and sd.language = 'U'
        left join silver_${env}.sap_sapuska.silver_gtsap_product_marketing_name_sap as mn
        on pg.product_sap_id = mn.product_sap_id and mn.language = 'U'
),
merchandise_category as (
    select
        pg.product_sap_id,
        chd2.class_id as merchandise_category_level_3_sub_category,
        chd3.class_id as merchandise_category_level_2,
        chd.LoadDatetime as chd_loaddatetime,
        olc.LoadDateTime as olc_loaddatetime
    from silver_${env}.sap_sapuska.silver_gtsap_product_global_basic_data as pg
        left join silver_${env}.sap_sapuska.silver_gtsap_class_header_data as chd 
        on pg.merchandise_category_segment = chd.class_id
        left join silver_${env}.sap_sapuska.silver_gtsap_object_linkage_to_class olc
        on chd.internal_class_id = olc.object
        left join silver_${env}.sap_sapuska.silver_gtsap_class_header_data as chd2
        on olc.internal_class_id = chd2.internal_class_id
        left join silver_${env}.sap_sapuska.silver_gtsap_object_linkage_to_class olc2
        on chd2.internal_class_id = olc2.object
        left join silver_${env}.sap_sapuska.silver_gtsap_class_header_data as chd3
        on olc2.internal_class_id = chd3.internal_class_id
    where chd.class_type = '026' and chd2.class_type = '026' and chd3.class_type = '026'
        and olc.object_or_class_indicator = 'K' and olc2.object_or_class_indicator = 'K'
)
select distinct
    cast(ltrim('0', pg.product_sap_id) as bigint) as product_sap_id,
    c.base_unit,
    pg.primary_base_unit_gtin,
    c.order_unit,
    uom.primary_order_unit_gtin,
    cast(uom.quantity_of_base_units_in_order_unit as DECIMAL(10,3)),
    pg.logistic_variant_link_to_base_unit_gtin,
    ltrim('0', lv.logistic_variant_link_to_base_unit_product_sap_id) as logistic_variant_link_to_base_unit_product_sap_id,
    pg.gtin_of_single_product_in_multipack as multipack_link_to_single_product_gtin,
    ltrim('0', mp.multipack_link_to_single_product_sap_id) as multipack_link_to_single_product_sap_id,
    cast(pg.amount_of_single_products_in_multipack as INT),
    l.short_description_fi_order_unit,
    l.product_marketing_name_sap_fi,
    ltrim('0', pg.default_vendor_in_global_product_master) as default_vendor_in_global_product_master,
    vg.vendor_name_1,
    pv.vendor_product_id,
    vg.country as vendor_country,
    rt.country_of_origin as product_country_of_origin,
    cast(pg.brand_id as INT),
    b.brand_description,
    cast(pg.sub_brand_id as INT),
    sb.sub_brand_description,
    cast(pg.product_family_id as INT),
    pf.product_family_name,
    pg.assortment_list_type as assortment_list_type_id,
    --assortment_list_type_name,
    pg.product_type,
    pg.product_category,
    pg.merchandise_category_segment,
    mc.merchandise_category_level_3_sub_category,
    mc.merchandise_category_level_2,
    cast(pg.gt_kespro_kcm_product_in_product_master_vksk as INT),
    cast(pg.height_of_base_unit as DECIMAL(10,3)),
    cast(pg.width_of_base_unit as DECIMAL(10,3)),
    cast(pg.length_of_base_unit as DECIMAL(10,3)),
    pg.unit_of_dimensions,
    cast(pg.net_weight_base_unit as DECIMAL(10,3)),
    cast(pg.gross_weight_base_unit as DECIMAL(10,3)),
    c.unit_of_weight,
    cast(pg.net_content as DECIMAL(10,3)),
    pg.comparison_price_number_of_units,
    cast(pg.gross_content as DECIMAL(10,3)),
    cast(pg.creation_date_of_sap_product as DATE),
    pg.purchase_blocking_status_global,
    cast(pg.purchase_blocking_valid_from as DATE),
    pg.sales_blocking_status_global,
    cast(pg.sales_blocking_valid_from as DATE),
    pg.discontinuation_reason_id,
    cast(pg.discontinuation_date as DATE),
    pg.pda_order_block as pda_ordering_block,
    pg.alcohol_license_level,
    pg.tobacco_license_level,
    pg.tobacco_license_eu,
    pg.self_care_product,
    cast(pg.age_limit as INT),
    pg.accounting_level,
    --accounting_level_name,
    rt.purchasing_group as purchasing_group_id_global,
    pu.purchasing_group_name,
    pg.vat_classification_code,
    pg.fruits_and_vegetables_sort_code,
    ltrim('0', pg.replaced_product_sap_id) as replaced_product_sap_id,
    pg.global_deletion_flag,
    cast(pg.novelty_product_valid_from as DATE),
    pg.transportation_group,
    pg.exclusive_sale_product as kesko_exclusive_sale_product,
    cast(pg.exclusive_sale_start_date as DATE),
    cast(pg.exclusive_sale_end_date as DATE),
    pg.prelaunch_indicator,
    cast(pg.prelaunch_start_date as DATE),
    cast(pg.prelaunch_end_date as DATE),
    pg.purchasing_method,
    pg.imported_by_kesko,
    ltrim('0', pg.pricing_reference_product) as pricing_reference_product,
    pg.pricing_profile_generic_product,
    cast(pg.alcohol_percentage as DECIMAL),
    cast(pg.dilution_factor as INT),
    pg.price_type_forced_global,
    pg.opflag,
    current_timestamp as GoldLoadDateTime,
    greatest(
        pg.LoadDateTime,
        uom.uom_loaddatetime,
        uom.uomls_loaddatetime,
        lv.gt_loaddatetime,
        l.sd_loaddatetime,
        l.mn_loaddatetime,
        mc.chd_loaddatetime,
        mc.olc_loaddatetime,
        b.LoadDateTime,
        sb.LoadDateTime,
        vg.LoadDateTime,
        pv.LoadDateTime
    ) as LoadDateTime
from silver_${env}.sap_sapuska.silver_gtsap_product_global_basic_data as pg
left join conversions c
    on pg.product_sap_id = c.product_sap_id
left join logistic_variant_link as lv
    on pg.product_sap_id = lv.product_sap_id
left join multipack_link as mp
    on pg.product_sap_id = mp.product_sap_id
left join silver_${env}.sap_sapuska.silver_gtsap_product_families as pf
    on pg.product_family_id = pf.product_family_id
left join label l
    on pg.product_sap_id = l.product_sap_id and l.language = 'U'
left join silver_${env}.sap_sapuska.silver_gtsap_product_global_retail_data as rt
    on pg.product_sap_id = rt.product_sap_id
left join silver_${env}.sap_sapuska.silver_gtsap_purchasing_groups as pu
    on rt.purchasing_group = pu.purchasing_group_id
left join units_of_measures as uom
    on pg.product_sap_id = uom.product_sap_id
    and c.order_unit = uom.unit_of_measure
left join merchandise_category mc on pg.product_sap_id = mc.product_sap_id
left join silver_${env}.sap_sapuska.silver_gtsap_brands as b on pg.brand_id = b.brand_id
left join silver_${env}.sap_sapuska.silver_gtsap_sub_brands as sb on pg.sub_brand_id = sb.sub_brand_id
left join silver_${env}.sap_sapuska.silver_gtsap_vendor_global_data as vg
    on pg.default_vendor_in_global_product_master = vg.vendor_id
left join silver_${env}.sap_sapuska.silver_gtsap_product_vendor as pv 
    on pg.product_sap_id = pv.product_sap_id and pg.default_vendor_in_global_product_master = pv.vendor_sap_id
order by product_sap_id