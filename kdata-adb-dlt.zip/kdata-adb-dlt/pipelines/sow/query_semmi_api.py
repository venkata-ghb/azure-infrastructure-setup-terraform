# Databricks notebook source
import requests as r
import json
import http
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

dbutils.widgets.text("environment", "dev")
dbutils.widgets.text("table_config_path", "/Workspace/Repos/DLT/kdata-adb-dlt/pipelines/sow")


# COMMAND ----------

environment = dbutils.widgets.get("environment")
if environment != "prod":
  url = f"semmi{environment}"
else:
  url = "semmi"
target_dir = f"abfss://dlt@kdata{environment}adls.dfs.core.windows.net/kespro-snowflake"
config_path = dbutils.widgets.get("table_config_path")
kespro_config_path = f"{config_path}/kespro_sow_config.json"


# COMMAND ----------

# open configs
with open(file=kespro_config_path, mode="r") as file:
    kespro_config = json.load(file)

# COMMAND ----------

# scopes
scopes = kespro_config.get('secret_scopes')
old_keyvault_scope = scopes.get("old_keyvault")
new_keyvault_scope = scopes.get("new_keyvault")

# Semmi credentials
semmi_credential_keys = kespro_config.get("semmi_credential_keys")
# client_id = dbutils.secrets.get(scope=old_keyvault_scope, key = semmi_credential_keys.get("client_id"))
# client_secret = dbutils.secrets.get(scope=old_keyvault_scope, key = semmi_credential_keys.get("client_secret"))

# New semmi credentials
client_id = dbutils.secrets.get(scope=new_keyvault_scope, key = semmi_credential_keys.get("client_id"))
client_secret = dbutils.secrets.get(scope=new_keyvault_scope, key = semmi_credential_keys.get("client_secret"))


#Get connection details from config
conn_details = kespro_config.get("connection_credentials")
user = dbutils.secrets.get(scope=old_keyvault_scope, key = conn_details.get("user_key"))
pw = dbutils.secrets.get(scope=old_keyvault_scope, key = conn_details.get("pw_key"))
host = dbutils.secrets.get(scope=old_keyvault_scope, key = conn_details.get("host_key"))
database_name = conn_details.get("database_name")

#Get connection details for new keyvault
kd_conn_details = kespro_config.get("connection_credentials")
kd_user = dbutils.secrets.get(scope=new_keyvault_scope, key = kd_conn_details.get("user_key"))
kd_pw = dbutils.secrets.get(scope=new_keyvault_scope, key = kd_conn_details.get("pw_key"))
kd_host = dbutils.secrets.get(scope=new_keyvault_scope, key = kd_conn_details.get("host_key"))
kd_database_name = kd_conn_details.get("database_name")

# COMMAND ----------

dbutils.fs.mkdirs(target_dir)

# COMMAND ----------

def refresh_access_token():
    print("Refresh access token")
    conn = http.client.HTTPSConnection("login.microsoftonline.com")
    payload = f'grant_type=client_credentials&client_id={client_id}&client_secret={client_secret}&scope=https://{url}.crm4.dynamics.com/.default'
    headers = {
      'Content-Type': 'application/x-www-form-urlencoded'
    }
    getbearer = conn.request("GET", "/ae6e7baa-e1bf-4ef0-92a1-4eb28ec805c0/oauth2/v2.0/token", payload, headers)
    res = conn.getresponse()
    data = res.read()
    data_json = json.loads(data.decode("utf-8"))
    accesstoken = ''
    try:
        accesstoken = data_json.get('access_token')
    except(KeyError):
        print('Could not get access token')

    return accesstoken

# COMMAND ----------

headers = {
    'Authorization': 'Bearer ' + refresh_access_token(),
    'Accept': 'application/json',
    'Content-Type': 'application/json; charset=utf-8',
    'Prefer': 'return=representation'
}

# COMMAND ----------

def query_semmi_api(headers, url, table, fields):
  print(f"Query semmi api for table {table}")
  #conn = http.client.HTTPSConnection(f"{url}.crm4.dynamics.com")
  fields = ",".join(fields)
  base_url = f"https://{url}.crm4.dynamics.com/api/data/v9.2/{table}?$select={fields}"
  payload = ''
  #conn.request("GET", f"/api/data/v9.2/{table}?$select={fields}", payload, headers)

  response_data = []

  while True:
    response = r.get(base_url, headers = headers)
    data = response.json()
    #print(data.get("@odata.nextLink"))
    response_data += data.get("value")
    if '@odata.nextLink' not in data:
        break
    base_url = data.get("@odata.nextLink")
  print("Query complete")
  return response_data


# COMMAND ----------


fields = ["di_actualpotentialkespro","di_buyingpotentialkespro","di_businessid","accountnumber"]
response = query_semmi_api(headers, url, "accounts", fields)

# COMMAND ----------

print("Create response df")
response_df = (spark.createDataFrame(response)
                .select(col("accountnumber").alias("customer_id"),
                        col("di_businessid").alias("vat_code"),
                        col("di_actualpotentialkespro").alias("kespro_actual_purchase_potential"),
                        col("di_buyingpotentialkespro").alias("kespro_purchase_potential")
                ).dropDuplicates()
                    )

# COMMAND ----------

def write_to_datalake(target, df, target_dir):
  print(f"Write to datalake to: {target_dir}/{target}")
  df = (df.withColumn("partitioning_timestamp", current_timestamp())
          .withColumn("year", year("partitioning_timestamp"))
          .withColumn("month", month("partitioning_timestamp"))
          .withColumn("day", dayofmonth("partitioning_timestamp"))
          .drop("partitioning_timestamp")
          .withColumn("LoadDateTime", current_timestamp())
        )
  (df.write
     .format("delta")
     .partitionBy("year", "month", "day")
     .mode("overwrite")
     .save(f"{target_dir}/{target}")
  )
  print("Write ok")

# COMMAND ----------

def write_to_kesprodata(target_table, df, postgres_host, postgres_database_name, postgres_user, postgres_pw):
  df = df.withColumn("LoadDateTime", current_timestamp())
  print(f"Dataframe schema for table {target_table}:")
  print(df)
  target_schema = "kespro_misc"
  print(f"Write table {target_schema}.{target_table} to kesprodata")
  (df.write
    .format("postgresql")
    .option("dbtable", f"{target_schema}.{target_table}")
    .option("host", postgres_host)
    .option("port", 5432)
    .option("database", postgres_database_name)
    .option("user", postgres_user)
    .option("password", postgres_pw)
    .option("batchSize", 50000)
    .option("numPartitions", 4)
    .option("truncate", "true")
    .mode("overwrite")
    .save()
  )
  print("Write ok")

# COMMAND ----------

print("Start data write to targets")
write_to_datalake("semmi_purchase_potential", response_df, target_dir)
write_to_kesprodata("semmi_purchase_potential", response_df, host, database_name, user, pw) # current
write_to_kesprodata("semmi_purchase_potential", response_df, kd_host, kd_database_name, kd_user, kd_pw) # new
print("End data write to targets")
