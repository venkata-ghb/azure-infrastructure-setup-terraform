# Databricks notebook source
import os
from pyspark.sql.functions import *
from pyspark.sql.types import *
import json
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend
import base64

# COMMAND ----------

dbutils.widgets.text("environment", "dev")
dbutils.widgets.text("table_config_path", "/Workspace/Repos/DLT/kdata-adb-dlt/pipelines/sow")

# COMMAND ----------

env = dbutils.widgets.get("environment")
config_path = dbutils.widgets.get("table_config_path")
kespro_config_path = f"{config_path}/kespro_sow_config.json"
warehouse = f"WH_{env}_KESPRO_CONS_REPORT_PBI"
database = f"KDATA_{env}"
role = f"KDATA_KSNOW_{env}_DATA_EXT_KESPRO_DATA_BRICKS"
target_dir = f"abfss://dlt@kdata{env}adls.dfs.core.windows.net/kespro-snowflake"

# COMMAND ----------

query_files = [filename for filename in os.listdir(config_path) if filename.endswith(".sql")]
queries = {}
for filename in query_files:
 with open(f"{config_path}/{filename}") as query_string:
   queries[filename.removesuffix(".sql")] = query_string.read()
   query_string.close()

with open(file=kespro_config_path, mode="r") as file:
    kespro_config = json.load(file)

# COMMAND ----------

# scopes
scopes = kespro_config.get('secret_scopes')
old_keyvault_scope = scopes.get("old_keyvault")
new_keyvault_scope = scopes.get("new_keyvault")
sf_key_scope = scopes.get("kespro_snowflake_shared")

# Snowflake config current
snowflake_credential_keys = kespro_config.get("snowflake_credential_keys")

# Snowflake config new
sf_username = dbutils.secrets.get(scope=new_keyvault_scope, key = snowflake_credential_keys.get('username'))
sf_host = dbutils.secrets.get(scope=new_keyvault_scope, key = snowflake_credential_keys.get('host'))
pem_private_key = dbutils.secrets.get(scope=sf_key_scope, key = snowflake_credential_keys.get('private_key'))
passphrase = dbutils.secrets.get(scope=sf_key_scope, key = snowflake_credential_keys.get('passphrase'))


#Get connection details from config
conn_details = kespro_config.get("connection_credentials")
user = dbutils.secrets.get(scope=old_keyvault_scope, key = conn_details.get("user_key"))
pw = dbutils.secrets.get(scope=old_keyvault_scope, key = conn_details.get("pw_key"))
host = dbutils.secrets.get(scope=old_keyvault_scope, key = conn_details.get("host_key"))
database_name = conn_details.get("database_name")

#Get connection details for new keyvault
kd_conn_details = kespro_config.get("connection_credentials")
kd_user = dbutils.secrets.get(scope=new_keyvault_scope, key = kd_conn_details.get("user_key"))
kd_pw = dbutils.secrets.get(scope=new_keyvault_scope, key = kd_conn_details.get("pw_key"))
kd_host = dbutils.secrets.get(scope=new_keyvault_scope, key = kd_conn_details.get("host_key"))
kd_database_name = kd_conn_details.get("database_name")

# COMMAND ----------

dbutils.fs.mkdirs(target_dir)

# COMMAND ----------

# Load the private key and decore with passphrase
private_key = serialization.load_pem_private_key(
    pem_private_key.encode(),
    password=passphrase.encode(),
    backend=default_backend()
)

# Convert to bytes
private_key_bytes = private_key.private_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PrivateFormat.PKCS8,
    encryption_algorithm=serialization.NoEncryption()
).decode("utf-8")

# Remove the header, footer, and newlines from the PEM string for snowflake
pem_private_key = private_key_bytes.replace(
    "-----BEGIN PRIVATE KEY-----", ""
).replace(
    "-----END PRIVATE KEY-----", ""
).replace("\n", "")

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Connection

# COMMAND ----------

snowflake_reader = (spark.read
  .format("snowflake")
  .option("host", sf_host)
  .option("user", sf_username)
  .option("pem_private_key", pem_private_key)
  .option("sfWarehouse", warehouse)
  .option("database", database)
  .option("schema", "PUB_GT_B2BCUSTOMERS")
  .option("role", role)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Fetch results from Snowflake
# MAGIC

# COMMAND ----------

def df_to_lowercase(df):

    lower_case_columns = [col.lower() for col in df.columns]
    df = df.toDF(*lower_case_columns)

    return df

# COMMAND ----------

print(f"Start load data from snowflake with {len(query_files)} queries")
sow_calculations = {}
for query_name, query in queries.items():
  print(f"Querying: {query_name}")
  sow_calculations[query_name] = df_to_lowercase(snowflake_reader.option("query", query).load())
print("All snowflake queries complete")

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Write to datalake

# COMMAND ----------

def write_to_datalake(target, df):
  print(f"Write data to datalake: {target_dir}/{target}")
  df = (df.withColumn("partitioning_timestamp", current_timestamp())
          .withColumn("year", year("partitioning_timestamp"))
          .withColumn("month", month("partitioning_timestamp"))
          .withColumn("day", dayofmonth("partitioning_timestamp"))
          .drop("partitioning_timestamp")
          .withColumn("LoadDateTime", current_timestamp())
        )
  (df.write
     .format("delta")
     .partitionBy("year", "month", "day")
     .mode("overwrite")
     .option("mergeSchema", "true")
     .save(f"{target_dir}/{target}")
  )
  print("Write ok")

# COMMAND ----------

def write_to_kesprodata(target_table, df, postgres_host, postgres_database_name, postgres_user, postgres_pw):
  df = df.withColumn("LoadDateTime", current_timestamp())
  print(f"Dataframe schema for table {target_table}:")
  print(df)
  target_schema = "kespro_misc"
  print(f"Write table {target_schema}.{target_table} to kesprodata")
  (df.write
    .format("postgresql")
    .option("dbtable", f"{target_schema}.{target_table}")
    .option("host", postgres_host)
    .option("port", 5432)
    .option("database", postgres_database_name)
    .option("user", postgres_user)
    .option("password", postgres_pw)
    .option("batchSize", 50000)
    .option("numPartitions", 4)
    .option("truncate", "true")
    .mode("overwrite")
    .save()
  )
  print("Write ok")

# COMMAND ----------

print("start run")
for query, df in sow_calculations.items():
    print(f"Write data to all targets for: {query}")
    write_to_datalake(query, df)
    write_to_kesprodata(query, df, host, database_name, user, pw) # current kd
    write_to_kesprodata(query, df, kd_host, kd_database_name, kd_user, kd_pw) # new kd
print("end run")
