# Databricks notebook source
import os
from pyspark.sql.functions import *
from pyspark.sql.types import *
import json

# COMMAND ----------

dbutils.widgets.text("environment", "dev")
dbutils.widgets.text("table_config_path", "/Workspace/Repos/DLT/kdata-adb-dlt/pipelines/sow")


# COMMAND ----------

environment = dbutils.widgets.get("environment")
source_dir = f"abfss://dlt@kdata{environment}adls.dfs.core.windows.net/kespro-snowflake"
target_dir = f"abfss://raw@kdata{environment}adls.dfs.core.windows.net/natural/SEMMI/stage/sow"
config_path = dbutils.widgets.get("table_config_path")
kespro_config_path = f"{config_path}/kespro_sow_config.json"

# COMMAND ----------

dbutils.fs.mkdirs(target_dir)

# COMMAND ----------

# open configs
with open(file=kespro_config_path, mode="r") as file:
    kespro_config = json.load(file)

# COMMAND ----------

# scopes
scopes = kespro_config.get('secret_scopes')
old_keyvault_scope = scopes.get("old_keyvault")
new_keyvault_scope = scopes.get("new_keyvault")

#Get connection details from config
conn_details = kespro_config.get("connection_credentials")
user = dbutils.secrets.get(scope=old_keyvault_scope, key = conn_details.get("user_key"))
pw = dbutils.secrets.get(scope=old_keyvault_scope, key = conn_details.get("pw_key"))
host = dbutils.secrets.get(scope=old_keyvault_scope, key = conn_details.get("host_key"))
database_name = conn_details.get("database_name")

#Get connection details for new keyvault
kd_conn_details = kespro_config.get("connection_credentials")
kd_user = dbutils.secrets.get(scope=new_keyvault_scope, key = kd_conn_details.get("user_key"))
kd_pw = dbutils.secrets.get(scope=new_keyvault_scope, key = kd_conn_details.get("pw_key"))
kd_host = dbutils.secrets.get(scope=new_keyvault_scope, key = kd_conn_details.get("host_key"))
kd_database_name = kd_conn_details.get("database_name")

# COMMAND ----------

# MAGIC %md 
# MAGIC
# MAGIC Read Snowflake data

# COMMAND ----------

company_purchases = (spark.read
                          .format("delta")
                          .load(f"{source_dir}/company_level_12_month_purchases")
                    )

# COMMAND ----------

# MAGIC %md
# MAGIC Read Semmi buying potential data

# COMMAND ----------

semmi_buying_potential = (spark.read
                          .format("delta")
                          .load(f"{source_dir}/semmi_purchase_potential")
                          .sort("kespro_purchase_potential", ascending=False)
                          .dropDuplicates(["vat_code"])
                    )

# COMMAND ----------

print("Create sow df")
sow_df = (company_purchases.alias("prc").join(semmi_buying_potential.alias("sbp"), "vat_code", "inner")
                           .select(col("prc.vat_code").alias("customer_b2b_company_id"),
                                   col("prc.wholesale_sum").alias("sow_purchase_amount").cast("double"),
                                   col("sbp.kespro_purchase_potential").alias("sow_total_purchasing_power_amount")
                                   )
                           .withColumn("sow_purchase_amount",
                                       when(col("sow_purchase_amount") < 0, 0)
                                       .otherwise(col("sow_purchase_amount"))
                                       )
                           .withColumn("sow_potential_amount",
                                       when((col("sow_total_purchasing_power_amount") - col("sow_purchase_amount")) > 0, round(col("sow_total_purchasing_power_amount") - col("sow_purchase_amount"), 2))
                                        .otherwise(lit(0).cast('double'))
                                       )
                           .withColumn("share_of_wallet_percentage", 
                                       when(round(col("sow_purchase_amount")/col("sow_total_purchasing_power_amount")*100, 0).cast("int") > 100, 100)
                                       .when(round(col("sow_purchase_amount")/col("sow_total_purchasing_power_amount")*100, 0).cast("int") < 0, 0)
                                       .otherwise(round(col("sow_purchase_amount")/col("sow_total_purchasing_power_amount")*100, 0).cast("int"))
                                       
                           )
                           .withColumn("share_of_wallet_category_description",
                                        when(col("share_of_wallet_percentage") > 80, "81-100%")
                                        .when(col("share_of_wallet_percentage") > 50, "51-80%")
                                        .when(col("share_of_wallet_percentage") > 20, "21-50%")
                                        .when(col("share_of_wallet_percentage").isNull(), lit(None).cast('int')) 
                                        .otherwise(lit("0-20%").cast("string"))
                           )
                           .withColumn("share_of_wallet_category",
                                        when(col("share_of_wallet_category_description") == "81-100%", 1)
                                        .when(col("share_of_wallet_category_description") == "51-80%", 2)
                                        .when(col("share_of_wallet_category_description") == "21-50%", 3)
                                        .when(col("share_of_wallet_category_description") == "0-20%", 4)
                                        .otherwise(lit(None).cast('string'))
                           )
                           .withColumn("yearmonthnum", concat(year(current_timestamp()), lpad(month(current_timestamp()), 2, "0")).cast("string"))
                           .select("customer_b2b_company_id",
                                    "share_of_wallet_category",
                                    "share_of_wallet_category_description",
                                    "share_of_wallet_percentage",
                                    "sow_total_purchasing_power_amount",
                                    "sow_purchase_amount",
                                    "sow_potential_amount",
                                    "yearmonthnum"
                                    )
                           .orderBy(desc("sow_total_purchasing_power_amount"))
                           .dropDuplicates(["customer_b2b_company_id"])
          )

# COMMAND ----------

def write_to_datalake(df, target_dir):
  print(f"Write to datalake to: {target_dir}/")
  df = (df.withColumn("partitioning_timestamp", current_timestamp())
          .withColumn("year", year("partitioning_timestamp").cast("string"))
          .withColumn("month", lpad(month("partitioning_timestamp"), 2, "0").cast("string"))
          .withColumn("date", date_format("partitioning_timestamp", "yyyy-MM-dd"))
        )
  (df.write
     .format("parquet")
     .partitionBy("year", "month", "date")
     .mode("append")
     .option("mergeSchema", "true")
     .save(f"{target_dir}")
  )
  print("Write ok")

# COMMAND ----------

def write_to_kesprodata(target_table, df, postgres_host, postgres_database_name, postgres_user, postgres_pw):
  df = df.withColumn("LoadDateTime", current_timestamp())
  print(f"Dataframe schema for table {target_table}:")
  print(df)
  target_schema = "kespro_misc"
  print(f"Write table {target_schema}.{target_table} to kesprodata")
  
  (df.write
    .format("postgresql")
    .option("dbtable", f"{target_schema}.{target_table}")
    .option("host", postgres_host)
    .option("port", 5432)
    .option("database", postgres_database_name)
    .option("user", postgres_user)
    .option("password", postgres_pw)
    .option("batchSize", 50000)
    .option("numPartitions", 4)
    .option("truncate", "true")
    .mode("overwrite")
    .save()
  )
  print("Write ok")

# COMMAND ----------

print("Start data write")
write_to_datalake(sow_df, target_dir)
write_to_kesprodata("sow_total_purchasing_power_amount", sow_df, host, database_name, user, pw) # current
write_to_kesprodata("sow_total_purchasing_power_amount", sow_df, kd_host, kd_database_name, kd_user, kd_pw) # new
print("End data write")
