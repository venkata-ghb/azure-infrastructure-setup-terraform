
resource databricks_job calculate_sow {
  name = "calculate_sow_${var.ENV}"

  job_cluster {
    job_cluster_key = "sow_cluster"
    new_cluster {
      num_workers    = 4
      spark_version  = "17.3.x-scala2.13"
      node_type_id   = "Standard_D4s_v5"
      spark_conf     = local.global_spark_conf
      spark_env_vars = { PYSPARK_PYTHON = "/databricks/python3/bin/python3" }
      data_security_mode = "SINGLE_USER"
    }
  }
  schedule {
    quartz_cron_expression = "0 0 6 6 * ?"
    timezone_id = "Europe/Helsinki"
    pause_status = "UNPAUSED"
  }

  timeout_seconds = 3600
  
  task {
    task_key        = "query_semmi"
    job_cluster_key = "sow_cluster"


     notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/sow/query_semmi_api"
      base_parameters = {
        environment         = var.ENV
        table_config_path   = "/Workspace${local.workspace_prefix}/pipelines/sow"
      }
    }
  }

  task {
    task_key        = "query_snowflake"
    job_cluster_key = "sow_cluster"


     notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/sow/query_snowflake"
      base_parameters = {
        environment         = var.ENV
        table_config_path   = "/Workspace${local.workspace_prefix}/pipelines/sow"
      }
    }
  }

  task {
    task_key        = "calculate_sow"
    job_cluster_key = "sow_cluster"
    depends_on {
      task_key = "query_semmi"
    }
    depends_on {
      task_key = "query_snowflake"
    }
     notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/sow/calculate_and_write_sow"
      base_parameters = {
        environment         = var.ENV
        table_config_path   = "/Workspace${local.workspace_prefix}/pipelines/sow"
      }
    }
  }

}