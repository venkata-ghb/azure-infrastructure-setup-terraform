with wholesale_all as(
  select sum(fw.WHOLESALES_AMOUNT_EXCL_FREIGHT_AND_OTHER_AND_CHARGING_AND_VAT) as wholesale_sum, dc.CUSTOMER_B2B as customer_id
  from PUB_GT_WHOLESALE.F_WHOLESALE_TRANSACTION_LINE_KESPRO fw
  left join
  PUB_GT_PRODUCTS.D_PRODUCT dp
  on fw.product_key = dp.product_key
  left join
  PUB_GT_B2BCUSTOMERS.D_CUSTOMER_B2B dc
  on fw.CUSTOMER_B2B_SOLD_TO_KEY = dc.CUSTOMER_B2B_KEY
  left join PUB_COMMON_GENERAL.D_MONTH dm 
    on dm.YEAR_MONTH = fw.YEAR_MONTH_KEY
  where
    fw.COMPANY_CODE = 1830
  and dp.PRODUCT_HIERARCHY_LEVEL_4_ID not in (9200, 9211, 9215, 9792)
  and fw.INVOICE_TYPE_CODE not in ('ZOMP', 'ZNMH', 'ZOMA')
  and dm.COMPARED_TO_CURRENT_MONTH >= -12
  group by CUSTOMER_B2B),
wholesale_storage as (
  select sum(fw.WHOLESALES_AMOUNT_EXCL_FREIGHT_AND_OTHER_AND_CHARGING_AND_VAT) as wholesale_sum_warehouse, dc.CUSTOMER_B2B as customer_id
  from PUB_GT_WHOLESALE.F_WHOLESALE_TRANSACTION_LINE_KESPRO fw
  left join
  PUB_GT_PRODUCTS.D_PRODUCT dp
  on fw.product_key = dp.product_key
  left join
  PUB_GT_B2BCUSTOMERS.D_CUSTOMER_B2B dc
  on fw.CUSTOMER_B2B_SOLD_TO_KEY = dc.CUSTOMER_B2B_KEY
  left join PUB_COMMON_GENERAL.D_MONTH dm 
    on dm.YEAR_MONTH = fw.YEAR_MONTH_KEY
  where
    fw.COMPANY_CODE = 1830
  and dp.PRODUCT_HIERARCHY_LEVEL_4_ID not in (9200, 9211, 9215, 9792)
  and fw.INVOICE_TYPE_CODE not in ('ZOMP', 'ZNMH', 'ZOMA')
  and fw.LOGISTICAL_MODEL_NAME_FI = 'Varasto'
  and dm.COMPARED_TO_CURRENT_MONTH >= -12
  group by CUSTOMER_B2B)
select wa.wholesale_sum, ws.wholesale_sum_warehouse, ltrim(wa.customer_id,'0') as customer_id from wholesale_all wa
left join wholesale_storage ws on wa.customer_id = ws.customer_id;