# ===============================================================================================================================
# valvira dlt pipeline
# ===============================================================================================================================
resource databricks_pipeline dlt_valvira {
  name = "dlt_valvira"

  cluster {
    label               = "default"
    spark_env_vars      = {}
    spark_conf          = local.global_spark_conf
    node_type_id        = local.default_node
    driver_node_type_id = local.default_node
    autoscale {
      min_workers = 1
      max_workers = 2
      mode        = "ENHANCED"
    }
  }

  library {
    notebook {
      path = "${local.workspace_prefix}/pipelines/valvira/dlt_valvira"
    }
  }

  storage     = "abfss://dlt@kdata${var.ENV}adls.dfs.core.windows.net/valvira/"
  continuous  = false
  channel     = "CURRENT"
  development = var.ENV == "dev" ? true : false
  photon      = false
  target      = "dlt_valvira"

  configuration = {
    environment     = var.ENV
    repository_path = "/Workspace${local.workspace_prefix}"
    target_schema   = "dlt_valvira"
  }
}

## SANITY CHECKUP PIPELINE

resource databricks_pipeline dlt_valvira_sanity {
  name = "dlt_valvira_sanity"

  cluster {
    label               = "default"
    spark_env_vars      = {}
    spark_conf          = local.global_spark_conf
    node_type_id        = local.default_node
    driver_node_type_id = local.default_node
    autoscale {
      min_workers = 1
      max_workers = 2
      mode        = "ENHANCED"
    }
  }

  library {
    notebook {
      path = "${local.workspace_prefix}/pipelines/valvira/dlt_valvira_sanity"
    }
  }

  storage     = "abfss://dlt@kdata${var.ENV}adls.dfs.core.windows.net/valvira/"
  continuous  = false
  channel     = "CURRENT"
  development = var.ENV == "dev" ? true : false
  photon      = false
  target      = "dlt_valvira"

  configuration = {
    environment     = var.ENV
    repository_path = "/Workspace${local.workspace_prefix}"
    target_schema   = "dlt_valvira"
  }
}
