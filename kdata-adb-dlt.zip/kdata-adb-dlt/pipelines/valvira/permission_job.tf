resource "databricks_permissions" "job-dlt_valvira" {
  job_id = databricks_job.dlt_valvira.id

  # DEVOPS PLATFORM
  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_PLATFORM"
    permission_level = "CAN_MANAGE"
  }

  # Data Factory
  access_control {
    service_principal_name = local.environmental[var.ENV].datafactory_app_id
    permission_level       = "CAN_MANAGE_RUN"
  }
}


resource "databricks_permissions" "job-dlt_valvira_sanity" {
  job_id = databricks_job.dlt_valvira_sanity.id

  # DEVOPS PLATFORM
  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_PLATFORM"
    permission_level = "CAN_MANAGE"
  }

  # Data Factory
  access_control {
    service_principal_name = local.environmental[var.ENV].datafactory_app_id
    permission_level       = "CAN_MANAGE_RUN"
  }
}