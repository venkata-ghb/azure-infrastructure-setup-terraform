# ==============================================================================================================================================
# Valvira Databricks job workflow
# ==============================================================================================================================================
resource databricks_job dlt_valvira {
  name = "job_${databricks_pipeline.dlt_valvira.name}"

  job_cluster {
    job_cluster_key = "valvira-cluster"
    new_cluster {
      num_workers    = 1
      spark_version  = "17.3.x-scala2.13"
      node_type_id   = "Standard_D4s_v5"
      spark_conf     = local.global_spark_conf
      spark_env_vars = { PYSPARK_PYTHON = "/databricks/python3/bin/python3" }
    }
  }

  email_notifications {
    on_failure = ["dlkeskokdataservice@tietoevry.com","itprocess.automation@kesko.fi"]
  }

  task {
    task_key = databricks_pipeline.dlt_valvira.name
    pipeline_task {
      pipeline_id = databricks_pipeline.dlt_valvira.id
    }
  }

  task {
    task_key        = "valvira_rest_api"
    job_cluster_key = "valvira-cluster"

    depends_on {
      task_key = databricks_pipeline.dlt_valvira.name
    }

    notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/valvira/valvira_silver_delta_to_valvira_api"
      base_parameters = {
        ENV                 = var.ENV
        EXTRACT_DATE        = "yyyy-mm"
        VALVIRA_APIM_KEY    = "kdata-valvira-apim-key"
        API_URL             = var.ENV == "prod" ? "https://api.kesko.fi/k-data/valvira/toimitustiedot" : "https://api-${var.ENV}.kesko.fi/k-data/valvira/test/toimitustiedot"
        VALVIRA_1905481_KEY = "kdata-valvira-vatcode-1905481-api-key"
        VALVIRA_0109862_KEY = "kdata-valvira-vatcode-0109862-api-key"
      }
    }
  }

  task {
    task_key        = "warmup_cluster"
    job_cluster_key = "valvira-cluster"
    notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/sap/warmup_cluster"
    }
  }
}

## Valivar Sanity Checkup Databricks Workflow

resource databricks_job dlt_valvira_sanity {
  name = "job_${databricks_pipeline.dlt_valvira_sanity.name}"

  job_cluster {
    job_cluster_key = "valvira-sanity-cluster"
    new_cluster {
      num_workers    = 1
      spark_version  = "17.3.x-scala2.13"
      node_type_id   = "Standard_D4s_v5"
      spark_conf     = local.global_spark_conf
      spark_env_vars = { PYSPARK_PYTHON = "/databricks/python3/bin/python3" }
    }
  }

  email_notifications {
    on_failure = ["dlkeskokdataservice@tietoevry.com","itprocess.automation@kesko.fi"]
  }

  task {
    task_key = databricks_pipeline.dlt_valvira_sanity.name
    pipeline_task {
      pipeline_id = databricks_pipeline.dlt_valvira_sanity.id
    }
  }

  task {
    task_key        = "valvira_rest_api_sanity"
    job_cluster_key = "valvira-sanity-cluster"

    depends_on {
      task_key = databricks_pipeline.dlt_valvira_sanity.name
    }

    notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/valvira/valvira_silver_delta_sanity_to_valvira_api"
      base_parameters = {
        ENV                 = var.ENV
        EXTRACT_DATE        = "yyyy-mm"
        VALVIRA_APIM_KEY    = "kdata-valvira-apim-key"
        API_URL             = var.ENV == "prod" ? "https://api.kesko.fi/k-data/valvira/test/toimitustiedot" : "https://api-${var.ENV}.kesko.fi/k-data/valvira/test/toimitustiedot"
        VALVIRA_1905481_KEY = "kdata-valvira-vatcode-1905481-api-key"
        VALVIRA_0109862_KEY = "kdata-valvira-vatcode-0109862-api-key"
      }
    }
  }

  task {
    task_key        = "warmup_cluster"
    job_cluster_key = "valvira-sanity-cluster"
    notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/sap/warmup_cluster"
    }
  }
}
