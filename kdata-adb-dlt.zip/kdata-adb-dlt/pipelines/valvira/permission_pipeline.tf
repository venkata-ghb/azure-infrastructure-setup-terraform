resource "databricks_permissions" "pipeline-dlt_valvira" {
  pipeline_id = databricks_pipeline.dlt_valvira.id

  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_PLATFORM"
    permission_level = "CAN_MANAGE"
  }
}

resource "databricks_permissions" "pipeline-dlt_valvira_sanity" {
  pipeline_id = databricks_pipeline.dlt_valvira_sanity.id

  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_PLATFORM"
    permission_level = "CAN_MANAGE"
  }
}
