# Databricks notebook source
# Import required Libraries
from pyspark.sql import types as T
from pyspark.sql import functions as F 
from pyspark.sql import Row
from tenacity import retry, stop_after_attempt, retry_if_exception_type, wait_fixed
from datetime import datetime,timedelta
import requests,json

# COMMAND ----------

#Setup Widgets to get parameters
dbutils.widgets.removeAll()
dbutils.widgets.text("EXTRACT_DATE", "yyyy-mm", "Provide date in 'yyyy-mm' Format")
dbutils.widgets.text("VALVIRA_1905481_KEY", "kdata-valvira-vatcode-1905481-api-key", "Api key (code - 1905481-8)")  
dbutils.widgets.text("VALVIRA_0109862_KEY", "kdata-valvira-vatcode-0109862-api-key", "Api key (code - 0109862-8)")
dbutils.widgets.text("VALVIRA_APIM_KEY", "kdata-valvira-apim-key", "APIM Key")
dbutils.widgets.text("API_URL", "https://api-dev.kesko.fi/k-data/valvira/toimitustiedot", "Valvira Api Url")
dbutils.widgets.text("ENV", "dev", "Environment")

# COMMAND ----------

#fetch necessary API keys
valvira_vatcode0109862_api_key= dbutils.secrets.get(scope = 'platform-keyvault', key = dbutils.widgets.get('VALVIRA_0109862_KEY'))
valvira_vatcode1905481_api_key= dbutils.secrets.get(scope = 'platform-keyvault', key = dbutils.widgets.get('VALVIRA_1905481_KEY'))
apim_key = dbutils.secrets.get(scope = 'platform-keyvault', key = dbutils.widgets.get('VALVIRA_APIM_KEY'))

#bronze table name
env = dbutils.widgets.get('ENV')
failed_table = f"silver_{env}.valvira.silver_failed_records"

# COMMAND ----------

#GET START DATE AND END DATE BASED ON PARAMS
def get_start_and_end_date():
    extract_date = dbutils.widgets.get('EXTRACT_DATE')
    if extract_date != 'yyyy-mm':
        # GET FIRST DATE AND LAST DATE OF PROVIDED MONTH
        month = datetime.strptime(extract_date, "%Y-%m")
        next_month = month.replace(month=month.month + 1, day=1)

        # CONVERT THE DATES TO STRING
        start_date = month.strftime('%Y-%m-%d')
        end_date = next_month.strftime('%Y-%m-%d')

        return start_date,end_date
    else:
        now_utc = datetime.utcnow()

        # GET FIRST DATE AND LAST DATE  BASED ON CURRENT UTC
        first_date_current_month = now_utc.replace(day=1)
        next_month = first_date_current_month + timedelta(days=33)
        first_date_next_month = next_month.replace(day=1)

        #CONVERT THE DATES TO STRING
        start_date = first_date_current_month.strftime('%Y-%m-%d')
        end_date = first_date_next_month.strftime('%Y-%m-%d')

    return start_date,end_date 

# COMMAND ----------

# API RELATED FUNCTIONS
def get_api_key(vat_code):
  """ RETURN API KEY BASED ON VAT CODE"""
  if vat_code == '1905481-8':
    key = valvira_vatcode1905481_api_key
  elif vat_code == '0109862-8':
    key = valvira_vatcode0109862_api_key
  else:
    raise Exception('INVALID VAT_CODE')  

  return key

# COMMAND ----------


class APITimeOutException(Exception):
    """
    Class to declare user defined Exception
    """
    pass

# COMMAND ----------

@retry(
    stop=stop_after_attempt(5),
    wait=wait_fixed(2),
    retry=retry_if_exception_type(APITimeOutException),
)
def post_to_api(data,vat_code):
  """POST THE DATA TO API"""
  
  response_json = None
  try:
    url = dbutils.widgets.get('API_URL')
    key = get_api_key(vat_code)
    headers = {
      'Content-Type': 'application/json',
      'x-allu-raportointi-apikey': key,
      'Ocp-Apim-Subscription-Key': apim_key
      }

    response = requests.request("PATCH", url, headers=headers, data=data)

    if response.status_code == 200:
      print(f'Request Successful with Response - {response}')
    elif response.status_code == 504:
      print(f'Request failed due to {response}')
      response_json = '504'
      raise APITimeOutException
    else:
      print(f'Request Failed due to - {response}')
      response_json = response.json()

  except APITimeOutException as te:
     print(f'API Timed out')

  except Exception as e:
    print(f'Failed while sending request to api with Error {e}') 
    raise e

  return response_json

def format_list(value):
    if isinstance(value, list):
        return "[" + ", ".join(format_list(item) for item in value) + "]"
    return str(value)

def format_failed_response(record):
    formatted_record = {
        "path": format_list(record.get("path", [])),
        "value": str(record.get("value", "")),
        "selite": format_list(record.get("selite", []))}
    return json.dumps(formatted_record, separators=(',', ':'))

# COMMAND ----------

#Read data from DLT
start_date,end_date = get_start_and_end_date()
print(f"Fetching data from {start_date} and till {end_date}.")

query = f'Select * from \
  (Select * from silver_{env}.valvira.silver_gtbw_kmarket UNION Select * from silver_{env}.valvira.silver_gtbw_kesko) \
    where SilverLoadDateTime >= "{start_date}" and SilverLoadDateTime < "{end_date}" '

valvira_df = spark.sql(query)
print(f'{valvira_df.count()} Records Fetched')

# COMMAND ----------

#Trim spaces from values
valvira_df = valvira_df.withColumn("vat_code", F.trim(valvira_df.vat_code)) \
  .withColumn("delivery_month", F.trim(valvira_df.delivery_month)) \
  .withColumn("alcohol_license", F.trim(valvira_df.alcohol_license)) \
  .withColumn("gtin", F.trim(valvira_df.gtin)) \
  .withColumn("usage_code", F.trim(valvira_df.usage_code)) \
  .withColumn("country_code", F.trim(valvira_df.country_code))

# COMMAND ----------

#Trim trailing zeroes from gtin
valvira_df = valvira_df.withColumn('gtin', F.regexp_replace('gtin', r'^[0]*', ''))

# COMMAND ----------

#Rename columns with respect to output json schema
renamed_valvira_df = valvira_df.withColumnRenamed('vat_code', 'asiakastunnus') \
  .withColumnRenamed('delivery_month', 'kausi') \
  .withColumnRenamed('alcohol_license', 'lupanumero') \
  .withColumnRenamed('gtin', 'tuotekoodi') \
  .withColumnRenamed('usage_code', 'tunniste') \
  .withColumnRenamed('country_code', 'maakoodi') \
  .withColumnRenamed('volume_litre', 'litramaara') \
  .withColumnRenamed('amount_euros', 'myyntihinta')

# COMMAND ----------

#Convert Empty Maakoodi to "000"
renamed_valvira_df = renamed_valvira_df.withColumn("maakoodi", \
  F.when(F.col("maakoodi")=="", "000") \
    .otherwise(F.col("maakoodi")))

# COMMAND ----------

#Deflatten Columns [lupanumero,tuotekoodi,tunniste,maakoodi,litramaara,myyntihinta] in to array of json objects
aggregate_rivit_df = renamed_valvira_df.withColumn('rivit', F.array(F.struct(F.col("lupanumero"), F.col("tuotekoodi"), F.col("tunniste"), F.col("maakoodi"), F.col("litramaara"), F.col("myyntihinta")))).select(F.col('asiakastunnus'),F.col('kausi'),F.col('rivit'))

# COMMAND ----------

#Deflatten Date column into a json and generate final valvira dataframe consisting jsons to be sent to api in proper formats
deflatten_kausi_df = aggregate_rivit_df.withColumn('kausi', \
  F.struct(F.col('kausi').substr(0,4).cast(T.IntegerType()).alias('vuosi'), \
    F.col('kausi').substr(5,6).cast(T.IntegerType()).alias('kuukausi')))

# COMMAND ----------

#Final output dataframe
output_valvira_df = deflatten_kausi_df.select(F.struct(F.col("asiakastunnus"), F.col("kausi"), F.col("rivit")).alias("output")) \
  .withColumn("output",F.to_json(F.col("output")))

# COMMAND ----------

#Generate string out of json
valvira_jsons = output_valvira_df.select(F.expr("collect_list({})".format('output'))).first()[0]

# COMMAND ----------

#Iterate through the List of Jsons and post each json
failed_records_list = []
retry_list = []
for json_string in valvira_jsons:
  #get vatcode from string
  json_dict = json.loads(json_string)
  vat_code = json_dict['asiakastunnus']

  #post to API
  failed_response = post_to_api(json_string,vat_code)
  if failed_response is not None and failed_response != '504':
      print(f'Failed to post JSON to API for vat_code {vat_code}. Adding following record to failed records list: {failed_response}')

      if isinstance(failed_response, list):
          for record in failed_response:
              if isinstance(record, dict):
                  failed_records_list.append(Row(response=format_failed_response(record)))

      elif isinstance(failed_response, dict):
          failed_records_list.append(Row(response=format_failed_response(failed_response)))

      else:
          print(f'Unexpected response format for vat_code {vat_code}: {failed_response}')
          failed_records_list.append(Row(response=json.dumps({"error": str(failed_response)})))
                    
  elif failed_response == '504':
      print('All retries failed, sending to the retry table for later reprocessing')
      retry_list.append(Row(failedjsons=json_string))
  else:
      print(f'Sent Data for Vat Code : {vat_code} Successfully')
  
print('All Valid Valvira data was send Successfully')

# COMMAND ----------

if failed_records_list:
  print(f'FAILED RECORDS LIST: {failed_records_list}')
    
  #define the schema of response message
  failed_response_schema = T.StructType([T.StructField("response", T.StringType(), True)])
  
  #create data frame with appropriate silver columns
  failed_response_df = spark.createDataFrame(failed_records_list,schema=failed_response_schema)
  failed_response_df = failed_response_df.withColumn("BronzeLoadDateTime", F.current_timestamp()) \
    .withColumn("SilverLoadDateTime", F.current_timestamp()) \
    .withColumn("SrcID", F.lit("source_system N/A"))

  #write dataframe into silver table
  failed_response_df.write.format("delta").mode("append").saveAsTable(failed_table)
  print('Failed Records Stored in Silver Table')

# COMMAND ----------

#create draframe for records that need to be retried, write such records in retry table, so they can be manually processed later ()
if retry_list:
  retry_df = spark.createDataFrame(retry_list)
  retry_df = retry_df.withColumn("BronzeLoadDateTime", F.current_timestamp()) \
    .withColumn("SilverLoadDateTime", F.current_timestamp()) \
    .withColumn("SrcID", F.lit("source_system N/A"))

  retry_df.write.format("delta").mode("append").saveAsTable(f'silver_{env}.valvira.silver_timedout_records')
  print('Timed Out  Records Stored in Silver Table')
