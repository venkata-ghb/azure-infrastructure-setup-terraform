# Databricks notebook source
# MAGIC %md
# MAGIC # Install dlt functions

# COMMAND ----------

import sys
sys.path.append("/Workspace/Repos/DLT/kdata-adb-dlt/dlt_functions/dltlib")

# COMMAND ----------

# MAGIC %md
# MAGIC # Imports

# COMMAND ----------

import dlt
import json
from pyspark.sql.functions import col, expr, current_timestamp
from pyspark.sql.types import TimestampType

# COMMAND ----------

from dltlib import *

# COMMAND ----------

# MAGIC %md
# MAGIC # Execution

# COMMAND ----------

options = {"cloudFiles.format": "parquet"}
env = spark.conf.get("environment")
inputPath = f"abfss://raw@kdata{env}adls.dfs.core.windows.net/natural/KAI/kespro/"
process_cols = {"LoadDateTime": col("Timestamp").cast(TimestampType())}
target_schema = spark.conf.get("target_schema") # schema in the local hive metastore
source_system = "kespro_kai"

# The processing rules for the bronze and silver layers are written
# in a single json file in the dlt repository.
pipeline_path = spark.conf.get("repository_path")
table_config_path = f"{pipeline_path}/tables.json"
with open(file=table_config_path, mode="r") as file:
    pipeline_tables = json.load(file)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Ingest raw data to bronze layer

# COMMAND ----------

# MAGIC %md ### DLTLIB-functions to fix Kespro-kai timestampNtz-problem.
# MAGIC
# MAGIC More permanent fix will be to add a parameter towards functions in dltlib to include dict item additional_table_properties that should be added to the table properties in bronze, temp and silver tables.
# MAGIC
# MAGIC Additionally, silver function dlt.create_streaming_live_table(f"silver_{source_system}_{target_table}") will be replaced with proper declaration so that table properties can be updated to silver level too
# MAGIC

# COMMAND ----------

def ingest_raw_data(table, inputPath, process_cols = None, **sparkOptions):
        #This is an example fix of the timestampNtz, where all the dltlib-functions have been copied to this executing notebook

        @dlt.table(
            name=f"bronze_{table}",
            comment="This table was created with Autoloader.",
            table_properties={"quality": "bronze",
                              "delta.enableChangeDataFeed": "True",
                              "delta.feature.timestampNtz": "supported"}
        )
        def load_dynamic_table_bronze():
            # Autoloader can infer schema for file types such as parquet, json and csv.
            df = (
                spark.readStream.format("cloudFiles")
                .options(**sparkOptions["sparkOptions"])
                .load(inputPath)
            )
            # If function call includes calculated columns, they are included into returned data frame here
            # 
            if process_cols:
                for column_name, column_statement in process_cols.items():
                    df = df.withColumn(column_name, column_statement)


            df = df.withColumn("BronzeLoadDateTime", current_timestamp())

            return df

# COMMAND ----------

def create_silver_temp_table(
        source_table,
        target_table,
        column_mapping,
        expectations,
        use_cdc = True,
        source_system = "source_system N/A",
        bronze_load_timestamp_column_name="BronzeLoadDateTime",
        live_table=True,
    ):
        
        @dlt.table(
            name=f"temp_{target_table}",
            comment="Temporary table for renaming columns before SCD is implemented.",
            temporary=True,
            table_properties={"quality": "temp",
                              "delta.feature.timestampNtz": "supported"},
        )
        @dlt.expect_all_or_drop(json.loads(expectations))
        def load_dynamic_table_silver():
            
            # Generate a select expression for renaming columns
            selExpr = [
                f"{value} as {key}"
                for key, value in column_mapping.items()
            ]
            
            # Add a load datetime to allow identifying rows processed
            # by a single instance of the pipeline. 
            load_dttm = [
                "current_timestamp() as SilverLoadDateTime",
                f"{bronze_load_timestamp_column_name} as BronzeLoadDateTime"   
            ]

            # Add an identifier for the source system. 
            # This is intended to be used mainly in the gold layer
            # where multiple different source systems can be combined in
            # a single table.
            source = [f"'{source_system}' as SrcID"]
            
            if use_cdc:
                table_prefix = "cdc"
                # DLT uses three columns with fixed names on the chage data feed.
                # They are needed for applying the SCD on the silver layer.
                cdc_column_list = [
                    f"_change_type as _change_type",
                    f"_commit_version as _commit_version",
                    f"_commit_timestamp as _commit_timestamp",
                ]
                # Append the metadata columns to a dynamic list of columns
                selExpr = selExpr + cdc_column_list + load_dttm + source
            else:
                table_prefix = "bronze"
                selExpr = selExpr + load_dttm + source
            
            table = f"LIVE.{table_prefix}_{source_table}" if live_table else source_table

            df = (
                spark.readStream.format("delta")
                .option("ignoreChanges", "true")
                .table(table)
            )

            return df.selectExpr(selExpr)

# COMMAND ----------

def create_silver_table(source_system, target_table, keys, sequence_by="BronzeLoadDateTime"):
    dlt.create_streaming_table(f"silver_{source_system}_{target_table}", table_properties={"quality": "silver", "delta.feature.timestampNtz": "supported"})
    dlt.apply_changes(
        target=f"silver_{source_system}_{target_table}",
        source=f"temp_{target_table}",
        keys=keys,
        sequence_by=col(sequence_by),
        stored_as_scd_type=1,
    )

# COMMAND ----------

for table in pipeline_tables.items():
  print(table[0], table[1]["kai_prefix"])

# COMMAND ----------

for table in pipeline_tables.items():
    # Create the bronze tables.
    table_name = table[0]
    kai_prefix = table[1].get("kai_prefix")
    ingest_raw_data(
      table=table_name, 
      sparkOptions=options,
      inputPath=f"{inputPath}/{kai_prefix}/{table_name}",
      process_cols = process_cols
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Process data from bronze to silver

# COMMAND ----------

for source_table, target_table in pipeline_tables.items():
  if target_table.get("process_silver"):
    create_silver_temp_table(
          source_table=source_table,
          target_table=target_table["target"],
          column_mapping=target_table["column_mapping"],
          expectations=dltlib.generate_expectations(
              keys=target_table["keys"],
              allowed_values=target_table["allowed_values"]
          ),
          use_cdc = False,
          source_system = 'kespro_kai'
      )  
    create_silver_table(
          source_system=source_system,
          target_table=target_table["target"], 
          keys=target_table["keys"],
          sequence_by="LoadDateTime"
      )
