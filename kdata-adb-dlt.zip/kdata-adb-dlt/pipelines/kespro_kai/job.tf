resource databricks_job dlt_kespro_kai {
  name = "dlt_kespro_kai_${var.ENV}"

  job_cluster {
    job_cluster_key = "kesprokai-cluster"
    new_cluster {
      num_workers    = 4
      spark_version  = "17.3.x-scala2.13"
      node_type_id   = "Standard_D4s_v5"
      spark_conf     = local.global_spark_conf
      spark_env_vars = { PYSPARK_PYTHON = "/databricks/python3/bin/python3" }
      data_security_mode = "SINGLE_USER"
    }
  }
  schedule {
    quartz_cron_expression = "0 0 6 ? * MON"
    timezone_id            = "Europe/Helsinki"
    pause_status           = "UNPAUSED"
  }

  timeout_seconds = 3600

  run_as {
    service_principal_name = local.environmental[var.ENV].app_id
  }

  task {
    task_key = databricks_pipeline.dlt_kespro_kai.name

    pipeline_task {
      pipeline_id = databricks_pipeline.dlt_kespro_kai.id
    }
  }

  # Writer warmup task

  task {
    task_key        = "warmup_cluster"
    job_cluster_key = "kesprokai-cluster"

    notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/sap/warmup_cluster"
    }
  }


  task {
    task_key        = "write_kesprodata_silver_tables"
    job_cluster_key = "kesprokai-cluster"

    depends_on {
      task_key = "dlt_kespro_kai"
    }

    notebook_task {
      notebook_path = "${local.workspace_prefix}/pipelines/sap/psql_writer"
      base_parameters = {
        env            = var.ENV
        pipeline_path  = "/Workspace${local.workspace_prefix}/pipelines/kespro_kai"
        max_workers    = 5
        writer_config  = "kesprodata_kai_silver"
        target_database = "kesprodata"
      }
    }
  }
}

# ==============================================================================================================================================
