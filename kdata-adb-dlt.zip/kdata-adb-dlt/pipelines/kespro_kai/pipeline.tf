resource databricks_pipeline dlt_kespro_kai {
  name = "dlt_kespro_kai"

  cluster {
    label          = "default"
    spark_env_vars = {}
    spark_conf = local.global_spark_conf
    autoscale {
      min_workers = lookup({
        dev  = 1
        test = 1
        prod = 1
      }, var.ENV)
      max_workers = lookup({
        dev  = 2
        test = 2
        prod = 2
      }, var.ENV)
      mode = "ENHANCED"
    }
  }

  library {
    notebook {
      path = "${local.workspace_prefix}/pipelines/kespro_kai/dlt_kespro_kai"
    }
  }

  storage     = "${local.storage_prefix}/kespro_kai/"
  continuous  = false
  channel     = "CURRENT"
  development = var.ENV == "dev" ? true : false
  photon      = false
  target      = "dlt_kespro_kai_${var.ENV}"

  configuration = {
    environment     = var.ENV
    repository_path = "/Workspace${local.workspace_prefix}/pipelines/kespro_kai"
    target_schema   = "dlt_kespro_kai_${var.ENV}"
  }
}


