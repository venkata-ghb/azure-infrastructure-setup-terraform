resource databricks_job dlt_soma {
  name = "dlt_soma_${var.ENV}"

  schedule {
    # Run at 8:00 AM EET time
    quartz_cron_expression = "0 0 7 ? * * *"
    timezone_id            = "Europe/Helsinki"
    pause_status           = "UNPAUSED"
  }

  pipeline_task {
    pipeline_id = databricks_pipeline.dlt_soma.id
  }
}
