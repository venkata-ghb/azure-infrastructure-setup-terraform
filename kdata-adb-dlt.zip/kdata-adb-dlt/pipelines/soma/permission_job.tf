resource "databricks_permissions" "job-dlt_soma" {
  job_id = databricks_job.dlt_soma.id

  # DEVOPS PLATFORM
  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_PLATFORM"
    permission_level = "CAN_MANAGE"
  }
}
