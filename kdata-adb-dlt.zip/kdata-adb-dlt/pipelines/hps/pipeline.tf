resource databricks_pipeline dlt_hps {
  name = "dlt_hps"

  cluster {
    label               = "default"
    spark_env_vars      = {}
    spark_conf          = local.global_spark_conf
    node_type_id        = local.default_node
    driver_node_type_id = local.default_node
    autoscale {
      min_workers = 1
      max_workers = 2
      mode        = "ENHANCED"
    }
  }

  library {
    notebook {
      path = "${local.workspace_prefix}/pipelines/hps/dlt_hps"
    }
  }

  catalog     = "silver_${var.ENV}"
  continuous  = false
  channel     = "PREVIEW"
  development = var.ENV != "prod" ? true : false
  photon      = false
  target      = "huolenpitosopimus"

  configuration = {
    environment     = var.ENV
    repository_path = "/Workspace${local.workspace_prefix}/pipelines/hps"
    target_schema   = "dlt_huolenpitosopimus"
  }
}
