resource databricks_job dlt_hps {
  name = databricks_pipeline.dlt_hps.name

  job_cluster {
    job_cluster_key = "hps-cluster"
    new_cluster {
      num_workers        = 1
      spark_version      = "17.3.x-scala2.13"
      node_type_id       = "Standard_D4s_v5"
      spark_conf         = local.global_spark_conf
      spark_env_vars     = { PYSPARK_PYTHON = "/databricks/python3/bin/python3" }
      data_security_mode = "USER_ISOLATION"
    }
  }

  task {
    task_key = databricks_pipeline.dlt_hps.name

    pipeline_task {
      pipeline_id = databricks_pipeline.dlt_hps.id
    }
  }

  task {
    task_key        = "warmup_cluster"
    job_cluster_key = "hps-cluster"

    notebook_task {
      notebook_path = "/Repos/DLT/kdata-adb-dlt/pipelines/sap/warmup_cluster"
    }
  }

  task {
    task_key        = "write_invoice_to_eventhub"
    job_cluster_key = "hps-cluster"

    depends_on {
      task_key = "dlt_hps"
    }
    depends_on {
      task_key = "warmup_cluster"
    }

    notebook_task {
      notebook_path = "/K-DATA-RESTRICTED/Common/v2/stream_delta_table_to_confluent"
      base_parameters = {
        env                          = var.ENV
        source_catalog               = "bronze_${var.ENV}"
        source_schema                = "huolenpitosopimus"
        source_table                 = "invoice"
        target_kafka_server          = "kdata-${var.ENV}-int-ctchr-eh.servicebus.windows.net:9093"
        target_kafka_topic           = "ctchr-harmonised"
        target_kafka_username        = "$ConnectionString"
        target_kafka_password_secret = "eh-ctchr-harmonised-adb-write"
        sql_query_file               = "hps/hps-to-eventhub.sql"
        secret_scope_name            = "platform-keyvault"
        start_timestamp              = "2024-09-12T00:00:00" # This is set to avoid reading before schema changes, which would cause failures
      }
    }
  }
}
