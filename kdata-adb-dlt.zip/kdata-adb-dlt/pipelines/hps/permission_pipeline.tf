resource "databricks_permissions" "pipeline-dlt_hps" {
  pipeline_id = databricks_pipeline.dlt_hps.id

  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_PLATFORM"
    permission_level = "CAN_MANAGE"
  }
}
