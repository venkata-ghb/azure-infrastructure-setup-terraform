# ===============================================================================================================================
# ktavara dlt pipeline (Full load)
# ===============================================================================================================================
resource databricks_pipeline dlt_ktavara_full {
  name = "dlt_ktavara_full"

  cluster {
    label          = "default"
    spark_env_vars = {}
    spark_conf     = local.global_spark_conf
    autoscale {
      min_workers = 1
      max_workers = 2
      mode        = "ENHANCED"
    }
  }

  library {
    notebook {
      path = "${local.workspace_prefix}/pipelines/ktavara/dlt_ktavara_full"
    }
  }

  storage     = "abfss://dlt@kdata${var.ENV}adls.dfs.core.windows.net/k_tavara/"
  continuous  = false
  channel     = "CURRENT"
  development = var.ENV == "dev" ? true : false
  photon      = false
  target      = "dlt_ktavara"

  configuration = {
    environment     = var.ENV
    repository_path = "/Workspace/${local.workspace_prefix}"
    target_schema   = "dlt_ktavara"
  }
}

# ===============================================================================================================================
# ktavara dlt pipeline (Incremental load)
# ===============================================================================================================================
resource databricks_pipeline dlt_ktavara_incremental {
  name = "dlt_ktavara_incremental"

  cluster {
    label          = "default"
    spark_env_vars = {}
    spark_conf     = local.global_spark_conf
    autoscale {
      min_workers = 1
      max_workers = 2
      mode        = "ENHANCED"
    }
  }

  library {
    notebook {
      path = "${local.workspace_prefix}/pipelines/ktavara/dlt_ktavara_incremental"
    }
  }

  storage     = "abfss://dlt@kdata${var.ENV}adls.dfs.core.windows.net/k_tavara/"
  continuous  = false
  channel     = "CURRENT"
  development = var.ENV == "dev" ? true : false
  photon      = false
  target      = "dlt_ktavara"

  configuration = {
    environment     = var.ENV
    repository_path = "/Workspace/${local.workspace_prefix}"
    target_schema   = "dlt_ktavara"
  }
}

# Ktavara rollout orders steering table
resource databricks_pipeline dlt_ktavara_rolloutorders {
  name = "dlt_ktavara_rolloutorders"

  cluster {
    label          = "default"
    spark_env_vars = {}
    spark_conf     = local.global_spark_conf
    autoscale {
      min_workers = 1
      max_workers = 2
      mode        = "ENHANCED"
    }
  }

  library {
    notebook {
      path = "${local.workspace_prefix}/pipelines/ktavara/dlt_ktavara_rolloutorders"
    }
  }

  storage     = "abfss://dlt@kdata${var.ENV}adls.dfs.core.windows.net/k_tavara/"
  continuous  = false
  channel     = "CURRENT"
  development = var.ENV == "dev" ? true : false
  photon      = false
  target      = "dlt_ktavara"

  configuration = {
    environment     = var.ENV
    repository_path = "/Workspace/${local.workspace_prefix}"
    target_schema   = "dlt_ktavara"
  }
}

