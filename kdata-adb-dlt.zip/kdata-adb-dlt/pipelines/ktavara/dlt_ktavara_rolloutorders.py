# Databricks notebook source
# MAGIC %md
# MAGIC # Imports

# COMMAND ----------

import json

# COMMAND ----------

# MAGIC %md
# MAGIC ## Import DLT pipeline functions

# COMMAND ----------
import os
import sys
repository_path = spark.conf.get("repository_path")
sys.path.append(os.path.abspath(f"{repository_path}/dlt_functions/dltlib"))
from dltlib import *

# COMMAND ----------

# MAGIC %md
# MAGIC # Execution

# COMMAND ----------

options = {"cloudFiles.format": "parquet"} # source file format in the data lake raw container
env = spark.conf.get("environment") # integration environment
inputPath = f"abfss://raw@kdata{env}adls.dfs.core.windows.net/natural/GTMAN/Stage/KFDMRampdown/Data/RolloutOrders/" 
process_cols = {}
target_schema = spark.conf.get("target_schema") # schema in the local hive metastore
source_system = "manual"

# The processing rules for the bronze and silver layers are written
# in a single json file in the dlt repository.
pipeline_path = spark.conf.get("repository_path")
table_config_path = f"{pipeline_path}/pipelines/ktavara/tables_rolloutorders.json"
with open(file=table_config_path, mode="r") as file:
    pipeline_tables = json.load(file)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Ingest raw data to bronze layer and update the cdc log

# COMMAND ----------

for table in pipeline_tables.keys():
    # Create the bronze tables.
    dltlib.ingest_raw_data(
      table=table, 
      sparkOptions=options, 
      inputPath=f"{inputPath}/{table}"
    )

    # Create the cdc tables by reading the change data feed of the bronze tables.
    dltlib.create_cdc_table(
      schema=target_schema, 
      table=table, 
      temporary=True
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Update the silver layer as a scd type 1

# COMMAND ----------

for source_table, target_table in pipeline_tables.items():
  # process only if silver processing is needed
  if target_table.get("process_silver") == "True":
    # From KVALIKOIMA KTAVARA tables cannot be loaded to silver layer if the bronze layer tables do not 
    # exist before the pipeline starts. The first instance of the pipeline generates the bronze
    # tables, the second instance generates the cdc table, temporary table and the silver table.
    if dltlib.check_if_table_exists(f"{target_schema}.bronze_{source_table}"):
        dltlib.create_silver_temp_table(
            source_table=source_table,
            target_table=target_table["target"],
            column_mapping=target_table["column_mapping"],
            expectations=dltlib.generate_expectations(
                keys=target_table["keys"],
                allowed_values=target_table["allowed_values"]
            ),
            use_cdc = True,
            source_system = source_system
        )

        dltlib.create_silver_table_scd1(
            source_system=source_system,
            target_table=target_table["target"], 
            keys=target_table["keys"]
        )
