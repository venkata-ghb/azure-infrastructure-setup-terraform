resource "databricks_permissions" "pipeline-dlt_ktavara_full" {
  pipeline_id = databricks_pipeline.dlt_ktavara_full.id

  # DEVOPS PLATFORM
  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_PLATFORM"
    permission_level = "CAN_MANAGE"
  }

  # Data Factory
  access_control {
    service_principal_name = local.environmental[var.ENV].datafactory_app_id
    permission_level       = "CAN_RUN"
  }
}

resource "databricks_permissions" "pipeline-dlt_ktavara_incremental" {
  pipeline_id = databricks_pipeline.dlt_ktavara_incremental.id

  # DEVOPS PLATFORM
  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_PLATFORM"
    permission_level = "CAN_MANAGE"
  }

  # Data Factory
  access_control {
    service_principal_name = local.environmental[var.ENV].datafactory_app_id
    permission_level       = "CAN_RUN"
  }
}

resource "databricks_permissions" "pipeline-dlt_ktavara_rolloutorders" {
  pipeline_id = databricks_pipeline.dlt_ktavara_rolloutorders.id

  # DEVOPS PLATFORM
  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_PLATFORM"
    permission_level = "CAN_MANAGE"
  }

  # Data Factory
  access_control {
    service_principal_name = local.environmental[var.ENV].datafactory_app_id
    permission_level       = "CAN_RUN"
  }
}
