resource "databricks_permissions" "job-dlt_ktavara" {
  job_id = databricks_job.dlt_ktavara.id

  # DEVOPS PLATFORM
  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_PLATFORM"
    permission_level = "CAN_MANAGE"
  }

  # Data Factory
  access_control {
    service_principal_name = local.environmental[var.ENV].datafactory_app_id
    permission_level       = "CAN_MANAGE_RUN"
  }
}

resource "databricks_permissions" "job-dlt_ktavara_rolloutorders" {
  job_id = databricks_job.dlt_ktavara_rolloutorders.id

  # DEVOPS PLATFORM
  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_PLATFORM"
    permission_level = "CAN_MANAGE"
  }

  # Data Factory
  access_control {
    service_principal_name = local.environmental[var.ENV].datafactory_app_id
    permission_level       = "CAN_MANAGE_RUN"
  }
}

