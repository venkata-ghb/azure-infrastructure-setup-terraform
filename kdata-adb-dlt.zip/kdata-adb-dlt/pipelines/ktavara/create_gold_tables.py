# Databricks notebook source
# MAGIC %md
# MAGIC ### Create Gold tables in gold_<env>.grocery_trade

# COMMAND ----------

dbutils.widgets.text(name="env",defaultValue="dev")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table: store_assortment_class

# COMMAND ----------

# MAGIC %md
# MAGIC #### Create Table Query

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS gold_${env}.grocery_trade.store_assortment_class (
# MAGIC display_group_id int,	
# MAGIC size_class_code string,	
# MAGIC size_class_code_name string,	
# MAGIC business_unit_erp_code string,	
# MAGIC product_group int,	
# MAGIC start_date date,	
# MAGIC end_date date,	
# MAGIC SrcID string,	
# MAGIC GoldLoadDateTime timestamp
# MAGIC )

# COMMAND ----------

# MAGIC %md
# MAGIC #### Insert data into table

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT OVERWRITE gold_${env}.grocery_trade.store_assortment_class
# MAGIC SELECT
# MAGIC   distinct BUS.Display_group_id, BUS.size_class_code, BUS.size_class_code size_class_code_name 
# MAGIC -- BusinessUnit erp code
# MAGIC ,  BU.business_unit_erp_code 
# MAGIC -- productgroup - MCAT
# MAGIC ,case
# MAGIC -- 2 digits in the left
# MAGIC     when len(DG.short_name) = 2 then left(DG.short_name, 2) 
# MAGIC -- 3 digits in the left
# MAGIC     when len(DG.short_name) = 3 then left(DG.short_name, 2) 
# MAGIC -- 2 digits in the left  + other text
# MAGIC     when (left(DG.short_name, 2)) > 0 then left(DG.short_name, 2) 
# MAGIC -- 'KCM KOKO - ’ text before product group
# MAGIC     when left(DG.short_name, 8) = 'KCM KOKO' then left((right((substring(DG.short_name, 1, 14)), 3)), 2)
# MAGIC     else 0
# MAGIC   End productgroup 
# MAGIC -- Validity for SizeClassCode
# MAGIC ,  BUS.valid_from,
# MAGIC   BUS.end_date,
# MAGIC   'Ktavara' SrcID,
# MAGIC   current_timestamp as GoldLoadDateTime
# MAGIC FROM
# MAGIC   silver_${env}.k_tavara.silver_kvalikoima_assortment_size_class_code BUS
# MAGIC   inner join silver_${env}.k_tavara.silver_kvalikoima_business_unit BU on BUS.business_unit_id = BU.business_unit_id
# MAGIC   inner join silver_${env}.k_tavara.silver_kvalikoima_display_group DG on BUS.display_group_id = DG.display_group_id 
# MAGIC -- RollOut – ProductGroups
# MAGIC where
# MAGIC   left(DG.name, 2) in (select merchandise_category from silver_${env}.k_tavara.silver_manual_rollout_steering_table
# MAGIC     where system_name = 'Ktavara' and start_date <= getdate()   )
# MAGIC  -- Keva Alue codes are ignored   
# MAGIC   and len(BUS.size_class_code) < 10
# MAGIC union all
# MAGIC select
# MAGIC   distinct SA.DisplayGroupID,
# MAGIC   SA.AssortmentClassName size_class_code,
# MAGIC   SA.AssortmentClassShortName size_class_code_name 
# MAGIC -- BusinessUnit erp code
# MAGIC ,  SA.BusinessUnitID 
# MAGIC -- productgroup - MCAT
# MAGIC ,  left(DG.MerchandizeCatID, 2) productgroup 
# MAGIC -- Validity for SizeClassCode
# MAGIC ,  SA.AssortmentStartDate start_date,
# MAGIC   case
# MAGIC     when SA.AssortmentEndDate is null then '2999-12-31'
# MAGIC     else SA.AssortmentEndDate
# MAGIC   end EndDate,
# MAGIC   'A2G' SrcID,
# MAGIC   current_timestamp as GoldLoadDateTime
# MAGIC from
# MAGIC   silver_${env}.kdata_gt_curated_a2g.storeassortmentclass SA
# MAGIC   inner join silver_${env}.kdata_gt_curated_a2g.displaygroup DG on SA.DisplayGroupID = DG.DisplayGroupID 
# MAGIC ------   data from max.loaddate
# MAGIC   INNER JOIN (
# MAGIC     SELECT BusinessUnitID, MAX(CAST(_RawLoadDateTime AS DATE)) AS max_load_date
# MAGIC     FROM silver_${env}.kdata_gt_curated_a2g.storeassortmentclass
# MAGIC     GROUP BY BusinessUnitID   ) AS subq ON 
# MAGIC     subq.BusinessUnitID = SA.BusinessUnitID AND CAST(SA._RawLoadDateTime AS DATE) = subq.max_load_date 
# MAGIC -- RollOut – ProductGroups
# MAGIC where
# MAGIC   left(DG.MerchandizeCatID, 2) in ( select merchandise_category from silver_${env}.k_tavara.silver_manual_rollout_steering_table
# MAGIC     where system_name = 'A2G' and start_date <= getdate()   )
# MAGIC   -- Keva Alue codes are ignored    
# MAGIC  and len(SA.AssortmentClassName) < 10

# COMMAND ----------

# MAGIC %md
# MAGIC ### Table: store_keva_suva_assortment

# COMMAND ----------

# MAGIC %md
# MAGIC #### Create Table

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS gold_${env}.grocery_trade.store_keva_suva_assortment (		
# MAGIC business_unit_erp_code string,
# MAGIC product_sap_id string,
# MAGIC assortment_type_description string,	
# MAGIC assortment_type string,	
# MAGIC product_group int,	
# MAGIC start_date date,	
# MAGIC end_date date,	
# MAGIC display_group_id int,	
# MAGIC SrcID string,	
# MAGIC GoldLoadDateTime timestamp,
# MAGIC bu_size_class_code string
# MAGIC )

# COMMAND ----------

# MAGIC %md
# MAGIC #### Insert data into table

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT OVERWRITE gold_${env}.grocery_trade.store_keva_suva_assortment
# MAGIC
# MAGIC   select 
# MAGIC   distinct *
# MAGIC   FROM analyst_workbench.gt_analysts.valikoimatiedotus_${env}
# MAGIC   where
# MAGIC   -- current and future assortment data
# MAGIC   start_date >= date_sub(current_timestamp(), 30) 
# MAGIC
# MAGIC   -- RollOut – Merchandise_categories for Ktavara data
# MAGIC   and product_group in (select merchandise_category from silver_${env}.k_tavara.silver_manual_rollout_steering_table RO
# MAGIC   where RO.system_name = 'Ktavara' and RO.start_date <= getdate())
# MAGIC
# MAGIC
# MAGIC   union all
# MAGIC
# MAGIC   -- BusinessUnit
# MAGIC   SELECT DISTINCT SP.BusinessUnitID business_unit_erp_code
# MAGIC   -- Product data
# MAGIC   , SP.ProductID product_sap_id
# MAGIC   -- Assortment data
# MAGIC   , SP.AssortmentType assortment_type_description
# MAGIC   , CASE
# MAGIC       WHEN SP.AssortmentType = 'Suva' THEN 8
# MAGIC       ELSE 1
# MAGIC     END assortment_type
# MAGIC   -- ProductGroup data
# MAGIC   , LEFT(BP.Productgroup, 2) product_group
# MAGIC   -- Assortment Plan Period - StartDate and EndDate
# MAGIC   , SP.AssortmentStartDate start_date, SP.AssortmentEndDate end_date
# MAGIC   -- DisplayGroup data
# MAGIC   , SP.DisplayGroupID display_group_id
# MAGIC   -- Source
# MAGIC   , 'A2G' SrcID
# MAGIC   , CURRENT_TIMESTAMP AS GoldLoadDateTime
# MAGIC   , SP.AssortmentClass bu_size_class_code
# MAGIC   FROM silver_${env}.kdata_gt_curated_a2g.storeassortmentproduct SP
# MAGIC   INNER JOIN silver_${env}.kdata_gt_curated_sap.basicproducts BP ON SP.ProductID = CAST(BP.SAPID AS BIGINT)
# MAGIC   ------   data from max.loaddate
# MAGIC   INNER JOIN (
# MAGIC     SELECT BusinessUnitID, MAX(CAST(loaddatetime AS DATE)) AS max_load_date
# MAGIC     FROM silver_${env}.kdata_gt_curated_a2g.storeassortmentproduct
# MAGIC     GROUP BY BusinessUnitID
# MAGIC   ) AS subq ON subq.BusinessUnitID = SP.BusinessUnitID AND CAST(SP.loaddatetime AS DATE) = subq.max_load_date
# MAGIC   -- future data is selected
# MAGIC   where SP.AssortmentStartDate >= date_sub(current_timestamp(), 30)
# MAGIC
# MAGIC   -- RollOut – ProductGroups
# MAGIC   AND 
# MAGIC   LEFT(BP.Productgroup, 2) IN (  SELECT merchandise_category   FROM silver_${env}.k_tavara.silver_manual_rollout_steering_table RO
# MAGIC     WHERE RO.system_name = 'A2G' AND RO.start_date <= GETDATE())

# COMMAND ----------

# MAGIC %md
# MAGIC -- This is the old code as, we kept it just for reference , but now we load this table from analyst workbench
# MAGIC INSERT OVERWRITE gold_${env}.grocery_trade.store_keva_suva_assortment
# MAGIC select distinct
# MAGIC -- BU - BusinessUnit - BU erp code
# MAGIC BU.business_unit_erp_code
# MAGIC -- product data
# MAGIC , P.product_sap_id
# MAGIC ,case
# MAGIC   when AA.assortment_type in ('SUVA', 'suva', 'Suva') then 'Suva'
# MAGIC   when AA.assortment_type in ('KEVA', 'keva', 'Keva') then 'Keva'
# MAGIC    else 'n/a' end assortment_type_description   
# MAGIC ,CASE
# MAGIC   when AA.assortment_type in ('SUVA', 'suva', 'Suva') then 8
# MAGIC   when AA.assortment_type in ('KEVA', 'keva', 'Keva') then 1
# MAGIC    else 0 end assortment_type 
# MAGIC
# MAGIC  -- BP - basic product - mcat
# MAGIC , left(BP.Productgroup, 2) product_group
# MAGIC -- APP - assortment plan period - startdate, enddate, DisplayGroup
# MAGIC , APP.start_date, APP.end_date, APP.display_group_id
# MAGIC -- Source
# MAGIC ,'Ktavara' SrcID
# MAGIC , current_timestamp as GoldLoadDateTime 
# MAGIC  ,BUS.size_class_code bu_size_class_code
# MAGIC
# MAGIC -- AA - accepted assortment plan product decision -product, assortment-type
# MAGIC from silver_${env}.k_tavara.silver_kvalikoima_accepted_assortment_plan_product_decision AA
# MAGIC
# MAGIC -- P - Product id => SAP id
# MAGIC inner join silver_${env}.k_tavara.silver_kvalikoima_product_mapping P on
# MAGIC AA.product_id = P.product_id
# MAGIC -- BP - Basic product - product group
# MAGIC inner join silver_${env}.kdata_gt_curated_sap.basicproducts BP on 
# MAGIC P.product_sap_id = cast(BP.SAPID as bigint)
# MAGIC
# MAGIC -- APS - assortment plan period businessunitgroup sizeclasscode  - SizeClassCode
# MAGIC  inner join silver_${env}.k_tavara.silver_kvalikoima_assortment_plan_period_business_unit_group_size_class_code APS on
# MAGIC  AA.decision_size_class_code_id = APS.assortment_plan_period_business_unit_group_size_class_code_id
# MAGIC  and AA.assortment_plan_period_business_unit_group_id = APS.assortment_plan_period_business_unit_group_id
# MAGIC
# MAGIC -- APP - assortment plan period - startdate, enddate
# MAGIC inner join silver_${env}.k_tavara.silver_kvalikoima_assortment_plan_period APP on
# MAGIC AA.assortment_plan_period_id = APP.assortment_plan_period_id
# MAGIC
# MAGIC -- AGG - assortment plan period BusinessUnit group
# MAGIC inner join silver_${env}.k_tavara.silver_kvalikoima_assortment_plan_period_business_unit_group AGG on
# MAGIC AGG.assortment_plan_period_business_unit_group_id = AA.assortment_plan_period_business_unit_group_id
# MAGIC and AGG.assortment_plan_period_id = AA.assortment_plan_period_id
# MAGIC
# MAGIC -- BUG - BusinessUnit group
# MAGIC inner join silver_${env}.k_tavara.silver_kvalikoima_business_unit_group BUG on
# MAGIC AGG.business_unit_group_id = BUG.business_unit_group_id
# MAGIC
# MAGIC -- BUS - BusinessUnit assortment sizeclasscode
# MAGIC inner join silver_${env}.k_tavara.silver_kvalikoima_assortment_size_class_code BUS on
# MAGIC BUG.business_unit_group_id = BUS.business_unit_group_id 
# MAGIC and BUS.display_group_id = APP.display_group_id
# MAGIC -- added filter for 'active' displaygroups for businessunit (by 20.8.2024/slh)
# MAGIC and  ((BUS.valid_from <= APP.start_date) and (BUS.end_date >= APP.start_date)) and BUS.removal = 'false'
# MAGIC
# MAGIC -- BU - BusinessUnit - BU erp code
# MAGIC inner join silver_${env}.k_tavara.silver_kvalikoima_business_unit BU on
# MAGIC BU.business_unit_id = BUS.business_unit_id
# MAGIC
# MAGIC
# MAGIC where
# MAGIC -- current and future assortment data
# MAGIC APP.start_date >= date_sub(current_timestamp(), 30) and 
# MAGIC AA.event_type not in ('REMOVAL')
# MAGIC
# MAGIC -- BU's SizeClassCode included in assortmentperiod's SizeClassCodes
# MAGIC -- when BU's SizeClassCode  = 'S', then product's SizeClassCode should also be 'S'
# MAGIC -- when 30, 65 and BU's SizeClassCode <> 'S', priority S,A,B,C...
# MAGIC -- when 10, 20 and BU's SizeClassCode <> 'S', priority is A,B,C,... 
# MAGIC and 
# MAGIC (
# MAGIC   ( 
# MAGIC      ( (BU.distribution_channel_code in (10, 20)) and (APS.size_class_code <= BUS.size_class_code)) or 
# MAGIC      ( (BU.distribution_channel_code in (30, 65)) and (BUS.size_class_code = '1') and (APS.size_class_code in ('1','A')) ) or
# MAGIC      ( (BU.distribution_channel_code in (30, 65)) and (BUS.size_class_code = 'S') and (APS.size_class_code ='S') ) or
# MAGIC      ( (BU.distribution_channel_code in (30, 65)) and (BUS.size_class_code = 'A') and (APS.size_class_code in ('S', 'A')) ) or
# MAGIC      ( (BU.distribution_channel_code in (30, 65)) and (BUS.size_class_code = 'B') and (APS.size_class_code in ('S', 'A', 'B')) ) or
# MAGIC      ( (BU.distribution_channel_code in (30, 65)) and (BUS.size_class_code = 'C') and (APS.size_class_code in ('S', 'A', 'B', 'C')) ) or
# MAGIC      ( (BU.distribution_channel_code in (30, 65)) and (BUS.size_class_code = 'D') and (APS.size_class_code in ('S', 'A', 'B', 'C', 'D')) ) or
# MAGIC      ( (BU.distribution_channel_code in (30, 65)) and (BUS.size_class_code = 'E') and (APS.size_class_code in ('S', 'A', 'B', 'C', 'D', 'E')) ) or
# MAGIC      ( (BU.distribution_channel_code in (30, 65)) and (BUS.size_class_code = 'F') and (APS.size_class_code in ('S', 'A', 'B', 'C', 'D', 'E', 'F')) ) or
# MAGIC      ( (BU.distribution_channel_code in (30, 65) and (BUS.size_class_code = 'G') and (APS.size_class_code in ('S', 'A', 'B', 'C', 'D', 'E', 'F', 'G')) ) or
# MAGIC  ( (BU.distribution_channel_code in (30, 65)) and (BUS.size_class_code = 'H') and (APS.size_class_code in ('S', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H')) ) or
# MAGIC  ( (BU.distribution_channel_code in (30, 65)) and (BUS.size_class_code = 'I') and (APS.size_class_code in ('S', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I')) ) 
# MAGIC   )
# MAGIC )
# MAGIC )
# MAGIC
# MAGIC -- RollOut – Merchandise_categories for Ktavara data
# MAGIC and left(BP.Productgroup, 2) in (select merchandise_category from silver_${env}.k_tavara.silver_manual_rollout_steering_table RO
# MAGIC where RO.system_name = 'Ktavara' and RO.start_date <= getdate())
# MAGIC
# MAGIC
# MAGIC union all
# MAGIC
# MAGIC -- BusinessUnit
# MAGIC SELECT DISTINCT SP.BusinessUnitID business_unit_erp_code
# MAGIC -- Product data
# MAGIC , SP.ProductID product_sap_id
# MAGIC -- Assortment data
# MAGIC , SP.AssortmentType assortment_type_description
# MAGIC , CASE
# MAGIC     WHEN SP.AssortmentType = 'Suva' THEN 8
# MAGIC     ELSE 1
# MAGIC   END assortment_type
# MAGIC -- ProductGroup data
# MAGIC , LEFT(BP.Productgroup, 2) product_group
# MAGIC -- Assortment Plan Period - StartDate and EndDate
# MAGIC , SP.AssortmentStartDate start_date, SP.AssortmentEndDate end_date
# MAGIC -- DisplayGroup data
# MAGIC , SP.DisplayGroupID display_group_id
# MAGIC -- Source
# MAGIC , 'A2G' SrcID
# MAGIC , CURRENT_TIMESTAMP AS GoldLoadDateTime
# MAGIC , SP.AssortmentClass bu_size_class_code
# MAGIC FROM silver_${env}.kdata_gt_curated_a2g.storeassortmentproduct SP
# MAGIC INNER JOIN silver_${env}.kdata_gt_curated_sap.basicproducts BP ON SP.ProductID = CAST(BP.SAPID AS BIGINT)
# MAGIC  ------   data from max.loaddate
# MAGIC INNER JOIN (
# MAGIC   SELECT BusinessUnitID, MAX(CAST(loaddatetime AS DATE)) AS max_load_date
# MAGIC   FROM silver_${env}.kdata_gt_curated_a2g.storeassortmentproduct
# MAGIC   GROUP BY BusinessUnitID
# MAGIC ) AS subq ON subq.BusinessUnitID = SP.BusinessUnitID AND CAST(SP.loaddatetime AS DATE) = subq.max_load_date
# MAGIC -- future data is selected
# MAGIC where SP.AssortmentStartDate >= date_sub(current_timestamp(), 30)
# MAGIC
# MAGIC -- RollOut – ProductGroups
# MAGIC AND 
# MAGIC LEFT(BP.Productgroup, 2) IN (  SELECT merchandise_category   FROM silver_${env}.k_tavara.silver_manual_rollout_steering_table RO
# MAGIC   WHERE RO.system_name = 'A2G' AND RO.start_date <= GETDATE())

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ### Gold Table Display group

# COMMAND ----------

# MAGIC %md
# MAGIC ### Create Display Group table

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS gold_${env}.grocery_trade.display_group (
# MAGIC display_group_id int,	
# MAGIC name string,	
# MAGIC short_name string,	
# MAGIC merchandisehierarchy2 string,	
# MAGIC SilverLoadDateTime timestamp,
# MAGIC SrcId string
# MAGIC )
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Insert into gold display group table

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT OVERWRITE gold_${env}.grocery_trade.display_group
# MAGIC select display_group_id
# MAGIC ,name
# MAGIC ,short_name
# MAGIC ,case
# MAGIC -- 2 digits in the left
# MAGIC  when len(short_name) = 2 then left(short_name, 2)
# MAGIC -- 3 digits in the left
# MAGIC  when len(short_name) = 3 then left(short_name, 2)
# MAGIC -- 2 digits in the left + other text
# MAGIC  when (left(short_name,2))> 0 then left(short_name, 2)
# MAGIC -- 'KCM KOKO - ' before merchandisehierarchy
# MAGIC  when left(short_name,8) = 'KCM KOKO' then left((right((substring(short_name,1,14)),3)),2) 
# MAGIC -- KCM data
# MAGIC  when left(short_name,3) = 'KCM' then left((right((substring(short_name,1,7)),3)),2) 
# MAGIC -- KSM data
# MAGIC  when left(short_name,3) = 'KSM' then left((right((substring(short_name,1,7)),3)),2) 
# MAGIC -- KM data
# MAGIC  when left(short_name,2) = 'KM' then left((right((substring(short_name,1,6)),3)),2) 
# MAGIC -- NK data
# MAGIC  when left(short_name,2) = 'NK' then left((right((substring(short_name,1,6)),3)),2)
# MAGIC -- merchandisehierarchy2 from name column - two digits in the left
# MAGIC  when (left(name,2))> 0 then left(name, 2)
# MAGIC else 'NA'
# MAGIC end merchandisehierarchy2
# MAGIC ,SilverLoadDateTime
# MAGIC ,'Ktavara' SrcId 
# MAGIC from silver_${env}.k_tavara.silver_kvalikoima_display_group
# MAGIC order by display_group_id
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ###Gold Table product_assortment_class

# COMMAND ----------

# MAGIC %md
# MAGIC ###Create Table Query product_assortment_class

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS gold_${env}.grocery_trade.product_assortment_class (
# MAGIC     business_unit_group int
# MAGIC     ,product_group  int
# MAGIC     ,product_sap_id bigint
# MAGIC     ,assortment_start_date  date
# MAGIC     ,assortment_end_date    date
# MAGIC     ,size_class_code    string
# MAGIC     ,assortment_type    string
# MAGIC     ,reason_code    string
# MAGIC     ,srcID  string
# MAGIC     ,GoldLoadDateTime timestamp
# MAGIC     )

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Before we load into the main table we process the data into 2 tables which makes loading process much faster

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Intermediate Table 1 silver_${env}.k_tavara.tuotekevasuva

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace table silver_${env}.k_tavara.TuoteKevaSuva
# MAGIC    (business_unit_group_name string,
# MAGIC    Keva_DC int,
# MAGIC    TuoteKeva bigint,
# MAGIC    MCAT int,
# MAGIC    Kstart date,
# MAGIC    Kend date,
# MAGIC    Sstart date,
# MAGIC    reason_Suva string,
# MAGIC    reason_Keva string,
# MAGIC    assortment_type string,
# MAGIC    load_date timestamp
# MAGIC   )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Insert

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT OVERWRITE silver_${env}.k_tavara.tuotekevasuva 
# MAGIC (business_unit_group_name, Keva_DC, TuoteKeva, MCAT, Kstart, Kend ,Sstart, reason_Suva, reason_keva, assortment_type, load_date)
# MAGIC SELECT distinct
# MAGIC ---- DC
# MAGIC  BUG.business_unit_group_name,
# MAGIC  ---- distribution channel
# MAGIC case
# MAGIC when BUG.business_unit_group_name = 'KM' then 30
# MAGIC when BUG.business_unit_group_name = 'KCM' then 10
# MAGIC when BUG.business_unit_group_name = 'KSM' then 20
# MAGIC when BUG.business_unit_group_name = 'KCM KOKO' then 65
# MAGIC else 0
# MAGIC end DC,
# MAGIC ---- keva information
# MAGIC         P.product_sap_id AS TuoteKeva, 
# MAGIC         left(BP.Productgroup, 2) AS MCAT,
# MAGIC         APP.start_date AS Kstart,
# MAGIC         KFDM_CAL.PeriodEndDate, 
# MAGIC ---- suva information
# MAGIC         tuoteSuva.Sstart, 
# MAGIC         max(tuoteSuva.reason_suva) reason_suva,
# MAGIC ---- keva reason 
# MAGIC         max(APS.size_class_code) reason_keva
# MAGIC         ,MIN(aa.assortment_type) AssortmentType
# MAGIC        , current_timestamp as load_date
# MAGIC
# MAGIC
# MAGIC ---- table, where is DC product keva and suva reason values
# MAGIC     FROM silver_${env}.k_tavara.silver_kvalikoima_product_mapping P
# MAGIC     inner join silver_${env}.kdata_gt_curated_sap.basicproducts BP 
# MAGIC         on P.product_sap_id = cast(BP.SAPID as bigint) 
# MAGIC     INNER JOIN silver_${env}.k_tavara.silver_kvalikoima_accepted_assortment_plan_product_decision AA 
# MAGIC         ON AA.product_id = P.product_id 
# MAGIC     INNER JOIN silver_${env}.k_tavara.silver_kvalikoima_assortment_plan_period APP 
# MAGIC         ON AA.assortment_plan_period_id = APP.assortment_plan_period_id  and APP.start_date >= (cast(getdate() as date) -90)
# MAGIC     INNER JOIN silver_${env}.k_tavara.silver_kvalikoima_assortment_plan_period_business_unit_group_size_class_code APS 
# MAGIC         ON AA.decision_size_class_code_id = APS.assortment_plan_period_business_unit_group_size_class_code_id
# MAGIC     inner join silver_${env}.k_tavara.silver_kvalikoima_assortment_plan_period_business_unit_group AGG on
# MAGIC     APS.assortment_plan_period_business_unit_group_id = AGG.assortment_plan_period_business_unit_group_id
# MAGIC     inner join silver_${env}.k_tavara.silver_kvalikoima_business_unit_group BUG  on
# MAGIC        BUG.business_unit_group_id = AGG.business_unit_group_id
# MAGIC     inner join silver_${env}.kdata_gt_curated_kfdm.calendarassortment KFDM_CAL on
# MAGIC        APP.start_date = KFDM_CAL.PeriodStartDate   
# MAGIC
# MAGIC ---- table, where is DC product suva reason values
# MAGIC      LEFT OUTER JOIN (SELECT 
# MAGIC         BUG.business_unit_group_id Suva_DC,
# MAGIC         P.product_sap_id AS TuoteSuva, 
# MAGIC         AA.assortment_type AS Suva, 
# MAGIC         APP.start_date AS Sstart, 
# MAGIC         MAX(APS.size_class_code) AS reason_suva
# MAGIC     FROM silver_${env}.k_tavara.silver_kvalikoima_product_mapping P
# MAGIC     INNER JOIN silver_${env}.k_tavara.silver_kvalikoima_accepted_assortment_plan_product_decision AA 
# MAGIC         ON AA.product_id = P.product_id and AA.assortment_type = 'SUVA'
# MAGIC     INNER JOIN silver_${env}.k_tavara.silver_kvalikoima_assortment_plan_period APP 
# MAGIC      ON AA.assortment_plan_period_id = APP.assortment_plan_period_id  and APP.start_date >= (cast(getdate() as date) -90)
# MAGIC     INNER JOIN silver_${env}.k_tavara.silver_kvalikoima_assortment_plan_period_business_unit_group_size_class_code APS 
# MAGIC         ON AA.decision_size_class_code_id = APS.assortment_plan_period_business_unit_group_size_class_code_id
# MAGIC     inner join silver_${env}.k_tavara.silver_kvalikoima_assortment_plan_period_business_unit_group AGG on
# MAGIC     APS.assortment_plan_period_business_unit_group_id = AGG.assortment_plan_period_business_unit_group_id
# MAGIC     inner join silver_${env}.k_tavara.silver_kvalikoima_business_unit_group BUG  on
# MAGIC        BUG.business_unit_group_id = AGG.business_unit_group_id
# MAGIC          GROUP BY 1, 2, 3, 4
# MAGIC ) AS tuoteSuva ON 
# MAGIC     APP.start_date = tuoteSuva.Sstart 
# MAGIC     AND P.product_sap_id = tuoteSuva.TuoteSuva 
# MAGIC     and BUG.business_unit_group_id = TuoteSuva.Suva_DC
# MAGIC
# MAGIC --- testing
# MAGIC     where  APP.start_date >= (cast(getdate() as date) -90)
# MAGIC     and BUG.business_unit_group_name in ('KM', 'KCM', 'KSM', 'KCM KOKO')
# MAGIC  
# MAGIC GROUP BY 
# MAGIC     BUG.business_unit_group_name,
# MAGIC     CASE
# MAGIC         WHEN BUG.business_unit_group_name = 'KM' THEN 30
# MAGIC         WHEN BUG.business_unit_group_name = 'KCM' THEN 10
# MAGIC         WHEN BUG.business_unit_group_name = 'KSM' THEN 20
# MAGIC         WHEN BUG.business_unit_group_name = 'KCM KOKO' THEN 65
# MAGIC         ELSE 0
# MAGIC     END,
# MAGIC     P.product_sap_id, 
# MAGIC     LEFT(BP.Productgroup, 2),
# MAGIC     APP.start_date,
# MAGIC     tuoteSuva.Sstart,
# MAGIC     KFDM_CAL.PeriodEndDate, 
# MAGIC     reason_suva
# MAGIC
# MAGIC   order by 2, 3, 5

# COMMAND ----------

# MAGIC %md
# MAGIC ### Intermediate Table 2: silver_${env}.k_tavara.DC_SizeClassCode 

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace table silver_${env}.k_tavara.DC_SizeClassCode
# MAGIC    (business_unit_group_name string,
# MAGIC     DC int,
# MAGIC     SizeClassCode string,
# MAGIC     StartDate date,
# MAGIC     jarnro int,
# MAGIC    load_date timestamp
# MAGIC    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Insert

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT OVERWRITE silver_${env}.k_tavara.DC_SizeClassCode 
# MAGIC (business_unit_group_name, DC, SizeClassCode, StartDate, jarnro, load_date)
# MAGIC select distinct
# MAGIC BUG.business_unit_group_name,
# MAGIC --------------------------------------
# MAGIC ---- distribution channel
# MAGIC case
# MAGIC     when BUG.business_unit_group_name = 'KM' then 30
# MAGIC     when BUG.business_unit_group_name = 'KCM' then 10
# MAGIC     when BUG.business_unit_group_name = 'KSM' then 20
# MAGIC     when BUG.business_unit_group_name = 'KCM KOKO' then 65
# MAGIC else 0
# MAGIC end DC,
# MAGIC  BUS.size_class_code SizeClassCode,
# MAGIC  APP.start_date,
# MAGIC case 
# MAGIC     when BUS.size_class_code = 'S' then 1
# MAGIC     when BUS.size_class_code = 'A' then 2
# MAGIC     when BUS.size_class_code = 'B' then 3
# MAGIC     when BUS.size_class_code = 'C' then 4
# MAGIC     when BUS.size_class_code = 'D' then 5
# MAGIC     when BUS.size_class_code = 'E' then 6
# MAGIC     when BUS.size_class_code = 'F' then 7
# MAGIC     when BUS.size_class_code = 'G' then 8
# MAGIC     when BUS.size_class_code = 'H' then 9
# MAGIC     when BUS.size_class_code = 'I' then 10
# MAGIC     when BUS.size_class_code = 'J' then 11
# MAGIC     when BUS.size_class_code = 'K' then 12
# MAGIC else 13
# MAGIC end jarnro
# MAGIC  , current_timestamp as load_date
# MAGIC
# MAGIC from silver_${env}.k_tavara.silver_kvalikoima_business_unit_group BUG
# MAGIC inner join silver_${env}.k_tavara.silver_kvalikoima_assortment_size_class_code BUS on
# MAGIC BUG.business_unit_group_id = BUS.business_unit_group_id
# MAGIC inner join silver_${env}.k_tavara.silver_kvalikoima_assortment_plan_period_business_unit_group AGG on
# MAGIC BUG.business_unit_group_id = AGG.business_unit_group_id
# MAGIC inner join silver_${env}.k_tavara.silver_kvalikoima_assortment_plan_period APP on
# MAGIC AGG.assortment_plan_period_id = APP.assortment_plan_period_id
# MAGIC
# MAGIC where BUG.business_unit_group_name in ('KM', 'KCM', 'KSM', 'KCM KOKO')
# MAGIC and APP.start_date >= (cast(getdate() as date) -90)
# MAGIC
# MAGIC order by DC, SizeClassCode, APP.start_date;

# COMMAND ----------

# MAGIC %md
# MAGIC ### Insert data into product_assortment_class

# COMMAND ----------

# MAGIC %sql 
# MAGIC INSERT OVERWRITE gold_${env}.grocery_trade.product_assortment_class
# MAGIC select distinct
# MAGIC --------------------------------------
# MAGIC  sizeclass.DC,
# MAGIC  reason.MCAT,
# MAGIC  reason.TuoteKeva product_sap_id,
# MAGIC  sizeclass.StartDate start_date, 
# MAGIC  reason.Kend end_date, 
# MAGIC  sizeclass.SizeClassCode size_class_code, 
# MAGIC  case
# MAGIC      when reason.reason_Keva = 'S' then 'KEVA'
# MAGIC      when reason.assortment_type = 'SUVA' then 'SUVA'
# MAGIC      when ((reason.reason_Suva is null) and (sizeclass.SizeClassCode >=reason.reason_keva) and (sizeclass.SizeClassCode <> 'S')) then 'KEVA'
# MAGIC      when ((reason.reason_suva = reason.reason_keva) and (sizeclass.SizeClassCode=reason.reason_keva)) then 'SUVA'
# MAGIC      when ((sizeclass.SizeClassCode < reason.reason_suva) and (sizeclass.SizeClassCode < reason.reason_keva)) then 'n/a'
# MAGIC      when ((sizeclass.SizeClassCode = reason.reason_suva) and (sizeclass.SizeClassCode < reason.reason_keva)) then 'SUVA'
# MAGIC      when ((sizeclass.SizeClassCode = 'S') and (reason.reason_Keva <> 'S')) then 'n/a'
# MAGIC      when ((sizeclass.SizeClassCode > reason.reason_suva) and (sizeclass.SizeClassCode < reason.reason_keva)) then 'SUVA'
# MAGIC      when ((sizeclass.SizeClassCode > reason.reason_suva) and (sizeclass.SizeClassCode = reason.reason_keva)) then 'KEVA'
# MAGIC      when ((sizeclass.SizeClassCode > reason.reason_suva) and (sizeclass.SizeClassCode > reason.reason_keva)) then 'KEVA'
# MAGIC      else 'aa'
# MAGIC  end assortment_type ,
# MAGIC    case
# MAGIC      when reason.reason_Keva = 'S' then reason.reason_keva
# MAGIC      when ((reason.reason_Suva is null) and (sizeclass.SizeClassCode >=reason.reason_keva) and (sizeclass.SizeClassCode <> 'S')) then reason.reason_keva
# MAGIC      when ((reason.reason_suva = reason.reason_keva) and (sizeclass.SizeClassCode=reason.reason_keva)) then reason.reason_suva
# MAGIC      when ((sizeclass.SizeClassCode < reason.reason_suva) and (sizeclass.SizeClassCode < reason.reason_keva)) then 'n/a'
# MAGIC      when ((sizeclass.SizeClassCode = reason.reason_suva) and (sizeclass.SizeClassCode < reason.reason_keva)) then reason.reason_suva
# MAGIC      when ((sizeclass.SizeClassCode = 'S') and (reason.reason_Keva <> 'S')) then 'n/a'
# MAGIC      when ((sizeclass.SizeClassCode > reason.reason_suva) and (sizeclass.SizeClassCode < reason.reason_keva)) then reason.reason_suva
# MAGIC      when ((sizeclass.SizeClassCode > reason.reason_suva) and (sizeclass.SizeClassCode = reason.reason_keva)) then reason.reason_keva
# MAGIC      when ((sizeclass.SizeClassCode > reason.reason_suva) and (sizeclass.SizeClassCode > reason.reason_keva)) then reason.reason_keva
# MAGIC      else 'ss'
# MAGIC  end ReasonCode
# MAGIC  , 'Ktavara' SrcID
# MAGIC  ,current_timestamp as GoldLoadDateTime
# MAGIC  
# MAGIC from silver_${env}.k_tavara.dc_sizeclasscode sizeclass
# MAGIC ------
# MAGIC inner join silver_${env}.k_tavara.tuotekevasuva reason on
# MAGIC sizeclass.business_unit_group_name = reason.business_unit_group_name and sizeclass.StartDate = reason.Kstart
# MAGIC
# MAGIC where reason.MCAT in (select merchandise_category from silver_${env}.k_tavara.silver_manual_rollout_steering_table
# MAGIC where system_name = 'Ktavara' and start_date <= (cast(getdate() as date) ) )
# MAGIC
# MAGIC and sizeclass.business_unit_group_name in ('KM', 'KCM', 'KSM', 'KCM KOKO')
# MAGIC and sizeclass.StartDate >= (cast(getdate() as date) -90)
# MAGIC
# MAGIC  and  case
# MAGIC     when reason.reason_Keva = 'S' then 'KEVA'
# MAGIC      when ((reason.reason_Suva is null) and (sizeclass.SizeClassCode >=reason.reason_keva) and (sizeclass.SizeClassCode <> 'S')) then 'KEVA'
# MAGIC      when ((reason.reason_suva = reason.reason_keva) and (sizeclass.SizeClassCode=reason.reason_keva)) then 'SUVA'
# MAGIC      when ((sizeclass.SizeClassCode < reason.reason_suva) and (sizeclass.SizeClassCode < reason.reason_keva)) then 'n/a'
# MAGIC      when ((sizeclass.SizeClassCode = reason.reason_suva) and (sizeclass.SizeClassCode < reason.reason_keva)) then 'SUVA'
# MAGIC      when ((sizeclass.SizeClassCode = 'S') and (reason.reason_Keva <> 'S')) then 'n/a'
# MAGIC      when ((sizeclass.SizeClassCode > reason.reason_suva) and (sizeclass.SizeClassCode < reason.reason_keva)) then 'SUVA'
# MAGIC      when ((sizeclass.SizeClassCode > reason.reason_suva) and (sizeclass.SizeClassCode = reason.reason_keva)) then 'KEVA'
# MAGIC      when ((sizeclass.SizeClassCode > reason.reason_suva) and (sizeclass.SizeClassCode > reason.reason_keva)) then 'KEVA'
# MAGIC      else 'n/a'
# MAGIC  end in ('SUVA', 'KEVA')
# MAGIC
# MAGIC -----------------------------------------------------------------------------------------
# MAGIC union all
# MAGIC -----------------------------------------------------------------------------------------
# MAGIC ---- A2G data
# MAGIC -----------------------------------------------------------------------------------------
# MAGIC select CustChainID DC
# MAGIC , left(BP.Productgroup, 2) MCAT
# MAGIC , ProductID product_sap_id
# MAGIC , AssortmentStartDate start_date
# MAGIC , AssortmentEndDate end_date
# MAGIC , SizeClass size_class_code
# MAGIC , AssortmentType assortment_type
# MAGIC , ReasonCode ReasonCode
# MAGIC , 'A2G' SrcID
# MAGIC , current_timestamp as GoldLoadDateTime
# MAGIC
# MAGIC from silver_${env}.kdata_gt_curated_a2g.productassortmentclass PTC
# MAGIC ---- Get the product mcat
# MAGIC inner join silver_${env}.kdata_gt_curated_sap.basicproducts BP on
# MAGIC cast(PTC.ProductID as bigint) = cast(BP.SAPID as bigint)
# MAGIC
# MAGIC  where left(BP.Productgroup, 2) in (select merchandise_category from silver_${env}.k_tavara.silver_manual_rollout_steering_table 
# MAGIC       where system_name = 'A2G' and start_date <= (cast(getdate() as date) ) )
# MAGIC  
# MAGIC  and  AssortmentStartDate >= (cast(getdate() as date) -90)  
# MAGIC  and CustChainID in (10, 20, 30, 50, 65)  
# MAGIC
# MAGIC order by DC, product_sap_id, ReasonCode, start_date, size_class_code

# COMMAND ----------

# MAGIC %md
# MAGIC ### End of process
