# ==============================================================================================================================================
# KTAVARA Databricks job workflow
# ==============================================================================================================================================
resource databricks_job dlt_ktavara {
  name = "dlt_ktavara"

  task {
    task_key = "${databricks_pipeline.dlt_ktavara_full.name}_cdc"
    pipeline_task {
      pipeline_id = databricks_pipeline.dlt_ktavara_full.id
    }
  }

  task {
    task_key = databricks_pipeline.dlt_ktavara_incremental.name
    pipeline_task {
      pipeline_id = databricks_pipeline.dlt_ktavara_incremental.id
    }
  }
  
  task {
    task_key = databricks_pipeline.dlt_ktavara_full.name
    pipeline_task {
      pipeline_id = databricks_pipeline.dlt_ktavara_full.id
    }
    depends_on {
      task_key = "${databricks_pipeline.dlt_ktavara_full.name}_cdc"
    }
  }
}

# ==============================================================================================================================================
# KTAVARA Rollout Steering table Databricks job workflow
# ==============================================================================================================================================
resource databricks_job dlt_ktavara_rolloutorders {
  name = "dlt_ktavara_rolloutorders"

  task {
    task_key = "${databricks_pipeline.dlt_ktavara_rolloutorders.name}_cdc"
    pipeline_task {
      pipeline_id = databricks_pipeline.dlt_ktavara_rolloutorders.id
    }
  }

  task {
    task_key = databricks_pipeline.dlt_ktavara_rolloutorders.name
    pipeline_task {
      pipeline_id = databricks_pipeline.dlt_ktavara_rolloutorders.id
    }
    depends_on {
      task_key = "${databricks_pipeline.dlt_ktavara_rolloutorders.name}_cdc"
    }
  }
}
