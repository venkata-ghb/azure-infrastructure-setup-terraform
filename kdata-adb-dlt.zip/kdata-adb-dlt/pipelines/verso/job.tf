resource databricks_job dlt_verso {
  name = "JOB_dlt_verso_${var.ENV}"

  schedule {
    pause_status           = var.ENV == "prod" ? "UNPAUSED" : "PAUSED"
    quartz_cron_expression = "19 0 0 * * ?"
    timezone_id            = "UTC"
  }

  email_notifications {
    alert_on_last_attempt     = false
    no_alert_for_skipped_runs = true
    on_failure                = var.ENV == "prod" ? ["nakul.bansal@kesko.fi",] : []
  }

  pipeline_task {
    pipeline_id = databricks_pipeline.dlt_verso.id
  }
}
