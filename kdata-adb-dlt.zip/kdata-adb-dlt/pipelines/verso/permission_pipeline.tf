resource "databricks_permissions" "pipeline-dlt_verso" {
  pipeline_id = databricks_pipeline.dlt_verso.id

  dynamic access_control {
    for_each = var.ENV == "prod" ? [1] : []
    content {
      user_name        = "nakul.bansal@kesko.fi"
      permission_level = "IS_OWNER"
    }
  }

  # DEVOPS PLATFORM
  access_control {
    group_name       = "KDATA_${upper(var.ENV)}_AZ_DEVOPS_PLATFORM"
    permission_level = "CAN_MANAGE"
  }

  # Data Factory
  access_control {
    service_principal_name = local.environmental[var.ENV].datafactory_app_id
    permission_level       = "CAN_RUN"
  }
}
