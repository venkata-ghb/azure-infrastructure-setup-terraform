#Common utility functions for KData's DLT pipelines

def ingest_raw_data(table, inputPath, **sparkOptions):
    """
    Function invokes delta live table creation for table specified in function call
    table
    """
    @dlt.table(
        name=f"bronze_{table}",
        comment="This table was created with Autoloader.",
        table_properties={"quality": "bronze", "delta.enableChangeDataFeed": "True"},
    )
    def load_dynamic_table_bronze():

        if sparkOptions["sparkOptions"]["cloudFiles.format"] == "parquet":
            """ 
            Autoloader does not support schema inference for parquet files
            in DB runtime 11.0. We can avoid this problem by reading the
            input path to a dataframe and passing the dataframe schema to
            autoloader.
            """
            schemaDF = spark.read.parquet(inputPath)
            df = (
                spark.readStream.format("cloudFiles")
                .options(**sparkOptions["sparkOptions"])
                .schema(schemaDF.schema)
                .load(inputPath)
            )
        else:
            # Autoloader can infer schema for other file types such as csv.
            df = (
                spark.readStream.format("cloudFiles")
                .options(**sparkOptions["sparkOptions"])
                .load(inputPath)
            )

        return df