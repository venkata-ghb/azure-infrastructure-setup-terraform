locals {
  verso_container = lookup({
    dev  = "dlt_debug_adls"
    test = "dlt_verso_test"
    prod = "dlt_verso"
  }, var.ENV)
  verso_schema = lookup({
    dev  = "dlt_verso_adls"
    test = "dlt_test_verso"
    prod = "dlt_verso"
  }, var.ENV)
}

resource databricks_pipeline dlt_verso {
  name = "dlt_verso_${var.ENV}"

  cluster {
    label               = "default"
    spark_env_vars      = {}
    spark_conf          = local.global_spark_conf
    node_type_id        = local.default_node
    driver_node_type_id = local.default_node
    autoscale {
      min_workers = 1
      max_workers = lookup({
        dev  = 3
        test = 5
        prod = 5
      }, var.ENV)
      mode = "ENHANCED"
    }
  }

  library {
    notebook {
      path = var.ENV == "prod" ? "${local.workspace_prefix}/pipelines/verso/dlt_verso" : "/Repos/ext.markus.varho@kesko.fi/kdata-adb-dlt/pipelines/verso/dlt_verso"
    }
  }

  storage     = var.ENV == "prod" ? "${local.storage_prefix}/verso/" : "abfss://testcontainer@unitycatalogextstor.dfs.core.windows.net/${local.verso_container}"
  continuous  = false
  channel     = var.ENV == "test" ? "PREVIEW" : "CURRENT"
  development = var.ENV != "prod" ? true : false
  photon      = false
  target      = local.verso_schema

  configuration = {
    environment     = var.ENV
    repository_path = var.ENV == "prod" ? "/Workspace${local.workspace_prefix}/" : "/Workspace/Repos/ext.markus.varho@kesko.fi/kdata-adb-dlt"
    target_schema   = local.verso_schema
  }
}
