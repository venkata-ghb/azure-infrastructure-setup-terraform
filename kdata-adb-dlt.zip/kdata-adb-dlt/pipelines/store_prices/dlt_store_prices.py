# Databricks notebook source
import sys
sys.path.append("/Workspace/Repos/DLT/kdata-adb-dlt/dlt_functions/dltlib")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Import DLT pipeline functions

# COMMAND ----------

import dlt
import json
from pyspark.sql.functions import col, expr, current_timestamp
from pyspark.sql.types import TimestampType
from pyspark.sql import SparkSession, DataFrame

# COMMAND ----------

from dltlib import *

# COMMAND ----------

options = {"cloudFiles.format": "avro"} # source file format in the data lake raw container
env = spark.conf.get("environment") # integration environment
inputPath = f"abfss://raw@kdata{env}adls.dfs.core.windows.net/natural/GTPOS/stage/"
process_cols = {}
target_schema = spark.conf.get("target_schema") # schema in the local hive metastore
source_system = "gtpos"

# The processing rules for the bronze and silver layers are written
# in a single json file in the dlt repository.
pipeline_path = spark.conf.get("repository_path")
print("repo pat:",pipeline_path)
table_config_path = f"{pipeline_path}/tables.json"
with open(file=table_config_path, mode="r") as file:
    pipeline_tables = json.load(file)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Ingest raw data to bronze layer and update the cdc log

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparing data for bronze layer

# COMMAND ----------

import pyspark.sql.functions as F
from pyspark.sql.functions import from_json,to_json, explode
from pyspark.sql.functions import when, col, count, max, current_timestamp, expr
import pyspark.sql.types as T
import pyspark
import zlib
import pytz
from datetime import datetime, timezone


BodySchema = T.StructType(
  [
    T.StructField('correlationId', T.StringType(), True),
    T.StructField('store', T.StringType(), True),
    T.StructField('eventType', T.StringType(), True),
    T.StructField('eventTime', T.StringType(), True),
    T.StructField('payload', T.ArrayType(T.StringType(),False), True)
  ]
)
PayloadSchema = T.StructType(
    [   T.StructField('ean', T.StringType(), True),
        T.StructField('name', T.StringType(), True),
        T.StructField('type', T.StringType(), True),
        T.StructField('group', T.StringType(), True),
        T.StructField('price', T.StringType(), True),
        T.StructField('vat', T.StringType(), True),
        T.StructField('salesUnit', T.StringType(), True),
        T.StructField('packageUnit', T.StringType(), True),
        T.StructField('referencePriceUnit', T.StringType(), True),
        T.StructField('packageSize', T.StringType(), True),
        T.StructField('unitPrice', T.StringType(), True),
        T.StructField('packageType', T.StringType(), True),
        T.StructField('scaleNumber', T.StringType(), True),
        T.StructField('costCenterId', T.StringType(), True),
        T.StructField('discountLimited', T.StringType(), True),
        T.StructField('plussaLimited', T.StringType(), True),
        T.StructField('texts', T.StringType(), True),
        T.StructField('isoCountryCode', T.StringType(), True),
        T.StructField('negativeItem', T.StringType(), True),
        T.StructField('marketingName', T.StringType(), True),
        T.StructField('sizeOfSalesPackage', T.StringType(), False),
        T.StructField('references', T.StringType(), True),
        T.StructField('descriptions', T.ArrayType(T.StringType(),False), True),
        T.StructField('restrictions', T.StringType(), True),
        T.StructField('promotions', T.StringType(), True),
        T.StructField('components', T.StringType(), True),
        T.StructField('priceHistory', T.StringType(), True)
    ]
)

ComponentsSchema = T.ArrayType(T.StructType(
    [   
      T.StructField('ean', T.StringType(), True),
      T.StructField('name', T.StringType(), True),
      T.StructField('type', T.StringType(), True),
      T.StructField('group', T.StringType(), True),
      T.StructField('price', T.StringType(), False),
      T.StructField('multiplier', T.StringType(), True)
    ]))

PromotionsSchema = T.StructType(
    [   T.StructField('id', T.StringType(), True)])

def transform_decompress_raw(df: DataFrame) -> DataFrame:
    """ Transform raw data to string format """
    def decompress(row: bytes):
        """ Check content of row for gzip or zlib header magic number and decompress if it matches """
        if row is not None and len(row) > 1 and (row[:2] == b'\x1f\x8b' or row[0] == b'\x78' or row[:2] == b'x\x9c'):
            decompressor = zlib.decompressobj(zlib.MAX_WBITS | 32)
            return decompressor.decompress(row).decode()

        return row.decode('utf-8') if row is not None else row
    decompress_udf = F.udf(decompress)

    return df.withColumn('Body', decompress_udf('Body')).selectExpr('SequenceNumber as SequenceNumber','Offset as Offset','EnqueuedTimeUtc as EnqueuedTimeUtc','SystemProperties as SystemProperties','Properties as Properties','Body AS Body')

def ingest_raw_data(table, inputPath, process_cols = None, **sparkOptions):
        @dlt.table(
            name=f"bronze_{table}",
            comment="This table was created with Autoloader.",
            table_properties={"quality": "bronze", "delta.enableChangeDataFeed": "True"},
        )
        def load_dynamic_table_bronze():
            # Autoloader can infer schema for file types such as parquet, json and csv test.
            avro_maindf = (
                spark.readStream.format("cloudFiles")
                .options(**sparkOptions["sparkOptions"])
                .load(inputPath)
                #.withColumn ("Body", F.decode(F.col("Body"), "iso-8859-1"))
            )
            maindf = transform_decompress_raw(avro_maindf)
            mapped_df = maindf.withColumn("Body", F.from_json("Body", BodySchema))

            df = mapped_df.select("SequenceNumber","Body.correlationId","Body.store","Body.eventTime",
            explode("Body.payload").alias("PayloadArray")).\
              select(col("SequenceNumber"),col("correlationId"),col("store"),col("eventTime"),from_json("PayloadArray", PayloadSchema).alias("PayloadIndv")).\
                select(
                  col("SequenceNumber"), col("correlationId"), col("store"), col("eventTime"), col("PayloadIndv.ean").alias("PayloadIndv_ean"), col("PayloadIndv.name").alias("PayloadIndv_name"), col("PayloadIndv.type").alias("PayloadIndv_type"), col("PayloadIndv.group").alias("PayloadIndv_group"), col("PayloadIndv.price").alias("PayloadIndv_price"), col("PayloadIndv.vat").alias("PayloadIndv_vat"), col("PayloadIndv.salesUnit").alias("PayloadIndv_salesUnit"), col("PayloadIndv.packageUnit"), col("PayloadIndv.referencePriceUnit"), col("PayloadIndv.packageSize"), col("PayloadIndv.unitPrice"), col("PayloadIndv.packageType"), col("PayloadIndv.scaleNumber"), col("PayloadIndv.costCenterId"), col("PayloadIndv.discountLimited"), col("PayloadIndv.plussaLimited"),col("PayloadIndv.texts"), col("PayloadIndv.isoCountryCode"), col("PayloadIndv.negativeItem"), col("PayloadIndv.marketingName"), col("PayloadIndv.sizeOfSalesPackage"), col("PayloadIndv.references"), col("PayloadIndv.restrictions"), when(col("PayloadIndv.promotions").isNull(), "0").when(col("PayloadIndv.promotions").isNotNull(), "1").alias("promotions"), col("PayloadIndv.promotions").alias("promotions_json"), col("PayloadIndv.priceHistory").alias('priceHistory'), col("PayloadIndv.descriptions").alias('descriptions'), when(col("PayloadIndv.components").isNull(), "0").when(col("PayloadIndv.components") == "[]", "0").when(col("PayloadIndv.components").isNotNull(), "1").alias("components"), col("PayloadIndv.components").alias("components_json"),  explode(F.array("PayloadIndv.components")).alias("component_array")).\
                    select("SequenceNumber", "correlationId", "store", "eventTime", col("PayloadIndv_ean").alias("ean"), col("PayloadIndv_name").alias("name"), 
                           col("PayloadIndv_type").alias("type"), col("PayloadIndv_group").alias("group"), col("PayloadIndv_price").alias("price"), 
                           col("PayloadIndv_vat").alias("vat"), col("PayloadIndv_salesUnit").alias("salesUnit"), "packageUnit","referencePriceUnit","packageSize","unitPrice","packageType","scaleNumber","costCenterId","discountLimited","plussaLimited","texts","isoCountryCode","negativeItem","marketingName","sizeOfSalesPackage","references","restrictions","promotions","promotions_json",
                           "components","components_json", 
                           from_json(col("component_array"), ComponentsSchema).getField("ean")[0].alias("components_ean"), 
                           from_json(col("component_array"), ComponentsSchema).getField("price")[0].alias("components_price"),
                           from_json(col("component_array"), ComponentsSchema).getField("multiplier")[0].alias("multiplier"),
                           "priceHistory", "descriptions"
                           )
            # If function call includes calculated columns, they are included into returned data frame here
            # 
            if process_cols:
              for column_name, column_statement in process_cols.items():
                df = df.withColumn(column_name, column_statement)
            df = df.withColumn("BronzeLoadDateTime", current_timestamp())
            return df


# COMMAND ----------

# MAGIC %md
# MAGIC ### Inserting data to bronze layer

# COMMAND ----------

for table in pipeline_tables.keys():
    # Create the bronze tables.
    ingest_raw_data(
      table=table,
      sparkOptions=options, 
      inputPath=f"{inputPath}/{table}"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Ingest bronze layer data to silver layer table

# COMMAND ----------

def create_silver_temp_table_storeprice(source_table,target_table,column_mapping,expectations,use_cdc = True,source_system = "source_system N/A"):
  @dlt.table(
    name=f"temp_{target_table}",
    comment="Temporary table for renaming columns before SCD is implemented.",
    temporary=True,
    table_properties={"quality": "temp"},
    )
  @dlt.expect_all(json.loads(expectations))
  def load_dynamic_table_silver():
    
    # Generate a select expression for renaming columns
    # selExpr = [
    #   f"{value} as {key}"
    #   for key, value in column_mapping.items()
    #   ]
    selExpr = ['eventTime as event_time', 'store as store_priceapi', 'cast(ean as bigint) as gtin', 'name as name_fi', 'marketingName as marketing_name', 'type as type_priceapi',
 'cast(group as int) as pos_segm', 'cast (price as DECIMAL(20,8)) as price_incl_vat', 'cast(vat as int) as vat_percentage', 'salesUnit as retail_sales_unit', 'packageUnit as retail_package_unit',
 'referencePriceUnit as reference_price_unit', 'packageSize as package_size', 'cast(unitPrice as decimal(20,8)) as unit_price_incl_vat', 'packageType as package_type', 'promotions as promotions_indicator',
 'promotions_json as promotion_json', 'components as components_indicator', 'components_ean as components_ean', 'cast(components_price as decimal(20,8)) as components_price', 'cast(multiplier as int) as components_multiplier',
 'components_json as components_json',
 "CASE WHEN (lower(discountLimited) == 'false' or discountLimited is null) THEN '0' else '1' end  as discount_limited_indicator",
 "CASE WHEN (lower(plussaLimited) == 'false' or plussaLimited is null) THEN '0' else '1' end  as plussa_limited_indicator",
 "CASE WHEN (lower(negativeItem) == 'false' or negativeItem is null) THEN '0' else '1' end  as negative_item_indicator",
 'costCenterId as store_cost_center_id', 'restrictions as restrictions', 'references as references', 'sizeOfSalesPackage as transport_package_size', 'isoCountryCode as iso_country_code',
 'texts as texts',
 'scaleNumber as scale_number', 'priceHistory as price_history', 'descriptions as json_descriptions', 'SequenceNumber as sequence_number', 'correlationId as correlation_id']
    # Add a load datetime to allow identifying rows processed
    # by a single instance of the pipeline. 
    load_dttm = [
                "current_timestamp() as SilverLoadDateTime"
                ,"BronzeLoadDateTime as BronzeLoadDateTime"
            ]

      # Add an identifier for the source system. 
      # This is intended to be used mainly in the gold layer
      # where multiple different source systems can be combined in
      # a single table.
    source = [f"'{source_system}' as SrcID"]
    if use_cdc:
      table_prefix = "cdc"
      # DLT uses three columns with fixed names on the chage data feed.
      # They are needed for applying the SCD on the silver layer.
      cdc_column_list = [
          f"_change_type as _change_type",
          f"_commit_version as _commit_version",
          f"_commit_timestamp as _commit_timestamp",
          ]
          # Append the metadata columns to a dynamic list of columns
      selExpr = selExpr + cdc_column_list + load_dttm + source
    else:
      table_prefix = "bronze"
      selExpr = selExpr + load_dttm + source
            
    df = (
      spark.readStream.format("delta")
      .option("ignoreChanges", "true")
      .table(f"LIVE.{table_prefix}_{source_table}")
      )
    df_silver = (
      spark.read.format("delta")
      .option("ignoreChanges", "true")
      #.table(f"hive_metastore.dlt_gtpos.bronze_store_prices")
      .table(f"LIVE.{table_prefix}_{source_table}")
      )
    tz = pytz.timezone('Europe/Helsinki')
    fin_date = datetime.now(tz).strftime("%Y-%m-%d")
    distinct_df = df_silver.selectExpr(['store', 'ean','cast(eventTime as timestamp) as eventTime']).filter(col('eventTime') < fin_date).groupBy("store","ean").agg(max("eventTime").alias("max_eventTime"))
    distinct_df = distinct_df.withColumnRenamed("ean","ean_bp")
    distinct_df = distinct_df.withColumnRenamed("store","store_bp")
  
  #  return df.selectExpr(selExpr)
    return df.join(distinct_df, (distinct_df.store_bp == df.store) & (distinct_df.ean_bp == df. ean) & (distinct_df.max_eventTime == df.eventTime)).selectExpr(selExpr)


# COMMAND ----------

def create_silver_table_storeprice(source_system, target_table, keys, sequence_by_col = "LoadDateTime"):
        dlt.create_streaming_live_table(f"silver_{source_system}_{target_table}")
        dlt.apply_changes(
            target=f"silver_{source_system}_{target_table}",
            source=f"temp_{target_table}",
            keys=keys,
            sequence_by=col(sequence_by_col),
            stored_as_scd_type=1,
        )

# COMMAND ----------

for source_table, target_table in pipeline_tables.items():
    if dltlib.check_if_table_exists(f"{target_schema}.bronze_{source_table}"):
        create_silver_temp_table_storeprice(
            source_table=source_table,
            target_table=f"{target_table['target']}_normal_prices",
            column_mapping=target_table["column_mapping"],
            expectations=dltlib.generate_expectations(
                keys=target_table["keys"],
                allowed_values=target_table["column_mapping"]
            ),
            use_cdc = False,
            source_system = source_system,
        )

        create_silver_table_storeprice(
            source_system=source_system,
            target_table=f"{target_table['target']}_normal_prices", 
            keys=target_table["keys"],
            sequence_by_col="event_time"
        )
