-- Databricks notebook source
CREATE OR refresh streaming Live TABLE last_day_sales_alldata
AS SELECT * FROM cloud_files("abfs://${container}@kdata${env}adls.dfs.core.windows.net/${location}.csv", "csv")

-- COMMAND ----------

CREATE OR replace Live TABLE last_day_sales
AS Select businessunitid, eancode, max(salesdate) as salesdate from LIVE.last_day_sales_alldata group by businessunitid, eancode

-- COMMAND ----------

-- This script is to create a gold table using store_price data
-- 1. Convert to add/calculate eur/g price and 'chain'
create or replace live table store_prices_pricepergram as
select 
price.gtin as ean,
price.store_priceapi as store,
verbu.ChainUnitName as ChainUnitName,
price.price_incl_vat as price,
price.retail_sales_unit as salesUnit,
price.unit_price_incl_vat as unitPrice,
price.reference_price_unit as referencePriceUnit,
--case when trim(price.reference_price_unit) in ('kg','l','m') then price.unit_price_incl_vat/1000 else price.unit_price_incl_vat end as pricePerGram
case when trim(price.reference_price_unit) in ('kg','m') then price.unit_price_incl_vat/1000 when trim(price.reference_price_unit) in ('l','kpl') then (price.price_incl_vat/cored.netWeight)/1000 else price.unit_price_incl_vat end as pricePerGram
from  silver_${env}.gtpos.silver_gtpos_store_prices_normal_prices price
left join (select distinct BusinessUnitID,ChainUnitID,ChainUnitName from silver_${env}.verso.silver_verso_businessunit) verbu on verbu.BusinessUnitID=price.store_priceapi
left join (select distinct ean as ean,measurements.netWeight as netWeight,measurements.contentUnitCode as contentUnitCode,row_number() OVER(PARTITION BY ean ORDER BY LoadDateTime desc) as rownumber from bronze_${env}.kdata_gt_raw_tps.coredata)cored on cored.ean=price.gtin and cored.rownumber=1
;

-- COMMAND ----------

-- This script is to create a gold table using store_price data
-- 2. Aggregate to chain level median price for regular products
Create or replace live table chain_level_median_price as
select
ean,
ChainUnitName as chain, 
median(pricePerGram) as avgPricePerGram
from
(
  select
    tab1.*
    ,max(rownumber) over(partition by ean,ChainUnitName) maxrownumber
    from (
      select
        price.ChainUnitName
        ,price.ean
        ,price.pricePerGram
        ,row_number() OVER(PARTITION BY price.ean,price.ChainUnitName ORDER BY price.pricePerGram) as rownumber
        ,cored.ean as sisko
      from
        LIVE.store_prices_pricepergram price
        join LIVE.last_day_sales lastday on ltrim('0', trim(price.ean)) = ltrim('0', trim(lastday.eancode)) and trim(price.store)=trim(lastday.businessunitid) and lastday.salesdate >= (curdate()-14)
        left join bronze_${env}.kdata_gt_raw_tps.coredata cored on ltrim('0', trim(cored.ean)) = ltrim('0', trim(price.ean)) and trim(cored.productSort) = 'INTERNAL_CODE_TEMPLATE'
    )tab1
)tab2
where 
case when (sisko is null or maxrownumber<3) then tab2.rownumber>0
     else case when trim(ChainUnitName) in ('K-Citymarket KT','K-Citymarket ET') then tab2.rownumber>round((maxrownumber*30)/100) and tab2.rownumber<=(maxrownumber-round((maxrownumber*30)/100))
               when trim(ChainUnitName) in ('K-Supermarket','K-Market') then tab2.rownumber>round((maxrownumber*40)/100) and tab2.rownumber<=(maxrownumber-round((maxrownumber*20)/100))
          else tab2.rownumber>0
          end
end
group by ean, ChainUnitName


-- COMMAND ----------

-- This script is to create a gold table using store_price data
-- 3. Generate prices for generic products (yleisraaka-aine)
CREATE OR REPLACE live TABLE chain_level_generic_products AS
SELECT
    pimID
    , chain
    , avgPricePerGram
FROM (
    SELECT
        referencedId AS pimID
        , CASE
            WHEN brand ILIKE 'PIRKKA' THEN 1
            ELSE 2
          END AS priority
        , price.chain as chain
        , AVG(price.avgPricePerGram) AS avgPricePerGram
    FROM LIVE.chain_level_median_price price
    LEFT JOIN (
      SELECT DISTINCT
          ean
          , pimid
          , articleCategoryCode
          , brand
          , references
          , ref.type as reference_type
          , ref.referencedId as referencedId
      FROM bronze_${env}.kdata_gt_raw_tps.coredata
      LATERAL VIEW OUTER EXPLODE(references) as ref
      QUALIFY RANK() OVER (PARTITION BY ean ORDER BY LoadDateTime DESC) = 1
    ) cored on TRIM(cored.ean) = TRIM(price.ean)
    WHERE
        cored.pimid IS NOT null AND cored.references IS NOT null
        AND TRIM(cored.reference_type) = 'Raaka-aine'
    GROUP BY 1,2,3
)
QUALIFY ROW_NUMBER() OVER (PARTITION BY pimID, chain ORDER BY priority) = 1
;
