resource databricks_pipeline dlt_store_prices {
  name = "dlt_store_prices"

  cluster {
    label               = "default"
    spark_env_vars      = {}
    spark_conf          = local.global_spark_conf
    node_type_id        = local.default_node
    driver_node_type_id = local.default_node
    autoscale {
      min_workers = 1
      max_workers = 2
      mode        = "ENHANCED"
    }
  }

  library {
    notebook {
      path = "${local.workspace_prefix}/pipelines/store_prices/dlt_store_prices"
    }
  }

  storage     = "${local.storage_prefix}/store_prices"
  continuous  = false
  channel     = "PREVIEW"
  development = var.ENV != "prod" ? true : false
  photon      = false
  target      = "dlt_gtpos"

  configuration = {
    environment     = var.ENV
    repository_path = "/Workspace${local.workspace_prefix}/pipelines/store_prices"
    target_schema   = "dlt_gtpos"
  }

  dynamic notification {
    for_each = var.ENV == "prod" ? [1] : []
    content {
      alerts = [
        "on-update-failure",
        "on-flow-failure",
        "on-update-fatal-failure",
      ]
      email_recipients = ["dlkeskokdataservice@tietoevry.com", ]
    }
  }
}

# ==============================================================================================================================================

resource databricks_pipeline dlt_gold_store_prices {
  name = "dlt_gold_store_prices"

  cluster {
    label          = "default"
    spark_env_vars = {}
    spark_conf     = local.global_spark_conf
    autoscale {
      min_workers = 1
      max_workers = 2
      mode        = "ENHANCED"
    }
  }

  library {
    notebook {
      path = "${local.workspace_prefix}/pipelines/store_prices/gold_store_prices"
    }
  }

  catalog     = "gold_${var.ENV}"
  continuous  = false
  channel     = "PREVIEW"
  development = var.ENV != "prod" ? true : false
  photon      = false
  target      = "gtpos"

  configuration = {
    environment   = var.ENV
    env           = var.ENV
    target_schema = "gtpos"
    container     = "exports"
    location      = "lastdaysales/extracts/*"
  }
}
