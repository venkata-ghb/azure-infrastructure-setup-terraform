# ==============================================================================================================================================
# Store Price Databricks job workflow
# ==============================================================================================================================================
resource databricks_job dlt_store_prices {
  name = databricks_pipeline.dlt_store_prices.name

  job_cluster {
    job_cluster_key = "store-prices-cluster"
    new_cluster {
      num_workers    = 2
      spark_version  = "15.4.x-scala2.12"
      node_type_id   = "Standard_D4s_v5"
      spark_conf     = local.global_spark_conf
      spark_env_vars = { PYSPARK_PYTHON = "/databricks/python3/bin/python3" }
    }
  }

  schedule {
    quartz_cron_expression = "51 9 2 * * ?"
    timezone_id            = "Europe/Helsinki"
    pause_status           = "UNPAUSED"
  }

  email_notifications {
    alert_on_last_attempt     = false
    no_alert_for_skipped_runs = false
    on_failure                = var.ENV == "prod" ? ["dlkeskokdataservice@tietoevry.com", ] : []
  }

  dynamic notification_settings {
    for_each = var.ENV == "prod" ? [1] : []
    content {
      no_alert_for_canceled_runs = false
      no_alert_for_skipped_runs  = false
    }
  }

  task {
    task_key = databricks_pipeline.dlt_gold_store_prices.name
    pipeline_task {
      pipeline_id = databricks_pipeline.dlt_gold_store_prices.id
    }

    depends_on {
      task_key = databricks_pipeline.dlt_store_prices.name
    }
  }

  task {
    task_key = databricks_pipeline.dlt_store_prices.name
    pipeline_task {
      pipeline_id = databricks_pipeline.dlt_store_prices.id
    }
  }

  task {
    task_key        = "warmup_cluster"
    job_cluster_key = "store-prices-cluster"
    notebook_task {
      notebook_path = "/Repos/DLT/kdata-adb-dlt/pipelines/sap/warmup_cluster"
    }
  }
}
