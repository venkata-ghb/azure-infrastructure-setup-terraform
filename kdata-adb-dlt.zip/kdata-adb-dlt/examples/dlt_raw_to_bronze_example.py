# Databricks notebook source
# MAGIC %md
# MAGIC # import

# COMMAND ----------

import dlt

# COMMAND ----------

# MAGIC %md
# MAGIC # Generic data ingestion function

# COMMAND ----------

def ingest_raw_data(table, inputPath, **sparkOptions):
    @dlt.table(
        name=f"kw_{table}",
        comment="Testing dynamic autoloader options in a dlt pipeline.",
        table_properties={"quality": "bronze"},
    )
    def load_dynamic_table_bronze():

        if sparkOptions["sparkOptions"]["cloudFiles.format"] == "parquet":
            # Autoloader does not support schema inference for parquet files in DB runtime 11.0.
            # We can avoid this problem by reading the input path to a dataframe and passing the
            # dataframe schema to autoloader.
            schemaDF = spark.read.parquet(inputPath)

            df = (
                spark.readStream.format("cloudFiles")
                .options(**sparkOptions["sparkOptions"])
                .schema(schemaDF.schema)
                .load(inputPath)
            )
        else:
            # Autoloader can infer schema for other file types such as csv.
            df = (
                spark.readStream.format("cloudFiles")
                .options(**sparkOptions["sparkOptions"])
                .load(inputPath)
            )

        return df

# COMMAND ----------

# MAGIC %md
# MAGIC # Parquet example

# COMMAND ----------

options = {"cloudFiles.format": "parquet"}
inputPath = (
    "abfss://raw@kdatadevadls.dfs.core.windows.net/natural/sap_sapuska/zzsmt_brand/"
)
table = "zzsmt_brand"

ingest_raw_data(table=table, sparkOptions=options, inputPath=inputPath)

# COMMAND ----------

# MAGIC %md
# MAGIC # CSV example

# COMMAND ----------

# Autoloader typically needs more parameters when processing csv files.
# The most commonly used parameters are header and delimiter. 
options = {"cloudFiles.format": "csv", "header": True, "delimiter": ";"}
inputPath = (
    "abfss://testcontainer@unitycatalogextstor.dfs.core.windows.net/grapes/producers/"
)
table = "producer"

ingest_raw_data(table=table, sparkOptions=options, inputPath=inputPath)
