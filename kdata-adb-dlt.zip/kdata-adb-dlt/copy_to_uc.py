# Databricks notebook source
# MAGIC %md
# MAGIC # Imports

# COMMAND ----------

import re

# COMMAND ----------

# MAGIC %md
# MAGIC # Widgets

# COMMAND ----------

dbutils.widgets.text(name="environment",defaultValue="dev")
dbutils.widgets.text(name="source_schema",defaultValue="dlt_verso_adls")
dbutils.widgets.text(name="source_system",defaultValue="verso")
environment = dbutils.widgets.get("environment")
source_schema = dbutils.widgets.get("source_schema")
source_system = dbutils.widgets.get("source_system")

# COMMAND ----------

# MAGIC %md
# MAGIC # Functions

# COMMAND ----------

def migrate_table(target_catalog, target_schema, source_schema, table):
    return spark.sql(f"""
    sync table {target_catalog}.{target_schema}.{table} 
    from {source_schema}.{table} """)

# COMMAND ----------

def migrate_view(source_schema, environment, source_system, view):
    view_definition = spark.sql(f"show create table {source_schema}.{view}").select("createtab_stmt").collect()[0][0]
    renamed_schema = f"silver_{environment}.{source_system}"
    translated_view = re.sub("`", " ",re.sub(
        source_schema, 
        renamed_schema,
        view_definition
    ))
    replace_view = re.sub("CREATE VIEW", "CREATE OR REPLACE VIEW", translated_view)
    try:
        spark.sql(replace_view)
    except Exception as e:
        print(e)


# COMMAND ----------

# MAGIC %md
# MAGIC # Execution

# COMMAND ----------

# MAGIC %md
# MAGIC ## Copy tables

# COMMAND ----------

source_tables = spark.sql(f"show tables in {source_schema}")
bronze_tables = [data[0] for data in source_tables.filter(source_tables.tableName.contains("bronze")).select("tableName").collect()]

table_results = []

for table in bronze_tables:
    table_results.append(migrate_table(
        target_catalog=f"bronze_{environment}",
        target_schema=source_system,
        source_schema=source_schema,
        table=table
    ))

silver_tables = [data[0] for data in source_tables.filter(source_tables.tableName.contains("storage_silver")).select("tableName").collect()]

for table in silver_tables:
    table_results.append(migrate_table(
        target_catalog=f"silver_{environment}",
        target_schema=source_system,
        source_schema=source_schema,
        table=table
    ))

dfs = table_results[0]
for df in table_results[1:]:
    dfs = dfs.union(df)

display(dfs)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Copy views

# COMMAND ----------

source_views = [data[0] for data in spark.sql(f"show views in {source_schema}").select("viewName").collect()]

print(source_views)
for view in source_views:
    migrate_view(
        source_schema=source_schema,
        environment=environment,
        source_system=source_system,
        view=view
    )


