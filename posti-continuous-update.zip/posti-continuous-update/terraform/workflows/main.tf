locals {
  project   = "lppcu"
  time_zone = "FLE Standard Time" # Time zone for Helsinki
}

data "azurerm_resource_group" "main" {
  name = var.RESOURCE_GROUP_NAME
}

data "azurerm_windows_function_app" "clm_updater" {
    name                = "${local.project}-func-ClmUpdater-${var.ENVIRONMENT}"
    resource_group_name = var.RESOURCE_GROUP_NAME
}

data "azurerm_windows_function_app" "event_batch_handler" {
    name                = "${local.project}-func-EventBatchHandler-${var.ENVIRONMENT}"
    resource_group_name = var.RESOURCE_GROUP_NAME
}

data "azurerm_windows_function_app" "posti_integration" {
    name                = "${local.project}-func-PostiIntegration-${var.ENVIRONMENT}"
    resource_group_name = var.RESOURCE_GROUP_NAME
}
