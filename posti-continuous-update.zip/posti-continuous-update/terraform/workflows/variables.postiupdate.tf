variable "BATCHING_SCHEDULE" {
  type = list
  description = "The hours of the day when the batch updates are done."
}

variable "UPDATE_FETCH_OFFSET" {
  type = number
  description = "How many minutes to wait before fetching an update after sending batch to Posti."
}

variable "POSTI_DAILY_UPDATE" {
  type = list # Even though it should only be a single value, we pass in as a list so that we can merge with batching schedule
  description = "When to fetch the daily updates that Posti does."
}
