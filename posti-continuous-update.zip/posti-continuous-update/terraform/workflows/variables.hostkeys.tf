variable "CLM_UPDATER_HOST_KEY" {
  type        = string
  description = "Host key for CLM Updater Function app."
  sensitive   = true
}

variable "EVENT_BATCH_HANDLER_HOST_KEY" {
  type        = string
  description = "Host key for Event Batch Function app."
  sensitive   = true
}

variable "POSTI_INTEGRATION_HOST_KEY" {
  type        = string
  description = "Host key for Posti Integration Function app."
  sensitive   = true
}
