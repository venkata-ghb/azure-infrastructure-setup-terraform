

variable "RETRY_SCHEDULE" {
  type = list
  description = "The hours of the day when CLM Updater and PostiIntegration are done."
}

variable "FILE_REFETCH_OFFSET" {
  type = number
  description = "How many minutes to wait before refetching an update after sending batch to Posti."
}

variable "CLM_CHANGES_RESEND_OFFSET" {
  type = number
  description = "How many minutes to wait resending failed clm changes after sending batch to Posti."
}
