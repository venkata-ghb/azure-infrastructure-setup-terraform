variable "DB_CLEANUP_SCHEDULE" {
  type = list
  description = "The hours of the day when database cleanups are done."
}

variable "DB_ENTRY_LIFETIME" {
  type = number
  description = "The number of days database entries should be stored."
}
