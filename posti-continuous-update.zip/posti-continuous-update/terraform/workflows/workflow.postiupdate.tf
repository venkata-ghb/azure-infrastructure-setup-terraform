#------------------------------SEND BATCHES------------------------------

resource "azurerm_logic_app_workflow" "batch_build_scheduling" {
  name                = "${local.project}-logic-batchbuilding-${var.ENVIRONMENT}"
  location            = data.azurerm_resource_group.main.location
  resource_group_name = data.azurerm_resource_group.main.name
  enabled             = var.ENVIRONMENT == "prod"

  lifecycle {
    ignore_changes = [
      tags,
    ]
  }
}

resource "azurerm_logic_app_trigger_recurrence" "batch_building_schedule" {
  name          = "Batching_Schedule"
  logic_app_id  = azurerm_logic_app_workflow.batch_build_scheduling.id
  frequency     = "Day"
  interval      = 1
  schedule {
    at_these_hours  = var.BATCHING_SCHEDULE
  }
  start_time    = "2022-09-01T10:00:00Z" # This only needs to be a time somewhere in the past so we can set time zone
  time_zone     = local.time_zone
}

resource "azurerm_logic_app_action_custom" "build_batch" {
  name         = "Trigger_Batch_Build"
  logic_app_id = azurerm_logic_app_workflow.batch_build_scheduling.id

  body = <<BODY
{
    "runAfter": {},
    "type": "Function",
    "inputs": {
        "function": {
            "id": "${data.azurerm_windows_function_app.event_batch_handler.id}/functions/BuildAndSendNewBatch"
        },
        "headers": {
            "x-functions-key": "${var.EVENT_BATCH_HANDLER_HOST_KEY}"
        },
        "method": "POST"
    }
}
BODY

}


#------------------------------FETCH CHANGES------------------------------


resource "azurerm_logic_app_workflow" "fetch_updates_scheduling" {
  name                = "${local.project}-logic-updatesfetching-${var.ENVIRONMENT}"
  location            = data.azurerm_resource_group.main.location
  resource_group_name = data.azurerm_resource_group.main.name
  enabled             = var.ENVIRONMENT == "prod"

  lifecycle {
    ignore_changes = [
      tags,
    ]
  }
}

resource "azurerm_logic_app_trigger_recurrence" "update_fetching_schedule" {
  name          = "Update_Fetching_Schedule"
  logic_app_id  = azurerm_logic_app_workflow.fetch_updates_scheduling.id
  frequency     = "Day"
  interval      = 1
  schedule {
    at_these_hours    = concat(var.POSTI_DAILY_UPDATE, var.BATCHING_SCHEDULE)
    at_these_minutes  = [ var.UPDATE_FETCH_OFFSET ]
  }
  start_time    = "2022-09-01T10:00:00Z" # This only needs to be a time somewhere in the past so we can set time zone
  time_zone     = local.time_zone
}

resource "azurerm_logic_app_action_custom" "fetch_updates" {
  name         = "Trigger_Posti_Update"
  logic_app_id = azurerm_logic_app_workflow.fetch_updates_scheduling.id

  body = <<BODY
{
    "runAfter": {},
    "type": "Function",
    "inputs": {
        "function": {
            "id": "${data.azurerm_windows_function_app.posti_integration.id}/functions/FetchRegistryChanges"
        },
        "headers": {
            "x-functions-key": "${var.POSTI_INTEGRATION_HOST_KEY}"
        },
        "method": "GET"
    }
}
BODY

}
