resource "azurerm_logic_app_workflow" "clean_db_scheduling" {
  name                = "${local.project}-logic-databasecleaning-${var.ENVIRONMENT}"
  location            = data.azurerm_resource_group.main.location
  resource_group_name = data.azurerm_resource_group.main.name
  enabled             = var.ENVIRONMENT == "prod"

  lifecycle {
    ignore_changes = [
      tags,
    ]
  }
}

resource "azurerm_logic_app_trigger_recurrence" "db_cleanup_schedule" {
  name          = "DB_Cleaning_Schedule"
  logic_app_id  = azurerm_logic_app_workflow.clean_db_scheduling.id
  frequency     = "Day"
  interval      = 1
  schedule {
    at_these_hours  = var.DB_CLEANUP_SCHEDULE
  }
  start_time    = "2022-09-01T10:00:00Z" # This only needs to be a time somewhere in the past so we can set time zone
  time_zone     = local.time_zone
}

resource "azurerm_logic_app_action_custom" "calculate_cutoff_date" {
  name         = "Calculate_Cutoff_Date"
  logic_app_id = azurerm_logic_app_workflow.clean_db_scheduling.id

  body = <<BODY
{
    "runAfter": {},
    "type": "InitializeVariable",
    "inputs": {
        "variables": [
            {
                "name": "Cutoff Date",
                "type": "string",
                "value": "@{addDays(utcNow(), -${var.DB_ENTRY_LIFETIME})}"
            }
        ]
    }
}
BODY

}

resource "azurerm_logic_app_action_custom" "delete_clm_update_errors" {
  name         = "Delete_Clm_Update_Errors"
  logic_app_id = azurerm_logic_app_workflow.clean_db_scheduling.id

  depends_on = [
    azurerm_logic_app_action_custom.calculate_cutoff_date
  ]

  body = <<BODY
{
    "runAfter": {
        "Calculate_Cutoff_Date": [
            "Succeeded"
        ]
    },
    "type": "Function",
    "inputs": {
        "function": {
            "id": "${data.azurerm_windows_function_app.clm_updater.id}/functions/DeleteClmUpdateErrors"
        },
        "headers": {
            "x-functions-key": "${var.CLM_UPDATER_HOST_KEY}"
        },
        "method": "DELETE",
        "queries": {
            "ErrorDateTime": "@{variables('Cutoff Date')}"
        }
    }
}
BODY

}

resource "azurerm_logic_app_action_custom" "delete_old_batches" {
  name         = "Delete_Old_Batches"
  logic_app_id = azurerm_logic_app_workflow.clean_db_scheduling.id

  depends_on = [
    azurerm_logic_app_action_custom.calculate_cutoff_date
  ]

  body = <<BODY
{
    "runAfter": {
        "Calculate_Cutoff_Date": [
            "Succeeded"
        ]
    },
    "type": "Function",
    "inputs": {
        "function": {
            "id": "${data.azurerm_windows_function_app.event_batch_handler.id}/functions/DeleteOldBatches"
        },
        "headers": {
            "x-functions-key": "${var.EVENT_BATCH_HANDLER_HOST_KEY}"
        },
        "method": "DELETE",
        "queries": {
            "ErrorDateTime": "@{variables('Cutoff Date')}"
        }
    }
}
BODY

}
