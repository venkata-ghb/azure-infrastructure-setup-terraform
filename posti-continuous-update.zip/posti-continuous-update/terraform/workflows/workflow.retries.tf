//Refetch failed Posti files

resource "azurerm_logic_app_workflow" "file_refetch_scheduling" {
  name                = "${local.project}-logic-filerefetching-${var.ENVIRONMENT}"
  location            = data.azurerm_resource_group.main.location
  resource_group_name = data.azurerm_resource_group.main.name
  enabled             = var.ENVIRONMENT == "prod"

  lifecycle {
    ignore_changes = [
      tags,
    ]
  }
}

resource "azurerm_logic_app_trigger_recurrence" "file_refetch_schedule" {
  name          = "Refetch_Failed_Files"
  logic_app_id  = azurerm_logic_app_workflow.file_refetch_scheduling.id
  frequency     = "Day"
  interval      = 1
  schedule {
    at_these_hours    = var.RETRY_SCHEDULE
    at_these_minutes  = [ var.FILE_REFETCH_OFFSET ]
  }
  start_time    = "2022-09-01T10:00:00Z" # This only needs to be a time somewhere in the past so we can set time zone
  time_zone     = local.time_zone
}

resource "azurerm_logic_app_action_custom" "refetch_updates" {
  name         = "Trigger_Posti_Update"
  logic_app_id = azurerm_logic_app_workflow.file_refetch_scheduling.id

  body = <<BODY
{
    "runAfter": {},
    "type": "Function",
    "inputs": {
        "function": {
            "id": "${data.azurerm_windows_function_app.posti_integration.id}/functions/RefetchFailedRegistryChanges"
        },
        "headers": {
            "x-functions-key": "${var.POSTI_INTEGRATION_HOST_KEY}"
        },
        "method": "GET"
    }
}
BODY

}

//Resend failed CLM records

resource "azurerm_logic_app_workflow" "clm_changes_resend_scheduling" {
  name                = "${local.project}-logic-clmchangesresend-${var.ENVIRONMENT}"
  location            = data.azurerm_resource_group.main.location
  resource_group_name = data.azurerm_resource_group.main.name
  enabled             = var.ENVIRONMENT == "prod"

  lifecycle {
    ignore_changes = [
      tags,
    ]
  }
}

resource "azurerm_logic_app_trigger_recurrence" "clm_changes_resend_schedule" {
  name          = "Resend_Failed_CLM_Changes"
  logic_app_id  = azurerm_logic_app_workflow.clm_changes_resend_scheduling.id
  frequency     = "Day"
  interval      = 1
  schedule {
    at_these_hours    = var.RETRY_SCHEDULE
    at_these_minutes  = [ var.CLM_CHANGES_RESEND_OFFSET ]
  }
  start_time    = "2022-09-01T10:00:00Z" # This only needs to be a time somewhere in the past so we can set time zone
  time_zone     = local.time_zone
}

resource "azurerm_logic_app_action_custom" "resend_clm_changes" {
  name         = "Trigger_Resend_CLM_Changes"
  logic_app_id = azurerm_logic_app_workflow.clm_changes_resend_scheduling.id

  body = <<BODY
{
    "runAfter": {},
    "type": "Function",
    "inputs": {
        "function": {
            "id": "${data.azurerm_windows_function_app.clm_updater.id}/functions/ResendFailedChanges"
        },
        "headers": {
            "x-functions-key": "${var.CLM_UPDATER_HOST_KEY}"
        },
        "method": "POST"
    }
}
BODY

}

