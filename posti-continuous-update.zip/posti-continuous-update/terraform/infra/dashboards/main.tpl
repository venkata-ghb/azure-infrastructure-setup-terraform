${jsonencode({
    "lenses": {
      "0": {
        "order": 0,
        "parts": {
          "0": {
            "position": {
              "x": 0,
              "y": 0,
              "colSpan": 10,
              "rowSpan": 4
            },
            "metadata": {
              "inputs": [
                {
                  "name": "ComponentId",
                  "value": "${appi-id}",
                  "isOptional": true
                },
                {
                  "name": "TimeContext",
                  "value": null,
                  "isOptional": true
                },
                {
                  "name": "ResourceIds",
                  "value": [
                    "${appi-id}"
                  ],
                  "isOptional": true
                },
                {
                  "name": "ConfigurationId",
                  "value": "${workbook-id}",
                  "isOptional": true
                },
                {
                  "name": "Type",
                  "value": "workbook",
                  "isOptional": true
                },
                {
                  "name": "GalleryResourceType",
                  "value": "microsoft.insights/components",
                  "isOptional": true
                },
                {
                  "name": "PinName",
                  "value": "Posti prod overview",
                  "isOptional": true
                },
                {
                  "name": "StepSettings",
                  "value": "{\"version\":\"KqlItem/1.0\",\"query\":\"let http_function_requests = requests\\n| where timestamp > now(-7d) and name != \\\"ReceiveUpdateEvent\\\" and name != \\\"ReceiveLifecycleEvent\\\";\\nlet data = http_function_requests\\n| summarize Mean = avg(duration), (Median, p95) = percentiles(duration, 50, 95), Count = count(), Successes = sum(resultCode == 200) by name, cloud_RoleName\\n| project App = cloud_RoleName, Function = name, Successes = Successes, Mean, Median, p95, Count, rank = 2\\n| union (http_function_requests\\n    | summarize Mean = avg(duration), (Median, p95) = percentiles(duration, 50, 95), Count = count(), Successes = sum(resultCode == 200)\\n    | project App = '🔸 All Apps', Function = '🔸 All Functions', Successes = Successes, Mean, Median, p95, Count, rank = 1);\\ndata\\n| extend Relevance = Mean * Count, Success_Rate = (toreal(Successes) / toreal(Count)) * 100\\n| sort by rank asc, Relevance desc\\n| project-away Relevance, rank, Successes\\n| extend Success_Rate = round(Success_Rate, 2), Mean = round(Mean, 2), Median = round(Median, 2), p95 = round(p95, 2)\\n| project App, Function, Count, Success_Rate, Mean, Median, p95\\n| render table\",\"size\":0,\"title\":\"Functions Performance\",\"queryType\":0,\"resourceType\":\"microsoft.insights/components\",\"gridSettings\":{\"formatters\":[{\"columnMatch\":\"Count\",\"formatOptions\":{\"min\":0,\"palette\":\"blue\"},\"formatter\":8},{\"columnMatch\":\"Success_Rate\",\"formatOptions\":{\"compositeBarSettings\":{\"columnSettings\":[],\"labelText\":\"\"},\"max\":100,\"min\":0,\"palette\":\"redGreen\"},\"formatter\":8},{\"columnMatch\":\"Mean|Median|p95\",\"formatOptions\":{\"max\":20000,\"min\":0,\"palette\":\"greenRed\"},\"formatter\":8}],\"labelSettings\":[{\"columnId\":\"Count\",\"label\":\"Requests\"},{\"columnId\":\"Success_Rate\",\"comment\":\"\",\"label\":\"Success(%)\"},{\"columnId\":\"Mean\",\"label\":\"Avg Duration(ms)\"},{\"columnId\":\"Median\",\"label\":\"Median Duration(ms)\"},{\"columnId\":\"p95\",\"label\":\"95% Duration(ms)\"}]}}",
                  "isOptional": true
                },
                {
                  "name": "ParameterValues",
                  "value": {},
                  "isOptional": true
                },
                {
                  "name": "Location",
                  "value": "westeurope",
                  "isOptional": true
                }
              ],
              "type": "Extension/AppInsightsExtension/PartType/PinnedNotebookQueryPart"
            }
          },
          "1": {
            "position": {
              "x": 10,
              "y": 0,
              "colSpan": 2,
              "rowSpan": 2
            },
            "metadata": {
              "inputs": [],
              "type": "Extension/HubsExtension/PartType/ClockPart",
              "settings": {
                "content": {
                  "settings": {
                    "timeFormat": "HH:mm",
                    "timezoneId": "FLE Standard Time",
                    "version": 1
                  }
                }
              }
            }
          },
          "2": {
            "position": {
              "x": 0,
              "y": 4,
              "colSpan": 10,
              "rowSpan": 4
            },
            "metadata": {
              "inputs": [
                {
                  "name": "ComponentId",
                  "value": "${appi-id}",
                  "isOptional": true
                },
                {
                  "name": "TimeContext",
                  "value": null,
                  "isOptional": true
                },
                {
                  "name": "ResourceIds",
                  "value": [
                    "${appi-id}"
                  ],
                  "isOptional": true
                },
                {
                  "name": "ConfigurationId",
                  "value": "${workbook-id}",
                  "isOptional": true
                },
                {
                  "name": "Type",
                  "value": "workbook",
                  "isOptional": true
                },
                {
                  "name": "GalleryResourceType",
                  "value": "microsoft.insights/components",
                  "isOptional": true
                },
                {
                  "name": "PinName",
                  "value": "Posti prod overview",
                  "isOptional": true
                },
                {
                  "name": "StepSettings",
                  "value": "{\"version\":\"KqlItem/1.0\",\"query\":\"let callsOfInterest = dependencies\\r\\n| where timestamp > now(-7d) and type == \\\"Azure DocumentDB\\\" and name in (\\r\\n\\\"StoreInvalidData\\\", \\\"GetAllBatches\\\", \\\"DeleteBatch\\\", \\\"GetOperationsByBatchId\\\", \\\"GetAllOperations\\\", \\\"StoreOperation\\\",\\r\\n\\\"GetAllInvalidData\\\", \\\"DeleteInvalidData\\\", \\\"DeleteOperation\\\", \\\"StoreBatch\\\", \\\"GetAllClmUpdateErrors\\\", \\\"DeletePostiError\\\",\\r\\n\\\"StoreClmError\\\", \\\"StorePostiError\\\", \\\"GetAllPostiErrors\\\", \\\"DeletePostiError\\\", \\\"StoreFileFetchingError\\\", \\\"GetAllFileFetching\\\",\\r\\n\\\"DeleteFileFetchingError\\\");\\r\\nlet data = callsOfInterest\\r\\n| summarize AvgDur = avg(duration), (MedianDur, p95Dur) = percentiles(duration, 50, 95),\\r\\nAvgCharge = avg(toreal(customDimensions[\\\"requestCharge\\\"])), p95Charge = percentile(toreal(customDimensions[\\\"requestCharge\\\"]), 95),\\r\\nCount = count(), Successes = sum(success == True) by operation_Name, name\\r\\n| project Function = operation_Name, OperationName = name, Count, Successes, AvgDur, MedianDur, p95Dur, AvgCharge, p95Charge, rank = 2\\r\\n| union (callsOfInterest\\r\\n    | summarize AvgDur = avg(duration), (MedianDur, p95Dur) = percentiles(duration, 50, 95),\\r\\n    AvgCharge = avg(toreal(customDimensions[\\\"requestCharge\\\"])), p95Charge = percentile(toreal(customDimensions[\\\"requestCharge\\\"]), 95),\\r\\n    Count = count(), Successes = sum(success == True)\\r\\n    | project Function = '🔸 All Functions', OperationName = '🔸 All Operations', Count, Successes, AvgDur, MedianDur, p95Dur, AvgCharge, p95Charge, rank = 1);\\r\\ndata\\r\\n| extend Success_Rate = (toreal(Successes) / toreal(Count)) * 100\\r\\n| sort by rank asc, Function desc, OperationName desc\\r\\n| project-away rank, Successes\\r\\n| extend Success_Rate = round(Success_Rate, 2), AvgDur = round(AvgDur, 2), MedianDur = round(MedianDur, 2), p95Dur = round(p95Dur, 2), AvgCharge = round(AvgCharge, 2), p95Charge = round(p95Charge, 2)\\r\\n| project Function, OperationName, Count, Success_Rate, AvgDur, MedianDur, p95Dur, AvgCharge, p95Charge\\r\\n| render table\",\"size\":0,\"title\":\"Cosmos Performance\",\"queryType\":0,\"resourceType\":\"microsoft.insights/components\",\"gridSettings\":{\"formatters\":[{\"columnMatch\":\"Count\",\"formatOptions\":{\"palette\":\"blue\"},\"formatter\":8},{\"columnMatch\":\"Success_Rate\",\"formatOptions\":{\"max\":100,\"min\":90,\"palette\":\"redGreen\"},\"formatter\":8},{\"columnMatch\":\"AvgDur|MedianDur|p95Dur\",\"formatOptions\":{\"max\":10000,\"min\":0,\"palette\":\"greenRed\"},\"formatter\":8},{\"columnMatch\":\"AvgCharge|p95Charge\",\"formatOptions\":{\"max\":20,\"min\":0,\"palette\":\"greenRed\"},\"formatter\":8}],\"labelSettings\":[{\"columnId\":\"Function\",\"label\":\"Call Source\"},{\"columnId\":\"OperationName\",\"label\":\"Call Name\"},{\"columnId\":\"Success_Rate\",\"label\":\"Success(%)\"},{\"columnId\":\"AvgDur\",\"label\":\"Avg Duration(ms)\"},{\"columnId\":\"MedianDur\",\"label\":\"Median Duration(ms)\"},{\"columnId\":\"p95Dur\",\"label\":\"95% Duration(ms)\"},{\"columnId\":\"AvgCharge\",\"label\":\"Avg Charge\"},{\"columnId\":\"p95Charge\",\"label\":\"95% Charge\"}]}}",
                  "isOptional": true
                },
                {
                  "name": "ParameterValues",
                  "value": {},
                  "isOptional": true
                },
                {
                  "name": "Location",
                  "value": "westeurope",
                  "isOptional": true
                }
              ],
              "type": "Extension/AppInsightsExtension/PartType/PinnedNotebookQueryPart"
            }
          },
          "3": {
            "position": {
              "x": 10,
              "y": 4,
              "colSpan": 9,
              "rowSpan": 4
            },
            "metadata": {
              "inputs": [
                {
                  "name": "ComponentId",
                  "value": "${appi-id}",
                  "isOptional": true
                },
                {
                  "name": "TimeContext",
                  "value": null,
                  "isOptional": true
                },
                {
                  "name": "ResourceIds",
                  "value": [
                    "${appi-id}"
                  ],
                  "isOptional": true
                },
                {
                  "name": "ConfigurationId",
                  "value": "${workbook-id}",
                  "isOptional": true
                },
                {
                  "name": "Type",
                  "value": "workbook",
                  "isOptional": true
                },
                {
                  "name": "GalleryResourceType",
                  "value": "microsoft.insights/components",
                  "isOptional": true
                },
                {
                  "name": "PinName",
                  "value": "Posti prod overview",
                  "isOptional": true
                },
                {
                  "name": "StepSettings",
                  "value": "{\"version\":\"KqlItem/1.0\",\"query\":\"let lifecycleEvents = traces\\r\\n| where operation_Name == \\\"ReceiveLifecycleEvent\\\"\\r\\n| order by timestamp asc;\\r\\nlet receivedEvents = lifecycleEvents\\r\\n| where message has \\\"Received event from customer life cycle hub\\\"\\r\\n| project timestamp, Status = \\\"Received\\\";\\r\\nlet successfulEvents = lifecycleEvents\\r\\n| where message has \\\"Begin storing of operation document\\\" or message has \\\"Storing of new operations is disabled\\\"\\r\\n| project timestamp, Status = \\\"Success\\\";\\r\\nlet invalidEvents = lifecycleEvents\\r\\n| where message has \\\"Begin storing of invalid data document\\\" or message has \\\"Storage of invalid data is disabled\\\"\\r\\n| project timestamp, Status = \\\"Invalid\\\";\\r\\nlet unsupportedEvents = lifecycleEvents\\r\\n| where message has \\\"Received unsupported event\\\"\\r\\n| project timestamp, Status = \\\"Unsupported\\\";\\r\\nlet unexpectedErrors = lifecycleEvents\\r\\n| where message has \\\"Unexpected error while receiving event\\\"\\r\\n| project timestamp, Status = \\\"Error\\\";\\r\\nlet min_t = now(-7d);\\r\\nlet max_t = now();\\r\\nlet dt = 15m;\\r\\nreceivedEvents | union successfulEvents, invalidEvents, unsupportedEvents, unexpectedErrors\\r\\n| make-series count() default = 0 on timestamp from min_t to max_t step dt by Status\\r\\n| render timechart\",\"size\":0,\"title\":\"Lifecycle events processing results\",\"queryType\":0,\"resourceType\":\"microsoft.insights/components\",\"chartSettings\":{\"seriesLabelSettings\":[{\"color\":\"red\",\"seriesName\":\"Error\"},{\"color\":\"green\",\"seriesName\":\"Success\"},{\"color\":\"orange\",\"seriesName\":\"Invalid\"},{\"color\":\"blue\",\"seriesName\":\"Received\"},{\"color\":\"gray\",\"seriesName\":\"Unsupported\"}],\"xAxis\":\"timestamp\"}}",
                  "isOptional": true
                },
                {
                  "name": "ParameterValues",
                  "value": {},
                  "isOptional": true
                },
                {
                  "name": "Location",
                  "value": "westeurope",
                  "isOptional": true
                }
              ],
              "type": "Extension/AppInsightsExtension/PartType/PinnedNotebookQueryPart"
            }
          },
          "4": {
            "position": {
              "x": 0,
              "y": 8,
              "colSpan": 10,
              "rowSpan": 5
            },
            "metadata": {
              "inputs": [
                {
                  "name": "ComponentId",
                  "value": "${appi-id}",
                  "isOptional": true
                },
                {
                  "name": "TimeContext",
                  "value": null,
                  "isOptional": true
                },
                {
                  "name": "ResourceIds",
                  "value": [
                    "${appi-id}"
                  ],
                  "isOptional": true
                },
                {
                  "name": "ConfigurationId",
                  "value": "${workbook-id}",
                  "isOptional": true
                },
                {
                  "name": "Type",
                  "value": "workbook",
                  "isOptional": true
                },
                {
                  "name": "GalleryResourceType",
                  "value": "microsoft.insights/components",
                  "isOptional": true
                },
                {
                  "name": "PinName",
                  "value": "Posti prod overview",
                  "isOptional": true
                },
                {
                  "name": "StepSettings",
                  "value": "{\"version\":\"KqlItem/1.0\",\"query\":\"\\r\\nlet customerRequests = traces\\r\\n| where timestamp > now(-7d)\\r\\n| where operation_Name != \\\"\\\" or severityLevel > 1\\r\\n| where customDimensions.prop__Uri matches regex \\\"https://api-dev|api.kesko.fi/clm-proxy/b2b/profile/v1/customers/\\\\\\\\d+$\\\" and message  startswith \\\"End processing HTTP request after\\\";\\r\\n\\r\\nlet data = customerRequests\\r\\n| summarize Mean = avg(todouble(customDimensions.[\\\"prop__ElapsedMilliseconds\\\"])), (Median, p95) = percentiles(todouble(customDimensions.prop__ElapsedMilliseconds), 50, 95), Count = count(), Successes = sum(toint(customDimensions.prop__StatusCode) == 200 or toint(customDimensions.prop__StatusCode) == 201 or toint(customDimensions.prop__StatusCode) == 204) by Msg = tostring(customDimensions.[\\\"prop__OriginalFormat\\\"]), Method = tostring(customDimensions.[\\\"prop__HttpMethod\\\"])\\r\\n| project HttpMethod = Method, Successes = Successes, Mean, Median, p95, Count, rank = 2\\r\\n| union (customerRequests\\r\\n    | summarize Mean = avg(todouble(customDimensions.[\\\"prop__ElapsedMilliseconds\\\"])), (Median, p95) = percentiles(todouble(customDimensions.[\\\"prop__ElapsedMilliseconds\\\"]), 50, 95), Count = count(), Successes = sum(toint(customDimensions.prop__StatusCode) == 200 or toint(customDimensions.prop__StatusCode) == 201 or toint(customDimensions.prop__StatusCode) == 204)\\r\\n    | project HttpMethod = '🔸 All Http methods', Successes = Successes, Mean, Median, p95, Count, rank = 1);\\r\\n\\r\\ndata\\r\\n| extend Relevance = Mean * Count, Success_Rate = (toreal(Successes) / toreal(Count)) * 100\\r\\n| sort by rank asc, Relevance desc\\r\\n| project-away Relevance, rank, Successes\\r\\n| extend Success_Rate = round(Success_Rate, 2), Mean = round(Mean, 2), Median = round(Median, 2), p95 = round(p95, 2)\\r\\n| project HttpMethod, Count, Success_Rate, Mean, Median, p95\\r\\n| render table\\r\\n\",\"size\":0,\"title\":\"CLM Updater - Customer Requests performance\",\"timeContext\":{\"durationMs\":259200000,\"endTime\":\"2022-09-28T10:19:00.000Z\"},\"queryType\":0,\"resourceType\":\"microsoft.insights/components\",\"gridSettings\":{\"formatters\":[{\"columnMatch\":\"Count\",\"formatOptions\":{\"palette\":\"blue\"},\"formatter\":8},{\"columnMatch\":\"Success_Rate\",\"formatOptions\":{\"max\":100,\"min\":0,\"palette\":\"redGreen\"},\"formatter\":8},{\"columnMatch\":\"Mean|Median|p95\",\"formatOptions\":{\"max\":20000,\"min\":0,\"palette\":\"greenRed\"},\"formatter\":8}],\"sortBy\":[{\"itemKey\":\"HttpMethod\",\"sortOrder\":1}]},\"sortBy\":[{\"itemKey\":\"HttpMethod\",\"sortOrder\":1}]}",
                  "isOptional": true
                },
                {
                  "name": "ParameterValues",
                  "value": {},
                  "isOptional": true
                },
                {
                  "name": "Location",
                  "value": "westeurope",
                  "isOptional": true
                }
              ],
              "type": "Extension/AppInsightsExtension/PartType/PinnedNotebookQueryPart"
            }
          },
          "5": {
            "position": {
              "x": 10,
              "y": 8,
              "colSpan": 9,
              "rowSpan": 5
            },
            "metadata": {
              "inputs": [
                {
                  "name": "ComponentId",
                  "value": "${appi-id}",
                  "isOptional": true
                },
                {
                  "name": "TimeContext",
                  "value": null,
                  "isOptional": true
                },
                {
                  "name": "ResourceIds",
                  "value": [
                    "${appi-id}"
                  ],
                  "isOptional": true
                },
                {
                  "name": "ConfigurationId",
                  "value": "${workbook-id}",
                  "isOptional": true
                },
                {
                  "name": "Type",
                  "value": "workbook",
                  "isOptional": true
                },
                {
                  "name": "GalleryResourceType",
                  "value": "microsoft.insights/components",
                  "isOptional": true
                },
                {
                  "name": "PinName",
                  "value": "Posti prod overview",
                  "isOptional": true
                },
                {
                  "name": "StepSettings",
                  "value": "{\"version\":\"KqlItem/1.0\",\"query\":\"let customerRequests = traces\\r\\n| where timestamp > now(-7d)\\r\\n| where operation_Name != \\\"\\\" or severityLevel > 1\\r\\n| where customDimensions.prop__Uri matches regex  \\\"^https://api-dev|api.kesko.fi/clm-proxy/b2b/profile/v1/customers/\\\\\\\\d+/assignments$\\\" and message  startswith \\\"End processing HTTP request after\\\";\\r\\n\\r\\nlet data = customerRequests\\r\\n| summarize Mean = avg(todouble(customDimensions.[\\\"prop__ElapsedMilliseconds\\\"])), (Median, p95) = percentiles(todouble(customDimensions.prop__ElapsedMilliseconds), 50, 95), Count = count(), Successes = sum(toint(customDimensions.prop__StatusCode) == 200 or toint(customDimensions.prop__StatusCode) == 201 or toint(customDimensions.prop__StatusCode) == 204) by Msg = tostring(customDimensions.[\\\"prop__OriginalFormat\\\"]), Method = tostring(customDimensions.[\\\"prop__HttpMethod\\\"])\\r\\n| project HttpMethod = Method, Successes = Successes, Mean, Median, p95, Count, rank = 2\\r\\n| union (customerRequests\\r\\n    | summarize Mean = avg(todouble(customDimensions.[\\\"prop__ElapsedMilliseconds\\\"])), (Median, p95) = percentiles(todouble(customDimensions.[\\\"prop__ElapsedMilliseconds\\\"]), 50, 95), Count = count(), Successes = sum(toint(customDimensions.prop__StatusCode) == 200 or toint(customDimensions.prop__StatusCode) == 201 or toint(customDimensions.prop__StatusCode) == 204)\\r\\n    | project HttpMethod = '🔸 All Http methods', Successes = Successes, Mean, Median, p95, Count, rank = 1);\\r\\n\\r\\ndata\\r\\n| extend Relevance = Mean * Count, Success_Rate = (toreal(Successes) / toreal(Count)) * 100\\r\\n| sort by rank asc, Relevance desc\\r\\n| project-away Relevance, rank, Successes\\r\\n| extend Success_Rate = round(Success_Rate, 2), Mean = round(Mean, 2), Median = round(Median, 2), p95 = round(p95, 2)\\r\\n| project HttpMethod, Count, Success_Rate, Mean, Median, p95\\r\\n| render table\",\"size\":0,\"title\":\"CLM Updater - Assignment Requests performance\",\"timeContext\":{\"durationMs\":259200000,\"endTime\":\"2022-09-28T10:19:00.000Z\"},\"queryType\":0,\"resourceType\":\"microsoft.insights/components\",\"gridSettings\":{\"formatters\":[{\"columnMatch\":\"Count\",\"formatOptions\":{\"palette\":\"blue\"},\"formatter\":8},{\"columnMatch\":\"Success_Rate\",\"formatOptions\":{\"max\":100,\"min\":0,\"palette\":\"redGreen\"},\"formatter\":8},{\"columnMatch\":\"Mean|Median|p95\",\"formatOptions\":{\"max\":20000,\"min\":0,\"palette\":\"greenRed\"},\"formatter\":8}],\"sortBy\":[{\"itemKey\":\"HttpMethod\",\"sortOrder\":1}]},\"sortBy\":[{\"itemKey\":\"HttpMethod\",\"sortOrder\":1}]}",
                  "isOptional": true
                },
                {
                  "name": "ParameterValues",
                  "value": {},
                  "isOptional": true
                },
                {
                  "name": "Location",
                  "value": "westeurope",
                  "isOptional": true
                }
              ],
              "type": "Extension/AppInsightsExtension/PartType/PinnedNotebookQueryPart"
            }
          },
          "6": {
            "position": {
              "x": 0,
              "y": 13,
              "colSpan": 10,
              "rowSpan": 4
            },
            "metadata": {
              "inputs": [
                {
                  "name": "ComponentId",
                  "value": "${appi-id}",
                  "isOptional": true
                },
                {
                  "name": "TimeContext",
                  "value": null,
                  "isOptional": true
                },
                {
                  "name": "ResourceIds",
                  "value": [
                    "${appi-id}"
                  ],
                  "isOptional": true
                },
                {
                  "name": "ConfigurationId",
                  "value": "${workbook-id}",
                  "isOptional": true
                },
                {
                  "name": "Type",
                  "value": "workbook",
                  "isOptional": true
                },
                {
                  "name": "GalleryResourceType",
                  "value": "microsoft.insights/components",
                  "isOptional": true
                },
                {
                  "name": "PinName",
                  "value": "Posti prod overview",
                  "isOptional": true
                },
                {
                  "name": "StepSettings",
                  "value": "{\"version\":\"KqlItem/1.0\",\"query\":\"let sendRequests = traces\\r\\n| where timestamp > now(-7d)\\r\\n| where operation_Name != \\\"\\\" or severityLevel > 1 \\r\\n| where cloud_RoleName == \\\"PostiIntegration\\\" and operation_Name == \\\"UpdateRegistry\\\"\\r\\n| where customDimensions.prop__Uri matches regex \\\"https://sbxgw.ecosystem.posti.fi/cdupdate/cu/v1/register/rd223u0001/\\\" and message startswith \\\"End processing HTTP request after\\\";\\r\\n\\r\\nlet data = sendRequests\\r\\n| summarize Mean = avg(todouble(customDimensions.[\\\"prop__ElapsedMilliseconds\\\"])), (Median, p95) = percentiles(todouble(customDimensions.prop__ElapsedMilliseconds), 50, 95), Count = count(), Successes = sum(toint(customDimensions.prop__StatusCode) == 200 or toint(customDimensions.prop__StatusCode) == 201 or toint(customDimensions.prop__StatusCode) == 204) by Msg = tostring(customDimensions.[\\\"prop__OriginalFormat\\\"]), Method = tostring(customDimensions.[\\\"prop__Uri\\\"])\\r\\n| project HttpMethod = Method, Successes = Successes, Mean, Median, p95, Count, rank = 2\\r\\n| union (sendRequests\\r\\n    | summarize Mean = avg(todouble(customDimensions.[\\\"prop__ElapsedMilliseconds\\\"])), (Median, p95) = percentiles(todouble(customDimensions.[\\\"prop__ElapsedMilliseconds\\\"]), 50, 95), Count = count(), Successes = sum(toint(customDimensions.prop__StatusCode) == 200 or toint(customDimensions.prop__StatusCode) == 201 or toint(customDimensions.prop__StatusCode) == 204)\\r\\n    | project HttpMethod = '🔸 Posti send requests', Successes = Successes, Mean, Median, p95, Count, rank = 1);\\r\\n\\r\\ndata\\r\\n| extend Relevance = Mean * Count, Success_Rate = (toreal(Successes) / toreal(Count)) * 100\\r\\n| sort by rank asc, Relevance desc\\r\\n| project-away Relevance, rank, Successes\\r\\n| extend Success_Rate = round(Success_Rate, 2), Mean = round(Mean, 2), Median = round(Median, 2), p95 = round(p95, 2)\\r\\n| project HttpMethod, Count, Success_Rate, Mean, Median, p95\\r\\n| render table\",\"size\":0,\"title\":\"Posti Integration - Send Files Requests performance\",\"timeContext\":{\"durationMs\":259200000,\"endTime\":\"2022-09-28T10:19:00.000Z\"},\"queryType\":0,\"resourceType\":\"microsoft.insights/components\",\"gridSettings\":{\"formatters\":[{\"columnMatch\":\"Count\",\"formatOptions\":{\"palette\":\"blue\"},\"formatter\":8},{\"columnMatch\":\"Success_Rate\",\"formatOptions\":{\"max\":100,\"min\":0,\"palette\":\"redGreen\"},\"formatter\":8},{\"columnMatch\":\"Mean|Median|p95\",\"formatOptions\":{\"max\":20000,\"min\":0,\"palette\":\"greenRed\"},\"formatter\":8}],\"sortBy\":[{\"itemKey\":\"HttpMethod\",\"sortOrder\":1}]},\"sortBy\":[{\"itemKey\":\"HttpMethod\",\"sortOrder\":1}]}",
                  "isOptional": true
                },
                {
                  "name": "ParameterValues",
                  "value": {},
                  "isOptional": true
                },
                {
                  "name": "Location",
                  "value": "westeurope",
                  "isOptional": true
                }
              ],
              "type": "Extension/AppInsightsExtension/PartType/PinnedNotebookQueryPart"
            }
          },
          "7": {
            "position": {
              "x": 10,
              "y": 13,
              "colSpan": 9,
              "rowSpan": 4
            },
            "metadata": {
              "inputs": [
                {
                  "name": "ComponentId",
                  "value": "${appi-id}",
                  "isOptional": true
                },
                {
                  "name": "TimeContext",
                  "value": null,
                  "isOptional": true
                },
                {
                  "name": "ResourceIds",
                  "value": [
                    "${appi-id}"
                  ],
                  "isOptional": true
                },
                {
                  "name": "ConfigurationId",
                  "value": "${workbook-id}",
                  "isOptional": true
                },
                {
                  "name": "Type",
                  "value": "workbook",
                  "isOptional": true
                },
                {
                  "name": "GalleryResourceType",
                  "value": "microsoft.insights/components",
                  "isOptional": true
                },
                {
                  "name": "PinName",
                  "value": "Posti prod overview",
                  "isOptional": true
                },
                {
                  "name": "StepSettings",
                  "value": "{\"version\":\"KqlItem/1.0\",\"query\":\"let sendRequests = traces\\r\\n| where operation_Name != \\\"\\\" or severityLevel > 1\\r\\n| where cloud_RoleName == \\\"PostiIntegration\\\" and (operation_Name == \\\"FetchRegistryChanges\\\" or operation_Name == \\\"RefetchFailedRegistryChanges\\\")\\r\\n| where message startswith \\\"Posti fetch changes status\\\";\\r\\n\\r\\nlet data = sendRequests\\r\\n| summarize Count = count() by FetchStatus = tostring(customDimensions.[\\\"prop__status\\\"])\\r\\n| project FetchStatus, Count, rank = 2\\r\\n| union (sendRequests\\r\\n| summarize Count = count() by FetchStatus = tostring(customDimensions.[\\\"prop__status\\\"])\\r\\n| project FetchStatus = '🔸 Posti fetch Statuses', Count, rank = 1);\\r\\n\\r\\ndata\\r\\n| sort by rank asc\\r\\n| project-away rank\\r\\n| project FetchStatus, Count\\r\\n| render table\",\"size\":0,\"title\":\"PostiInegration - Fetch Statuses\",\"timeContext\":{\"durationMs\":259200000,\"endTime\":\"2022-09-28T10:19:00.000Z\"},\"queryType\":0,\"resourceType\":\"microsoft.insights/components\",\"gridSettings\":{\"formatters\":[{\"columnMatch\":\"Count\",\"formatOptions\":{\"palette\":\"blue\"},\"formatter\":8},{\"columnMatch\":\"Success_Rate\",\"formatOptions\":{\"max\":100,\"min\":0,\"palette\":\"redGreen\"},\"formatter\":8},{\"columnMatch\":\"Mean|Median|p95\",\"formatOptions\":{\"max\":20000,\"min\":0,\"palette\":\"greenRed\"},\"formatter\":8}]},\"sortBy\":[]}",
                  "isOptional": true
                },
                {
                  "name": "ParameterValues",
                  "value": {},
                  "isOptional": true
                },
                {
                  "name": "Location",
                  "value": "westeurope",
                  "isOptional": true
                }
              ],
              "type": "Extension/AppInsightsExtension/PartType/PinnedNotebookQueryPart"
            }
          },
          "8": {
            "position": {
              "x": 0,
              "y": 22,
              "colSpan": 11,
              "rowSpan": 4
            },
            "metadata": {
              "inputs": [
                {
                  "name": "ComponentId",
                  "value": "${appi-id}",
                  "isOptional": true
                },
                {
                  "name": "TimeContext",
                  "value": null,
                  "isOptional": true
                },
                {
                  "name": "ResourceIds",
                  "value": [
                    "${appi-id}"
                  ],
                  "isOptional": true
                },
                {
                  "name": "ConfigurationId",
                  "value": "${workbook-id}",
                  "isOptional": true
                },
                {
                  "name": "Type",
                  "value": "workbook",
                  "isOptional": true
                },
                {
                  "name": "GalleryResourceType",
                  "value": "microsoft.insights/components",
                  "isOptional": true
                },
                {
                  "name": "PinName",
                  "value": "Posti prod overview",
                  "isOptional": true
                },
                {
                  "name": "StepSettings",
                  "value": "{\"version\":\"KqlItem/1.0\",\"query\":\"let sendRequests = traces\\r\\n| where timestamp > now(-7d)\\r\\n|  where operation_Name != \\\"\\\" or severityLevel > 1\\r\\n| where cloud_RoleName == \\\"PostiIntegration\\\" and (operation_Name == \\\"FetchRegistryChanges\\\" or operation_Name == \\\"RefetchFailedRegistryChanges\\\")\\r\\n| where customDimensions.prop__Uri matches regex \\\"https://sbxgw.ecosystem.posti.fi/cdupdate/cu/v1/register/rd223u0001/\\\" and message startswith \\\"End processing HTTP request after\\\";\\r\\n\\r\\nlet data = sendRequests\\r\\n| summarize Mean = avg(todouble(customDimensions.[\\\"prop__ElapsedMilliseconds\\\"])), (Median, p95) = percentiles(todouble(customDimensions.prop__ElapsedMilliseconds), 50, 95), Count = count(), Successes = sum(toint(customDimensions.prop__StatusCode) == 200 or toint(customDimensions.prop__StatusCode) == 201 or toint(customDimensions.prop__StatusCode) == 204) by Msg = tostring(customDimensions.[\\\"prop__OriginalFormat\\\"]), Method = tostring(customDimensions.[\\\"prop__Uri\\\"])\\r\\n| project PostiRequest = Method, Successes = Successes, Mean, Median, p95, Count, rank = 2\\r\\n| union (sendRequests\\r\\n    | summarize Mean = avg(todouble(customDimensions.[\\\"prop__ElapsedMilliseconds\\\"])), (Median, p95) = percentiles(todouble(customDimensions.[\\\"prop__ElapsedMilliseconds\\\"]), 50, 95), Count = count(), Successes = sum(toint(customDimensions.prop__StatusCode) == 200 or toint(customDimensions.prop__StatusCode) == 201 or toint(customDimensions.prop__StatusCode) == 204)\\r\\n    | project PostiRequest = '🔸 Posti fetch requests', Successes = Successes, Mean, Median, p95, Count, rank = 1);\\r\\n\\r\\ndata\\r\\n| extend Relevance = Mean * Count, Success_Rate = (toreal(Successes) / toreal(Count)) * 100\\r\\n| sort by rank asc, Relevance desc\\r\\n| project-away Relevance, rank, Successes\\r\\n| extend Success_Rate = round(Success_Rate, 2), Mean = round(Mean, 2), Median = round(Median, 2), p95 = round(p95, 2)\\r\\n| project PostiRequest, Count, Success_Rate, Mean, Median, p95\\r\\n| render table\",\"size\":0,\"title\":\"PostiInegration - Fetch Requests performance\",\"timeContext\":{\"durationMs\":259200000,\"endTime\":\"2022-09-28T10:19:00.000Z\"},\"queryType\":0,\"resourceType\":\"microsoft.insights/components\",\"gridSettings\":{\"formatters\":[{\"columnMatch\":\"Count\",\"formatOptions\":{\"palette\":\"blue\"},\"formatter\":8},{\"columnMatch\":\"Success_Rate\",\"formatOptions\":{\"max\":100,\"min\":0,\"palette\":\"redGreen\"},\"formatter\":8},{\"columnMatch\":\"Mean|Median|p95\",\"formatOptions\":{\"max\":20000,\"min\":0,\"palette\":\"greenRed\"},\"formatter\":8}]},\"sortBy\":[]}",
                  "isOptional": true
                },
                {
                  "name": "ParameterValues",
                  "value": {},
                  "isOptional": true
                },
                {
                  "name": "Location",
                  "value": "westeurope",
                  "isOptional": true
                }
              ],
              "type": "Extension/AppInsightsExtension/PartType/PinnedNotebookQueryPart"
            }
          },
          "9": {
            "position": {
              "x": 0,
              "y": 26,
              "colSpan": 9,
              "rowSpan": 6
            },
            "metadata": {
              "inputs": [
                {
                  "name": "ComponentId",
                  "value": "${appi-id}"
                }
              ],
              "type": "Extension/AppInsightsExtension/PartType/AppMapGalPt",
              "settings": {
                "content": {
                  "DataModelJSON": "{}",
                  "exclude4xxError": true,
                  "layout": "Hierarchical"
                }
              },
              "asset": {
                "idInputName": "ComponentId",
                "type": "ApplicationInsights"
              },
              "filters": {
                "MsPortalFx_TimeRange": {
                  "model": {
                    "format": "utc",
                    "granularity": "1h",
                    "relative": "24h"
                  }
                }
              }
            }
          },
          "10": {
            "position": {
              "x": 0,
              "y": 22,
              "colSpan": 11,
              "rowSpan": 4
            },
            "metadata": {
              "inputs": [
                {
                  "name": "ComponentId",
                  "value": "${appi-id}",
                  "isOptional": true
                },
                {
                  "name": "TimeContext",
                  "value": null,
                  "isOptional": true
                },
                {
                  "name": "ResourceIds",
                  "value": [
                    "${appi-id}"
                  ],
                  "isOptional": true
                },
                {
                  "name": "ConfigurationId",
                  "value": "${workbook-id}",
                  "isOptional": true
                },
                {
                  "name": "Type",
                  "value": "workbook",
                  "isOptional": true
                },
                {
                  "name": "GalleryResourceType",
                  "value": "microsoft.insights/components",
                  "isOptional": true
                },
                {
                  "name": "PinName",
                  "value": "Posti prod overview",
                  "isOptional": true
                },
                {
                  "name": "StepSettings",
                  "value": "{\"version\": \"KqlItem/1.0\",\"query\": \"let postiChanges = traces\\n| where operation_Name == \\\"FetchRegistryChanges\\\" and  message has \\\"Clm Updater posti changes request body\\\"\\n| order by timestamp asc;\\nlet totalUsers = postiChanges\\n| extend parsedProp = parse_json(trim_start(\\\"Clm Updater posti changes request body\\\\nJson Body: \\\", message)) \\n| mv-expand parsedProp\\n| project timestamp, parsedProp, Status = \\\"Total Users\\\";\\nlet identifiedUsers = totalUsers\\n| where parsedProp.WasIdentified == true\\n| project timestamp, Status = \\\"Identified\\\";\\nlet addressChangeUsers = totalUsers\\n| where parsedProp.WasAddressChanged == true\\n| project timestamp, Status = \\\"Address Changed\\\";\\nlet foreignAddressChangeUsers = totalUsers\\n| where parsedProp.WasForeignAddressChanged == true\\n| project timestamp, Status = \\\"Foreign Address Changed\\\";\\nlet nameChangeUsers = totalUsers\\n| where parsedProp.WasNameChanged == true\\n| project timestamp, Status = \\\"Name Changed\\\";\\nlet deceasedUsers = totalUsers\\n| where parsedProp.IsDeceased == true\\n| project timestamp, Status = \\\"Deceased\\\";\\nlet minorUsers = totalUsers\\n| where parsedProp.IsMinor == true\\n| project timestamp, Status = \\\"Minor\\\";\\nlet duplicateUsers = totalUsers\\n| where parsedProp.IsMinor == true\\n| project timestamp, Status = \\\"Duplicate\\\";\\nlet min_t = now(-7d);\\nlet max_t = now();\\nlet dt = 1d;\\ntotalUsers | union identifiedUsers, addressChangeUsers, deceasedUsers, nameChangeUsers, foreignAddressChangeUsers, minorUsers, duplicateUsers\\n| make-series count() default = 0 on timestamp from min_t to max_t step dt by Status\\n| render  barchart\",\r\n        \"size\": 0,\r\n        \"title\": \"Posti Response Summary\",\r\n        \"timeContext\": {\r\n          \"durationMs\": 604800000\r\n        },\r\n        \"queryType\": 0,\r\n        \"resourceType\": \"microsoft.insights/components\",\r\n        \"gridSettings\": {\r\n          \"formatters\": [\r\n            {\r\n              \"columnMatch\": \"Count\",\r\n              \"formatOptions\": {\r\n                \"min\": 0,\r\n                \"palette\": \"blue\"\r\n              },\r\n              \"formatter\": 8\r\n            },\r\n            {\r\n              \"columnMatch\": \"Success_Rate\",\r\n              \"formatOptions\": {\r\n                \"compositeBarSettings\": {\r\n                  \"columnSettings\": [],\r\n                  \"labelText\": \"\"\r\n                },\r\n                \"max\": 100,\r\n                \"min\": 0,\r\n                \"palette\": \"redGreen\"\r\n              },\r\n              \"formatter\": 8\r\n            },\r\n            {\r\n              \"columnMatch\": \"Mean|Median|p95\",\r\n              \"formatOptions\": {\r\n                \"max\": 20000,\r\n                \"min\": 0,\r\n                \"palette\": \"greenRed\"\r\n              },\r\n              \"formatter\": 8}]}}",
                  "isOptional": true
                },
                {
                  "name": "ParameterValues",
                  "value": {},
                  "isOptional": true
                },
                {
                  "name": "Location",
                  "value": "westeurope",
                  "isOptional": true
                }
              ],
              "type": "Extension/AppInsightsExtension/PartType/PinnedNotebookQueryPart"
            }
          }
        }
      }
    },
    "metadata": {
      "model": {
        "timeRange": {
          "value": {
            "relative": {
              "duration": 24,
              "timeUnit": 1
            }
          },
          "type": "MsPortalFx.Composition.Configuration.ValueTypes.TimeRange"
        },
        "filterLocale": {
          "value": "en-us"
        },
        "filters": {
          "value": {
            "MsPortalFx_TimeRange": {
              "model": {
                "format": "utc",
                "granularity": "5m",
                "relative": "24h"
              },
              "displayCache": {
                "name": "UTC Time",
                "value": "Past 24 hours"
              },
              "filteredPartIds": [
                "StartboardPart-AppMapGalPt-b3b3d772-892c-4cde-8c33-dbb3e45ad06e",
                "StartboardPart-PinnedNotebookQueryPart-b3b3d772-892c-4cde-8c33-dbb3e45ad072",
                "StartboardPart-PinnedNotebookQueryPart-b3b3d772-892c-4cde-8c33-dbb3e45ad074",
                "StartboardPart-PinnedNotebookQueryPart-b3b3d772-892c-4cde-8c33-dbb3e45ad076",
                "StartboardPart-PinnedNotebookQueryPart-b3b3d772-892c-4cde-8c33-dbb3e45ad078",
                "StartboardPart-PinnedNotebookQueryPart-b3b3d772-892c-4cde-8c33-dbb3e45ad07a",
                "StartboardPart-PinnedNotebookQueryPart-b3b3d772-892c-4cde-8c33-dbb3e45ad07c",
                "StartboardPart-PinnedNotebookQueryPart-b3b3d772-892c-4cde-8c33-dbb3e45ad07e",
                "StartboardPart-PinnedNotebookQueryPart-b3b3d772-892c-4cde-8c33-dbb3e45ad080",
                "StartboardPart-PinnedNotebookQueryPart-b3b3d772-892c-4cde-8c33-dbb3e45ad080"
              ]
            }
          }
        }
      }
    }
  })}