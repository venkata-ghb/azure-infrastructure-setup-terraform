data "azurerm_resource_group" "main" {
  name = var.RESOURCE_GROUP_NAME
}

data "azurerm_client_config" "current" {
}

locals {
  tieto_vpn_ip = "115.110.104.174/32"
  project   = "lppcu"
  time_zone = "FLE Standard Time" # Time zone for Helsinki
  env = {
    dev = {
      devops_principal_id = "a047d6d2-d8df-431d-bdf4-f8e567ac8103", 
    },
    test = {
      devops_principal_id = "a12f1853-3a04-428f-8c18-c876159fd7dc"
    },
    prod = {
      devops_principal_id = "e87ef217-1b2b-4bce-9790-3067277966ed"
    }
  }
  kv_name = "https://lppcu-kv-${var.ENVIRONMENT}.vault.azure.net"

  # Remove these settings after the pilot. No longer needed after 01.03.2024
  pilot_settings = {
    dev = {
      is_enabled = false
      customer_id = 99999000
    },
    test = {
      is_enabled = false
      customer_id = 99999000
    },
    prod = {
      is_enabled = false
      customer_id = 99999000
    },
  }
}

/*------------------------------------Key Vault------------------------------------*/

resource "azurerm_key_vault" "kv" {
  name                            = "${local.project}-kv-${var.ENVIRONMENT}"
  location                        = data.azurerm_resource_group.main.location
  resource_group_name             = data.azurerm_resource_group.main.name
  enabled_for_disk_encryption     = true
  enabled_for_template_deployment = true
  purge_protection_enabled        = true
  tenant_id                       = data.azurerm_client_config.current.tenant_id

  sku_name = "standard"
  network_acls {
    bypass = "AzureServices"
    default_action = "Deny"
    ip_rules = concat([local.tieto_vpn_ip],module.clmupdater_function_app.ip_list)
  }

  lifecycle {
    ignore_changes = [tags,network_acls]
  }
}

resource "azurerm_key_vault_access_policy" "devops_kvaccess" {
  key_vault_id = azurerm_key_vault.kv.id
  tenant_id    = data.azurerm_client_config.current.tenant_id
  object_id    = local.env[var.ENVIRONMENT].devops_principal_id

  secret_permissions = [
      "List",
      "Set",
      "Get",
      "Delete"
    ]
}

# Adding access for ext.jhansi.nallamothu@kesko.fi user
resource "azurerm_key_vault_access_policy" "sameer_kvaccess" {
  key_vault_id = azurerm_key_vault.kv.id
  tenant_id    = data.azurerm_client_config.current.tenant_id
  object_id    = "31896672-a2c7-4a56-ac9b-29c6a0e15517"

  secret_permissions = [
      "List",
      "Set",
      "Get",
      "Delete"
    ]
}

/*------------------------------------MONITORING------------------------------------*/


resource "azurerm_log_analytics_workspace" "main" {
  name                = "${local.project}-log-${var.ENVIRONMENT}"
  location            = data.azurerm_resource_group.main.location
  resource_group_name = data.azurerm_resource_group.main.name
  sku                 = "PerGB2018"
  retention_in_days   = 60
  daily_quota_gb      = 10

  lifecycle {
    ignore_changes = [
      tags,
    ]
  }
}


/*------------------------------------APP INSIGHTS------------------------------------*/


resource "azurerm_application_insights" "main" {
  name                 = "${local.project}-appi-${var.ENVIRONMENT}"
  location             = data.azurerm_resource_group.main.location
  resource_group_name  = data.azurerm_resource_group.main.name
  workspace_id         = azurerm_log_analytics_workspace.main.id
  application_type     = "web"
  retention_in_days    = var.ENVIRONMENT == "prod" ? 90 : 30
  daily_data_cap_in_gb = var.ENVIRONMENT == "prod" ? 50 : 10

  lifecycle {
    ignore_changes = [
      tags,
    ]
  }
}

# Application Insights Standard Web Tests

module "clmupdater_swt" {
  source = "./modules/standardWebTest"
  resource_group_name = data.azurerm_resource_group.main.name
  resource_group_location = data.azurerm_resource_group.main.location
  name = "ClmUpdater"
  application_insights_id = azurerm_application_insights.main.id
  project = local.project
  environment = var.ENVIRONMENT
  url_route = "qVfnWT0dPFTQHH6jb14rYos"
}

module "eventbatchhandler_swt" {
  source = "./modules/standardWebTest"
  resource_group_name = data.azurerm_resource_group.main.name
  resource_group_location = data.azurerm_resource_group.main.location
  name = "eventbatchhandler"
  application_insights_id = azurerm_application_insights.main.id
  project = local.project
  environment = var.ENVIRONMENT
  url_route = "emUsFFRPInCfXnK7612cT9JL"
}

module "postiintegration_swt" {
  source = "./modules/standardWebTest"
  resource_group_name = data.azurerm_resource_group.main.name
  resource_group_location = data.azurerm_resource_group.main.location
  name = "PostiIntegration"
  application_insights_id = azurerm_application_insights.main.id
  project = local.project
  environment = var.ENVIRONMENT
  url_route = "Hv06apCobwy2Jz8PH8BV27S"
}

/*------------------------------------WORKBOOKS------------------------------------*/


resource "random_uuid" "posti_overview" {
}

resource "azurerm_application_insights_workbook" "posti_overview" {
  name                = resource.random_uuid.posti_overview.result
  resource_group_name = data.azurerm_resource_group.main.name
  location            = data.azurerm_resource_group.main.location
  display_name        = "Posti ${var.ENVIRONMENT} overview"
  source_id           = lower(resource.azurerm_application_insights.main.id)
  data_json           = templatefile("./workbooks/posti-overview.tpl", { appi-id = resource.azurerm_application_insights.main.id })

  lifecycle {
    ignore_changes = [
      tags,
    ]
  }
}


/*------------------------------------DASHBOARDS------------------------------------*/


resource "azurerm_portal_dashboard" "main" {
  name                 = "${local.project}-dash-Overview-${var.ENVIRONMENT}"
  resource_group_name  = data.azurerm_resource_group.main.name
  location             = data.azurerm_resource_group.main.location
  dashboard_properties = templatefile("./dashboards/main.tpl", { appi-id = resource.azurerm_application_insights.main.id, workbook-id = resource.azurerm_application_insights_workbook.posti_overview.id })

  lifecycle {
    ignore_changes = [
      tags,
      dashboard_properties,
    ]
  }
}


/*------------------------------------SERVICE PLAN------------------------------------*/


resource "azurerm_service_plan" "main" {
  name                = "${local.project}-plan-FunctionApp-${var.ENVIRONMENT}"
  location            = data.azurerm_resource_group.main.location
  resource_group_name = data.azurerm_resource_group.main.name
  os_type             = "Windows"
  sku_name            = "EP1"

  lifecycle {
    ignore_changes = [
      tags,
    ]
  }
}


/*------------------------------------COSMOSDB------------------------------------*/


resource "azurerm_cosmosdb_account" "acc" {
  name                = "${local.project}-cosmosacc-postisql-${var.ENVIRONMENT}"
  location            = data.azurerm_resource_group.main.location
  resource_group_name = data.azurerm_resource_group.main.name
  offer_type          = "Standard"

  capabilities {
    name = "EnableServerless"
  }

  consistency_policy {
    consistency_level       = "Strong"
  }

  geo_location {
    location          = data.azurerm_resource_group.main.location
    failover_priority = 0
  }

  public_network_access_enabled = true
  # IP allowlisting needed for access through portal
  # https://docs.microsoft.com/en-us/azure/cosmos-db/how-to-configure-firewall#allow-requests-from-the-azure-portal
  ip_range_filter = "115.110.104.174,131.207.242.128,20.126.245.27,40.76.54.131,52.169.50.45,52.176.6.30,52.187.184.26,104.42.195.92"
  is_virtual_network_filter_enabled = true
  virtual_network_rule {
    id = var.SUBNET_RESOURCE_ID
    ignore_missing_vnet_service_endpoint = false
  }

  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}

resource "azurerm_cosmosdb_sql_database" "cosmos_sql" {
  name                = "${local.project}-cosmos-PostiSql-${var.ENVIRONMENT}"
  resource_group_name = data.azurerm_resource_group.main.name
  account_name        = azurerm_cosmosdb_account.acc.name
}

resource "azurerm_monitor_diagnostic_setting" "cosmos" {
  name                       = "mds-${local.project}-CosmosDb-${var.ENVIRONMENT}"
  target_resource_id         = azurerm_cosmosdb_account.acc.id
  log_analytics_workspace_id = azurerm_log_analytics_workspace.main.id

  enabled_log {
    category = "DataPlaneRequests"

    retention_policy {
      enabled = true
      days    = 30
    }
  }

  # Azure generates defaults log and metric entries, ignoring them here to avoid Terraform attempting to delete them.
  # https://github.com/terraform-providers/terraform-provider-azurerm/issues/10388
  lifecycle {
    ignore_changes = [metric]
  }
}


/*------------------------------------FUNCTION APPS------------------------------------*/


# CLM Updater

module "clmupdater_function_app" {
  source = "./modules/functionApp"
  project = local.project
  name = "ClmUpdater"
  environment = var.ENVIRONMENT
  
  resource_group_location = data.azurerm_resource_group.main.location
  resource_group_name = data.azurerm_resource_group.main.name
  service_plan_id = azurerm_service_plan.main.id
  application_insights_key = azurerm_application_insights.main.instrumentation_key
  subnet_id = var.SUBNET_RESOURCE_ID
  tieto_vpn_ip = local.tieto_vpn_ip

  app_settings = {
    "ClmProfileSettings__BaseUrl"                   = var.CLM_PROFILE_BASE_URL,
    "ClmAuthSettings__BaseUrl"                      = var.CLM_AUTH_BASE_URL,
    "ClmAuthSettings__ClientId"                     = "@Microsoft.KeyVault(SecretUri=${local.kv_name}/secrets/clm-auth-client-access-key/)",
    "ClmAuthSettings__ClientSecret"                 = "@Microsoft.KeyVault(SecretUri=${local.kv_name}/secrets/clm-auth-client-access-secret/)",
    "ClmAuthSettings__ApiKey"                       = "@Microsoft.KeyVault(SecretUri=${local.kv_name}/secrets/clm-auth-api-key-secret/)",
    "ClmAuthSettings__DisableGrantScopeChannel"     = var.CLM_AUTH_DISABLE_GRANT_SCOPE_CHANNEL
    "ClmProfileSettings__DisableProcessingChanges"  = var.CLM_PROFILE_DISABLE_PROCESSING_CHANGES
    "CosmosDbSettings__Name"                        = azurerm_cosmosdb_sql_database.cosmos_sql.name
    "CosmosDbSettings__ConnectionString"            = "@Microsoft.KeyVault(SecretUri=${local.kv_name}/secrets/lppcu-cosmos-db-connection-string/)",
    "CosmosDbSettings__ClmUpdateErrorsContainer"    = var.CLM_UPDATE_ERRORS_CONTAINER_NAME
    "CosmosDbSettings__DisableStoreClmUpdateErrors" = var.DISABLE_STORE_CLM_UPDATE_ERRORS
    "FunctionSettings__DisableClmErrorResend"       = var.FUNCTIONSETTINGS_DISABLE_CLM_ERROR_RESEND
    "AzureWebJobs.UpdateClm.Disabled"               = 0
    "AzureWebJobs.DeleteClmUpdateErrors.Disabled"   = 0
    "FUNCTIONS_INPROC_NET8_ENABLED"                 = 1
  }

  tenant_id = data.azurerm_client_config.current.tenant_id
  key_vault_id = azurerm_key_vault.kv.id
}

resource "azurerm_cosmosdb_sql_container" "clm_update_errors" {
  name                = "ClmUpdateErrors"
  resource_group_name = data.azurerm_resource_group.main.name
  account_name        = azurerm_cosmosdb_account.acc.name
  database_name       = azurerm_cosmosdb_sql_database.cosmos_sql.name
  partition_key_paths  = ["/failedOperation"]

  indexing_policy {
    indexing_mode = "none"
  }
}

# Posti integration

module "postiintegration_function_app" {
  source = "./modules/functionApp"
  project = local.project
  name = "PostiIntegration"
  environment = var.ENVIRONMENT
  
  resource_group_location = data.azurerm_resource_group.main.location
  resource_group_name = data.azurerm_resource_group.main.name
  service_plan_id = azurerm_service_plan.main.id
  application_insights_key = azurerm_application_insights.main.instrumentation_key
  subnet_id = var.SUBNET_RESOURCE_ID
  tieto_vpn_ip = local.tieto_vpn_ip

  app_settings = {
    "PostiApiSettings__RegistryId"                          = "@Microsoft.KeyVault(SecretUri=${local.kv_name}/secrets/posti-registry-id/)",
    "PostiApiSettings__BaseUrl"                             = var.API_BASE_URL,
    "PostiApiSettings__RetryCount"                          = var.API_RETRY_COUNT,
    "PostiApiSettings__RetryIncrementInSeconds"             = var.API_RETRY_INCREMENT_IN_SECONDS,
    "PostiApiSettings__DisableFetchingChangesFromPosti"     = var.DISABLE_FETCHING_CHANGES_FROM_POSTI,
    "PostiApiSettings__DisableSendingChangesToPosti"        = var.DISABLE_SENDING_CHANGES_TO_POSTI,
    "PostiAuthSettings__BaseUrl"                            = var.AUTH_BASE_URL,
    "PostiAuthSettings__TokenTreshold"                      = var.AUTH_TOKEN_TRESHOLD,
    "PostiAuthSettings__ConsumerKey"                        = "@Microsoft.KeyVault(SecretUri=${local.kv_name}/secrets/posti-api-consumer-key/)",
    "PostiAuthSettings__ConsumerSecret"                     = "@Microsoft.KeyVault(SecretUri=${local.kv_name}/secrets/posti-api-consumer-secret/)",
    "ClmUpdaterSettings__Url"                               = module.clmupdater_function_app.url
    "ClmUpdaterSettings__HostKey"                           = "@Microsoft.KeyVault(SecretUri=${local.kv_name}/secrets/ClmUpdater-function-access-key/)",
    "ClmUpdaterSettings__DisableSendingChangesToClmUpdater" = var.DISABLE_SENDING_CHANGES_TO_CLM_UPDATER
    "EventBatcherSettings__Url"                             = var.EVENT_BATCH_HANDLER_URL
    "EventBatcherSettings__HostKey"                         = "@Microsoft.KeyVault(SecretUri=${local.kv_name}/secrets/EventBatchHandler-function-access-key/)",
    "EventBatcherSettings__DisableBatchFetching"            = var.DISABLE_BATCH_FETCHING
    "EventBatcherSettings__DisableDeletingDuplicate"        = false
    "CosmosDbSettings__Name"                                = azurerm_cosmosdb_sql_database.cosmos_sql.name
    "CosmosDbSettings__ConnectionString"                    = "@Microsoft.KeyVault(SecretUri=${local.kv_name}/secrets/lppcu-cosmos-db-connection-string/)",
    "CosmosDbSettings__PostiErrorsContainer"                = var.POSTI_ERRORS_CONTAINER_NAME
    "CosmosDbSettings__FileFetchingErrorsContainer"         = "FileFetchingErrors"
    "CosmosDbSettings__DisableStorePostiErrors"             = var.DISABLE_STORE_POSTI_ERRORS
    "FunctionSettings__DisableFileRefetch"                  = false
    "FetchRegistryChangesTriggerSchedule"                   = var.ENVIRONMENT == "prod" ? "0 0 5,8,11,14,19 * * *" : "0 30 5,6,7,8,9,10,11,12,13,14,15,16,17 * * *"
    "AzureWebJobs.FetchRegistryChanges.Disabled"            = var.ENVIRONMENT == "dev" ? 1 : 0
    "AzureWebJobs.RefetchFailedRegistryChanges.Disabled"    = var.ENVIRONMENT == "dev" ? 1 : 0
    "FUNCTIONS_INPROC_NET8_ENABLED"                         = 1
  }
  tenant_id = data.azurerm_client_config.current.tenant_id
  key_vault_id = azurerm_key_vault.kv.id
}

resource "azurerm_cosmosdb_sql_container" "posti_errors" {
  name                = "PostiErrors"
  resource_group_name = data.azurerm_resource_group.main.name
  account_name        = azurerm_cosmosdb_account.acc.name
  database_name       = azurerm_cosmosdb_sql_database.cosmos_sql.name
  partition_key_paths  = ["/operation"]

  indexing_policy {
    indexing_mode = "none"
  }
}

resource "azurerm_cosmosdb_sql_container" "file_fetching_errors" {
  name                = "FileFetchingErrors"
  resource_group_name = data.azurerm_resource_group.main.name
  account_name        = azurerm_cosmosdb_account.acc.name
  database_name       = azurerm_cosmosdb_sql_database.cosmos_sql.name
  partition_key_paths  = ["/id"]

  indexing_policy {
    indexing_mode = "none"
  }
}

# Event batch handler

resource "azurerm_user_assigned_identity" "main" {
  name                = "${local.project}-id-EventBatchHandler-${var.ENVIRONMENT}"
  resource_group_name = data.azurerm_resource_group.main.name
  location            = data.azurerm_resource_group.main.location

  lifecycle {
    ignore_changes = [
      tags,
    ]
  }
}

module "event_batch_handler_function_app" {
  source = "./modules/functionApp"
  project = local.project
  name = "EventBatchHandler"
  environment = var.ENVIRONMENT
  
  resource_group_location = data.azurerm_resource_group.main.location
  resource_group_name = data.azurerm_resource_group.main.name
  service_plan_id = azurerm_service_plan.main.id
  application_insights_key = azurerm_application_insights.main.instrumentation_key
  subnet_id = var.SUBNET_RESOURCE_ID
  tieto_vpn_ip = local.tieto_vpn_ip

  app_settings = {
    "CosmosDbSettings__Name"                                    = azurerm_cosmosdb_sql_database.cosmos_sql.name
    "CosmosDbSettings__ConnectionString"                        = "@Microsoft.KeyVault(SecretUri=${local.kv_name}/secrets/lppcu-cosmos-db-connection-string/)",
    "CosmosDbSettings__InvalidDataContainer"                    = azurerm_cosmosdb_sql_container.invalid_clm_data.name
    "CosmosDbSettings__OperationsContainer"                     = azurerm_cosmosdb_sql_container.operations.name
    "CosmosDbSettings__CustomerContainer"                       = azurerm_cosmosdb_sql_container.customer_container.name
    "CosmosDbSettings__CustomerLeftDocumentTtl"                 = 30
    "CosmosDbSettings__OperationsUnbatchedPartitionKey"         = var.UNBATCHED_OPERATIONS_PARTITION_KEY
    "CosmosDbSettings__BatchesContainer"                        = azurerm_cosmosdb_sql_container.batches.name
    "CosmosDbSettings__DisableStoreNewOperations"               = var.DISABLE_STORE_NEW_OPERATIONS
    "CosmosDbSettings__DisableStoreInvalidData"                 = var.DISABLE_STORE_INVALID_DATA
    "CosmosDbSettings__DisableBuildNewBatch"                    = var.DISABLE_BUILD_NEW_BATCH
    "CosmosDbSettings__DisableStoreNewBatch"                    = var.DISABLE_STORE_NEW_BATCH
    "PilotSettings__PilotCustomerId"                            = local.pilot_settings[var.ENVIRONMENT].customer_id
    "PilotSettings__IsPilotEnabled"                             = local.pilot_settings[var.ENVIRONMENT].is_enabled
    "CosmosDbSettings__DisableFetchingBatches"                  = var.DISABLE_FETCHING_BATCHES
    "PostiIntegrationSettings__Url"                             = module.postiintegration_function_app.url
    "PostiIntegrationSettings__HostKey"                         = "@Microsoft.KeyVault(SecretUri=${local.kv_name}/secrets/PostiIntegration-function-access-key/)",
    "PostiIntegrationSettings__DisableSendOperationsForUpdate"  = var.DISABLE_SEND_OPERATIONS_FOR_UPDATE
    "BuildAndSendNewBatchTriggerSchedule"                       = var.ENVIRONMENT == "prod" ? "0 0 7,10,13,18 * * *" : "0 0 5,6,7,8,9,10,11,12,13,14,15,16,17 * * *"
    "CustomerLifeCycleHub__hubName"                             = var.CUSTOMER_LIFECYCLE_HUB_NAME
    "CustomerLifeCycleHub__fullyQualifiedNamespace"             = var.CUSTOMER_LIFECYCLE_FQNS
    "CustomerLifeCycleHub__consumerGroupName"                   = var.CUSTOMER_LIFECYCLE_CONSUMER_GROUP_NAME
    "CustomerLifeCycleHub__credential"                          = "managedidentity"
    "CustomerLifeCycleHub__clientId"                            = azurerm_user_assigned_identity.main.client_id
    "CustomerInfoUpdateHub__consumerGroupName"                  = var.CUSTOMER_INFO_UPDATE_CONSUMER_GROUP_NAME
    "CustomerInfoUpdateHub__hubName"                            = var.CUSTOMER_INFO_UPDATE_HUB_NAME
    "AzureWebJobs.ReceiveLifecycleEvent.Disabled"               = 0
    "AzureWebJobs.ReceiveUpdateEvent.Disabled"                  = 0
    "AzureWebJobs.BuildAndSendNewBatch.Disabled"                = var.ENVIRONMENT == "dev" ? 1 : 0
    "FUNCTIONS_INPROC_NET8_ENABLED"                             = 1
    
  }
  identity_type = "SystemAssigned, UserAssigned"
  identity_ids = [ azurerm_user_assigned_identity.main.id ]
  tenant_id = data.azurerm_client_config.current.tenant_id
  key_vault_id = azurerm_key_vault.kv.id
}

resource "azurerm_cosmosdb_sql_container" "invalid_clm_data" {
  name                = "InvalidClmData"
  resource_group_name = data.azurerm_resource_group.main.name
  account_name        = azurerm_cosmosdb_account.acc.name
  database_name       = azurerm_cosmosdb_sql_database.cosmos_sql.name
  partition_key_paths  = ["/operation"]

  indexing_policy {
    indexing_mode = "none"
  }
}

resource "azurerm_cosmosdb_sql_container" "operations" {
  name                = "Operations"
  resource_group_name = data.azurerm_resource_group.main.name
  account_name        = azurerm_cosmosdb_account.acc.name
  database_name       = azurerm_cosmosdb_sql_database.cosmos_sql.name
  partition_key_paths  = ["/batchId"]

  indexing_policy {
    indexing_mode = "none"
  }
}

resource "azurerm_cosmosdb_sql_container" "batches" {
  name                = "Batches"
  resource_group_name = data.azurerm_resource_group.main.name
  account_name        = azurerm_cosmosdb_account.acc.name
  database_name       = azurerm_cosmosdb_sql_database.cosmos_sql.name
  # The number of batches should be low enough that we set a single
  # static partition key for all batches
  partition_key_paths  = ["/partitionKey"]

  indexing_policy {
    indexing_mode = "none"
  }
}

resource "azurerm_cosmosdb_sql_container" "configuration" {
  name                = "Configuration"
  resource_group_name = data.azurerm_resource_group.main.name
  account_name        = azurerm_cosmosdb_account.acc.name
  database_name       = azurerm_cosmosdb_sql_database.cosmos_sql.name
  # The number of batches should be low enough that we set a single
  # static partition key for all batches
  partition_key_paths  = ["/type"]

  indexing_policy {
    indexing_mode = "none"
  }
}

resource "azurerm_cosmosdb_sql_container" "customer_container" {
  name                = "Customers"
  resource_group_name = data.azurerm_resource_group.main.name
  account_name        = azurerm_cosmosdb_account.acc.name
  database_name       = azurerm_cosmosdb_sql_database.cosmos_sql.name
  partition_key_paths  = ["/id"]
  default_ttl         = -1

}
