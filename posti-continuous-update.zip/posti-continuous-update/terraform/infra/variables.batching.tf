# Names need to be in all caps to properly match imported variables in pipeline

variable "CUSTOMER_LIFECYCLE_HUB_NAME" {
  type        = string
  description = "The name of the life cycle hub."
}

variable "CUSTOMER_INFO_UPDATE_CONSUMER_GROUP_NAME" {
  type        = string
  description = "The name of the customer update consumer group the function should use."
}

variable "CUSTOMER_INFO_UPDATE_HUB_NAME" {
  type        = string
  description = "The name of the customer info update hub."
}

variable "CUSTOMER_LIFECYCLE_FQNS" {
  type        = string
  description = "The fully qualified namespace where the customer lifecycle hub resides."
}

variable "CUSTOMER_LIFECYCLE_CONSUMER_GROUP_NAME" {
  type        = string
  description = "The name of the consumer group the function should use."
}

variable "UNBATCHED_OPERATIONS_PARTITION_KEY" {
  type        = string
  description = "Constant partition key for operations that are not yet part of a sent batch."
}

variable "DISABLE_STORE_NEW_OPERATIONS" {
  type        = bool
  default     = false
  description = "Feature flag for disabling storage of incoming events that are stored as operations."
}

variable "DISABLE_STORE_INVALID_DATA" {
  type        = bool
  default     = false
  description = "Feature flag for disabling storage of invalid data in incoming events."
}

variable "DISABLE_BUILD_NEW_BATCH" {
  type        = bool
  default     = false
  description = "Feature flag for disabling building of new batches."
}

variable "DISABLE_STORE_NEW_BATCH" {
  type        = bool
  default     = false
  description = "Feature flag for disabling storage of built batches."
}

variable "DISABLE_SEND_OPERATIONS_FOR_UPDATE" {
  type        = bool
  default     = false
  description = "Feature flag for disabling sending of batches of operations to update in Posti."
}

variable "DISABLE_FETCHING_BATCHES" {
  type        = bool
  default     = false
  description = "Feature flag for disabling Fetching batches."
}

variable "POSTI_INTEGRATION_HOST_KEY" {
  type        = string
  description = "Host key for Posti Integration Function app."
  sensitive   = true
}
