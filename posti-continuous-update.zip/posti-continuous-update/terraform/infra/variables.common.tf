# Names need to be in all caps to properly match imported variables in pipeline

variable "ENVIRONMENT" {
  type        = string
  description = "The environment the deployment is being made in."
}

variable "RESOURCE_GROUP_NAME" {
  type        = string
  description = "Resource group to create resources in"
}

variable "SUBNET_RESOURCE_ID" {
  type = string
}