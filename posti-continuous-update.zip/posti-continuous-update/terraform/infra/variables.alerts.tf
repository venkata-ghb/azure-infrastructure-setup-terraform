variable "ALERT_EMAIL_RECEIVER_NAME" {
  type        = string
  description = "Name of the receiver of alert email"
}

variable "ALERT_EMAIL_RECEIVER_ADDRESS" {
  type        = string
  description = "Target email for alert emails"
}


variable "TIETO_EMAIL_RECEIVER_ADDRESS" {
  type        = string
  description = "Tieto target email for alert emails"
}

variable "INVALID_LIFECYCLE_THRESHOLD" {
  type        = number
  description = "The percentage threshold for firing an alert for lifecycles with invalid data"
}

variable "UNEXPECTED_LIFECYCLE_ERROR_THRESHOLD" {
  type        = number
  description = "The percentage threshold for firing an alert for unexpected errors in lifecycle processing"
}

variable "COSMOS_ERROR_THRESHOLD" {
  type        = number
  description = "The percentage threshold for firing an alert for cosmos errors"
}

variable "UNSUCCESSFUL_CLM_REQUESTS_THRESHOLD" {
  type        = number
  description = "The percentage threshold for firing an alert for unsuccessful requests to CLM"
}

variable "UNSUCCESSFUL_POSTI_FETCH_THRESHOLD" {
  type        = number
  description = "The percentage threshold for firing an alert for unsuccessful fetching from POSTI"
}

variable "UNSUCCESSFUL_POSTI_FILE_SEND_THRESHOLD" {
  type        = number
  description = "The percentage threshold for firing an alert for unsuccessful sending files to POSTI"
}

variable "POSTI_URL_HOST" {
  type        = string
  description = "POSTI URL"
  sensitive   = true
}
variable "dev_team_emails" {
  type = list(string)
  description = "Providing the Development team DL for alerts"
  default = ["KeskoAMS.DotNET@tcs.com"]
}
variable "azure_team_DL" {
    description = "Providing the Azure team DL for alerts"
    default     = "keskoAMS.cloud@tcs.com"
}