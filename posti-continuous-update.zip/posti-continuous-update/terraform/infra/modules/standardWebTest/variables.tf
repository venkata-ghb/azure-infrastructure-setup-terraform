variable "name" {
  type        = string
  description = "Name of the application (for resource names and identifiers)"
}

variable "project" {
  type        = string
  description = "Name of the project"
}

variable "resource_group_name" {
  type        = string
  description = "Resource group name"
}

variable "resource_group_location" {
  type        = string
  description = "Resource group location"
}

variable "application_insights_id" {
  type        = string
  description = "Application Insights Id"
}

variable "environment" {
  type        = string
  description = "The environment the deployment is being made in."
}

variable "url_route" {
  type        = string
  description = "URL Route."
}
