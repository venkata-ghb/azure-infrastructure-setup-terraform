resource "azurerm_application_insights_standard_web_test" "main" {
  name                    = "${var.project}-${var.name}-availability-${var.environment}"
  location                = var.resource_group_location
  resource_group_name     = var.resource_group_name
  application_insights_id = var.application_insights_id
  geo_locations           = ["emea-nl-ams-azr", "emea-gb-db3-azr"]
  enabled = true
  frequency = 900
  
  validation_rules {
    expected_status_code = 200 
    ssl_check_enabled = true
    ssl_cert_remaining_lifetime = 7
  }

  request {
    url = "https://lppcu-func-${var.name}-${var.environment}.azurewebsites.net/api/${var.url_route}/health-check"
    header {
      name = "x-functions-key"
      value = ""//Actual values are set in the app insights
    }
  }
  lifecycle {
    ignore_changes = [request, tags]
  }
}