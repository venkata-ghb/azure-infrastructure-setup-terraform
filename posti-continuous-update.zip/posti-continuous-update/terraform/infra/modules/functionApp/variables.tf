variable "name" {
  type        = string
  description = "Name of the application (for resource names and identifiers)"
}

variable "project" {
  type        = string
  description = "Name of the project"
}

variable "resource_group_name" {
  type        = string
  description = "Resource group name"
}

variable "resource_group_location" {
  type        = string
  description = "Resource group location"
}

variable "service_plan_id" {
  type        = string
  description = "Service plan ID"
}

variable "tieto_vpn_ip" {
  type        = string
  description = "IP Address of Tieto VPN"
}

variable "application_insights_key" {
  type        = string
  description = "Application Insights key"
}

variable "environment" {
  type        = string
  description = "The environment the deployment is being made in."
}

variable "subnet_id" {
  type        = string  
}

variable "app_settings" {
  type        = map
  description = "Function app settings (environment variables etc)"
  default     = {}
}

variable "identity_ids" {
  type        = list(string)
  description = "List of user assigned identity ids to assign to the app."
  default     = null
}
variable "identity_type" {
  type    = string
  default = "SystemAssigned"
}
variable "key_vault_id"{
  type = string
}
variable "tenant_id"{
  type = string
}