output "id" {
    value       = azurerm_windows_function_app.main.id
    description = "Resource id of the function app."
}

output "url" {
    value = "https://${azurerm_windows_function_app.main.name}.azurewebsites.net/api/"
    description = "URL to the Function app, assumes that the app uses the default /api suffix" 
}

output "name" { 
    value = azurerm_windows_function_app.main.name
    description = "Name of the function app" 
}

output "ip_list" { 
    value = azurerm_windows_function_app.main.possible_outbound_ip_address_list
    description = "Outbound IP Address List" 
}
