
resource "azurerm_windows_function_app" "main" {
  name                 = "${var.project}-func-${var.name}-${var.environment}"
  location             = var.resource_group_location
  resource_group_name  = var.resource_group_name

  storage_account_name       = azurerm_storage_account.main.name
  storage_account_access_key = azurerm_storage_account.main.primary_access_key
  service_plan_id            = var.service_plan_id 
  builtin_logging_enabled    = false
  
  https_only   = true
  virtual_network_subnet_id = var.subnet_id
  app_settings = merge({
    "CONTAINER_NAME" = "azure-webjobs-secrets"
  }, var.app_settings)

  site_config {
    use_32_bit_worker = false
    http2_enabled = true
    ftps_state                  = "Disabled"
    application_insights_key = var.application_insights_key
    application_stack {
      dotnet_version = "v8.0"
    }
    ip_restriction_default_action = "Deny"
    scm_ip_restriction_default_action = "Deny"
    vnet_route_all_enabled    = true
    scm_use_main_ip_restriction = true
    ip_restriction{
      service_tag = "AzureCloud.westeurope"
      name = "Azure Cloud"
    }
    ip_restriction {
      service_tag = "ApplicationInsightsAvailability"
      name = "App Insights"
    }
    ip_restriction {
      ip_address = var.tieto_vpn_ip
      priority = 300
      name = "Tieto VPN IP"
    }
  }

  /*We only want to do this assignment if an identity should be provided. But since
  at least in one case we need to assign identity data to a specific environment
  variable we can't create the identity in the module, but rather outside. This
  hack is based on these posts:
  https://medium.com/@business_99069/terraform-0-12-conditional-block-7d166e4abcbf
  https://medium.com/codex/terraform-conditional-logic-and-dynamic-configuration-blocks-19c3c3f62796*/
  identity {
    type         = var.identity_type
    identity_ids = var.identity_ids
  }
  
  lifecycle {
    prevent_destroy = true

    ignore_changes = [
      tags,
      service_plan_id,
      site_config[0].remote_debugging_version,
      app_settings["WEBSITE_RUN_FROM_PACKAGE"] # Adding this to avoid deletion of functions which are linked as "run from package"
    ]
  }
}

resource "azurerm_storage_account" "main" {
  name                     = "${var.project}st${substr(lower(var.name), 0, 10)}${var.environment}"
  location                 = var.resource_group_location
  resource_group_name      = var.resource_group_name
  account_tier             = "Standard"
  account_replication_type = "LRS"

  lifecycle {
    ignore_changes = [
      tags,
    ]
  }
}

resource "azurerm_key_vault_access_policy" "kvaccess" {
  key_vault_id = var.key_vault_id
  tenant_id    = azurerm_windows_function_app.main.identity[0].tenant_id
  object_id    = azurerm_windows_function_app.main.identity[0].principal_id

  secret_permissions = [
    "Get", "List",
  ]
}