${jsonencode({
  "version": "Notebook/1.0",
  "items": [
    {
      "type": 9,
      "content": {
        "version": "KqlParameterItem/1.0",
        "parameters": [
          {
            "id": "eac9cbf1-6364-4f28-9c61-a9b038c035d7",
            "isRequired": true,
            "name": "TimeRange",
            "type": 4,
            "typeSettings": {
              "allowCustom": true,
              "selectableValues": [
                {
                  "durationMs": 300000
                },
                {
                  "durationMs": 900000
                },
                {
                  "durationMs": 1800000
                },
                {
                  "durationMs": 3600000
                },
                {
                  "durationMs": 14400000
                },
                {
                  "durationMs": 43200000
                },
                {
                  "durationMs": 86400000
                },
                {
                  "durationMs": 172800000
                },
                {
                  "durationMs": 259200000
                },
                {
                  "durationMs": 604800000
                },
                {
                  "durationMs": 1209600000
                },
                {
                  "durationMs": 2592000000
                },
                {
                  "durationMs": 5184000000
                }
              ]
            },
            "value": {
              "durationMs": 86400000
            },
            "version": "KqlParameterItem/1.0"
          }
        ],
        "style": "pills",
        "queryType": 0,
        "resourceType": "microsoft.insights/components"
      },
      "name": "parameters - 1",
      "styleSettings": {
        "margin": "20px"
      }
    },
    {
      "type": 3,
      "content": {
        "version": "KqlItem/1.0",
        "query": "traces\r\n| where timestamp {TimeRange}\r\n| summarize ReceivedCount = count(), ValidCount = countif(customDimensions.LogLevel != \"Error\")\r\n| extend ValidPercentage = toreal(ValidCount) / toreal(ReceivedCount) * 100.0\r\n| project-away ReceivedCount, ValidCount\r\n| extend ValidPercentage = round(ValidPercentage, 2)",
        "size": 1,
        "title": "Overall Success Rate",
        "timeContextFromParameter": "TimeRange",
        "queryType": 0,
        "resourceType": "microsoft.insights/components",
        "visualization": "tiles",
        "gridSettings": {
          "formatters": [
            {
              "columnMatch": "ValidPercentage",
              "formatOptions": {
                "customColumnWidthSetting": "150px",
                "max": 0.01,
                "min": 100,
                "palette": "greenRed"
              },
              "formatter": 8,
              "numberFormat": {
                "options": {
                  "maximumFractionDigits": 2,
                  "style": "decimal"
                },
                "unit": 1
              }
            }
          ]
        },
        "tileSettings": {
          "showBorder": false,
          "size": "full",
          "titleContent": {
            "columnMatch": "ValidPercentage",
            "formatOptions": {
              "compositeBarSettings": {
                "columnSettings": [
                  {
                    "color": "lightBlue",
                    "columnName": "ValidPercentage"
                  }
                ],
                "labelText": ""
              },
              "max": 0.01,
              "min": 100,
              "palette": "greenRed"
            },
            "formatter": 8,
            "numberFormat": {
              "options": {
                "minimumFractionDigits": 2,
                "style": "decimal"
              },
              "unit": 1
            }
          }
        },
        "graphSettings": {
          "type": 0
        },
        "mapSettings": {
          "itemColorSettings": {
            "colorAggregation": "Sum",
            "heatmapPalette": "greenRed",
            "nodeColorField": "ValidPercentage",
            "type": "heatmap"
          },
          "legendAggregation": "Sum",
          "legendMetric": "ValidPercentage",
          "locInfo": "LatLong",
          "sizeAggregation": "Sum",
          "sizeSettings": "ValidPercentage"
        }
      },
      "customWidth": "20",
      "showPin": true,
      "name": "Overall Success Rate",
      "styleSettings": {
        "margin": "20px",
        "padding": "10px",
        "showBorder": true
      }
    },
    {
      "type": 10,
      "content": {
        "chartId": "workbook5aa10f65-cec7-4469-a734-ed089fac8ad2",
        "version": "MetricsItem/2.0",
        "size": 1,
        "chartType": -1,
        "resourceType": "microsoft.insights/components",
        "metricScope": 0,
        "resourceIds": [
          "${appi-id}"
        ],
        "timeContextFromParameter": "TimeRange",
        "timeContext": {
          "durationMs": 86400000
        },
        "metrics": [
          {
            "namespace": "microsoft.insights/components/kusto",
            "metric": "microsoft.insights/components/kusto-Availability-availabilityResults/availabilityPercentage",
            "aggregation": 4,
            "columnName": "Availability Percentage"
          }
        ],
        "title": "Overall Availability",
        "gridFormatType": 1,
        "tileSettings": {
          "leftContent": {
            "columnMatch": "Value",
            "formatOptions": {
              "max": 100,
              "min": 0.01,
              "palette": "redGreen"
            },
            "formatter": 12,
            "numberFormat": {
              "options": {
                "maximumFractionDigits": 2,
                "maximumSignificantDigits": 3,
                "style": "decimal"
              },
              "unit": 1
            }
          },
          "showBorder": false,
          "sortOrderField": 2,
          "titleContent": {
            "columnMatch": "Name",
            "formatOptions": {
              "linkTarget": "Resource",
              "showIcon": true
            },
            "formatter": 13
          }
        },
        "gridSettings": {
          "formatters": [
            {
              "columnMatch": "Subscription",
              "formatter": 5
            },
            {
              "columnMatch": "Name",
              "formatOptions": {
                "linkTarget": "Resource"
              },
              "formatter": 13
            },
            {
              "columnMatch": "Metric",
              "formatter": 1
            },
            {
              "columnMatch": "Aggregation",
              "formatter": 5
            },
            {
              "columnMatch": "Value",
              "formatter": 1
            },
            {
              "columnMatch": "Timeline",
              "formatter": 9
            }
          ],
          "rowLimit": 10000
        }
      },
      "customWidth": "20",
      "showPin": true,
      "name": "Overall Availability",
      "styleSettings": {
        "margin": "20px",
        "padding": "10px",
        "showBorder": true
      }
    },
    {
      "type": 3,
      "content": {
        "version": "KqlItem/1.0",
        "query": "let min_t = {TimeRange:start};\r\nlet max_t = now();\r\nlet dt = {TimeRange:grain};\r\ntraces\r\n| where timestamp {TimeRange}\r\n| order by timestamp asc\r\n| summarize ReceivedCount = count() , ValidCount = countif(customDimensions.LogLevel != \"Error\") by timestamp\r\n| extend ValidPercentage = toreal(ValidCount) / toreal(ReceivedCount) * 100.0\r\n| make-series SuccessPercentage=avg(ValidPercentage) default = 0 on timestamp from min_t to max_t step dt\r\n| render timechart",
        "size": 0,
        "aggregation": 3,
        "title": "Success Rate Trend",
        "timeContextFromParameter": "TimeRange",
        "queryType": 0,
        "resourceType": "microsoft.insights/components",
        "chartSettings": {
          "ySettings": {
            "numberFormatSettings": {
              "options": {
                "maximumFractionDigits": 2,
                "style": "decimal",
                "useGrouping": true
              },
              "unit": 1
            }
          }
        }
      },
      "customWidth": "50",
      "showPin": true,
      "name": "Success Rate Trend",
      "styleSettings": {
        "margin": "10px",
        "padding": "10px",
        "showBorder": true
      }
    },
    {
      "type": 12,
      "content": {
        "version": "NotebookGroup/1.0",
        "groupType": "editable",
        "title": "Summary",
        "expandable": true,
        "loadType": "always",
        "items": [
          {
            "type": 3,
            "content": {
              "version": "KqlItem/1.0",
              "query": "let postiChanges = traces\n| where timestamp {TimeRange}\n| where operation_Name == \"FetchRegistryChanges\" and  message has \"Clm Updater posti changes request body\"\n| order by timestamp asc;\nlet totalUsers = postiChanges\n| extend parsedProp = parse_json(trim_start(\"Clm Updater posti changes request body\\nJson Body: \", message)) \n| mv-expand parsedProp\n| project timestamp, parsedProp, Status = \"Total Users\";\nlet identifiedUsers = totalUsers\n| where parsedProp.WasIdentified == true\n| project timestamp, Status = \"Identified\";\nlet addressChangeUsers = totalUsers\n| where parsedProp.WasAddressChanged == true\n| project timestamp, Status = \"Address Changed\";\nlet foreignAddressChangeUsers = totalUsers\n| where parsedProp.WasForeignAddressChanged == true\n| project timestamp, Status = \"Foreign Address Changed\";\nlet nameChangeUsers = totalUsers\n| where parsedProp.WasNameChanged == true\n| project timestamp, Status = \"Name Changed\";\nlet deceasedUsers = totalUsers\n| where parsedProp.IsDeceased == true\n| project timestamp, Status = \"Deceased\";\nlet minorUsers = totalUsers\n| where parsedProp.IsMinor == true\n| project timestamp, Status = \"Minor\";\nlet duplicateUsers = totalUsers\n| where parsedProp.IsMinor == true\n| project timestamp, Status = \"Duplicate\";\nlet min_t = startofday({TimeRange:start});\nlet max_t = startofday(now(+1d));\nlet dt = {TimeRange:grain};\ntotalUsers | union identifiedUsers, addressChangeUsers, deceasedUsers, nameChangeUsers, foreignAddressChangeUsers, minorUsers, duplicateUsers\n| make-series count() default = 0 on timestamp from min_t to max_t step dt by Status\n| render  barchart",
              "size": 0,
              "title": "Posti Response Summary",
              "queryType": 0,
              "resourceType": "microsoft.insights/components",
              "gridSettings": {
                "formatters": [
                  {
                    "columnMatch": "Count",
                    "formatOptions": {
                      "min": 0,
                      "palette": "blue"
                    },
                    "formatter": 8
                  },
                  {
                    "columnMatch": "Success_Rate",
                    "formatOptions": {
                      "compositeBarSettings": {
                        "columnSettings": [],
                        "labelText": ""
                      },
                      "max": 100,
                      "min": 0,
                      "palette": "redGreen"
                    },
                    "formatter": 8
                  },
                  {
                    "columnMatch": "Mean|Median|p95",
                    "formatOptions": {
                      "max": 20000,
                      "min": 0,
                      "palette": "greenRed"
                    },
                    "formatter": 8
                  }
                ]
              }
            },
            "customWidth": "50",
            "showPin": true,
            "name": "Posti Response Summary",
            "styleSettings": {
              "showBorder": true
            }
          },
          {
            "type": 3,
            "content": {
              "version": "KqlItem/1.0",
              "query": "\r\nlet customerRequests = traces\r\n| where timestamp {TimeRange}\r\n| where operation_Name != \"\" or severityLevel > 1\r\n| where customDimensions.prop__Uri matches regex \"https://api-dev|api.kesko.fi/clm-b2b-proxy/v1/b2b/profile/ext/customers\" and message  startswith \"End processing HTTP request after\"\r\n| project timestamp, customDimensions, Status = \"Total Requests\";\r\nlet updateRequests = customerRequests\r\n| where customDimensions.[\"prop__HttpMethod\"] in (\"PATCH\")\r\n| where toint(customDimensions.prop__StatusCode) in (200, 201, 204)\r\n| project timestamp, Status = \"CustomerUpdateRequests\";\r\nlet assignmentAdditionRequests = customerRequests\r\n| where customDimensions.prop__Uri has \"assignments\" and customDimensions.[\"prop__HttpMethod\"] in (\"POST\") and toint(customDimensions.prop__StatusCode) in (200, 201, 204)\r\n| project timestamp, Status = \"AssignmentAdditionRequests\";\r\nlet assignmentUpdateRequests = customerRequests\r\n| where customDimensions.prop__Uri has \"assignments\" and customDimensions.[\"prop__HttpMethod\"] in (\"PUT\")\r\n| where toint(customDimensions.prop__StatusCode) in (200, 201, 204)\r\n| project timestamp, Status = \"AssignmentUpdateRequests\";\r\nlet min_t = startofday({TimeRange:start});\r\nlet max_t = startofday(now(+1d));\r\nlet dt = {TimeRange:grain};\r\ncustomerRequests | union updateRequests, assignmentAdditionRequests, assignmentUpdateRequests\r\n| make-series count() default = 0 on timestamp from min_t to max_t step dt by Status\r\n| render  barchart",
              "size": 0,
              "title": "CLM Updater - Customer Requests summary",
              "queryType": 0,
              "resourceType": "microsoft.insights/components",
              "gridSettings": {
                "formatters": [
                  {
                    "columnMatch": "Count",
                    "formatOptions": {
                      "palette": "blue"
                    },
                    "formatter": 8
                  },
                  {
                    "columnMatch": "Success_Rate",
                    "formatOptions": {
                      "max": 100,
                      "min": 0,
                      "palette": "redGreen"
                    },
                    "formatter": 8
                  },
                  {
                    "columnMatch": "Mean|Median|p95|p90|p99",
                    "formatOptions": {
                      "max": 20000,
                      "min": 0,
                      "palette": "greenRed"
                    },
                    "formatter": 8
                  }
                ]
              },
              "sortBy": []
            },
            "customWidth": "50",
            "showPin": true,
            "name": "CLM Updater - Customer Requests summary",
            "styleSettings": {
              "showBorder": true
            }
          },
          {
            "type": 3,
            "content": {
              "version": "KqlItem/1.0",
              "query": "let postiChanges = traces\r\n| where timestamp {TimeRange}\r\n| where operation_Name == \"BuildAndSendNewBatch\" and  message has \"Sending operations to Posti Integration application for registry update.\"\r\n| order by timestamp asc;\r\nlet totalUsers = postiChanges\r\n| extend parsedProp = parse_json(trim_start(\"Sending operations to Posti Integration application for registry update.\\nPayload: \", message)) \r\n| mv-expand parsedProp\r\n| project timestamp, parsedProp, Status = \"Total Users\";\r\nlet newUsers = totalUsers\r\n| where parsedProp.Operation == \"Add\"\r\n| project timestamp, Status = \"New Users\";\r\nlet modifiedUsers = totalUsers\r\n| where parsedProp.Operation == \"Modify\"\r\n| project timestamp, Status = \"Modify Users\";\r\nlet removedUsers = totalUsers\r\n| where parsedProp.Operation == \"Remove\"\r\n| project timestamp, Status = \"Removed Users\";\r\nlet min_t = startofday({TimeRange:start});\r\nlet max_t = startofday(now(+1d));\r\nlet dt = {TimeRange:grain};\r\ntotalUsers | union newUsers, modifiedUsers, removedUsers\r\n| make-series count() default = 0 on timestamp from min_t to max_t step dt by Status\r\n| render  barchart    ",
              "size": 0,
              "title": "CLM Events To Posti Summary",
              "queryType": 0,
              "resourceType": "microsoft.insights/components",
              "gridSettings": {
                "formatters": [
                  {
                    "columnMatch": "Count",
                    "formatOptions": {
                      "palette": "blue"
                    },
                    "formatter": 8
                  },
                  {
                    "columnMatch": "Success_Rate",
                    "formatOptions": {
                      "max": 100,
                      "min": 0,
                      "palette": "redGreen"
                    },
                    "formatter": 8
                  },
                  {
                    "columnMatch": "Mean|Median|p95|p90|p99",
                    "formatOptions": {
                      "max": 20000,
                      "min": 0,
                      "palette": "greenRed"
                    },
                    "formatter": 8
                  }
                ]
              },
              "sortBy": []
            },
            "customWidth": "50",
            "showPin": true,
            "name": "CLM Events To Posti Summary",
            "styleSettings": {
              "showBorder": true
            }
          }
        ]
      },
      "name": "Summary",
      "styleSettings": {
        "margin": "20px",
        "showBorder": true
      }
    },
    {
      "type": 12,
      "content": {
        "version": "NotebookGroup/1.0",
        "groupType": "editable",
        "title": "Posti Data",
        "expandable": true,
        "items": [
          {
            "type": 3,
            "content": {
              "version": "KqlItem/1.0",
              "query": "traces\n| where timestamp {TimeRange}\n| where operation_Name == \"FetchRegistryChanges\" and  message has \"Clm Updater posti changes request body\"\n| extend parsedProp = trim_start(\"Clm Updater posti changes request body\\nJson Body: \", message)\n| project UserCount = countof(parsedProp, \"CustomerNumber\"), Timestamp = timestamp, ProcessedDate = format_datetime(timestamp, 'yyyy-MM-dd'), PostiResponseSummary = parsedProp\n| sort by Timestamp desc ",
              "size": 0,
              "title": "Posti Response Data",
              "queryType": 0,
              "resourceType": "microsoft.insights/components",
              "gridSettings": {
                "formatters": [
                  {
                    "columnMatch": "Count",
                    "formatOptions": {
                      "aggregation": "Sum",
                      "min": 0,
                      "palette": "blue"
                    },
                    "formatter": 8
                  },
                  {
                    "columnMatch": "ProcessedDate",
                    "formatter": 5
                  }
                ],
                "rowLimit": 80,
                "hierarchySettings": {
                  "expandTopLevel": false,
                  "groupBy": [
                    "ProcessedDate"
                  ],
                  "treeType": 1
                }
              }
            },
            "customWidth": "50",
            "showPin": true,
            "name": "Posti Response Data",
            "styleSettings": {
              "showBorder": true
            }
          },
          {
            "type": 3,
            "content": {
              "version": "KqlItem/1.0",
              "query": "traces\n|where timestamp {TimeRange}\n| where operation_Name == \"BuildAndSendNewBatch\" and  message has \"Sending operations to Posti Integration application for registry update.\"\n| extend parsedProp = trim_start(\"Sending operations to Posti Integration application for registry update.\\nPayload: \", message)\n| project UserCount = countof(parsedProp, \"CustomerNumber\"), Timestamp = timestamp, ProcessedDate = format_datetime(timestamp, 'yyyy-MM-dd'), CLMEventToPostiSummary = parsedProp\n| sort by Timestamp desc ",
              "size": 0,
              "title": "CLM events to Posti Data",
              "queryType": 0,
              "resourceType": "microsoft.insights/components",
              "gridSettings": {
                "formatters": [
                  {
                    "columnMatch": "Count",
                    "formatOptions": {
                      "aggregation": "Sum",
                      "min": 0,
                      "palette": "blue"
                    },
                    "formatter": 8
                  },
                  {
                    "columnMatch": "ProcessedDate",
                    "formatter": 5
                  }
                ],
                "rowLimit": 80,
                "hierarchySettings": {
                  "expandTopLevel": false,
                  "groupBy": [
                    "ProcessedDate"
                  ],
                  "treeType": 1
                }
              }
            },
            "customWidth": "50",
            "showPin": true,
            "name": "CLM events to Posti Data",
            "styleSettings": {
              "showBorder": true
            }
          },
          {
            "type": 3,
            "content": {
              "version": "KqlItem/1.0",
              "query": "traces\r\n| where timestamp {TimeRange}\r\n| where message startswith \"Clm request failed\"\r\n| extend strObj = message,errorObj = parse_json(tostring(split(message, \"Response message: \")[1]))\r\n| project ErrorCount = countof(strObj, \"Clm request failed\"), Date = format_datetime(timestamp, 'yyyy-MM-dd'), Error_Type = errorObj.error, URL = split(errorObj.path, 'b2b')[1], Error_Code = errorObj.status\r\n| sort by Date desc \r\n",
              "size": 0,
              "title": "CLM Updater - Failed Requests",
              "timeContextFromParameter": "TimeRange",
              "queryType": 0,
              "resourceType": "microsoft.insights/components",
              "gridSettings": {
                "formatters": [
                  {
                    "columnMatch": "$gen_group",
                    "formatOptions": {
                      "customColumnWidthSetting": "20%",
                      "palette": "blue"
                    },
                    "formatter": 8
                  },
                  {
                    "columnMatch": "Count",
                    "formatOptions": {
                      "aggregation": "Sum",
                      "palette": "orangeRed"
                    },
                    "formatter": 8
                  },
                  {
                    "columnMatch": "Error_Type",
                    "formatOptions": {
                      "customColumnWidthSetting": "15%"
                    },
                    "formatter": 0
                  },
                  {
                    "columnMatch": "URL",
                    "formatOptions": {
                      "customColumnWidthSetting": "25%"
                    },
                    "formatter": 0
                  },
                  {
                    "columnMatch": "Error_Code",
                    "formatOptions": {
                      "max": 600,
                      "min": 400,
                      "palette": "orangeRed"
                    },
                    "formatter": 8
                  },
                  {
                    "columnMatch": "Success_Rate",
                    "formatOptions": {
                      "max": 100,
                      "min": 0,
                      "palette": "redGreen"
                    },
                    "formatter": 8
                  }
                ],
                "rowLimit": 1500,
                "hierarchySettings": {
                  "groupBy": [
                    "Date",
                    "Error_Type"
                  ],
                  "treeType": 1
                }
              },
              "sortBy": []
            },
            "customWidth": "50",
            "showPin": true,
            "name": "CLM Updater - Failed Requests",
            "styleSettings": {
              "showBorder": true
            }
          }
        ]
      },
      "name": "Posti Data",
      "styleSettings": {
        "margin": "20px",
        "showBorder": true
      }
    },
    {
      "type": 12,
      "content": {
        "version": "NotebookGroup/1.0",
        "groupType": "editable",
        "title": "Events processing results",
        "expandable": true,
        "loadType": "always",
        "items": [
          {
            "type": 3,
            "content": {
              "version": "KqlItem/1.0",
              "query": "let lifecycleEvents = traces\r\n| where timestamp {TimeRange}\r\n| where operation_Name == \"ReceiveLifecycleEvent\"\r\n| order by timestamp asc;\r\nlet receivedEvents = lifecycleEvents\r\n| where message has \"Received event from customer life cycle hub\"\r\n| project timestamp, Status = \"Received\";\r\nlet successfulEvents = lifecycleEvents\r\n| where message has \"Begin storing of operation document\" or message has \"Storing of new operations is disabled\"\r\n| project timestamp, Status = \"Success\";\r\nlet invalidEvents = lifecycleEvents\r\n| where message has \"Begin storing of invalid data document\" or message has \"Storage of invalid data is disabled\"\r\n| project timestamp, Status = \"Invalid\";\r\nlet unsupportedEvents = lifecycleEvents\r\n| where message has \"Received unsupported event\"\r\n| project timestamp, Status = \"Unsupported\";\r\nlet unexpectedErrors = lifecycleEvents\r\n| where message has \"Unexpected error while receiving event\"\r\n| project timestamp, Status = \"Error\";\r\nlet min_t = {TimeRange:start};\r\nlet max_t = now();\r\nlet dt = 15m;\r\nreceivedEvents | union successfulEvents, invalidEvents, unsupportedEvents, unexpectedErrors\r\n| make-series count() default = 0 on timestamp from min_t to max_t step dt by Status\r\n| render timechart",
              "size": 0,
              "title": "Customer Lifecycle events processing results",
              "queryType": 0,
              "resourceType": "microsoft.insights/components",
              "chartSettings": {
                "seriesLabelSettings": [
                  {
                    "color": "red",
                    "seriesName": "Error"
                  },
                  {
                    "color": "green",
                    "seriesName": "Success"
                  },
                  {
                    "color": "orange",
                    "seriesName": "Invalid"
                  },
                  {
                    "color": "blue",
                    "seriesName": "Received"
                  },
                  {
                    "color": "gray",
                    "seriesName": "Unsupported"
                  }
                ],
                "xAxis": "timestamp"
              }
            },
            "customWidth": "50",
            "showPin": true,
            "name": "Customer Lifecycle request",
            "styleSettings": {
              "showBorder": true
            }
          },
          {
            "type": 3,
            "content": {
              "version": "KqlItem/1.0",
              "query": "let lifecycleEvents = traces\r\n| where timestamp {TimeRange}\r\n| where operation_Name == \"ReceiveUpdateEvent\"\r\n| order by timestamp asc;\r\nlet receivedEvents = lifecycleEvents\r\n| where message has \"Received event from customer update hub\"\r\n| project timestamp, Status = \"Received\";\r\nlet successfulEvents = lifecycleEvents\r\n| where message has \"Begin storing of operation document\" or message has \"Storing of new operations is disabled\"\r\n| project timestamp, Status = \"Success\";\r\nlet invalidEvents = lifecycleEvents\r\n| where message has \"Begin storing of invalid data document\" or message has \"Storage of invalid data is disabled\"\r\n| project timestamp, Status = \"Invalid\";\r\nlet unsupportedEvents = lifecycleEvents\r\n| where message has \"Received unsupported event\"\r\n| project timestamp, Status = \"Unsupported\";\r\nlet unexpectedErrors = lifecycleEvents\r\n| where message has \"Unexpected error while receiving event\"\r\n| project timestamp, Status = \"Error\";\r\nlet min_t = {TimeRange:start};\r\nlet max_t = now();\r\nlet dt = 15m;\r\nreceivedEvents | union successfulEvents, invalidEvents, unsupportedEvents, unexpectedErrors\r\n| make-series count() default = 0 on timestamp from min_t to max_t step dt by Status\r\n| render timechart",
              "size": 0,
              "title": "Customer Basic Data Update events processing results",
              "queryType": 0,
              "resourceType": "microsoft.insights/components",
              "chartSettings": {
                "seriesLabelSettings": [
                  {
                    "color": "red",
                    "seriesName": "Error"
                  },
                  {
                    "color": "green",
                    "seriesName": "Success"
                  },
                  {
                    "color": "orange",
                    "seriesName": "Invalid"
                  },
                  {
                    "color": "blue",
                    "seriesName": "Received"
                  },
                  {
                    "color": "gray",
                    "seriesName": "Unsupported"
                  }
                ],
                "xAxis": "timestamp"
              }
            },
            "customWidth": "50",
            "showPin": true,
            "name": "CUSTOMER_BASIC_INFORMATION_UPDATED Event request",
            "styleSettings": {
              "showBorder": true
            }
          }
        ]
      },
      "name": "Events processing results",
      "styleSettings": {
        "margin": "20px",
        "showBorder": true
      }
    },
    {
      "type": 12,
      "content": {
        "version": "NotebookGroup/1.0",
        "groupType": "editable",
        "title": "Performance Group",
        "expandable": true,
        "items": [
          {
            "type": 3,
            "content": {
              "version": "KqlItem/1.0",
              "query": "\r\nlet customerRequests = traces\r\n| where timestamp {TimeRange}\r\n| where operation_Name != \"\" or severityLevel > 1\r\n| where customDimensions.prop__Uri matches regex \"https://api-dev|api.kesko.fi/clm-b2b-proxy/v1/b2b/profile/ext/customers/\\\\d+$\" and message  startswith \"End processing HTTP request after\";\r\n\r\nlet data = customerRequests\r\n| summarize Mean = avg(todouble(customDimensions.[\"prop__ElapsedMilliseconds\"])), (Median, p90, p95, p99) = percentiles(todouble(customDimensions.prop__ElapsedMilliseconds), 50, 90, 95, 99), Count = count(), Successes = sum(toint(customDimensions.prop__StatusCode) == 200 or toint(customDimensions.prop__StatusCode) == 201 or toint(customDimensions.prop__StatusCode) == 204) by Msg = tostring(customDimensions.[\"prop__OriginalFormat\"]), Method = tostring(customDimensions.[\"prop__HttpMethod\"])\r\n| project HttpMethod = Method, Successes = Successes, Mean, Median, p90, p95, p99, Count, rank = 2\r\n| union (customerRequests\r\n    | summarize Mean = avg(todouble(customDimensions.[\"prop__ElapsedMilliseconds\"])), (Median, p90, p95, p99) = percentiles(todouble(customDimensions.[\"prop__ElapsedMilliseconds\"]), 50, 90, 95, 99), Count = count(), Successes = sum(toint(customDimensions.prop__StatusCode) == 200 or toint(customDimensions.prop__StatusCode) == 201 or toint(customDimensions.prop__StatusCode) == 204)\r\n    | project HttpMethod = '🔸 All Http methods', Successes = Successes, Mean, Median, p90, p95, p99, Count, rank = 1);\r\n\r\ndata\r\n| extend Relevance = Mean * Count, Success_Rate = (toreal(Successes) / toreal(Count)) * 100\r\n| sort by rank asc, Relevance desc\r\n| project-away Relevance, rank, Successes\r\n| extend Success_Rate = round(Success_Rate, 2), Mean = round(Mean, 2), Median = round(Median, 2), p90 = round(p90, 2), p95 = round(p95, 2), p99 = round(p99, 2)\r\n| project HttpMethod, Count, Success_Rate, Mean, Median, p90, p95, p99\r\n| render table\r\n",
              "size": 0,
              "title": "CLM Updater - Customer Requests performance",
              "queryType": 0,
              "resourceType": "microsoft.insights/components",
              "gridSettings": {
                "formatters": [
                  {
                    "columnMatch": "Count",
                    "formatOptions": {
                      "palette": "blue"
                    },
                    "formatter": 8
                  },
                  {
                    "columnMatch": "Success_Rate",
                    "formatOptions": {
                      "max": 100,
                      "min": 0,
                      "palette": "redGreen"
                    },
                    "formatter": 8
                  },
                  {
                    "columnMatch": "Mean|Median|p95|p90|p99",
                    "formatOptions": {
                      "max": 5000,
                      "min": 0,
                      "palette": "greenRed"
                    },
                    "formatter": 8
                  }
                ],
                "sortBy": [
                  {
                    "itemKey": "HttpMethod",
                    "sortOrder": 1
                  }
                ],
                "labelSettings": [
                  {
                    "columnId": "HttpMethod",
                    "label": "Http Method"
                  },
                  {
                    "columnId": "Count",
                    "label": "Total Requests Count"
                  },
                  {
                    "columnId": "Success_Rate",
                    "label": "Successful Requests"
                  },
                  {
                    "columnId": "Mean",
                    "label": "Avg Duration(ms)"
                  },
                  {
                    "columnId": "Median",
                    "label": "Median Duration(ms)"
                  },
                  {
                    "columnId": "p90",
                    "label": "90% Duration(ms)"
                  },
                  {
                    "columnId": "p95",
                    "label": "95% Duration(ms)"
                  },
                  {
                    "columnId": "p99",
                    "label": "99% Duration(ms)"
                  }
                ]
              },
              "sortBy": [
                {
                  "itemKey": "HttpMethod",
                  "sortOrder": 1
                }
              ]
            },
            "customWidth": "50",
            "showPin": true,
            "name": "CLM Updater - Customer Requests performance",
            "styleSettings": {
              "showBorder": true
            }
          },
          {
            "type": 3,
            "content": {
              "version": "KqlItem/1.0",
              "query": "let customerRequests = traces\r\n| where timestamp {TimeRange}\r\n| where operation_Name != \"\" or severityLevel > 1\r\n| where (customDimensions.prop__Uri matches regex  \"^https://api-dev|api.kesko.fi/clm-b2b-proxy/v1/b2b/profile/ext/customers/\\\\d+/assignments$\" or customDimensions.prop__Uri matches regex  \"^https://api-dev|api.kesko.fi/clm-b2b-proxy/v1/b2b/profile/ext/customers/\\\\d+/assignments/\\\\d+$\") and message  startswith \"End processing HTTP request after\";\r\n\r\nlet data = customerRequests\r\n| summarize Mean = avg(todouble(customDimensions.[\"prop__ElapsedMilliseconds\"])), (Median, p90, p95, p99) = percentiles(todouble(customDimensions.prop__ElapsedMilliseconds), 50, 90, 95, 99), Count = count(), Successes = sum(toint(customDimensions.prop__StatusCode) == 200 or toint(customDimensions.prop__StatusCode) == 201 or toint(customDimensions.prop__StatusCode) == 204) by Msg = tostring(customDimensions.[\"prop__OriginalFormat\"]), Method = tostring(customDimensions.[\"prop__HttpMethod\"])\r\n| project HttpMethod = Method, Successes = Successes, Mean, Median, p90, p95, p99, Count, rank = 2\r\n| union (customerRequests\r\n    | summarize Mean = avg(todouble(customDimensions.[\"prop__ElapsedMilliseconds\"])), (Median, p90, p95, p99) = percentiles(todouble(customDimensions.[\"prop__ElapsedMilliseconds\"]), 50, 90, 95, 99), Count = count(), Successes = sum(toint(customDimensions.prop__StatusCode) == 200 or toint(customDimensions.prop__StatusCode) == 201 or toint(customDimensions.prop__StatusCode) == 204)\r\n    | project HttpMethod = '🔸 All Http methods', Successes = Successes, Mean, Median, p90, p95, p99, Count, rank = 1);\r\n\r\ndata\r\n| extend Relevance = Mean * Count, Success_Rate = (toreal(Successes) / toreal(Count)) * 100\r\n| sort by rank asc, Relevance desc\r\n| project-away Relevance, rank, Successes\r\n| extend Success_Rate = round(Success_Rate, 2), Mean = round(Mean, 2), Median = round(Median, 2), p90 = round(p90, 2), p95 = round(p95, 2), p99 = round(p99, 2)\r\n| project HttpMethod, Count, Success_Rate, Mean, Median, p90, p95, p99\r\n| render table",
              "size": 0,
              "title": "CLM Updater - Assignment Requests performance",
              "queryType": 0,
              "resourceType": "microsoft.insights/components",
              "gridSettings": {
                "formatters": [
                  {
                    "columnMatch": "Count",
                    "formatOptions": {
                      "palette": "blue"
                    },
                    "formatter": 8
                  },
                  {
                    "columnMatch": "Success_Rate",
                    "formatOptions": {
                      "max": 100,
                      "min": 0,
                      "palette": "redGreen"
                    },
                    "formatter": 8
                  },
                  {
                    "columnMatch": "Mean|Median|p95|p90|p99",
                    "formatOptions": {
                      "max": 5000,
                      "min": 0,
                      "palette": "greenRed"
                    },
                    "formatter": 8
                  }
                ],
                "rowLimit": 80,
                "sortBy": [
                  {
                    "itemKey": "HttpMethod",
                    "sortOrder": 1
                  }
                ],
                "labelSettings": [
                  {
                    "columnId": "HttpMethod",
                    "label": "Http Method"
                  },
                  {
                    "columnId": "Count",
                    "label": "Total Requests Count"
                  },
                  {
                    "columnId": "Success_Rate",
                    "label": "Successful Requests"
                  },
                  {
                    "columnId": "Mean",
                    "label": "Avg Duration(ms)"
                  },
                  {
                    "columnId": "Median",
                    "label": "Median Duration(ms)"
                  },
                  {
                    "columnId": "p90",
                    "label": "90% Duration(ms)"
                  },
                  {
                    "columnId": "p95",
                    "label": "95% Duration(ms)"
                  },
                  {
                    "columnId": "p99",
                    "label": "99% Duration(ms)"
                  }
                ]
              },
              "sortBy": [
                {
                  "itemKey": "HttpMethod",
                  "sortOrder": 1
                }
              ]
            },
            "customWidth": "50",
            "showPin": true,
            "name": "CLM Updater - Assignment Requests performance",
            "styleSettings": {
              "showBorder": true
            }
          },
          {
            "type": 3,
            "content": {
              "version": "KqlItem/1.0",
              "query": "let http_function_requests = requests\n    | where timestamp > ago(7d)\n        and name != \"ReceiveUpdateEvent\"\n        and name != \"ReceiveLifecycleEvent\";\nlet data = http_function_requests\n    | summarize\n        Mean = avg(duration),\n        (Median, p90, p95, p99) = percentiles(duration, 50, 90, 95, 99),\n        Count = count(),\n        Successes = sum(resultCode == 200) + sum(resultCode == 202) + sum(resultCode == 204) + sumif(resultCode==0, success==\"True\")\n        by name, cloud_RoleName\n    | project\n        App = cloud_RoleName,\n        Function = name,\n        Successes = Successes,\n        Mean,\n        Median,\n        p90,\n        p95,\n        p99,\n        Count,\n        rank = 2\n    | union (http_function_requests\n        | summarize\n            Mean = avg(duration),\n            (Median, p90, p95, p99) = percentiles(duration, 50, 90, 95, 99),\n            Count = count(),\n            Successes = sum(resultCode == 200) + sum(resultCode == 202) + sum(resultCode == 204) + sumif(resultCode==0, success==\"True\")\n        | project\n            App = '🔸 All Apps',\n            Function = '🔸 All Functions',\n            Successes = Successes,\n            Mean,\n            Median,\n            p90,\n            p95,\n            p99,\n            Count,\n            rank = 1);\ndata\n| extend\n    Relevance = Mean * Count,\n    Success_Rate = (toreal(Successes) / toreal(Count)) * 100\n| sort by rank asc, Relevance desc\n| project-away Relevance, rank, Successes\n| extend\n    Success_Rate = round(Success_Rate, 2),\n    Mean = round(Mean, 2),\n    Median = round(Median, 2),\n    p90 = round(p90, 2),\n    p95 = round(p95, 2),\n    p99 = round(p99, 2)\n| project App, Function, Count, Success_Rate, Mean, Median, p90, p95, p99\n| render table",
              "size": 0,
              "title": "Functions Performance",
              "queryType": 0,
              "resourceType": "microsoft.insights/components",
              "gridSettings": {
                "formatters": [
                  {
                    "columnMatch": "Count",
                    "formatOptions": {
                      "min": 0,
                      "palette": "blue"
                    },
                    "formatter": 8
                  },
                  {
                    "columnMatch": "Success_Rate",
                    "formatOptions": {
                      "compositeBarSettings": {
                        "columnSettings": [],
                        "labelText": ""
                      },
                      "max": 100,
                      "min": 0,
                      "palette": "redGreen"
                    },
                    "formatter": 8
                  },
                  {
                    "columnMatch": "Mean|Median|p95|p90|p99",
                    "formatOptions": {
                      "max": 10000,
                      "min": 0,
                      "palette": "greenRed"
                    },
                    "formatter": 8
                  }
                ],
                "labelSettings": [
                  {
                    "columnId": "App",
                    "label": "App"
                  },
                  {
                    "columnId": "Function",
                    "label": "Function"
                  },
                  {
                    "columnId": "Count",
                    "label": "Requests"
                  },
                  {
                    "columnId": "Success_Rate",
                    "comment": "",
                    "label": "Success(%)"
                  },
                  {
                    "columnId": "Mean",
                    "label": "Avg Duration(ms)"
                  },
                  {
                    "columnId": "Median",
                    "label": "Median Duration(ms)"
                  },
                  {
                    "columnId": "p90",
                    "label": "90% Duration(ms)"
                  },
                  {
                    "columnId": "p95",
                    "label": "95% Duration(ms)"
                  },
                  {
                    "columnId": "p99",
                    "label": "99% Duration(ms)"
                  }
                ]
              }
            },
            "customWidth": "50",
            "showPin": true,
            "name": "Functions Performance",
            "styleSettings": {
              "showBorder": true
            }
          },
          {
            "type": 3,
            "content": {
              "version": "KqlItem/1.0",
              "query": "let callsOfInterest = dependencies\r\n| where timestamp {TimeRange} and type == \"Azure DocumentDB\" and name in (\r\n\"StoreInvalidData\", \"GetAllBatches\", \"DeleteBatch\", \"GetOperationsByBatchId\", \"GetAllOperations\", \"StoreOperation\",\r\n\"GetAllInvalidData\", \"DeleteInvalidData\", \"DeleteOperation\", \"StoreBatch\", \"GetAllClmUpdateErrors\", \"DeletePostiError\",\r\n\"StoreClmError\", \"StorePostiError\", \"GetAllPostiErrors\", \"DeletePostiError\", \"StoreFileFetchingError\", \"GetAllFileFetching\",\r\n\"DeleteFileFetchingError\");\r\nlet data = callsOfInterest\r\n| summarize AvgDur = avg(duration), (MedianDur, p90Dur, p95Dur, p99Dur) = percentiles(duration, 50, 90, 95, 99),\r\nAvgCharge = avg(toreal(customDimensions[\"requestCharge\"])), \r\np90Charge = percentile(toreal(customDimensions[\"requestCharge\"]), 90), \r\np95Charge = percentile(toreal(customDimensions[\"requestCharge\"]), 95),\r\np99Charge = percentile(toreal(customDimensions[\"requestCharge\"]), 99),\r\nCount = count(), Successes = sum(success == True) by operation_Name, name\r\n| project Function = operation_Name, OperationName = name, Count, Successes, AvgDur, MedianDur, p90Dur, p95Dur, p99Dur, AvgCharge, p90Charge, p95Charge, p99Charge, rank = 2\r\n| union (callsOfInterest\r\n    | summarize AvgDur = avg(duration), (MedianDur, p90Dur, p95Dur, p99Dur) = percentiles(duration, 50, 90, 95, 99),\r\n    AvgCharge = avg(toreal(customDimensions[\"requestCharge\"])), \r\n    p90Charge = percentile(toreal(customDimensions[\"requestCharge\"]), 90), \r\n    p95Charge = percentile(toreal(customDimensions[\"requestCharge\"]), 95),\r\n    p99Charge = percentile(toreal(customDimensions[\"requestCharge\"]), 99),\r\n    Count = count(), Successes = sum(success == True)\r\n    | project Function = '🔸 All Functions', OperationName = '🔸 All Operations', Count, Successes, AvgDur, MedianDur, p90Dur, p95Dur, p99Dur, AvgCharge, p90Charge, p95Charge, p99Charge, rank = 1);\r\ndata\r\n| extend Success_Rate = (toreal(Successes) / toreal(Count)) * 100\r\n| sort by rank asc, Function desc, OperationName desc\r\n| project-away rank, Successes\r\n| extend Success_Rate = round(Success_Rate, 2), AvgDur = round(AvgDur, 2), MedianDur = round(MedianDur, 2), \r\n    p90Dur = round(p90Dur, 2), p95Dur = round(p95Dur, 2), p99Dur = round(p99Dur, 2),\r\n    AvgCharge = round(AvgCharge, 2), \r\n    p90Charge = round(p90Charge, 2), p95Charge = round(p95Charge, 2), p99Charge = round(p99Charge, 2)\r\n| project Function, OperationName, Count, Success_Rate, AvgDur, MedianDur, p90Dur, p95Dur, p99Dur, AvgCharge, p90Charge, p95Charge, p99Charge\r\n| render table",
              "size": 0,
              "title": "Cosmos Performance",
              "queryType": 0,
              "resourceType": "microsoft.insights/components",
              "gridSettings": {
                "formatters": [
                  {
                    "columnMatch": "Count",
                    "formatOptions": {
                      "palette": "blue"
                    },
                    "formatter": 8
                  },
                  {
                    "columnMatch": "Success_Rate",
                    "formatOptions": {
                      "max": 100,
                      "min": 90,
                      "palette": "redGreen"
                    },
                    "formatter": 8
                  },
                  {
                    "columnMatch": "AvgDur|MedianDur|p95Dur|p90Dur|p99Dur",
                    "formatOptions": {
                      "max": 5000,
                      "min": 0,
                      "palette": "greenRed"
                    },
                    "formatter": 8
                  },
                  {
                    "columnMatch": "AvgCharge|p95Charge|p90Charge|p99Charge",
                    "formatOptions": {
                      "max": 20,
                      "min": 0,
                      "palette": "greenRed"
                    },
                    "formatter": 8
                  }
                ],
                "labelSettings": [
                  {
                    "columnId": "Function",
                    "label": "Call Source"
                  },
                  {
                    "columnId": "OperationName",
                    "label": "Call Name"
                  },
                  {
                    "columnId": "Count",
                    "label": "Count"
                  },
                  {
                    "columnId": "Success_Rate",
                    "label": "Success(%)"
                  },
                  {
                    "columnId": "AvgDur",
                    "label": "Avg Duration(ms)"
                  },
                  {
                    "columnId": "MedianDur",
                    "label": "Median Duration(ms)"
                  },
                  {
                    "columnId": "p90Dur",
                    "label": "90% Duration(ms)"
                  },
                  {
                    "columnId": "p95Dur",
                    "label": "95% Duration(ms)"
                  },
                  {
                    "columnId": "p99Dur",
                    "label": "99% Duration(ms)"
                  },
                  {
                    "columnId": "AvgCharge",
                    "label": "Avg Charge"
                  },
                  {
                    "columnId": "p90Charge",
                    "label": "90% Charge"
                  },
                  {
                    "columnId": "p95Charge",
                    "label": "95% Charge"
                  },
                  {
                    "columnId": "p99Charge",
                    "label": "99% Charge"
                  }
                ]
              }
            },
            "customWidth": "50",
            "showPin": true,
            "name": "Cosmos Performance",
            "styleSettings": {
              "showBorder": true
            }
          },
          {
            "type": 3,
            "content": {
              "version": "KqlItem/1.0",
              "query": "let sendRequests = traces\r\n| where timestamp {TimeRange}\r\n| where operation_Name != \"\" or severityLevel > 1 \r\n| where cloud_RoleName == \"PostiIntegration\" and operation_Name == \"UpdateRegistry\"\r\n| where customDimensions.prop__Uri has \"https://apigw2.ecosystem.posti.fi/cdupdate/cu/v1/register\" and message startswith \"End processing HTTP request after\";\r\n\r\nlet data = sendRequests\r\n| summarize Mean = avg(todouble(customDimensions.[\"prop__ElapsedMilliseconds\"])), (Median, p90,p95,p99) = percentiles(todouble(customDimensions.prop__ElapsedMilliseconds), 50, 90,95,99), Count = count(), Successes = sum(toint(customDimensions.prop__StatusCode) == 200 or toint(customDimensions.prop__StatusCode) == 201 or toint(customDimensions.prop__StatusCode) == 204) by Msg = tostring(customDimensions.[\"prop__OriginalFormat\"]), Method = tostring(customDimensions.[\"prop__Uri\"])\r\n| project HttpMethod = Method, Successes = Successes, Mean, Median, p90, p95, p99, Count, rank = 2\r\n| union (sendRequests\r\n    | summarize Mean = avg(todouble(customDimensions.[\"prop__ElapsedMilliseconds\"])), (Median, p90,p95,p99) = percentiles(todouble(customDimensions.prop__ElapsedMilliseconds), 50, 90,95,99), Count = count(), Successes = sum(toint(customDimensions.prop__StatusCode) == 200 or toint(customDimensions.prop__StatusCode) == 201 or toint(customDimensions.prop__StatusCode) == 204)\r\n    | project HttpMethod = '🔸 Posti send requests', Successes = Successes, Mean, Median, p90,p95,p99, Count, rank = 1);\r\n\r\ndata\r\n| extend Relevance = Mean * Count, Success_Rate = (toreal(Successes) / toreal(Count)) * 100\r\n| sort by rank asc, Relevance desc\r\n| project-away Relevance, rank, Successes\r\n| extend Success_Rate = round(Success_Rate, 2), Mean = round(Mean, 2), Median = round(Median, 2), p90 = round(p90, 2), p95 = round(p95, 2), p99 = round(p99, 2)\r\n| project HttpMethod, Count, Success_Rate, Mean, Median, p90, p95, p99\r\n| render table",
              "size": 0,
              "title": "Posti Integration - Send Files Requests performance",
              "queryType": 0,
              "resourceType": "microsoft.insights/components",
              "gridSettings": {
                "formatters": [
                  {
                    "columnMatch": "Count",
                    "formatOptions": {
                      "palette": "blue"
                    },
                    "formatter": 8
                  },
                  {
                    "columnMatch": "Success_Rate",
                    "formatOptions": {
                      "max": 100,
                      "min": 0,
                      "palette": "redGreen"
                    },
                    "formatter": 8
                  },
                  {
                    "columnMatch": "Mean|Median|p95|p90|p99",
                    "formatOptions": {
                      "max": 5000,
                      "min": 0,
                      "palette": "greenRed"
                    },
                    "formatter": 8
                  }
                ],
                "sortBy": [
                  {
                    "itemKey": "HttpMethod",
                    "sortOrder": 1
                  }
                ]
              },
              "sortBy": [
                {
                  "itemKey": "HttpMethod",
                  "sortOrder": 1
                }
              ]
            },
            "customWidth": "50",
            "showPin": true,
            "name": "Posti Integration - Send Files Requests performance",
            "styleSettings": {
              "showBorder": true
            }
          },
          {
            "type": 3,
            "content": {
              "version": "KqlItem/1.0",
              "query": "let sendRequests = traces\r\n| where timestamp {TimeRange}\r\n|  where operation_Name != \"\" or severityLevel > 1\r\n| where cloud_RoleName == \"PostiIntegration\" and (operation_Name == \"FetchRegistryChanges\" or operation_Name == \"RefetchFailedRegistryChanges\")\r\n| where customDimensions.prop__Uri has \"https://apigw2.ecosystem.posti.fi/cdupdate/cu/v1/register\" and message startswith \"End processing HTTP request after\";\r\n\r\nlet data = sendRequests\r\n| summarize Mean = avg(todouble(customDimensions.[\"prop__ElapsedMilliseconds\"])), (Median, p90, p95, p99) = percentiles(todouble(customDimensions.prop__ElapsedMilliseconds), 50, 90, 95, 99), Count = count(), Successes = sum(toint(customDimensions.prop__StatusCode) == 200 or toint(customDimensions.prop__StatusCode) == 201 or toint(customDimensions.prop__StatusCode) == 204) by Msg = tostring(customDimensions.[\"prop__OriginalFormat\"]), Method = tostring(customDimensions.[\"prop__Uri\"])\r\n| project PostiRequest = Method, Successes = Successes, Mean, Median,  p90, p95, p99, Count, rank = 2\r\n| union (sendRequests\r\n    | summarize Mean = avg(todouble(customDimensions.[\"prop__ElapsedMilliseconds\"])), (Median,  p90, p95, p99) = percentiles(todouble(customDimensions.[\"prop__ElapsedMilliseconds\"]), 50, 90, 95, 99), Count = count(), Successes = sum(toint(customDimensions.prop__StatusCode) == 200 or toint(customDimensions.prop__StatusCode) == 201 or toint(customDimensions.prop__StatusCode) == 204)\r\n    | project PostiRequest = '🔸 Posti fetch requests', Successes = Successes, Mean, Median,  p90, p95, p99, Count, rank = 1);\r\n\r\ndata\r\n| extend Relevance = Mean * Count, Success_Rate = (toreal(Successes) / toreal(Count)) * 100\r\n| sort by rank asc, Relevance desc\r\n| project-away Relevance, rank, Successes\r\n| extend Success_Rate = round(Success_Rate, 2), Mean = round(Mean, 2), Median = round(Median, 2), p90 = round(p90, 2), p95 = round(p95, 2), p99 = round(p99, 2)\r\n| project PostiRequest, Count, Success_Rate, Mean, Median,  p90, p95, p99\r\n| render table",
              "size": 0,
              "title": "PostiIntegration - Fetch Requests performance",
              "timeContext": {
                "durationMs": 604800000
              },
              "queryType": 0,
              "resourceType": "microsoft.insights/components",
              "gridSettings": {
                "formatters": [
                  {
                    "columnMatch": "Count",
                    "formatOptions": {
                      "palette": "blue"
                    },
                    "formatter": 8
                  },
                  {
                    "columnMatch": "Success_Rate",
                    "formatOptions": {
                      "max": 100,
                      "min": 0,
                      "palette": "redGreen"
                    },
                    "formatter": 8
                  },
                  {
                    "columnMatch": "Mean|Median|p95|p90|p99",
                    "formatOptions": {
                      "max": 3000,
                      "min": 0,
                      "palette": "greenRed"
                    },
                    "formatter": 8
                  }
                ],
                "rowLimit": 80
              },
              "sortBy": []
            },
            "customWidth": "50",
            "showPin": true,
            "name": "PostiInegration - Fetch Requests performance",
            "styleSettings": {
              "showBorder": true
            }
          },
          {
            "type": 10,
            "content": {
              "chartId": "workbookb1b4e482-34c0-4626-bdd3-4ffb55ed3d88",
              "version": "MetricsItem/2.0",
              "size": 0,
              "chartType": 2,
              "resourceType": "microsoft.insights/components",
              "metricScope": 0,
              "resourceIds": [
                "${appi-id}"
              ],
              "timeContextFromParameter": "TimeRange",
              "timeContext": {
                "durationMs": 86400000
              },
              "metrics": [
                {
                  "namespace": "microsoft.insights/components/kusto",
                  "metric": "microsoft.insights/components/kusto-Performance Counters-performanceCounters/processCpuPercentageTotal",
                  "aggregation": 3,
                  "splitBy": "cloud/roleName"
                }
              ],
              "title": "CPU Usage",
              "gridSettings": {
                "formatters": [
                  {
                    "columnMatch": "Subscription",
                    "formatter": 5
                  },
                  {
                    "columnMatch": "Name",
                    "formatOptions": {
                      "linkTarget": "Resource"
                    },
                    "formatter": 13
                  },
                  {
                    "columnMatch": "microsoft.insights/components/kusto-Performance Counters-performanceCounters/processCpuPercentageTotal Timeline",
                    "formatter": 5
                  },
                  {
                    "columnMatch": "microsoft.insights/components/kusto-Performance Counters-performanceCounters/processCpuPercentageTotal",
                    "formatter": 1,
                    "numberFormat": {
                      "options": null,
                      "unit": 1
                    }
                  }
                ],
                "rowLimit": 10000,
                "labelSettings": [
                  {
                    "columnId": "microsoft.insights/components/kusto-Performance Counters-performanceCounters/processCpuPercentageTotal",
                    "label": "Process CPU (all cores) (Max)"
                  },
                  {
                    "columnId": "microsoft.insights/components/kusto-Performance Counters-performanceCounters/processCpuPercentageTotal Timeline",
                    "label": "Process CPU (all cores) Timeline"
                  }
                ]
              }
            },
            "customWidth": "50",
            "showPin": true,
            "name": "CPU Usage",
            "styleSettings": {
              "showBorder": true
            }
          },
          {
            "type": 10,
            "content": {
              "chartId": "workbookd1426854-1b25-40e0-8b97-76500583604b",
              "version": "MetricsItem/2.0",
              "size": 0,
              "chartType": 2,
              "resourceType": "microsoft.insights/components",
              "metricScope": 0,
              "resourceIds": [
                "${appi-id}"
              ],
              "timeContextFromParameter": "TimeRange",
              "timeContext": {
                "durationMs": 86400000
              },
              "metrics": [
                {
                  "namespace": "microsoft.insights/components/kusto",
                  "metric": "microsoft.insights/components/kusto-Server-requests/count",
                  "aggregation": 1,
                  "splitBy": "request/name"
                }
              ],
              "title": "Server Requests",
              "gridSettings": {
                "rowLimit": 10000
              }
            },
            "customWidth": "50",
            "showPin": true,
            "name": "Server Requests",
            "styleSettings": {
              "showBorder": true
            }
          },
          {
            "type": 10,
            "content": {
              "chartId": "workbook9365ce13-845d-47b6-8143-e036c276cec8",
              "version": "MetricsItem/2.0",
              "size": 0,
              "chartType": 2,
              "resourceType": "microsoft.insights/components",
              "metricScope": 0,
              "resourceIds": [
                "${appi-id}"
              ],
              "timeContextFromParameter": "TimeRange",
              "timeContext": {
                "durationMs": 86400000
              },
              "metrics": [
                {
                  "namespace": "microsoft.insights/components/kusto",
                  "metric": "microsoft.insights/components/kusto-Server-requests/duration",
                  "aggregation": 4,
                  "splitBy": "operation/name"
                }
              ],
              "title": "Server Response Time",
              "gridSettings": {
                "rowLimit": 10000
              }
            },
            "customWidth": "50",
            "showPin": true,
            "name": "Server Response Time",
            "styleSettings": {
              "showBorder": true
            }
          }
        ]
      },
      "name": "Performance Group",
      "styleSettings": {
        "margin": "20px",
        "showBorder": true
      }
    },
    {
      "type": 12,
      "content": {
        "version": "NotebookGroup/1.0",
        "groupType": "editable",
        "title": "Dependency",
        "expandable": true,
        "items": [
          {
            "type": 3,
            "content": {
              "version": "KqlItem/1.0",
              "query": "let dependenciesData = dependencies\r\n| where timestamp {TimeRange}\r\n| summarize Count = count(), Users = dcount(user_Id) by type\r\n| order by type asc| project v = type, t = type, s=false\r\n| union (datatable(v:string, t:string, s:boolean)['*', 'All Dependencies', true]);\r\nlet resultCodes = datatable(x:string, y:string, z:boolean)['*', 'All', true]\r\n| union (dependencies | summarize by resultCode| order by resultCode asc| where isnotempty(resultCode)|project x = resultCode, y = resultCode, z = false);\r\nlet bigWindow = dependencies\r\n| where type in (dependenciesData) or '*' in (dependenciesData)\r\n| where resultCode in (resultCodes) or '*' in (resultCodes)\r\n| summarize by type, resultCode\r\n| summarize makelist(strcat(type, '-', resultCode), 100000);\r\nlet data = dependencies\r\n| where type in (dependenciesData) or '*' in (dependenciesData)\r\n| where resultCode in (resultCodes) or '*' in (resultCodes);\r\ndata\r\n| make-series Count = count()  default = 0 on timestamp in range({TimeRange:start}, now(), {TimeRange:grain}) by s = strcat(resultCode, '::', type)",
              "size": 0,
              "title": "Dependency Chart",
              "queryType": 0,
              "resourceType": "microsoft.insights/components",
              "visualization": "barchart"
            },
            "customWidth": "50",
            "showPin": true,
            "name": "Dependency Chart",
            "styleSettings": {
              "showBorder": true
            }
          },
          {
            "type": 10,
            "content": {
              "chartId": "workbook155dbf85-d271-4af5-9be7-9c2b39927a68",
              "version": "MetricsItem/2.0",
              "size": 0,
              "chartType": 2,
              "resourceType": "microsoft.insights/components",
              "metricScope": 0,
              "resourceIds": [
                "${appi-id}"
              ],
              "timeContextFromParameter": "TimeRange",
              "timeContext": {
                "durationMs": 86400000
              },
              "metrics": [
                {
                  "namespace": "microsoft.insights/components",
                  "metric": "microsoft.insights/components-Failure-dependencies/failed",
                  "aggregation": 7
                }
              ],
              "title": "Dependency Failures",
              "gridSettings": {
                "rowLimit": 10000
              }
            },
            "customWidth": "50",
            "showPin": true,
            "name": "Dependency Failures",
            "styleSettings": {
              "showBorder": true
            }
          }
        ]
      },
      "name": "Dependency",
      "styleSettings": {
        "margin": "20px",
        "showBorder": true
      }
    },
    {
      "type": 12,
      "content": {
        "version": "NotebookGroup/1.0",
        "groupType": "editable",
        "title": "Customer Search",
        "expandable": true,
        "items": [
          {
            "type": 9,
            "content": {
              "version": "KqlParameterItem/1.0",
              "parameters": [
                {
                  "id": "85c9a045-595b-4120-863c-1fd4bc3047b5",
                  "version": "KqlParameterItem/1.0",
                  "name": "CustomerId",
                  "type": 1,
                  "isRequired": true,
                  "timeContext": {
                    "durationMs": 86400000
                  },
                  "value": "",
                  "label": "Customer ID"
                }
              ],
              "style": "pills",
              "queryType": 0,
              "resourceType": "microsoft.insights/components"
            },
            "name": "parameters - 0"
          },
          {
            "type": 3,
            "content": {
              "version": "KqlItem/1.0",
              "query": "let sourceMapping = dynamic(\r\n    {\r\n    \"UpdateClm\": \"CLM Update Logs\",\r\n    \"ReceiveUpdateEvent\": \"Customer Basic Information Update Logs\",\r\n    \"ReceiveLifecycleEvent\": \"Customer Lifecycle Event Logs\",\r\n    \"RefetchFailedRegistryChanges\": \"POSTI Fetch Logs\",\r\n    \"FetchRegistryChanges\": \"POSTI Fetch Logs\"\r\n    });\r\nlet postiFetchDetails=traces\r\n| where message has '{CustomerId}' and message startswith \"Clm Updater posti changes request body\"\r\n| extend postiFetchLogs = parse_json(tostring(split(message, 'Json Body: ')[1]))\r\n| mv-expand postiFetchLogs\r\n| where postiFetchLogs.CustomerNumber == '{CustomerId}'\r\n| extend customerDetails=postiFetchLogs;\r\ntraces | union postiFetchDetails\r\n| where message has '{CustomerId}' and isnull(customDimensions.prop__HttpMethod)  \r\n| project Timestamp=timestamp, ['Operation Name']=sourceMapping[operation_Name], ['Log Text']=iif(isnotnull(customerDetails), customerDetails, message)",
              "size": 0,
              "timeContextFromParameter": "TimeRange",
              "queryType": 0,
              "resourceType": "microsoft.insights/components"
            },
            "showPin": true,
            "name": "Customer Search",
            "styleSettings": {
              "margin": "10px",
              "padding": "10px",
              "showBorder": true
            }
          }
        ]
      },
      "customWidth": "100",
      "name": "Customer Search",
      "styleSettings": {
        "margin": "20px",
        "showBorder": true
      }
    }
  ],
  "fallbackResourceIds": [
    "${appi-id}"
  ],
  "styleSettings": {
    "paddingStyle": "narrow",
    "spacingStyle": "narrow"
  },
  "$schema": "https://github.com/Microsoft/Application-Insights-Workbooks/blob/master/schema/workbook.json"
})}