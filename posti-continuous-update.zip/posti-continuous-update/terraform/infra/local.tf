locals {
  action_group_emails =  concat(var.ENVIRONMENT != "dev" ? var.dev_team_emails : [], var.ENVIRONMENT == "prod" ? [var.azure_team_DL] : [])
}