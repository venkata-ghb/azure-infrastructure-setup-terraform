terraform {
  backend "azurerm" {}
}
