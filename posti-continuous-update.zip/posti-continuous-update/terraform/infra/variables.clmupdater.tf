variable "CLM_PROFILE_BASE_URL" {
  type        = string
  description = "Base Url for the CLM Profile"
  sensitive   = true
}

variable "CLM_AUTH_BASE_URL" {
  type        = string
  description = "Base Url for the CLM Auth"
  sensitive   = true
}

variable "CLM_AUTH_CLIENT_ID" {
  type        = string
  description = "Client ID for the CLM Auth"
  sensitive   = true
}

variable "CLM_AUTH_CLIENT_SECRET" {
  type        = string
  description = "Client Secret for the CLM Auth"
  sensitive   = true
}

variable "CLM_AUTH_API_KEY" {
  type        = string
  description = "API Key for the CLM Auth"
  sensitive   = true
}

variable "CLM_PROFILE_DISABLE_PROCESSING_CHANGES" {
  type        = bool
  default     = false
  description = "Feature flag for disabling sending changes to CLM."
}

variable "CLM_UPDATE_ERRORS_CONTAINER_NAME" {
  type        = string
  description = "Name of CosmosDb clm update errors container"
}

variable "DISABLE_STORE_CLM_UPDATE_ERRORS" {
  type        = bool
  default     = false
  description = "Feature flag for disabling storing clm update errors in ComsosDb."
}

variable "CLM_AUTH_DISABLE_GRANT_SCOPE_CHANNEL" {
  type        = bool
  default     = false
  description = "Feature flag for disabling using grant type, scope and channel from the body from the login request."
}

variable "FUNCTIONSETTINGS_DISABLE_CLM_ERROR_RESEND" {
  type        = bool
  default     = false
  description = "Feature flag for disabling resending errors to CLM."
}