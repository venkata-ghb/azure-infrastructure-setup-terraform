# Names need to be in all caps to properly match imported variables in pipeline

variable "API_REGISTRY_ID" {
  type        = string
  description = "The environment the deployment is being made in."
}

variable "API_BASE_URL" {
  type        = string
  description = "Resource group to create resources in"
}

variable "API_RETRY_COUNT" {
  type        = number
  default     = 3
  description = "How many times should we retry a failed request"
}

variable "API_RETRY_INCREMENT_IN_SECONDS" {
  type        = string
  default     = 30
  description = "By how many seconds do we want to increment between each retry."
}

variable "AUTH_BASE_URL" {
  type        = string
  description = "Resource group to create resources in"
}

variable "AUTH_TOKEN_TRESHOLD" {
  type        = string
  description = "Resource group to create resources in"
}

variable "AUTH_CONSUMER_KEY" {
  type        = string
  description = "Resource group to create resources in"
  sensitive = true
}

variable "AUTH_CONSUMER_SECRET" {
  type        = string
  description = "Resource group to create resources in"
  sensitive = true
}

variable "DISABLE_SENDING_CHANGES_TO_CLM_UPDATER" {
  type        = bool
  default     = false
  description = "Feature flag for disabling sending of Posti changes to CLM Updater."
}

variable "DISABLE_BATCH_FETCHING" {
  type        = bool
  default     = false
  description = "Feature flag for disabling Fetching latest batch from Event Batcher."
}

variable "DISABLE_FETCHING_CHANGES_FROM_POSTI" {
  type        = bool
  default     = false
  description = "Feature flag for disabling Fetching latest changes from Posti."
}

variable "DISABLE_SENDING_CHANGES_TO_POSTI" {
  type        = bool
  default     = false
  description = "Feature flag for disabling sending changes to Posti."
}

variable "POSTI_ERRORS_CONTAINER_NAME" {
  type        = string
  description = "Name of CosmosDb posti errors container"
}

variable "DISABLE_STORE_POSTI_ERRORS" {
  type        = bool
  default     = false
  description = "Feature flag for disabling storing posti errors in ComsosDb."
}

variable "FUNCTIONSETTINGS_DISABLE_FILE_REFETCH" {
  type        = bool
  default     = false
  description = "Feature flag for disabling refetching unsuccessfully fetched files."
}

variable "EVENT_BATCH_HANDLER_HOST_KEY" {
  type        = string
  description = "Host key for Event Batch Function app."
  sensitive   = true
}

variable "CLM_UPDATER_HOST_KEY" {
  type        = string
  description = "Host key for CLM Updater Function app."
  sensitive   = true
}

//Temp cycle workaround
//We cannot pass resource data 
//from PostiIntegration to Event Batcher 
//and from Event Batcher to PostiIntegration
//at the same time, because it's creating Cycle error in Terraform
variable "EVENT_BATCH_HANDLER_URL" {
  type        = string
  description = "Url for the Event Batch Handler function app"
  sensitive   = true
}
