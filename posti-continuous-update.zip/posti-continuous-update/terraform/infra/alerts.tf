# The action groups and alerts for monitoring the system

resource "azurerm_monitor_action_group" "posti_devops" {
  name                = "${local.project}-ag-PostiIntegrationDevOps-${var.ENVIRONMENT}"
  resource_group_name = data.azurerm_resource_group.main.name
  short_name          = "postidevops"

  dynamic "email_receiver" {
    for_each = local.action_group_emails
    content {
      name = replace(split("@", email_receiver.value)[0], ".", "-")
      email_address = email_receiver.value
    }
  }

  lifecycle {
      ignore_changes = [
        tags,
      ]
    }
}
resource "azurerm_monitor_metric_alert" "low_availability_alert" {
  name                = "${local.project}-alert-Low-Availability-${var.ENVIRONMENT}"
  description         = "Alert will trigger if availability is less than 95%"
  resource_group_name = data.azurerm_resource_group.main.name
  scopes              = [resource.azurerm_application_insights.main.id]

  criteria {
    metric_namespace = "microsoft.insights/components"
    metric_name      = "availabilityResults/availabilityPercentage"
    aggregation      = "Average"
    operator         = "LessThan"
    threshold        = 95

  }
  frequency = "PT15M"
  window_size = "PT1H"
  severity = 1
  action {
    action_group_id  = resource.azurerm_monitor_action_group.posti_devops.id
  }
  lifecycle {
    ignore_changes = [tags]
  }
}

resource "azurerm_monitor_metric_alert" "dependency_failure_alert" {
  name                = "${local.project}-alert-dependency-failure-${var.ENVIRONMENT}"
  description         = "Alert will trigger if dependency failure is high"
  resource_group_name = data.azurerm_resource_group.main.name
  scopes              = [resource.azurerm_application_insights.main.id]

  criteria {
    metric_namespace = "microsoft.insights/components"
    metric_name      = "dependencies/failed"
    aggregation      = "Count"
    operator         = "GreaterThanOrEqual"
    threshold        = 100

  }
  frequency = "PT15M"
  window_size = "PT1H"
  severity = 1
  action {
    action_group_id  = resource.azurerm_monitor_action_group.posti_devops.id
  }

  lifecycle {
    ignore_changes = [tags]
  }
}


resource "azurerm_monitor_scheduled_query_rules_alert_v2" "invalid_clm_events_data_v2" {
  name                = "${local.project}-alert-InvalidClmEvents-${var.ENVIRONMENT}"
  display_name        = "${local.project}-alert-InvalidClmEvents-${var.ENVIRONMENT}"

  location            = data.azurerm_resource_group.main.location
  resource_group_name = data.azurerm_resource_group.main.name

  action {
    action_groups = [ resource.azurerm_monitor_action_group.posti_devops.id ]
  }

  evaluation_frequency = "PT1H"
  window_duration      = "PT3H"
  severity             = 1
  scopes               = [resource.azurerm_application_insights.main.id]
  criteria {
    query       = <<-QUERY
      let clmEvents = traces
      | where operation_Name in ("ReceiveLifecycleEvent", "ReceiveUpdateEvent");
      let receivedEvents = clmEvents
      | where message has "Received event from customer life cycle hub"
      | project Status = "Received";
      let invalidEvents = clmEvents
      | where message has "Begin storing of invalid data document"
      | project Status = "Invalid";
      receivedEvents | union invalidEvents
      | summarize ReceivedCount = countif(Status == "Received"), InvalidCount = countif(Status == "Invalid")
      | extend InvalidPercentage = toreal(InvalidCount) / toreal(ReceivedCount) * 100.0
      | project-away ReceivedCount, InvalidCount
      | extend InvalidPercentage = round(InvalidPercentage, 2)
    QUERY

    time_aggregation_method = "Maximum"
    threshold               = var.INVALID_LIFECYCLE_THRESHOLD
    operator                = "GreaterThanOrEqual"

    metric_measure_column = "InvalidPercentage"
  }

  description             = "Alert for unusually high amounts of invalid data."
  auto_mitigation_enabled = true
  enabled                 = true

  lifecycle {
    ignore_changes = [tags]
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "unexpected_clm_events_errors_v2" {
  name                = "${local.project}-alert-UnexpectedClmEventErrors-${var.ENVIRONMENT}"
  display_name        = "${local.project}-alert-UnexpectedClmEventErrors-${var.ENVIRONMENT}"

  location            = data.azurerm_resource_group.main.location
  resource_group_name = data.azurerm_resource_group.main.name

  action {
    action_groups = [ resource.azurerm_monitor_action_group.posti_devops.id ]
  }

  evaluation_frequency = "PT1H"
  window_duration      = "PT3H"
  severity             = 1
  scopes               = [resource.azurerm_application_insights.main.id]
  criteria {
    query       = <<-QUERY
      let clmEvents = traces
      | where operation_Name in ("ReceiveLifecycleEvent", "ReceiveUpdateEvent");
      let receivedEvents = clmEvents
      | where message has "Received event from customer life cycle hub"
      | project Status = "Received";
      let unexpectedErrors = clmEvents
      | where message has "Unexpected error while receiving event"
      | project Status = "Error";
      receivedEvents | union unexpectedErrors
      | summarize ReceivedCount = countif(Status == "Received"), ErrorCount = countif(Status == "Error")
      | extend ErrorPercentage = toreal(ErrorCount) / toreal(ReceivedCount) * 100.0
      | project-away ReceivedCount, ErrorCount
      | extend ErrorPercentage = round(ErrorPercentage, 2)
    QUERY

    time_aggregation_method = "Maximum"
    threshold               = var.UNEXPECTED_LIFECYCLE_ERROR_THRESHOLD
    operator                = "GreaterThanOrEqual"

    metric_measure_column = "ErrorPercentage"
  }

  description             = "Alert for unusually high amounts of unexpected errors while processing lifecycle events."
  auto_mitigation_enabled = true
  enabled                 = true

  lifecycle {
    ignore_changes = [tags]
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "build_and_send_new_batch_alert_v2" {
  name                = "${local.project}-alert-BuildAndSendNewBatchAlert-${var.ENVIRONMENT}"
  display_name        = "${local.project}-alert-BuildAndSendNewBatchAlert-${var.ENVIRONMENT}"

  location            = data.azurerm_resource_group.main.location
  resource_group_name = data.azurerm_resource_group.main.name

  action {
    action_groups = [ resource.azurerm_monitor_action_group.posti_devops.id ]
  }

  evaluation_frequency = "PT30M"
  window_duration      = "PT1H"
  severity             = 1
  scopes               = [resource.azurerm_application_insights.main.id]
  criteria {
    query       = <<-QUERY
      union isfuzzy=true
        exceptions
      | extend Source = "Exception"
      | union
        traces
      | where message contains "Build And Send New Batch Alert"
      | extend Source = "Trace"
      | summarize count() by Source, bin(timestamp, 10m)
      | where count_ > 0
    QUERY

    time_aggregation_method = "Total"
    threshold               = var.UNEXPECTED_LIFECYCLE_ERROR_THRESHOLD
    operator                = "GreaterThanOrEqual"

    metric_measure_column = "count_"
  }

  description             = "Build and Send New Batch Exception Raised"
  auto_mitigation_enabled = true
  enabled                 = true

  lifecycle {
    ignore_changes = [tags]
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "cosmos_failure_v2" {
  name                = "${local.project}-alert-CosmosErrors-${var.ENVIRONMENT}"
  display_name        = "${local.project}-alert-CosmosErrors-${var.ENVIRONMENT}"

  location            = data.azurerm_resource_group.main.location
  resource_group_name = data.azurerm_resource_group.main.name

  action {
    action_groups = [ resource.azurerm_monitor_action_group.posti_devops.id ]
  }

  evaluation_frequency = "PT15M"
  window_duration      = "PT1H"
  severity             = 1
  scopes               = [resource.azurerm_application_insights.main.id]
  criteria {
    query       = <<-QUERY
      let cosmosCalls = dependencies
      | where type == "Azure DocumentDB" and name !has("GET") and name !has("Query documents") and resultCode != 404
      | project success, Status = "Called";
      let failedCosmosCalls = cosmosCalls
      | where success != "True"
      | extend Status = "Failed";
      cosmosCalls | union failedCosmosCalls
      | summarize CallCount = countif(Status == "Called"), FailCount = countif(Status == "Failed")
      | extend FailPercentage = toreal(FailCount) / toreal(CallCount) * 100.0
      | project-away CallCount, FailCount
      | extend FailPercentage = round(FailPercentage, 2)
    QUERY

    time_aggregation_method = "Maximum"
    threshold               = var.COSMOS_ERROR_THRESHOLD
    operator                = "GreaterThanOrEqual"

    metric_measure_column = "FailPercentage"
  }

  description             = "Alert for unusually high amounts of failed Cosmos requests"
  auto_mitigation_enabled = true
  enabled                 = true

  lifecycle {
    ignore_changes = [tags]
  }
}


resource "azurerm_monitor_scheduled_query_rules_alert_v2" "unsuccessful_clm_requests_v2" {
  name                = "${local.project}-alert-ClmRequestsFail-${var.ENVIRONMENT}"
  display_name        = "${local.project}-alert-ClmRequestsFail-${var.ENVIRONMENT}"

  location            = data.azurerm_resource_group.main.location
  resource_group_name = data.azurerm_resource_group.main.name

  action {
    action_groups = [ resource.azurerm_monitor_action_group.posti_devops.id ]
  }

  evaluation_frequency = "PT1H"
  window_duration      = "PT3H"
  severity             = 1
  scopes               = [resource.azurerm_application_insights.main.id]
  criteria {
    query       = <<-QUERY
      let allClmRequest = traces
      | where operation_Name != "" or severityLevel > 1
      | where cloud_RoleName == "ClmUpdater"
      | where customDimensions.prop__Uri matches regex "https://api-dev|api.kesko.fi/clm-b2b-proxy/v1/b2b/profile/ext/customers/" and message startswith "End processing HTTP request after";
      let allRequests = allClmRequest
      | project Status = "All requests";
      let allSuccess = allClmRequest
      | where toint(customDimensions.prop__StatusCode) == 200 or toint(customDimensions.prop__StatusCode) == 201 or toint(customDimensions.prop__StatusCode) == 204
      | project Status = "Successful requests";
      allRequests | union allSuccess
      | summarize RequestCount = countif(Status == "All requests"), SuccessfulCount = countif(Status == "Successful requests")
      | extend UnsuccessfulPercentage = 100 - (toreal(SuccessfulCount) / toreal(RequestCount) * 100)
      | project-away RequestCount, SuccessfulCount
      | extend UnsuccessfulPercentage = round(UnsuccessfulPercentage, 2)
    QUERY

    time_aggregation_method = "Maximum"
    threshold               = var.UNSUCCESSFUL_CLM_REQUESTS_THRESHOLD
    operator                = "GreaterThanOrEqual"

    metric_measure_column = "UnsuccessfulPercentage"
  }

  description             = "Alert for unusually high amounts of unsuccessful requests to CLM"
  auto_mitigation_enabled = true
  enabled                 = true

  lifecycle {
    ignore_changes = [tags]
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "posti_integration_fails_v2" {
  name                = "${local.project}-alert-PostiIntegrationFail-${var.ENVIRONMENT}"
  display_name        = "${local.project}-alert-PostiIntegrationFail-${var.ENVIRONMENT}"

  location            = data.azurerm_resource_group.main.location
  resource_group_name = data.azurerm_resource_group.main.name

  action {
    action_groups = [ resource.azurerm_monitor_action_group.posti_devops.id ]
  }

  evaluation_frequency = "PT1H"
  window_duration      = "PT3H"
  severity             = 1
  scopes               = [resource.azurerm_application_insights.main.id]
  criteria {
    query = <<-QUERY
      traces
      | where severityLevel > 1
      | where cloud_RoleName == "PostiIntegration" and (operation_Name == "FetchRegistryChanges" or operation_Name == "RefetchFailedRegistryChanges" or operation_Name == "UpdateRegistry")
      | summarize AggregatedValue = count()
    QUERY

    time_aggregation_method = "Maximum"
    threshold               = var.UNSUCCESSFUL_POSTI_FETCH_THRESHOLD
    operator                = "GreaterThanOrEqual"

    metric_measure_column = "AggregatedValue"
  }

  description             = "Alert for unusually high amounts of unsuccessful fetches from Posti"
  auto_mitigation_enabled = true
  enabled                 = true

  lifecycle {
    ignore_changes = [tags]
  }
}


resource "azurerm_monitor_scheduled_query_rules_alert_v2" "unsuccessful_posti_fetch_statuses_v2" {
  name                = "${local.project}-alert-PostiFetchDetailsFail-${var.ENVIRONMENT}"
  display_name        = "${local.project}-alert-PostiFetchDetailsFail-${var.ENVIRONMENT}"

  location            = data.azurerm_resource_group.main.location
  resource_group_name = data.azurerm_resource_group.main.name

  action {
    action_groups = [ resource.azurerm_monitor_action_group.posti_devops.id ]
  }

  evaluation_frequency = "PT1H"
  window_duration      = "PT3H"
  severity             = 1
  scopes               = [resource.azurerm_application_insights.main.id]
  criteria {
    query = <<-QUERY
        let allFileRequests =  traces
      | where severityLevel > 1 or operation_Name != ""
      | where cloud_RoleName == "PostiIntegration" and (operation_Name == "FetchRegistryChanges" or operation_Name == "RefetchFailedRegistryChanges") and (customDimensions.prop__Uri has "${var.POSTI_URL_HOST}")
      | where message startswith "End processing HTTP ";
      let allRequests = allFileRequests
      | project Status = "All requests";
      let allSuccess = allFileRequests
      | where toint(customDimensions.prop__StatusCode) == 200 or toint(customDimensions.prop__StatusCode) == 201 or toint(customDimensions.prop__StatusCode) == 204
      | project Status = "Successful requests";
      allRequests | union allSuccess
      | summarize RequestCount = countif(Status == "All requests"), SuccessfulCount = countif(Status == "Successful requests")
      | extend UnsuccessfulPercentage = 100 - (toreal(SuccessfulCount) / toreal(RequestCount) * 100)
      | project-away RequestCount, SuccessfulCount
      | extend UnsuccessfulPercentage = round(UnsuccessfulPercentage, 2)
        QUERY

    time_aggregation_method = "Maximum"
    threshold               = 1
    operator                = "GreaterThanOrEqual"

    metric_measure_column = "UnsuccessfulPercentage"
  }

  description             = "Alert for Posti fetch response errors"
  auto_mitigation_enabled = true
  enabled                 = true

  lifecycle {
    ignore_changes = [tags, criteria[0].query]
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "unsuccessful_posti_file_send_v2" {
  name                = "${local.project}-alert-PostiFileSendFail-${var.ENVIRONMENT}"
  display_name        = "${local.project}-alert-PostiFileSendFail-${var.ENVIRONMENT}"

  location            = data.azurerm_resource_group.main.location
  resource_group_name = data.azurerm_resource_group.main.name

  action {
    action_groups = [ resource.azurerm_monitor_action_group.posti_devops.id ]
  }

  evaluation_frequency = "PT1H"
  window_duration      = "PT3H"
  severity             = 1
  scopes               = [resource.azurerm_application_insights.main.id]
  criteria {
    query = <<-QUERY
        let allFileRequests =  traces
      | where severityLevel > 1 or operation_Name != ""
      | where cloud_RoleName == "PostiIntegration" and operation_Name == "UpdateRegistry" and (customDimensions.prop__Uri has "${var.POSTI_URL_HOST}")
      | where message startswith "End processing HTTP ";
      let allRequests = allFileRequests
      | project Status = "All requests";
      let allSuccess = allFileRequests
      | where toint(customDimensions.prop__StatusCode) == 200 or toint(customDimensions.prop__StatusCode) == 201 or toint(customDimensions.prop__StatusCode) == 204
      | project Status = "Successful requests";
      allRequests | union allSuccess
      | summarize RequestCount = countif(Status == "All requests"), SuccessfulCount = countif(Status == "Successful requests")
      | extend UnsuccessfulPercentage = 100 - (toreal(SuccessfulCount) / toreal(RequestCount) * 100)
      | project-away RequestCount, SuccessfulCount
      | extend UnsuccessfulPercentage = round(UnsuccessfulPercentage, 2)
        QUERY

    time_aggregation_method = "Maximum"
    threshold               = var.UNSUCCESSFUL_POSTI_FILE_SEND_THRESHOLD
    operator                = "GreaterThanOrEqual"

    metric_measure_column = "UnsuccessfulPercentage"
  }

  description             = "Alert for unusually high amounts of unsuccessful sending or commiting files to Posti"
  auto_mitigation_enabled = true
  enabled                 = true

  lifecycle {
    ignore_changes = [tags, criteria[0].query]
  }
}


