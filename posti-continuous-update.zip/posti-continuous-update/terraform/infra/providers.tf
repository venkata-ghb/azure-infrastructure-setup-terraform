provider "azurerm" {
  skip_provider_registration = true
  
  features {
    key_vault {
      # Terraform will automatically recover a soft-deleted
      # Key Vault during Creation if one is found.
      # So we're explicitely opting out of it
      purge_soft_delete_on_destroy = true
    }
  }
}

terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">=3.95.0, <4.0.0"
    }
  }

  required_version = "~> 1.0"
}
