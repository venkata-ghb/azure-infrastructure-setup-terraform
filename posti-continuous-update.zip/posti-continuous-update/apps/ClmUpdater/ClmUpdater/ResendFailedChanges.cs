using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ClmUpdater.ClmApim;
using ClmUpdater.ClmApim.Models;
using ClmUpdater.Config.Models;
using ClmUpdater.CosmosDb;
using ClmUpdater.CosmosDb.Models;
using ClmUpdater.Mappers;
using ClmUpdater.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace ClmUpdater
{
  public class ResendFailedChanges
  {
    private readonly ILogger<ResendFailedChanges> _logger;
    private readonly ICustomerProfileService _customerProfileService;
    private readonly IClmChangeMapper _mapper;
    private readonly ICosmosDbService _cosmosDbService;
    private readonly FunctionSettings _functionSettings;


    public ResendFailedChanges(ILogger<ResendFailedChanges> logger, ICustomerProfileService customerProfileService, IClmChangeMapper mapper, ICosmosDbService cosmosDbService, FunctionSettings functionSettings)
    {
      _logger = logger;
      _customerProfileService = customerProfileService;
      _mapper = mapper;
      _cosmosDbService = cosmosDbService;
      _functionSettings = functionSettings;
    }

    [FunctionName("ResendFailedChanges")]
    public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req)
    {
      try
      {
        if (_functionSettings.DisableClmErrorResend)
        {
          LogFileResendDisabled();
          return new OkResult();
        }

        //Get all update errors 
        var errorDocuments = await _cosmosDbService.GetClmUpdateErrors();

        //Run retry
        var retryTasks = new List<Task>();
        List<ClmResponse> results = await RetrySendingFailedChanges(errorDocuments, retryTasks);

        //Remove successful from cosmosDb
        await RemoveSuccessfulyResentDocuments(errorDocuments, results);

        //Get failed records, which will determine the response message and code 
        var failed = results.Where(r => r.ResponseStatus == ClmResponseStatus.Fail).ToList();

        return GetActionResult(failed);
      }
      catch (Exception ex)
      {
        LogUnexpectedError(ex);
        return new StatusCodeResult(StatusCodes.Status500InternalServerError);
      }
    }

    private async Task RemoveSuccessfulyResentDocuments(List<ClmUpdateErrorDocument> errorDocuments, List<ClmResponse> results)
    {
      var successful = results.Where(r => r.ResponseStatus == ClmResponseStatus.Success);
      var removeSuccessfulTasks = new List<Task>();
      foreach (var success in successful)
      {
        var errorDoc = errorDocuments.FirstOrDefault(doc => doc.CustomerId == success.CustomerId && doc.FailedOperation == success.ChangeStatus.ToString());
        removeSuccessfulTasks.Add(_cosmosDbService.DeleteClmUpdateError(errorDoc.Id, errorDoc.FailedOperation));
      }

      await Task.WhenAll(removeSuccessfulTasks);
    }

    private async Task<List<ClmResponse>> RetrySendingFailedChanges(List<ClmUpdateErrorDocument> errorDocuments, List<Task> tasks)
    {
      var results = new List<ClmResponse>();
      foreach (var errorDocument in errorDocuments)
      {
        tasks.Add(GetRetryTaskFromDocument(errorDocument));
      }
      await Task.WhenAll(tasks);
      foreach (Task<ClmResponse> task in tasks)
        results.Add(task.Result);
      return results;
    }

    private Task GetRetryTaskFromDocument(ClmUpdateErrorDocument errorDocument)
    {
      var clmChange = _mapper.Map(errorDocument);
      ClmChangeStatus failedReason;
      Enum.TryParse(errorDocument.FailedOperation, out failedReason);
      var task = failedReason switch
      {
        ClmChangeStatus.CustomerUpdated => _customerProfileService.ModifyCustomerAsync(clmChange),
        ClmChangeStatus.IdentifiedAssignmentSet => _customerProfileService.MarkIdentifiedAssignment(clmChange.CustomerId, clmChange.ChangeStatus.WasIdentified.Value),
        ClmChangeStatus.PersonDuplicated => _customerProfileService.SetDuplicateAttribute(clmChange),
        _ => Task.CompletedTask
      };
      return task;
    }

    private ActionResult GetActionResult(List<ClmResponse> failed)
    {
      if (failed.Count == 0)
        return new OkResult();

      return new ObjectResult(PrepareResponse(failed)) { StatusCode = StatusCodes.Status500InternalServerError };
    }

    private FailedActionResponse PrepareResponse(List<ClmResponse> failed)
        => new FailedActionResponse("Some records where not correctly processed by CLM", JsonConvert.SerializeObject(failed));


    private void LogUnexpectedError(Exception ex)
    {
      _logger.LogError("There was an unexpected error:\n" +
          "Error: {error}\n" +
          "Stack trace: {trace}",
          ex, ex.StackTrace);
    }

    private void LogFileResendDisabled()
    {
      _logger.LogInformation("CLM Error resend disabled. Skipping");
    }
  }
}
