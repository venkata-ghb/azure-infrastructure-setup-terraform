﻿namespace ClmUpdater.Config;

/// <summary>
/// Flag interface that helps in registering settings model in DI
/// </summary>
public interface ICustomApplicationSetting
{
}