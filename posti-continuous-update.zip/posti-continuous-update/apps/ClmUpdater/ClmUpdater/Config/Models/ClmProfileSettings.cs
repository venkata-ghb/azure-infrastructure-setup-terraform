﻿namespace ClmUpdater.Config.Models;
public class ClmProfileSettings : ICustomApplicationSetting
{
  public string BaseUrl { get; init; }

  //Feature flags
  public bool DisableProcessingChanges { get; init; }
}
