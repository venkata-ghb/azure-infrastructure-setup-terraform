﻿namespace ClmUpdater.Config.Models;
public class FunctionSettings : ICustomApplicationSetting
{
  public bool DisableClmErrorResend { get; init; }
}
