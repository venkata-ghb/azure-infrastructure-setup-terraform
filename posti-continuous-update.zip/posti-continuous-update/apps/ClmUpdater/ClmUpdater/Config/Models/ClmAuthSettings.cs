﻿namespace ClmUpdater.Config.Models;
public class ClmAuthSettings : ICustomApplicationSetting
{
  public string ApiKey { get; init; }
  public string ClientId { get; init; }
  public string ClientSecret { get; init; }
  public string BaseUrl { get; init; }
  public bool DisableGrantScopeChannel { get; init; }
}
