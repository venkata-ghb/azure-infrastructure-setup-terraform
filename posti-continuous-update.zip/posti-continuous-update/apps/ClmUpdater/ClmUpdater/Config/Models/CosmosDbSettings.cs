﻿namespace ClmUpdater.Config.Models;
public class CosmosDbSettings : ICustomApplicationSetting
{
  public string Name { get; init; }
  public string ConnectionString { get; init; }
  public string ClmUpdateErrorsContainer { get; init; }
  // Feature flags
  public bool DisableStoreClmUpdateErrors { get; init; }
}

