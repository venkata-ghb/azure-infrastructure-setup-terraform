﻿using System.Globalization;
using Newtonsoft.Json.Converters;

namespace ClmUpdater.Tools;
public class ClmDateTimeConverter : IsoDateTimeConverter
{
  public ClmDateTimeConverter()
  {
    DateTimeFormat = "yyyy-MM-ddTHH:mm:ss.fffZ";
    Culture = CultureInfo.InvariantCulture;
  }
}
