﻿using System;
using System.Linq;
using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Cosmos.Linq;
using NodaTime;

namespace ClmUpdater.Tools;
public class Utils
{
  public static long ConvertIso8601StringToUnixTimestamp(string isoTime)
  {
    var dateTimeOffset = DateTimeOffset.Parse(isoTime);
    var instant = Instant.FromDateTimeOffset(dateTimeOffset);
    return instant.ToUnixTimeSeconds();
  }

  public static DateTime UnixSecondsToDateTime(long timestamp, bool local = false)
  {
    var offset = DateTimeOffset.FromUnixTimeSeconds(timestamp);
    return local ? offset.LocalDateTime : offset.UtcDateTime;
  }

}

/// <summary>
/// This is a wrapper just to make functions using LINQ extensions for Cosmos testable.
/// </summary>
/// <remarks>
/// Discussion and workaround from here: https://github.com/Azure/azure-cosmos-dotnet-v3/issues/893
/// </remarks>
public interface ICosmosLinqQuery
{
  FeedIterator<T> GetFeedIterator<T>(IQueryable<T> query);

  string GetQueryText<T>(IQueryable<T> query);
}

public class CosmosLinqQueryWrapper : ICosmosLinqQuery
{
  public FeedIterator<T> GetFeedIterator<T>(IQueryable<T> query)
  {
    return query.ToFeedIterator();
  }

  public string GetQueryText<T>(IQueryable<T> query)
  {
    return query.ToQueryDefinition().QueryText;
  }
}
