﻿using System;
using System.Net.Http;
using ClmUpdater.Config.Models;
using Microsoft.Extensions.Logging;
using Polly;
using Polly.Retry;

namespace ClmUpdater.Tools;
public static class PollyPoliciesFactory
{
  public static AsyncRetryPolicy<HttpResponseMessage> CreateRetryPolicy()
  {
    var retryPolicy = Policy.Handle<HttpRequestException>()
      .OrResult<HttpResponseMessage>(r => !r.IsSuccessStatusCode)
      .WaitAndRetryAsync(
              2,
              retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
              onRetry: (outcome, timespan, retryAttempt, context) =>
              {
                var log = context.GetLogger();
                if (outcome.Exception != null)
                  LogException(outcome, retryAttempt, context, log);
                else
                  LogStatusCode(outcome, retryAttempt, context, log);
              }
      );

    return retryPolicy;
  }

  private static void LogStatusCode(DelegateResult<HttpResponseMessage> outcome, int retryAttempt, Context context, ILogger log)
  {
    log?.LogInformation("Request failed with status code {statusCode} \n" +
                        "Method: {method}\n" +
                        "Uri: {uri}\n" +
                        "Retry attempt: {retryAttempt}\n",
                        outcome.Result.StatusCode,
                        context.GetRequestMethod(),
                        context.GetRequestUri(),
                        retryAttempt);
  }

  private static void LogException(DelegateResult<HttpResponseMessage> outcome, int retryAttempt, Context context, ILogger log)
  {
    log?.LogInformation("Request failed with exception \n" +
      "Method: {method}\n" +
      "Uri: {uri}\n" +
      "Retry attempt: {retryAttempt}\n" +
      "Exception: {message}",
      context.GetRequestMethod(),
      context.GetRequestUri(),
      retryAttempt,
      outcome.Exception.Message);
  }
}
