﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using ClmUpdater.ClmApim.Models;
using ClmUpdater.Config.Models;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace ClmUpdater.ClmApim;

public interface IAuthorizationService
{
  public Task AddAuthHeader(HttpRequestMessage request, CancellationToken token);
  public void AddApiKeyHeader(HttpRequestMessage request);
}

public class AuthorizationService : IAuthorizationService
{
  private const string AuthorizationEndpoint = "login";

  private readonly HttpClient _httpClient;
  private readonly ClmAuthSettings _configuration;
  private readonly ITokenCache _tokenCache;
  private readonly ILogger<AuthorizationService> _logger;

  public AuthorizationService(
      HttpClient httpClient,
      ITokenCache tokenCache,
      ClmAuthSettings configuration, ILogger<AuthorizationService> logger)
  {
    _configuration = configuration;
    _httpClient = httpClient;
    _httpClient.BaseAddress = new Uri(configuration.BaseUrl);
    _tokenCache = tokenCache;
    _logger = logger;
  }

  private const string ClientIdKey = "client_id";
  private const string ClientSecretKey = "client_secret";
  private static readonly KeyValuePair<string, string> Channel = new("channel", "V");
  private static readonly KeyValuePair<string, string> GrantType = new("grant_type", "client_credentials");
  private static readonly KeyValuePair<string, string> Scope = new("scope", "any");

  /// <summary>
  /// Fetch OAuth token from CLM upstream and stores the token to injected ITokenCache.
  /// </summary>
  /// <param name="cancellationToken">Cancellation support</param>
  /// <returns>The token</returns>
  private async Task<OAuthToken> GetAuthToken(CancellationToken cancellationToken)
  {
    try
    {
      await _tokenCache.TokenSemaphore.WaitAsync(cancellationToken);

      if (_tokenCache.Token?.HasExpired == false)
      {
        return _tokenCache.Token;
      }

      //23.08.22
      //Added feature flag for creating body with of without channel, grantType and Scope
      //Earlier it was working fine with those properties but somethig has changed and removing
      //this fields seems to be fixing the issue
      //This is only a temp solution
      using var requestContent = _configuration.DisableGrantScopeChannel ?
        new FormUrlEncodedContent(new List<KeyValuePair<string, string>>
            {
                new(ClientIdKey, _configuration.ClientId),
                new(ClientSecretKey, _configuration.ClientSecret),
            })
        : new FormUrlEncodedContent(new List<KeyValuePair<string, string>>
            {
                new(ClientIdKey, _configuration.ClientId),
                new(ClientSecretKey, _configuration.ClientSecret),
                Channel,
                GrantType,
                Scope
            });

      using var request =
          new HttpRequestMessage(HttpMethod.Post, $"{_configuration.BaseUrl}{AuthorizationEndpoint}")
          {
            Content = requestContent
          };

      AddApiKeyHeader(request);

      var response = await _httpClient.SendAsync(request, cancellationToken);

      var responseString = await response.Content.ReadAsStringAsync();
      var tokenResponse = JsonConvert.DeserializeObject<ZuulSuccessResponse>(responseString);

      return _tokenCache.Token = new OAuthToken(tokenResponse);
    }
    finally
    {
      _tokenCache.TokenSemaphore.Release(1);
    }
  }

  private const string AuthHeader = "Authorization";

  /// <summary>
  /// Attach CLM OAuth token to request headers. Get token from cache or upstream.
  /// </summary>
  /// <param name="request"></param>
  /// <param name="cancellationToken"></param>
  public async Task AddAuthHeader(HttpRequestMessage request, CancellationToken cancellationToken)
  {
    var authToken = await GetAuthToken(cancellationToken);
    request.Headers.Remove(AuthHeader);

    //If there there was a problem with getting an access token (as example it was empty) don't add it again to the Header
    //In this case requests probably will return 401 (and in that case we will save changes that didn't made to CLM in CosmosDb
    if (!string.IsNullOrEmpty(authToken.AuthorizationHeaderValue))
      request.Headers.Add(AuthHeader, authToken.AuthorizationHeaderValue);

  }

  private const string ApiKeyHeader = "Ocp-Apim-Subscription-Key";

  /// <summary>
  /// Attach APIM api key to request headers. Get the key from configuration.
  /// </summary>
  /// <param name="request"></param>
  public void AddApiKeyHeader(HttpRequestMessage request)
  {
    request.Headers.Add(ApiKeyHeader, _configuration.ApiKey);
  }
  private void LogGettingTokenResponse(string tokenResponse)
  {
    _logger.LogInformation("Access token response\n" +
            "Response: {tokenResponse}", tokenResponse);
  }
}
