﻿

using Newtonsoft.Json;

namespace ClmUpdater.ClmApim.Models;
public record ZuulSuccessResponse
{
  [JsonProperty("access_token")]
  public string AccessToken { get; init; } = string.Empty;

  [JsonProperty("token_type")]
  public string TokenType { get; init; } = string.Empty;

  [JsonProperty("expires_in")]
  public int ExpiresIn { get; init; }

  [JsonProperty("scope")]
  public string Scope { get; init; } = string.Empty;

  [JsonProperty("jti")]
  public string Jti { get; init; } = string.Empty;
}
