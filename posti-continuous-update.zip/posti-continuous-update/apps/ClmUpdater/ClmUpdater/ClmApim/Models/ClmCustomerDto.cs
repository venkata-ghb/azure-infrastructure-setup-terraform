﻿using System;
using System.Collections.Generic;
using ClmUpdater.Tools;
using Newtonsoft.Json;

namespace ClmUpdater.ClmApim.Models;

/// <summary>
/// Main DTO that can be send into CLM in order to update Customer info
/// </summary>
[JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
public record ClmCustomerDto
{
  [JsonProperty("lastModify")]
  [JsonConverter(typeof(ClmDateTimeConverter))]
  public DateTime? LastModify { get; init; }

  [JsonProperty("login")]
  public string Login { get; init; }

  [JsonProperty("birthDate")]
  [JsonConverter(typeof(ClmDateOnlyConverter))]
  public DateOnly? BirthDate { get; init; }

  [JsonProperty("gender")]
  public string Gender { get; init; }

  [JsonProperty("preferredChannel")]
  public string PreferredChannel { get; init; }

  [JsonProperty("nationality")]
  public string Nationality { get; init; }

  [JsonProperty("address")]
  public AddressDto Address { get; init; }

  [JsonProperty("permissions")]
  public PermissionDto Permissions { get; init; }

  [JsonProperty("title")]
  public string Title { get; init; }

  [JsonProperty("firstName")]
  public string FirstName { get; init; }

  [JsonProperty("lastName")]
  public string LastName { get; init; }

  [JsonProperty("language")]
  public string Language { get; init; }

  [JsonProperty("pointExpirationDisabled")]
  public string PointExpirationDisabled { get; init; }

  [JsonProperty("mainIdentifier")]
  public string MainIdentifier { get; init; }

  [JsonProperty("mobileId")]
  public string MobileId { get; init; }

  [JsonProperty("mobileSystem")]
  public string mobileSystem { get; init; }

  /// <summary>
  /// Used when retreiving Customer Information
  /// Can also be used in other routes, but it will overwrite the enitre array
  /// So for updating only specific attributes, PatchAttributeDto should be used
  /// </summary>
  [JsonProperty("attributes")]
  public List<AttributeDto> Attributes { get; init; }

  /// <summary>
  /// Used when updating Customer Information using Patch request 
  /// It will only change the given attribute 
  /// </summary>
  [JsonProperty("patchAttributes")]
  public List<PatchAttributeDto> PatchAttributes { get; init; }

  [JsonProperty("blacklistReason")]
  public string BlacklistReason { get; init; }

  [JsonProperty("websiteAccess")]
  public string WebsiteAccess { get; init; }

  [JsonProperty("redemptionEnabled")]
  public string RedemptionEnabled { get; init; }

  [JsonProperty("householdLockDate")]
  [JsonConverter(typeof(ClmDateOnlyConverter))]
  public DateOnly? HouseholdLockDate { get; init; }

  [JsonProperty("termAndConditionAcceptedDate")]
  public string TermAndConditionAcceptedDate { get; init; }

  [JsonProperty("ssn")]
  public string Ssn { get; init; }
}

[JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
public record AddressDto()
{
  [JsonProperty("street")]
  public string Street { get; init; }

  [JsonProperty("house")]
  public string House { get; init; }

  [JsonProperty("apartmentNumber")]
  public string ApartmentNumber { get; init; }

  [JsonProperty("postalCode")]
  public string PostalCode { get; init; }

  [JsonProperty("city")]
  public string City { get; init; }

  [JsonProperty("country")]
  public string Country { get; init; }

  [JsonProperty("region")]
  public string Region { get; init; }

  [JsonProperty("email")]
  public string Email { get; init; }

  [JsonProperty("phone")]
  public string Phone { get; init; }

  [JsonProperty("mobile")]
  public string Mobile { get; init; }

  [JsonProperty("fax")]
  public string Fax { get; init; }

  [JsonProperty("additionalInfo")]
  public string AdditionalInfo { get; init; }
}

[JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
public record PermissionDto()
{
  [JsonProperty("sms")]
  public bool Sms { get; init; }

  [JsonProperty("push")]
  public bool Push { get; init; }

  [JsonProperty("email")]
  public bool Email { get; init; }

  [JsonProperty("post")]
  public bool Post { get; init; }

  [JsonProperty("phone")]
  public bool Phone { get; init; }

  [JsonProperty("info")]
  public bool Info { get; init; }

  [JsonProperty("adverts")]
  public bool Adverts { get; init; }

  [JsonProperty("facebook")]
  public bool Facebook { get; init; }

  [JsonProperty("segmentation")]
  public bool Segmentation { get; init; }

  [JsonProperty("removeAvatar")]
  public bool RemoveAvatar { get; init; }

}

/// <summary>
/// Customer Attributes (like if person is an adult, is alive, etc)
/// Used when receiving Customer Information
/// </summary>
[JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
public record AttributeDto()
{
  [JsonProperty("code")]
  public string Code { get; init; }

  [JsonProperty("value")]
  public string Value { get; init; }
}

/// <summary>
/// Customer Attributes (like if person is an adult, is alive, etc)
/// Used when updating Customer Information -> only used in Patch request
/// </summary>
[JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
public record PatchAttributeDto()
{
  [JsonProperty("code")]
  public string Code { get; init; }

  [JsonProperty("value")]
  public string Value { get; init; }

  /// <summary>
  /// Operation: add or remove
  /// </summary>
  [JsonProperty("op")]
  public string Op { get; init; }
}
