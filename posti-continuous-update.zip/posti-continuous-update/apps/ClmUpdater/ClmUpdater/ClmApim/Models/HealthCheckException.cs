﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClmUpdater.ClmApim.Models;
public class HealthCheckException : ApplicationException
{
  public HealthCheckException(string message, Exception e) : base(message, e) { }
  public HealthCheckException(string message) : base(message) { }
}
