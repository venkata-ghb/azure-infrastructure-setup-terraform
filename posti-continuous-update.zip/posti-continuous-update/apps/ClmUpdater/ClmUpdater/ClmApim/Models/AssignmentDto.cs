﻿using System;
using System.Collections.Generic;
using ClmUpdater.Tools;
using Newtonsoft.Json;

namespace ClmUpdater.ClmApim.Models;

/// <summary>
/// Customer assingment in CLM. Used for exmple to set information that customer's address was validated
/// </summary>
[JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
public record AssignmentDto()
{
  [JsonProperty("id")]
  public int? Id { get; set; }
  [JsonProperty("value")]
  public string Value { get; set; }
  [JsonProperty("startDate")]
  [JsonConverter(typeof(ClmDateTimeConverter))]
  public DateTime StartDate { get; set; }
  public List<AttributeDto> Attribute { get; set; }
  [JsonProperty("code")]
  public string Code { get; set; }
}
