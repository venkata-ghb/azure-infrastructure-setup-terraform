﻿namespace ClmUpdater.ClmApim.Models;

public enum ClmResponseStatus
{
  Success,
  Fail,
  ActionNoNeeded,
  Conflict
}

