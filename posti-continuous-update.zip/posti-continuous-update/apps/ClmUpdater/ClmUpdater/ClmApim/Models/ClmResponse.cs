﻿using ClmUpdater.Models;

namespace ClmUpdater.ClmApim.Models;
public class ClmResponse
{
  public ClmResponseStatus ResponseStatus { get; init; }
  public ClmChangeStatus ChangeStatus { get; init; }
  public string CustomerId { get; init; }

  private ClmResponse(ClmResponseStatus responseStatus, ClmChangeStatus changeStatus, string customerId)
  {
    ResponseStatus = responseStatus;
    ChangeStatus = changeStatus;
    CustomerId = customerId;
  }

  public static ClmResponse CreateSuccessStatus(ClmChangeStatus changeStatus, string customerId)
      => new ClmResponse(ClmResponseStatus.Success, changeStatus, customerId);
  public static ClmResponse CreateFailedStatus(ClmChangeStatus changeStatus, string customerId)
      => new ClmResponse(ClmResponseStatus.Fail, changeStatus, customerId);
  public static ClmResponse CreateConflictStatus(ClmChangeStatus changeStatus, string customerId)
      => new ClmResponse(ClmResponseStatus.Conflict, changeStatus, customerId);
  public static ClmResponse CreateActionNoNeededStatus(ClmChangeStatus changeStatus, string customerId)
      => new ClmResponse(ClmResponseStatus.ActionNoNeeded, changeStatus, customerId);
}
