﻿using System;
using ClmUpdater.ClmApim.Models;

namespace ClmUpdater.ClmApim;
public class OAuthToken
{
  /// <summary>
  /// How long before actual expiration we want to get a new token
  /// </summary>
  private static readonly TimeSpan ExpirationThreshold = new(0, 5, 0);

  /// <summary>
  /// When we consider the token expired
  /// </summary>
  public DateTime Expiration;

  /// <summary>
  /// The oauth bearer token
  /// </summary>
  public string Token;

  /// <summary>
  /// Value for auth header.
  /// </summary>
  public string AuthorizationHeaderValue;

  public bool HasExpired => Expiration < DateTime.UtcNow;

  public OAuthToken(ZuulSuccessResponse response)
  {
    Expiration = DateTime.UtcNow
        .AddSeconds(response.ExpiresIn)
        .Add(-ExpirationThreshold);

    Token = response.AccessToken;
    //We do the trim in case of getting empty access token, so AuthService can handle empty string/null
    AuthorizationHeaderValue = $"{response.TokenType} {response.AccessToken}".Trim();
  }
}
