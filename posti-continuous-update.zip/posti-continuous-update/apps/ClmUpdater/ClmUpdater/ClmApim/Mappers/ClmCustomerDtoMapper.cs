﻿using System;
using System.Collections.Generic;
using System.Net;
using ClmUpdater.ClmApim.Models;
using ClmUpdater.Models;

namespace ClmUpdater.ClmApim.Mappers;

public interface IClmCustomerDtoMapper
{
  public ClmCustomerDto Map(ClmChangeModel clmChangeModel);
  public ClmCustomerDto MapForDuplicate(string customerNumber, string duplicateId);
  public ClmCustomerDto MapForCLMDuplicate(string duplicateFieldMessage);
}

public class ClmCustomerDtoMapper : IClmCustomerDtoMapper
{

  public ClmCustomerDto Map(ClmChangeModel clmChangeModel)
  {
    if (clmChangeModel is null) return null;

    var dto = new ClmCustomerDto()
    {
      Address = MapAddress(clmChangeModel.Address),
      PatchAttributes = MapAttributes(clmChangeModel),
      FirstName = clmChangeModel.FirstName,
      LastName = clmChangeModel.LastName
    };

    return dto;
  }

  public ClmCustomerDto MapForDuplicate(string customerNumber, string duplicateId)
  {

    return new ClmCustomerDto()
    {
      PatchAttributes = new List<PatchAttributeDto>()
      {
        new PatchAttributeDto()
        {
          Code = ClmUpdaterConstants.DuplicateField,
          Value = $"{customerNumber}, {duplicateId}",
          Op = "add"
        }
      }
    };
  }

  public ClmCustomerDto MapForCLMDuplicate(string duplicateFieldMessage)
  {

    return new ClmCustomerDto()
    {
      PatchAttributes = new List<PatchAttributeDto>()
      {
        new PatchAttributeDto()
        {
          Code = ClmUpdaterConstants.DuplicateField,
          Value = duplicateFieldMessage,
          Op = "add"
        }
      }
    };
  }

  private AddressDto MapAddress(ClmAddress address)
  {
    if (address is null) return null;

    return new AddressDto()
    {
      City = string.IsNullOrEmpty(address.City) ? null : address.City,
      PostalCode = string.IsNullOrEmpty(address.PostalCode) ? null : address.PostalCode,
      Street = string.IsNullOrEmpty(address.Street) ? null : address.Street,
      Phone = string.IsNullOrEmpty(address.Telephone) ? null : address.Telephone,
      Country = SetCountryCode(address.CountryCode)
    };
  }

  private string SetCountryCode(string countryCode)
  {
    if (string.IsNullOrEmpty(countryCode)) return ClmUpdaterConstants.EmptyCountryCode;
    //If AX is the country code, which means user is moved out of Posti's delivery zone (Ahvenanmaa). Setting the country code as FI
    if (countryCode.Equals(ClmUpdaterConstants.AhvenanmaaCountryCode, StringComparison.OrdinalIgnoreCase))
      return ClmUpdaterConstants.DefaultCountryCode;

    return countryCode;
  }

  private List<PatchAttributeDto> MapAttributes(ClmChangeModel clmChangeModel)
  {
    var attributes = MapStatus(clmChangeModel.PersonStatus);
    if (clmChangeModel.Address != null && clmChangeModel.Address.CountryCode == ClmUpdaterConstants.AhvenanmaaCountryCode)
    {
      if(attributes == null)
      {
        attributes = new List<PatchAttributeDto>()
        {
          new PatchAttributeDto()
          {
            Code = ClmUpdaterConstants.DuplicateField,
            Value = ClmUpdaterConstants.AhvenanmaaMessage,
            Op = "add"
          }
        };
      }
      else
      {
        attributes.Add(new PatchAttributeDto()
        {
          Code = ClmUpdaterConstants.DuplicateField,
          Value = ClmUpdaterConstants.AhvenanmaaMessage,
          Op = "add"
        });
      }
    }

    return attributes;
  }

  private List<PatchAttributeDto> MapStatus(ClmPersonStatus status)
  {
    if (status == null)
      return null;

    var attributesToUpdate = new List<PatchAttributeDto>();

    if (status.IsDeceased.HasValue && status.IsDeceased.Value)
    {
      var attributeDto = new PatchAttributeDto()
      {
        Code = "CUS_DECEASED",
        Value = "1",
        Op = "add"
      };
      attributesToUpdate.Add(attributeDto);
      return attributesToUpdate;
    }

    if (status.IsMinor.HasValue)
    {
      var attributeDto = new PatchAttributeDto()
      {
        Code = "CUS_TAYSI_IKA",
        Value = status.IsMinor.Value ? "0" : "1",
        Op = "add"
      };
      attributesToUpdate.Add(attributeDto);
    }

    return attributesToUpdate.Count > 0 ? attributesToUpdate : null;
  }
}


