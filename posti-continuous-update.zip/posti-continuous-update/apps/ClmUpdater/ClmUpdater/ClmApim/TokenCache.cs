﻿using System.Threading;

namespace ClmUpdater.ClmApim;

public interface ITokenCache
{
  SemaphoreSlim TokenSemaphore { get; }
  OAuthToken? Token { get; set; }
}

public class TokenCache : ITokenCache
{
  public SemaphoreSlim TokenSemaphore { get; init; }
  public OAuthToken? Token { get; set; }

  public TokenCache()
  {
    TokenSemaphore = new SemaphoreSlim(1, 1);
  }
}
