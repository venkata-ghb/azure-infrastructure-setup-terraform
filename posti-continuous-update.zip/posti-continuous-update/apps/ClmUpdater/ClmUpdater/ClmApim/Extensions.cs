﻿using ClmUpdater.ClmApim.Mappers;
using ClmUpdater.Tools;
using Microsoft.Extensions.DependencyInjection;

namespace ClmUpdater.ClmApim;
public static class Extensions
{
  public static IServiceCollection RegisterClmApim(this IServiceCollection services)
  {
    services.AddTransient<BearerTokenHandler>();
    services.AddTransient<PollyContextHandler>();
    services.AddScoped<IClmCustomerDtoMapper, ClmCustomerDtoMapper>();
    services.AddSingleton<ITokenCache, TokenCache>();
    services.AddHttpClient<IAuthorizationService, AuthorizationService>();
    services.AddHttpClient<ICustomerProfileService, CustomerProfileService>()
      .AddHttpMessageHandler<PollyContextHandler>()
      .AddPolicyHandler(PollyPoliciesFactory.CreateRetryPolicy())
      .AddHttpMessageHandler<BearerTokenHandler>();

    return services;
  }
}


