﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using ClmUpdater.ClmApim.Mappers;
using ClmUpdater.ClmApim.Models;
using ClmUpdater.Config.Models;
using ClmUpdater.Models;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace ClmUpdater.ClmApim;

public interface ICustomerProfileService
{
  public Task<List<ClmResponse>> ProcessChangesAsync(List<ClmChangeModel> changes);
  public Task<ClmResponse> ModifyCustomerAsync(ClmChangeModel changeModel);
  public Task<ClmResponse> SetDuplicateAttribute(ClmChangeModel changeModel);
  public Task<ClmResponse> MarkIdentifiedAssignment(string customerId, bool wasIdentified);
  public Task<ClmResponse> SetCLMDuplicateAttribute(ClmChangeModel changeModel);
  public Task HealthCheckCall();
}

public class CustomerProfileService : ICustomerProfileService
{
  private readonly HttpClient _httpClient;
  private readonly IClmCustomerDtoMapper _mapper;
  private readonly ILogger<CustomerProfileService> _logger;
  private readonly ClmProfileSettings _settings;

  
  public CustomerProfileService(HttpClient httpClient, ClmProfileSettings settings, IClmCustomerDtoMapper mapper, ILogger<CustomerProfileService> logger)
  {
    _httpClient = httpClient;
    _httpClient.BaseAddress = new System.Uri(settings.BaseUrl);
    _mapper = mapper;
    _logger = logger;
    _settings = settings;
  }

  public async Task HealthCheckCall()
  {
    var route = $"search?customer.customerId=19999999999991&customer.firstName=dummy-user";//Some dummy user sent to search. Expecting empty array
    var response = await _httpClient.GetAsync(route);

    if (response.IsSuccessStatusCode == false)
    {
      var errorResponseMessage = await response.Content.ReadAsStringAsync();
      _logger.LogError("CLM API Health Check Failed with \n" +
        "Status code: {statusCode}\n" +
        "Reason: {reason}\n" +
        "Response message: {response}",
        response.StatusCode,
        response.ReasonPhrase,
        errorResponseMessage);
      throw new HealthCheckException($"Health check failed: {response.StatusCode}, {response.ReasonPhrase}, {errorResponseMessage}");
    }

    _logger.LogInformation("CLM API Health Check Succeeded");
  }

  public async Task<ClmResponse> ModifyCustomerAsync(ClmChangeModel changeModel)
  {
    if (_settings.DisableProcessingChanges)
    {
      _logger.LogInformation("Processing changes disabled. Skipping");
      return ClmResponse.CreateActionNoNeededStatus(ClmChangeStatus.Ignore, changeModel.CustomerId);
    }
    
    LogCustomerToBeModified(changeModel);
    
    var route = $"customers/{changeModel.CustomerId}";
    var dto = _mapper.Map(changeModel);
    if (changeModel.Address != null && changeModel.Address.CountryCode == ClmUpdaterConstants.AhvenanmaaCountryCode)
    {
      _logger.LogInformation($"Setting Ahvenanmaalainen osoite for customer {changeModel.CustomerId}");
    }
    string json = JsonConvert.SerializeObject(dto);
    var httpContent = new StringContent(json, Encoding.UTF8, "application/json");
    var response = await _httpClient.PatchAsync(route, httpContent);

    if(response.StatusCode == System.Net.HttpStatusCode.Conflict)
    {
      return await PrepareClmResponse(response, ClmChangeStatus.Conflict, changeModel.CustomerId);
    }

    return await PrepareClmResponse(response, ClmChangeStatus.CustomerUpdated, changeModel.CustomerId);
  }

  public async Task<ClmResponse> SetDuplicateAttribute(ClmChangeModel changeModel)
  {
    if (_settings.DisableProcessingChanges)
    {
      _logger.LogInformation("Processing changes disabled. Skipping");
      return ClmResponse.CreateActionNoNeededStatus(ClmChangeStatus.Ignore, changeModel.CustomerId);
    }

    LogCustomerToBeModified(changeModel);
    var route = $"customers/{changeModel.CustomerId}";
    
    var dto = _mapper.MapForDuplicate(changeModel.CustomerId, changeModel.DuplicatedId);
    string json = JsonConvert.SerializeObject(dto);
    var httpContent = new StringContent(json, Encoding.UTF8, "application/json");
    var response = await _httpClient.PatchAsync(route, httpContent);
    return await PrepareClmResponse(response, ClmChangeStatus.PersonDuplicated, changeModel.CustomerId);
  }

  public async Task<ClmResponse> SetCLMDuplicateAttribute(ClmChangeModel changeModel)
  {
    if (_settings.DisableProcessingChanges)
    {
      _logger.LogInformation("Processing changes disabled. Skipping");
      return ClmResponse.CreateActionNoNeededStatus(ClmChangeStatus.Ignore, changeModel.CustomerId);
    }

    LogCustomerToSetDuplicateFieldValueMessage(changeModel);
    var route = $"customers/{changeModel.CustomerId}";
    var dto = _mapper.MapForCLMDuplicate(ClmUpdaterConstants.DuplicateFieldValueMessage);
    string json = JsonConvert.SerializeObject(dto);
    _logger.LogInformation(json);
    var httpContent = new StringContent(json, Encoding.UTF8, "application/json");
    var response = await _httpClient.PatchAsync(route, httpContent);
    return
      await PrepareClmResponse(response, ClmChangeStatus.PersonDuplicated, changeModel.CustomerId);
  }

  public async Task<ClmResponse> MarkIdentifiedAssignment(string customerId, bool wasIdentified)
  {
    if (_settings.DisableProcessingChanges)
    {
      _logger.LogInformation("Processing changes disabled. Skipping");
      return ClmResponse.CreateActionNoNeededStatus(ClmChangeStatus.Ignore, customerId);
    }

    LogCustomerToBeIdentified(customerId, wasIdentified);

    //Get all customer assignments and check if CUS_OSOITEVALIDOINTI exists
    var assignments = await GetCustomerAssingmentsAsync(customerId);

    //if there was an error while fetching the assignment list just return failed status
    if (assignments is null)
      return ClmResponse.CreateFailedStatus(ClmChangeStatus.IdentifiedAssignmentSet, customerId);

    var newAssignmentValue = wasIdentified ? ClmUpdaterConstants.Identified : ClmUpdaterConstants.NotIdentified;
    var assignmentId = GetAddressIdentifiedAssignmentId(assignments, newAssignmentValue);

    //If assignment value is same as new one, ignore
    if(assignmentId == -1)
    {
      _logger.LogInformation($"Assignment value is either NV or same as existing one for customer {customerId}. No change needed. Skipping");
      return ClmResponse.CreateActionNoNeededStatus(ClmChangeStatus.Ignore, customerId);
    }


    //If assignment doesn't exist (id is 0) then add new one
    //If assignment does exist (id is not 0) then update the existing one
    var response = assignmentId is 0 ?
      await PostNewAddressIdentifiedAssignmentAsync(customerId, wasIdentified) :
      await PutNewAddressIdentifiedAssignmentAsync(customerId, assignmentId, wasIdentified);

    return await PrepareClmResponse(response, ClmChangeStatus.IdentifiedAssignmentSet, customerId);
  }

  private async Task<HttpResponseMessage> PostNewAddressIdentifiedAssignmentAsync(string customerId, bool wasIdentified)
  {
    var route = $"customers/{customerId}/assignments";
    var dto = new AssignmentDto() {
      Value = wasIdentified ? ClmUpdaterConstants.Identified : ClmUpdaterConstants.NotIdentified,
      Code = ClmUpdaterConstants.AddressValidationStatusField,
      StartDate = DateTime.Now
    };
    string json = JsonConvert.SerializeObject(dto);
    LogAddingAddressIndentifiedAssignment(customerId, json);
    var httpContent = new StringContent(json, Encoding.UTF8, "application/json");
    return await _httpClient.PostAsync(route, httpContent);
  }

  private async Task<HttpResponseMessage> PutNewAddressIdentifiedAssignmentAsync(string customerId, int assignmentid, bool wasIdentified)
  {
    var route = $"customers/{customerId}/assignments/{assignmentid}";
    var dto = new AssignmentDto() {
      Value = wasIdentified ? ClmUpdaterConstants.Identified : ClmUpdaterConstants.NotIdentified,
      StartDate = DateTime.Now
    };
    string json = JsonConvert.SerializeObject(dto);
    LogUpdatingAddressIdentifiedAssigment(customerId, assignmentid, json);
    var httpContent = new StringContent(json, Encoding.UTF8, "application/json");
    return await _httpClient.PutAsync(route, httpContent);
  }

  private async Task<List<AssignmentDto>> GetCustomerAssingmentsAsync(string customerId)
  {
    var route = $"customers/{customerId}/assignments";
    var response = await _httpClient.GetAsync(route);
    var json = await response.Content.ReadAsStringAsync();
    if (!response.IsSuccessStatusCode)
    {
      LogUnsuccessfulAssignmentFetch(response, json);
      return null;
    }

    var userAssingments = JsonConvert.DeserializeObject<List<AssignmentDto>>(json);
    return userAssingments;
  }

  private int GetAddressIdentifiedAssignmentId(List<AssignmentDto> assingments, string newValue)
  {
    var assignment = assingments.Where(assignment => assignment.Code.Equals(ClmUpdaterConstants.AddressValidationStatusField)).FirstOrDefault();
    if(assignment == null)
    {
      return 0;
    }
    if (assignment != null && (assignment.Value.Equals("NV") || assignment.Value.Equals(newValue)))
    {
      return -1;
    }
    
    return (int)assignment.Id;
  }

  private async Task<ClmResponse> PrepareClmResponse(HttpResponseMessage response, ClmChangeStatus status, string customerId)
  {

    if(response.StatusCode == System.Net.HttpStatusCode.Conflict)
    {
      var errorResponseMessage = await response.Content.ReadAsStringAsync();
      LogFailedRequestResponse(response, errorResponseMessage);
      return ClmResponse.CreateConflictStatus(status, customerId);
    }
    if (!response.IsSuccessStatusCode)
    {
      var errorResponseMessage = await response.Content.ReadAsStringAsync();
      LogFailedRequestResponse(response, errorResponseMessage);
      return ClmResponse.CreateFailedStatus(status, customerId);
    }
    return ClmResponse.CreateSuccessStatus(status, customerId);
  }

  public async Task<List<ClmResponse>> ProcessChangesAsync(List<ClmChangeModel> changes)
  {
    var tasks = new List<Task>();
    var results = new List<ClmResponse>();

    if (_settings.DisableProcessingChanges)
    {
      LogDisableProcessing(changes);
      return results;
    }

    foreach (ClmChangeModel model in changes)
    {

      var assignments = await GetCustomerAssingmentsAsync(model.CustomerId);
      if (assignments is null)
      {
        continue;
      }
      var assignment = assignments.Where(assignment => assignment.Code.Equals(ClmUpdaterConstants.AddressValidationStatusField, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
      if(assignment != null && assignment.Value == "NV")
      {
        continue;
      }
      tasks.AddRange(RunChangeAction(model));
    }

    await Task.WhenAll(tasks);
    foreach (Task<ClmResponse> t in tasks)
    {
      results.Add(t.Result);
    }

    return results;
  }

  private List<Task> RunChangeAction(ClmChangeModel changeModel)
  {
    var tasks = new List<Task>();
    
    //if user is duplicated do nothing and just return the task array
    if (changeModel.ChangeStatus.IsDuplicated.HasValue && changeModel.ChangeStatus.IsDuplicated.Value)
    {
      //TODO: set attribute that should trigger fraud rule on the CLM side
      //Add NI as assignment attribute.
      LogDuplicatedUser(changeModel);
      tasks.Add(SetDuplicateAttribute(changeModel));
      tasks.Add(MarkIdentifiedAssignment(changeModel.CustomerId, false));
      return tasks;
    }

    //Set address identified assignment in CLM to Identified or Not Identified
    //Don't change address identified assignment if the person is deceased 
    if (changeModel.ChangeStatus.WasIdentified.HasValue)
    {
      tasks.Add(MarkIdentifiedAssignment(changeModel.CustomerId, changeModel.ChangeStatus.WasIdentified.Value));
    }

    //If person was not identified, just return from function (there is nothing to modify for the unidentfied person
    if (changeModel.ChangeStatus.WasIdentified.Value == false)
      return tasks;

    //Update address, person status and name 
    if (changeModel.ChangeStatus.WasModified.HasValue && changeModel.ChangeStatus.WasModified.Value)
    {
      tasks.Add(ModifyCustomerAsync(changeModel));
    }

    return tasks;
  }

  private void LogUnsuccessfulAssignmentFetch(HttpResponseMessage response, string json)
  {
    _logger.LogInformation("Fetching assignments was unsuccessful\n" +
            "Status code: {statusCode}\n" +
            "Reason: {reason}\n" +
            "Response content: {response}",
            response.StatusCode,
            response.ReasonPhrase,
            json);
  }

  private void LogDisableProcessing(List<ClmChangeModel> changes)
  {
    _logger.LogInformation("Processing changes disabled. Skipping.\n" +
            "Changes: {changes}", JsonConvert.SerializeObject(changes));
  }

  private void LogCustomerToBeIdentified(string customerId, bool wasIdentified)
  {
    _logger.LogInformation("Customer to be marked as identified:\n" +
                "CustomerId: {customerId}\n" +
                "Identification status: {wasIdentified}", customerId, wasIdentified);
  }

  private void LogAddingAddressIndentifiedAssignment(string customerId, string json)
  {
    _logger.LogInformation("POST Address Identifier assignment\n" +
      "Customer Id: {customerId}\n" +
      "Request: {json}",
      customerId,
      json);
  }

  private void LogUpdatingAddressIdentifiedAssigment(string customerId, int assignmentid, string json)
  {
    _logger.LogInformation("PUT Address Identifier assignment\n" +
          "Customer Id: {customerId}\n" +
          "AssignmentId: {assignmentId}\n" +
          "Request: {json}",
          customerId,
          assignmentid,
          json);
  }

  private void LogCustomerToBeModified(ClmChangeModel changeModel)
  {
    _logger.LogInformation("Customer to be modified:\n" +
                "CustomerId: {customerId}\n" +
                "LastName: {lastName}\n" +
                "Postal Code: {postalCode}\n" +
                "Is minor: {isMinor}\n" +
                "Is deceased: {isDeceased}\n",
                changeModel.CustomerId,
                changeModel.LastName,
                changeModel.Address?.PostalCode,
                changeModel.PersonStatus?.IsMinor,
                changeModel.PersonStatus?.IsDeceased
                );
  }

  private void LogCustomerToSetDuplicateFieldValueMessage(ClmChangeModel changeModel)
  {
    _logger.LogInformation("Customer is updated with attribute Mahdollinen duplikaattijäsenyys:\n" +
                "CustomerId: {customerId}\n" +
                "CUS_POSTIN_TUPLAT: Mahdollinen duplikaattijäsenyys - Postin päivitys epäonnistui",
                changeModel.CustomerId
                );
  }

  private void LogFailedRequestResponse(HttpResponseMessage message, string errorResponse)
  {
    _logger.LogError("Clm request failed \n" +
        "Status code: {statusCode}\n" +
        "Reason: {reason}\n" +
        "Response message: {response}",
        message.StatusCode,
        message.ReasonPhrase,
        errorResponse);
  }

  private void LogDuplicatedUser(ClmChangeModel changeModel)
  {
    _logger.LogInformation("Customer with following id was duplicated\n" +
            "CustomerId: {customerId}\n" +
            "DuplicatedId {duplicatedId}", changeModel.CustomerId, changeModel.DuplicatedId);
  }
}
