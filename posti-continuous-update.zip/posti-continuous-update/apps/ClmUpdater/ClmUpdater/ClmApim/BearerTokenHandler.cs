﻿using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace ClmUpdater.ClmApim;
public class BearerTokenHandler : DelegatingHandler
{
  private readonly IAuthorizationService _authService;

  public BearerTokenHandler(IAuthorizationService authService)
      => _authService = authService;

  protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
  {
    if (!request.Headers.Contains("Ocp-Apim-Subscription-Key"))
    {
      await _authService.AddAuthHeader(request, cancellationToken);
      _authService.AddApiKeyHeader(request);
    }

    return await base.SendAsync(request, cancellationToken);
  }
}
