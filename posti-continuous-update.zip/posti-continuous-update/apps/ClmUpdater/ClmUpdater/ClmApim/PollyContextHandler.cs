﻿using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using ClmUpdater.Tools;
using Microsoft.Extensions.Logging;
using Polly;

namespace ClmUpdater.ClmApim;
public class PollyContextHandler : DelegatingHandler
{
  private readonly ILogger<ICustomerProfileService> _logger;

  public PollyContextHandler(ILogger<ICustomerProfileService> logger)
  {
    _logger = logger;
  }

  protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
  {
    var pollyContext = new Context()
      .WithLogger(_logger)
      .WithRequest(request);
    request.SetPolicyExecutionContext(pollyContext);

    return await base.SendAsync(request, cancellationToken);
  }
}
