﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using ClmUpdater.CosmosDb.Models;
using ClmUpdater.Models;

namespace ClmUpdater.Mappers;

public interface IClmChangeMapper
{
  public List<ClmChangeModel> Map(List<PostiCustomerChangeDto> dtos);
  public ClmChangeModel Map(PostiCustomerChangeDto dto);

  public List<ClmChangeModel> Map(List<ClmUpdateErrorDocument> documents);
  public ClmChangeModel Map(ClmUpdateErrorDocument document);
}

public class ClmChangeMapper : IClmChangeMapper
{
  private const string _foreignPostalCode = "00000";
  private const string _foreignCityCode = "Ulkomaa";
  private const string _finlandDefaultCityCode = "Tuntematon";
  private const string _localCountryName = "Finland";
  private const string _localCountryCode = "FI";

  public List<ClmChangeModel> Map(List<PostiCustomerChangeDto> dtos)
  {
    var models = new List<ClmChangeModel>();
    dtos.ForEach(dto => models.Add(Map(dto)));
    return models;
  }

  public ClmChangeModel Map(PostiCustomerChangeDto dto)
  {
    var clmChange = new ClmChangeModel()
    {
      ChangeStatus = new ChangeStatus()
      {
        IsDuplicated = dto.PostiChangeStatus.IsDuplicated,
        WasIdentified = dto.PostiChangeStatus.WasIdentified,
        WasModified = dto.PostiChangeStatus.WasModified,
      },
      CustomerId = dto.CustomerId,
      DuplicatedId = dto.DuplicatedId,
      FirstName = dto.FirstName,
      LastName = dto.LastName,
      Address = MapDtoToAddress(dto),
      PersonStatus = MapDtoToPersonStatus(dto),
      Ssn = dto.Ssn
    };

    return clmChange;
  }

  private ClmAddress MapDtoToAddress(PostiCustomerChangeDto dto)
  {
    if (dto.Address is null && dto.ForeignAddress is null)
      return null;

    if (dto.Address is not null)
      return MapLocalDtoToAddress(dto);

    return MapForeignDtoToAddress(dto);
  }


  private ClmAddress MapLocalDtoToAddress(PostiCustomerChangeDto dto)
  {
    if (dto.Address is null)
      return null;

    var address = new ClmAddress()
    {
      City = dto.Address.City,
      PostalCode = dto.Address.PostalCode,
      Street = dto.Address.Street,
      CountryName = _localCountryName,
      CountryCode = _localCountryCode.ToUpper()
    };
    return address;
  }

  private static ClmAddress MapForeignDtoToAddress(PostiCustomerChangeDto dto)
  {
    if (dto.ForeignAddress is null)
      return null;
    var (city, postalCode, street) = MapAhvenanmaaAddress(dto.ForeignAddress);
    if (city != null && postalCode != null && street != null)
    {
      return new ClmAddress()
      {
        City = city,
        PostalCode = postalCode,
        Street = street,
        CountryName = _localCountryName,
        CountryCode = _localCountryCode,
      };
    }
    return new ClmAddress()
    {
      City = city,
      PostalCode = postalCode,
      Street = string.IsNullOrEmpty(street) ? MapOtherAddressLineToSingleLine(dto.ForeignAddress) : street,
      CountryName = dto.ForeignAddress.CountryName,
      CountryCode = dto.ForeignAddress.CountryCode?.ToUpper(),
    };

    static string MapOtherAddressLineToSingleLine(PostiForeignAddressDto dto)
    {
      return string.Join(" ", dto.OtherAddressLine1, dto.OtherAddressLine2, dto.OtherAddressLine3, dto.OtherAddressLine4).Trim();
    }

  }
  //This is added to check if foreign country is AX, i.e. Ahvenanmaa and postal code starts with 22.
  private static (string, string, string) MapAhvenanmaaAddress(PostiForeignAddressDto dto)
  {
    //If country code is null or empty then use the default values for foreign addresses.
    if (string.IsNullOrEmpty(dto.CountryCode)) return (_foreignCityCode, _foreignPostalCode, null);
    //If country code is not 'AX' the use the default values for foreign addresses.
    if (!dto.CountryCode.Equals(ClmUpdaterConstants.AhvenanmaaCountryCode, StringComparison.OrdinalIgnoreCase)) return (_foreignCityCode, _foreignPostalCode, null);

    if (dto.CountryCode.Equals(ClmUpdaterConstants.AhvenanmaaCountryCode, StringComparison.OrdinalIgnoreCase))
    {
      var cityName = string.Empty;
      var postCode = string.Empty;
      var streetName = string.Empty;
      string pattern = @"(?:AX-?|)?(22\d{3})\s+(\w+)"; // 5-digit postal code starting with "22"
      var addressLines = string.Join(" ", dto.OtherAddressLine1, dto.OtherAddressLine2, dto.OtherAddressLine3, dto.OtherAddressLine4).Trim();
      if (!string.IsNullOrEmpty(addressLines))
      {
        Regex regex = new Regex(pattern);
        Match match = regex.Match(addressLines);
        if (match.Success)
        {
          postCode = match.Groups[1].Value;
          cityName = match.Groups[2].Value;
          if (string.IsNullOrEmpty(cityName)) { cityName = _foreignCityCode; }
          addressLines = addressLines.Replace(postCode, "").Trim();
          addressLines = addressLines.Replace("AX-", "").Trim();
          addressLines = addressLines.Replace("AX", "").Trim();
          addressLines = addressLines.Replace(cityName, "").Trim();
          addressLines = Regex.Replace(addressLines, @"\s+", " ").Trim();
          streetName = addressLines;
        }
        else
        {
          string postalPattern = @"\b22\d{3}\b";
          Match postalMatch = Regex.Match(addressLines, postalPattern);
          if (postalMatch.Success)
          {
            postCode = postalMatch.Value;
            cityName = _finlandDefaultCityCode;
            addressLines = addressLines.Replace(postCode, "").Trim();
            addressLines = addressLines.Replace("AX-", "").Trim();
            addressLines = addressLines.Replace("AX", "").Trim();
            addressLines = Regex.Replace(addressLines, @"\s+", " ").Trim();
            streetName = addressLines;
          }
          else
          {
            postCode = _foreignPostalCode;
            cityName = _finlandDefaultCityCode;
            addressLines = addressLines.Replace("AX-", "").Trim();
            addressLines = addressLines.Replace("AX", "").Trim();
            addressLines = Regex.Replace(addressLines, @"\s+", " ").Trim();
            streetName = addressLines;
          }
        }

        return (cityName, postCode, streetName);
      }
    }

    //If address line 2 and address line 3 field, both, are null or empty, use the default values for foreign addresses.
    if (string.IsNullOrEmpty(dto.OtherAddressLine3) && string.IsNullOrEmpty(dto.OtherAddressLine2)) return (_foreignCityCode, _foreignPostalCode, null);

    //The Ahvenanmaa postal code most probably will be found in addressline2 field.
    //If it is not found in address line 2, trying to get it from address line 3 field.
    //Else just return the default values for foreign addresses.
    //Also, removing postalcode and city from the street address.
    if (!string.IsNullOrEmpty(dto.OtherAddressLine2) && PostalCodeExistsOnAddressLine(dto.OtherAddressLine2))
    {
      var street = string.Join(" ", dto.OtherAddressLine1, dto.OtherAddressLine3, dto.OtherAddressLine4).Trim();
      var (city, postalCode) = AhvenanmaaAddressDetailsFromAddressLine(dto.OtherAddressLine2);
      return (city, postalCode, street);
    }
    else if (!string.IsNullOrEmpty(dto.OtherAddressLine3) && PostalCodeExistsOnAddressLine(dto.OtherAddressLine3))
    {
      var street = string.Join(" ", dto.OtherAddressLine1, dto.OtherAddressLine2, dto.OtherAddressLine4).Trim();
      var (city, postalCode) = AhvenanmaaAddressDetailsFromAddressLine(dto.OtherAddressLine3);
      return (city, postalCode, street);
    }

    return (_foreignCityCode, _foreignPostalCode, null);
  }

  private static bool PostalCodeExistsOnAddressLine(string addressLine)
  {
    if (addressLine.StartsWith(ClmUpdaterConstants.AhvenanmaaPostalCodePrefix))
    {
      var addressArray = addressLine.Split(' ');
      string mayBePostalCode = addressArray.First();
      return mayBePostalCode.Length == ClmUpdaterConstants.AhvenanmaaPostalCodeLength;
    }
    return false;    
  }

  private static (string, string) AhvenanmaaAddressDetailsFromAddressLine(string addressLine)
  {
    //The addressline value can be something like "22123 Abcdef", hence splitting it with space.
    var addressArray = addressLine.Split(' ');

    var postalCode = addressArray.FirstOrDefault();
    //The first element of the array is assumed to be the postal code and it should be of length 5.
    if (!string.IsNullOrEmpty(postalCode) && postalCode.Length == ClmUpdaterConstants.AhvenanmaaPostalCodeLength)
    {
      //Rest of the address line array, after removing postal code, is joined to create the name of the city.
      string city = string.Join(" ", addressArray.Skip(1));
      if (city.Trim().Length > 0)
      {
        return (city, postalCode);
      }
      else
      {
        return (_foreignCityCode, postalCode);
      }
    }
    return (_foreignCityCode, _foreignPostalCode);
  }

  private ClmPersonStatus MapDtoToPersonStatus(PostiCustomerChangeDto dto)
  {
    if (dto.PersonStatus is null)
      return null;

    var status = new ClmPersonStatus()
    {
      IsDeceased = dto.PersonStatus.IsDeceased,
      IsMinor = dto.PersonStatus.IsMinor
    };

    return status;
  }

  public List<ClmChangeModel> Map(List<ClmUpdateErrorDocument> documents)
  {
    var changesCollection = new List<ClmChangeModel>();
    documents.ForEach(document => changesCollection.Add(Map(document)));
    return changesCollection;
  }

  public ClmChangeModel Map(ClmUpdateErrorDocument document)
  {
    return new ClmChangeModel()
    {
      Ssn = document.Ssn,
      DuplicatedId = document.DuplicatedId,
      ChangeStatus = new ChangeStatus()
      {
        IsDuplicated = document.ChangeStatus.IsDuplicated,
        WasIdentified = document.ChangeStatus.WasIdentified,
        WasModified = document.ChangeStatus.WasModified
      },
      Address = new ClmAddress()
      {
        City = document.Address.City,
        CountryCode = document.Address.CountryCode,
        CountryName = document.Address.CountryName,
        PostalCode = document.Address.PostalCode,
        Street = document.Address.Street
      },
      CustomerId = document.CustomerId,
      FirstName = document.FirstName,
      LastName = document.LastName,
      PersonStatus = new ClmPersonStatus()
      {
        IsDeceased = document.PersonStatus.IsDeceased,
        IsMinor = document.PersonStatus.IsMinor
      }
    };
  }
}
