﻿using System;
using ClmUpdater.ClmApim.Models;
using Newtonsoft.Json;

namespace ClmUpdater.CosmosDb.Models;
public record ClmUpdateErrorDocument
{
  /// <summary>
  /// Id required by CosmosDB
  /// </summary>
  [JsonProperty("id")]
  public string Id { get; init; }

  [JsonProperty("changeStatus")]
  public ClmChangeStatusDocument ChangeStatus { get; init; }

  [JsonProperty("failedOperation")]
  public string FailedOperation { get; init; }

  [JsonProperty("timestamp")]
  public long Timestamp { get; init; }

  [JsonProperty("customerId")]
  public string CustomerId { get; init; }

  [JsonProperty("duplicatedId")]
  public string DuplicatedId { get; init; }

  [JsonProperty("ssn")]
  public string Ssn { get; init; }

  [JsonProperty("lastName")]
  public string LastName { get; init; }

  [JsonProperty("firstName")]
  public string FirstName { get; init; }

  [JsonProperty("address")]
  public ClmAddressDocument Address { get; init; }

  [JsonProperty("personStatus")]
  public ClmPersonStatusDocument PersonStatus { get; init; }
  public static ClmUpdateErrorDocument CreateFromChangeModelAndResponse(ClmChangeModel model, ClmResponse response, long timeStamp)
  {
    return new ClmUpdateErrorDocument()
    {
      Address = new ClmAddressDocument()
      {
        City = model.Address?.City,
        CountryCode = model.Address?.CountryCode,
        CountryName = model.Address?.CountryName,
        PostalCode = model.Address?.PostalCode,
        Street = model.Address?.Street,
        Telephone = model.Address?.Telephone,
      },
      FailedOperation = response.ChangeStatus.ToString(),
      ChangeStatus = new ClmChangeStatusDocument()
      {
        IsDuplicated = model.ChangeStatus.IsDuplicated,
        WasIdentified = model.ChangeStatus.WasIdentified,
        WasModified = model.ChangeStatus.WasModified
      },
      CustomerId = model.CustomerId,
      DuplicatedId = model.DuplicatedId,
      FirstName = model.FirstName,
      LastName = model.LastName,
      Timestamp = timeStamp,
      Id = $"{timeStamp}::{model.CustomerId}::{response.ChangeStatus}",
      PersonStatus = PreparePersonStatusDocument(model.PersonStatus)
    };

    ClmPersonStatusDocument PreparePersonStatusDocument(ClmPersonStatus clmPersonStatus)
    {
      if (clmPersonStatus == null)
        return null;

      return new ClmPersonStatusDocument()
      {
        IsDeceased = model.PersonStatus.IsDeceased,
        IsMinor = model.PersonStatus.IsMinor
      };
    }
  }
  public static ClmUpdateErrorDocument CreateFromErrorDocumentAndResponse(ClmUpdateErrorDocument error, ClmResponse response, long timeStamp)
  {
    return new ClmUpdateErrorDocument()
    {
      Address = error.Address,
      FailedOperation = response.ChangeStatus.ToString(),
      ChangeStatus = error.ChangeStatus,
      CustomerId = error.CustomerId,
      DuplicatedId = error.DuplicatedId,
      FirstName = error.FirstName,
      LastName = error.LastName,
      Timestamp = timeStamp,
      Id = $"{timeStamp}::{error.CustomerId}::{response.ChangeStatus}",
      PersonStatus = error.PersonStatus,
    };
  }
}



public record ClmAddressDocument
{

  [JsonProperty("city")]
  public string City { get; init; }

  [JsonProperty("postalCode")]
  public string PostalCode { get; init; }

  [JsonProperty("street")]
  public string Street { get; init; }

  [JsonProperty("telephone")]
  public string Telephone { get; init; }

  [JsonProperty("email")]
  public string Email { get; init; }

  [JsonProperty("countryCode")]
  public string CountryCode { get; init; }

  [JsonProperty("countryName")]
  public string CountryName { get; init; }
}

public record ClmChangeStatusDocument
{
  [JsonProperty("wasIdentified")]
  public bool? WasIdentified { get; init; }
  [JsonProperty("wasModified")]
  public bool? WasModified { get; init; }

  [JsonProperty("isDuplicated")]
  public bool? IsDuplicated { get; init; }
}

public record ClmPersonStatusDocument
{

  [JsonProperty("isMinor")]
  public bool? IsMinor { get; init; }

  [JsonProperty("isDeceased")]
  public bool? IsDeceased { get; init; }

  [JsonProperty("dateOfDeath")]
  public DateOnly? DateOfDeath { get; init; }
}
