﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using ClmUpdater.Config.Models;
using ClmUpdater.CosmosDb.Models;
using ClmUpdater.Tools;
using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.DataContracts;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace ClmUpdater.CosmosDb;
public interface ICosmosDbService
{
  Task<bool> StoreClmUpdateError(ClmUpdateErrorDocument document);
  Task<bool> DeleteClmUpdateErrors(DateTime? errorsDateTime = null);
  Task<bool> DeleteClmUpdateError(string clmErrorId, string partitionKeyString);
  Task HealthCheckCall();
  Task<List<ClmUpdateErrorDocument>> GetClmUpdateErrors();
}

public class CosmosDbService : ICosmosDbService
{
  private readonly ILogger<CosmosDbService> _logger;
  private readonly CosmosDbSettings _settings;
  private readonly CosmosClient _cosmosClient;
  private readonly TelemetryClient _telemetryClient;
  private readonly ICosmosLinqQuery _cosmosLinqQueryWrapper;
  private readonly ItemRequestOptions _defaultOptions = new() { EnableContentResponseOnWrite = false };


  public CosmosDbService(ILogger<CosmosDbService> logger, CosmosDbSettings settings, CosmosClient cosmosClient, TelemetryConfiguration telemetryConfiguration, ICosmosLinqQuery cosmosLinqQueryWrapper)
  {
    _logger = logger;
    _settings = settings;
    _cosmosClient = cosmosClient;
    _telemetryClient = new TelemetryClient(telemetryConfiguration);
    _cosmosLinqQueryWrapper = cosmosLinqQueryWrapper;
  }

  public async Task HealthCheckCall()
  {
    await _cosmosClient.GetContainer(_settings.Name, "Operations").ReadContainerAsync();
    await _cosmosClient.GetContainer(_settings.Name, "Configuration").ReadContainerAsync();
  }

  public async Task<bool> DeleteClmUpdateErrors(DateTime? errorDateTime = null)
  {
    var allClmUpdateErrors = await GetClmUpdateErrors();
    var varErrorsToRemove = errorDateTime == null ?
      allClmUpdateErrors :
      allClmUpdateErrors.Where(document => Utils.UnixSecondsToDateTime(document.Timestamp).ToUniversalTime() <= errorDateTime).ToList();

    var deletionTasks = new List<Task<bool>>();
    foreach (var postiError in varErrorsToRemove)
    {
      deletionTasks.Add(DeleteClmUpdateError(postiError.Id, postiError.FailedOperation));
    }
    var deletionResults = await Task.WhenAll(deletionTasks);

    return deletionResults.All(x => x);
  }

  public async Task<List<ClmUpdateErrorDocument>> GetClmUpdateErrors()
  {
    var postiErrorsContainer = _cosmosClient.GetContainer(_settings.Name, _settings.ClmUpdateErrorsContainer);
    var cosmosQuery = postiErrorsContainer
        .GetItemLinqQueryable<ClmUpdateErrorDocument>().Select(document => document);
    var cosmosOperation = new CosmosDependencyOperation("GetAllClmUpdateErrors");

    cosmosOperation.Data = _cosmosLinqQueryWrapper.GetQueryText(cosmosQuery);
    var resultsIterator = _cosmosLinqQueryWrapper.GetFeedIterator(cosmosQuery);

    try
    {
      var results = new List<ClmUpdateErrorDocument>();

      while (resultsIterator.HasMoreResults)
      {
        var response = await resultsIterator.ReadNextAsync();
        cosmosOperation.StatusCode = (int)response.StatusCode;
        cosmosOperation.RequestCharge += response.RequestCharge;
        foreach (var doc in response)
        {
          results.Add(doc);
        }
      }
      cosmosOperation.Success = true;
      LogSuccessfullyFetchedClmUpdateErrors(results);

      return results;
    }
    catch (CosmosException ex)
    {
      LogFailedFetchClmUpdateErrors(ex);
      cosmosOperation.StatusCode = (int)ex.StatusCode;
      cosmosOperation.RequestCharge = ex.RequestCharge;
      return null;
    }
    finally
    {
      TrackCosmosDependency(cosmosOperation);
    }
  }

  /// <summary>
  /// Remove error from batch container by error id 
  /// </summary>
  /// <param name="clmErrorId"></param>
  /// <returns></returns>
  public async Task<bool> DeleteClmUpdateError(string clmErrorId, string partitionKeyString)
  {
    LogDeletingClmUpdateError(clmErrorId);

    var partitionKey = new PartitionKey(partitionKeyString);
    var cosmosOperation = new CosmosDependencyOperation("DeletePostiError");

    try
    {
      var clmUpdateErrorContainer = _cosmosClient.GetContainer(_settings.Name, _settings.ClmUpdateErrorsContainer);
      var response = await clmUpdateErrorContainer.DeleteItemAsync<ClmUpdateErrorDocument>(clmErrorId, partitionKey, _defaultOptions);
      LogSuccesfulDeletionOfClmUpdateError(clmErrorId);

      cosmosOperation.Success = true;
      cosmosOperation.StatusCode = (int)response.StatusCode;
      cosmosOperation.RequestCharge = response.RequestCharge;
      return true;
    }
    catch (CosmosException ex)
    {
      LogFailedDeletionOfClmUpdateError(ex, clmErrorId);
      cosmosOperation.StatusCode = (int)ex.StatusCode;
      cosmosOperation.RequestCharge = ex.RequestCharge;
      return false;
    }
    finally
    {
      TrackCosmosDependency(cosmosOperation);
    }
  }

  public async Task<bool> StoreClmUpdateError(ClmUpdateErrorDocument document)
  {
    if (_settings.DisableStoreClmUpdateErrors)
    {
      LogDisabledErrorStoring();
      return true;
    }

    var partitionKey = new PartitionKey(document.FailedOperation);
    var cosmosOperation = new CosmosDependencyOperation("StoreClmError");

    try
    {
      var operationContainer = _cosmosClient.GetContainer(_settings.Name, _settings.ClmUpdateErrorsContainer);
      var response = await operationContainer.CreateItemAsync(document, partitionKey, _defaultOptions);
      LogSuccessfulStoringOfPostiErrorData(document);

      cosmosOperation.Success = true;
      cosmosOperation.StatusCode = (int)response.StatusCode;
      cosmosOperation.RequestCharge = response.RequestCharge;
      return true;
    }
    catch (CosmosException ex)
    {
      LogFailedStoringOfPostiErrorData(ex, document);
      cosmosOperation.StatusCode = (int)ex.StatusCode;
      cosmosOperation.RequestCharge = ex.RequestCharge;
      return false;
    }
    finally
    {
      TrackCosmosDependency(cosmosOperation);
    }
  }
  private struct CosmosDependencyOperation
  {
    public string Name { get; set; }
    public DateTime StartTime { get; set; } = DateTime.UtcNow;
    public bool Success { get; set; } = false;
    public int StatusCode { get; set; } = 0;
    public double RequestCharge { get; set; } = 0.0;
    public string Data { get; set; } = "";

    public CosmosDependencyOperation(string name)
    {
      Name = name;
    }
  }

  private void TrackCosmosDependency(CosmosDependencyOperation operation)
  {
    var dependency = new DependencyTelemetry()
    {
      Name = operation.Name,
      Target = _cosmosClient.Endpoint.Host,
      Data = operation.Data,
      Type = "Azure DocumentDB",
      Timestamp = operation.StartTime,
      Duration = DateTime.UtcNow - operation.StartTime,
      ResultCode = $"{operation.StatusCode}",
      Success = operation.Success,
    };
    dependency.Properties["requestCharge"] = operation.RequestCharge.ToString(CultureInfo.InvariantCulture);
    _telemetryClient.TrackDependency(dependency);
  }

  private void LogSuccessfulStoringOfPostiErrorData(ClmUpdateErrorDocument document)
  {
    _logger.LogInformation("Successfully added clm error error data to database.\n" +
      "Customer id: {customerId}. Change status: {changeStatus}",
      document.CustomerId, document.ChangeStatus);
  }

  private void LogFailedStoringOfPostiErrorData(CosmosException ex, ClmUpdateErrorDocument document)
  {
    _logger.LogError(ex, "Failed to store clm error error data in database.\n" +
      "Invalid data: {invalidDataDocument}\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      JsonConvert.SerializeObject(document),
      ex.Message, ex.StackTrace);
  }

  private void LogDisabledErrorStoring()
  {
    _logger.LogInformation("CLM Error error storing disabled");
  }


  private void LogSuccessfullyFetchedClmUpdateErrors(List<ClmUpdateErrorDocument> fetchedErrors)
  {
    _logger.LogInformation("Successfully fetched all Clm Update Errors Errors.\n" +
      "Documents:\n{documents}",
      string.Join("\n", fetchedErrors.Select(doc => JsonConvert.SerializeObject(doc))));
  }

  private void LogDeletingClmUpdateError(string errorId)
  {
    _logger.LogInformation("Begin deletion of Clm Update Error from database.\n" +
      "Error id: {errorId}.", errorId);
  }

  private void LogSuccesfulDeletionOfClmUpdateError(string errorId)
  {
    _logger.LogInformation("Successfully deleted Clm Update Error.\n" +
      "Error id: {errorId}.", errorId);
  }

  private void LogFailedFetchClmUpdateErrors(CosmosException ex)
  {
    _logger.LogError(ex, "Failed to fetch all Clm Update errors.\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      ex.Message, ex.StackTrace);
  }

  private void LogFailedDeletionOfClmUpdateError(CosmosException ex, string errorId)
  {
    _logger.LogError(ex, "Failed to delete clm update error.\n" +
      "Error id: {errorId}.\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      errorId,
      ex.Message, ex.StackTrace);
  }
}
