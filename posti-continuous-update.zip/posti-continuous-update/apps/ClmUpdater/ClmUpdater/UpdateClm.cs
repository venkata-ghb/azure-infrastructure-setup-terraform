using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using ClmUpdater.ClmApim;
using ClmUpdater.ClmApim.Models;
using ClmUpdater.CosmosDb;
using ClmUpdater.CosmosDb.Models;
using ClmUpdater.Mappers;
using ClmUpdater.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NodaTime;

namespace ClmUpdater
{
  public class UpdateClm
  {
    private readonly ILogger<UpdateClm> _logger;
    private readonly IClock _clock;
    private readonly ICustomerProfileService _customerProfileService;
    private readonly IClmChangeMapper _mapper;
    private readonly ICosmosDbService _cosmosDbService;

    public UpdateClm(ILogger<UpdateClm> logger, ICustomerProfileService customerProfileService, IClmChangeMapper mapper, ICosmosDbService cosmosDbService, IClock clock)
    {
      _logger = logger;
      _customerProfileService = customerProfileService;
      _mapper = mapper;
      _cosmosDbService = cosmosDbService;
      _clock = clock;
    }

    [FunctionName("UpdateClm")]
    public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req)
    {
      try
      {
        string requestBody = await new StreamReader(req.Body).ReadToEndAsync();

        var dtos = JsonConvert.DeserializeObject<List<PostiCustomerChangeDto>>(requestBody);
        var changeModels = _mapper.Map(dtos);

        if (changeModels is null || changeModels.Count == 0)
          return new OkResult();

        var results = await _customerProfileService.ProcessChangesAsync(changeModels);
        var failed = results.Where(r => r.ResponseStatus == ClmResponseStatus.Fail).ToList();
        foreach (var change in failed)
        {
          var document = ClmUpdateErrorDocument.CreateFromChangeModelAndResponse(changeModels.FirstOrDefault(x => x.CustomerId == change.CustomerId), change, _clock.GetCurrentInstant().ToUnixTimeSeconds());
          await _cosmosDbService.StoreClmUpdateError(document);
        }
        var conflicts = results.Where(r => r.ResponseStatus == ClmResponseStatus.Conflict).ToList();
        foreach (var change in conflicts)
        {
          var conflictChangeModel = changeModels.FirstOrDefault(x => x.CustomerId == change.CustomerId);
          await _customerProfileService.SetCLMDuplicateAttribute(conflictChangeModel);
        }
        return GetActionResult(failed);
      }
      catch (Exception ex)
      {
        LogUnexpectedError(ex);
        return new StatusCodeResult(StatusCodes.Status500InternalServerError);
      }
    }

    private ActionResult GetActionResult(List<ClmResponse> failed)
    {
      if (failed.Count == 0)
        return new OkResult();

      return new ObjectResult(PrepareResponse(failed)) { StatusCode = StatusCodes.Status500InternalServerError };
    }

    private FailedActionResponse PrepareResponse(List<ClmResponse> failed)
        => new FailedActionResponse("Some records where not correctly processed by CLM", JsonConvert.SerializeObject(failed));

    private void LogUnexpectedError(Exception ex)
    {
      _logger.LogError("There was an unexpected error:\n" +
          "Error: {error}\n" +
          "Stack trace: {trace}",
          ex, ex.StackTrace);
    }
  }
}
