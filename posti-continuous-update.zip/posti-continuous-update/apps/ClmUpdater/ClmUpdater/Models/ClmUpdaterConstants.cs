﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClmUpdater.Models;
public static class ClmUpdaterConstants
{
  public const string AddressValidationStatusField = "CUS_OSOITEVALIDOINTI";
  public const string Identified = "I";
  public const string NotIdentified = "NI";
  public const string EmptyCountryCode = "XX";
  public const string AhvenanmaaCountryCode = "AX";
  public const string AhvenanmaaPostalCodePrefix = "22";
  public const int AhvenanmaaPostalCodeLength = 5;
  public const string DefaultCountryCode = "FI";
  public const string DuplicateField = "CUS_POSTIN_TUPLAT";
  public const string DuplicateFieldValueMessage = "Mahdollinen duplikaattijäsenyys - Postin päivitys epäonnistui";
  public const string AhvenanmaaMessage = "Ahvenanmaalainen osoite - tarkista osoitetiedot";
}
