﻿namespace ClmUpdater.Models;

public record FailedActionResponse(string Message, string Data);
