﻿namespace ClmUpdater.Models;

public enum ClmChangeStatus
{
  IdentifiedAssignmentSet,
  CustomerUpdated,
  PersonDuplicated,
  Ignore,
  Conflict
}

public enum PostiAddressType
{
  Finnish,
  Swedish
}

