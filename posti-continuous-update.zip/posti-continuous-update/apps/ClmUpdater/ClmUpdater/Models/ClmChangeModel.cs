﻿/// <summary>
/// This model represent data that will be send to the CLM Updater function
/// </summary>
public class ClmChangeModel
{
  public ChangeStatus ChangeStatus { get; init; }
  public string CustomerId { get; init; }
  public string DuplicatedId { get; init; }
  public string Ssn { get; init; }
  public string LastName { get; init; }
  public string FirstName { get; init; }
  public ClmAddress Address { get; init; }
  public ClmPersonStatus PersonStatus { get; init; }

  public bool IsPersonDeceased()
  {
    if (PersonStatus == null)
      return false;

    return PersonStatus.IsDeceased.HasValue && PersonStatus.IsDeceased.Value;
  }
}

public record ChangeStatus
{
  public bool? WasIdentified { get; init; }
  public bool? WasModified { get; init; }
  public bool? IsDuplicated { get; init; }
}

public class ClmAddress
{
  public string City { get; init; }
  public string PostalCode { get; init; }
  public string Street { get; init; }
  public string Telephone { get; init; }
  public string CountryCode { get; init; }
  public string CountryName { get; init; }
}

public class ClmPersonStatus
{
  public bool? IsMinor { get; init; }
  public bool? IsDeceased { get; init; }
}
