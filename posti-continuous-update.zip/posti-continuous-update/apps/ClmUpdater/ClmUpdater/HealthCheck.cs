using System;
using System.Threading.Tasks;
using System.Web.Http;
using ClmUpdater.ClmApim;
using ClmUpdater.CosmosDb;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;

namespace ClmUpdater;

public class HealthCheck
{
  private readonly ICosmosDbService _cosmosDbService;
  private readonly ICustomerProfileService _customerProfileService;
  private readonly ILogger<HealthCheck> _logger;

  public HealthCheck(ICosmosDbService cosmosDbService, ICustomerProfileService customerProfileService, ILogger<HealthCheck> log)
  {
    _cosmosDbService = cosmosDbService;
    _customerProfileService = customerProfileService;
    _logger = log;
  }
  [FunctionName("HealthCheck")]
  public async Task<IActionResult> Run(
      [HttpTrigger(AuthorizationLevel.Function, "get", Route = "qVfnWT0dPFTQHH6jb14rYos/health-check")] HttpRequest req)
  {

    try
    {
      _logger.LogInformation("Running Health Check");

      await _cosmosDbService.HealthCheckCall();
      await _customerProfileService.HealthCheckCall();
      return new OkResult();
    }
    catch (Exception ex)
    {
      _logger.LogError(ex, "Healthcheck failed with exception.\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      ex.Message, ex.StackTrace);
      return new InternalServerErrorResult();
    }

  }
}
