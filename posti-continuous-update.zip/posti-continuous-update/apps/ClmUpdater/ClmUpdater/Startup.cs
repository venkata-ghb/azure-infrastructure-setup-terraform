﻿using ClmUpdater.ClmApim;
using ClmUpdater.Config;
using ClmUpdater.Config.Models;
using ClmUpdater.CosmosDb;
using ClmUpdater.Mappers;
using Microsoft.ApplicationInsights.Channel;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;
using NodaTime;

[assembly: FunctionsStartup(typeof(ClmUpdater.Startup))]

namespace ClmUpdater
{
  public class CloudNameInitializer : ITelemetryInitializer
  {
    public void Initialize(ITelemetry telemetry)
    {
      telemetry.Context.Cloud.RoleName = "ClmUpdater";
    }
  }

  public class Startup : FunctionsStartup
  {
    public override void Configure(IFunctionsHostBuilder builder)
    {
      builder.Services.AddLogging();
      builder.Services.AddSingleton<ITelemetryInitializer, CloudNameInitializer>();
      builder.Services.AddScoped<IClmChangeMapper, ClmChangeMapper>();

      builder.Services.RegisterClmApim();
      builder.Services.RegisterCosmosDb();
      builder.Services.AddSingleton<IClock>(SystemClock.Instance);
      builder.Services.RegisterConfiguration<ClmAuthSettings>(ServiceLifetime.Scoped);
      builder.Services.RegisterConfiguration<ClmProfileSettings>(ServiceLifetime.Scoped);
      builder.Services.RegisterConfiguration<CosmosDbSettings>(ServiceLifetime.Scoped);
      builder.Services.RegisterConfiguration<FunctionSettings>(ServiceLifetime.Scoped);

    }
  }
}
