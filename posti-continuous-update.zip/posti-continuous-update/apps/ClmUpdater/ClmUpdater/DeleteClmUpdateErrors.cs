using System;
using System.Threading.Tasks;
using ClmUpdater.CosmosDb;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;

namespace ClmUpdater;

public class DeleteClmUpdateErrors
{
  private readonly ILogger<DeleteClmUpdateErrors> _logger;
  private readonly ICosmosDbService _cosmosDbService;

  public DeleteClmUpdateErrors(ILogger<DeleteClmUpdateErrors> logger, ICosmosDbService cosmosDbService)
  {
    _logger = logger;
    _cosmosDbService = cosmosDbService;
  }

  [FunctionName("DeleteClmUpdateErrors")]
  
    public async Task Run(
        [TimerTrigger("0 45 23 * * *")] TimerInfo timerInfo)
  {
    try
    {
      //Get parameter and delete records
      var clmUpdateErrorsDateTime = DateTime.Now.AddDays(-30);
      var deletionErrorsResult = await _cosmosDbService.DeleteClmUpdateErrors(clmUpdateErrorsDateTime);

      if (deletionErrorsResult != true)
        LogMessages("Failed to process delete clm update table enties", true);

      LogMessages("Successfully deleted clm update table entries", false);
    }
    catch (Exception ex)
    {
      LogUnexpectedError(ex);
      
    }
  }

  private void LogMessages(string message, bool isError)
  {
    if(isError)
    {
      _logger.LogError(message);
    }
    else
    {
      _logger.LogInformation(message);
    }
    
  }
  private void LogClmDateTimeRequest(string dateTimeRequest)
  {
    _logger.LogInformation("Incoming Clm Update Errors deletion request request\n" +
      "Clm Update Errors deletion request dateTime: {request}", dateTimeRequest);
  }
  private void LogUnexpectedError(Exception ex)
  {
    _logger.LogError("There was an unexpected error:\n" +
        "Error: {error}\n" +
        "Stack trace: {trace}",
        ex, ex.StackTrace);
  }
}

