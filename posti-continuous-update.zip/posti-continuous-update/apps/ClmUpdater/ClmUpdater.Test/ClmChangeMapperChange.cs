﻿using ClmUpdater.Mappers;
using ClmUpdater.Test.Fixtures;
using FluentAssertions;
using Xunit;

namespace ClmUpdater.Test;
public class ClmChangeMapperTest
{
  [Theory]
  [InlineData("", "", "Street example")]
  [InlineData("", "CityExample", "Street example")]
  [InlineData("01340", "CityExample", "Street example")]
  public void Map_MapWithAddress_Valid(string postalCode, string city, string street)
  {
    var dto = Generators.CreateCustomerChangeDtoWithAddress(city: city, postalCode: postalCode, street: street);

    var mapper = new ClmChangeMapper();

    var result = mapper.Map(dto);

    result.Address.City.Should().Be(city);
    result.Address.Street.Should().Be(street);
    result.Address.PostalCode.Should().Be(postalCode);
    result.Address.CountryCode.Should().Be("FI");
    result.Address.CountryName.Should().Be("Finland");
  }

  [Theory]
  [InlineData("line1", "line2", "line3", "line4", "ca", "Canada")]
  [InlineData("line1", "", "", "", "ca", "Canada")]
  [InlineData("line1", "line2", "", "", "ca", "Canada")]
  [InlineData("line1", "line2", "line3", "", "Pl", "Poland")]
  [InlineData("", "line2", "line3", "", "pL", "Poland")]
  public void Map_MapWithForeignAddress_Valid(string otherAddressLine1, string otherAddressLine2, string otherAddressLine3, string otherAddressLine4, string countryCode, string countryName)
  {
    var dto = Generators.CreateCustomerChangeDtoWithAddress(otherAddressLine1: otherAddressLine1, otherAddressLine2: otherAddressLine2,
      otherAddressLine3: otherAddressLine3, otherAddressLine4: otherAddressLine4, countryName: countryName, countryCode: countryCode);

    var mapper = new ClmChangeMapper();
    var street = otherAddressLine1 + " " + otherAddressLine2 + " " + otherAddressLine3 + " " + otherAddressLine4;

    var result = mapper.Map(dto);

    result.Address.City.Should().Be("Ulkomaa");
    result.Address.Street.Should().Be(street.Trim());
    result.Address.PostalCode.Should().Be("00000");
    result.Address.CountryCode.Should().Be(countryCode.ToUpper()); ;
    result.Address.CountryName.Should().Be(countryName);
  }
  [Fact]
  public void Map_MapWithAhvenanmaaAddress_AX_Country_MissingLine2AndLine3_Valid()
  {
    var dto = Generators.CreateCustomerChangeDtoWithAddress(otherAddressLine1: "Line1", countryName: "ÅLAND", countryCode: "AX");

    var mapper = new ClmChangeMapper();
    var street = "Line1";

    var result = mapper.Map(dto);

    result.Address.City.Should().Be("Tuntematon");
    result.Address.Street.Should().Be(street.Trim());
    result.Address.PostalCode.Should().Be("00000");
    result.Address.CountryCode.Should().Be("FI");
    result.Address.CountryName.Should().Be("Finland");
  }

  [Theory]
  [InlineData("line1", "22470 City", "line3", "line4", "ax", "ÅLAND")]
  public void Map_MapWithAhvenanmaaAddress_AddressLine2_Valid(string otherAddressLine1, string otherAddressLine2, string otherAddressLine3, string otherAddressLine4, string countryCode, string countryName)
  {
    var dto = Generators.CreateCustomerChangeDtoWithAddress(otherAddressLine1: otherAddressLine1, otherAddressLine2: otherAddressLine2,
      otherAddressLine3: otherAddressLine3, otherAddressLine4: otherAddressLine4, countryName: countryName, countryCode: countryCode);

    var mapper = new ClmChangeMapper();
    var street = $"{otherAddressLine1} {otherAddressLine3} {otherAddressLine4}";

    var result = mapper.Map(dto);

    result.Address.City.Should().Be("City");
    result.Address.Street.Should().Be(street.Trim());
    result.Address.PostalCode.Should().Be("22470");
    result.Address.CountryCode.Should().Be("FI");
    result.Address.CountryName.Should().Be("Finland");
  }
  

  [Theory]
  [InlineData("line1", "line2", "22270 City", "line4", "ax", "ÅLAND")]
  public void Map_MapWithAhvenanmaaAddress_AddressLine3_Valid(string otherAddressLine1, string otherAddressLine2, string otherAddressLine3, string otherAddressLine4, string countryCode, string countryName)
  {
    var dto = Generators.CreateCustomerChangeDtoWithAddress(otherAddressLine1: otherAddressLine1, otherAddressLine2: otherAddressLine2,
      otherAddressLine3: otherAddressLine3, otherAddressLine4: otherAddressLine4, countryName: countryName, countryCode: countryCode);

    var mapper = new ClmChangeMapper();
    var street = $"{otherAddressLine1} {otherAddressLine2} {otherAddressLine4}";

    var result = mapper.Map(dto);

    result.Address.City.Should().Be("City");
    result.Address.Street.Should().Be(street.Trim());
    result.Address.PostalCode.Should().Be("22270");
    result.Address.CountryCode.Should().Be("FI");
    result.Address.CountryName.Should().Be("Finland");
  }

  [Theory]
  [InlineData("line1", "222 City", "line2",  "line4", "ax", "ÅLAND")]
  [InlineData("line1", "2220", "line2", "line4", "ax", "ÅLAND")]
  public void Map_MapWithAhvenanmaaAddress_AddressLine2_InValid(string otherAddressLine1, string otherAddressLine2, string otherAddressLine3, string otherAddressLine4, string countryCode, string countryName)
  {
    var dto = Generators.CreateCustomerChangeDtoWithAddress(otherAddressLine1: otherAddressLine1, otherAddressLine2: otherAddressLine2,
      otherAddressLine3: otherAddressLine3, otherAddressLine4: otherAddressLine4, countryName: countryName, countryCode: countryCode);

    var mapper = new ClmChangeMapper();
    var street = otherAddressLine1 + " " + otherAddressLine2 + " " + otherAddressLine3 + " " + otherAddressLine4;

    var result = mapper.Map(dto);

    result.Address.City.Should().Be("Tuntematon");
    result.Address.Street.Should().Be(street.Trim());
    result.Address.PostalCode.Should().Be("00000");
    result.Address.CountryCode.Should().Be("FI");
    result.Address.CountryName.Should().Be("Finland");
  }

  [Theory]
  [InlineData("line1", "line2", "222 City", "line4", "ax", "ÅLAND")]
  [InlineData("line1", "line2", "line3", "line4", "ax", "ÅLAND")]
  [InlineData("line1", "line2", "2220", "line4", "ax", "ÅLAND")]
  public void Map_MapWithAhvenanmaaAddress_AddressLine3_InValid(string otherAddressLine1, string otherAddressLine2, string otherAddressLine3, string otherAddressLine4, string countryCode, string countryName)
  {
    var dto = Generators.CreateCustomerChangeDtoWithAddress(otherAddressLine1: otherAddressLine1, otherAddressLine2: otherAddressLine2,
      otherAddressLine3: otherAddressLine3, otherAddressLine4: otherAddressLine4, countryName: countryName, countryCode: countryCode);

    var mapper = new ClmChangeMapper();
    var street = otherAddressLine1 + " " + otherAddressLine2 + " " + otherAddressLine3 + " " + otherAddressLine4;

    var result = mapper.Map(dto);

    result.Address.City.Should().Be("Tuntematon");
    result.Address.Street.Should().Be(street.Trim());
    result.Address.PostalCode.Should().Be("00000");
    result.Address.CountryCode.Should().Be("FI");
    result.Address.CountryName.Should().Be("Finland");
  }

  [Theory]
  [InlineData("line1", "line2", "line4", "ax", "ÅLAND")]
  public void Map_MapWithAhvenanmaaAddress_MissingValues(string otherAddressLine1, string otherAddressLine2, string otherAddressLine4, string countryCode, string countryName)
  {
    var dto = Generators.CreateCustomerChangeDtoWithAddress(otherAddressLine1: otherAddressLine1, otherAddressLine2: otherAddressLine2,
      otherAddressLine4: otherAddressLine4, countryName: countryName, countryCode: countryCode);

    var mapper = new ClmChangeMapper();
    var street = otherAddressLine1 + " " + otherAddressLine2 + " " + otherAddressLine4;

    var result = mapper.Map(dto);

    result.Address.City.Should().Be("Tuntematon");
    result.Address.Street.Should().Be(street.Trim());
    result.Address.PostalCode.Should().Be("00000");
    result.Address.CountryCode.Should().Be("FI");
    result.Address.CountryName.Should().Be("Finland");
  }

  [Fact]
  public void Map_MapWithEmptyAddressAndForeignAddress_NullInTheseProperties()
  {
    var dto = Generators.CreateCustomerChangeDtoWithAddress();

    var mapper = new ClmChangeMapper();

    var result = mapper.Map(dto);

    result.Address.Should().BeNull();
  }
}
