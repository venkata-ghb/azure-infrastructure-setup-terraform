﻿using System;
using ClmUpdater.Tools;
using FluentAssertions;
using Newtonsoft.Json;
using Xunit;

namespace ClmUpdater.Test.Tools;
public class ClmDateTimeConverterTest
{
  [Fact]
  public void ConvertFromJsonTest()
  {
    //Arrange
    var mockJson = Utils.ReadFixture("dateTimeTest.json");
    //Act
    var convert = JsonConvert.DeserializeObject<ExampleJsonModel>(mockJson);
    //Assert
    convert.DateTime.Year.Should().Be(2022);
    convert.DateTime.Month.Should().Be(5);
    convert.DateTime.Day.Should().Be(27);
    convert.DateTime.Hour.Should().Be(14);
    convert.DateTime.Minute.Should().Be(30);
    convert.DateTime.Second.Should().Be(15);
    convert.DateTime.Millisecond.Should().Be(135);
  }

  [Fact]
  public void ConvertToJsonTest()
  {
    //Arrange
    var dateTime = new DateTime(2022, 5, 27, 14, 30, 15, 135, DateTimeKind.Utc);
    var model = new ExampleJsonModel() { DateTime = dateTime };
    var mockJson = Utils.ReadFixture("dateTimeTest.json");
    //Act
    var convert = JsonConvert.SerializeObject(model);
    //Assert
    convert.Should().BeEquivalentTo(mockJson);
  }

  record ExampleJsonModel
  {
    [JsonProperty("dateTime")]
    [JsonConverter(typeof(ClmDateTimeConverter))]
    public DateTime DateTime { get; init; }
  }
}
