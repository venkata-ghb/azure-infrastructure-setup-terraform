﻿using System;
using ClmUpdater.Tools;
using FluentAssertions;
using Newtonsoft.Json;
using Xunit;

namespace ClmUpdater.Test.Tools;
public class ClmDateOnlyConverterTest
{
  [Fact]
  public void ConvertFromJsonTest()
  {
    //Arrange
    var mockJson = Utils.ReadFixture("dateOnlyTest.json");
    //Act
    var convert = JsonConvert.DeserializeObject<ExampleJsonModel>(mockJson);
    //Assert
    convert.DateOnly.Year.Should().Be(2022);
    convert.DateOnly.Month.Should().Be(5);
    convert.DateOnly.Day.Should().Be(27);

  }

  [Fact]
  public void ConvertToJsonTest()
  {
    //Arrange
    var dateOnly = new DateOnly(2022, 5, 27);
    var model = new ExampleJsonModel() { DateOnly = dateOnly };
    var mockJson = Utils.ReadFixture("dateOnlyTest.json");
    //Act
    var convert = JsonConvert.SerializeObject(model);
    //Assert
    convert.Should().BeEquivalentTo(mockJson);
  }

  record ExampleJsonModel
  {
    [JsonProperty("dateOnly")]
    [JsonConverter(typeof(ClmDateOnlyConverter))]
    public DateOnly DateOnly { get; init; }
  }
}
