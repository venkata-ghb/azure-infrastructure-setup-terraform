﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using ClmUpdater.ClmApim.Models;
using ClmUpdater.Config.Models;
using ClmUpdater.CosmosDb;
using ClmUpdater.CosmosDb.Models;
using ClmUpdater.Test.Fixtures;
using ClmUpdater.Tools;
using FluentAssertions;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using Moq;
using NodaTime;
using NodaTime.Testing;
using Xunit;

namespace ClmUpdater.Test.CosmosDb;

public class CosmosDbServiceTest
{
  private readonly CosmosDbSettings _mockSettings;
  private readonly Mock<CosmosClient> _mockCosmosClient;
  private readonly Mock<Container> _mockClmErrorsContainer;
  private readonly FakeClock _testClock;

  private readonly Mock<ItemResponse<ClmUpdateErrorDocument>> _mockStoreClmErrorDocumentResponse;
  private readonly Mock<ICosmosLinqQuery> _mockCosmosLinqQueryWrapper;

  private readonly CosmosDbService _testService;
  private readonly Mock<ItemResponse<ClmUpdateErrorDocument>> _mockDeleteClmUpdateErrorResponse;


  public CosmosDbServiceTest(ILogger<CosmosDbService> logger)
  {
    var testTime = new DateTime(2022, 1, 10, 7, 30, 45, DateTimeKind.Utc);
    var testInstant = Instant.FromDateTimeUtc(testTime);
    _testClock = new FakeClock(testInstant);
    _mockSettings = new CosmosDbSettings()
    {
      Name = "FakeDb",
      ConnectionString = "ConnectToDb",
      ClmUpdateErrorsContainer = "ClmUpdateErrors",
      DisableStoreClmUpdateErrors = false
    };
    _mockCosmosClient = new Mock<CosmosClient>();
    // Setup URI return for telemetry calls
    _mockCosmosClient
      .Setup(c => c.Endpoint)
      .Returns(new Uri("https://some-cosmos.db"));
    // Setup fetching of containers
    _mockClmErrorsContainer = new Mock<Container>();
    _mockCosmosClient
        .Setup(c => c.GetContainer(_mockSettings.Name, _mockSettings.ClmUpdateErrorsContainer))
        .Returns(_mockClmErrorsContainer.Object)
        .Verifiable();

    _mockStoreClmErrorDocumentResponse = new Mock<ItemResponse<ClmUpdateErrorDocument>>();
    _mockDeleteClmUpdateErrorResponse = new Mock<ItemResponse<ClmUpdateErrorDocument>>();
    _mockCosmosLinqQueryWrapper = new Mock<ICosmosLinqQuery>();


    _testService = new CosmosDbService(
      logger,
      _mockSettings,
      _mockCosmosClient.Object,
      new TelemetryConfiguration(),
      _mockCosmosLinqQueryWrapper.Object);
  }

  private void SetupFetchingAndDeletingPostiErrors(IEnumerable<ClmUpdateErrorDocument> clmUpdateErrorsResponse)
  {
    // Configure fetching batches
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetQueryText(It.IsAny<IQueryable<ClmUpdateErrorDocument>>()))
      .Returns("Some query");
    var mockFeedIteratorErrors = new Mock<FeedIterator<ClmUpdateErrorDocument>>();
    mockFeedIteratorErrors
      .SetupSequence(fi => fi.HasMoreResults)
      .Returns(true)
      .Returns(false);
    var mockFeedErrorsResponse = new Mock<FeedResponse<ClmUpdateErrorDocument>>();
    mockFeedErrorsResponse
        .Setup(fr => fr.GetEnumerator()).Returns(clmUpdateErrorsResponse.GetEnumerator());
    mockFeedIteratorErrors
        .SetupSequence(fi => fi.ReadNextAsync(default))
        .ReturnsAsync(mockFeedErrorsResponse.Object);
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetFeedIterator(It.IsAny<IQueryable<ClmUpdateErrorDocument>>()))
      .Returns(mockFeedIteratorErrors.Object);
    _mockClmErrorsContainer
      .Setup(c => c.GetItemLinqQueryable<ClmUpdateErrorDocument>(false, null, null, null))
      .Returns(new EnumerableQuery<ClmUpdateErrorDocument>(new List<ClmUpdateErrorDocument>()))
      .Verifiable();


    // Configure deleting batches
    foreach (var error in clmUpdateErrorsResponse)
    {
      _mockClmErrorsContainer
        .Setup(c => c.DeleteItemAsync<ClmUpdateErrorDocument>(
          It.Is<string>(id => id == error.Id),
          It.Is<PartitionKey>(key => key == new PartitionKey(error.FailedOperation)),
          It.IsAny<ItemRequestOptions>(),
          default))
        .ReturnsAsync(_mockDeleteClmUpdateErrorResponse.Object)
        .Verifiable();
    }
  }
  private List<ClmUpdateErrorDocument> PrepareClmUpdateErrorDocumentsCollection()
  {
    var failedResponse = ClmResponse.CreateFailedStatus(Models.ClmChangeStatus.IdentifiedAssignmentSet, "11111");
    var august30 = ClmUpdateErrorDocument.CreateFromChangeModelAndResponse(Generators.PrepareClmChangeModel(), failedResponse, 1661842010);
    var august29 = ClmUpdateErrorDocument.CreateFromChangeModelAndResponse(Generators.PrepareClmChangeModel(), failedResponse, 1661755610);
    var august28 = ClmUpdateErrorDocument.CreateFromChangeModelAndResponse(Generators.PrepareClmChangeModel(), failedResponse, 1661669210);

    var listOfDocuments = new List<ClmUpdateErrorDocument>() { august28, august29, august30 }.OrderByDescending(x => x.Timestamp);

    return listOfDocuments.ToList();
  }

  [Fact]
  public async void DeleteClmUpdateErrors_OperationSuccessfulNoParams_ReturnsTrue()
  {
    //Arrange
    var listOfDocuments = PrepareClmUpdateErrorDocumentsCollection();
    SetupFetchingAndDeletingPostiErrors(listOfDocuments);

    //Act
    var result = await _testService.DeleteClmUpdateErrors();

    //Assert
    result.Should().BeTrue();

    _mockClmErrorsContainer.Verify();
    _mockClmErrorsContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void StorePostiError_OperationSuccessfullyStored_ReturnsTrue()
  {
    // ASSIGN
    var clmChange = Generators.PrepareClmChangeModel();
    var clmResponse = ClmResponse.CreateFailedStatus(Models.ClmChangeStatus.IdentifiedAssignmentSet, clmChange.CustomerId);
    var expectedDocument = ClmUpdateErrorDocument.CreateFromChangeModelAndResponse(clmChange, clmResponse, _testClock.GetCurrentInstant().ToUnixTimeSeconds());
    
    var expectedPartitionKey = new PartitionKey(clmResponse.ChangeStatus.ToString());
    _mockClmErrorsContainer
      .Setup(container => container.CreateItemAsync(
        It.Is<ClmUpdateErrorDocument>(doc => doc == expectedDocument),
        It.Is<PartitionKey>(key => key == expectedPartitionKey),
        It.IsAny<ItemRequestOptions>(),
        default))
      .ReturnsAsync(_mockStoreClmErrorDocumentResponse.Object)
      .Verifiable();

    // ACT
    var success = await _testService.StoreClmUpdateError(expectedDocument);

    // ASSERT
    success.Should().BeTrue();
    _mockClmErrorsContainer.Verify();
    _mockClmErrorsContainer.VerifyNoOtherCalls();
  }

  [Theory]
  [InlineData(26, 3)]
  [InlineData(28, 2)]
  [InlineData(29, 1)]
  [InlineData(30, 0)]
  [InlineData(31, 0)]
  public async void DeleteClmUpdateErrors_OperationSuccessfulDateTimeParam_ReturnsTrue(int day, int collectionCount)
  {
    //Arrange
    var listOfDocuments = PrepareClmUpdateErrorDocumentsCollection().Skip(collectionCount).ToList();
    SetupFetchingAndDeletingPostiErrors(listOfDocuments);
    var dateParam = new DateTime(2022, 8, day, 7, 30, 45, DateTimeKind.Utc);

    //Act
    var result = await _testService.DeleteClmUpdateErrors(dateParam);

    //Assert
    result.Should().BeTrue();

    _mockClmErrorsContainer.Verify();
    _mockClmErrorsContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void StorePostiError_CosmosExceptionThrown_ReturnsFalse()
  {
    // ASSIGN
    var clmChange = Generators.PrepareClmChangeModel();
    var clmResponse = ClmResponse.CreateFailedStatus(Models.ClmChangeStatus.IdentifiedAssignmentSet, clmChange.CustomerId);
    var expectedDocument = ClmUpdateErrorDocument.CreateFromChangeModelAndResponse(clmChange, clmResponse, _testClock.GetCurrentInstant().ToUnixTimeSeconds());

    var expectedPartitionKey = new PartitionKey(clmResponse.ChangeStatus.ToString());
    _mockClmErrorsContainer
      .Setup(container => container.CreateItemAsync(
        It.Is<ClmUpdateErrorDocument>(doc => doc == expectedDocument),
        It.Is<PartitionKey>(key => key == expectedPartitionKey),
        It.IsAny<ItemRequestOptions>(),
        default))
      .ThrowsAsync(new CosmosException("Oops", HttpStatusCode.BadRequest, 440, "id", 0.1))
      .Verifiable();

    // ACT
    var success = await _testService.StoreClmUpdateError(expectedDocument);

    // ASSERT
    success.Should().BeFalse();
    _mockClmErrorsContainer.Verify();
    _mockClmErrorsContainer.VerifyNoOtherCalls();
  }
}
