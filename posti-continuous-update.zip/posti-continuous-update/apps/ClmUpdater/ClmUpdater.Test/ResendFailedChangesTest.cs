using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using ClmUpdater.ClmApim;
using ClmUpdater.ClmApim.Mappers;
using ClmUpdater.ClmApim.Models;
using ClmUpdater.Config.Models;
using ClmUpdater.CosmosDb;
using ClmUpdater.CosmosDb.Models;
using ClmUpdater.Mappers;
using ClmUpdater.Test.Fixtures;
using FluentAssertions;
using FluentAssertions.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using NodaTime;
using NodaTime.Testing;
using RichardSzalay.MockHttp;
using Xunit;

namespace ClmUpdater.Test
{
  public class ResendFailedChangesTest
  {
    private readonly ILogger<ResendFailedChanges> _logger;
    private readonly FakeClock _testClock;
    private readonly ILogger<CustomerProfileService> _profileLogger;
    private readonly CustomerProfileService _customerProfileService;
    private readonly MockHttpMessageHandler _cpsHttpMock;
    private readonly ClmProfileSettings _clmProfileSettings;
    private readonly Mock<ICosmosDbService> _mockDbService;
    private readonly List<ClmUpdateErrorDocument> _listOfDocuments;
    private readonly FunctionSettings _functionSetings;

    public ResendFailedChangesTest(ILogger<ResendFailedChanges> logger, ILogger<CustomerProfileService> profileLogger)
    {
      _functionSetings = new FunctionSettings()
      {
        DisableClmErrorResend = false,
      };

      var testTime = new DateTime(2022, 1, 10, 7, 30, 45, DateTimeKind.Utc);
      var testInstant = Instant.FromDateTimeUtc(testTime);
      _testClock = new FakeClock(testInstant);
      _logger = logger;
      _profileLogger = profileLogger;
      _mockDbService = new Mock<ICosmosDbService>();
      _listOfDocuments = PrepareClmUpdateErrorDocumentsCollection();
      _mockDbService
         .Setup(dbService => dbService.GetClmUpdateErrors())
         .ReturnsAsync(_listOfDocuments)
         .Verifiable();



      _clmProfileSettings = new ClmProfileSettings()
      {
        BaseUrl = "http://domain/api/"
      };
      _cpsHttpMock = new MockHttpMessageHandler();
      _customerProfileService = new CustomerProfileService(_cpsHttpMock.ToHttpClient(), _clmProfileSettings, new ClmCustomerDtoMapper(), _profileLogger);
    }

    [Fact]
    public async void ValidRequest_Returns200()
    {
      var mapperMock = new ClmChangeMapper();
      var changes = mapperMock.Map(_listOfDocuments);

      foreach (var error in _listOfDocuments)
      {
        _mockDbService
         .Setup(dbService => dbService.DeleteClmUpdateError(error.Id, error.FailedOperation))
         .ReturnsAsync(true)
         .Verifiable();
      }

      changes?.ForEach(change => SetMockHttp(change, HttpStatusCode.NoContent, change.CustomerId));
      var resendFailedChanges = new ResendFailedChanges(_logger, _customerProfileService, mapperMock, _mockDbService.Object, _functionSetings);
      var request = Utils.CreateMockRequestWithBody(null).Object;
      //Act
      var response = await resendFailedChanges.Run(request);

      //Assert            
      response.Should().BeAssignableTo<OkResult>();
      _mockDbService.Verify();
      _mockDbService.VerifyNoOtherCalls();
    }

    [Theory]
    [InlineData(1, 2)]
    [InlineData(2, 1)]
    [InlineData(0, 3)]

    public async void ValidRequest_Returns500AndInfoWhichRecordsFailedToSendAgain(int skip, int skipLast)
    {
      var mapperMock = new ClmChangeMapper();
      var changes = mapperMock.Map(_listOfDocuments);

      PrepareDocuments(skip, skipLast);

      changes?.SkipLast(skipLast).ToList().ForEach(change => SetMockHttp(change, HttpStatusCode.NoContent, change.CustomerId));
      changes?.Skip(skip).ToList().ForEach(change => SetMockHttp(change, HttpStatusCode.InternalServerError, change.CustomerId));
      var resendFailedChanges = new ResendFailedChanges(_logger, _customerProfileService, mapperMock, _mockDbService.Object, _functionSetings);
      var request = Utils.CreateMockRequestWithBody(null).Object;
      //Act
      var response = await resendFailedChanges.Run(request);

      //Assert            
      response.Should().BeAssignableTo<ObjectResult>();
      var result = (ObjectResult)response;

      result.Should().NotBeNull();
      result.StatusCode.Should().Be(StatusCodes.Status500InternalServerError);
      _mockDbService.Verify();
      _mockDbService.VerifyNoOtherCalls();
    }

    private void PrepareDocuments(int skip, int skipLast)
    {
      foreach (var error in _listOfDocuments.SkipLast(skipLast))
      {
        _mockDbService
         .Setup(dbService => dbService.DeleteClmUpdateError(error.Id, error.FailedOperation))
         .ReturnsAsync(true)
         .Verifiable();
      }
    }

    private void SetMockHttp(ClmChangeModel clmChange, HttpStatusCode code, string customerId = "10001908")
    {
      string customerIdentifiedPath = $"customers/{clmChange.CustomerId}/assignments";
      string customerModifyPath = $"customers/{clmChange.CustomerId}";
      string assignmentPutPath = $"customers/{clmChange.CustomerId}/assignments/544551";
      var mockGetAssignmentsResponse = Utils.ReadFixture("assingmentsResponseNoAddressAssignments.json");

      _cpsHttpMock.When(System.Net.Http.HttpMethod.Post, $"{_clmProfileSettings.BaseUrl}{customerIdentifiedPath}").Respond(code);
      _cpsHttpMock.When(System.Net.Http.HttpMethod.Put, $"{_clmProfileSettings.BaseUrl}{assignmentPutPath}").Respond(code);
      _cpsHttpMock.When(System.Net.Http.HttpMethod.Get, $"{_clmProfileSettings.BaseUrl}{customerIdentifiedPath}").Respond("application/json", mockGetAssignmentsResponse);
      _cpsHttpMock.When(System.Net.Http.HttpMethod.Patch, $"{_clmProfileSettings.BaseUrl}{customerModifyPath}").Respond(code);
    }

    private List<ClmUpdateErrorDocument> PrepareClmUpdateErrorDocumentsCollection()
    {
      var randomInt = new Random();
      var random = randomInt.Next(0, 10000);
      var failedResponse = ClmResponse.CreateFailedStatus(Models.ClmChangeStatus.IdentifiedAssignmentSet, random.ToString());
      var firstError = ClmUpdateErrorDocument.CreateFromChangeModelAndResponse(Generators.PrepareClmChangeModel(customerId: randomInt.Next(0, 10000).ToString()), failedResponse, _testClock.GetCurrentInstant().ToUnixTimeSeconds());
      var secondError = ClmUpdateErrorDocument.CreateFromChangeModelAndResponse(Generators.PrepareClmChangeModel(customerId: randomInt.Next(0, 10000).ToString()), failedResponse, _testClock.GetCurrentInstant().ToUnixTimeSeconds());
      var thirdError = ClmUpdateErrorDocument.CreateFromChangeModelAndResponse(Generators.PrepareClmChangeModel(customerId: randomInt.Next(0, 10000).ToString()), failedResponse, _testClock.GetCurrentInstant().ToUnixTimeSeconds());

      return new List<ClmUpdateErrorDocument>() { secondError, firstError, thirdError };
    }
  }
}
