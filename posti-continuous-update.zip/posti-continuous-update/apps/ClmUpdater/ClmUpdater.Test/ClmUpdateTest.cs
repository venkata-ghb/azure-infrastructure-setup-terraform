using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using ClmUpdater.ClmApim;
using ClmUpdater.ClmApim.Mappers;
using ClmUpdater.ClmApim.Models;
using ClmUpdater.Config.Models;
using ClmUpdater.CosmosDb;
using ClmUpdater.CosmosDb.Models;
using ClmUpdater.Mappers;
using ClmUpdater.Models;
using FluentAssertions;
using FluentAssertions.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Internal;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using NodaTime;
using NodaTime.Testing;
using RichardSzalay.MockHttp;
using Xunit;

namespace ClmUpdater.Test
{
  public class ClmUpdateTest
  {
    private readonly ILogger<UpdateClm> _logger;
    private readonly FakeClock _testClock;
    private readonly ILogger<CustomerProfileService> _profileLogger;
    private readonly CustomerProfileService _customerProfileService;
    private readonly MockHttpMessageHandler _cpsHttpMock;
    private readonly ClmProfileSettings _clmProfileSettings;
    private readonly Mock<ICosmosDbService> _mockDbService;

    public ClmUpdateTest(ILogger<UpdateClm> logger, ILogger<CustomerProfileService> profileLogger)
    {
      var testTime = new DateTime(2022, 1, 10, 7, 30, 45, DateTimeKind.Utc);
      var testInstant = Instant.FromDateTimeUtc(testTime);
      _testClock = new FakeClock(testInstant);
      _logger = logger;
      _profileLogger = profileLogger;
      _mockDbService = new Mock<ICosmosDbService>();

      _clmProfileSettings = new ClmProfileSettings()
      {
        BaseUrl = "http://domain/api/"
      };
      _cpsHttpMock = new MockHttpMessageHandler();
      _customerProfileService = new CustomerProfileService(_cpsHttpMock.ToHttpClient(), _clmProfileSettings, new ClmCustomerDtoMapper(), _profileLogger);
    }

    [Fact]
    public async void ValidJsonBody_Returns200()
    {
      //Arrange
      var requestJson = Utils.ReadFixture("requestFromFetcher.json");
      var dtos = JsonConvert.DeserializeObject<List<PostiCustomerChangeDto>>(requestJson);
      var request = Utils.CreateMockRequestWithBody(dtos).Object;

      var mapperMock = new ClmChangeMapper();
      dtos.ForEach(dto => SetMockHttp(HttpStatusCode.NoContent, dto.CustomerId));
      var clmUpdate = new UpdateClm(_logger, _customerProfileService, mapperMock, _mockDbService.Object, _testClock);

      //Act
      var response = await clmUpdate.Run(request);

      //Assert            
      response.Should().BeAssignableTo<OkResult>();
      _mockDbService.VerifyNoOtherCalls();
    }

    [Fact]
    public async void CLMConflict_Returns200()
    {
      //Arrange
      var requestJson = Utils.ReadFixture("duplicate.json");
      var dtos = JsonConvert.DeserializeObject<List<PostiCustomerChangeDto>>(requestJson);
      var request = Utils.CreateMockRequestWithBody(dtos).Object;
      var customerProfileMock = new Mock<ICustomerProfileService>();
      var changesResponse = new List<ClmResponse>
      {
        ClmResponse.CreateConflictStatus(ClmChangeStatus.Conflict, dtos[0].CustomerId)
      };
      customerProfileMock.Setup(x => x.ProcessChangesAsync(It.IsAny<List<ClmChangeModel>>()))
        .Returns(Task.FromResult(changesResponse));
      var mapperMock = new ClmChangeMapper();
      dtos.ForEach(dto => SetMockHttp(HttpStatusCode.NoContent, dto.CustomerId));
      var clmUpdate = new UpdateClm(_logger, customerProfileMock.Object, mapperMock, _mockDbService.Object, _testClock);

      //Act
      var response = await clmUpdate.Run(request);

      //Assert            
      response.Should().BeAssignableTo<OkResult>();
      _mockDbService.VerifyNoOtherCalls();
      customerProfileMock.Verify(x => x.SetCLMDuplicateAttribute(It.IsAny<ClmChangeModel>()),Times.Once);
    }

    [Fact]
    public async void ClientServiceExceptionWhileProcessing_Return500()
    {
      //Arrange
      var requestJson = Utils.ReadFixture("requestFromFetcher.json");
      var dtos = JsonConvert.DeserializeObject<List<PostiCustomerChangeDto>>(requestJson);
      var clmErrors = new List<ClmUpdateErrorDocument>();
      PrepareDocuments(dtos, clmErrors);

      dtos.ForEach(dto => SetMockHttp(HttpStatusCode.InternalServerError, dto.CustomerId));

      var request = Utils.CreateMockRequestWithBody(dtos).Object;
      var mapperMock = new ClmChangeMapper();
      var clmUpdate = new UpdateClm(_logger, _customerProfileService, mapperMock, _mockDbService.Object, _testClock);

      //Act
      var response = await clmUpdate.Run(request);

      //Assert
      response.Should().BeAssignableTo<ObjectResult>();
      var result = (ObjectResult)response;

      result.StatusCode.Should().Be(StatusCodes.Status500InternalServerError);
      result.Value.Should().BeAssignableTo<FailedActionResponse>();
      _mockDbService.Verify();
      //_mockDbService.VerifyNoOtherCalls();
    }

    private void PrepareDocuments(List<PostiCustomerChangeDto> dtos, List<ClmUpdateErrorDocument> clmErrors)
    {
      foreach (var dto in dtos)
      {
        var model = PrepareClmChangeObject(dto);
        if (model.ChangeStatus.IsDuplicated.HasValue && model.ChangeStatus.IsDuplicated.Value)
        {
          clmErrors.Add(ClmUpdateErrorDocument.CreateFromChangeModelAndResponse(model, ClmResponse.CreateFailedStatus(ClmChangeStatus.PersonDuplicated, model.CustomerId), _testClock.GetCurrentInstant().ToUnixTimeSeconds()));
          continue;
        }
        if (model.ChangeStatus.WasIdentified.HasValue )
        {
          clmErrors.Add(ClmUpdateErrorDocument.CreateFromChangeModelAndResponse(model, ClmResponse.CreateFailedStatus(ClmChangeStatus.IdentifiedAssignmentSet, model.CustomerId), _testClock.GetCurrentInstant().ToUnixTimeSeconds()));

        }
        if (model.ChangeStatus.WasIdentified == false)
          continue;
        if (model.ChangeStatus.WasModified.HasValue && model.ChangeStatus.WasModified.Value)
          clmErrors.Add(ClmUpdateErrorDocument.CreateFromChangeModelAndResponse(model, ClmResponse.CreateFailedStatus(ClmChangeStatus.CustomerUpdated, model.CustomerId), _testClock.GetCurrentInstant().ToUnixTimeSeconds()));
      }

      foreach (var error in clmErrors)
      {
        _mockDbService
         .Setup(dbService => dbService.StoreClmUpdateError(It.Is<ClmUpdateErrorDocument>(document => document == error)))
         .ReturnsAsync(true)
         .Verifiable();
      }
    }

    [Fact]
    public async void NullRequest_Returns500()
    {
      //Assert
      DefaultHttpRequest request = null;

      var profileMock = new Mock<ICustomerProfileService>();
      var mapperMock = new Mock<IClmChangeMapper>();
      var clmUpdate = new UpdateClm(_logger, profileMock.Object, mapperMock.Object, _mockDbService.Object, _testClock);

      //Act
      var response = await clmUpdate.Run(request);

      //Assert            
      response.Should().BeAssignableTo<StatusCodeResult>();
      var result = (StatusCodeResult)response;

      result.Should().NotBeNull();
      result.StatusCode.Should().Be(StatusCodes.Status500InternalServerError);
      _mockDbService.VerifyNoOtherCalls();
    }

    private ClmChangeModel PrepareClmChangeObject(PostiCustomerChangeDto dto)
    {
      var mapper = new ClmChangeMapper();
      return mapper.Map(dto);
    }

    private void SetMockHttp(HttpStatusCode code, string customerId = "10001908")
    {
      var dto = new PostiCustomerChangeDto()
      {
        PostiChangeStatus = new PostiChangeStatusDto()
        {
          WasIdentified = true,
          WasModified = true,
          IsDuplicated = false
        },
        CustomerId = customerId,
        LastName = "Posti",
        FirstName = "Pertti-Liisa",
        Address = new PostiAddressDto()
        {
          AddressType = PostiAddressType.Finnish,
          PostalCode = "67830",
          City = "Kaupunki",
          Street = "Teststreet 12 A 404"
        },
        PersonStatus = new PostiPersonStatusDto()
        {
          IsDeceased = true,
          IsMinor = true,
        }
      };
      var clmChange = PrepareClmChangeObject(dto);

      string customerIdentifiedPath = $"customers/{clmChange.CustomerId}/assignments";
      string customerModifyPath = $"customers/{clmChange.CustomerId}";
      string assignmentPutPath = $"customers/{clmChange.CustomerId}/assignments/544551";
      var mockGetAssignmentsResponse = Utils.ReadFixture("assingmentsResponseNoAddressAssignments.json");

      _cpsHttpMock.When(System.Net.Http.HttpMethod.Post, $"{_clmProfileSettings.BaseUrl}{customerIdentifiedPath}").Respond(code);
      _cpsHttpMock.When(System.Net.Http.HttpMethod.Put, $"{_clmProfileSettings.BaseUrl}{assignmentPutPath}").Respond(code);
      _cpsHttpMock.When(System.Net.Http.HttpMethod.Get, $"{_clmProfileSettings.BaseUrl}{customerIdentifiedPath}").Respond("application/json", mockGetAssignmentsResponse);
      _cpsHttpMock.When(System.Net.Http.HttpMethod.Patch, $"{_clmProfileSettings.BaseUrl}{customerModifyPath}").Respond(code);
      _cpsHttpMock.When(System.Net.Http.HttpMethod.Patch, "*/10010851").Respond(HttpStatusCode.Conflict);
    }
  }

}
