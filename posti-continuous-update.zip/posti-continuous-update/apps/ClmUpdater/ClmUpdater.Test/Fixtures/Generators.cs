﻿namespace ClmUpdater.Test.Fixtures;

public static class Generators
{
  public static ClmChangeModel PrepareClmChangeModel(
    string city = "Kaupunki",
    string postalCode = "67830",
    string telephone = "",
    string street = "",
    string countryCode = "",
    string countryName = "",
    bool isDupilcated = false,
    bool wasModified = true,
    bool wasIdentified = true,
    string customerId = "11111",
    string? duplicatedId = null,
    string firstName = "Pertti-Liisa",
    string lastName = "Posti",
    bool isDeceased = false,
    bool isMinor = false,
    string ssn = ""
    )
  {
    var clmChangeModel = new ClmChangeModel()
    {
      Address = new ClmAddress()
      {
        City = city,
        PostalCode = postalCode,
        Telephone = telephone,
        Street = street,
        CountryCode = countryCode,
        CountryName = countryName
      },
      ChangeStatus = new ChangeStatus()
      {
        IsDuplicated = isDupilcated,
        WasIdentified = wasIdentified,
        WasModified = wasModified
      },
      CustomerId = customerId,
      DuplicatedId = duplicatedId,
      FirstName = firstName,
      LastName = lastName,
      PersonStatus = new ClmPersonStatus()
      {
        IsDeceased = isDeceased,
        IsMinor = isMinor
      },
      Ssn = ssn
    };

    return clmChangeModel;
  }

  public static PostiCustomerChangeDto CreateCustomerChangeDtoWithAddress(

    string? city = null,
    string? postalCode = null,
    string? street = null,
    string? otherAddressLine1 = null,
    string? otherAddressLine2 = null,
    string? otherAddressLine3 = null,
    string? otherAddressLine4 = null,
    string? countryCode = null,
    string? countryName = null,
    bool? isMinor = null,
    bool? isDeceased = null,
    string firstName = "Pertti-Liisa",
    string lastName = "Posti")
  {
    var dto = new PostiCustomerChangeDto()
    {
      PostiChangeStatus = new PostiChangeStatusDto()
      {
        WasIdentified = true,
        WasModified = true,
        IsDuplicated = false
      },
      CustomerId = "111",
      LastName = lastName,
      FirstName = firstName,
      Address = CreateAddressDto(postalCode, city, street),
      ForeignAddress = CreateForeignAddressDto(otherAddressLine1, otherAddressLine2, otherAddressLine3, otherAddressLine4, countryCode, countryName),
      PersonStatus = CreateStatusDto(isMinor, isDeceased)
    };

    return dto;

    PostiAddressDto CreateAddressDto(string? postalCode, string? city, string? street)
    {
      if (string.IsNullOrEmpty(postalCode) && string.IsNullOrEmpty(city) && string.IsNullOrEmpty(street))
        return null;

      return new PostiAddressDto()
      {
        PostalCode = postalCode,
        City = city,
        Street = street,
      };
    }

    PostiForeignAddressDto CreateForeignAddressDto(string? otherAddresLine1, string? otherAddresLine2, string? otherAddresLine3, string? otherAddresLine4, string? countryCode, string? countryName)
    {
      if (string.IsNullOrEmpty(otherAddresLine1) && string.IsNullOrEmpty(otherAddresLine2) && string.IsNullOrEmpty(otherAddresLine3) && string.IsNullOrEmpty(otherAddresLine4)
        && string.IsNullOrEmpty(countryName) && string.IsNullOrEmpty(countryCode))
        return null;

      return new PostiForeignAddressDto()
      {
        OtherAddressLine1 = otherAddresLine1,
        OtherAddressLine2 = otherAddresLine2,
        OtherAddressLine3 = otherAddresLine3,
        OtherAddressLine4 = otherAddresLine4,
        CountryCode = countryCode,
        CountryName = countryName
      };
    }

    PostiPersonStatusDto CreateStatusDto(bool? isMinor, bool? isDeceased)
    {
      if (isDeceased is null && isMinor is null)
        return null;

      return new PostiPersonStatusDto()
      {
        IsDeceased = isDeceased,
        IsMinor = isMinor
      };
    };
  }
}
