using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ClmUpdater.CosmosDb;
using FluentAssertions;
using FluentAssertions.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace ClmUpdater.Test
{
  public class DeleteClmUpdateErrorsTest
  {
    private readonly Mock<ICosmosDbService> _mockDbService;
    private readonly DeleteClmUpdateErrors _testTrigger;

    public DeleteClmUpdateErrorsTest(ILogger<DeleteClmUpdateErrors> logger)
    {
      _mockDbService = new Mock<ICosmosDbService>();
      _testTrigger = new DeleteClmUpdateErrors(logger, _mockDbService.Object);
    }

    [Theory]
    [InlineData(null)]
    [InlineData("2022-07-05T13:00:27Z")]
    public async void ValidRequest_SuccessResponse(string requestParam)
    {
      DateTime? param = !string.IsNullOrEmpty(requestParam) ? DateTime.Parse(requestParam) : null;

      var request = Utils.CreateMockRequestWithQuery(new Dictionary<string, Microsoft.Extensions.Primitives.StringValues>() {
      {"ErrorDateTime", requestParam }
    });
      _mockDbService.Setup(x => x.DeleteClmUpdateErrors(It.IsAny<DateTime?>())).ReturnsAsync(true);

      //Act
      Func<Task> act = () => _testTrigger.Run(null);

      //Assert            
      await act.Should().NotThrowAsync();
    }

    [Theory]
    [InlineData(null)]
    [InlineData("2022-07-05T13:00:27Z")]
    public async void ValidRequest_500ResponseAferFailedDeletion(string requestParam)
    {
      DateTime? param = !string.IsNullOrEmpty(requestParam) ? DateTime.Parse(requestParam) : null;

      var request = Utils.CreateMockRequestWithQuery(new Dictionary<string, Microsoft.Extensions.Primitives.StringValues>() {
      {"ErrorDateTime", requestParam }
    });
      _mockDbService.Setup(x => x.DeleteClmUpdateErrors(It.IsAny<DateTime?>())).ReturnsAsync(false);

      //Act
      Func<Task> act = () => _testTrigger.Run(null);

      //Assert            
      await act.Should().NotThrowAsync();

    }
  }
}
