﻿using System.Collections.Generic;
using System.Net;
using ClmUpdater.ClmApim;
using ClmUpdater.ClmApim.Mappers;
using ClmUpdater.ClmApim.Models;
using ClmUpdater.Config.Models;
using ClmUpdater.Mappers;
using ClmUpdater.Models;
using ClmUpdater.Test.Fixtures;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using RichardSzalay.MockHttp;
using Xunit;

namespace ClmUpdater.Test.ClmApim;
public class CustomerProfileServiceTest
{
  private readonly ILogger<CustomerProfileService> _logger;

  public CustomerProfileServiceTest(ILogger<CustomerProfileService> logger)
  {
    _logger = logger;
  }

  [Theory]
  [InlineData("", "", "Street example", null, null, "", "", "", "", "", "")]
  [InlineData("", "CityExample", "Street example", null, null, "", "", "", "", "", "")]
  [InlineData("01340", "CityExample", "Street example", null, null, "", "", "", "", "", "")]
  [InlineData("", "", "", true, null, "", "", "", "", "", "")]
  [InlineData("", "", "", null, true, "", "", "", "", "", "")]
  [InlineData("01340", "CityExample", "Street example", true, true, "", "", "", "", "", "")]
  [InlineData("", "", "", true, true, "line1", "", "", "", "CA", "Canada")]
  [InlineData("", "", "", true, true, "line1", "line2", "", "", "CA", "Canada")]
  [InlineData("", "", "", true, true, "line1", "line2", "line3", "", "CA", "Canada")]
  [InlineData("", "", "", true, true, "line1", "line2", "line3", "line4", "CA", "Canada")]
  [InlineData("", "", "", true, true, "", "line2", "line3", "line4", "CA", "Canada")]
  [InlineData("", "", "", true, true, "", "", "", "line4", "CA", "Canada")]
  public async void ModifyCustomerAsync_ValidPayloadWithAddressAndNoProblems_SuccessResponse(
    string postalCode, string city, string street, bool? isMinor, bool? isDeceased,
    string otherAddressLine1, string otherAddressLine2, string otherAddressLine3, string otherAddressLine4,
    string countryCode, string countryName)
  {
    //Arrange
    var settings = new ClmProfileSettings()
    {
      BaseUrl = "http://domain/api/"
    };

    var dto = Generators.CreateCustomerChangeDtoWithAddress(city, postalCode, street,
      otherAddressLine1, otherAddressLine2, otherAddressLine3, otherAddressLine4, countryCode, countryName,
      isMinor, isDeceased);
    var clmChange = PrepareClmChangeObject(dto);
    var mapper = new ClmCustomerDtoMapper();

    string customerModifyPath = $"customers/{clmChange.CustomerId}";

    var mockHttp = new MockHttpMessageHandler();
    mockHttp.When($"{settings.BaseUrl}{customerModifyPath}").Respond(HttpStatusCode.NoContent);
    var customerProfileService = new CustomerProfileService(mockHttp.ToHttpClient(), settings, mapper, _logger);

    //Act
    var result = await customerProfileService.ModifyCustomerAsync(clmChange);

    //Assert            
    result.Should().NotBeNull();
    result.ResponseStatus.Should().Be(ClmUpdater.ClmApim.Models.ClmResponseStatus.Success);
  }

  [Fact]
  public async void ModifyCustomerAsync_DisableProcessingChangesTrue_SuccessResponse()
  {
    //Arrange
    var settings = new ClmProfileSettings()
    {
      BaseUrl = "http://domain/api/",
      DisableProcessingChanges = true
    };

    var dto = Generators.CreateCustomerChangeDtoWithAddress();
    var clmChange = PrepareClmChangeObject(dto);
    var mapper = new ClmCustomerDtoMapper();

    var mockHttp = new MockHttpMessageHandler();
    var customerProfileService = new CustomerProfileService(mockHttp.ToHttpClient(), settings, mapper, _logger);

    //Act
    var result = await customerProfileService.ModifyCustomerAsync(clmChange);

    //Assert            
    result.Should().NotBeNull();
    result.ResponseStatus.Should().Be(ClmUpdater.ClmApim.Models.ClmResponseStatus.ActionNoNeeded);
  }

  [Fact]
  public async void ModifyCustomerAsync_HttpErroWhileProcessing_FailResponse()
  {
    //Arrange
    var settings = new ClmProfileSettings()
    {
      BaseUrl = "http://domain/api/"
    };
    var dto = new PostiCustomerChangeDto()
    {
      PostiChangeStatus = new PostiChangeStatusDto()
      {
        WasIdentified = true,
        WasModified = true,
        IsDuplicated = false
      },
      CustomerId = "10001908",
      LastName = "Posti",
      FirstName = "Pertti-Liisa",
      Address = new PostiAddressDto()
      {
        AddressType = PostiAddressType.Finnish,
        PostalCode = "67830",
        City = "Kaupunki",
        Street = "Teststreet 12 A 404"
      },
      PersonStatus = new PostiPersonStatusDto()
      {
        IsDeceased = true,
        IsMinor = true,
      }
    };
    var clmChange = PrepareClmChangeObject(dto);
    var mapper = new ClmCustomerDtoMapper();

    string customerModifyPath = $"customers/{clmChange.CustomerId}";

    var mockHttp = new MockHttpMessageHandler();
    mockHttp.When($"{settings.BaseUrl}{customerModifyPath}").Respond(HttpStatusCode.InternalServerError);
    var customerProfileService = new CustomerProfileService(mockHttp.ToHttpClient(), settings, mapper, _logger);

    //Act
    var result = await customerProfileService.ModifyCustomerAsync(clmChange);

    //Assert            
    result.Should().NotBeNull();
    result.ResponseStatus.Should().Be(ClmUpdater.ClmApim.Models.ClmResponseStatus.Fail);
  }

  //[Fact]
  //public async void ModifyCustomerAsync_AddAhvenanmaaMessage()
  //{
  //  //Arrange
  //  var settings = new ClmProfileSettings()
  //  {
  //    BaseUrl = "http://domain/api/"
  //  };
  //  var payloadToClm = new ClmCustomerDto
  //  {
  //    FirstName = "Pertti-Liisa",
  //    LastName = "Posti",
  //    Address = new AddressDto()
  //    {
  //      City = "Ulkomaa",
  //      Country = "FI",
  //      Street = "123 Address Some dummy street",
  //      PostalCode = "00000"
  //    },
  //    PatchAttributes = new List<PatchAttributeDto>()
  //    {
  //      new PatchAttributeDto()
  //      {
  //        Code = "CUS_TAYSI_IKA",
  //        Value = "1",
  //        Op = "add"
  //      },
  //      new PatchAttributeDto()
  //      {
  //        Code = "CUS_POSTIN_TUPLAT",
  //        Value = "Ahvenanmaalainen osoite - tarkista osoitetiedot",
  //        Op = "add"
  //      }
  //    }
  //  };
  //  var dto = new PostiCustomerChangeDto()
  //  {
  //    PostiChangeStatus = new PostiChangeStatusDto()
  //    {
  //      WasIdentified = true,
  //      WasModified = true,
  //      IsDuplicated = false
  //    },
  //    CustomerId = "10001908",
  //    LastName = "Posti",
  //    FirstName = "Pertti-Liisa",
  //    ForeignAddress = new PostiForeignAddressDto()
  //    {
  //      CountryCode = "AX",
  //      CountryName = "ABCD",
  //      OtherAddressLine1 = "123 Address",
  //      OtherAddressLine2 = "Some dummy street"
  //    },
  //    PersonStatus = new PostiPersonStatusDto()
  //    {
  //      IsDeceased = false,
  //      IsMinor = false,
  //    }
  //  };
  //  var clmChange = PrepareClmChangeObject(dto);
  //  var mapper = new ClmCustomerDtoMapper();

  //  string customerModifyPath = $"customers/{clmChange.CustomerId}";

  //  var mockHttp = new MockHttpMessageHandler();
  //  mockHttp.When($"{settings.BaseUrl}{customerModifyPath}").WithContent(JsonConvert.SerializeObject(payloadToClm)).Respond(HttpStatusCode.NoContent);
  //  var client = mockHttp.ToHttpClient();
  //  var customerProfileService = new CustomerProfileService(client, settings, mapper, _logger);

  //  //Act
  //  var result = await customerProfileService.ModifyCustomerAsync(clmChange);

  //  //Assert
    
  //  result.Should().NotBeNull();
  //  result.ResponseStatus.Should().Be(ClmUpdater.ClmApim.Models.ClmResponseStatus.Success);
  //}

  [Fact]
  public async void ModifyCustomerAsync_CLMConflict_SuccessResponse()
  {
    //Arrange
    var settings = new ClmProfileSettings()
    {
      BaseUrl = "http://domain/api/"
    };
    var dto = new PostiCustomerChangeDto()
    {
      PostiChangeStatus = new PostiChangeStatusDto()
      {
        WasIdentified = true,
        WasModified = true,
        IsDuplicated = false
      },
      CustomerId = "10001908",
      LastName = "Posti",
      FirstName = "Pertti-Liisa",
      Address = new PostiAddressDto()
      {
        AddressType = PostiAddressType.Finnish,
        PostalCode = "67830",
        City = "Kaupunki",
        Street = "Teststreet 12 A 404"
      },
      PersonStatus = new PostiPersonStatusDto()
      {
        IsDeceased = true,
        IsMinor = true,
      }
    };
    var clmChange = PrepareClmChangeObject(dto);
    var mapper = new ClmCustomerDtoMapper();

    string customerModifyPath = $"customers/{clmChange.CustomerId}";
    var mockHttp = new MockHttpMessageHandler();
    mockHttp.When($"{settings.BaseUrl}{customerModifyPath}").Respond(HttpStatusCode.Conflict);
   
    var customerProfileService = new CustomerProfileService(mockHttp.ToHttpClient(), settings, mapper, _logger);

    //Act
    var result = await customerProfileService.ModifyCustomerAsync(clmChange);

    //Assert
    result.Should().NotBeNull();
    result.ResponseStatus.Should().Be(ClmUpdater.ClmApim.Models.ClmResponseStatus.Conflict);
  }

  [Fact]
  public async void SetDuplicateAttribute_ValidPayload_SuccessResponse()
  {
    //Arrange
    var settings = new ClmProfileSettings()
    {
      BaseUrl = "http://domain/api/"
    };
    var dto = new PostiCustomerChangeDto()
    {
      PostiChangeStatus = new PostiChangeStatusDto()
      {
        WasIdentified = true,
        WasModified = true,
        IsDuplicated = true
      },
      CustomerId = "123",
      DuplicatedId = "124",
      LastName = "Posti",
      FirstName = "Pertti-Liisa",
      Address = new PostiAddressDto()
      {
        AddressType = PostiAddressType.Finnish,
        PostalCode = "67830",
        City = "Kaupunki",
        Street = "Teststreet 12 A 404"
      },
      PersonStatus = new PostiPersonStatusDto()
      {
        IsDeceased = true,
        IsMinor = true,
      }
    };
    var clmChange = PrepareClmChangeObject(dto);
    var mapper = new ClmCustomerDtoMapper();

    string customerModifyPath = $"customers/{clmChange.CustomerId}";

    var mockHttp = new MockHttpMessageHandler();
    mockHttp.When($"{settings.BaseUrl}{customerModifyPath}").Respond(HttpStatusCode.NoContent);
    var customerProfileService = new CustomerProfileService(mockHttp.ToHttpClient(), settings, mapper, _logger);

    //Act
    var result = await customerProfileService.SetDuplicateAttribute(clmChange);

    //Assert            
    result.Should().NotBeNull();
    result.ResponseStatus.Should().Be(ClmUpdater.ClmApim.Models.ClmResponseStatus.Success);
  }

  [Fact]
  public async void SetDuplicateAttribute_ValidPayload_ErrorResponse()
  {
    //Arrange
    var settings = new ClmProfileSettings()
    {
      BaseUrl = "http://domain/api/"
    };
    var dto = new PostiCustomerChangeDto()
    {
      PostiChangeStatus = new PostiChangeStatusDto()
      {
        WasIdentified = true,
        WasModified = true,
        IsDuplicated = true
      },
      CustomerId = "123",
      DuplicatedId = "124",
      LastName = "Posti",
      FirstName = "Pertti-Liisa",
      Address = new PostiAddressDto()
      {
        AddressType = PostiAddressType.Finnish,
        PostalCode = "67830",
        City = "Kaupunki",
        Street = "Teststreet 12 A 404"
      },
      PersonStatus = new PostiPersonStatusDto()
      {
        IsDeceased = true,
        IsMinor = true,
      }
    };
    var clmChange = PrepareClmChangeObject(dto);
    var mapper = new ClmCustomerDtoMapper();

    string customerModifyPath = $"customers/{clmChange.CustomerId}";

    var mockHttp = new MockHttpMessageHandler();
    mockHttp.When($"{settings.BaseUrl}{customerModifyPath}").Respond(HttpStatusCode.InternalServerError);
    var customerProfileService = new CustomerProfileService(mockHttp.ToHttpClient(), settings, mapper, _logger);

    //Act
    var result = await customerProfileService.SetDuplicateAttribute(clmChange);

    //Assert            
    result.Should().NotBeNull();
    result.ResponseStatus.Should().Be(ClmUpdater.ClmApim.Models.ClmResponseStatus.Fail);

  }


  [Theory]
  [InlineData("assingmentsResponseNoAddressAssignments.json", true)]
  [InlineData("assingmentsResponseNoAddressAssignments.json", false)]
  [InlineData("assingmentsResponseWithAddressAssignments.json", true)]
  [InlineData("assingmentsResponseWithAddressAssignments.json", false)]
  public async void MarkAsIdentifiedAsync_ValidPayloadAndNoProblems_SuccessResponse(string assignmentResponseFixturePath, bool wasIndentified)
  {
    //Arrange
    var settings = new ClmProfileSettings()
    {
      BaseUrl = "http://domain/api/"
    };
    var customerId = "10001908";
    var mapper = new ClmCustomerDtoMapper();

    string assignmentGetPostPath = $"customers/{customerId}/assignments";
    string assignmentPutPath = $"customers/{customerId}/assignments/544551";

    var mockHttp = new MockHttpMessageHandler();
    var mockGetAssignmentsResponse = Utils.ReadFixture(assignmentResponseFixturePath);
    mockHttp.When(System.Net.Http.HttpMethod.Post, $"{settings.BaseUrl}{assignmentGetPostPath}").Respond(HttpStatusCode.NoContent);
    mockHttp.When(System.Net.Http.HttpMethod.Put, $"{settings.BaseUrl}{assignmentPutPath}").Respond(HttpStatusCode.NoContent);
    mockHttp.When(System.Net.Http.HttpMethod.Get, $"{settings.BaseUrl}{assignmentGetPostPath}").Respond("application/json", mockGetAssignmentsResponse);
    var customerProfileService = new CustomerProfileService(mockHttp.ToHttpClient(), settings, mapper, _logger);

    //Act
    var result = await customerProfileService.MarkIdentifiedAssignment(customerId, wasIndentified);

    //Assert            
    result.Should().NotBeNull();
    result.ResponseStatus.Should().Be(ClmUpdater.ClmApim.Models.ClmResponseStatus.Success);
  }

  [Theory]
  [InlineData("assingmentsResponseWithI.json")]
  [InlineData("assingmentsResponseWithNV.json")]
  public async void MarkAsIdentifiedAsync_IgnoreUpdateForNVUsers_SuccessResponse(string assignmentResponseFixturePath)
  {
    //Arrange
    var settings = new ClmProfileSettings()
    {
      BaseUrl = "http://domain/api/",
      DisableProcessingChanges = false
    };
    
    var mapper = new ClmCustomerDtoMapper();
    var customerId = "10001908";

    string assignmentGetPostPath = $"customers/{customerId}/assignments";

    var mockHttp = new MockHttpMessageHandler();
    var mockGetAssignmentsResponse = Utils.ReadFixture(assignmentResponseFixturePath);
    mockHttp.When(System.Net.Http.HttpMethod.Get, $"{settings.BaseUrl}{assignmentGetPostPath}").Respond("application/json", mockGetAssignmentsResponse);
    var customerProfileService = new CustomerProfileService(mockHttp.ToHttpClient(), settings, mapper, _logger);

    //Act
    var result = await customerProfileService.MarkIdentifiedAssignment(customerId, true);

    //Assert            
    result.Should().NotBeNull();
    result.ResponseStatus.Should().Be(ClmUpdater.ClmApim.Models.ClmResponseStatus.ActionNoNeeded);
  }

  [Fact]
  public async void MarkAsIdentifiedAsync_DisableProcessingChangesTrue_SuccessResponse()
  {
    //Arrange
    var settings = new ClmProfileSettings()
    {
      BaseUrl = "http://domain/api/",
      DisableProcessingChanges = true
    };
    var customerId = "10001908";
    var mapper = new ClmCustomerDtoMapper();

    var mockHttp = new MockHttpMessageHandler(); ;
    var customerProfileService = new CustomerProfileService(mockHttp.ToHttpClient(), settings, mapper, _logger);

    //Act
    var result = await customerProfileService.MarkIdentifiedAssignment(customerId, true);

    //Assert            
    result.Should().NotBeNull();
    result.ResponseStatus.Should().Be(ClmUpdater.ClmApim.Models.ClmResponseStatus.ActionNoNeeded);
  }

  [Theory]
  [InlineData("assingmentsResponseNoAddressAssignments.json", true)]
  [InlineData("assingmentsResponseNoAddressAssignments.json", false)]
  [InlineData("assingmentsResponseWithAddressAssignments.json", true)]
  [InlineData("assingmentsResponseWithAddressAssignments.json", false)]
  public async void MarkAsIdentifiedAsync_HttpErrorOnPostPut_FailResponse(string assignmentResponseFixturePath, bool wasIdentified)
  {
    //Arrange
    var settings = new ClmProfileSettings()
    {
      BaseUrl = "http://domain/api/"
    };
    var customerId = "10001908";
    var mapper = new ClmCustomerDtoMapper();

    string assignmentGetPostPath = $"customers/{customerId}/assignments";
    string assignmentPutPath = $"customers/{customerId}/assignments/544551";

    var mockHttp = new MockHttpMessageHandler();
    var mockGetAssignmentsResponse = Utils.ReadFixture(assignmentResponseFixturePath);
    mockHttp.When(System.Net.Http.HttpMethod.Post, $"{settings.BaseUrl}{assignmentGetPostPath}").Respond(HttpStatusCode.InternalServerError);
    mockHttp.When(System.Net.Http.HttpMethod.Put, $"{settings.BaseUrl}{assignmentPutPath}").Respond(HttpStatusCode.InternalServerError);
    mockHttp.When(System.Net.Http.HttpMethod.Get, $"{settings.BaseUrl}{assignmentGetPostPath}").Respond("application/json", mockGetAssignmentsResponse);
    var customerProfileService = new CustomerProfileService(mockHttp.ToHttpClient(), settings, mapper, _logger);

    //Act
    var result = await customerProfileService.MarkIdentifiedAssignment(customerId, wasIdentified);

    //Assert            
    result.Should().NotBeNull();
    result.ResponseStatus.Should().Be(ClmUpdater.ClmApim.Models.ClmResponseStatus.Fail);
  }

  [Theory]
  [InlineData("assignmentResponse401.json", true, HttpStatusCode.Unauthorized)]
  [InlineData("assignmentResponse401.json", false, HttpStatusCode.Unauthorized)]
  [InlineData("assignmentResponseUnknown.json", true, HttpStatusCode.InternalServerError)]
  [InlineData("assignmentResponseUnknown.json", false, HttpStatusCode.InternalServerError)]
  public async void MarkAsIdentifiedAsync_HttpErrorFetchingAssignments_FailResponse(string assignmentResponseFixturePath, bool wasIdentified, HttpStatusCode code)
  {
    //Arrange
    var settings = new ClmProfileSettings()
    {
      BaseUrl = "http://domain/api/"
    };
    var customerId = "10001908";
    var mapper = new ClmCustomerDtoMapper();

    string assignmentGetPostPath = $"customers/{customerId}/assignments";
    string assignmentPutPath = $"customers/{customerId}/assignments/544551";

    var mockHttp = new MockHttpMessageHandler();
    var mockGetAssignmentsResponse = Utils.ReadFixture(assignmentResponseFixturePath);
    mockHttp.When(System.Net.Http.HttpMethod.Get, $"{settings.BaseUrl}{assignmentGetPostPath}").Respond(code, "application/json", mockGetAssignmentsResponse);
    var customerProfileService = new CustomerProfileService(mockHttp.ToHttpClient(), settings, mapper, _logger);

    //Act
    var result = await customerProfileService.MarkIdentifiedAssignment(customerId, wasIdentified);

    //Assert            
    result.Should().NotBeNull();
    result.ResponseStatus.Should().Be(ClmUpdater.ClmApim.Models.ClmResponseStatus.Fail);
  }

  private ClmChangeModel PrepareClmChangeObject(PostiCustomerChangeDto dto)
  {
    var mapper = new ClmChangeMapper();
    return mapper.Map(dto);
  }
}
