﻿using System.Linq;
using System.Net.Http;
using System.Threading;
using ClmUpdater.ClmApim;
using ClmUpdater.Config.Models;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using RichardSzalay.MockHttp;
using Xunit;

namespace ClmUpdater.Test.ClmApim;
public class AuthorizationServiceTest
{
  private readonly ILogger<AuthorizationService> _logger;

  public AuthorizationServiceTest(ILogger<AuthorizationService> logger)
  {
    _logger = logger;
  }

  [Fact]
  public async void AddAuthHeader_ValidResponse_AuthHeaderWithCorrectValue()
  {
    var settings = new ClmAuthSettings()
    {
      ClientId = "ClientId",
      ClientSecret = "secret",
      ApiKey = "apiKey",
      BaseUrl = "http://domain/api/"
    };

    var tokenCache = new TokenCache();

    var mockFileSendResponse = Utils.ReadFixture("tokenResponse.json");
    var mockHttp = new MockHttpMessageHandler();
    mockHttp.When($"{settings.BaseUrl}login").Respond("application/json", mockFileSendResponse);
    var authService = new AuthorizationService(mockHttp.ToHttpClient(), tokenCache, settings, _logger);
    var httpRequestMessage = new HttpRequestMessage();
    var cancellationToken = new CancellationToken();
    //Act
    await authService.AddAuthHeader(httpRequestMessage, cancellationToken);

    //Assert
    httpRequestMessage.Headers.Authorization.ToString().Should().Be($"{tokenCache.Token.AuthorizationHeaderValue}");
  }

  [Fact]
  public async void AddAuthHeader_ErrorResponse_AuthHeaderEmpty()
  {
    var settings = new ClmAuthSettings()
    {
      ClientId = "ClientId",
      ClientSecret = "secret",
      ApiKey = "apiKey",
      BaseUrl = "http://domain/api/"
    };

    var tokenCache = new TokenCache();

    var mockFileSendResponse = Utils.ReadFixture("errorTokenResponse.json");
    var mockHttp = new MockHttpMessageHandler();
    mockHttp.When($"{settings.BaseUrl}login").Respond("application/json", mockFileSendResponse);
    var authService = new AuthorizationService(mockHttp.ToHttpClient(), tokenCache, settings, _logger);
    var httpRequestMessage = new HttpRequestMessage();
    var cancellationToken = new CancellationToken();
    //Act
    await authService.AddAuthHeader(httpRequestMessage, cancellationToken);

    //Assert
    httpRequestMessage.Headers.Authorization.Should().BeNull();
  }

  [Fact]
  public void AddApiKeyHeader_RunFunction_ApimHeaderValid()
  {
    var settings = new ClmAuthSettings()
    {
      ClientId = "ClientId",
      ClientSecret = "secret",
      ApiKey = "apiKey",
      BaseUrl = "http://domain/api/"
    };

    var tokenCache = new TokenCache();

    var mockFileSendResponse = Utils.ReadFixture("tokenResponse.json"); var mockHttp = new MockHttpMessageHandler();
    mockHttp.When($"{settings.BaseUrl}login").Respond("application/json", mockFileSendResponse);
    var authService = new AuthorizationService(mockHttp.ToHttpClient(), tokenCache, settings, _logger);
    var httpRequestMessage = new HttpRequestMessage();

    //Act
    authService.AddApiKeyHeader(httpRequestMessage);

    //Assert
    httpRequestMessage.Headers.Contains("Ocp-Apim-Subscription-Key").Should().BeTrue();
    var apimHeaderValue = httpRequestMessage.Headers.GetValues("Ocp-Apim-Subscription-Key").ToList().FirstOrDefault();

    apimHeaderValue.Should().Be(settings.ApiKey);
  }
}
