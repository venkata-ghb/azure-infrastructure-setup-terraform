﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;
using System.Web.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using PostiIntegration.ClmUpdater;
using PostiIntegration.ClmUpdater.Exceptions;
using PostiIntegration.CosmosDb;
using PostiIntegration.Models;
using PostiIntegration.Posti;
using PostiIntegration.Posti.Models;

namespace PostiIntegration
{
  public class FetchManualRegistryChanges
  {
    private readonly ILogger<FetchManualRegistryChanges> _logger;
    private readonly IPostiService _postiClient;
    private readonly IClmUpdaterService _clmUpdaterService;
    private readonly ICosmosDbService _cosmosDbService;

    public FetchManualRegistryChanges(ILogger<FetchManualRegistryChanges> logger, IPostiService postiClient, IClmUpdaterService clmUpdaterService, ICosmosDbService cosmosDbService)
    {
      _logger = logger;
      _postiClient = postiClient;
      _clmUpdaterService = clmUpdaterService;
      _cosmosDbService = cosmosDbService;
    }

    [FunctionName("FetchManualRegistryChanges")]
    public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req)
    {
      try
      {
        var json = await req.ReadAsStringAsync();

        if (json == null) return new BadRequestResult();

        var deliverable = JsonConvert.DeserializeObject<Deliverable>(json);
        //Fetch changes
        var changesResponse = await _postiClient.FetchFile(deliverable);
        LogFetchChangesStatus(changesResponse);
        //Prepare result based on response
        var returnResult = changesResponse.Status switch
        {
          PostiResultStatus.FilePreparationFailed =>
            new ObjectResult(new ErrorResponse(((FilePreparationFailedResult)changesResponse).Code, ((FilePreparationFailedResult)changesResponse).Message)) { StatusCode = StatusCodes.Status502BadGateway },
          PostiResultStatus.FetchingFailed => await StoreFailedFetchDetails((FileFetchingFailedResult)changesResponse),
          PostiResultStatus.Ok => await SendChangesAndStoreErrors((OkPostiResult)changesResponse),
          _ => new OkResult()
        };

        return returnResult;
      }
      
      catch (ClmUpdaterRequestException clmUpdaterException)
      {
        LogClmUpdaterRequestException(clmUpdaterException);
        return new InternalServerErrorResult();
      }
      catch (CosmosException cosmosException)
      {
        LogUnexpectedError(cosmosException);
        return new ObjectResult(new ErrorResponse("storing_file_fetch_errors_fails", "An error occurred while storing File Fetching Errors in database"))
        {
          StatusCode = StatusCodes.Status500InternalServerError
        };
      }
      catch (Exception ex)
      {
        LogUnexpectedError(ex);
        return new InternalServerErrorResult();
      }
    }

    private async Task<IActionResult> StoreFailedFetchDetails(FileFetchingFailedResult result)
    {
      var storeResult = await _cosmosDbService.StoreFileFetchingError(result);
      if (!storeResult)
        return new ObjectResult(new ErrorResponse("storing_file_fetch_errors_fails", "An error occurred while storing File Fetching Errors in database"))
        {
          StatusCode = StatusCodes.Status500InternalServerError
        };

      return new ObjectResult(new ErrorResponse(result.Code, result.Message)) { StatusCode = StatusCodes.Status502BadGateway };
    }

    private async Task<IActionResult> SendChangesAndStoreErrors(OkPostiResult changesResponse)
    {
      await SendChangesToClmUpdaterIfNeeded(changesResponse);
      var storeResult = await StorePostiErrorsInDbIfNeeded(changesResponse);
      if (!storeResult)
        return new ObjectResult(new ErrorResponse("storing_posti_errors_fails", "An error occurred while storing PostiErrors in database"))
        {
          StatusCode = StatusCodes.Status500InternalServerError
        };

      return new OkResult();
    }

    private async Task SendChangesToClmUpdaterIfNeeded(OkPostiResult okResponse)
    {
      if (okResponse.PostiChanges.Count <= 0)
        return;
      foreach (var chunk in okResponse.PostiChanges.Chunk(25))
      {
        await _clmUpdaterService.SendChangesAsync(chunk.ToList());
        Thread.Sleep(1000);
      }
    }

    private async Task<bool> StorePostiErrorsInDbIfNeeded(OkPostiResult okResponse)
    {
      if (okResponse.PostiErrors.Count <= 0)
        return true;

      var tasks = new List<Task<bool>>();
      foreach (var error in okResponse.PostiErrors)
      {
        tasks.Add(_cosmosDbService.StorePostiError(error));
      }

      var results = await Task.WhenAll(tasks);
      return results.All(x => x == true);
    }

    private void LogFetchChangesStatus(PostiResult changesResponse)
    {
      _logger.LogInformation("Posti fetch changes status.\n" +
          "Status: {status}", changesResponse.Status);
    }

    private void LogUnexpectedError(Exception ex)
    {
      _logger.LogError("There was an unexpected error:\n" +
          "Error: {error}\n" +
          "Stack trace: {trace}",
          ex, ex.StackTrace);
    }

    private void LogClmUpdaterRequestException(ClmUpdaterRequestException clmUpdaterException)
    {
      _logger.LogInformation(clmUpdaterException.ToString(), clmUpdaterException.StatusCode, clmUpdaterException.Reason);
    }

  }
}
