﻿using Newtonsoft.Json;

namespace PostiIntegration.Models;

/// <summary>
/// This model represent data that will be send to the CLM Updater function
/// </summary>
[JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
public record PostiCustomerChangeDto
{
  [JsonProperty("postiChangeStatus")]
  public PostiChangeStatusDto PostiChangeStatus { get; init; }
  [JsonProperty("customerId")]
  public string CustomerId { get; init; }
  [JsonProperty("duplicatedID")]
  public string DuplicatedId { get; init; }
  [JsonProperty("ssn")]
  public string Ssn { get; init; }
  [JsonProperty("lastName")]
  public string LastName { get; init; }
  [JsonProperty("firstName")]
  public string FirstName { get; init; }

  [JsonProperty("address")]
  public PostiAddressDto Address { get; init; }
  [JsonProperty("foreignAddress")]
  public PostiForeignAddressDto ForeignAddress { get; init; }

  [JsonProperty("personStatus")]
  public PostiPersonStatusDto PersonStatus { get; init; }
}

public record PostiChangeStatusDto
{
  [JsonProperty("wasIdentified")]
  public bool? WasIdentified { get; init; }
  [JsonProperty("wasModified")]
  public bool? WasModified { get; init; }
  [JsonProperty("isDuplicated")]
  public bool? IsDuplicated { get; init; }
}

public record PostiPersonStatusDto
{
  [JsonProperty("isMinor")]
  public bool? IsMinor { get; init; }
  [JsonProperty("isDeceased")]
  public bool? IsDeceased { get; init; }
}

public record PostiAddressDto
{
  [JsonProperty("addressType")]
  public PostiAddressType? AddressType { get; init; }
  [JsonProperty("postalCode")]
  public string PostalCode { get; init; }
  [JsonProperty("city")]
  public string City { get; init; }
  [JsonProperty("street")]
  public string Street { get; init; }
}

public class PostiForeignAddressDto
{
  [JsonProperty("otherAddressLine1")]
  public string OtherAddressLine1 { get; set; }
  [JsonProperty("otherAddressLine2")]
  public string OtherAddressLine2 { get; set; }
  [JsonProperty("otherAddressLine3")]
  public string OtherAddressLine3 { get; set; }
  [JsonProperty("otherAddressLine4")]
  public string OtherAddressLine4 { get; set; }
  [JsonProperty("countryCode")]
  public string CountryCode { get; set; }
  [JsonProperty("countryName")]
  public string CountryName { get; set; }
}
