﻿using Newtonsoft.Json;

namespace PostiIntegration.Models
{
  /// <summary>
  /// Incoming request body, that is corresponding to csv record that will be send to Posti
  /// </summary>
  public class RegistryRecordDto
  {
    [JsonProperty("operation")]
    public PostiOperations? Operation { get; init; }

    [JsonProperty("customerNumber")]
    public string CustomerNumber { get; init; }

    [JsonProperty("ssn")]
    public string Ssn { get; init; }

    [JsonProperty("lastName")]
    public string LastName { get; init; }

    [JsonProperty("firstName")]
    public string FirstName { get; init; }

    [JsonProperty("postalCode")]
    public string PostalCode { get; init; }

    [JsonProperty("city")]
    public string City { get; init; }

    [JsonProperty("address")]
    public string Address { get; init; }

    [JsonProperty("telephone")]
    public string Telephone { get; init; }

    [JsonProperty("email")]
    public string Email { get; init; }

    [JsonProperty("extra")]
    public string Extra { get; init; }
  }
}
