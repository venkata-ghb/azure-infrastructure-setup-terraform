﻿using System.Text.Json.Serialization;
using Newtonsoft.Json.Converters;

namespace PostiIntegration.Models;

[JsonConverter(typeof(StringEnumConverter))]
public enum PostiOperations
{
  Add,
  Remove,
  Modify
}
public enum BatchOperations
{
  Add,
  Remove,
  Modify
}
public enum PostiAddressType
{
  Finnish,
  Swedish
}
