﻿namespace PostiIntegration.Models;
public class BatchRecord
{
  public BatchOperations Operation { get; init; }
  public string CustomerNumber { get; init; }
  public string Ssn { get; init; }
  public string LastName { get; init; }
  public string FirstName { get; init; }
  public string PostalCode { get; init; }
  public string City { get; init; }
  public string Address { get; init; }
  public string Telephone { get; init; }
  public string Email { get; init; }
  public string Extra { get; init; }
  public long Timestamp { get; init; }
}
