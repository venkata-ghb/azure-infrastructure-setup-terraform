﻿using System.Collections.Generic;

namespace PostiIntegration.Models
{
  /// <summary>
  /// General Error response
  /// </summary>
  /// <typeparam name="T"></typeparam>
  /// <param name="Code">Error code</param>
  /// <param name="Errors">List of error</param>
  public record ErrorResponse<T>(string Code, IEnumerable<T> Errors);

  /// <summary>
  /// General Error response
  /// </summary>
  /// <typeparam name="T"></typeparam>
  /// <param name="Code">Error code</param>
  /// <param name="Errors">Error message</param>
  public record ErrorResponse(string Code, string Error);
}
