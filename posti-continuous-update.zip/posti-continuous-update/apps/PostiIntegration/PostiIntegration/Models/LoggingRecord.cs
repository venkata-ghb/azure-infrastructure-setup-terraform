﻿namespace PostiIntegration.Models;
public class LoggingRecord
{
  public string CustomerNumber { get; init; }
  public bool? WasIdentified { get; init; }
  public bool? WasModified { get; init; }
  public bool? IsDuplicated { get; init; }
  public bool? WasAddressChanged { get; init; }
  public bool? WasForeignAddressChanged { get; init; }
  public bool? WasNameChanged { get; init; }
  public bool? IsMinor { get; init; }
  public bool? IsDeceased { get; init; }
}

public record PostiRegistryLoggingRecord(string CustomerNumber, string Operation);
