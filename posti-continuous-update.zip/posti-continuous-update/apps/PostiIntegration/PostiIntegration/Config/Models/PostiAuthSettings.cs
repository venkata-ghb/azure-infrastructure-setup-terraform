﻿namespace PostiIntegration.Config.Models;
public class PostiAuthSettings : ICustomApplicationSetting
{
  public string BaseUrl { get; init; }
  public int TokenTreshold { get; init; }
  public string ConsumerKey { get; init; }
  public string ConsumerSecret { get; init; }
}
