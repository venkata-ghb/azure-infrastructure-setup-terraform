﻿namespace PostiIntegration.Config.Models;
public class ClmUpdaterSettings : ICustomApplicationSetting
{
  public string Url { get; init; }
  public string HostKey { get; init; }

  //Feature flags
  public bool DisableSendingChangesToClmUpdater { get; init; }
}
