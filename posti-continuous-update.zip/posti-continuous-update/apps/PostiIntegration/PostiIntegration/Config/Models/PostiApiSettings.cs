﻿namespace PostiIntegration.Config.Models;
public class PostiApiSettings : ICustomApplicationSetting
{
  public string BaseUrl { get; init; }
  public string RegistryId { get; init; }
  public int RetryCount { get; init; }
  public int RetryIncrementInSeconds { get; init; }

  //Feature flags
  public bool DisableFetchingChangesFromPosti { get; init; }
  public bool DisableSendingChangesToPosti { get; init; }
}
