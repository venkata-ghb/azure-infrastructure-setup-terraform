﻿namespace PostiIntegration.Config.Models;
public class FunctionSettings : ICustomApplicationSetting
{
  public bool DisableFileRefetch { get; init; }
}
