﻿namespace PostiIntegration.Config.Models;
public class CosmosDbSettings : ICustomApplicationSetting
{
  public string Name { get; init; }
  public string ConnectionString { get; init; }
  public string PostiErrorsContainer { get; init; }
  public string FileFetchingErrorsContainer { get; init; }
  // Feature flags
  public bool DisableStorePostiErrors { get; init; }
  public bool DisableStoreFileFetchingErrors { get; init; }
}
