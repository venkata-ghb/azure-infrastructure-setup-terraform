﻿namespace PostiIntegration.Config.Models;
public class EventBatcherSettings : ICustomApplicationSetting
{
  public string Url { get; init; }
  public string HostKey { get; init; }

  //Feature flags
  public bool DisableBatchFetching { get; init; }
  public bool DisableDeletingDuplicate { get; init; }
}
