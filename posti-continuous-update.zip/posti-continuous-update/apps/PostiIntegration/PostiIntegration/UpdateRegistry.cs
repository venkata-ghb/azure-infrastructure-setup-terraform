using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FluentValidation;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using PostiIntegration.Models;
using PostiIntegration.Posti;
using PostiIntegration.Validators;

namespace PostiIntegration
{
  public class UpdateRegistry
  {
    private readonly ILogger<UpdateRegistry> _logger;
    private readonly IValidator<IList<RegistryRecordDto>> _validator;
    private readonly IPostiService _postiService;

    public UpdateRegistry(ILogger<UpdateRegistry> logger, IValidator<IList<RegistryRecordDto>> validator, IPostiService postiService)
    {
      _logger = logger;
      _validator = validator;
      _postiService = postiService;
    }

    [FunctionName("UpdateRegistry")]
    public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req)
    {
      try
      {
        var json = await req.ReadAsStringAsync();
        var loggingRecord = JsonConvert.DeserializeObject<List<PostiRegistryLoggingRecord>>(json);
        LogReceivedRequest(JsonConvert.SerializeObject(loggingRecord));
        var records = JsonConvert.DeserializeObject<List<RegistryRecordDto>>(json);

        _validator.Validate(records, options => options.ThrowOnFailures());
        var result = await _postiService.SendChangesAsync(records);

        if (result.Status == Posti.Models.SendChangesStatus.Fail)
        {
          var failed = result as Posti.Models.SendChangesFailed;
          return new ObjectResult(new ErrorResponse(failed.Code, failed.Message)) { StatusCode = StatusCodes.Status502BadGateway };
        }

        return new OkResult();
      }
      catch (JsonSerializationException ex)
      {
        LogSerializationError(ex);
        return new BadRequestObjectResult(new ErrorResponse("serialization_error", ex.Message));
      }
      catch (ValidationException ex)
      {
        LogValidationError(ex);
        return new BadRequestObjectResult(new ErrorResponse<ValidationError>("validation_error", ex.Errors.Select(e => new ValidationError(e.PropertyName, e.ErrorMessage))));
      }
      catch (Exception ex)
      {
        LogUnexpectedError(ex);
        return new StatusCodeResult(StatusCodes.Status500InternalServerError);
      }
    }

    private void LogSerializationError(JsonSerializationException ex)
    {
      _logger.LogError("There was a serialization error:\n" +
          "Message: {message}\n" +
          "Stack trace: {stackTrace}", ex.Message, ex.StackTrace);
    }

    private void LogReceivedRequest(string requestBody)
    {
      _logger.LogInformation("Received registry update request \n" +
          "Request: {request}", requestBody);
    }

    private void LogValidationError(ValidationException ex)
    {
      _logger.LogError("There was a validation error:\n" +
          "Message: {Message}", ex.Message);
    }
    private void LogUnexpectedError(Exception ex)
    {
      _logger.LogError("There was an unexpected error:\n" +
          "Error: {error}\n" +
          "Stack trace: {trace}",
          ex, ex.StackTrace);
    }
  }
}
