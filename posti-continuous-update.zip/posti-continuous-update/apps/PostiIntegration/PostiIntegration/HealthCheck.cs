using System;
using System.Threading.Tasks;
using System.Web.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using PostiIntegration.CosmosDb;
using PostiIntegration.Posti;

namespace PostiIntegration;

public class HealthCheck
{
  private readonly ICosmosDbService _cosmosService;
  private readonly IPostiService _postiService;
  private readonly ILogger<HealthCheck> _logger;

  public HealthCheck(ICosmosDbService cosmosService, IPostiService postiService, ILogger<HealthCheck> log)
  {
    _cosmosService = cosmosService;
    _postiService = postiService;
    _logger = log;
  }
  [FunctionName("HealthCheck")]
  public async Task<IActionResult> Run(
      [HttpTrigger(AuthorizationLevel.Function, "get", Route = "Hv06apCobwy2Jz8PH8BV27S/health-check")] HttpRequest req)
  {

    try
    {
      _logger.LogInformation("Running Health Check");

      await _cosmosService.HealthCheckCall();
      await _postiService.HealthCheckCall();
      return new OkResult();
    }
    catch (Exception ex)
    {
      _logger.LogError(ex, "Healthcheck failed with exception.\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      ex.Message, ex.StackTrace);
      return new InternalServerErrorResult();
    }

  }
}
