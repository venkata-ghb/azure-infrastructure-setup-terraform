﻿using System.Net.Http;
using Microsoft.Extensions.Logging;
using Polly;

namespace PostiIntegration.Tools;
public static class ContextExtensions
{
  private static readonly string LoggerKey = "LoggerKey";
  private static readonly string RequestUriKey = "RequestUriKey";
  private static readonly string RequestMethodKey = "RequestMethodKey";

  public static Context WithLogger(this Context context, ILogger logger)
  {
    context[LoggerKey] = logger;
    return context;
  }

  public static ILogger GetLogger(this Context context)
  {
    if (context.TryGetValue(LoggerKey, out object logger))
    {
      return logger as ILogger;
    }
    return null;
  }

  public static Context WithRequest(this Context context, HttpRequestMessage request)
  {
    context[RequestMethodKey] = request.Method.Method;
    context[RequestUriKey] = request.RequestUri.AbsolutePath;
    return context;
  }

  public static string GetRequestUri(this Context context)
  {
    if (context.TryGetValue(RequestUriKey, out object uri))
    {
      return uri as string;
    }
    return null;
  }

  public static string GetRequestMethod(this Context context)
  {
    if (context.TryGetValue(RequestMethodKey, out object method))
    {
      return method as string;
    }
    return null;
  }
}

