﻿using System;
using System.Net.Http;
using Microsoft.Extensions.Logging;
using Polly;
using Polly.Retry;
using PostiIntegration.Config.Models;

namespace PostiIntegration.Tools;
public static class PollyPoliciesFactory
{
  public static AsyncRetryPolicy<HttpResponseMessage> CreateRetryPolicy(PostiApiSettings settings)
  {
    var retryPolicy = Policy.Handle<HttpRequestException>()
      .OrResult<HttpResponseMessage>(r => !r.IsSuccessStatusCode)
      .WaitAndRetryAsync(
              settings.RetryCount,
              retryAttempt => TimeSpan.FromSeconds(retryAttempt * settings.RetryIncrementInSeconds),
              onRetry: (outcome, timespan, retryAttempt, context) =>
              {
                var log = context.GetLogger();
                if (outcome.Exception != null)
                  LogException(outcome, retryAttempt, context, log);
                else
                  LogStatusCode(outcome, retryAttempt, context, log);
              }
      );

    return retryPolicy;
  }

  private static void LogStatusCode(DelegateResult<HttpResponseMessage> outcome, int retryAttempt, Context context, ILogger log)
  {
    log?.LogInformation("Request failed with status code {statusCode} \n" +
                        "Method: {method}\n" +
                        "Uri: {uri}\n" +
                        "Retry attempt: {retryAttempt}\n" +
                        "Auth Header Scheme: {authScheme}\n" +
                        "Auth Header Value: {authValue}\n",
                        outcome.Result.StatusCode,
                        context.GetRequestMethod(),
                        context.GetRequestUri(),
                        retryAttempt,
                        outcome.Result.RequestMessage.Headers.Authorization.Scheme,
                        outcome.Result.RequestMessage.Headers.Authorization.Parameter);
  }

  private static void LogException(DelegateResult<HttpResponseMessage> outcome, int retryAttempt, Context context, ILogger log)
  {
    log?.LogInformation("Request failed with exception \n" +
      "Method: {method}\n" +
      "Uri: {uri}\n" +
      "Retry attempt: {retryAttempt}\n" +
      "Exception: {message}",
      context.GetRequestMethod(),
      context.GetRequestUri(),
      retryAttempt,
      outcome.Exception.Message);
  }
}
