﻿using System;
using System.Globalization;
using Newtonsoft.Json;

namespace PostiIntegration.Tools;
public class PostiDateOnlyConverter : JsonConverter<DateOnly>
{
  private const string DateFormat = "yyyyMMdd";

  public override DateOnly ReadJson(JsonReader reader, Type objectType, DateOnly existingValue, bool hasExistingValue, JsonSerializer serializer)
  {
    return DateOnly.ParseExact((string)reader.Value, DateFormat, CultureInfo.InvariantCulture);
  }

  public override void WriteJson(JsonWriter writer, DateOnly value, JsonSerializer serializer)
  {
    writer.WriteValue(value.ToString(DateFormat, CultureInfo.InvariantCulture));
  }
}
