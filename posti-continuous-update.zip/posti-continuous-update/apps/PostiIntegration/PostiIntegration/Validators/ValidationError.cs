﻿namespace PostiIntegration.Validators
{
  public record ValidationError(string Field, string Operation);
}
