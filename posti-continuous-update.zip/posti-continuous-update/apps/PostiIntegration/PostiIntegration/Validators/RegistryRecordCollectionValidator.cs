﻿using System.Collections.Generic;
using FluentValidation;
using FluentValidation.Results;
using PostiIntegration.Models;

namespace PostiIntegration.Validators
{
  public class RegistryRecordCollectionValidator : AbstractValidator<IList<RegistryRecordDto>>
  {
    public RegistryRecordCollectionValidator()
    {
      RuleForEach(list => list).SetValidator(new RegistryRecordValidator());
    }

    protected override bool PreValidate(ValidationContext<IList<RegistryRecordDto>> context, ValidationResult result)
    {
      if (context.InstanceToValidate == null)
      {
        result.Errors.Add(new ValidationFailure("", "Collection is null"));
        return false;
      }
      return base.PreValidate(context, result);
    }
  }

  public class RegistryRecordValidator : AbstractValidator<RegistryRecordDto>
  {
    public RegistryRecordValidator()
    {
      RuleFor(x => x.Operation).NotEmpty().IsInEnum();
      RuleFor(x => x.CustomerNumber).NotEmpty().MaximumLength(50);
      RuleFor(x => x.Ssn).MaximumLength(11);
      RuleFor(x => x.LastName).NotEmpty().Unless(x => x.Operation == PostiOperations.Remove).MaximumLength(100);
      RuleFor(x => x.FirstName).NotEmpty().Unless(x => x.Operation == PostiOperations.Remove).MaximumLength(100);
      RuleFor(x => x.PostalCode).NotEmpty().Unless(x => x.Operation == PostiOperations.Remove).MaximumLength(5);
      RuleFor(x => x.City).MaximumLength(30);
      RuleFor(x => x.Address).NotEmpty().Unless(x => x.Operation == PostiOperations.Remove).MaximumLength(100);
      RuleFor(x => x.Telephone).MaximumLength(20);
      RuleFor(x => x.Email).MaximumLength(50);
      RuleFor(x => x.Extra).MaximumLength(50);
    }
  }
}
