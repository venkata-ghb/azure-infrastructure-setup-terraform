﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using PostiIntegration.ClmUpdater.Exceptions;
using PostiIntegration.Config.Models;
using PostiIntegration.EventBatcher.Mappers;
using PostiIntegration.EventBatcher.Models;
using PostiIntegration.Models;

namespace PostiIntegration.EventBatcher;
public interface IEventBatcherService
{
  Task<EventBatcherResult> GetBatchAsync(string fileCreation = "");
  Task PostEvent(List<CustomerLeftEvent> leftEvents);
}

public class EventBatcherService : IEventBatcherService
{
  private readonly HttpClient _httpClient;
  private readonly ILogger<EventBatcherService> _logger;
  private readonly IBatchRecordMapper _mapper;
  private readonly EventBatcherSettings _settings;

  public EventBatcherService(HttpClient httpClient, EventBatcherSettings eventBatcherSettings, ILogger<EventBatcherService> logger, IBatchRecordMapper mapper)
  {
    _httpClient = httpClient;

    _httpClient.BaseAddress = new System.Uri(eventBatcherSettings.Url);
    _httpClient.DefaultRequestHeaders.Add("x-functions-key", eventBatcherSettings.HostKey);
    _logger = logger;
    _mapper = mapper;
    _settings = eventBatcherSettings;
  }

  /// <summary>
  /// Fetch latest batch from Event Batcher
  /// </summary>
  /// <returns></returns>
  public async Task<EventBatcherResult> GetBatchAsync(string fileCreation = "")
  {
    if (_settings.DisableBatchFetching)
    {
      LogBatchFetchingDisabled();
      return new EventBatcherResult() { Status = EventBatcherResultStatus.BatchFetchingDisabled };
    }
    var urlQuery = string.IsNullOrEmpty(fileCreation) ? string.Empty : $"?BatchTime={GetDateTimeInCorrectFormat(fileCreation)}";

    var response = await _httpClient.GetAsync($"GetBatch{urlQuery}");

    if (!response.IsSuccessStatusCode)
    {
      var errorResponseMessage = await response.Content.ReadAsStringAsync();
      LogHttpError(response, errorResponseMessage);
      return new EventBatcherResult() { Status = EventBatcherResultStatus.HttpError };
    }

    var json = await response.Content.ReadAsStringAsync();
    LogLatestBatch(json);
    var batchRecordsDto = JsonConvert.DeserializeObject<List<BatchRecordDto>>(json);

    //If we're fetching a batch we're expecting that it won't be null or empty
    if (batchRecordsDto is null || batchRecordsDto.Count == 0)
    {
      LogEmptyResponse();
      return new EventBatcherResult() { Status = EventBatcherResultStatus.EmptyBatchError };
    }

    var batchRecords = _mapper.Map(batchRecordsDto);
    return new EventBatcherResult() { Status = EventBatcherResultStatus.Success, BatchRecords = batchRecords };
  }

  public async Task PostEvent(List<CustomerLeftEvent> leftEvents)
  {
    if (_settings.DisableDeletingDuplicate)
    {
      LogDeletingDuplicateDisabled();
      return;
    }

    var jsonBody = JsonConvert.SerializeObject(leftEvents);
    var data = new StringContent(jsonBody, Encoding.UTF8, "application/json");
    LogDeletingDuplicateDisabledBody(jsonBody);
    var response = await _httpClient.PostAsync("StoreCaputredEvents", data);

    if (!response.IsSuccessStatusCode)
    {
      var errorResponseMessage = await response.Content.ReadAsStringAsync();
      LogHttpError(response, errorResponseMessage);
    }

  }
  /// <summary>
  /// This function is for the Posti Sandbox Bug - this is temp fix for issue that suppose to be fixed in demo/prod env 
  /// In the get file details response it sends day in the incorrect format
  /// Example:
  /// 2022-10-283 13:02:09
  /// So instead of the day of month we get the day of the year
  /// </summary>
  /// <param name="dateTimeFromDto"></param>
  /// <returns></returns>
  private string GetDateTimeInCorrectFormat(string dateTimeFromDto)
  {
    var array = dateTimeFromDto.Split(" ");
    var dateInArray = array[0].Split("-");
    var timeInArray = array[1].Split(":");
    var days = Convert.ToInt32(dateInArray[2]) - 1;
    DateTime date = new DateTime(DateTime.Now.Year, 1, 1)
      .AddDays(days)
      .AddHours(Convert.ToInt32(timeInArray[0]))
        .AddMinutes(Convert.ToInt32(timeInArray[1]))
      .AddSeconds(Convert.ToInt32(timeInArray[2]));

    return date.ToString("yyyy-MM-ddTHH:mm:ssZ", CultureInfo.InvariantCulture);
  }

  private void LogBatchFetchingDisabled()
  {
    _logger.LogInformation("Fetching latest batch disabled");
  }

  private void LogDeletingDuplicateDisabled()
  {
    _logger.LogInformation("Deleting duplicate from registry disabled.");
  }

  private void LogDeletingDuplicateDisabledBody(string jsonBody)
  {
    _logger.LogInformation("Sending changes to EventHandler to disable duplicates.\n" +
            "Json request: {request}", jsonBody);
  }

  private void LogEmptyResponse()
  {
    _logger.LogInformation("Empty fetch response");
  }

  private void LogHttpError(HttpResponseMessage response, string errorResponseMessage)
  {
    _logger.LogError("Error while fetching latest batch \n" +
            "Status Code: {statusCode}\n" +
            "Reason: {reason}\n" +
            "Response: {content}", response.StatusCode, response.ReasonPhrase, errorResponseMessage);
  }

  private void LogLatestBatch(string json)
  {
    _logger.LogInformation("Latest batch response:\n" +
          "Response: {response}", json);
  }
}
