﻿using System.Collections.Generic;
using System.Text.Json.Serialization;
using Newtonsoft.Json.Converters;
using PostiIntegration.EventBatcher.Mappers;
using PostiIntegration.Models;

namespace PostiIntegration.EventBatcher.Models;
public class EventBatcherResult
{
  public EventBatcherResultStatus Status { get; init; }
  public List<BatchRecord> BatchRecords { get; init; }
}

[JsonConverter(typeof(StringEnumConverter))]
public enum EventBatcherOperations
{
  Add,
  Remove,
  Modify
}
