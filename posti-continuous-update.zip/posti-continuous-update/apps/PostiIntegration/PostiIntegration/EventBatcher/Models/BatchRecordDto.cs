﻿using Newtonsoft.Json;

namespace PostiIntegration.EventBatcher.Models;

/// <summary>
/// Contains information about a data that went into Posti Registry
/// Used when trying to get information want when wrong Posti Registry Update
/// </summary>
public record BatchRecordDto
{
  [JsonProperty("timestamp")]
  public long Timestamp { get; init; }

  [JsonProperty("operation")]
  public EventBatcherOperations Operation { get; init; }

  [JsonProperty("customerNumber")]
  public string CustomerNumber { get; init; }

  [JsonProperty("ssn")]
  public string Ssn { get; init; }

  [JsonProperty("lastName")]
  public string LastName { get; init; }

  [JsonProperty("firstName")]
  public string FirstName { get; init; }

  [JsonProperty("postalCode")]
  public string PostalCode { get; init; }

  [JsonProperty("city")]
  public string City { get; init; }

  [JsonProperty("address")]
  public string Address { get; init; }

  [JsonProperty("telephone")]
  public string Telephone { get; init; }

  [JsonProperty("email")]
  public string Email { get; init; }

  [JsonProperty("extra")]
  public string Extra { get; init; }
}
