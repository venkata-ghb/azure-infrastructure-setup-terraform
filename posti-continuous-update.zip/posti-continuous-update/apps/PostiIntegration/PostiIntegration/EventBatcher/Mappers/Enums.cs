﻿namespace PostiIntegration.EventBatcher.Mappers;
public enum EventBatcherResultStatus
{
  Success,
  HttpError,
  EmptyBatchError,
  BatchFetchingDisabled
}
