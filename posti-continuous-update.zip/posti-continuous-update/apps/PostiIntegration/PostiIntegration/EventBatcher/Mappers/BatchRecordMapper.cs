﻿using System.Collections.Generic;
using PostiIntegration.EventBatcher.Models;
using PostiIntegration.Models;

namespace PostiIntegration.EventBatcher.Mappers;

public interface IBatchRecordMapper
{
  BatchRecord Map(BatchRecordDto dto);
  List<BatchRecord> Map(List<BatchRecordDto> dtos);
}

public class BatchRecordMapper : IBatchRecordMapper
{
  public BatchRecord Map(BatchRecordDto dto)
  {
    var batchRecord = new BatchRecord()
    {
      Address = dto.Address,
      City = dto.City,
      CustomerNumber = dto.CustomerNumber,
      Email = dto.Email,
      FirstName = dto.FirstName,
      LastName = dto.LastName,
      Extra = dto.Extra,
      Operation = MapOperations(dto.Operation),
      PostalCode = dto.PostalCode,
      Ssn = dto.Ssn,
      Telephone = dto.Telephone,
      Timestamp = dto.Timestamp
    };

    return batchRecord;
  }

  private BatchOperations MapOperations(EventBatcherOperations operation)
    => operation switch
    {
      EventBatcherOperations.Add => BatchOperations.Add,
      EventBatcherOperations.Remove => BatchOperations.Remove,
      EventBatcherOperations.Modify => BatchOperations.Modify
    };

  public List<BatchRecord> Map(List<BatchRecordDto> dtos)
  {
    var batchRecords = new List<BatchRecord>();
    dtos.ForEach(dto => batchRecords.Add(Map(dto)));

    return batchRecords;
  }
}
