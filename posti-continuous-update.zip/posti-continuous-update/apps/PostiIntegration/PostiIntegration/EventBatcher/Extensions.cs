﻿using System.Collections.Generic;
using Microsoft.Extensions.DependencyInjection;
using PostiIntegration.EventBatcher.Mappers;
using PostiIntegration.Models;

namespace PostiIntegration.EventBatcher;
public static class Extensions
{
  public static IServiceCollection RegisterEventBatcherClients(this IServiceCollection services)
  {
    services.AddHttpClient<IEventBatcherService, EventBatcherService>();
    services.AddScoped<IBatchRecordMapper, BatchRecordMapper>();

    return services;
  }

  public static BatchRecord GetLine(this List<BatchRecord> batchRecords, int line)
  {
    return batchRecords[line - 1];
  }
}
