﻿using System.Threading.Tasks;

namespace PostiIntegration.Posti;
public interface ITokenService
{
  public Task<string> GetAccessToken();
  public Task<string> GetRawAccessToken();
}
