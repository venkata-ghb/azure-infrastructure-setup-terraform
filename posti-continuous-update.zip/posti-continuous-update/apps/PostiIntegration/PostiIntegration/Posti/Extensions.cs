﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using PostiIntegration.Config.Models;
using PostiIntegration.Posti.Csv;
using PostiIntegration.Posti.Factories;
using PostiIntegration.Tools;

namespace PostiIntegration.Posti;
public static class Extensions
{
  public static IServiceCollection RegisterPostiClients(this IServiceCollection services, IConfiguration configuration)
  {
    var postiAPiSettings = new PostiApiSettings();
    configuration.GetSection("PostiApiSettings").Bind(postiAPiSettings);

    services.AddTransient<BearerTokenHandler>();
    services.AddTransient<PollyContextHandler>();

    services.AddTransient<IPostiChangesFactory, PostiChangesFactory>();
    services.AddTransient<ICsvPreparer, CsvPreparer>();
    services.AddTransient<IRegistryRecordCsvFactory, RegistryRecordCsvFactory>();
    services.AddHttpClient<ITokenService, TokenService>();
    services.AddHttpClient<IPostiService, PostiService>()
      .AddHttpMessageHandler<PollyContextHandler>()
      .AddPolicyHandler(PollyPoliciesFactory.CreateRetryPolicy(postiAPiSettings))
      .AddHttpMessageHandler<BearerTokenHandler>();

    return services;
  }
}
