﻿using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;

namespace PostiIntegration.Posti;
public class BearerTokenHandler : DelegatingHandler
{
  private readonly ITokenService _tokenService;

  public BearerTokenHandler(ITokenService tokenService)
      => _tokenService = tokenService;

  protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
  {
    if (!request.Headers.Contains("Authorization"))
    {
      var token = await _tokenService.GetRawAccessToken();
      request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
    }

    return await base.SendAsync(request, cancellationToken);
  }
}
