﻿using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Polly;
using PostiIntegration.Tools;

namespace PostiIntegration.Posti;
public class PollyContextHandler : DelegatingHandler
{
  private readonly ILogger<PostiService> _logger;

  public PollyContextHandler(ILogger<PostiService> logger)
  {
    _logger = logger;
  }

  protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
  {
    var pollyContext = new Context()
      .WithLogger(_logger)
      .WithRequest(request);
    request.SetPolicyExecutionContext(pollyContext);

    return await base.SendAsync(request, cancellationToken);
  }
}
