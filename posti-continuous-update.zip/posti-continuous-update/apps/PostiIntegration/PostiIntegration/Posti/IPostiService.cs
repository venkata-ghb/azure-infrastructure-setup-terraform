﻿using System.Collections.Generic;
using System.Threading.Tasks;
using PostiIntegration.Models;
using PostiIntegration.Posti.Models;

namespace PostiIntegration.Posti;
public interface IPostiService
{
  public Task<PostiResult> GetChangesAsync();
  public Task<PostiResult> FetchFile(Deliverable dto);
  public Task<ISendChangesResult> SendChangesAsync(List<RegistryRecordDto> recordsDto);
  public Task<ISendChangesResult> CommitChangesAsync();
  public Task HealthCheckCall();
}
