﻿using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using CsvHelper;
using CsvHelper.Configuration;
using PostiIntegration.Models;
using PostiIntegration.Posti.Factories;
using PostiIntegration.Posti.Models;

namespace PostiIntegration.Posti.Csv;

public interface ICsvPreparer
{
  public ByteArrayContent PrepareCsv(RegistryRecordDto[] records);
}
public class CsvPreparer : ICsvPreparer
{
  private readonly IRegistryRecordCsvFactory _factory;

  public CsvPreparer(IRegistryRecordCsvFactory factory)
  {
    _factory = factory;
  }

  public ByteArrayContent PrepareCsv(RegistryRecordDto[] records)
  {
    //Map Dto to CSV model
    var mappedRecords = _factory.Map(records);
    //Create byte Array for all but last records
    var configWithNewLine = new CsvConfiguration(CultureInfo.InvariantCulture)
    { Delimiter = ";", HasHeaderRecord = false, };
    var recordsArray = GetByteArray(mappedRecords.Take(mappedRecords.Count - 1), configWithNewLine);

    //Create array for just last record (which can't have new line in the end
    var configWithoutNewLine = new CsvConfiguration(CultureInfo.InvariantCulture)
    { Delimiter = ";", HasHeaderRecord = false, NewLine = "", ShouldQuote = args => false };
    var lastRecordArray = GetByteArray(mappedRecords.TakeLast(1), configWithoutNewLine);

    //Merge arrays and return as ByteArrayContent
    var mergedArrays = recordsArray.Concat(lastRecordArray);
    var fileContent = new ByteArrayContent(mergedArrays.ToArray());
    return fileContent;
  }

  private byte[] GetByteArray(IEnumerable<RegistryRecordCsv> records, CsvConfiguration config)
  {
    using var memoryStream = new MemoryStream();
    using var streamWriter = new StreamWriter(memoryStream);
    using var csv = new CsvWriter(streamWriter, config);

    csv.WriteRecords(records);
    csv.Flush();
    return memoryStream.ToArray();
  }
}
