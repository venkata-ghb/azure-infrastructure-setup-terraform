﻿using PostiIntegration.Models;

namespace PostiIntegration.Posti.Models;

public record PostiError
{
  public FetchErrorType FetchErrorType { get; init; }
  public string Operation { get; init; }
  public string ErrorMessage { get; init; }
  public string CustomerId { get; init; }
  public string Ssn { get; init; }
  public string LastName { get; init; }
  public string FirstName { get; init; }
  public string Telephone { get; init; }
  public string Email { get; init; }
  public string Extra { get; init; }
  public string PostalCode { get; init; }
  public string City { get; init; }
  public string Address { get; init; }
  public long Timestamp { get; init; }

  public static PostiError CreateFromBatchRecordAndMessage(BatchRecord batchRecord, string message)
  {
    return new PostiError()
    {
      FetchErrorType = GetErrorType(message),
      Address = batchRecord.Address,
      City = batchRecord.City,
      PostalCode = batchRecord.PostalCode,
      CustomerId = batchRecord.CustomerNumber,
      Email = batchRecord.Email,
      ErrorMessage = message,
      Extra = batchRecord.Extra,
      FirstName = batchRecord.FirstName,
      LastName = batchRecord.LastName,
      Ssn = batchRecord.Ssn,
      Telephone = batchRecord.Telephone,
      Operation = batchRecord.Operation.ToString(),
      Timestamp = batchRecord.Timestamp
    };
  }

  private static FetchErrorType GetErrorType(string errorMessage) =>
    errorMessage switch
    {
      "person does not exist in the follow-up register" => FetchErrorType.PersonDoesNotExist,
      "Person already exists in the follow-up register with a same customer number" => FetchErrorType.CustomerIdAlreadyExists,
      _ => FetchErrorType.Other
    };
}
