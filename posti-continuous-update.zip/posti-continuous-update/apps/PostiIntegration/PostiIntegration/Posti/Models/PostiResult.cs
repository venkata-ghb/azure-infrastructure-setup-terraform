﻿using System;
using System.Collections.Generic;

namespace PostiIntegration.Posti.Models;

/// <summary>
/// Errors about customer that Posti didn't update. For example there was already customer with given CustomerId
/// </summary>
public class PostiChangeError
{
  public string Line { get; init; }
  public string Message { get; init; }
}

/// <summary>
/// Model that containt information about posti fetch result
/// </summary>
public abstract class PostiResult
{
  public abstract PostiResultStatus Status { get; init; }
}

/// <summary>
/// Posti Fetch 
/// </summary>
public class NoChangesPostiResult : PostiResult
{
  public override PostiResultStatus Status { get; init; } = PostiResultStatus.NoChanges;
}

public class BatchMatchingErrorResult : PostiResult
{
  public override PostiResultStatus Status { get; init; } = PostiResultStatus.BatchMatchingError;
  public string Code { get; init; } = "batch_matching_failed";
  public string Message { get; init; } = "There was an issue while matching posti errors with batch file";
}

/// <summary>
/// When file preparation fails for some reason
/// </summary>
public class FilePreparationFailedResult : PostiResult
{
  public override PostiResultStatus Status { get; init; } = PostiResultStatus.FilePreparationFailed;
  public string Code { get; init; } = "file_preparation_failed";
  public string Message { get; init; } = "File was not created properly";
}

/// <summary>
/// When file fetching fails for some reason
/// </summary>
public class FileFetchingFailedResult : PostiResult
{
  public override PostiResultStatus Status { get; init; } = PostiResultStatus.FetchingFailed;
  public string Code { get; init; } = "fetching_failed";
  public string Message { get; init; } = "There was an issue while fetching file from Posti";

  public string Id { get; init; }
  public DateTime Created { get; init; }
  public int Lines { get; init; }
  public int Chunks { get; init; }

}

/// <summary>
/// Successful fetch. Contains status, changes and problems with last registry update
/// </summary>
public class OkPostiResult : PostiResult
{
  public override PostiResultStatus Status { get; init; } = PostiResultStatus.Ok;
  public string FileId { get; init; } = default;
  public List<PostiChange> PostiChanges { get; private set; } = new List<PostiChange>();
  public List<PostiError> PostiErrors { get; private set; } = new List<PostiError>();

  public OkPostiResult(string fileId)
  {
    FileId = fileId;
  }

  public void AddChange(PostiChange change)
  {
    if (change is null)
      return;
    PostiChanges.Add(change);
  }

  public void AddChanges(List<PostiChange> changes)
      => changes.ForEach(change => AddChange(change));

  public void AddErrors(List<PostiError> errors)
      => PostiErrors.AddRange(errors);
}
