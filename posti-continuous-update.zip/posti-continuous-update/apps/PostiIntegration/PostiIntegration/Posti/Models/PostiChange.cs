﻿using System;

namespace PostiIntegration.Posti.Models;


public class PostiChange
{
  public PostiChangeStatus PostiChangeStatus { get; init; }
  public string CustomerId { get; init; }
  public string? DuplicatedId { get; init; }
  public string Ssn { get; init; }
  public string LastName { get; init; }
  public string FirstName { get; init; }
  public Address Address { get; init; }
  public ForeignAddress ForeignAddress { get; init; }
  public PersonStatus PersonStatus { get; init; }
}

public record PostiChangeStatus
{
  public bool? WasIdentified { get; init; }
  public bool? WasModified { get; init; }
  public bool? IsDuplicated { get; init; }
}

public class PersonStatus
{
  public bool? IsMinor { get; init; }
  public bool? IsDeceased { get; init; }
  public DateOnly? DateOfDeath { get; init; }
}

public class Address
{
  public AddressType? AddressType { get; init; }
  public string PostalCode { get; init; }
  public string City { get; init; }
  public string Street { get; init; }
}

public class ForeignAddress
{
  public string OtherAddressLine1 { get; set; }
  public string OtherAddressLine2 { get; set; }
  public string OtherAddressLine3 { get; set; }
  public string OtherAddressLine4 { get; set; }
  public string CountryCode { get; set; }
  public string CountryName { get; set; }
}


