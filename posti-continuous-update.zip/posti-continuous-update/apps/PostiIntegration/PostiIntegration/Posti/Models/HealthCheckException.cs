﻿using System;

namespace PostiIntegration.Posti.Models;
public class HealthCheckException : ApplicationException
{

  public HealthCheckException(string message) : base(message)
  {
  }

}
