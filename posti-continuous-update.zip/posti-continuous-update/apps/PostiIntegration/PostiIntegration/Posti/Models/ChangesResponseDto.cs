﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using PostiIntegration.Tools;

namespace PostiIntegration.Posti.Models;

/// <summary>
/// This model represents "file" response from Posti
/// </summary>
/// <summary>
/// This model represents "file" response from Posti
/// </summary>
public record ChangesResponseDto
{
  [JsonProperty("runs")]
  public List<RunDto> Runs { get; init; } = default!;

  [JsonProperty("registry")]
  public List<RegistryDto> Registry { get; init; } = default!;
}

/// <summary>
/// Add comits
/// </summary>
public record RunDto()
{
  [JsonProperty("date")]
  public DateTime Date { get; init; } = default!;
  [JsonProperty("infos")]
  public List<InfoDto> Infos { get; init; } = default!;
  [JsonProperty("errors")]
  public List<InfoDto> Errors { get; init; } = default!;
}

/// <summary>
/// Information about the runs. Used for infos and errors
/// </summary>
public record InfoDto
{
  [JsonProperty("line")]
  public string Line { get; init; } = default!;
  [JsonProperty("message")]
  public string Message { get; init; } = default!;
}

/// <summary>
/// This represents changed made for one user
/// </summary>
public record RegistryDto
{
  [JsonProperty("status")]
  public Status? Status { get; init; } = default!;
  [JsonProperty("operationStatus")]
  public OperationStatus? OperationStatus { get; init; } = default!;
  [JsonProperty("details")]
  public DetailsDto Details { get; init; } = default!;

  [JsonProperty("customerId")]
  public string CustomerId { get; init; } = default!;
  [JsonProperty("duplicateCustomerId")]
  public string? Duplicate { get; init; } = default!;

  [JsonProperty("ssnOrDateOfBirth")]
  public string CustGivenSsn { get; init; } = default!;
  [JsonProperty("Changes")]
  public ChangesDto? Changes { get; init; }

}

/// <summary>
/// Address of the user
/// </summary>
public record AddressDto
{
  [JsonProperty("aStreetAddress")]
  public string Address { get; init; } = default!;
  [JsonProperty("aPostcodeName")]
  public string City { get; init; } = default!;
  [JsonProperty("aPostcode")]
  public string PostCode { get; init; } = default!;
  [JsonProperty("aAddressLanguageCode")]
  public AddressLanguage AddressLanguage { get; init; } = default!;
  [JsonProperty("aAddressFamilyId")]
  public string AddressFamilyId { get; init; } = default!;
  [JsonProperty("aAddressStatusCode")]
  public AddressStatus? AddressStatus { get; init; } = default!;

  [JsonProperty("aOtherAddressLine1")]
  public string OtherAddressLine1 { get; init; }

  [JsonProperty("aOtherAddressLine2")]
  public string OtherAddressLine2 { get; init; }

  [JsonProperty("aOtherAddressLine3")]
  public string OtherAddressLine3 { get; init; }

  [JsonProperty("aOtherAddressLine4")]
  public string OtherAddressLine4 { get; init; }

  [JsonProperty("aOtherCountryCode")]
  public string? CountryCode { get; init; }

  [JsonProperty("aCountryName")]
  public string? CountryName { get; init; }
}

/// <summary>
/// Status of the person
/// </summary>
public record PersonStatusDto
{
  [JsonProperty("sPersonStatusCode")]
  public PersonStatusEnum? Status { get; init; }

  [JsonProperty("sDayOfDeath")]
  [JsonConverter(typeof(PostiDateOnlyConverter))]
  public DateOnly? DayOfDeath { get; init; }
}

public record NameDto
{
  [JsonProperty("nNameStatusCode")]
  public NameStatus? NameStatus { get; init; } = default!;
  [JsonProperty("nFirstNames")]
  public string FirstName { get; init; } = default!;

  [JsonProperty("nLastName")]
  public string LastName { get; init; } = default!;
}

public record DetailsDto
{
  [JsonProperty("personStatus")]
  public PersonStatusDto? PersonStatus { get; init; } = default!;

  [JsonProperty("identification")]
  public IdentificationDto Identification { get; init; } = default!;
}

public record IdentificationDto
{
  [JsonProperty("dIdentificationCode")]
  public IdentificationStatus? IdentificationStatus { get; init; } = default!;

}

public record ChangesDto
{
  [JsonProperty("name")]
  public NameDto? Name { get; init; }

  [JsonProperty("address")]
  public AddressDto? Address { get; init; }
}
