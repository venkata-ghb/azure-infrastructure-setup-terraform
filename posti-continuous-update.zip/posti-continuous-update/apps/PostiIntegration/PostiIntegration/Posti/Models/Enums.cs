﻿using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Linq;
using System.Runtime.Serialization;
using System.Text.Json.Serialization;

namespace PostiIntegration.Posti.Models;
[JsonConverter(typeof(StringEnumConverter))]
public enum OperationStatus
{

  OperationSuccessful,
  PersonAddeToRegister,
  PersonRemovedFromRegister,
  PersonInfoModified,
  PersonDoesNotExistInRegister,
  PersonExistWithSameCustomerNo,
  OperationFailed

}
[JsonConverter(typeof(StringEnumConverter))]
public enum Status
{

  [EnumMember(Value = "CHANGED")]
  CHANGED = 1,

  [EnumMember(Value = "NO_CHANGE")]
  NO_CHANGE = 2,

  [EnumMember(Value = "NOT_DETECTED")]
  NOT_DETECTED = 3,

  [EnumMember(Value = "DUPLICATE")]
  DUPLICATE = 4,

  [EnumMember(Value = "REMOVED")]
  REMOVED = 5,

}

public enum PersonStatusEnum
{
  Alive,
  MinorAlive,
  Deceased
}

public enum IdentificationStatus
{
  IdentifiedWithNameAndAddress,
  IdentifiedWithSsn,
  NotIdentified,
  Duplicate
}

public enum NameStatus
{
  CorrectName,
  LastNameChanged,
  FirstNameChanged,
  LastAndFirstNameChanged,
  NameSpellingChanged
}

public enum AddressStatus
{
  AddressCorrect,
  AddressChanged,
  AddressSpellingRevised,
  RevisionOfTheAddressWithoutAssignment,
  AddressCannotBeDeliveredOrIsNotKnown,
  ForeignAddress
}

public enum AddressLanguage
{
  Finnish,
  Swedish
}

public enum AddressType
{
  Finnish,
  Swedish
}


public enum PostiResultStatus
{
  NoChanges,
  Ok,
  FilePreparationFailed,
  FetchingFailed,
  BatchMatchingError
}

public enum CsvRecordOperation
{
  A,
  R,
  M
}

public enum FetchErrorType
{
  CustomerIdAlreadyExists,
  PersonDoesNotExist,
  Other
}

