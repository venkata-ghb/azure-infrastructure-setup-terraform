﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using PostiIntegration.Config.Models;

namespace PostiIntegration.Posti;
public class TokenService : ITokenService
{
  private readonly HttpClient _httpClient;
  private readonly PostiAuthSettings _authSettings;
  private readonly ILogger<TokenService> _logger;

  private static readonly SemaphoreSlim _accessTokenSemaphore;
  private static AccessToken _accessToken;

  static TokenService()
  {
    _accessToken = null!;
    _accessTokenSemaphore = new SemaphoreSlim(1, 1);
  }

  public TokenService(HttpClient httpClient, PostiAuthSettings authSettings, ILogger<TokenService> logger)
  {

    _httpClient = httpClient;
    _authSettings = authSettings;
    _httpClient.BaseAddress = new Uri(authSettings.BaseUrl);
    _logger = logger;
  }

  public async Task<string> GetAccessToken()
  {
    try
    {
      await _accessTokenSemaphore.WaitAsync();
      if (_accessToken is not null && !_accessToken.Expired)
        return _accessToken.Token;

      string path = "";
      var keyValues = new List<KeyValuePair<string, string>>
      {
      new KeyValuePair<string, string>("grant_type","client_credentials"),
      new KeyValuePair<string, string>("client_id",_authSettings.ConsumerKey),
      new KeyValuePair<string, string>("client_secret",_authSettings.ConsumerSecret),
      };
      var content = new FormUrlEncodedContent(keyValues);
      var response = await _httpClient.PostAsync(path, content);

      var responseContentStream = await response.Content.ReadAsStringAsync();

      _accessToken = JsonConvert.DeserializeObject<AccessToken>(responseContentStream);
      LogInformationTokenAquired(_accessToken);
      _accessToken.SetThreshold(_authSettings.TokenTreshold);

      return _accessToken.Token;
    }
    finally
    {
      _accessTokenSemaphore.Release(1);
    }
  }

  public async Task<string> GetRawAccessToken()
  {
    string path = "";
    var keyValues = new List<KeyValuePair<string, string>>
    {
      new KeyValuePair<string, string>("grant_type","client_credentials"),
      new KeyValuePair<string, string>("client_id",_authSettings.ConsumerKey),
      new KeyValuePair<string, string>("client_secret",_authSettings.ConsumerSecret),
    };
    var content = new FormUrlEncodedContent(keyValues);
    var response = await _httpClient.PostAsync(path, content);

    var responseContentStream = await response.Content.ReadAsStringAsync();

    _accessToken = JsonConvert.DeserializeObject<AccessToken>(responseContentStream);
    LogRawInformationTokenAquired(_accessToken);

    return _accessToken.Token;

  }

  private void LogInformationTokenAquired(AccessToken accessToken)
  {
    _logger.LogInformation("Aquired access token.\n" +
        "Expires in: {expiryIn}", accessToken.ExpiresInSeconds);
  }

  private void LogRawInformationTokenAquired(AccessToken accessToken)
  {
    _logger.LogInformation("Aquired raw access token.\n" +
        "Expires in: {expiryIn}", accessToken.ExpiresInSeconds);
  }


}
