﻿using System;

namespace PostiIntegration.Posti;
public class AccessToken
{
  private TimeSpan _threshold = new(0, 55, 0);
  public string Token { get; }
  public int ExpiresInSeconds { get; }
  public DateTime Expires { get; }
  public bool Expired => (Expires - DateTime.UtcNow).TotalSeconds <= (ExpiresInSeconds - _threshold.TotalSeconds);

  public AccessToken(
      string access_token,
      int expires_in)
  {
    Token = access_token;
    ExpiresInSeconds = expires_in;
    Expires = DateTime.UtcNow.AddSeconds(ExpiresInSeconds);
  }

  public void SetThreshold(int minutes) => _threshold = new(0, minutes, 0);
}
