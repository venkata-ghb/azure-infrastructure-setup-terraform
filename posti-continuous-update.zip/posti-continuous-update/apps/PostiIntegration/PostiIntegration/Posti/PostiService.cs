using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Policy;
using System.Threading;
using System.Threading.Tasks;
using Azure.Core;
using Microsoft.Azure.Cosmos.Spatial;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using PostiIntegration.Config.Models;
using PostiIntegration.EventBatcher;
using PostiIntegration.EventBatcher.Mappers;
using PostiIntegration.EventBatcher.Models;
using PostiIntegration.Models;
using PostiIntegration.Posti.Csv;
using PostiIntegration.Posti.Factories;
using PostiIntegration.Posti.Models;

namespace PostiIntegration.Posti;
public class PostiService : IPostiService
{
  private readonly HttpClient _httpClient;
  private readonly PostiApiSettings _settings;
  private readonly ILogger<PostiService> _logger;
  private readonly IPostiChangesFactory _postiChangesFactory;
  private readonly ICsvPreparer _csvPreparer;
  private readonly IEventBatcherService _eventBatcherService;
  private readonly ITokenService _tokenService;
  private const string PostiJsonFileDeliveryType = "RESULT_JSON_FILE_CHANGES";

  public PostiService(HttpClient httpClient, PostiApiSettings settings, ILogger<PostiService> logger,
    IPostiChangesFactory postiChangesFactory, ICsvPreparer csvPreparer,
    IEventBatcherService eventBatcherService, ITokenService tokenService)
  {
    _httpClient = httpClient;
    _httpClient.BaseAddress = new System.Uri(settings.BaseUrl);
    _httpClient.Timeout = TimeSpan.FromMinutes(5);
    _settings = settings;
    _logger = logger;
    _postiChangesFactory = postiChangesFactory;
    _csvPreparer = csvPreparer;
    _eventBatcherService = eventBatcherService;
    _tokenService = tokenService;
  }

  #region Fetch Changes

  public async Task HealthCheckCall()
  {
    string route = $"register/{_settings.RegistryId}/status";
    var response = await _httpClient.GetAsync(route);
    //Retrying to get the token
    if (response.IsSuccessStatusCode == false)
    {
      var errorResponseMessage = await response.Content.ReadAsStringAsync();
      _logger.LogError("Posti API Health Check Failed with \n" +
        "Status code: {statusCode}\n" +
        "Reason: {reason}\n" +
        "Response message: {response}",
        response.StatusCode,
        response.ReasonPhrase,
        errorResponseMessage);
      throw new HealthCheckException($"Health check failed: {response.StatusCode}, {response.ReasonPhrase}, {errorResponseMessage}");
    }
  }
  public async Task<PostiResult> GetChangesAsync()
  {
    if (_settings.DisableFetchingChangesFromPosti)
    {
      LogPostiFetchDisabled();
      return new NoChangesPostiResult();
    }

      string prepareDelivery = $"register/{_settings.RegistryId}/status";
      var fileResponse = await _httpClient.GetAsync(prepareDelivery);
      //Retrying to get the token
      if (fileResponse.IsSuccessStatusCode == false)
      {
        //Log failed file preparation and return
        LogFilePreparationFailed();
        return new FilePreparationFailedResult();
      }

      var responseContentStream = await fileResponse.Content.ReadAsStringAsync();
      LogInformationFile(responseContentStream);


    return await PrepareChangesAsync(responseContentStream);

  }

  public async Task<PostiResult> FetchFile(Deliverable dto)
  {
    (var success, var contents, var errors) = await PrepareFileResponseContents(dto);

    if (!success)
    {
      //store file dto in db and return failed
      LogFileFetchingFailed(dto);
      return new FileFetchingFailedResult()
      {
        Id = dto.Id,
        Chunks = dto.NumberOfChunks,
        Created = dto.CreatedDate,
      };
    }

    LogFileFetchErrors(errors);

    var changesCollection = SerializeResponseToList(contents);
    (var changes, var changesErrors) = _postiChangesFactory.Create(changesCollection);

    var okResult = new OkPostiResult(dto.Id);
    okResult.AddChanges(changes);
    var duplicateUsers = changesCollection.Where(x => x.Status == Status.DUPLICATE && x.OperationStatus != OperationStatus.PersonExistWithSameCustomerNo && !string.IsNullOrEmpty(x.Duplicate)).ToList().Select(x => new CustomerLeftEvent
    {
      AccountType = "REGULAR",
      CustomerId = x.CustomerId,
      AddressValidationStatus = "",
      Timestamp = DateTimeOffset.UtcNow.ToString("yyyy-MM-dd'T'HH:mm:ssK"),
      EventType = "CUSTOMER_LEFT"
    }).ToList();

    if(duplicateUsers.Count > 0)
    {
      foreach (var chunk in duplicateUsers.Chunk(50))
      {
        await _eventBatcherService.PostEvent(chunk.ToList());
      }
    }

    //If errors were found in response, match them with latest batch
    //TODO if matching what we need to do?
    if (changesErrors.Count > 0)
    {
      var batchmatchingResult = await MatchErrorWithBatchRecords(changesErrors, okResult, dto.CreatedDate.ToString());
      if (batchmatchingResult == false) return new BatchMatchingErrorResult();
    }
    return okResult;
  }

  private async Task<PostiResult> PrepareChangesAsync(string jsonString)
  {
    if (jsonString != null && jsonString == "No changes")
      return new NoChangesPostiResult() { Status = PostiResultStatus.NoChanges };

    var file = JsonConvert.DeserializeObject<GetFileResponseDto>(jsonString);

    var selectedFile = file.Message.Updates.OrderByDescending(x => x.ProcessingDate).FirstOrDefault().Deliverables.Where(x => x.DeliverableType == PostiJsonFileDeliveryType && x.Status == "PROCESSED").FirstOrDefault();

    return await FetchFile(selectedFile);
  }

  private bool ContainsProcessedReadyFile(string jsonString)
  {
    if (jsonString == null)
      return false;
    var file = JsonConvert.DeserializeObject<GetFileResponseDto>(jsonString);

    var selectedFile = file.Message.Updates.OrderByDescending(x => x.ProcessingDate).FirstOrDefault().Deliverables.Where(x => x.DeliverableType == PostiJsonFileDeliveryType).FirstOrDefault();

    return selectedFile.Status == "PROCESSED";
  }

  private async Task<bool> MatchErrorWithBatchRecords(List<PostiChangeError> changesErrors, OkPostiResult okResult, string fileCreationDateTime)
  {
    var batchResult = await _eventBatcherService.GetBatchAsync(fileCreationDateTime);
    switch (batchResult.Status)
    {
      case EventBatcherResultStatus.HttpError:
        LogBatchHttpError();
        return false;
      case EventBatcherResultStatus.BatchFetchingDisabled:
        return true;
      case EventBatcherResultStatus.EmptyBatchError:
        LogEmptyBatchResponseError();
        return false;
      case EventBatcherResultStatus.Success:
        HandleSuccessulBatchFetch(changesErrors, okResult, batchResult);
        return true;
      default:
        return true;
    }
  }

  private void HandleSuccessulBatchFetch(List<PostiChangeError> changesErrors, OkPostiResult okResult, EventBatcher.Models.EventBatcherResult batchResult)
  {
    var errorRecords = new List<PostiError>();
    //Match and map errors from posti response with batch lines
    foreach (var error in changesErrors)
    {
      var batchRecord = batchResult.BatchRecords.GetLine(int.Parse(error.Line));
      var errorRecord = PostiError.CreateFromBatchRecordAndMessage(batchRecord, error.Message);
      errorRecords.Add(errorRecord);
    };
    okResult.AddErrors(errorRecords);
  }

  private List<RegistryDto> SerializeResponseToList(List<string> changesResponse)
  {
    var changesCollection = new List<RegistryDto>();

    foreach (var change in changesResponse)
    {
      var changes = JsonConvert.DeserializeObject<List<RegistryDto>>(change);
      changesCollection.AddRange(changes);
    }

    return changesCollection;
  }

  private async Task<Tuple<bool, List<string>, List<string>>> PrepareFileResponseContents(Deliverable dto)
  {
    var contents = new List<string>();
    var errors = new List<string>();
    for (int i = 1; i <= dto.NumberOfChunks; i++)
    {
      string path = $"register/{_settings.RegistryId}/result/{dto.Id}?chunk={i}";
      var contentResponse = await _httpClient.GetAsync(path);
      if (contentResponse.IsSuccessStatusCode == false)
      {
        return Tuple.Create(false, contents, errors);
      }

      var content = await contentResponse.Content.ReadAsStringAsync();
      LogInformationFileContent(path);
      dynamic row = JsonConvert.DeserializeObject(content);

      if (row.ToString().Contains("error"))
        errors.Add(content);
      else
        contents.Add(content);
    }

    return Tuple.Create(true, contents, errors);
  }
  #endregion

  #region Send changes
  public async Task<ISendChangesResult> SendChangesAsync(List<RegistryRecordDto> recordsDto)
  {
    if (_settings.DisableSendingChangesToPosti)
    {
      LogSendingChangesToPostiDisabled();
      return new SendChangesSuccess();
    }

    foreach (var chunk in recordsDto.Chunk(49000))
    {
      using var multipartFormContnent = new MultipartFormDataContent();
      string sendFileRoute = $"register/{_settings.RegistryId}/newFiles?forceStart=false";
      var fileContent = _csvPreparer.PrepareCsv(chunk);
      multipartFormContnent.Add(fileContent, name: "data", fileName: "data.csv");
      var fileResponse = await _httpClient.PostAsync(sendFileRoute, multipartFormContnent);
      if (!fileResponse.IsSuccessStatusCode)
        return SendChangesFailed.CreateUploadFailedStatus();
    }

    return new SendChangesSuccess();
  }

  public async Task<ISendChangesResult> CommitChangesAsync()
  {
    if (_settings.DisableSendingChangesToPosti)
    {
      LogSendingChangesToPostiDisabled();
      return new SendChangesSuccess();
    }
    
    string commitFiles = $"register/{_settings.RegistryId}/modifications";
    var commitResult = await _httpClient.PostAsync(commitFiles, null);

    if (!commitResult.IsSuccessStatusCode)
      return SendChangesFailed.CreateCommitFailedStatus();

    return new SendChangesSuccess();
  }
  #endregion

  #region Logging
  private void LogSendingChangesToPostiDisabled()
  {
    _logger.LogInformation("Sending changes to Posti disabled");
  }

  private void LogPostiFetchDisabled()
  {
    _logger.LogInformation("Fetching changes from Posti disabled");
  }

  private void LogInformationFile(string fileResponse)
  {
    _logger.LogInformation("Get file response\n" +
        "File response: {fileResponse}", fileResponse);
  }

  private void LogInformationFileContent(string requestPath)
  {
    _logger.LogInformation("Get file content response\n" +
        "Request's path: {path}\n", requestPath);
  }

  private void LogFilePreparationFailed()
  {
    _logger.LogError("File preparation failed");
  }

  private void LogToken(string token)
  {
    _logger.LogInformation("Token created:\n" +
        "{token}\n", token);
  }

  private void LogFileFetchingFailed(Deliverable dto)
  {
    _logger.LogError("Fetching file failed \n" +
        "FileId: {errors} Chunks: {chunks} Created: {created}",
        dto.Id, dto.NumberOfChunks, dto.CreatedDate);
  }

  private void LogFileFetchErrors(List<string> errorResponse)
  {
    if (errorResponse.Count > 0)
      _logger.LogError("Errors found on fetching \n" +
          "Errors: {errors}", errorResponse);
  }

  private void LogEmptyBatchResponseError()
  {
    _logger.LogError("Fetched batch was empty, even though errors were founds in Posti response");
  }

  private void LogBatchHttpError()
  {
    _logger.LogError("There was a http error while fetching latest batch");
  }
  #endregion
}
