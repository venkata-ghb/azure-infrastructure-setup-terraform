﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PostiIntegration.Posti.Models;

namespace PostiIntegration.Posti.Factories;
public interface IPostiChangesFactory
{
  public Tuple<List<PostiChange>, List<PostiChangeError>> Create(List<RegistryDto> changesCollection);
}

public class PostiChangesFactory : IPostiChangesFactory
{
  private readonly ILogger<PostiChangesFactory> _logger;

  public PostiChangesFactory(ILogger<PostiChangesFactory> logger)
  {
    _logger = logger;
  }

  public Tuple<List<PostiChange>, List<PostiChangeError>> Create(List<RegistryDto> changesCollection)
  {
    var removed = new List<string>();
    var mappedCollection = new List<PostiChange>();
    var mappedErrors = new List<PostiChangeError>();

    changesCollection.Where(x => x.Status != Status.REMOVED).ToList().ForEach(registryRow => mappedCollection.Add(PreparePostiChange(registryRow)));

    return Tuple.Create(mappedCollection, mappedErrors);
  }

  private void LogRemovedCustomers(List<string> removed)
  {
    _logger.LogInformation("Customers with following CustomerIds were removed successfully from Posti Registry \n" +
          "CustomerIds: {customerIds}", JsonConvert.SerializeObject(removed));
  }

  private PostiChange PreparePostiChange(RegistryDto registryDto)
  {
    var personStatus = new PersonStatus()
    {
      DateOfDeath = registryDto.Details?.PersonStatus?.DayOfDeath,

      IsDeceased = registryDto.Details != null && registryDto.Details?.PersonStatus != null && registryDto.Details.PersonStatus.Status.HasValue ? registryDto.Details.PersonStatus?.Status == PersonStatusEnum.Deceased : null,
      IsMinor = registryDto.Details != null && registryDto.Details?.PersonStatus != null && registryDto.Details.PersonStatus.Status.HasValue ? registryDto.Details.PersonStatus?.Status == PersonStatusEnum.MinorAlive : null,

    };

    var change = new PostiChange()
    {
      PostiChangeStatus = DtoToPostiChangeStatus(new ChangeState(
       registryDto.Status.HasValue ? registryDto.Status.Value : null,
        ((bool)(registryDto.Changes?.Name?.NameStatus != null) && (bool)(registryDto.Changes?.Name?.NameStatus.HasValue)) ? registryDto.Changes?.Name?.NameStatus.Value : null,
        ((bool)(registryDto.Changes?.Address?.AddressStatus != null) && (bool)(registryDto.Changes?.Address?.AddressStatus.HasValue)) ? registryDto.Changes?.Address?.AddressStatus.Value : null,
        registryDto.Details != null && registryDto.Details.Identification != null && registryDto.Details.Identification.IdentificationStatus != null && registryDto.Details.Identification.IdentificationStatus.HasValue ? registryDto.Details.Identification.IdentificationStatus.Value : null,
        personStatus,
        !string.IsNullOrEmpty(registryDto.Duplicate))),
      CustomerId = registryDto.CustomerId,
      DuplicatedId = registryDto.Duplicate,
      Ssn = registryDto.CustGivenSsn,
      LastName = registryDto.Changes?.Name?.LastName,
      FirstName = registryDto.Changes?.Name?.FirstName,
      Address = PrepareAddressFromDto(registryDto.Changes?.Address),
      ForeignAddress = PrepareForeignAddressFromDto(registryDto.Changes?.Address),
      PersonStatus = personStatus
    };

    return change;
  }

  private Address PrepareAddressFromDto(AddressDto addressDto)
  {
    //If foreign address then set address to null
    if (addressDto is null || addressDto.AddressStatus == AddressStatus.ForeignAddress)
      return null;

    return new Address()
    {
      AddressType = AddressLanguageToType(addressDto),
      PostalCode = addressDto?.PostCode,
      City = addressDto?.City,
      Street = addressDto?.Address
    };
  }

  private ForeignAddress PrepareForeignAddressFromDto(AddressDto addressDto)
  {
    //If not foreign address then set Foreign address to null
    if (addressDto is null || addressDto.AddressStatus != AddressStatus.ForeignAddress)
      return null;

    return new ForeignAddress()
    {
      CountryCode = addressDto?.CountryCode,
      CountryName = addressDto?.CountryName,
      OtherAddressLine1 = addressDto?.OtherAddressLine1,
      OtherAddressLine2 = addressDto?.OtherAddressLine2,
      OtherAddressLine3 = addressDto?.OtherAddressLine3,
      OtherAddressLine4 = addressDto?.OtherAddressLine4
    };
  }

  private record ChangeState(Status? Status, NameStatus? NameStatus, AddressStatus? AddressStatus,
    IdentificationStatus? IdentificationStatus, PersonStatus PersonStatus, bool IsDuplciated);

  private PostiChangeStatus DtoToPostiChangeStatus(ChangeState changeStatus)
  {
    var postiChangeStatus = new PostiChangeStatus()
    {
      IsDuplicated = changeStatus.IsDuplciated,
      WasIdentified = wasIdentified(changeStatus.IdentificationStatus),
      WasModified = wasModified(changeStatus)
    };

    return postiChangeStatus;
  }

  /// <summary>
  /// Maps identification status to boolean value
  /// </summary>
  /// <param name="identificationStatus"></param>
  /// <returns></returns>
  private bool wasIdentified(IdentificationStatus? identificationStatus) =>
    identificationStatus switch
    {
      IdentificationStatus.IdentifiedWithSsn => true,
      IdentificationStatus.IdentifiedWithNameAndAddress => true,
      _ => false
    };

  /// <summary>
  /// Maps multiple statuses to inforamtion if a given person was modified
  /// </summary>
  /// <param name="changeStatus"></param>
  /// <returns></returns>
  private bool wasModified(ChangeState changeStatus)
  {
    //If OperationStatus is equal to Person changed (telephone, email or extra changed that means that a person was modified
    if (changeStatus.Status == Status.CHANGED)
      return true;

    //If Address status is not equal to address correct that means that address has changed and that the person was modified
    if (changeStatus.AddressStatus.HasValue && changeStatus.AddressStatus != AddressStatus.AddressCorrect)
      return true;

    //If Name status is other the correct one, that means that it has been changed, and a person was modifed
    if (changeStatus.NameStatus.HasValue && changeStatus.NameStatus != NameStatus.CorrectName)
      return true;

    //If any of the person status fields is not null that means that the person has been modified
    if (changeStatus.PersonStatus is not null && changeStatus.PersonStatus.IsMinor.HasValue && changeStatus.PersonStatus.IsMinor.Value == true)
      return true;

    if (changeStatus.PersonStatus is not null && changeStatus.PersonStatus.IsDeceased.HasValue && changeStatus.PersonStatus.IsDeceased.Value == true)
      return true;

    return false;
  }

  private AddressType? AddressLanguageToType(AddressDto dto)
  {
    if (dto == null)
      return null;

    return dto.AddressLanguage switch
    {
      AddressLanguage.Finnish => AddressType.Finnish,
      AddressLanguage.Swedish => AddressType.Swedish,
      _ => null
    };
  }

  /*private string RemovedCustomerCheck(InfoDto infoDto)
  {
    Regex regex = new Regex(@"^Customer [\w]+ was removed$", RegexOptions.Compiled | RegexOptions.IgnoreCase);

    if (!regex.IsMatch(infoDto.Message))
      return null;

    return GetIdOfRemovedUser(infoDto.Message);
  }*/

  /*private PostiChangeError PreparePostiChangeError(InfoDto errorDto)
  {
    Regex regex = new Regex(@"^Customer [\w]+ was removed$", RegexOptions.Compiled | RegexOptions.IgnoreCase);

    var error = new PostiChangeError()
    {
      Line = errorDto.Line,
      Message = errorDto.Message
    };
    return error;
  }*/

  private string GetIdOfRemovedUser(string infoMessage)
  {
    var split = infoMessage.Split(' ');
    return split[1];
  }
}
