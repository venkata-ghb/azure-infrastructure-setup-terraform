﻿using System.Collections.Generic;
using PostiIntegration.Models;
using PostiIntegration.Posti.Models;

namespace PostiIntegration.Posti.Factories;

public interface IRegistryRecordCsvFactory
{
  public List<RegistryRecordCsv> Map(RegistryRecordDto[] dtos);
  public RegistryRecordCsv Map(RegistryRecordDto dto);
}

public class RegistryRecordCsvFactory : IRegistryRecordCsvFactory
{
  public List<RegistryRecordCsv> Map(RegistryRecordDto[] dtos)
  {
    var mappedList = new List<RegistryRecordCsv>();
    foreach (var dto in dtos)
      mappedList.Add(Map(dto));
    return mappedList;
  }

  public RegistryRecordCsv Map(RegistryRecordDto dto)
  {

    var csvRecord = new RegistryRecordCsv()
    {
      Operation = MapOperation(dto.Operation.Value),
      Address = dto.Address,
      City = dto.City,
      CustomerNumber = dto.CustomerNumber,
      Email = dto.Email,
      FirstName = dto.FirstName,
      LastName = dto.LastName,
      Extra = dto.Extra,
      PostalCode = dto.PostalCode,
      Ssn = dto.Ssn,
      Telephone = dto.Telephone
    };
    return csvRecord;
  }

  private string MapOperation(PostiOperations postiOperations)
      => postiOperations switch
      {
        PostiOperations.Add => CsvRecordOperation.A.ToString(),
        PostiOperations.Remove => CsvRecordOperation.R.ToString(),
        PostiOperations.Modify => CsvRecordOperation.M.ToString(),
        _ => string.Empty,
      };
}
