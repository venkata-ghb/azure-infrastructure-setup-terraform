﻿using System.Collections.Generic;
using PostiIntegration.Models;
using PostiIntegration.Posti.Models;

namespace PostiIntegration.ClmUpdater.Mappers;
/// <summary>
/// This factory maps domain models into dtos that will be send outside this function app
/// </summary>
public interface IPostiCustomerChangeDtoMapper
{
  public List<PostiCustomerChangeDto> Map(List<PostiChange> changes);
  public PostiCustomerChangeDto Map(PostiChange changes);
}

public class PostiCustomerChangeDtoMapper : IPostiCustomerChangeDtoMapper
{
  public List<PostiCustomerChangeDto> Map(List<PostiChange> changes)
  {
    List<PostiCustomerChangeDto> dtos = new List<PostiCustomerChangeDto>();
    changes.ForEach(change => dtos.Add(Map(change)));
    return dtos;
  }

  public PostiCustomerChangeDto Map(PostiChange change)
  {
    return new PostiCustomerChangeDto()
    {
      PostiChangeStatus = new PostiChangeStatusDto()
      {
        IsDuplicated = change.PostiChangeStatus.IsDuplicated,
        WasIdentified = change.PostiChangeStatus.WasIdentified,
        WasModified = change.PostiChangeStatus.WasModified,
      },
      CustomerId = change.CustomerId,
      DuplicatedId = change.DuplicatedId,
      Ssn = change.Ssn,
      LastName = change.LastName,
      FirstName = change.FirstName,
      Address = PrepareAddress(change),
      ForeignAddress = PrepareForeignAddress(change),
      PersonStatus = new PostiPersonStatusDto()
      {
        IsDeceased = change.PersonStatus?.IsDeceased,
        IsMinor = change.PersonStatus?.IsMinor
      }
    };
  }

  private PostiAddressDto PrepareAddress(PostiChange change)
  {
    return change.Address is not null ? new PostiAddressDto()
    {
      AddressType = AddressTypeMapper(change),
      PostalCode = change.Address?.PostalCode,
      City = change.Address?.City,
      Street = change.Address?.Street
    } : null;
  }
  private PostiForeignAddressDto PrepareForeignAddress(PostiChange change)
  {
    return change.ForeignAddress is not null ? new PostiForeignAddressDto()
    {
      CountryCode = change.ForeignAddress?.CountryCode,
      CountryName = change.ForeignAddress?.CountryName,
      OtherAddressLine1 = change.ForeignAddress?.OtherAddressLine1,
      OtherAddressLine2 = change.ForeignAddress?.OtherAddressLine2,
      OtherAddressLine3 = change.ForeignAddress?.OtherAddressLine3,
      OtherAddressLine4 = change.ForeignAddress?.OtherAddressLine4
    } : null;
  }

  private Models.PostiAddressType? AddressTypeMapper(PostiChange change)
  {
    if (change.Address == null)
      return null;

    return change.Address.AddressType switch
    {
      AddressType.Finnish => Models.PostiAddressType.Finnish,
      AddressType.Swedish => Models.PostiAddressType.Swedish,
      _ => null
    };
  }
}
