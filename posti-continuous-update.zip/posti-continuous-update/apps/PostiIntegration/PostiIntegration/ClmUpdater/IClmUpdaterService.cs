﻿using System.Collections.Generic;
using System.Threading.Tasks;
using PostiIntegration.Posti.Models;

namespace PostiIntegration.ClmUpdater;
public interface IClmUpdaterService
{
  public Task SendChangesAsync(List<PostiChange> changes);
}
