﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using PostiIntegration.ClmUpdater.Exceptions;
using PostiIntegration.ClmUpdater.Mappers;
using PostiIntegration.Config.Models;
using PostiIntegration.Models;
using PostiIntegration.Posti.Models;

namespace PostiIntegration.ClmUpdater;
public class ClmUpdaterService : IClmUpdaterService
{
  private readonly HttpClient _httpClient;
  private readonly IPostiCustomerChangeDtoMapper _mapper;
  private readonly ILogger<ClmUpdaterService> _logger;
  private readonly ClmUpdaterSettings _settings;

  public ClmUpdaterService(HttpClient httpClient, ClmUpdaterSettings clmUpdaterSettings, ILogger<ClmUpdaterService> logger, IPostiCustomerChangeDtoMapper mapper)
  {
    _httpClient = httpClient;
    _httpClient.Timeout = TimeSpan.FromMinutes(5);
    _httpClient.BaseAddress = new System.Uri(clmUpdaterSettings.Url);
    _httpClient.DefaultRequestHeaders.Add("x-functions-key", clmUpdaterSettings.HostKey);
    _logger = logger;
    _mapper = mapper;
    _settings = clmUpdaterSettings;
  }

  public async Task SendChangesAsync(List<PostiChange> changes)
  {
    var mappedDto = _mapper.Map(changes);
    
    var jsonBody = JsonConvert.SerializeObject(mappedDto);
    var data = new StringContent(jsonBody, Encoding.UTF8, "application/json");
    if (_settings.DisableSendingChangesToClmUpdater)
    {
      LogSendingChangesDisabled();
      return;
    }
    var loggingBody = JsonConvert.SerializeObject(changes.Select(x => CreateFromPostiChanges(x)));
    LogClmUpdaterRequest(loggingBody);

    var fileResponse = await _httpClient.PostAsync("UpdateClm", data);

    if (!fileResponse.IsSuccessStatusCode)
    {
      throw new ClmUpdaterRequestException(fileResponse.StatusCode, fileResponse.ReasonPhrase, fileResponse.RequestMessage);
    }
      
  }
  private LoggingRecord CreateFromPostiChanges(PostiChange postiChange)
  {
    return new LoggingRecord
    {
      CustomerNumber = postiChange.CustomerId,
      IsDeceased = postiChange.PersonStatus?.IsDeceased,
      IsMinor = postiChange.PersonStatus?.IsMinor,
      WasAddressChanged = postiChange.Address != null && postiChange.Address.PostalCode != null,
      WasForeignAddressChanged = postiChange.ForeignAddress != null && postiChange.ForeignAddress.OtherAddressLine1 != null,
      WasIdentified = postiChange.PostiChangeStatus.WasIdentified,
      WasModified = postiChange.PostiChangeStatus.WasModified,
      IsDuplicated = postiChange.PostiChangeStatus.IsDuplicated,
      WasNameChanged = postiChange.FirstName != null || postiChange.LastName != null,
    };
  }
  private void LogSendingChangesDisabled()
  {
    _logger.LogInformation("Sending changes to CLM Updater disabled. Skipping\n");
  }

  private void LogClmUpdaterRequest(string jsonBody)
  {
    _logger.LogInformation("Clm Updater posti changes request body\n" +
        "Json Body: {body}", jsonBody);
  }
}
