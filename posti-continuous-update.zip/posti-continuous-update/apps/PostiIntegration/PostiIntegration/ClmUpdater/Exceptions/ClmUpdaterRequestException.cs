﻿using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;

namespace PostiIntegration.ClmUpdater.Exceptions;
public class ClmUpdaterRequestException : Exception
{
  public HttpStatusCode StatusCode { get; init; }
  public string Reason { get; init; }
  public HttpRequestMessage RequestMessage { get; init; }

  public ClmUpdaterRequestException(HttpStatusCode statusCode, string reason, HttpRequestMessage requestMessage)
  {
    StatusCode = statusCode;
    Reason = reason;
    RequestMessage = requestMessage;
  }

  public override string ToString()
  {
    return "Clm request failed \n" +
        "Status code: {statusCode}\n" +
        "Reason: {reason}\n";
  }
}
