﻿using Microsoft.Extensions.DependencyInjection;
using PostiIntegration.ClmUpdater.Mappers;

namespace PostiIntegration.ClmUpdater;
public static class Extensions
{
  public static IServiceCollection RegisterClmUpdaterClients(this IServiceCollection services)
  {
    services.AddHttpClient<IClmUpdaterService, ClmUpdaterService>();
    services.AddScoped<IPostiCustomerChangeDtoMapper, PostiCustomerChangeDtoMapper>();

    return services;
  }
}
