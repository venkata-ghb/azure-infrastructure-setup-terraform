﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using PostiIntegration.ClmUpdater;
using PostiIntegration.ClmUpdater.Exceptions;
using PostiIntegration.Config.Models;
using PostiIntegration.CosmosDb;
using PostiIntegration.CosmosDb.Models;
using PostiIntegration.Models;
using PostiIntegration.Posti;
using PostiIntegration.Posti.Models;

namespace PostiIntegration
{
  public class RefetchFailedRegistryChanges
  {
    private readonly ILogger<RefetchFailedRegistryChanges> _logger;
    private readonly IPostiService _postiClient;
    private readonly IClmUpdaterService _clmUpdaterService;
    private readonly ICosmosDbService _cosmosDbService;
    private readonly FunctionSettings _functionSettings;

    public RefetchFailedRegistryChanges(ILogger<RefetchFailedRegistryChanges> logger, IPostiService postiClient, IClmUpdaterService clmUpdaterService, ICosmosDbService cosmosDbService, FunctionSettings functionSettings)
    {
      _logger = logger;
      _postiClient = postiClient;
      _clmUpdaterService = clmUpdaterService;
      _cosmosDbService = cosmosDbService;
      _functionSettings = functionSettings;
    }

    [FunctionName("RefetchFailedRegistryChanges")]
    public async Task Run(
        [TimerTrigger("0 20 22 * * *")] TimerInfo timerInfo)
    {
      try
      {
        if (_functionSettings.DisableFileRefetch)
        {
          LogFileRefetchDisabled();
          return;
        }
        //Fetch changes
        var fileFetchingErrors = await _cosmosDbService.GetAllFileFetchingErrors();
        LogFilesToRefetch(fileFetchingErrors);
        var fetchResult = new List<PostiResult>();
        foreach (var error in fileFetchingErrors)
        {
          var dtoFromError = Deliverable.CreateFromDocument(error);
          var result = await _postiClient.FetchFile(dtoFromError);
          LogFetchChangesStatus(result);
          fetchResult.Add(result);
        }

        //Removed refetched file data from CosmosDb
        //and send changes to ClmUpdater and stori PostiErrors
        var updateResult = new List<bool>();
        foreach (var result in fetchResult.Where(result => result.Status == PostiResultStatus.Ok))
        {
          await _cosmosDbService.DeleteFileFetchingError((result as OkPostiResult).FileId);
          updateResult.Add(await SendChangesAndStoreErrors(result as OkPostiResult));
        }

        //Based on fetch and update result prepare response
        LogInformation(PrepareResponse(fetchResult, updateResult));
      }
      catch (ClmUpdaterRequestException clmUpdaterException)
      {
        LogClmUpdaterRequestException(clmUpdaterException);
      }
      catch (CosmosException cosmosException)
      {
        LogCosmosDbException(cosmosException);
       
      }
      catch (Exception ex)
      {
        LogUnexpectedError(ex);
      }
    }

    private static string PrepareResponse(List<PostiResult> fetchResult, List<bool> updateResult)
    {
      var errorMessages = new List<string>();
      foreach (var result in fetchResult.Where(fetchResult => fetchResult.Status != PostiResultStatus.Ok && fetchResult.Status != PostiResultStatus.NoChanges))
      {
        switch (result)
        {
          case FileFetchingFailedResult fileFetching:
            errorMessages.Add($"{fileFetching.Code} - {fileFetching.Message}");
            break;
          case BatchMatchingErrorResult batchMatchingError:
            errorMessages.Add($"{batchMatchingError.Code} - {batchMatchingError.Message}");
            break;
          default:
            break;
        }
      }
      if (errorMessages.Count > 0)
        return String.Join(", ", errorMessages.ToArray()); ;

      if (updateResult.Where(result => result != true).ToList().Count > 0)
        return "RefetchFailedRegistryChanges: Failed";

      return "Success";
    }

    private async Task<bool> SendChangesAndStoreErrors(OkPostiResult changesResponse)
    {

      await SendChangesToClmUpdaterIfNeeded(changesResponse);
      return await StorePostiErrorsInDbIfNeeded(changesResponse);
    }

    private async Task SendChangesToClmUpdaterIfNeeded(OkPostiResult okResponse)
    {
      if (okResponse.PostiChanges.Count <= 0)
        return;
      foreach (var chunk in okResponse.PostiChanges.Chunk(25))
      {
        try
        {
          await _clmUpdaterService.SendChangesAsync(chunk.ToList());
        }
        catch (Exception)
        {

        }
        Thread.Sleep(1000);
      }
    }

    private async Task<bool> StorePostiErrorsInDbIfNeeded(OkPostiResult okResponse)
    {
      if (okResponse.PostiErrors.Count <= 0)
        return true;

      var tasks = new List<Task<bool>>();
      foreach (var error in okResponse.PostiErrors)
      {
        tasks.Add(_cosmosDbService.StorePostiError(error));
      }

      var results = await Task.WhenAll(tasks);
      return results.All(x => x == true);
    }
    private void LogFetchChangesStatus(PostiResult changesResponse)
    {
      _logger.LogInformation("Posti fetch changes status.\n" +
          "Status: {status}", changesResponse.Status);
    }

    private void LogInformation(string message)
    {
      _logger.LogInformation(message);
    }

    private void LogFilesToRefetch(List<FileFetchingErrorDocument> errors)
    {
      _logger.LogInformation("Files to refetch.\n" +
          "Files details: {details}", JsonConvert.SerializeObject(errors));
    }

    private void LogUnexpectedError(Exception ex)
    {
      _logger.LogError("There was an unexpected error:\n" +
          "Error: {error}\n" +
          "Stack trace: {trace}",
          ex, ex.StackTrace);
    }

    private void LogCosmosDbException(CosmosException cosmosException)
    {
      _logger.LogError("There was an cosmos db error:\n" +
          "Activity id: {activity}\n" +
          "Message: {message}\n" +
          "Stack trace: {trace}",
          cosmosException.ActivityId,
          cosmosException.Message,
          cosmosException.StackTrace);
    }

    private void LogClmUpdaterRequestException(ClmUpdaterRequestException clmUpdaterException)
    {
      _logger.LogInformation(clmUpdaterException.ToString(), clmUpdaterException.StatusCode, clmUpdaterException.Reason);
    }

    private void LogFileRefetchDisabled()
    {
      _logger.LogInformation("File refetching disabled. Skipping");
    }

  }
}
