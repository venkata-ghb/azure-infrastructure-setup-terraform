using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FluentValidation;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using PostiIntegration.Models;
using PostiIntegration.Posti;
using PostiIntegration.Validators;

namespace PostiIntegration
{
  public class CommitRegistry
  {
    private readonly ILogger<CommitRegistry> _logger;
    private readonly IPostiService _postiService;

    public CommitRegistry(ILogger<CommitRegistry> logger, IPostiService postiService)
    {
      _logger = logger;
      _postiService = postiService;
    }

    [FunctionName("CommitRegistry")]
    public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Function, "put", Route = null)] HttpRequest req)
    {
      try
      {
        _logger.LogInformation("Received registry commit request");

        var result = await _postiService.CommitChangesAsync();

        if (result.Status == Posti.Models.SendChangesStatus.Fail)
        {
          var failed = result as Posti.Models.SendChangesFailed;
          return new ObjectResult(new ErrorResponse(failed.Code, failed.Message)) { StatusCode = StatusCodes.Status502BadGateway };
        }

        return new OkResult();
      }
      
      catch (Exception ex)
      {
        LogUnexpectedError(ex);
        return new StatusCodeResult(StatusCodes.Status500InternalServerError);
      }
    }

    
    private void LogUnexpectedError(Exception ex)
    {
      _logger.LogError("There was an unexpected error:\n" +
          "Error: {error}\n" +
          "Stack trace: {trace}",
          ex, ex.StackTrace);
    }
  }
}
