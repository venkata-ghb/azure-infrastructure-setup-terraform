﻿using FluentValidation;
using Microsoft.ApplicationInsights.Channel;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;
using PostiIntegration.ClmUpdater;
using PostiIntegration.Config;
using PostiIntegration.Config.Models;
using PostiIntegration.CosmosDb;
using PostiIntegration.EventBatcher;
using PostiIntegration.Posti;
using PostiIntegration.Validators;

[assembly: FunctionsStartup(typeof(PostiIntegration.Startup))]

namespace PostiIntegration
{
  public class CloudNameInitializer : ITelemetryInitializer
  {
    public void Initialize(ITelemetry telemetry)
    {
      telemetry.Context.Cloud.RoleName = "PostiIntegration";
    }
  }

  public class Startup : FunctionsStartup
  {
    public override void Configure(IFunctionsHostBuilder builder)
    {
      var configuration = builder.GetContext().Configuration;

      builder.Services.AddLogging();
      builder.Services.AddSingleton<ITelemetryInitializer, CloudNameInitializer>();
      builder.Services.AddValidatorsFromAssemblyContaining<RegistryRecordValidator>();
      builder.Services.RegisterPostiClients(configuration);
      builder.Services.RegisterClmUpdaterClients();
      builder.Services.RegisterEventBatcherClients();
      builder.Services.RegisterCosmosDb();
      builder.Services.RegisterConfiguration<PostiApiSettings>(ServiceLifetime.Scoped);
      builder.Services.RegisterConfiguration<PostiAuthSettings>(ServiceLifetime.Scoped);
      builder.Services.RegisterConfiguration<ClmUpdaterSettings>(ServiceLifetime.Scoped);
      builder.Services.RegisterConfiguration<EventBatcherSettings>(ServiceLifetime.Scoped);
      builder.Services.RegisterConfiguration<CosmosDbSettings>(ServiceLifetime.Scoped);
      builder.Services.RegisterConfiguration<FunctionSettings>(ServiceLifetime.Scoped);
    }
  }
}
