﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;
using Azure;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using PostiIntegration.ClmUpdater;
using PostiIntegration.ClmUpdater.Exceptions;
using PostiIntegration.Config.Models;
using PostiIntegration.CosmosDb;
using PostiIntegration.Models;
using PostiIntegration.Posti;
using PostiIntegration.Posti.Models;

namespace PostiIntegration
{
  public class FetchRegistryChanges
  {
    private readonly ILogger<FetchRegistryChanges> _logger;
    private readonly IPostiService _postiClient;
    private readonly IClmUpdaterService _clmUpdaterService;
    private readonly ICosmosDbService _cosmosDbService;

    public FetchRegistryChanges(ILogger<FetchRegistryChanges> logger, IPostiService postiClient, IClmUpdaterService clmUpdaterService, ICosmosDbService cosmosDbService)
    {
      _logger = logger;
      _postiClient = postiClient;
      _clmUpdaterService = clmUpdaterService;
      _cosmosDbService = cosmosDbService;
    }

    [FunctionName("FetchRegistryChanges")]
    public async Task Run(
        [TimerTrigger("%FetchRegistryChangesTriggerSchedule%")] TimerInfo timerInfo)
    {
      try
      {
        //Fetch changes
        var changesResponse = await _postiClient.GetChangesAsync();
        LogFetchChangesStatus(changesResponse);
        //Prepare result based on response
        var returnResult = changesResponse.Status switch
        {
          PostiResultStatus.FilePreparationFailed =>
            new ObjectResult(new ErrorResponse(((FilePreparationFailedResult)changesResponse).Code, ((FilePreparationFailedResult)changesResponse).Message)) { StatusCode = StatusCodes.Status502BadGateway },
          PostiResultStatus.FetchingFailed => await StoreFailedFetchDetails((FileFetchingFailedResult)changesResponse),
          PostiResultStatus.Ok => await SendChangesAndStoreErrors((OkPostiResult)changesResponse),
          _ => new OkResult()
        };

        //return returnResult;
      }
      catch (ClmUpdaterRequestException clmUpdaterException)
      {
        LogClmUpdaterRequestException(clmUpdaterException);
      }
      catch (CosmosException cosmosException)
      {
        LogUnexpectedError(cosmosException);
        
      }
      catch (Exception ex)
      {
        LogUnexpectedError(ex);
      }
    }

    private async Task<IActionResult> StoreFailedFetchDetails(FileFetchingFailedResult result)
    {
      var storeResult = await _cosmosDbService.StoreFileFetchingError(result);
      if (!storeResult)
        return new ObjectResult(new ErrorResponse("storing_file_fetch_errors_fails", "An error occurred while storing File Fetching Errors in database"))
        {
          StatusCode = StatusCodes.Status500InternalServerError
        };

      return new ObjectResult(new ErrorResponse(result.Code, result.Message)) { StatusCode = StatusCodes.Status502BadGateway };
    }

    private async Task<IActionResult> SendChangesAndStoreErrors(OkPostiResult changesResponse)
    {
      if (await IsPostiFileAlreadyProcessed(changesResponse.FileId))
      {
        _logger.LogInformation("Posti delivery id already processed.\n" +
          "Delivery Id: {deliveryId}", changesResponse.FileId);
        return new OkResult();
      }
      
      await SendChangesToClmUpdaterIfNeeded(changesResponse);
      await _cosmosDbService.StorePostiDeliverableConfiguration(changesResponse.FileId);
      var storeResult = await StorePostiErrorsInDbIfNeeded(changesResponse);
      if (!storeResult)
        return new ObjectResult(new ErrorResponse("storing_posti_errors_fails", "An error occurred while storing PostiErrors in database"))
        {
          StatusCode = StatusCodes.Status500InternalServerError
        };
      
      return new OkResult();
    }

    private async Task<bool> IsPostiFileAlreadyProcessed(string deliveryId)
    {
      var postiProcessedDeliveryId = await _cosmosDbService.GetPostiDeliverableConfiguration();
      return postiProcessedDeliveryId == deliveryId;
    }

    private async Task SendChangesToClmUpdaterIfNeeded(OkPostiResult okResponse)
    {
      if (okResponse.PostiChanges.Count <= 0)
        return;
      
      foreach (var chunk in okResponse.PostiChanges.Chunk(25))
      {
        try
        {
          await _clmUpdaterService.SendChangesAsync(chunk.ToList());
        }
        catch (Exception)
        {
        }

        Thread.Sleep(1000);
      }
    }

    private async Task<bool> StorePostiErrorsInDbIfNeeded(OkPostiResult okResponse)
    {
      if (okResponse.PostiErrors.Count <= 0)
        return true;

      var tasks = new List<Task<bool>>();
      foreach (var error in okResponse.PostiErrors)
      {
        tasks.Add(_cosmosDbService.StorePostiError(error));
      }

      var results = await Task.WhenAll(tasks);
      return results.All(x => x == true);
    }

    private void LogFetchChangesStatus(PostiResult changesResponse)
    {
      _logger.LogInformation("Posti fetch changes status.\n" +
          "Status: {status}", changesResponse.Status);
    }

    private void LogUnexpectedError(Exception ex)
    {
      _logger.LogError("There was an unexpected error:\n" +
          "Error: {error}\n" +
          "Stack trace: {trace}",
          ex, ex.StackTrace);
    }

    private void LogClmUpdaterRequestException(ClmUpdaterRequestException clmUpdaterException)
    {
      _logger.LogInformation(clmUpdaterException.ToString(), clmUpdaterException.StatusCode, clmUpdaterException.Reason);
    }

  }
}
