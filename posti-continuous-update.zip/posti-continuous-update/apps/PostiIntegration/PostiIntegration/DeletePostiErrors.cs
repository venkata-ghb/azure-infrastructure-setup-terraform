using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using PostiIntegration.CosmosDb;

namespace PostiIntegration
{
  public class DeletePostiErrors
  {
    private readonly ILogger<DeletePostiErrors> _logger;
    private readonly ICosmosDbService _cosmosDbService;

    public DeletePostiErrors(ILogger<DeletePostiErrors> logger, ICosmosDbService cosmosDbService)
    {
      _logger = logger;
      _cosmosDbService = cosmosDbService;
    }

    [FunctionName("DeletePostiErrors")]
    public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "delete", Route = null)] HttpRequest req)
    {
      try
      {
        //Get parameter and delete records
        var errorDateTime = GetErrorDateTimeFromQueryParam(req);
        var deletionResult = await _cosmosDbService.DeletePostiErrors(errorDateTime);

        if (deletionResult != true)
          return new StatusCodeResult(StatusCodes.Status500InternalServerError);

        return new NoContentResult();
      }
      catch (Exception ex)
      {
        LogUnexpectedError(ex);
        return new StatusCodeResult(StatusCodes.Status500InternalServerError);
      }
    }

    private DateTime? GetErrorDateTimeFromQueryParam(HttpRequest req)
    {
      var errorDateTimeQuery = req.Query["ErrorDateTime"];
      if (string.IsNullOrEmpty(errorDateTimeQuery))
      {
        LogEmptyErrorDateTime();
        return null;
      }

      LogPostiErrorRequest(errorDateTimeQuery);
      return DateTime.Parse(errorDateTimeQuery).ToUniversalTime();
    }

    private void LogEmptyErrorDateTime()
    {
      _logger.LogInformation("PostiError DateTime is empty. Delete all posti erros");
    }

    private void LogPostiErrorRequest(string dateTimeRequest)
    {
      _logger.LogInformation("Incoming PostiErrors deletion request request\n" +
        "PostiErrors deletion request dateTime: {request}", dateTimeRequest);
    }
    private void LogUnexpectedError(Exception ex)
    {
      _logger.LogError("There was an unexpected error:\n" +
          "Error: {error}\n" +
          "Stack trace: {trace}",
          ex, ex.StackTrace);
    }
  }
}
