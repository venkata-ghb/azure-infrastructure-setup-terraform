﻿using System;
using Newtonsoft.Json;

namespace PostiIntegration.CosmosDb.Models;
public record ConfigurationDocument
{
  /// <summary>
  /// Id required by CosmosDB
  /// </summary>
  [JsonProperty("id")]
  public string Id { get; init; }
  [JsonProperty("value")]
  public string Value { get; init; }
  [JsonProperty("type")]
  public string Type { get; init; }
  [JsonProperty("date")]
  public DateTime Date { get; init; }
}
