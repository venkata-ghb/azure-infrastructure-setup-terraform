﻿using System;
using Newtonsoft.Json;
using PostiIntegration.Posti.Models;

namespace PostiIntegration.CosmosDb.Models;
public record FileFetchingErrorDocument
{
  /// <summary>
  /// Id required by CosmosDB
  /// </summary>
  [JsonProperty("id")]
  public string Id { get; init; }
  [JsonProperty("createdDate")]
  public DateTime Created { get; init; }

  [JsonProperty("numberOfChunks")]
  public int Chunks { get; init; }

  public static FileFetchingErrorDocument CreateFromResult(FileFetchingFailedResult result)
  {
    return new FileFetchingErrorDocument { Id = result.Id, Created = result.Created, Chunks = result.Chunks };
  }
}
