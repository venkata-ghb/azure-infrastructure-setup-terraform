﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using PostiIntegration.Posti.Models;

namespace PostiIntegration.CosmosDb.Models;
public record PostiErrorDocument
{
  /// <summary>
  /// Id required by CosmosDB
  /// </summary>
  [JsonProperty("id")]
  public string Id { get; init; }

  [JsonProperty("fetchErrorType")]
  [JsonConverter(typeof(StringEnumConverter))]
  public FetchErrorType FetchErrorType { get; init; }
  [JsonProperty("timestamp")]
  public long Timestamp { get; init; }

  [JsonProperty("operation")]
  public string Operation { get; init; }

  [JsonProperty("errorMessage")]
  public string ErrorMessage { get; init; }

  [JsonProperty("customerId")]
  public string CustomerId { get; init; }

  [JsonProperty("ssn")]
  public string Ssn { get; init; }

  [JsonProperty("lastName")]
  public string LastName { get; init; }

  [JsonProperty("firstName")]
  public string FirstName { get; init; }

  [JsonProperty("telephone")]
  public string Telephone { get; init; }

  [JsonProperty("email")]
  public string Email { get; init; }

  [JsonProperty("extra")]
  public string Extra { get; init; }

  [JsonProperty("postalCode")]
  public string PostalCode { get; init; }

  [JsonProperty("city")]
  public string City { get; init; }

  [JsonProperty("address")]
  public string Address { get; init; }

  public static PostiErrorDocument CreateFromPostiError(PostiError error)
    => new PostiErrorDocument()
    {
      Id = $"{error.Timestamp}::{error.CustomerId}::{error.Operation}",
      Address = error.Address,
      City = error.City,
      CustomerId = error.CustomerId,
      Ssn = error.Ssn,
      LastName = error.LastName,
      FirstName = error.FirstName,
      Telephone = error.Telephone,
      Email = error.Email,
      Extra = error.Extra,
      PostalCode = error.PostalCode,
      ErrorMessage = error.ErrorMessage,
      FetchErrorType = error.FetchErrorType,
      Operation = error.Operation,
      Timestamp = error.Timestamp
    };
}
