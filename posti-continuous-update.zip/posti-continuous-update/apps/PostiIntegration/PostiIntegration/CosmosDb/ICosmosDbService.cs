﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Reflection.Metadata;
using System.Threading.Tasks;
using System.Xml.Linq;
using Azure;
using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.DataContracts;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PostiIntegration.Config.Models;
using PostiIntegration.CosmosDb.Models;
using PostiIntegration.Posti.Models;

namespace PostiIntegration.CosmosDb;
public interface ICosmosDbService
{
  Task<List<FileFetchingErrorDocument>> GetAllFileFetchingErrors();
  Task<bool> StorePostiError(PostiError error);
  Task<bool> DeletePostiErrors(DateTime? errorsDateTime = null);
  Task<bool> StoreFileFetchingError(FileFetchingFailedResult result);
  Task<bool> DeleteFileFetchingError(string fetchedFileId);
  Task<string> GetPostiDeliverableConfiguration();
  Task<bool> StorePostiDeliverableConfiguration(string deliverableId);
  public Task HealthCheckCall();
}

public class CosmosDbService : ICosmosDbService
{
  private readonly ILogger<CosmosDbService> _logger;
  private readonly ICosmosLinqQuery _cosmosLinqQueryWrapper;
  private readonly CosmosDbSettings _settings;
  private readonly CosmosClient _cosmosClient;
  private readonly TelemetryClient _telemetryClient;
  private const string PostiDeliverableConfigurationId = "LatestPostiDeliverable";

  private readonly ItemRequestOptions _defaultOptions = new() { EnableContentResponseOnWrite = false };


  public CosmosDbService(ILogger<CosmosDbService> logger, CosmosDbSettings settings, CosmosClient cosmosClient, TelemetryConfiguration telemetryConfiguration, ICosmosLinqQuery cosmosLinqQueryWrapper)
  {
    _logger = logger;
    _settings = settings;
    _cosmosClient = cosmosClient;
    _telemetryClient = new TelemetryClient(telemetryConfiguration);
    _cosmosLinqQueryWrapper = cosmosLinqQueryWrapper;
  }
  public async Task<bool> StoreFileFetchingError(FileFetchingFailedResult result)
  {
    if (_settings.DisableStoreFileFetchingErrors)
    {
      LogDisabledFileErrorStoring();
      return true;
    }

    var document = FileFetchingErrorDocument.CreateFromResult(result);
    var partitionKey = new PartitionKey(document.Id);
    var cosmosOperation = new CosmosDependencyOperation("StoreFileFetchingError");

    try
    {
      var operationContainer = _cosmosClient.GetContainer(_settings.Name, _settings.FileFetchingErrorsContainer);
      var response = await operationContainer.CreateItemAsync(document, partitionKey, _defaultOptions);
      LogSuccessfulStoringOfFileFetchingErrorData(document);

      cosmosOperation.Success = true;
      cosmosOperation.StatusCode = (int)response.StatusCode;
      cosmosOperation.RequestCharge = response.RequestCharge;
      return true;
    }
    catch (CosmosException ex)
    {
      LogFailedStoringOfFileFetchingErrorData(ex, document);
      cosmosOperation.StatusCode = (int)ex.StatusCode;
      cosmosOperation.RequestCharge = ex.RequestCharge;
      return false;
    }
    finally
    {
      TrackCosmosDependency(cosmosOperation);
    }
  }
  public async Task HealthCheckCall()
  {
    await _cosmosClient.GetContainer(_settings.Name, "FileFetchingErrors").ReadContainerAsync();
    await _cosmosClient.GetContainer(_settings.Name, "PostiErrors").ReadContainerAsync();
  }
  public async Task<bool> StorePostiError(PostiError error)
  {
    if (_settings.DisableStorePostiErrors)
    {
      LogDisabledErrorStoring();
      return true;
    }

    var document = PostiErrorDocument.CreateFromPostiError(error);
    var partitionKey = new PartitionKey(document.Operation);
    var cosmosOperation = new CosmosDependencyOperation("StorePostiError");

    try
    {
      var operationContainer = _cosmosClient.GetContainer(_settings.Name, _settings.PostiErrorsContainer);
      var response = await operationContainer.CreateItemAsync(document, partitionKey, _defaultOptions);
      LogSuccessfulStoringOfPostiErrorData(document);

      cosmosOperation.Success = true;
      cosmosOperation.StatusCode = (int)response.StatusCode;
      cosmosOperation.RequestCharge = response.RequestCharge;
      return true;
    }
    catch (CosmosException ex)
    {
      LogFailedStoringOfPostiErrorData(ex, document);
      cosmosOperation.StatusCode = (int)ex.StatusCode;
      cosmosOperation.RequestCharge = ex.RequestCharge;
      return false;
    }
    finally
    {
      TrackCosmosDependency(cosmosOperation);
    }
  }

  public async Task<string> GetPostiDeliverableConfiguration()
  {
    var configurationContainer = _cosmosClient.GetContainer(_settings.Name, "Configuration");
    
    var cosmosOperation = new CosmosDependencyOperation("GetPostiDeliverableConfiguration");

    try
    {
      ItemResponse<ConfigurationDocument>  readItem = await configurationContainer.ReadItemAsync<ConfigurationDocument>(
        id: PostiDeliverableConfigurationId,
        partitionKey: new PartitionKey(PostiDeliverableConfigurationId));

      cosmosOperation.Success = true;
      cosmosOperation.StatusCode = (int)readItem.StatusCode;
      cosmosOperation.RequestCharge = readItem.RequestCharge;

      LogSuccessfullyFetchedConfiguration(readItem.Resource);

      return readItem.Resource.Value;
    }
    catch (CosmosException ex)
    {
      LogFailedPostiErrorsFetch(ex);
      cosmosOperation.StatusCode = (int)ex.StatusCode;
      cosmosOperation.RequestCharge = ex.RequestCharge;
      return null;
    }
    finally
    {
      TrackCosmosDependency(cosmosOperation);
    }
  }

  public async Task<bool> StorePostiDeliverableConfiguration(string deliverableId)
  {

    var document = new ConfigurationDocument
    {
      Type = PostiDeliverableConfigurationId,
      Id = PostiDeliverableConfigurationId,
      Value = deliverableId
    };
    var partitionKey = new PartitionKey(document.Type);
    var cosmosOperation = new CosmosDependencyOperation("StoreConfiguration");

    try
    {
      var operationContainer = _cosmosClient.GetContainer(_settings.Name, "Configuration");
      var response = await operationContainer.UpsertItemAsync(document, partitionKey, _defaultOptions);
      LogSuccessfulStoringOfConfigurationData(document);

      cosmosOperation.Success = true;
      cosmosOperation.StatusCode = (int)response.StatusCode;
      cosmosOperation.RequestCharge = response.RequestCharge;
      return true;
    }
    catch (CosmosException ex)
    {
      LogFailedStoringOfConfigurationData(ex, document);
      cosmosOperation.StatusCode = (int)ex.StatusCode;
      cosmosOperation.RequestCharge = ex.RequestCharge;
      return false;
    }
    finally
    {
      TrackCosmosDependency(cosmosOperation);
    }
  }

  public async Task<bool> DeletePostiErrors(DateTime? errorDateTime = null)
  {
    var allPostiErrors = await GetAllPostiErrors();
    var varErrorsToRemove = errorDateTime == null ?
      allPostiErrors :
      allPostiErrors.Where(document => Utils.UnixSecondsToDateTime(document.Timestamp).ToUniversalTime() <= errorDateTime).ToList();

    var deletionTasks = new List<Task<bool>>();
    foreach (var postiError in varErrorsToRemove)
    {
      deletionTasks.Add(DeletePostiError(postiError.Id, postiError.Operation.ToString()));
    }
    var deletionResults = await Task.WhenAll(deletionTasks);

    return deletionResults.All(x => x);
  }

  public async Task<List<PostiErrorDocument>> GetAllPostiErrors()
  {
    var postiErrorsContainer = _cosmosClient.GetContainer(_settings.Name, _settings.PostiErrorsContainer);
    var cosmosQuery = postiErrorsContainer
        .GetItemLinqQueryable<PostiErrorDocument>().Select(document => document);
    var cosmosOperation = new CosmosDependencyOperation("GetAllPostiErrors");

    cosmosOperation.Data = _cosmosLinqQueryWrapper.GetQueryText(cosmosQuery);
    var resultsIterator = _cosmosLinqQueryWrapper.GetFeedIterator(cosmosQuery);

    try
    {
      var results = new List<PostiErrorDocument>();

      while (resultsIterator.HasMoreResults)
      {
        var response = await resultsIterator.ReadNextAsync();
        cosmosOperation.StatusCode = (int)response.StatusCode;
        cosmosOperation.RequestCharge += response.RequestCharge;
        foreach (var doc in response)
        {
          results.Add(doc);
        }
      }
      cosmosOperation.Success = true;
      LogSuccessfullyFetchedPostiErrors(results);

      return results;
    }
    catch (CosmosException ex)
    {
      LogFailedPostiErrorsFetch(ex);
      cosmosOperation.StatusCode = (int)ex.StatusCode;
      cosmosOperation.RequestCharge = ex.RequestCharge;
      return null;
    }
    finally
    {
      TrackCosmosDependency(cosmosOperation);
    }
  }

  public async Task<List<FileFetchingErrorDocument>> GetAllFileFetchingErrors()
  {
    var fileFetchingContainer = _cosmosClient.GetContainer(_settings.Name, _settings.FileFetchingErrorsContainer);
    var cosmosQuery = fileFetchingContainer
        .GetItemLinqQueryable<FileFetchingErrorDocument>().Select(document => document);
    var cosmosOperation = new CosmosDependencyOperation("GetAllFileFetching");

    cosmosOperation.Data = _cosmosLinqQueryWrapper.GetQueryText(cosmosQuery);
    var resultsIterator = _cosmosLinqQueryWrapper.GetFeedIterator(cosmosQuery);

    try
    {
      var results = new List<FileFetchingErrorDocument>();

      while (resultsIterator.HasMoreResults)
      {
        var response = await resultsIterator.ReadNextAsync();
        cosmosOperation.StatusCode = (int)response.StatusCode;
        cosmosOperation.RequestCharge += response.RequestCharge;
        foreach (var doc in response)
        {
          results.Add(doc);
        }
      }
      cosmosOperation.Success = true;
      LogSuccessfullyFetchedFileFetchingErrors(results);
      results = results.OrderBy(x => x.Created).ToList();
      return results;
    }
    catch (CosmosException ex)
    {
      LogFailedPostiErrorsFetch(ex);
      cosmosOperation.StatusCode = (int)ex.StatusCode;
      cosmosOperation.RequestCharge = ex.RequestCharge;
      return null;
    }
    finally
    {
      TrackCosmosDependency(cosmosOperation);
    }
  }

  /// <summary>
  /// Remove posti error from PostiError container by error id 
  /// </summary>
  /// <param name="fetchedFileId"></param>
  /// <param name="fetchedFileId"></param>
  /// <returns></returns>
  private async Task<bool> DeletePostiError(string postiErrorId, string partitionKeyString)
  {
    LogDeletingPostiError(postiErrorId);
    var partitionKey = new PartitionKey(partitionKeyString);
    var cosmosOperation = new CosmosDependencyOperation("DeletePostiError");

    try
    {
      var operationContainer = _cosmosClient.GetContainer(_settings.Name, _settings.PostiErrorsContainer);
      var response = await operationContainer.DeleteItemAsync<PostiErrorDocument>(postiErrorId, partitionKey, _defaultOptions);
      LogSuccesfulDeletionOfPostiError(postiErrorId);

      cosmosOperation.Success = true;
      cosmosOperation.StatusCode = (int)response.StatusCode;
      cosmosOperation.RequestCharge = response.RequestCharge;
      return true;
    }
    catch (CosmosException ex)
    {
      LogFailedDeletionOfPostiError(ex, postiErrorId);
      cosmosOperation.StatusCode = (int)ex.StatusCode;
      cosmosOperation.RequestCharge = ex.RequestCharge;
      return false;
    }
    finally
    {
      TrackCosmosDependency(cosmosOperation);
    }
  }

  /// <summary>
  /// Remove posti error from FileFetching container by error id 
  /// </summary>
  /// <param name="fetchedFileId"></param>
  /// <param name="fetchedFileId"></param>
  /// <returns></returns>
  public async Task<bool> DeleteFileFetchingError(string fetchedFileId)
  {
    LogDeletingFileFetchingError(fetchedFileId);

    var partitionKey = new PartitionKey(fetchedFileId);
    var cosmosOperation = new CosmosDependencyOperation("DeleteFileFetchingError");

    try
    {
      var operationContainer = _cosmosClient.GetContainer(_settings.Name, _settings.FileFetchingErrorsContainer);
      var response = await operationContainer.DeleteItemAsync<FileFetchingErrorDocument>(fetchedFileId, partitionKey, _defaultOptions);
      LogSuccesfulDeletionOfFileFetchingError(fetchedFileId);

      cosmosOperation.Success = true;
      cosmosOperation.StatusCode = (int)response.StatusCode;
      cosmosOperation.RequestCharge = response.RequestCharge;
      return true;
    }
    catch (CosmosException ex)
    {
      LogFailedDeletionOfFileFetchingError(ex, fetchedFileId);
      cosmosOperation.StatusCode = (int)ex.StatusCode;
      cosmosOperation.RequestCharge = ex.RequestCharge;
      return false;
    }
    finally
    {
      TrackCosmosDependency(cosmosOperation);
    }
  }
  private struct CosmosDependencyOperation
  {
    public string Name { get; set; }
    public DateTime StartTime { get; set; } = DateTime.UtcNow;
    public bool Success { get; set; } = false;
    public int StatusCode { get; set; } = 0;
    public double RequestCharge { get; set; } = 0.0;
    public string Data { get; set; } = "";

    public CosmosDependencyOperation(string name)
    {
      Name = name;
    }
  }

  private void TrackCosmosDependency(CosmosDependencyOperation operation)
  {
    var dependency = new DependencyTelemetry()
    {
      Name = operation.Name,
      Target = _cosmosClient.Endpoint.Host,
      Data = operation.Data,
      Type = "Azure DocumentDB",
      Timestamp = operation.StartTime,
      Duration = DateTime.UtcNow - operation.StartTime,
      ResultCode = $"{operation.StatusCode}",
      Success = operation.Success,
    };
    dependency.Properties["requestCharge"] = operation.RequestCharge.ToString(CultureInfo.InvariantCulture);
    _telemetryClient.TrackDependency(dependency);
  }


  private void LogSuccessfulStoringOfPostiErrorData(PostiErrorDocument document)
  {
    _logger.LogInformation("Successfully added posti error data to database.\n" +
      "Customer id: {customerId}. Operation: {operation}. Timestamp: {timestamp}.",
      document.CustomerId, document.Operation, document.Timestamp);
  }

  private void LogFailedStoringOfPostiErrorData(CosmosException ex, PostiErrorDocument document)
  {
    _logger.LogError(ex, "Failed to store posti error data in database.\n" +
      "Invalid data: {invalidDataDocument}\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      JsonConvert.SerializeObject(document),
      ex.Message, ex.StackTrace);
  }

  private void LogFailedStoringOfConfigurationData(CosmosException ex, ConfigurationDocument document)
  {
    _logger.LogError(ex, "Failed to store configuration data in database.\n" +
      "Invalid data: {invalidDataDocument}\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      JsonConvert.SerializeObject(document),
      ex.Message, ex.StackTrace);
  }

  private void LogSuccessfulStoringOfConfigurationData(ConfigurationDocument document)
  {
    _logger.LogInformation("Successfully added configuration data to database.\n" +
      "Data: {dataDocument}\n",
      JsonConvert.SerializeObject(document));
  }

  private void LogDisabledErrorStoring()
  {
    _logger.LogInformation("Posti error storing disabled");
  }

  private void LogDisabledFileErrorStoring()
  {
    _logger.LogInformation("File fetching error storing disabled");
  }

  private void LogSuccessfulStoringOfFileFetchingErrorData(FileFetchingErrorDocument document)
  {
    _logger.LogInformation("Successfully added file fetching error data to database.\n" +
      "File id: {id}. Chunks: {chunks}. Created: {created}",
      document.Id, document.Chunks, document.Created);
  }

  private void LogFailedStoringOfFileFetchingErrorData(CosmosException ex, FileFetchingErrorDocument document)
  {
    _logger.LogError(ex, "Failed to store file fetchting error data in database.\n" +
      "Invalid data: {invalidDataDocument}\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      JsonConvert.SerializeObject(document),
      ex.Message, ex.StackTrace);
  }

  private void LogSuccessfullyFetchedPostiErrors(List<PostiErrorDocument> fetchedErrors)
  {
    _logger.LogInformation("Successfully fetched all Posti Errors.\n" +
      "Documents:\n{documents}",
      string.Join("\n", fetchedErrors.Select(doc => JsonConvert.SerializeObject(doc))));
  }

  private void LogSuccessfullyFetchedConfiguration(ConfigurationDocument configurationDocument)
  {
    _logger.LogInformation("Successfully fetched Configuration Document.\n" +
      "Document:\n{document}",
      JsonConvert.SerializeObject(configurationDocument));
  }

  private void LogSuccessfullyFetchedFileFetchingErrors(List<FileFetchingErrorDocument> fetchedErrors)
  {
    _logger.LogInformation("Successfully fetched all FileFetching Errors.\n" +
      "Documents:\n{documents}",
      string.Join("\n", fetchedErrors.Select(doc => JsonConvert.SerializeObject(doc))));
  }

  private void LogDeletingPostiError(string errorId)
  {
    _logger.LogInformation("Begin deletion of PostiError from database.\n" +
      "Error id: {errorId}.", errorId);
  }

  private void LogDeletingFileFetchingError(string errorId)
  {
    _logger.LogInformation("Begin deletion of FileFetchingError from database.\n" +
      "Error id: {errorId}.", errorId);
  }

  private void LogSuccesfulDeletionOfPostiError(string errorId)
  {
    _logger.LogInformation("Successfully deleted Posti Error.\n" +
      "Error id: {errorId}.", errorId);
  }

  private void LogSuccesfulDeletionOfFileFetchingError(string errorId)
  {
    _logger.LogInformation("Successfully deleted FileFetching Error.\n" +
      "Error id: {errorId}.", errorId);
  }

  private void LogFailedPostiErrorsFetch(CosmosException ex)
  {
    _logger.LogError(ex, "Failed to fetch all posti errors.\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      ex.Message, ex.StackTrace);
  }

  private void LogFailedDeletionOfPostiError(CosmosException ex, string errorId)
  {
    _logger.LogError(ex, "Failed to delete posti error.\n" +
      "Error id: {errorId}.\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      errorId,
      ex.Message, ex.StackTrace);
  }

  private void LogFailedDeletionOfFileFetchingError(CosmosException ex, string errorId)
  {
    _logger.LogError(ex, "Failed to delete file fetching error.\n" +
      "Error id: {errorId}.\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      errorId,
      ex.Message, ex.StackTrace);
  }
}
