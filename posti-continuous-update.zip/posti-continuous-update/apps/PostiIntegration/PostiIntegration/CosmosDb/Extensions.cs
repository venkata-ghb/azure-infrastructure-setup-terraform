﻿using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.DependencyInjection;
using PostiIntegration.Config.Models;

namespace PostiIntegration.CosmosDb;
public static class Extensions
{
  public static IServiceCollection RegisterCosmosDb(this IServiceCollection services)
  {
    services.AddSingleton(serviceProvider =>
    {
      var dbSettings = serviceProvider.GetService<CosmosDbSettings>();
      var options = new CosmosClientOptions
      {
        AllowBulkExecution = true,
      };
      return new CosmosClient(dbSettings.ConnectionString, options);
    });
    services.AddTransient<ICosmosDbService, CosmosDbService>();
    services.AddScoped<ICosmosLinqQuery, CosmosLinqQueryWrapper>();

    return services;
  }
}
