using System.Net;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using PostiIntegration.Config.Models;
using PostiIntegration.EventBatcher;
using PostiIntegration.EventBatcher.Mappers;
using PostiIntegration.EventBatcher.Models;
using RichardSzalay.MockHttp;
using Xunit;

namespace PostiIntegration.Test.EventBatcher
{
  public class EventBatcherServiceTest
  {
    private readonly ILogger<EventBatcherService> _logger;

    public EventBatcherServiceTest(ILogger<EventBatcherService> logger)
    {
      _logger = logger;
    }

    [Fact]
    public async void GetLatestBatchAsync_ValidRequest_SuccessResponse()
    {
      //Arrange
      var settings = new EventBatcherSettings()
      {
        Url = "http://domain/api/",
        HostKey = "key",
        DisableBatchFetching = false,
      };

      string prepareDeliveryPath = "GetBatch";

      var mockHttp = new MockHttpMessageHandler();
      var mockLatestBatchResponse = Utils.ReadFixture("latestBatchResponse.json");
      mockHttp.When($"{settings.Url}{prepareDeliveryPath}").Respond("application/json", mockLatestBatchResponse);
      var mapper = new BatchRecordMapper();
      var eventBatcherService = new EventBatcherService(mockHttp.ToHttpClient(), settings, _logger, mapper);

      //Act
      var result = await eventBatcherService.GetBatchAsync();

      //Assert            
      result.Should().NotBeNull();
      result.Should().BeAssignableTo<EventBatcherResult>();
      result.Status.Should().Be(EventBatcherResultStatus.Success);
      result.BatchRecords.Count.Should().Be(4);
    }

    [Fact]
    public async void GetLatestBatchAsync_ValidRequest_EmptyErrorResponse()
    {
      //Arrange
      var settings = new EventBatcherSettings()
      {
        Url = "http://domain/api/",
        HostKey = "key",
        DisableBatchFetching = false
      };

      string prepareDeliveryPath = "GetBatch";

      var mockHttp = new MockHttpMessageHandler();
      var mockLatestBatchResponse = "";
      mockHttp.When($"{settings.Url}{prepareDeliveryPath}").Respond("application/json", mockLatestBatchResponse);
      var mapper = new BatchRecordMapper();
      var eventBatcherService = new EventBatcherService(mockHttp.ToHttpClient(), settings, _logger, mapper);

      //Act
      var result = await eventBatcherService.GetBatchAsync();

      //Assert            
      result.Should().NotBeNull();
      result.Should().BeAssignableTo<EventBatcherResult>();
      result.Status.Should().Be(EventBatcherResultStatus.EmptyBatchError);
      result.BatchRecords.Should().BeNull();
    }

    [Theory]
    [InlineData(HttpStatusCode.Unauthorized)]
    [InlineData(HttpStatusCode.NotFound)]
    [InlineData(HttpStatusCode.InternalServerError)]
    public async void GetLatestBatchAsync_ValidRequest_HttpErrorResponse(HttpStatusCode code)
    {
      //Arrange
      var settings = new EventBatcherSettings()
      {
        Url = "http://domain/api/",
        HostKey = "key",
        DisableBatchFetching = false,
      };

      string prepareDeliveryPath = "GetBatch";

      var mockHttp = new MockHttpMessageHandler();
      mockHttp.When($"{settings.Url}{prepareDeliveryPath}").Respond(code);
      var mapper = new BatchRecordMapper();
      var eventBatcherService = new EventBatcherService(mockHttp.ToHttpClient(), settings, _logger, mapper);
      //Act
      var result = await eventBatcherService.GetBatchAsync();

      //Assert            
      result.Should().NotBeNull();
      result.Should().BeAssignableTo<EventBatcherResult>();
      result.Status.Should().Be(EventBatcherResultStatus.HttpError);
      result.BatchRecords.Should().BeNull();
    }

    [Fact]
    public async void GetLatestBatchAsync_DisabledBatchFechingFlagTrue_SuccessResponse()
    {
      //Arrange
      var settings = new EventBatcherSettings()
      {
        Url = "http://domain/api/",
        HostKey = "key",
        DisableBatchFetching = true,
      };

      var mockHttp = new MockHttpMessageHandler();
      var mapper = new BatchRecordMapper();
      var eventBatcherService = new EventBatcherService(mockHttp.ToHttpClient(), settings, _logger, mapper);

      //Act
      var result = await eventBatcherService.GetBatchAsync();

      //Assert            
      result.Should().NotBeNull();
      result.Should().BeAssignableTo<EventBatcherResult>();
      result.Status.Should().Be(EventBatcherResultStatus.BatchFetchingDisabled);
    }
  }
}
