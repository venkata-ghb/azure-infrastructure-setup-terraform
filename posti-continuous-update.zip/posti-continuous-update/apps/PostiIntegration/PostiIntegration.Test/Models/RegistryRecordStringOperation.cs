﻿using Newtonsoft.Json;

namespace PostiIntegration.Test.Models;
/// <summary>
/// Used only for testing purpose to simulate passing Operation as a string.
/// Default data sample is from valid user that was provided in Posti csv example
/// </summary>
public class RegistryRecordStringOperationDto
{
  #pragma warning disable CS8618 // Shut up about nullable values
  public RegistryRecordStringOperationDto() { }

  public RegistryRecordStringOperationDto(string operation)
  {
    Operation = operation;
    CustomerNumber = "123";
    Ssn = operation == "Remove" ? "" : "080838-8550";
    LastName = operation == "Remove" ? "" : "Meikäläinen";
    FirstName = operation == "Remove" ? "" : "Matti";
    PostalCode = operation == "Remove" ? "" : "01340";
    City = operation == "Remove" ? "" : "Vantaa";
    Address = operation == "Remove" ? "" : "Torikatu 7";
    Telephone = operation == "Remove" ? "" : "0501234567";
    Email = operation == "Remove" ? "" : "matti.meikalainen@testi.fi";
    Extra = operation == "Remove" ? "" : "super customer";
  }

  [JsonProperty("operation")]
  public string Operation { get; set; }

  [JsonProperty("customerNumber")]
  public string CustomerNumber { get; set; }

  [JsonProperty("ssn")]
  public string Ssn { get; set; }

  [JsonProperty("lastName")]
  public string LastName { get; set; }

  [JsonProperty("firstName")]
  public string FirstName { get; set; }

  [JsonProperty("postalCode")]
  public string PostalCode { get; set; }

  [JsonProperty("city")]
  public string City { get; set; }

  [JsonProperty("address")]
  public string Address { get; set; }

  [JsonProperty("telephone")]
  public string Telephone { get; set; }

  [JsonProperty("email")]
  public string Email { get; set; }

  [JsonProperty("extra")]
  public string Extra { get; set; }
}
