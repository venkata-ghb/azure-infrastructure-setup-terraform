﻿using System;
using System.Collections.Generic;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using PostiIntegration.Posti.Factories;
using PostiIntegration.Posti.Models;
using Xunit;

namespace PostiIntegration.Test.Posti.Factories;
public class PostiChangesFactoryTest
{
  private readonly IPostiChangesFactory _postiChangesFactory;

  public PostiChangesFactoryTest(ILogger<PostiChangesFactory> logger)
  {
    _postiChangesFactory = new PostiChangesFactory(logger);
  }

  [Fact]
  public void Create_CheckAddressResponse_ValidAddressValue()
  {
    var mockGetChangesResponse = Utils.ReadFixture("PostiRegistryChange/exampleResponseWithLocalAndForeignAddress.json");
    var deserializedPostiResponse = JsonConvert.DeserializeObject<List<RegistryDto>>(mockGetChangesResponse);

    (var changes, var changesErrors) = _postiChangesFactory.Create(deserializedPostiResponse);

    changes.Should().NotBeNull();
    changes[0].Address.Should().BeNull();
    changes[0].ForeignAddress.Should().NotBeNull();
    changes[1].Address.Should().NotBeNull();
    changes[1].ForeignAddress.Should().BeNull();
  }
}
