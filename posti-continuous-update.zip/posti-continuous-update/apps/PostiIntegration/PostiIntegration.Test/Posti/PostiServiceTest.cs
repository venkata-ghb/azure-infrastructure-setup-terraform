using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using PostiIntegration.ClmUpdater;
using PostiIntegration.Config.Models;
using PostiIntegration.EventBatcher;
using PostiIntegration.EventBatcher.Models;
using PostiIntegration.Models;
using PostiIntegration.Posti;
using PostiIntegration.Posti.Csv;
using PostiIntegration.Posti.Factories;
using PostiIntegration.Posti.Models;
using PostiIntegration.Test.Fixtures;
using RichardSzalay.MockHttp;
using Xunit;

namespace PostiIntegration.Test.Posti
{
  public class PostiServiceTest
  {
    private readonly ILogger<PostiService> _logger;
    private readonly CsvPreparer _csvPreparer;
    private readonly IEventBatcherService _eventBatcherService;
    private readonly PostiApiSettings _postiApiSettings;
    private readonly PostiChangesFactory _postiChangesFactory;

    public PostiServiceTest(ILogger<PostiService> logger, ILogger<PostiChangesFactory> changeFactorylogger, ILogger<EventBatcherService> eventBatcherServiceLogger)
    {
      _logger = logger;
      _csvPreparer = new CsvPreparer(new RegistryRecordCsvFactory());
      _eventBatcherService = Generators.PrepareEventBatchService(eventBatcherServiceLogger);
      _postiApiSettings = new PostiApiSettings()
      {
        BaseUrl = "http://posti.domain/api/",
        RegistryId = "registryId"
      };
      _postiChangesFactory = new PostiChangesFactory(changeFactorylogger);
    }

    /*[Fact]
    public async void GetChanges_NoChanges_ReturnsNoChangesString()
    {
      //Arrange

      string prepareDeliveryPath = $"register/{_postiApiSettings.RegistryId}/preparation/changes?format=JSON";
      string getChangesPath = $"register/{_postiApiSettings.RegistryId}/result/1?chunk=1";

      var mockDeliveryResponse = "No changes";
      var mockGetChangesResponse = "No changes";

      var mockHttp = new MockHttpMessageHandler();
      mockHttp.When($"{_postiApiSettings.BaseUrl}{prepareDeliveryPath}").Respond("application/json", mockDeliveryResponse);
      mockHttp.When($"{_postiApiSettings.BaseUrl}{getChangesPath}").Respond("application/json", mockGetChangesResponse);
      var postiService = new PostiService(mockHttp.ToHttpClient(), _postiApiSettings, _logger, _postiChangesFactory, _csvPreparer, _eventBatcherService);

      //Act
      var response = await postiService.GetChangesAsync();

      //Assert            
      response.Should().NotBeNull();
      response.Should().BeAssignableTo<PostiResult>();
      response.Status.Should().Be(PostiResultStatus.NoChanges);
    }*/

    [Fact]
    public async void GetChanges_FetchChangesFromPostiDisabledTrue_ReturnsNoChangesString()
    {
      //Arrange
      var postiApiSettings = new PostiApiSettings()
      {
        BaseUrl = "http://posti.domain/api/",
        RegistryId = "registryId",
        DisableFetchingChangesFromPosti = true,
      };

      var postiAuthSettings = new PostiAuthSettings()
      {
        BaseUrl = "http://posti.domain/api/",
        ConsumerKey = "dummy",
        ConsumerSecret = "dummy",
        TokenTreshold = 0,
      };
      var tokenService = new Mock<ITokenService>();
      tokenService.Setup(p => p.GetAccessToken()).ReturnsAsync("token");
      var mockHttp = new MockHttpMessageHandler();
      var postiService = new PostiService(mockHttp.ToHttpClient(), postiApiSettings, _logger, _postiChangesFactory, _csvPreparer, _eventBatcherService, tokenService.Object);

      //Act
      var response = await postiService.GetChangesAsync();

      //Assert            
      response.Should().NotBeNull();
      response.Should().BeAssignableTo<PostiResult>();
      response.Status.Should().Be(PostiResultStatus.NoChanges);
    }

    [Theory]
    [InlineData("deliveryFileOneChunk.json", 3)]
    public async void GetChanges_ChangesMadeInRegistryInChunksTest_ReturnsArrayWithChanges(string mockDeliveryPath, int responseCount)
    {
      //Arrange
      string changesPreparation = $"register/{_postiApiSettings.RegistryId}/status";
      string getChangesPath = $"register/{_postiApiSettings.RegistryId}/result/f7551c87-62b2-4531-bc21-8f93f88646f4?chunk=1";
      var eventBatcherService = new Mock<IEventBatcherService>();
      var mockDeliveryResponse = Utils.ReadFixture(mockDeliveryPath);
      var mockChangesPreparation = Utils.ReadFixture("deliveryFileThreeChunks.json");
      var mockGetChangesResponse = Utils.ReadFixture("PostiRegistryChange/exampleRegistryChangesResponse.json");

      var postiAuthSettings = new PostiAuthSettings()
      {
        BaseUrl = "http://posti.domain/api/",
        ConsumerKey = "dummy",
        ConsumerSecret = "dummy",
        TokenTreshold = 0,
      };
      var mockTokenService = new Mock<ITokenService>();
      mockTokenService.Setup(p => p.GetAccessToken()).ReturnsAsync("token");

      var mockHttp = new MockHttpMessageHandler();
      mockHttp.When($"{_postiApiSettings.BaseUrl}{getChangesPath}").Respond("application/json", mockGetChangesResponse);
      mockHttp.When($"{_postiApiSettings.BaseUrl}{changesPreparation}").Respond("application/json", mockChangesPreparation);

      var tokenService = new PostiService(mockHttp.ToHttpClient(), _postiApiSettings, _logger, _postiChangesFactory, _csvPreparer, eventBatcherService.Object, mockTokenService.Object);

      //Act
      var response = await tokenService.GetChangesAsync();

      //Assert
      //
      eventBatcherService.Verify(x => x.PostEvent(It.IsAny<List<CustomerLeftEvent>>()), Times.Once);
      response.Should().NotBeNull();
      response.Should().BeAssignableTo<OkPostiResult>();
      var okResponse = (OkPostiResult)response;
      okResponse.Status.Should().Be(PostiResultStatus.Ok);
      okResponse.PostiChanges.Should().NotBeNull();
      okResponse.PostiChanges.Count.Should().Be(responseCount);
      okResponse.PostiChanges[0].PostiChangeStatus.WasIdentified.Should().BeTrue();
      okResponse.PostiChanges[0].PostiChangeStatus.WasModified.Should().BeTrue();
      okResponse.PostiChanges[0].PostiChangeStatus.IsDuplicated.Should().BeFalse();
      okResponse.PostiChanges[0].PersonStatus.DateOfDeath.Should().Be(new DateOnly(2011, 09, 20));
      okResponse.PostiChanges[0].PersonStatus.IsDeceased.Should().BeTrue();
      okResponse.PostiChanges[0].PersonStatus.IsMinor.Should().BeFalse();
      okResponse.PostiChanges[0].Address.Should().BeNull();
      okResponse.PostiChanges[0].ForeignAddress.Should().NotBeNull();

      okResponse.PostiChanges[1].PostiChangeStatus.WasIdentified.Should().BeTrue();
      okResponse.PostiChanges[1].PostiChangeStatus.WasModified.Should().BeTrue();
      okResponse.PostiChanges[1].PostiChangeStatus.IsDuplicated.Should().BeFalse();
      okResponse.PostiChanges[1].PersonStatus.DateOfDeath.Should().BeNull();
      okResponse.PostiChanges[1].PersonStatus.IsDeceased.Should().BeFalse();
      okResponse.PostiChanges[1].PersonStatus.IsMinor.Should().BeTrue();
      okResponse.PostiChanges[1].Address.Should().NotBeNull();
      okResponse.PostiChanges[1].ForeignAddress.Should().BeNull();

      okResponse.PostiChanges[2].PostiChangeStatus.WasIdentified.Should().BeFalse();
      okResponse.PostiChanges[2].PostiChangeStatus.WasModified.Should().BeFalse();
      okResponse.PostiChanges[2].PostiChangeStatus.IsDuplicated.Should().BeTrue();
      okResponse.PostiChanges[2].PersonStatus.DateOfDeath.Should().BeNull();
      okResponse.PostiChanges[2].DuplicatedId.Should().Be("3");
      okResponse.PostiChanges[2].PersonStatus.IsDeceased.Should().BeNull();
      okResponse.PostiChanges[2].PersonStatus.IsMinor.Should().BeNull();
      okResponse.PostiChanges[2].Address.Should().BeNull();
      okResponse.PostiChanges[2].ForeignAddress.Should().BeNull();


    }

    /* [Theory]
     [InlineData("PostiRegistryChange/otherErrorInResponse.json", 1, FetchErrorType.Other, "Other error")]
     [InlineData("PostiRegistryChange/personAlreadyExistErrorInResponse.json", 1, FetchErrorType.CustomerIdAlreadyExists, "Person already exists in the follow-up register with a same customer number")]
     [InlineData("PostiRegistryChange/personNotFoundErrorInResponse.json", 1, FetchErrorType.PersonDoesNotExist, "person does not exist in the follow-up register")]
     [InlineData("PostiRegistryChange/noErrorsInResponse.json", 0, null, null)]
     public async void GetChanges_MatchErrorsWithBatchResponse_MatchesCorrectly(string responseFilePath, int errorCount, FetchErrorType errorType, string message)
     {
       //Arrange
       string prepareDeliveryPath = $"register/{_postiApiSettings.RegistryId}/preparation/changes?format=JSON";
       string getChangesPath = $"register/{_postiApiSettings.RegistryId}/result/*";

       var mockDeliveryResponse = Utils.ReadFixture("deliveryFileOneChunk.json");
       var mockGetChangesResponse = Utils.ReadFixture(responseFilePath);

       var mockHttp = new MockHttpMessageHandler();
       mockHttp.When($"{_postiApiSettings.BaseUrl}{prepareDeliveryPath}").Respond("application/json", mockDeliveryResponse);
       mockHttp.When($"{_postiApiSettings.BaseUrl}{getChangesPath}").Respond("application/json", mockGetChangesResponse);

       var tokenService = new PostiService(mockHttp.ToHttpClient(), _postiApiSettings, _logger, _postiChangesFactory, _csvPreparer, _eventBatcherService);

       //Act
       var response = await tokenService.GetChangesAsync();

       //Assert            
       response.Should().NotBeNull();
       response.Should().BeAssignableTo<OkPostiResult>();
       var okResponse = (OkPostiResult)response;
       okResponse.Status.Should().Be(PostiResultStatus.Ok);
       okResponse.PostiErrors.Should().NotBeNull();
       okResponse.PostiErrors.Count.Should().Be(errorCount);

       if (errorCount > 0)
       {
         okResponse.PostiErrors[0].Should().NotBeNull();
         okResponse.PostiErrors[0].FetchErrorType.Should().Be(errorType);
         okResponse.PostiErrors[0].ErrorMessage.Should().Be(message);
       }
     }

     [Fact]
     public async void GetChanges_MatchErrorsWithGeneratedData_MatchesCorrectly()
     {
       //Arrange
       string prepareDeliveryPath = $"register/{_postiApiSettings.RegistryId}/preparation/changes?format=JSON";
       string getChangesPath = $"register/{_postiApiSettings.RegistryId}/result/*";

       var mockDeliveryResponse = Utils.ReadFixture("deliveryFileOneChunk.json");
       var mockEventBatcherService = new Mock<IEventBatcherService>();
       var generatedBatch = Generators.GenerateEventBatcherResult();
       mockEventBatcherService.Setup(p => p.GetBatchAsync(It.IsAny<string>())).ReturnsAsync(generatedBatch);
       var mockChangesResponse = Generators.GenerateChangesResponseDtoWithJustError();
       var changesResponseJson = JsonConvert.SerializeObject(mockChangesResponse);


       var mockHttp = new MockHttpMessageHandler();
       mockHttp.When($"{_postiApiSettings.BaseUrl}{prepareDeliveryPath}").Respond("application/json", mockDeliveryResponse);
       mockHttp.When($"{_postiApiSettings.BaseUrl}{getChangesPath}").Respond("application/json", changesResponseJson);

       var tokenService = new PostiService(mockHttp.ToHttpClient(), _postiApiSettings, _logger, _postiChangesFactory, _csvPreparer, mockEventBatcherService.Object);

       //Act
       var response = await tokenService.GetChangesAsync();

       //Assert            
       response.Should().NotBeNull();
       response.Should().BeAssignableTo<OkPostiResult>();
       var okResponse = (OkPostiResult)response;
       okResponse.Status.Should().Be(PostiResultStatus.Ok);
       okResponse.PostiErrors.Should().NotBeNull();
       okResponse.PostiErrors.Count.Should().Be(mockChangesResponse.Runs[0].Errors.Count);
       for (var i = 0; i < mockChangesResponse.Runs[0].Errors.Count; i++)
       {
         var line = int.Parse(mockChangesResponse.Runs[0].Errors[i].Line) - 1;
         okResponse.PostiErrors[i].CustomerId.Should().Be(generatedBatch.BatchRecords[line].CustomerNumber);
         okResponse.PostiErrors[i].FirstName.Should().Be(generatedBatch.BatchRecords[line].FirstName);
         okResponse.PostiErrors[i].LastName.Should().Be(generatedBatch.BatchRecords[line].LastName);
         okResponse.PostiErrors[i].Address.Should().Be(generatedBatch.BatchRecords[line].Address);
         okResponse.PostiErrors[i].City.Should().Be(generatedBatch.BatchRecords[line].City);
         okResponse.PostiErrors[i].PostalCode.Should().Be(generatedBatch.BatchRecords[line].PostalCode);
         okResponse.PostiErrors[i].Telephone.Should().Be(generatedBatch.BatchRecords[line].Telephone);
         okResponse.PostiErrors[i].Email.Should().Be(generatedBatch.BatchRecords[line].Email);
         okResponse.PostiErrors[i].Extra.Should().Be(generatedBatch.BatchRecords[line].Extra);
         okResponse.PostiErrors[i].Operation.ToString().Should().Be(generatedBatch.BatchRecords[line].Operation.ToString());
         okResponse.PostiErrors[i].ErrorMessage.Should().Be(mockChangesResponse.Runs[0].Errors[i].Message);
         okResponse.PostiErrors[i].FetchErrorType.Should().Be(GetFetchErrorType(mockChangesResponse.Runs[0].Errors[i].Message));
       }

       FetchErrorType GetFetchErrorType(string message)
         => message switch
         {
           "person does not exist in the follow-up register" => FetchErrorType.PersonDoesNotExist,
           "Person already exists in the follow-up register with a same customer number" => FetchErrorType.CustomerIdAlreadyExists,
           _ => FetchErrorType.Other
         };
     }
     */
    [Fact]
    public async void SendChanges_FileSend_Success()
    {
      //Arrange

      string sendFileRoute = $"register/{_postiApiSettings.RegistryId}/newFiles?forceStart=false";
      string commitFiles = $"register/{_postiApiSettings.RegistryId}/modifications";


      var mockFileSendResponse = Utils.ReadFixture("SuccessfulFileSendResponse.json");
      var moclFileCommitResponse = Utils.ReadFixture("SuccessfulFileCommitResponse.json");
      var postiAuthSettings = new PostiAuthSettings()
      {
        BaseUrl = "http://posti.domain/api/",
        ConsumerKey = "dummy",
        ConsumerSecret = "dummy",
        TokenTreshold = 0,
      };
      var mockTokenService = new Mock<ITokenService>();
      mockTokenService.Setup(p => p.GetAccessToken()).ReturnsAsync("token");
      var mockHttp = new MockHttpMessageHandler();
      mockHttp.When($"{_postiApiSettings.BaseUrl}{sendFileRoute}").Respond("application/json", mockFileSendResponse);
      mockHttp.When($"{_postiApiSettings.BaseUrl}{commitFiles}").Respond("application/json", moclFileCommitResponse);
      var postiService = new PostiService(mockHttp.ToHttpClient(), _postiApiSettings, _logger, _postiChangesFactory, _csvPreparer, _eventBatcherService, mockTokenService.Object);
      var exampleDtoCollection = PrepareRegistryRecordDtoCollection();

      //Act
      Func<Task<ISendChangesResult>> act = () => postiService.SendChangesAsync(exampleDtoCollection);

      //Assert            
      var whichConstrain = await act.Should().NotThrowAsync();
      var result = whichConstrain.Which;
      result.Should().NotBeNull();
      result.Status.Should().Be(SendChangesStatus.Success);
    }

    [Fact]
    public async void SendChanges_FileSend_FileSendFail()
    {
      //Arrange

      string sendFileRoute = $"register/{_postiApiSettings.RegistryId}/newFiles?forceStart=false";
      string commitFiles = $"register/{_postiApiSettings.RegistryId}/modifications";

      var moclFileCommitResponse = Utils.ReadFixture("SuccessfulFileCommitResponse.json");
      var postiAuthSettings = new PostiAuthSettings()
      {
        BaseUrl = "http://posti.domain/api/",
        ConsumerKey = "dummy",
        ConsumerSecret = "dummy",
        TokenTreshold = 0,
      };
      var mockTokenService = new Mock<ITokenService>();
      mockTokenService.Setup(p => p.GetAccessToken()).ReturnsAsync("token");
      var mockHttp = new MockHttpMessageHandler();
      mockHttp.When($"{_postiApiSettings.BaseUrl}{sendFileRoute}").Respond(HttpStatusCode.InternalServerError);
      mockHttp.When($"{_postiApiSettings.BaseUrl}{commitFiles}").Respond("application/json", moclFileCommitResponse);
      var postiService = new PostiService(mockHttp.ToHttpClient(), _postiApiSettings, _logger, _postiChangesFactory, _csvPreparer, _eventBatcherService, mockTokenService.Object);
      var exampleDtoCollection = PrepareRegistryRecordDtoCollection();

      //Act
      Func<Task<ISendChangesResult>> act = () => postiService.SendChangesAsync(exampleDtoCollection);

      //Assert            
      var whichConstrain = await act.Should().NotThrowAsync();
      var result = whichConstrain.Which;
      result.Should().NotBeNull();
      result.Status.Should().Be(SendChangesStatus.Fail);
      result.Should().BeAssignableTo<SendChangesFailed>();
      ((SendChangesFailed)(result)).Code.Should().Be("upload_failed");
    }

    [Fact]
    public async void SendChanges_FileSend_FileCommitFail()
    {
      //Arrange

      string commitFiles = $"register/{_postiApiSettings.RegistryId}/modifications";


      var mockFileSendResponse = Utils.ReadFixture("SuccessfulFileSendResponse.json");
      var moclFileCommitResponse = Utils.ReadFixture("SuccessfulFileCommitResponse.json");
      var postiAuthSettings = new PostiAuthSettings()
      {
        BaseUrl = "http://posti.domain/api/",
        ConsumerKey = "dummy",
        ConsumerSecret = "dummy",
        TokenTreshold = 0,
      };
      var mockTokenService = new Mock<ITokenService>();
      mockTokenService.Setup(p => p.GetAccessToken()).ReturnsAsync("token");
      var mockHttp = new MockHttpMessageHandler();
      mockHttp.When($"{_postiApiSettings.BaseUrl}{commitFiles}").Respond(HttpStatusCode.InternalServerError);
      var postiService = new PostiService(mockHttp.ToHttpClient(), _postiApiSettings, _logger, _postiChangesFactory, _csvPreparer, _eventBatcherService, mockTokenService.Object);
      var exampleDtoCollection = PrepareRegistryRecordDtoCollection();

      //Act
      Func<Task<ISendChangesResult>> act = () => postiService.CommitChangesAsync();

      //Assert            
      var whichConstrain = await act.Should().NotThrowAsync();
      var result = whichConstrain.Which;
      result.Should().NotBeNull();
      result.Status.Should().Be(SendChangesStatus.Fail);
      result.Should().BeAssignableTo<SendChangesFailed>();
      ((SendChangesFailed)(result)).Code.Should().Be("commit_fail");
    }

    [Fact]
    public async void SendChanges_SendChangesToPostiDisabledTrue_Success()
    {
      //Arrange

      var postiApiSettings = new PostiApiSettings()
      {
        BaseUrl = "http://posti.domain/api/",
        RegistryId = "registryId",
        DisableSendingChangesToPosti = true
      };
      var postiAuthSettings = new PostiAuthSettings()
      {
        BaseUrl = "http://posti.domain/api/",
        ConsumerKey = "dummy",
        ConsumerSecret = "dummy",
        TokenTreshold = 0,
      };
      var mockTokenService = new Mock<ITokenService>();
      mockTokenService.Setup(p => p.GetAccessToken()).ReturnsAsync("token");
      var mockHttp = new MockHttpMessageHandler();

      var postiService = new PostiService(mockHttp.ToHttpClient(), postiApiSettings, _logger, _postiChangesFactory, _csvPreparer, _eventBatcherService, mockTokenService.Object);
      var exampleDtoCollection = PrepareRegistryRecordDtoCollection();

      //Act
      Func<Task<ISendChangesResult>> act = () => postiService.SendChangesAsync(exampleDtoCollection);

      //Assert            
      var whichConstrain = await act.Should().NotThrowAsync();
      var result = whichConstrain.Which;
      result.Should().NotBeNull();
      result.Status.Should().Be(SendChangesStatus.Success);
    }

    private List<RegistryRecordDto> PrepareRegistryRecordDtoCollection()
    {
      var record = new RegistryRecordDto()
      {
        Operation = PostiOperations.Add,
        CustomerNumber = "1",
        Ssn = "080838-8550",
        LastName = "Meik�l�inen",
        FirstName = "Matti",
        PostalCode = "01340",
        City = "Vantaa",
        Address = "Torikatu 7",
        Telephone = "0501234567",
        Email = "matti.meikalainen@testi.fi",
        Extra = "super customer"
      };

      return new List<RegistryRecordDto> { record, record, record };
    }
  }
}
