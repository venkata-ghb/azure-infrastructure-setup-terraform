﻿using System.Text;
using FluentAssertions;
using PostiIntegration.Models;
using PostiIntegration.Posti.Csv;
using PostiIntegration.Posti.Factories;
using Xunit;

namespace PostiIntegration.Test.Posti;
public class CsvPreparerTest
{

  [Fact]
  public async void PrepareCsv_ValidChunk_ReturnsValidByteArray()
  {
    //Arrange
    var csvPreparer = new CsvPreparer(new RegistryRecordCsvFactory());
    var chunk = PrepareRecordChunk();

    //Act
    var byteArrayContent = csvPreparer.PrepareCsv(chunk);

    //Assert
    byteArrayContent.Should().NotBeNull();
    var content = await byteArrayContent.ReadAsStringAsync();
    var csvExample = CsvExample();
    content.Should().Be(csvExample);
  }

  private string CsvExample()
  {
    var line = "A;1;080838-8550;Meikäläinen;Matti;01340;Vantaa;Torikatu 7;0501234567;matti.meikalainen@testi.fi;super customer";
    var stringBuilder = new StringBuilder();
    stringBuilder.AppendLine(line);
    stringBuilder.AppendLine(line);
    stringBuilder.Append(line);
    return stringBuilder.ToString();
  }

  private RegistryRecordDto[] PrepareRecordChunk()
  {
    var record = new RegistryRecordDto()
    {
      Operation = PostiOperations.Add,
      CustomerNumber = "1",
      Ssn = "080838-8550",
      LastName = "Meikäläinen",
      FirstName = "Matti",
      PostalCode = "01340",
      City = "Vantaa",
      Address = "Torikatu 7",
      Telephone = "0501234567",
      Email = "matti.meikalainen@testi.fi",
      Extra = "super customer"
    };

    return new RegistryRecordDto[] { record, record, record };
  }
}
