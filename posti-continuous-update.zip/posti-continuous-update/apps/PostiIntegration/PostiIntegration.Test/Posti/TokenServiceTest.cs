using FluentAssertions;
using Microsoft.Extensions.Logging;
using PostiIntegration.Config.Models;
using PostiIntegration.Posti;
using RichardSzalay.MockHttp;
using Xunit;

namespace PostiIntegration.Test.Posti
{
  public class TokenServiceTest
  {
    private readonly ILogger<TokenService> _logger;

    public TokenServiceTest(ILogger<TokenService> logger)
    {
      _logger = logger;
    }

    [Fact]
    public async void GetAccessToken_ExecuteMethod_ReturnsAccessToken()
    {
      //Arrange
      var authSettings = new PostiAuthSettings()
      {
        BaseUrl = "http://domain/auth/token",
      };

      var path = "";
      var mockResponse = Utils.ReadFixture("accessTokenResponse.json");

      var mockHttp = new MockHttpMessageHandler();
      mockHttp.When($"{authSettings.BaseUrl}{path}").Respond("application/json", mockResponse);

      var tokenService = new TokenService(mockHttp.ToHttpClient(), authSettings, _logger);
      var expectedAccessToken = new AccessToken("token", 3600);
      //Act
      var response = await tokenService.GetAccessToken();

      //Assert            
      response.Should().NotBeNull();
      response.Should().Be(expectedAccessToken.Token);
    }
  }
}
