﻿using System;
using System.Collections.Generic;
using Bogus;
using Microsoft.Extensions.Logging;
using PostiIntegration.Config.Models;
using PostiIntegration.CosmosDb.Models;
using PostiIntegration.EventBatcher;
using PostiIntegration.EventBatcher.Mappers;
using PostiIntegration.EventBatcher.Models;
using PostiIntegration.Models;
using PostiIntegration.Posti.Models;
using RichardSzalay.MockHttp;

namespace PostiIntegration.Test.Fixtures;
public static class Generators
{
  public static List<PostiChange> GenerateFakePostiChangesCollection(bool isLocalAddress = true)
  {
    var test = new Faker<PostiChange>(locale: "fi")
        .RuleFor(x => x.PostiChangeStatus, x => GenerateChangeStatus())
        .RuleFor(x => x.CustomerId, x => x.Finance.Account(50))
        .RuleFor(x => x.Ssn, x => x.Finance.Account(11))
        .RuleFor(x => x.FirstName, x => x.Name.FirstName())
        .RuleFor(x => x.LastName, x => x.Name.LastName())
        .RuleFor(x => x.Address, x => GenerateAddress(isLocalAddress))
        .RuleFor(x => x.ForeignAddress, x => GenerateForeignAddress(isLocalAddress))
        .RuleFor(x => x.PersonStatus, x => GeneratePersonStatus());
    var sampleCollection = test.GenerateBetween(2, 5);
    sampleCollection.Add(new PostiChange() { CustomerId = "1", DuplicatedId = "2", PostiChangeStatus = new PostiChangeStatus() { IsDuplicated = true } });
    return sampleCollection;
  }

  public static PostiChangeStatus GenerateChangeStatus()
  {
    var changeStatus = new Faker<PostiChangeStatus>()
      .RuleFor(x => x.IsDuplicated, x => x.Random.Bool())
      .RuleFor(x => x.WasIdentified, x => x.Random.Bool())
      .RuleFor(x => x.WasModified, x => x.Random.Bool());

    return changeStatus.Generate();
  }
  public static PersonStatus GeneratePersonStatus()
  {
    var changeStatus = new Faker<PersonStatus>()
      .RuleFor(x => x.DateOfDeath, x => x.Date.PastDateOnly())
      .RuleFor(x => x.IsMinor, x => x.Random.Bool())
      .RuleFor(x => x.IsDeceased, x => x.Random.Bool());

    return changeStatus.Generate();
  }

  public static Address GenerateAddress(bool isLocalAddress)
  {
    var address = new Faker<Address>(locale: "fi")
        .RuleFor(x => x.AddressType, x => x.PickRandom<AddressType>())
        .RuleFor(x => x.City, x => x.Address.City())
        .RuleFor(x => x.Street, x => x.Address.StreetAddress())
        .RuleFor(x => x.PostalCode, x => x.Address.ZipCode("#####"));
    return isLocalAddress ? address.Generate() : null;
  }
  public static ForeignAddress GenerateForeignAddress(bool isLocalAddress)
  {
    var address = new Faker<ForeignAddress>(locale: "fi")
        .RuleFor(x => x.OtherAddressLine1, x => x.Address.StreetAddress())
        .RuleFor(x => x.OtherAddressLine2, x => x.Address.ZipCode())
        .RuleFor(x => x.OtherAddressLine3, x => x.Address.StreetAddress())
        .RuleFor(x => x.OtherAddressLine4, x => x.Address.City())
        .RuleFor(x => x.CountryCode, x => x.Address.Country())
        .RuleFor(x => x.CountryName, x => x.Address.CountryCode());
    return !isLocalAddress ? address.Generate() : null;
  }

  public static EventBatcherResult GenerateEventBatcherResult()
  {
    var batchResult = new Faker<EventBatcherResult>()
        .RuleFor(x => x.Status, x => EventBatcherResultStatus.Success)
        .RuleFor(x => x.BatchRecords, x => GenerateCollectionOfBatchRecords());

    return batchResult.Generate();
  }

  public static List<BatchRecord> GenerateCollectionOfBatchRecords(int min = 40, int max = 50)
  {
    var batchRecords = new Faker<BatchRecord>()
        .RuleFor(x => x.CustomerNumber, x => x.Finance.Account(50))
        .RuleFor(x => x.Ssn, x => x.Finance.Account(11))
        .RuleFor(x => x.FirstName, x => x.Name.FirstName())
        .RuleFor(x => x.LastName, x => x.Name.LastName())
        .RuleFor(x => x.City, x => x.Address.City())
        .RuleFor(x => x.Address, x => x.Address.StreetAddress())
        .RuleFor(x => x.PostalCode, x => x.Address.ZipCode("#####"))
        .RuleFor(x => x.Email, x => x.Internet.Email())
        .RuleFor(x => x.Extra, x => x.Random.Utf16String(maxLength: 50));
    return batchRecords.GenerateBetween(min, max);
  }


  public static EventBatcherService PrepareEventBatchService(ILogger<EventBatcherService> logger)
  {
    var _postiApiSettings = new EventBatcherSettings()
    {
      Url = "http://eventBatcher.domain/api/",
      HostKey = "key"
    };

    string prepareDeliveryPath = "GetBatch";

    var mockHttp = new MockHttpMessageHandler();
    var mockLatestBatchResponse = Utils.ReadFixture("latestBatchResponse.json");
    mockHttp.When($"{_postiApiSettings.Url}{prepareDeliveryPath}").Respond("application/json", mockLatestBatchResponse);
    var mapper = new BatchRecordMapper();
    var eventBatcherService = new EventBatcherService(mockHttp.ToHttpClient(), _postiApiSettings, logger, mapper);

    return eventBatcherService;
  }

  public static PostiError GeneratePostiError(
    long timestamp = 1234567,
    string operation = "Add",
    string customerId = "000000",
    string ssn = "010100-0000",
    string lastName = "Teekkari",
    string firstName = "Teemu",
    string postalCode = "00100",
    string city = "Helsinki",
    string address = "Feikkikatu 1",
    string telephone = "0401112222",
    string email = "teemu.teekkari@mailplace.com",
    string extra = "",
    string errorMessage = "person does not exist in the follow-up register",
    FetchErrorType errorType = FetchErrorType.PersonDoesNotExist)
  {
    return new PostiError()
    {
      Timestamp = timestamp,
      Operation = operation,
      CustomerId = customerId,
      Ssn = ssn,
      LastName = lastName,
      FirstName = firstName,
      PostalCode = postalCode,
      City = city,
      Address = address,
      Telephone = telephone,
      Email = email,
      Extra = extra,
      ErrorMessage = errorMessage,
      FetchErrorType = errorType
    };
  }

  public static (Deliverable dto, FileFetchingErrorDocument document) GetFileResponseDtoAndFailedFetchDocument(
    string id = "634417d1f614a5008a39d177",
    int chunks = 1,
    string created = "2022-10-28 13:02:09",
    int lines = 1)
  {
    var document = new FileFetchingErrorDocument()
    {
      Id = id,
      Chunks = chunks,
      Created = DateTime.Parse(created),
    };

    var dto = Deliverable.CreateFromDocument(document);

    return (dto, document);
  }
}
