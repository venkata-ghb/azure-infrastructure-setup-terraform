﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using PostiIntegration.CosmosDb;
using Xunit;

namespace PostiIntegration.Test;
public class DeletePostiErrorsTest
{
  private readonly Mock<ICosmosDbService> _mockDbService;
  private readonly DeletePostiErrors _testTrigger;

  public DeletePostiErrorsTest(ILogger<DeletePostiErrors> logger)
  {
    _mockDbService = new Mock<ICosmosDbService>();
    _testTrigger = new DeletePostiErrors(logger, _mockDbService.Object);
  }

  [Theory]
  [InlineData(null)]
  [InlineData("2022-07-05T13:00:27Z")]
  public async void ValidRequest_SuccessResponse(string requestParam)
  {
    DateTime? param = !string.IsNullOrEmpty(requestParam) ? DateTime.Parse(requestParam) : null;

    var request = Utils.CreateMockRequestWithQuery(new Dictionary<string, Microsoft.Extensions.Primitives.StringValues>() {
      {"ErrorDateTime", requestParam }
    });
    _mockDbService.Setup(x => x.DeletePostiErrors(It.IsAny<DateTime?>())).ReturnsAsync(true);

    //Act
    Func<Task<IActionResult>> act = () => _testTrigger.Run(request.Object);

    //Assert            
    var result = await act.Should().NotThrowAsync();
    var response = result.Which;
    response.Should().BeAssignableTo<NoContentResult>();
  }

  [Theory]
  [InlineData(null)]
  [InlineData("2022-07-05T13:00:27Z")]
  public async void ValidRequest_500ResponseAferFailedDeletion(string requestParam)
  {
    DateTime? param = !string.IsNullOrEmpty(requestParam) ? DateTime.Parse(requestParam) : null;

    var request = Utils.CreateMockRequestWithQuery(new Dictionary<string, Microsoft.Extensions.Primitives.StringValues>() {
      {"ErrorDateTime", requestParam }
    });
    _mockDbService.Setup(x => x.DeletePostiErrors(It.IsAny<DateTime?>())).ReturnsAsync(false);

    //Act
    Func<Task<IActionResult>> act = () => _testTrigger.Run(request.Object);

    //Assert            
    var result = await act.Should().NotThrowAsync();
    var response = result.Which;
    response.Should().BeAssignableTo<StatusCodeResult>();
    response.As<StatusCodeResult>().Should().NotBeNull();
    response.As<StatusCodeResult>().StatusCode.Should().Be(500);

  }
}
