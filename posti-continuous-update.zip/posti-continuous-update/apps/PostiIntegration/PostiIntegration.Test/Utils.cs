﻿using System.Collections.Generic;
using System.IO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Internal;
using Microsoft.Extensions.Primitives;
using Moq;
using Newtonsoft.Json;

namespace PostiIntegration.Test
{
  internal static class Utils
  {
    public static Mock<HttpRequest> CreateMockRequestWithBody(object? body)
    {
      var memoryStream = new MemoryStream();
      var streamWriter = new StreamWriter(memoryStream);

      var json = JsonConvert.SerializeObject(body);

      streamWriter.Write(json);
      streamWriter.Flush();

      memoryStream.Position = 0;

      var mockRequest = new Mock<HttpRequest>();
      mockRequest.Setup(req => req.Body).Returns(memoryStream);

      return mockRequest;
    }

    public static Mock<HttpRequest> CreateMockRequestWithoutBody()
    {
      var mockRequest = new Mock<HttpRequest>();
      return mockRequest;
    }

    public static Mock<HttpRequest> CreateMockRequestWithQuery(Dictionary<string, StringValues> query)
    {
      var q = new QueryCollection(query);

      var mockRequest = new Mock<HttpRequest>();
      mockRequest.Setup(req => req.Query).Returns(q);

      return mockRequest;
    }

    public static string ReadFixture(string filename)
    {
      var directory = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);

      return File.ReadAllText(Path.Combine(directory, "Fixtures", filename));
    }
  }
}
