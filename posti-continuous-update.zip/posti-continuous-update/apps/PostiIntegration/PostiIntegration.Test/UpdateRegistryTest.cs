using System.Collections.Generic;
using Bogus;
using FluentAssertions;
using FluentValidation;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Internal;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using PostiIntegration.Models;
using PostiIntegration.Posti;
using PostiIntegration.Posti.Models;
using PostiIntegration.Test.Models;
using PostiIntegration.Validators;
using Xunit;

namespace PostiIntegration.Test
{
  public class UpdateRegistryTest
  {
    private UpdateRegistry _updateRegistry;
    private ILogger<UpdateRegistry> _logger;

    public UpdateRegistryTest(ILogger<UpdateRegistry> updateRegistryLogger)
    {
      _logger = updateRegistryLogger;
      IValidator<IList<RegistryRecordDto>> validator = new RegistryRecordCollectionValidator();
      var postiServiceMock = new Mock<IPostiService>();
      postiServiceMock.Setup(x => x.SendChangesAsync(It.IsAny<List<RegistryRecordDto>>()))
          .ReturnsAsync(new SendChangesSuccess());
      _updateRegistry = new UpdateRegistry(updateRegistryLogger, validator, postiServiceMock.Object);
    }

    private void SetupFunction(ILogger<UpdateRegistry> logger, ISendChangesResult functionResult)
    {
      IValidator<IList<RegistryRecordDto>> validator = new RegistryRecordCollectionValidator();
      var postiServiceMock = new Mock<IPostiService>();
      postiServiceMock.Setup(x => x.SendChangesAsync(It.IsAny<List<RegistryRecordDto>>()))
          .ReturnsAsync(functionResult);
      _updateRegistry = new UpdateRegistry(logger, validator, postiServiceMock.Object);
    }

    [Fact]
    public async void ValidJsonBodyDefaultRecordDto_Returns200()
    {
      var sampleCollection = PrepareDefaultCollection();

      var request = Utils.CreateMockRequestWithBody(sampleCollection).Object;

      //Act
      var response = await _updateRegistry.Run(request);

      //Assert            
      response.Should().BeAssignableTo<OkResult>();
    }

    [Fact]
    public async void ValidJsonBodyWithGeneratedModel_Returns200()
    {
      //Arrange
      List<RegistryRecordStringOperationDto> sampleCollection = PrepareRegistryRecordStringOperationDtoBody();
      var request = Utils.CreateMockRequestWithBody(sampleCollection).Object;

      //Act
      var response = await _updateRegistry.Run(request);

      //Assert            
      response.Should().BeAssignableTo<OkResult>();
    }

    [Fact]
    public async void ValidJsonBodyWithGeneratedModelButSendFails_Returns502()
    {
      //Arrange
      var commitFailedStatus = SendChangesFailed.CreateUploadFailedStatus();
      SetupFunction(_logger, commitFailedStatus);

      List<RegistryRecordStringOperationDto> sampleCollection = PrepareRegistryRecordStringOperationDtoBody();
      var request = Utils.CreateMockRequestWithBody(sampleCollection).Object;


      //Act
      var response = await _updateRegistry.Run(request);

      //Assert            
      response.Should().BeAssignableTo<ObjectResult>();

      var result = (ObjectResult)response;
      result.Value.Should().NotBeNull();
      result.Value.As<ErrorResponse>().Code.Should().Be(commitFailedStatus.Code);
      result.Value.As<ErrorResponse>().Error.Should().Be(commitFailedStatus.Message);
    }

    [Fact]
    public async void ValidJsonBodyWithGeneratedModelButCommitFails_Returns502()
    {
      //Arrange
      var commitFailedStatus = SendChangesFailed.CreateCommitFailedStatus();
      SetupFunction(_logger, commitFailedStatus);

      List<RegistryRecordStringOperationDto> sampleCollection = PrepareRegistryRecordStringOperationDtoBody();
      var request = Utils.CreateMockRequestWithBody(sampleCollection).Object;


      //Act
      var response = await _updateRegistry.Run(request);

      //Assert            
      response.Should().BeAssignableTo<ObjectResult>();

      var result = (ObjectResult)response;
      result.Value.Should().NotBeNull();
      result.Value.As<ErrorResponse>().Code.Should().Be(commitFailedStatus.Code);
      result.Value.As<ErrorResponse>().Error.Should().Be(commitFailedStatus.Message);
    }

    [Theory]
    [InlineData("")]
    [InlineData(null)]
    public async void InvalidOperationJsonBody_Returns400(string operation)
    {
      //Arrange
      var sampleCollection = PrepareDefaultCollection();
      sampleCollection[0].Operation = operation;
      var request = Utils.CreateMockRequestWithBody(sampleCollection).Object;

      //Act
      var response = await _updateRegistry.Run(request);

      //Assert            
      response.Should().BeAssignableTo<BadRequestObjectResult>();
      var result = (BadRequestObjectResult)response;

      result.Value.Should().NotBeNull();
      result.Value.As<ErrorResponse<ValidationError>>().Code.Should().Be("validation_error");
    }

    [Theory]
    [InlineData("SomeRandomString")]
    public async void InvalidOperationSerializationJsonBody_Returns400(string operation)
    {
      //Arrange
      var sampleCollection = PrepareDefaultCollection();
      sampleCollection[0].Operation = operation;
      var request = Utils.CreateMockRequestWithBody(sampleCollection).Object;

      //Act
      var response = await _updateRegistry.Run(request);

      //Assert            
      response.Should().BeAssignableTo<BadRequestObjectResult>();
      var result = (BadRequestObjectResult)response;

      result.Value.Should().NotBeNull();
      result.Value.As<ErrorResponse>().Code.Should().Be("serialization_error");
    }

    [Theory]
    [InlineData("")]
    [InlineData(null)]
    [InlineData("00000000000000000000000000000000000000000000000000000000000000")]
    public async void InvalidCustomerNumberJsonBody_Returns400(string customerNumber)
    {
      //Arrange
      var sampleCollection = PrepareDefaultCollection();
      sampleCollection[0].CustomerNumber = customerNumber;
      var request = Utils.CreateMockRequestWithBody(sampleCollection).Object;

      //Act
      var response = await _updateRegistry.Run(request);

      //Assert            
      response.Should().BeAssignableTo<BadRequestObjectResult>();
      var result = (BadRequestObjectResult)response;

      result.Value.Should().NotBeNull();
      result.Value.As<ErrorResponse<ValidationError>>().Code.Should().Be("validation_error");
    }

    [Theory]
    [InlineData("000000000000")]
    public async void InvalidSsnJsonBody_Returns400(string ssn)
    {
      //Arrange
      var sampleCollection = PrepareDefaultCollection();
      sampleCollection[0].Ssn = ssn;
      var request = Utils.CreateMockRequestWithBody(sampleCollection).Object;

      //Act
      var response = await _updateRegistry.Run(request);

      //Assert            
      response.Should().BeAssignableTo<BadRequestObjectResult>();
      var result = (BadRequestObjectResult)response;

      result.Value.Should().NotBeNull();
      result.Value.As<ErrorResponse<ValidationError>>().Code.Should().Be("validation_error");
    }

    [Theory]
    [InlineData("")]
    [InlineData(null)]
    [InlineData("00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000")]
    public async void InvalidLastName_Returns400(string lastName)
    {
      //Arrange
      var sampleCollection = PrepareDefaultCollection();
      sampleCollection[0].LastName = lastName;
      var request = Utils.CreateMockRequestWithBody(sampleCollection).Object;

      //Act
      var response = await _updateRegistry.Run(request);

      //Assert            
      response.Should().BeAssignableTo<BadRequestObjectResult>();
      var result = (BadRequestObjectResult)response;

      result.Value.Should().NotBeNull();
      result.Value.As<ErrorResponse<ValidationError>>().Code.Should().Be("validation_error");
    }

    [Theory]
    [InlineData("")]
    [InlineData(null)]
    [InlineData("00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000")]
    public async void InvalidFirstName_Returns400(string firstName)
    {
      //Arrange
      var sampleCollection = PrepareDefaultCollection();
      sampleCollection[0].FirstName = firstName;
      var request = Utils.CreateMockRequestWithBody(sampleCollection).Object;

      //Act
      var response = await _updateRegistry.Run(request);

      //Assert            
      response.Should().BeAssignableTo<BadRequestObjectResult>();
      var result = (BadRequestObjectResult)response;

      result.Value.Should().NotBeNull();
      result.Value.As<ErrorResponse<ValidationError>>().Code.Should().Be("validation_error");
    }

    [Theory]
    [InlineData("")]
    [InlineData(null)]
    [InlineData("000000")]
    public async void InvalidPostalCode_Returns400(string postalCode)
    {
      //Arrange
      var sampleCollection = PrepareDefaultCollection();
      sampleCollection[0].PostalCode = postalCode;
      var request = Utils.CreateMockRequestWithBody(sampleCollection).Object;

      //Act
      var response = await _updateRegistry.Run(request);

      //Assert            
      response.Should().BeAssignableTo<BadRequestObjectResult>();
      var result = (BadRequestObjectResult)response;

      result.Value.Should().NotBeNull();
      result.Value.As<ErrorResponse<ValidationError>>().Code.Should().Be("validation_error");
    }

    [Theory]
    [InlineData("0000000000000000000000000000000")]
    public async void InvalidCity_Returns400(string city)
    {
      //Arrange
      var sampleCollection = PrepareDefaultCollection();
      sampleCollection[0].City = city;
      var request = Utils.CreateMockRequestWithBody(sampleCollection).Object;

      //Act
      var response = await _updateRegistry.Run(request);

      //Assert            
      response.Should().BeAssignableTo<BadRequestObjectResult>();
      var result = (BadRequestObjectResult)response;

      result.Value.Should().NotBeNull();
      result.Value.As<ErrorResponse<ValidationError>>().Code.Should().Be("validation_error");
    }

    [Theory]
    [InlineData("")]
    [InlineData(null)]
    [InlineData("00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000")]
    public async void InvalidAddress_Returns400(string address)
    {
      //Arrange
      var sampleCollection = PrepareDefaultCollection();
      sampleCollection[0].Address = address;
      var request = Utils.CreateMockRequestWithBody(sampleCollection).Object;

      //Act
      var response = await _updateRegistry.Run(request);

      //Assert            
      response.Should().BeAssignableTo<BadRequestObjectResult>();
      var result = (BadRequestObjectResult)response;

      result.Value.Should().NotBeNull();
      result.Value.As<ErrorResponse<ValidationError>>().Code.Should().Be("validation_error");
    }

    [Theory]
    [InlineData("000000000000000000001")]
    public async void InvalidTelephone_Returns400(string telephone)
    {
      //Arrange
      var sampleCollection = PrepareDefaultCollection();
      sampleCollection[0].Telephone = telephone;
      var request = Utils.CreateMockRequestWithBody(sampleCollection).Object;

      //Act
      var response = await _updateRegistry.Run(request);

      //Assert            
      response.Should().BeAssignableTo<BadRequestObjectResult>();
      var result = (BadRequestObjectResult)response;

      result.Value.Should().NotBeNull();
      result.Value.As<ErrorResponse<ValidationError>>().Code.Should().Be("validation_error");
    }

    [Theory]
    [InlineData("000000000000000000000000000000000000000000000000000000000000")]
    public async void InvalidEmail_Returns400(string email)
    {
      //Arrange
      var sampleCollection = PrepareDefaultCollection();
      sampleCollection[0].Email = email;
      var request = Utils.CreateMockRequestWithBody(sampleCollection).Object;

      //Act
      var response = await _updateRegistry.Run(request);

      //Assert            
      response.Should().BeAssignableTo<BadRequestObjectResult>();
      var result = (BadRequestObjectResult)response;

      result.Value.Should().NotBeNull();
      result.Value.As<ErrorResponse<ValidationError>>().Code.Should().Be("validation_error");
    }

    [Theory]
    [InlineData("000000000000000000000000000000000000000000000000000000000000")]
    public async void InvalidExtra_Returns400(string extra)
    {
      //Arrange
      var sampleCollection = PrepareDefaultCollection();
      sampleCollection[0].Extra = extra;
      var request = Utils.CreateMockRequestWithBody(sampleCollection).Object;

      //Act
      var response = await _updateRegistry.Run(request);

      //Assert            
      response.Should().BeAssignableTo<BadRequestObjectResult>();
      var result = (BadRequestObjectResult)response;

      result.Value.Should().NotBeNull();
      result.Value.As<ErrorResponse<ValidationError>>().Code.Should().Be("validation_error");
    }

    [Fact]
    public async void EmptyBody_Returns400()
    {
      //Assert
      var request = Utils.CreateMockRequestWithBody(null).Object;

      //Act
      var response = await _updateRegistry.Run(request);

      //Assert            
      response.Should().BeAssignableTo<BadRequestObjectResult>();
      var result = (BadRequestObjectResult)response;

      result.Value.Should().NotBeNull();
      result.Value.As<ErrorResponse<ValidationError>>().Code.Should().Be("validation_error");
    }

    [Fact]
    public async void NullRequest_Returns500()
    {
      //Assert
      DefaultHttpRequest request = null;

      //Act
      var response = await _updateRegistry.Run(request);

      //Assert            
      response.Should().BeAssignableTo<StatusCodeResult>();
      var result = (StatusCodeResult)response;

      result.Should().NotBeNull();
      result.StatusCode.Should().Be(StatusCodes.Status500InternalServerError);
    }

    private static List<RegistryRecordStringOperationDto> PrepareDefaultCollection()
    {
      //Arrange
      return new List<RegistryRecordStringOperationDto>()
            { new RegistryRecordStringOperationDto("Add"), new RegistryRecordStringOperationDto("Remove") };
    }

    private List<RegistryRecordStringOperationDto> PrepareRegistryRecordStringOperationDtoBody()
    {
      var operation = new string[] { "Add", "Remove", "Modify" };
      var test = new Faker<RegistryRecordStringOperationDto>(locale: "fi")
          .RuleFor(x => x.Operation, x => x.PickRandom(operation))
          .RuleFor(x => x.CustomerNumber, x => x.Finance.Account(50))
          .RuleFor(x => x.Ssn, x => x.Finance.Account(11))
          .RuleFor(x => x.FirstName, x => x.Name.FirstName())
          .RuleFor(x => x.LastName, x => x.Name.LastName())
          .RuleFor(x => x.PostalCode, x => x.Address.ZipCode("#####"))
          .RuleFor(x => x.City, x => x.Address.City())
          .RuleFor(x => x.Address, x => x.Address.StreetAddress())
          .RuleFor(x => x.Telephone, x => x.Phone.PhoneNumber("####################"))
          .RuleFor(x => x.Email, x => x.Internet.Email())
          .RuleFor(x => x.Extra, x => x.Random.Utf16String(maxLength: 50));
      var sampleCollection = test.GenerateBetween(2, 5);
      return sampleCollection;
    }
  }
}
