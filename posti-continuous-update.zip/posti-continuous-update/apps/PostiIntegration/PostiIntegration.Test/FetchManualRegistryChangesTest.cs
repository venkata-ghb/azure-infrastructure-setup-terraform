using System;
using System.Collections.Generic;
using System.Net;
using System.Web.Http;
using Azure;
using Azure.Core;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using Moq;
using PostiIntegration.ClmUpdater;
using PostiIntegration.CosmosDb;
using PostiIntegration.Models;
using PostiIntegration.Posti;
using PostiIntegration.Posti.Models;
using PostiIntegration.Test.Fixtures;
using PostiIntegration.Test.Models;
using Xunit;

namespace PostiIntegration.Test
{
  public class FetchManualRegistryChangesTest
  {
    private readonly ILogger<FetchManualRegistryChanges> _logger;
    private readonly Mock<ICosmosDbService> _mockDbService;


    public FetchManualRegistryChangesTest(ILogger<FetchManualRegistryChanges> logger)
    {
      _logger = logger;
      _mockDbService = new Mock<ICosmosDbService>();
    }

    [Fact]
    public async void NoChangesFetched_Returns200()
    {
      //Arrange
      Deliverable deliverable = new Deliverable
      {
        CreatedDate = DateTime.UtcNow,
        Id = "abcd-1234",
        NumberOfChunks = 1,
      };
      var postiService = new Mock<IPostiService>();
      postiService.Setup(p => p.FetchFile(deliverable)).ReturnsAsync(new NoChangesPostiResult { Status = PostiResultStatus.NoChanges });

      var clmUpdaterService = new Mock<IClmUpdaterService>();
      clmUpdaterService.Setup(p => p.SendChangesAsync(new List<PostiChange>()));

      var expectedPostiError = Generators.GeneratePostiError();

      _mockDbService
      .Setup(dbService => dbService.StorePostiError(It.Is<PostiError>(postiError => postiError == expectedPostiError)))
      .ReturnsAsync(true)
      .Verifiable();

      var fetchRegistry = new FetchManualRegistryChanges(_logger, postiService.Object, clmUpdaterService.Object, _mockDbService.Object);
      var request = Utils.CreateMockRequestWithoutBody().Object;

      //Act
      var response = await fetchRegistry.Run(request);

      response.Should().BeAssignableTo<InternalServerErrorResult>();
      _mockDbService.VerifyNoOtherCalls();
    }
    
    [Fact]
    public async void ChangesFetched_Returns200()
    {
      //Arrange
      Deliverable deliverable = new Deliverable
      {
        CreatedDate = DateTime.UtcNow,
        Id = "abcd-1234",
        NumberOfChunks = 1,
      };
      var postiService = new Mock<IPostiService>();

      var examplePostiResult = new OkPostiResult("1") { Status = PostiResultStatus.Ok };
      var expectedPostiError = Generators.GeneratePostiError();
      examplePostiResult.PostiChanges.AddRange(Generators.GenerateFakePostiChangesCollection());
      examplePostiResult.PostiErrors.Add(expectedPostiError);

      _mockDbService
      .Setup(dbService => dbService.StorePostiError(It.Is<PostiError>(postiError => postiError == expectedPostiError)))
      .ReturnsAsync(true)
      .Verifiable();

      var clmUpdaterService = new Mock<IClmUpdaterService>();
      clmUpdaterService.Setup(p => p.SendChangesAsync(new List<PostiChange>()));

      postiService.Setup(p => p.FetchFile(deliverable)).ReturnsAsync(examplePostiResult);
      var fetchRegistry = new FetchManualRegistryChanges(_logger, postiService.Object, clmUpdaterService.Object, _mockDbService.Object);
      var request = Utils.CreateMockRequestWithBody(deliverable).Object;

      //Act
      var response = await fetchRegistry.Run(request);

      //Assert            
      response.Should().BeAssignableTo<OkResult>();
      _mockDbService.Verify();
      _mockDbService.VerifyNoOtherCalls();
    }
    
    [Fact]
    public async void FilePreparationFails_Returns500()
    {
      //Arrange
      Deliverable deliverable = new Deliverable
      {
        CreatedDate = DateTime.UtcNow,
        Id = "abcd-1234",
        NumberOfChunks = 1,
      };
      var postiService = new Mock<IPostiService>();

      var examplePostiResult = new FilePreparationFailedResult();
      var clmUpdaterService = new Mock<IClmUpdaterService>();

      postiService.Setup(p => p.FetchFile(deliverable)).ReturnsAsync(examplePostiResult);
      var fetchRegistry = new FetchManualRegistryChanges(_logger, postiService.Object, clmUpdaterService.Object, _mockDbService.Object);
      var request = Utils.CreateMockRequestWithBody(deliverable).Object;
      //Act
      var response = await fetchRegistry.Run(request);

      //Assert            
      response.Should().BeAssignableTo<ObjectResult>();
      var result = response as ObjectResult;
      result.StatusCode.Should().Be(StatusCodes.Status502BadGateway);
      result.Value.Should().BeEquivalentTo(new ErrorResponse(examplePostiResult.Code, examplePostiResult.Message));
      _mockDbService.Verify();
      _mockDbService.VerifyNoOtherCalls();
    }

    [Fact]
    public async void FileFetchingFails_Returns500()
    {
      //Arrange
      Deliverable deliverable = new()
      {
        CreatedDate = DateTime.UtcNow,
        Id = "abcd-1234",
        NumberOfChunks = 1,
      };
      var postiService = new Mock<IPostiService>();
      var examplePostiResult = new FileFetchingFailedResult()
      {
        Id = "634417d1f614a5008a39d177",
        Chunks = 1,
        Created = DateTime.Parse("2022-10-28 13:02:09"),
        Lines = 1,
      };

      _mockDbService
      .Setup(dbService => dbService.StoreFileFetchingError(It.Is<FileFetchingFailedResult>(result => result == examplePostiResult)))
      .ReturnsAsync(true)
      .Verifiable();

      var clmUpdaterService = new Mock<IClmUpdaterService>();

      postiService.Setup(p => p.FetchFile(deliverable)).ReturnsAsync(examplePostiResult);
      var fetchRegistry = new FetchManualRegistryChanges(_logger, postiService.Object, clmUpdaterService.Object, _mockDbService.Object);
      var request = Utils.CreateMockRequestWithBody(deliverable).Object;
      //Act
      var response = await fetchRegistry.Run(request);

      //Assert            
      response.Should().BeAssignableTo<ObjectResult>();
      var result = response as ObjectResult;
      result.StatusCode.Should().Be(StatusCodes.Status502BadGateway);
      result.Value.Should().BeEquivalentTo(new ErrorResponse(examplePostiResult.Code, examplePostiResult.Message));
      _mockDbService.Verify();
      _mockDbService.VerifyNoOtherCalls();
    }

    [Fact]
    public async void UnexpectedException_Returns500()
    {
      //Arrange
      Deliverable deliverable = new()
      {
        CreatedDate = DateTime.UtcNow,
        Id = "abcd-1234",
        NumberOfChunks = 1,
      };
      var postiService = new Mock<IPostiService>();
      postiService.Setup(p => p.FetchFile(deliverable)).Throws(new System.Exception());
      var clmUpdaterService = new Mock<IClmUpdaterService>();
      clmUpdaterService.Setup(p => p.SendChangesAsync(new List<PostiChange>()));

      var fetchRegistry = new FetchManualRegistryChanges(_logger, postiService.Object, clmUpdaterService.Object, _mockDbService.Object);
      var request = Utils.CreateMockRequestWithBody(deliverable).Object;

      //Act
      var response = await fetchRegistry.Run(request);

      //Assert            
      response.Should().BeAssignableTo<StatusCodeResult>();
      response.As<StatusCodeResult>().StatusCode.Should().Be(StatusCodes.Status500InternalServerError);
    }

    [Fact]
    public async void CosmosException_Returns500()
    {
      //Arrange
      Deliverable deliverable = new()
      {
        CreatedDate = DateTime.UtcNow,
        Id = "abcd-1234",
        NumberOfChunks = 1,
      };
      var examplePostiResult = new OkPostiResult("1") { Status = PostiResultStatus.Ok };
      var expectedPostiError = Generators.GeneratePostiError();
      examplePostiResult.PostiChanges.AddRange(Generators.GenerateFakePostiChangesCollection());
      examplePostiResult.PostiErrors.Add(expectedPostiError);

      var postiService = new Mock<IPostiService>();
      postiService.Setup(p => p.FetchFile(deliverable)).ReturnsAsync(examplePostiResult);
      var clmUpdaterService = new Mock<IClmUpdaterService>();
      clmUpdaterService.Setup(p => p.SendChangesAsync(new List<PostiChange>()));


      _mockDbService
      .Setup(dbService => dbService.StorePostiError(It.Is<PostiError>(postiError => postiError == expectedPostiError)))
      .Throws(new CosmosException("Oops", HttpStatusCode.BadRequest, 440, "id", 0.1))
      .Verifiable();

      var fetchRegistry = new FetchManualRegistryChanges(_logger, postiService.Object, clmUpdaterService.Object, _mockDbService.Object);
      var request = Utils.CreateMockRequestWithBody(deliverable).Object;

      //Act
      var response = await fetchRegistry.Run(request);

      //Assert            
      response.Should().BeAssignableTo<ObjectResult>();
      response.As<ObjectResult>().StatusCode.Should().Be(StatusCodes.Status500InternalServerError);
      response.As<ObjectResult>().Value.Should().BeEquivalentTo(new ErrorResponse("storing_file_fetch_errors_fails", "An error occurred while storing File Fetching Errors in database"));

      _mockDbService.Verify();
      _mockDbService.VerifyNoOtherCalls();
    }
  }
}
