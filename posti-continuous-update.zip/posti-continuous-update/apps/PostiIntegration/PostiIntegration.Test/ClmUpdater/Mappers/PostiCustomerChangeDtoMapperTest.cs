﻿using System.Linq;
using FluentAssertions;
using PostiIntegration.ClmUpdater.Mappers;
using Xunit;

namespace PostiIntegration.Test.ClmUpdater.Mappers;
public class PostiCustomerChangeDtoMapperTest
{
  private readonly PostiCustomerChangeDtoMapper _mapper;

  public PostiCustomerChangeDtoMapperTest()
  {
    _mapper = new PostiCustomerChangeDtoMapper();
  }

  [Fact]
  public void Map_CheckAddressAfterMappingFromGeneratedChanges_CorrectMapping()
  {
    var changes = Fixtures.Generators.GenerateFakePostiChangesCollection(isLocalAddress: true);
    var mappedDtos = _mapper.Map(changes);
    foreach (var dto in mappedDtos.SkipLast(1))
    {
      dto.Address.Should().NotBeNull();
      dto.ForeignAddress.Should().BeNull();
    }
  }

  [Fact]
  public void Map_CheckForeignAddressAfterMappingFromGeneratedChanges_CorrectMapping()
  {
    var changes = Fixtures.Generators.GenerateFakePostiChangesCollection(isLocalAddress: false);
    var mappedDtos = _mapper.Map(changes);
    foreach (var dto in mappedDtos.SkipLast(1))
    {
      dto.Address.Should().BeNull();
      dto.ForeignAddress.Should().NotBeNull();
    }
  }
}
