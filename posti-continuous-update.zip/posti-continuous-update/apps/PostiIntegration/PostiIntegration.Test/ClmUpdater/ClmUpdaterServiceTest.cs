using System;
using System.Net;
using System.Threading.Tasks;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using PostiIntegration.ClmUpdater;
using PostiIntegration.ClmUpdater.Exceptions;
using PostiIntegration.ClmUpdater.Mappers;
using PostiIntegration.Config.Models;
using PostiIntegration.Test.Fixtures;
using RichardSzalay.MockHttp;
using Xunit;

namespace PostiIntegration.Test.ClmUpdater
{
  public class ClmUpdaterServiceTest
  {
    private readonly ILogger<ClmUpdaterService> _logger;

    public ClmUpdaterServiceTest(ILogger<ClmUpdaterService> logger)
    {
      _logger = logger;
    }

    [Fact]
    public async void SendChangesAsync_SendingChanges_NotThrowingException()
    {
      //Arrange
      var settings = new ClmUpdaterSettings()
      {
        Url = "http://domain/api/",
        HostKey = "key"
      };

      string prepareDeliveryPath = "UpdateClm";

      var mockHttp = new MockHttpMessageHandler();
      mockHttp.When($"{settings.Url}{prepareDeliveryPath}").Respond(HttpStatusCode.OK);
      var mapper = new PostiCustomerChangeDtoMapper();
      var postiService = new ClmUpdaterService(mockHttp.ToHttpClient(), settings, _logger, mapper);

      //Act
      Func<Task> act = () => postiService.SendChangesAsync(Generators.GenerateFakePostiChangesCollection());

      //Assert            
      await act.Should().NotThrowAsync();
    }

    [Fact]
    public async void SendChangesAsync_DisableChangeSendFlagTrue_NotThrowingException()
    {
      //Arrange
      var settings = new ClmUpdaterSettings()
      {
        Url = "http://domain/api/",
        HostKey = "key",
        DisableSendingChangesToClmUpdater = true
      };

      var mockHttp = new MockHttpMessageHandler();
      var mapper = new PostiCustomerChangeDtoMapper();
      var postiService = new ClmUpdaterService(mockHttp.ToHttpClient(), settings, _logger, mapper);

      //Act
      Func<Task> act = () => postiService.SendChangesAsync(Generators.GenerateFakePostiChangesCollection());

      //Assert            
      await act.Should().NotThrowAsync();
    }

    [Theory]
    [InlineData(HttpStatusCode.Unauthorized)]
    [InlineData(HttpStatusCode.NotFound)]
    [InlineData(HttpStatusCode.InternalServerError)]
    public async void SendChangesAsync_HttpCallThrowsException_ThrowsHttpRequestException(HttpStatusCode code)
    {
      //Arrange
      var settings = new ClmUpdaterSettings()
      {
        Url = "http://domain/api/",
        HostKey = "key"
      };

      string prepareDeliveryPath = "UpdateClm";

      var mockHttp = new MockHttpMessageHandler();
      mockHttp.When($"{settings.Url}{prepareDeliveryPath}").Respond(code);
      var mapper = new PostiCustomerChangeDtoMapper();
      var postiService = new ClmUpdaterService(mockHttp.ToHttpClient(), settings, _logger, mapper);

      //Act
      Func<Task> act = () => postiService.SendChangesAsync(Generators.GenerateFakePostiChangesCollection());

      //Assert            
      var err = await act.Should().ThrowAsync<ClmUpdaterRequestException>()
          .Where(ex => ex.StatusCode == code);
    }
  }
}
