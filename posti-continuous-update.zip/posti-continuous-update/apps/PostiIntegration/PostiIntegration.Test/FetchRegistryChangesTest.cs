using System;
using System.Collections.Generic;
using System.Net;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using Moq;
using PostiIntegration.ClmUpdater;
using PostiIntegration.CosmosDb;
using PostiIntegration.Models;
using PostiIntegration.Posti;
using PostiIntegration.Posti.Models;
using PostiIntegration.Test.Fixtures;
using Xunit;

namespace PostiIntegration.Test
{
  public class FetchRegistryChangesTest
  {
    private readonly ILogger<FetchRegistryChanges> _logger;
    private readonly Mock<ICosmosDbService> _mockDbService;


    public FetchRegistryChangesTest(ILogger<FetchRegistryChanges> logger)
    {
      _logger = logger;
      _mockDbService = new Mock<ICosmosDbService>();
    }

    [Fact]
    public async void NoChangesFetched_Returns200()
    {
      //Arrange
      var postiService = new Mock<IPostiService>();
      postiService.Setup(p => p.GetChangesAsync()).ReturnsAsync(new NoChangesPostiResult { Status = PostiResultStatus.NoChanges });

      var clmUpdaterService = new Mock<IClmUpdaterService>();
      clmUpdaterService.Setup(p => p.SendChangesAsync(new List<PostiChange>()));

      var expectedPostiError = Generators.GeneratePostiError();

      _mockDbService
      .Setup(dbService => dbService.StorePostiError(It.Is<PostiError>(postiError => postiError == expectedPostiError)))
      .ReturnsAsync(true)
      .Verifiable();

      var fetchRegistry = new FetchRegistryChanges(_logger, postiService.Object, clmUpdaterService.Object, _mockDbService.Object);
      var request = Utils.CreateMockRequestWithBody(null).Object;

      //Act
      await fetchRegistry.Run(null);


      _mockDbService.VerifyNoOtherCalls();
    }

    [Fact]
    public async void ChangesFetched_Returns200()
    {
      //Arrange
      var postiService = new Mock<IPostiService>();

      var examplePostiResult = new OkPostiResult("1234-0987") { Status = PostiResultStatus.Ok };
      var expectedPostiError = Generators.GeneratePostiError();
      examplePostiResult.PostiChanges.AddRange(Generators.GenerateFakePostiChangesCollection());
      examplePostiResult.PostiErrors.Add(expectedPostiError);

      _mockDbService
      .Setup(dbService => dbService.StorePostiError(It.Is<PostiError>(postiError => postiError == expectedPostiError)))
      .ReturnsAsync(true)
      .Verifiable();

      _mockDbService
      .Setup(dbService => dbService.GetPostiDeliverableConfiguration())
      .ReturnsAsync("1234-5678")
      .Verifiable();

      _mockDbService
      .Setup(dbService => dbService.StorePostiDeliverableConfiguration("1234-0987"))
      .ReturnsAsync(true)
      .Verifiable();

      var clmUpdaterService = new Mock<IClmUpdaterService>();
      clmUpdaterService.Setup(p => p.SendChangesAsync(new List<PostiChange>()));

      postiService.Setup(p => p.GetChangesAsync()).ReturnsAsync(examplePostiResult);
      var fetchRegistry = new FetchRegistryChanges(_logger, postiService.Object, clmUpdaterService.Object, _mockDbService.Object);
      var request = Utils.CreateMockRequestWithBody(null).Object;

      //Act
      await fetchRegistry.Run(null);

      //Assert            

      _mockDbService.Verify();
      _mockDbService.VerifyNoOtherCalls();
    }

    [Fact]
    public async void FilePreparationFails_Returns500()
    {
      //Arrange
      var postiService = new Mock<IPostiService>();

      var examplePostiResult = new FilePreparationFailedResult();
      var clmUpdaterService = new Mock<IClmUpdaterService>();

      postiService.Setup(p => p.GetChangesAsync()).ReturnsAsync(examplePostiResult);
      var fetchRegistry = new FetchRegistryChanges(_logger, postiService.Object, clmUpdaterService.Object, _mockDbService.Object);

      //Act
      await fetchRegistry.Run(null);

      //Assert            

      _mockDbService.Verify();
      _mockDbService.VerifyNoOtherCalls();
    }

    [Fact]
    public async void FileFetchingFails_Returns500()
    {
      //Arrange
      var postiService = new Mock<IPostiService>();
      var examplePostiResult = new FileFetchingFailedResult()
      {
        Id = "634417d1f614a5008a39d177",
        Chunks = 1,
        Created = DateTime.Parse("2022-10-28 13:02:09"),
        Lines = 1,
      };

      _mockDbService
      .Setup(dbService => dbService.StoreFileFetchingError(It.Is<FileFetchingFailedResult>(result => result == examplePostiResult)))
      .ReturnsAsync(true)
      .Verifiable();

      var clmUpdaterService = new Mock<IClmUpdaterService>();

      postiService.Setup(p => p.GetChangesAsync()).ReturnsAsync(examplePostiResult);
      var fetchRegistry = new FetchRegistryChanges(_logger, postiService.Object, clmUpdaterService.Object, _mockDbService.Object);

      //Act
      await fetchRegistry.Run(null);

      //Assert      
      //result.StatusCode.Should().Be(StatusCodes.Status502BadGateway);
      //result.Value.Should().BeEquivalentTo(new ErrorResponse(examplePostiResult.Code, examplePostiResult.Message));
      _mockDbService.Verify();
      _mockDbService.VerifyNoOtherCalls();
    }

    [Fact]
    public async void UnexpectedException_Returns500()
    {
      //Arrange
      var postiService = new Mock<IPostiService>();
      postiService.Setup(p => p.GetChangesAsync()).Throws(new System.Exception());
      var clmUpdaterService = new Mock<IClmUpdaterService>();
      clmUpdaterService.Setup(p => p.SendChangesAsync(new List<PostiChange>()));

      var fetchRegistry = new FetchRegistryChanges(_logger, postiService.Object, clmUpdaterService.Object, _mockDbService.Object);


      //Act
      await fetchRegistry.Run(null);

      //Assert            
      //response.Should().BeAssignableTo<StatusCodeResult>();
      //response.As<StatusCodeResult>().StatusCode.Should().Be(StatusCodes.Status500InternalServerError);
    }

    [Fact]
    public async void CosmosException_Returns500()
    {
      //Arrange
      var examplePostiResult = new OkPostiResult("1") { Status = PostiResultStatus.Ok };
      var expectedPostiError = Generators.GeneratePostiError();
      examplePostiResult.PostiChanges.AddRange(Generators.GenerateFakePostiChangesCollection());
      examplePostiResult.PostiErrors.Add(expectedPostiError);

      var postiService = new Mock<IPostiService>();
      postiService.Setup(p => p.GetChangesAsync()).ReturnsAsync(examplePostiResult);
      var clmUpdaterService = new Mock<IClmUpdaterService>();
      clmUpdaterService.Setup(p => p.SendChangesAsync(new List<PostiChange>()));


      _mockDbService
      .Setup(dbService => dbService.StorePostiError(It.Is<PostiError>(postiError => postiError == expectedPostiError)))
      .Throws(new CosmosException("Oops", HttpStatusCode.BadRequest, 440, "id", 0.1))
      .Verifiable();

      _mockDbService
      .Setup(dbService => dbService.GetPostiDeliverableConfiguration())
      .ReturnsAsync("1234-5678")
      .Verifiable();

      _mockDbService
      .Setup(dbService => dbService.StorePostiDeliverableConfiguration("1"))
      .ReturnsAsync(true)
      .Verifiable();

      var fetchRegistry = new FetchRegistryChanges(_logger, postiService.Object, clmUpdaterService.Object, _mockDbService.Object);


      //Act
      await fetchRegistry.Run(null);

      //Assert            
      //response.Should().BeAssignableTo<ObjectResult>();
      //response.As<ObjectResult>().StatusCode.Should().Be(StatusCodes.Status500InternalServerError);
      //response.As<ObjectResult>().Value.Should().BeEquivalentTo(new ErrorResponse("storing_file_fetch_errors_fails", "An error occurred while storing File Fetching Errors in database"));

      _mockDbService.Verify();
      _mockDbService.VerifyNoOtherCalls();
    }
  }
}
