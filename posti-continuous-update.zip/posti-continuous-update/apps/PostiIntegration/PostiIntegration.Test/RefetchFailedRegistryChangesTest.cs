using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using Moq;
using PostiIntegration.ClmUpdater;
using PostiIntegration.Config.Models;
using PostiIntegration.CosmosDb;
using PostiIntegration.CosmosDb.Models;
using PostiIntegration.Models;
using PostiIntegration.Posti;
using PostiIntegration.Posti.Models;
using PostiIntegration.Test.Fixtures;
using Xunit;

namespace PostiIntegration.Test
{
  public class RefetchFailedRegistryChangesTest
  {
    private readonly ILogger<RefetchFailedRegistryChanges> _logger;
    private readonly Mock<ICosmosDbService> _mockDbService;
    private readonly FunctionSettings _functionSettings;


    public RefetchFailedRegistryChangesTest(ILogger<RefetchFailedRegistryChanges> logger)
    {
      _logger = logger;
      _mockDbService = new Mock<ICosmosDbService>();
      _functionSettings = new FunctionSettings()
      {
        DisableFileRefetch = false,
      };
    }

    [Fact]
    public async void ChangesFetched_Returns200()
    {
      //Arrange
      var postiService = new Mock<IPostiService>();
      var fileIds = new List<string>() { "634417d1f614a5008a39d177", "634417d1f614a5008a39d178" };
      var results = new List<PostiResult>();
      fileIds.ForEach(fileId => results.Add(OkPostiResultPrepare(fileId)));
      Arrange(fileIds, results, postiService);

      var clmUpdaterService = new Mock<IClmUpdaterService>();
      clmUpdaterService.Setup(p => p.SendChangesAsync(new List<PostiChange>()));


      var refetchFiles = new RefetchFailedRegistryChanges(_logger, postiService.Object, clmUpdaterService.Object, _mockDbService.Object, _functionSettings);
      var request = Utils.CreateMockRequestWithBody(null).Object;

      //Act
      await refetchFiles.Run(null);

      //Assert            

      _mockDbService.Verify();
      _mockDbService.VerifyNoOtherCalls();
    }

    private static OkPostiResult OkPostiResultPrepare(string fileId)
    {
      var examplePostiResult = new OkPostiResult(fileId) { Status = PostiResultStatus.Ok };
      var expectedPostiError = Generators.GeneratePostiError();
      examplePostiResult.PostiChanges.AddRange(Generators.GenerateFakePostiChangesCollection());
      examplePostiResult.PostiErrors.Add(expectedPostiError);

      return examplePostiResult;
    }



    [Fact]
    public async void FileFetchingFails_Returns500()
    {
      //Arrange
      var postiService = new Mock<IPostiService>();
      var fileIds = new List<string>() { "634417d1f614a5008a39d177", "634417d1f614a5008a39d178" };

      var examplePostiResult = new FileFetchingFailedResult()
      {
        Id = fileIds[0],
        Chunks = 1,
        Created = DateTime.Parse("2022-10-28 13:02:09"),
        Lines = 1,
      };
      var examplePostiResult2 = new FileFetchingFailedResult()
      {
        Id = fileIds[1],
        Chunks = 1,
        Created = DateTime.Parse("2022-10-28 13:02:09"),
        Lines = 1,
      };
      var expectedResponse = new List<ErrorResponse>()
      {
        new ErrorResponse(examplePostiResult.Code, examplePostiResult.Message),
        new ErrorResponse(examplePostiResult2.Code, examplePostiResult2.Message)
      };
      Arrange(fileIds, new List<PostiResult>() { examplePostiResult, examplePostiResult2 }, postiService);

      var clmUpdaterService = new Mock<IClmUpdaterService>();

      postiService.Setup(p => p.GetChangesAsync()).ReturnsAsync(examplePostiResult);
      var fetchRegistry = new RefetchFailedRegistryChanges(_logger, postiService.Object, clmUpdaterService.Object, _mockDbService.Object, _functionSettings);


      //Act
      await fetchRegistry.Run(null);

      //Assert            
      //response.Should().BeAssignableTo<ObjectResult>();
      //var result = response as ObjectResult;
      //result.StatusCode.Should().Be(StatusCodes.Status500InternalServerError);
      //result.Value.Should().BeEquivalentTo(expectedResponse);
      _mockDbService.Verify();
      _mockDbService.VerifyNoOtherCalls();
    }

    [Fact]
    public async void FileFetchingFailsAndBatchMatching_Returns500()
    {
      //Arrange
      var postiService = new Mock<IPostiService>();
      var fileIds = new List<string>() { "634417d1f614a5008a39d177", "634417d1f614a5008a39d178" };

      var examplePostiResult = new FileFetchingFailedResult()
      {
        Id = fileIds[0],
        Chunks = 1,
        Created = DateTime.Parse("2022-10-28 13:02:09"),
        Lines = 1,
      };
      var examplePostiResult2 = new BatchMatchingErrorResult();
      var expectedResponse = new List<ErrorResponse>()
      {
        new ErrorResponse(examplePostiResult.Code, examplePostiResult.Message),
        new ErrorResponse(examplePostiResult2.Code, examplePostiResult2.Message)
      };
      Arrange(fileIds, new List<PostiResult>() { examplePostiResult, examplePostiResult2 }, postiService);

      var clmUpdaterService = new Mock<IClmUpdaterService>();

      postiService.Setup(p => p.GetChangesAsync()).ReturnsAsync(examplePostiResult);
      var fetchRegistry = new RefetchFailedRegistryChanges(_logger, postiService.Object, clmUpdaterService.Object, _mockDbService.Object, _functionSettings);


      //Act
      await fetchRegistry.Run(null);

      //Assert            

      _mockDbService.Verify();
      _mockDbService.VerifyNoOtherCalls();
    }

    [Fact]
    public async void UnexpectedException_Returns500()
    {
      //Arrange
      var postiService = new Mock<IPostiService>();
      (var dto, var document) = Generators.GetFileResponseDtoAndFailedFetchDocument(id: "fileId");
      postiService.Setup(p => p.FetchFile(dto)).Throws(new System.Exception());
      var clmUpdaterService = new Mock<IClmUpdaterService>();
      clmUpdaterService.Setup(p => p.SendChangesAsync(new List<PostiChange>()));

      var fetchRegistry = new RefetchFailedRegistryChanges(_logger, postiService.Object, clmUpdaterService.Object, _mockDbService.Object, _functionSettings);


      //Act
      await fetchRegistry.Run(null);

      //Assert            
      //response.Should().BeAssignableTo<StatusCodeResult>();
      //response.As<StatusCodeResult>().StatusCode.Should().Be(StatusCodes.Status500InternalServerError);
    }

    [Fact]
    public async void CosmosException_Returns500()
    {
      //Arrange
      var postiService = new Mock<IPostiService>();
      var fileIds = new List<string>() { "634417d1f614a5008a39d177", "634417d1f614a5008a39d178" };
      var results = new List<PostiResult>();
      fileIds.ForEach(fileId => results.Add(OkPostiResultPrepare(fileId)));
      ArrangeWithCosmosDbError(fileIds, results, postiService);
      var clmUpdaterService = new Mock<IClmUpdaterService>();
      clmUpdaterService.Setup(p => p.SendChangesAsync(new List<PostiChange>()));


      var refetchFiles = new RefetchFailedRegistryChanges(_logger, postiService.Object, clmUpdaterService.Object, _mockDbService.Object, _functionSettings);

      //Act
      await refetchFiles.Run(null);

      //Assert            
      //response.Should().BeAssignableTo<ObjectResult>();
      //response.As<ObjectResult>().StatusCode.Should().Be(StatusCodes.Status500InternalServerError);
      //response.As<ObjectResult>().Value.Should().BeEquivalentTo(new ErrorResponse("cosmos_error", "There was a problem with CosmosDb"));
      _mockDbService.Verify();
      _mockDbService.VerifyNoOtherCalls();
    }

    private void Arrange(List<string> fileIds, List<PostiResult> examplePostiResults, Mock<IPostiService> postiService)
    {
      var expectedFileResponse = new List<FileFetchingErrorDocument>();
      foreach (var (fileId, examplePostiResult) in fileIds.Zip(examplePostiResults))
      {

        (var dto, var document) = Generators.GetFileResponseDtoAndFailedFetchDocument(id: fileId);
        expectedFileResponse.Add(document);

        if (examplePostiResult as OkPostiResult != null)
        {
          _mockDbService
        .Setup(dbService => dbService.DeleteFileFetchingError(document.Id))
          .ReturnsAsync(true)
          .Verifiable();

          _mockDbService
        .Setup(dbService => dbService.StorePostiError(It.IsAny<PostiError>()))
          .ReturnsAsync(true)
          .Verifiable();
        }

        postiService.Setup(p => p.FetchFile(dto)).ReturnsAsync(examplePostiResult);
      }
      _mockDbService
        .Setup(dbService => dbService.GetAllFileFetchingErrors())
          .ReturnsAsync(expectedFileResponse)
          .Verifiable();

    }

    private void ArrangeWithCosmosDbError(List<string> fileIds, List<PostiResult> examplePostiResults, Mock<IPostiService> postiService)
    {
      var expectedFileResponse = new List<FileFetchingErrorDocument>();
      foreach (var fileId in fileIds)
      {
        (var dto, var document) = Generators.GetFileResponseDtoAndFailedFetchDocument(id: fileId);
        expectedFileResponse.Add(document);
      }
      _mockDbService
        .Setup(dbService => dbService.GetAllFileFetchingErrors())
          .Throws(new CosmosException("Oops", HttpStatusCode.BadRequest, 440, "id", 0.1))
          .Verifiable();

    }
  }
}
