﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using FluentAssertions;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using Moq;
using PostiIntegration.Config.Models;
using PostiIntegration.CosmosDb;
using PostiIntegration.CosmosDb.Models;
using PostiIntegration.Posti.Models;
using PostiIntegration.Test.Fixtures;
using Xunit;

namespace PostiIntegration.Test.CosmosDb;
public class CosmosDbServiceTest
{
  private readonly CosmosDbSettings _mockSettings;
  private readonly Mock<CosmosClient> _mockCosmosClient;
  private readonly Mock<Container> _mockPostiErrorsContainer;
  private readonly Mock<Container> _mockFileFetchingErrorsContainer;

  private readonly Mock<ItemResponse<PostiErrorDocument>> _mockStorePostiErrorDocumentResponse;
  private readonly Mock<ItemResponse<FileFetchingErrorDocument>> _mockStoreFileFetchingErrorDocumentResponse;
  private readonly Mock<ICosmosLinqQuery> _mockCosmosLinqQueryWrapper;

  private readonly CosmosDbService _testService;
  private readonly Mock<ItemResponse<PostiErrorDocument>> _mockDeletePostiErrorResponse;
  private readonly Mock<ItemResponse<FileFetchingErrorDocument>> _mockDeleteFileFetchingErrorResponse;

  public CosmosDbServiceTest(ILogger<CosmosDbService> logger)
  {

    _mockSettings = new CosmosDbSettings()
    {
      Name = "FakeDb",
      ConnectionString = "ConnectToDb",
      PostiErrorsContainer = "PostiErrors",
      FileFetchingErrorsContainer = "FileFetchingErrors",
      DisableStorePostiErrors = false
    };
    _mockCosmosClient = new Mock<CosmosClient>();
    // Setup URI return for telemetry calls
    _mockCosmosClient
      .Setup(c => c.Endpoint)
      .Returns(new Uri("https://some-cosmos.db"));
    // Setup fetching of containers
    _mockPostiErrorsContainer = new Mock<Container>();
    _mockCosmosClient
        .Setup(c => c.GetContainer(_mockSettings.Name, _mockSettings.PostiErrorsContainer))
        .Returns(_mockPostiErrorsContainer.Object)
        .Verifiable();

    _mockFileFetchingErrorsContainer = new Mock<Container>();
    _mockCosmosClient
        .Setup(c => c.GetContainer(_mockSettings.Name, _mockSettings.FileFetchingErrorsContainer))
        .Returns(_mockFileFetchingErrorsContainer.Object)
        .Verifiable();

    _mockStorePostiErrorDocumentResponse = new Mock<ItemResponse<PostiErrorDocument>>();
    _mockStoreFileFetchingErrorDocumentResponse = new Mock<ItemResponse<FileFetchingErrorDocument>>();
    _mockDeletePostiErrorResponse = new Mock<ItemResponse<PostiErrorDocument>>();
    _mockDeleteFileFetchingErrorResponse = new Mock<ItemResponse<FileFetchingErrorDocument>>();
    _mockCosmosLinqQueryWrapper = new Mock<ICosmosLinqQuery>();
    _testService = new CosmosDbService(
      logger,
      _mockSettings,
      _mockCosmosClient.Object,
      new TelemetryConfiguration(),
      _mockCosmosLinqQueryWrapper.Object);
  }

  private void SetupFetchingAndDeletingPostiErrors(IEnumerable<PostiErrorDocument> postiErrorsResponse)
  {
    // Configure fetching postiErrors
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetQueryText(It.IsAny<IQueryable<PostiErrorDocument>>()))
      .Returns("Some query");
    var mockFeedIteratorPostiErrors = new Mock<FeedIterator<PostiErrorDocument>>();
    mockFeedIteratorPostiErrors
      .SetupSequence(fi => fi.HasMoreResults)
      .Returns(true)
      .Returns(false);
    var mockFeedPostiErrorsResponse = new Mock<FeedResponse<PostiErrorDocument>>();
    mockFeedPostiErrorsResponse
        .Setup(fr => fr.GetEnumerator()).Returns(postiErrorsResponse.GetEnumerator());
    mockFeedIteratorPostiErrors
        .SetupSequence(fi => fi.ReadNextAsync(default))
        .ReturnsAsync(mockFeedPostiErrorsResponse.Object);
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetFeedIterator(It.IsAny<IQueryable<PostiErrorDocument>>()))
      .Returns(mockFeedIteratorPostiErrors.Object);
    _mockPostiErrorsContainer
      .Setup(c => c.GetItemLinqQueryable<PostiErrorDocument>(false, null, null, null))
      .Returns(new EnumerableQuery<PostiErrorDocument>(new List<PostiErrorDocument>()))
      .Verifiable();


    // Configure deleting errors
    foreach (var error in postiErrorsResponse)
    {
      _mockPostiErrorsContainer
        .Setup(c => c.DeleteItemAsync<PostiErrorDocument>(
          It.Is<string>(id => id == error.Id),
          It.Is<PartitionKey>(key => key == new PartitionKey(error.Operation.ToString())),
          It.IsAny<ItemRequestOptions>(),
          default))
        .ReturnsAsync(_mockDeletePostiErrorResponse.Object)
        .Verifiable();
    }
  }

  [Fact]
  public async void DeletePostiErrors_OperationSuccessfulNoParams_ReturnsTrue()
  {
    //Arrange
    var listOfDocuments = PreparePostiErrorDocumentCollection();
    SetupFetchingAndDeletingPostiErrors(listOfDocuments);

    //Act
    var result = await _testService.DeletePostiErrors();

    //Assert
    result.Should().BeTrue();

    _mockPostiErrorsContainer.Verify();
    _mockPostiErrorsContainer.VerifyNoOtherCalls();
  }

  [Theory]
  [InlineData(26, 3)]
  [InlineData(28, 2)]
  [InlineData(29, 1)]
  [InlineData(30, 0)]
  [InlineData(31, 0)]
  public async void DeletePostiErrors_OperationSuccessfulDateTimeParam_ReturnsTrue(int day, int collectionCount)
  {
    //Arrange
    var listOfDocuments = PreparePostiErrorDocumentCollection().Skip(collectionCount).ToList();
    SetupFetchingAndDeletingPostiErrors(listOfDocuments);
    var dateParam = new DateTime(2022, 8, day, 7, 30, 45, DateTimeKind.Utc);

    //Act
    var result = await _testService.DeletePostiErrors(dateParam);

    //Assert
    result.Should().BeTrue();

    _mockPostiErrorsContainer.Verify();
    _mockPostiErrorsContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void StorePostiError_OperationSuccessfullyStored_ReturnsTrue()
  {
    // ASSIGN
    var postiError = Generators.GeneratePostiError();
    var expectedDocument = new PostiErrorDocument()
    {
      Id = $"{postiError.Timestamp}::{postiError.CustomerId}::{postiError.Operation}",
      Timestamp = postiError.Timestamp,
      Operation = postiError.Operation,
      CustomerId = postiError.CustomerId,
      Ssn = postiError.Ssn,
      LastName = postiError.LastName,
      FirstName = postiError.FirstName,
      PostalCode = postiError.PostalCode,
      City = postiError.City,
      Address = postiError.Address,
      Telephone = postiError.Telephone,
      Email = postiError.Email,
      Extra = postiError.Extra,
      FetchErrorType = postiError.FetchErrorType,
      ErrorMessage = postiError.ErrorMessage
    };
    var expectedPartitionKey = new PartitionKey(postiError.Operation);
    _mockPostiErrorsContainer
      .Setup(container => container.CreateItemAsync(
        It.Is<PostiErrorDocument>(doc => doc == expectedDocument),
        It.Is<PartitionKey>(key => key == expectedPartitionKey),
        It.IsAny<ItemRequestOptions>(),
        default))
      .ReturnsAsync(_mockStorePostiErrorDocumentResponse.Object)
      .Verifiable();

    // ACT
    var success = await _testService.StorePostiError(postiError);

    // ASSERT
    success.Should().BeTrue();
    _mockPostiErrorsContainer.Verify();
    _mockPostiErrorsContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void StorePostiError_CosmosExceptionThrown_ReturnsFalse()
  {
    // ASSIGN
    var postiError = Generators.GeneratePostiError();
    var expectedDocument = new PostiErrorDocument()
    {
      Id = $"{postiError.Timestamp}::{postiError.CustomerId}::{postiError.Operation}",
      Timestamp = postiError.Timestamp,
      Operation = postiError.Operation,
      CustomerId = postiError.CustomerId,
      Ssn = postiError.Ssn,
      LastName = postiError.LastName,
      FirstName = postiError.FirstName,
      PostalCode = postiError.PostalCode,
      City = postiError.City,
      Address = postiError.Address,
      Telephone = postiError.Telephone,
      Email = postiError.Email,
      Extra = postiError.Extra,
      FetchErrorType = postiError.FetchErrorType,
      ErrorMessage = postiError.ErrorMessage
    };
    var expectedPartitionKey = new PartitionKey(postiError.Operation);
    _mockPostiErrorsContainer
      .Setup(container => container.CreateItemAsync(
        It.Is<PostiErrorDocument>(doc => doc == expectedDocument),
        It.Is<PartitionKey>(key => key == expectedPartitionKey),
        It.IsAny<ItemRequestOptions>(),
        default))
      .ThrowsAsync(new CosmosException("Oops", HttpStatusCode.BadRequest, 440, "id", 0.1))
      .Verifiable();

    // ACT
    var success = await _testService.StorePostiError(postiError);

    // ASSERT
    success.Should().BeFalse();
    _mockPostiErrorsContainer.Verify();
    _mockPostiErrorsContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void StoreFileFetchingError_OperationSuccessfullyStored_ReturnsTrue()
  {
    // ASSIGN
    var examplePostiResult = new FileFetchingFailedResult()
    {
      Id = "634417d1f614a5008a39d177",
      Chunks = 1,
      Created = DateTime.Parse("2022-10-28 13:02:09"),
    };
    var expectedDocument = FileFetchingErrorDocument.CreateFromResult(examplePostiResult);
    var expectedPartitionKey = new PartitionKey(expectedDocument.Id);
    _mockFileFetchingErrorsContainer
      .Setup(container => container.CreateItemAsync(
        It.Is<FileFetchingErrorDocument>(doc => doc == expectedDocument),
        It.Is<PartitionKey>(key => key == expectedPartitionKey),
        It.IsAny<ItemRequestOptions>(),
        default))
      .ReturnsAsync(_mockStoreFileFetchingErrorDocumentResponse.Object)
      .Verifiable();

    // ACT
    var success = await _testService.StoreFileFetchingError(examplePostiResult);

    // ASSERT
    success.Should().BeTrue();
    _mockPostiErrorsContainer.Verify();
    _mockPostiErrorsContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void StoreFileFetchingError_CosmosExceptionThrown_ReturnsFalse()
  {
    // ASSIGN
    var examplePostiResult = new FileFetchingFailedResult()
    {
      Id = "634417d1f614a5008a39d177",
      Chunks = 1,
      Created = DateTime.Parse("2022-10-28 13:02:09"),
      Lines = 1,
    };
    var expectedDocument = FileFetchingErrorDocument.CreateFromResult(examplePostiResult);
    var expectedPartitionKey = new PartitionKey(expectedDocument.Id);
    _mockFileFetchingErrorsContainer
      .Setup(container => container.CreateItemAsync(
        It.Is<FileFetchingErrorDocument>(doc => doc == expectedDocument),
        It.Is<PartitionKey>(key => key == expectedPartitionKey),
        It.IsAny<ItemRequestOptions>(),
        default))
      .ThrowsAsync(new CosmosException("Oops", HttpStatusCode.BadRequest, 440, "id", 0.1))
      .Verifiable();

    // ACT
    var success = await _testService.StoreFileFetchingError(examplePostiResult);

    // ASSERT
    success.Should().BeFalse();
    _mockFileFetchingErrorsContainer.Verify();
    _mockFileFetchingErrorsContainer.VerifyNoOtherCalls();
  }


  [Fact]
  public async void DeleteFileFetchingError_Success_ReturnsTrue()
  {
    // ASSIGN
    (_, var expectedDocument) = Generators.GetFileResponseDtoAndFailedFetchDocument("id1");
    var expectedPartitionKey = new PartitionKey(expectedDocument.Id);
    _mockFileFetchingErrorsContainer
        .Setup(c => c.DeleteItemAsync<FileFetchingErrorDocument>(
          It.Is<string>(id => id == expectedDocument.Id),
          It.Is<PartitionKey>(key => key == new PartitionKey(expectedDocument.Id)),
          It.IsAny<ItemRequestOptions>(),
          default))
        .ReturnsAsync(_mockDeleteFileFetchingErrorResponse.Object)
        .Verifiable();

    // ACT
    var success = await _testService.DeleteFileFetchingError(expectedDocument.Id);

    // ASSERT
    success.Should().BeTrue();
    _mockFileFetchingErrorsContainer.Verify();
    _mockFileFetchingErrorsContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void DeleteFileFetchingError_ThrowException_ReturnsFalse()
  {
    // ASSIGN
    (_, var expectedDocument) = Generators.GetFileResponseDtoAndFailedFetchDocument("id1");
    var expectedPartitionKey = new PartitionKey(expectedDocument.Id);
    _mockFileFetchingErrorsContainer
        .Setup(c => c.DeleteItemAsync<FileFetchingErrorDocument>(
          It.Is<string>(id => id == expectedDocument.Id),
          It.Is<PartitionKey>(key => key == new PartitionKey(expectedDocument.Id)),
          It.IsAny<ItemRequestOptions>(),
          default))
        .ThrowsAsync(new CosmosException("Oops!", HttpStatusCode.InternalServerError, 500, "id", 1.0))
        .Verifiable();

    // ACT
    var success = await _testService.DeleteFileFetchingError(expectedDocument.Id);

    // ASSERT
    success.Should().BeFalse();
    _mockFileFetchingErrorsContainer.Verify();
    _mockFileFetchingErrorsContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void GetAllFileFetchingErrors_Success_ReturnsCollection()
  {
    // ASSIGN
    (_, var doc1) = Generators.GetFileResponseDtoAndFailedFetchDocument("id1");
    (_, var doc2) = Generators.GetFileResponseDtoAndFailedFetchDocument("id2");
    var expectedReturn = new List<FileFetchingErrorDocument>() { doc1, doc2 };
    SetupFetchingFileFetchingErrors(expectedReturn);

    // ACT
    var fetchingResponse = await _testService.GetAllFileFetchingErrors();

    // ASSERT
    fetchingResponse.Should().BeEquivalentTo(expectedReturn);
    _mockFileFetchingErrorsContainer.Verify();
    _mockFileFetchingErrorsContainer.VerifyNoOtherCalls();
  }

  private void SetupFetchingFileFetchingErrors(IEnumerable<FileFetchingErrorDocument> fileFetchingErrorsDocuments)
  {
    // Configure fetching postiErrors
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetQueryText(It.IsAny<IQueryable<FileFetchingErrorDocument>>()))
      .Returns("Some query");
    var mockFeedIteratorFileFetchingErrors = new Mock<FeedIterator<FileFetchingErrorDocument>>();
    mockFeedIteratorFileFetchingErrors
      .SetupSequence(fi => fi.HasMoreResults)
      .Returns(true)
      .Returns(false);
    var mockFeedFleFetchingErrorsResponse = new Mock<FeedResponse<FileFetchingErrorDocument>>();
    mockFeedFleFetchingErrorsResponse
        .Setup(fr => fr.GetEnumerator()).Returns(fileFetchingErrorsDocuments.GetEnumerator());
    mockFeedIteratorFileFetchingErrors
        .SetupSequence(fi => fi.ReadNextAsync(default))
        .ReturnsAsync(mockFeedFleFetchingErrorsResponse.Object);
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetFeedIterator(It.IsAny<IQueryable<FileFetchingErrorDocument>>()))
      .Returns(mockFeedIteratorFileFetchingErrors.Object);
    _mockFileFetchingErrorsContainer
      .Setup(c => c.GetItemLinqQueryable<FileFetchingErrorDocument>(false, null, null, null))
      .Returns(new EnumerableQuery<FileFetchingErrorDocument>(new List<FileFetchingErrorDocument>()))
      .Verifiable();
  }

  private List<PostiErrorDocument> PreparePostiErrorDocumentCollection()
  {
    var august30 = PostiErrorDocument.CreateFromPostiError(Generators.GeneratePostiError(timestamp: 1661842010));
    var august29 = PostiErrorDocument.CreateFromPostiError(Generators.GeneratePostiError(timestamp: 1661755610));
    var august28 = PostiErrorDocument.CreateFromPostiError(Generators.GeneratePostiError(timestamp: 1661669210));

    var listOfDocuments = new List<PostiErrorDocument>() { august28, august29, august30 }.OrderByDescending(x => x.Timestamp);

    return listOfDocuments.ToList();
  }
}
