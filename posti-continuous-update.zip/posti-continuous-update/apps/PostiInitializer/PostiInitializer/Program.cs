using Microsoft.Extensions.Azure;
using PostiInitializer.Config;
using PostiInitializer.Posti;
using PostiIntegration.Config.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.RegisterPostiClients(builder.Configuration);
builder.Services.Configure<PostiApiSettings>((builder.Configuration.GetSection("PostiApiSettings")));
builder.Services.Configure<PostiAuthSettings>((builder.Configuration.GetSection("PostiAuthSettings")));
builder.Services.Configure<ClmUpdaterSettings>((builder.Configuration.GetSection("ClmUpdaterSettings")));
builder.Services.Configure<EventBatcherSettings>((builder.Configuration.GetSection("EventBatcherSettings")));

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddAzureClients(clientBuilder =>
{
  clientBuilder.AddBlobServiceClient(builder.Configuration["Connection:blob"], preferMsi: true);
});

var app = builder.Build();


// Configure the HTTP request pipeline.
//if (app.Environment.IsDevelopment())
//
  app.UseSwagger();
  app.UseSwaggerUI();
//}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
