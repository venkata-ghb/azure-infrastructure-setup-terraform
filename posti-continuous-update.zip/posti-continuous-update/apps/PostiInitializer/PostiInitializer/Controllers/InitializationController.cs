using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using PostiInitializer.Posti;
using PostiInitializer.Posti.Models;

namespace PostiInitializer.Controllers;
[ApiController]
[Route("[controller]")]
public class InitializationController : ControllerBase
{

  private readonly IPostiService _service;

  public InitializationController(ILogger<InitializationController> logger, IPostiService service)
  {
    _service = service;
  }
  [HttpPost("/CreateRegister")]
  public async Task<IActionResult> CreateRegister()
  {
    var registryId = await _service.CreateRegister();
    if(registryId == null)
    {
      return new StatusCodeResult(StatusCodes.Status500InternalServerError);
    }

    return new OkObjectResult(new CreateRegisterResponse
    {
      RegistryId = registryId,
      OperationStatus = "OK"
    });
  }
  [HttpPost("/PrepareFiles")]
  public async Task<IActionResult> PrepareFiles()
  {
    await _service.MapAndSaveMigrationFileInPostiFormatAsync();

    return new OkResult();
  }

  [HttpPost("/SendFiles")]
  public async Task<IActionResult> SendFiles()
  {
    var result = await _service.SendFilesToPosti();
    if (result.Status == Posti.Models.SendChangesStatus.Success)
      return new OkResult();
    return new StatusCodeResult(StatusCodes.Status500InternalServerError);
  }

  [HttpPost("/CommitFiles")]
  public async Task<IActionResult> CommitFiles()
  {
    var result = await _service.CommitFilesToPosti();
    if (result.Status == Posti.Models.SendChangesStatus.Success)
      return new OkResult();
    return new StatusCodeResult(StatusCodes.Status500InternalServerError);
  }

  [HttpPost("/PrepareChanges_DoNotUse")]
  public async Task<IActionResult> PrepareChanges()
  {
    var result = await _service.FetchChangesAndSaveThemInStorageAccount();
    if (result.Status == Posti.Models.PostiResultStatus.Ok)
      return new OkObjectResult("Not Ready");

    return new ObjectResult(new { result.Status, result.FileFetchStatuses }) { StatusCode = StatusCodes.Status500InternalServerError };
  }

  [HttpPost("/FetchChanges")]
  public async Task<IActionResult> FetchChanges()
  {
    var result = await _service.ListDeliverablesAndSaveThemInStorageAccount();
    if (result.Status == Posti.Models.PostiResultStatus.Ok)
      return new OkObjectResult("Not Used");

    return new ObjectResult(new { result.Status, result.FileFetchStatuses }) { StatusCode = StatusCodes.Status500InternalServerError };
  }

  [HttpPost("/ManualProcessing/{fileId}")]
  public async Task<IActionResult> ManualChanges(string fileId)
  {
    var result = await _service.ManualCsvProcessing(fileId);
    if (result.Status == Posti.Models.PostiResultStatus.Ok)
      return new OkObjectResult(result);

    return new ObjectResult(new { result.Status, result.FileFetchStatuses }) { StatusCode = StatusCodes.Status500InternalServerError };
  }

  [HttpPost("/UpdateClm")]
  public async Task<IActionResult> UpdateClm()
  {
    var result = await _service.SendToCLM();
    if (result.Status == Posti.Models.PostiResultStatus.Ok)
    {
      return new ObjectResult(new { result.Status, result.FileFetchStatuses }) { StatusCode = StatusCodes.Status500InternalServerError };
    }
    return new OkObjectResult(result);
  }

  [HttpPost("/UpdateClm/{fileName}/do-not-use")]
  public async Task<IActionResult> UpdateClmControlled(string fileName)
  {
    var result = await _service.SendToCLMControlled(fileName);
    Console.WriteLine(result.Status);
    if (result.Status == Posti.Models.PostiResultStatus.Ok)
    {
      return new OkObjectResult(result);
      
    }
    return new ObjectResult(new { result.Status, result.FileFetchStatuses }) { StatusCode = StatusCodes.Status500InternalServerError };
  }

  [HttpPost("/Duplicates")]
  public async Task<List<string>> Duplicates()
  {
    var result = await _service.Duplicates();
    Console.WriteLine(result);
    
    return result;
  }

}
