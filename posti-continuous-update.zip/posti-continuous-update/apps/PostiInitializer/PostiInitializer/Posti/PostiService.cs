﻿using System.Text;
using System.Threading.Channels;
using Microsoft.Extensions.Options;
using Microsoft.VisualBasic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PostiInitializer.Config;
using PostiInitializer.Posti.Csv;
using PostiInitializer.Posti.Mappers;
using PostiInitializer.Posti.Models;

namespace PostiInitializer.Posti;

public interface IPostiService
{
  Task<string?> CreateRegister();
  Task MapAndSaveMigrationFileInPostiFormatAsync();
  Task<ISendChangesResult> SendFilesToPosti();
  Task<ISendChangesResult> CommitFilesToPosti();
  Task<PostiResult> FetchChangesAndSaveThemInStorageAccount();
  Task<PostiResult> SendToCLM();
  Task<PostiResult> SendToCLMControlled(string fileName);
  Task<PostiResult> ManualCsvProcessing(string fileName);
  Task<List<string>> Duplicates();
  Task<PostiResult> ListDeliverablesAndSaveThemInStorageAccount();
}

public class PostiService : IPostiService
{
  private readonly ICsvService _csvService;
  private readonly HttpClient _httpClient;
  private readonly PostiApiSettings _settings;
  private readonly ILogger<PostiService> _logger;
  private readonly IStorageAccountService _storageAccountService;
  private readonly IPostiChangesMapper _postiChangeMapper;
  private readonly IPostiCustomerChangeDtoMapper _postiCustomerChangeMapper;
  private readonly IClmUpdaterService _clmUpdaterService;
  private readonly IEventBatcherService _eventBatcherService;
  private const string PostiJsonFileDeliveryType = "RESULT_JSON_FILE_CHANGES";

  public PostiService(ICsvService csvService, HttpClient httpClient, IOptions<PostiApiSettings> settings, ILogger<PostiService> logger, IStorageAccountService storageAccountService, IPostiChangesMapper postiChangeMapper, IPostiCustomerChangeDtoMapper postiCustomerChangeMapper, IClmUpdaterService clmUpdaterService, IEventBatcherService eventBatcherService)
  {
    _csvService = csvService;
    _httpClient = httpClient;

    _settings = settings.Value;
    _logger = logger;
    _httpClient.BaseAddress = new Uri(_settings.BaseUrl);
    _httpClient.Timeout = TimeSpan.FromMinutes(5);
    _storageAccountService = storageAccountService;
    _postiChangeMapper = postiChangeMapper;
    _postiCustomerChangeMapper = postiCustomerChangeMapper;
    _clmUpdaterService = clmUpdaterService;
    _eventBatcherService = eventBatcherService;
  }

  public async Task<string?> CreateRegister()
  {
    string createRegistryRoute = $"register?format=OTS";
    var response = await _httpClient.PostAsync(createRegistryRoute, null);
    var responseContentStream = await response.Content.ReadAsStringAsync();
    if (response.IsSuccessStatusCode == false)
    {
      //Log failed file preparation and return
      _logger.LogError($"Registry creation failed with error {responseContentStream}. Try manually.");
      return null;
    }
    var registryDetails = JsonConvert.DeserializeObject<CreateRegisterDto>(responseContentStream);
    if(registryDetails != null && !string.IsNullOrEmpty(registryDetails.OperationStatus) && registryDetails.OperationStatus.Equals("OK", StringComparison.OrdinalIgnoreCase))
    {
      _logger.LogInformation($"Registry created. {registryDetails.RegistryId}");
      return registryDetails.RegistryId;
    }
    
    return null;
  }

  public async Task<List<string>> Duplicates()
  {
    var fileNames = await _storageAccountService.GetFileNameCollection("migration_", "dummy");
    var lst = new List<string>();
    /*var data0 = await _storageAccountService.GetFileAsync("migration_1_rd236l0003.csv", null);
    var data1 = await _storageAccountService.GetFileAsync("migration_2_rd236l0004.csv", null);
    var data2 = await _storageAccountService.GetFileAsync("migration_3_rd236l0005.csv", null);
    var data3 = await _storageAccountService.GetFileAsync("migration_4_rd236l0007.csv", null);
    var data4 = await _storageAccountService.GetFileAsync("migration_5_rd236l0008.csv", null);
    var data5 = await _storageAccountService.GetFileAsync("migration_6_rd236m0001.csv", null);
    var data6 = await _storageAccountService.GetFileAsync("migration_7_rd236m0002.csv", null);
    var data7 = await _storageAccountService.GetFileAsync("migration_8_rd236m0003.csv", null);
    var data = data0.Concat(data1).Concat(data2).Concat(data3).Concat(data4).Concat(data5).Concat(data6).Concat(data7).ToArray();*/
    foreach (var fileName in fileNames)
    {
      var data = await _storageAccountService.GetFileAsync(fileName, null);
      var changes = _csvService.ReadPostiFile(data);

      var postiChange = _postiChangeMapper.Duplicates(changes.ToList());
      lst = lst.Concat(postiChange).ToList();
    }
      
    return lst;
  }
  public async Task MapAndSaveMigrationFileInPostiFormatAsync()
  {
    var data = await _storageAccountService.GetFileAsync(_settings.MigrationFileName, null);
    var migrationRecordCollection = _csvService.ReadMigrationFile(data);
    LogMigrationFileRead();
    await SavePostiCsvInBlob(migrationRecordCollection);
  }

  public async Task ReadClmUpdateFileAsync(string fileName)
  {
    var data = await _storageAccountService.GetFileAsync(fileName, null);
    var changes = JsonConvert.DeserializeObject<List<PostiChange>>(data.ToString());
    LogMigrationFileRead();
    foreach (var chunk in changes.Chunk(20))
    {
      await _clmUpdaterService.SendChangesAsync(chunk.ToList());
    }
      
  }

  private async Task SavePostiCsvInBlob(IList<MigrationRecordCsv> migrationRecords)
  {
    int index = 1;
    foreach (var chunk in migrationRecords.Chunk(8000))
    {
      //using var multipartFormContnent = new MultipartFormDataContent();
      //string sendFileRoute = $"register/{_settings.RegistryId}/newFiles?forceStart=false";
      var fileContent = _csvService.PrepareCsv(chunk);
      await _storageAccountService.SavePostiFile(fileContent, $"migration_{index}.csv");
      LogPostiCsvWritten(index);
      index++;
    }
  }

  public async Task<ISendChangesResult> SendFilesToPosti()
  {
    //var fileNames = await _storageAccountService.GetFileNameCollection("posti");
    var fileNames = await _storageAccountService.GetFileNameCollection("migration_", null);
    foreach (var fileName in fileNames)
    {
      using var multipartFormContnent = new MultipartFormDataContent();
      string sendFileRoute = $"register/{_settings.RegistryId}/newFiles?forceStart=false";
      var fileContent = await _storageAccountService.GetFileAsync(fileName, null);
      multipartFormContnent.Add(new ByteArrayContent(fileContent), name: "data", fileName: "data.csv");
      var fileResponse = await _httpClient.PostAsync(sendFileRoute, multipartFormContnent);

      if (!fileResponse.IsSuccessStatusCode)
        return SendChangesFailed.CreateUploadFailedStatus();
    }

    return new SendChangesSuccess();
  }

  public async Task<ISendChangesResult> CommitFilesToPosti()
  {
    
    string commitFiles = $"register/{_settings.RegistryId}/modifications";
    //string commitFiles = $"register/{_settings.RegistryId}/initialActivation";
    var commitResult = await _httpClient.PostAsync(commitFiles, null);

    if (!commitResult.IsSuccessStatusCode)
      return SendChangesFailed.CreateCommitFailedStatus();

    return new SendChangesSuccess();
  }

  public async Task<PostiResult> FetchChangesAndSaveThemInStorageAccount()
  {

    string prepareDelivery = $"register/{_settings.RegistryId}/preparation/changes?format=JSON";
    //string prepareDelivery = $"register/{_settings.RegistryId}/preparation/all";
    var fileResponse = await _httpClient.PostAsync(prepareDelivery, null);
    if (fileResponse.IsSuccessStatusCode == false)
    {
      //Log failed file preparation and return
      LogFilePreparationFailed();
      return new PostiResult(PostiResultStatus.FilePreparationFailed);
    }

    var responseContentStream = await fileResponse.Content.ReadAsStringAsync();
    LogInformationFile(responseContentStream);

    return new PostiResult(PostiResultStatus.Ok);
  }

  public async Task<PostiResult> ListDeliverablesAndSaveThemInStorageAccount()
  {

    //string prepareDelivery = $"register/{_settings.RegistryId}/preparation/changes?format=JSON";
    string prepareDelivery = $"register/{_settings.RegistryId}/status";
    var fileResponse = await _httpClient.GetAsync(prepareDelivery);
    if (fileResponse.IsSuccessStatusCode == false)
    {
      //Log failed file preparation and return
      LogFilePreparationFailed();
      return new PostiResult(PostiResultStatus.FilePreparationFailed);
    }

    var responseContentStream = await fileResponse.Content.ReadAsStringAsync();
    LogInformationFile(responseContentStream);

    return await PrepareChangesAsync(responseContentStream);
  }

  public async Task<PostiResult> FetchFile(Deliverable dto)
  {
    (var fetchStatuses, var contents) = await FetchChangesAndSaveResponseInBlob(dto);

    var fetchResult = fetchStatuses.Any(status => status.success == false) ?
      PostiResultStatus.FetchingFailed :
      PostiResultStatus.Ok;
    var changesCollection = SerializeResponseToList(contents);

    var duplicateUsers = changesCollection.Where(x => x.Status == OperationStatus.DUPLICATE).ToList().Select(x => new CustomerLeftEvent
    {
      AccountType = "REGULAR",
      CustomerId = x.CustomerId,
      AddressValidationStatus = "",
      Timestamp = DateTimeOffset.UtcNow.ToString("yyyy-MM-dd'T'HH:mm:ssK"),
      EventType = "CUSTOMER_LEFT"
    }).ToList();

    if (duplicateUsers.Count > 0)
    {
      foreach (var chunk in duplicateUsers.Chunk(50))
      {
        await _eventBatcherService.PostEvent(chunk.ToList());
      }
      
    }

    var okResult = new PostiResult(fetchResult, fetchStatuses);
    return okResult;
  }
  private List<RegistryDto> SerializeResponseToList(List<string> changesResponse)
  {
    var changesCollection = new List<RegistryDto>();

    foreach (var change in changesResponse)
    {
      var changes = JsonConvert.DeserializeObject<List<RegistryDto>>(change);
      changesCollection.AddRange(changes);
    }

    return changesCollection;
  }
  private async Task<PostiResult> PrepareChangesAsync(string jsonString)
  {
    if (jsonString != null && jsonString == "No changes")
      return new PostiResult(PostiResultStatus.NoChanges);

    var file = JsonConvert.DeserializeObject<GetFileResponseDto>(jsonString);
    var selectedFile = file.Message.Updates.OrderByDescending(x => x.ProcessingDate).FirstOrDefault().Deliverables.Where(x => x.DeliverableType == PostiJsonFileDeliveryType && x.Status == "PROCESSED").FirstOrDefault();
    return await FetchFile(selectedFile);
  }

  private async Task<Tuple<List<FileFetchStatus>, List<string>>> FetchChangesAndSaveResponseInBlob(Deliverable dto)
  {
    var fetchStatuses = new List<FileFetchStatus>();
    var contents = new List<string>();
    for (int chunkIndex = 1; chunkIndex <= dto.NumberOfChunks; chunkIndex++)
    {
      var fileName = $"{dto.Id}_{chunkIndex}";
      
      LogFileFetchStart(fileName);
      string path = $"register/{_settings.RegistryId}/result/{dto.Id}?chunk={chunkIndex}";
      var contentResponse = await _httpClient.GetAsync(path);
      var fetchStatus = new FileFetchStatus(fileName, contentResponse.IsSuccessStatusCode);
      fetchStatuses.Add(fetchStatus);
      LogFileFetchFinished(fetchStatus);

      var content = await contentResponse.Content.ReadAsByteArrayAsync();
      await _storageAccountService.SavePostiFile(content, $"{fileName}.json");

      var contentAsString = await contentResponse.Content.ReadAsStringAsync();
      contents.Add(contentAsString);
      dynamic row = JsonConvert.DeserializeObject(contentAsString);

      if (row.ToString().Contains("error"))
        LogFetchingError(chunkIndex, fileName);
      else
      {
        var changes = JsonConvert.DeserializeObject<List<RegistryDto>>(contentAsString);
       
        var postiChange = _postiChangeMapper.Create(changes);
        
        var clmUpdateList = _postiCustomerChangeMapper.Map(postiChange.Item1);
        var index = 1;
        foreach (var chunk in clmUpdateList.Chunk(40))
        {
          var customerChangeDto = JsonConvert.SerializeObject(chunk);
          await _storageAccountService.SaveClmProcessedFile(Encoding.UTF8.GetBytes(customerChangeDto), $"clmUpdater_{fileName}_{index}.json");
          index++;
        }
      }
    }

    return Tuple.Create(fetchStatuses, contents);
  }

  public async Task<PostiResult> ManualCsvProcessing(string fileName)
  {
    /*var data = await _storageAccountService.GetFileAsync(fileName, null);
    var prefix = fileName.Split(".")[0].Split("_");
    var fileNameAddition = $"{prefix[0]}_{prefix[1]}";
    var changes = _csvService.ReadPostiFile(data);
    
    var postiChange = _postiChangeMapper.Create(changes.ToList());
    var clmUpdateList = _postiCustomerChangeMapper.Map(postiChange.Item1);
    var index = 1;
    foreach (var chunk in clmUpdateList.Chunk(25))
    {
      var customerChangeDto = JsonConvert.SerializeObject(chunk);
      await _storageAccountService.SaveClmProcessedFile(Encoding.UTF8.GetBytes(customerChangeDto), $"clmUpdater_{fileNameAddition}_{index}.json");
      index++;
    }*/
      
    
      return new PostiResult(PostiResultStatus.Ok);
  }

  public async Task<PostiResult> SendToCLM()
  {
    var fileNames = await _storageAccountService.GetFileNameCollection("clmUpdater_", "clmupdater1");
    var totalUserCount = 0;
    foreach (var fileName in fileNames)
    {
      var fileContent = await _storageAccountService.GetFileAsync(fileName, "clmupdater1");
      var contentAsString = Encoding.UTF8.GetString(fileContent, 0, fileContent.Length);
      dynamic row = JsonConvert.DeserializeObject<List<PostiChange>>(contentAsString);
      totalUserCount += row?.Count;
      Console.WriteLine($"#<--+++++++  Sent {fileName} for processing. Total users processed {totalUserCount} +++++++-->");
      try
      {
        await _clmUpdaterService.SendChangesAsync(row);
      }catch(Exception ex)
      {
        //Console.WriteLine(ex);
      }

      Thread.Sleep(2000);

    }
    return new PostiResult(PostiResultStatus.Ok);
  }

  public async Task<PostiResult> SendToCLMControlled(string fileName)
  {
      var fileContent = await _storageAccountService.GetFileAsync(fileName, "clmupdater1");
      var contentAsString = Encoding.UTF8.GetString(fileContent, 0, fileContent.Length);
      dynamic row = JsonConvert.DeserializeObject<List<PostiChange>>(contentAsString);
      await _clmUpdaterService.SendChangesAsync(row);
      Console.WriteLine($"#Sent {row?.Count} posti data for processing..");

    return new PostiResult(PostiResultStatus.Ok);
  }

  #region Logging
  private void LogFileFetchStart(string fileName)
  {
    _logger.LogInformation("Start file fetching\n" +
            "File: {fileName}", fileName);
  }
  private void LogFetchingError(int chunkIndex, string fileName)
  {
    _logger.LogError("There was error while fetching file\n" +
              "Filename: {fileName}\n" +
              "Chunk: {chunk}", fileName, chunkIndex);
  }

  private void LogFileFetchFinished(FileFetchStatus status)
  {
    _logger.LogInformation("File fetch finished\n" +
            "File: {fileName}\n" +
            "Success {success}", status.fileName, status.success);
  }

  private void LogMigrationFileRead()
  {
    _logger.LogInformation("Migration file read from storage account");
  }

  private void LogPostiCsvWritten(int index)
  {
    _logger.LogInformation("File stored in Storage account\n" +
            "Filename: {fileName}", $"posti{index}.csv");
  }

  private void LogInformationFile(string fileResponse)
  {
    _logger.LogInformation("Get file response\n" +
        "File response: {fileResponse}", fileResponse);
  }

  private void LogFilePreparationFailed()
  {
    _logger.LogError("File preparation failed");
  }
  #endregion
}
