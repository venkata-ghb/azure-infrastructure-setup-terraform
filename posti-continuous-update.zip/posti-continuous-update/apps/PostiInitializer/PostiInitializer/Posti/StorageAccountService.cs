﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

namespace PostiInitializer.Posti;

public interface IStorageAccountService
{
  Task<byte[]> GetFileAsync(string fileName, string? containerName);
  Task SavePostiFile(byte[] csv, string fileName);
  Task SaveClmProcessedFile(byte[] csv, string fileName);
  Task<IList<string>> GetFileNameCollection(string fileNamePart, string? containerName);
}

public class StorageAccountService : IStorageAccountService
{
  private readonly string _storageContainerName;
  private readonly ILogger<StorageAccountService> _logger;
  private readonly BlobServiceClient _blobServiceClient;


  public StorageAccountService(IConfiguration configuration, ILogger<StorageAccountService> logger, BlobServiceClient blobServiceClient)
  {
    _storageContainerName = configuration.GetValue<string>("BlobContainerName");
    _logger = logger;
    _blobServiceClient = blobServiceClient;
  }

  public async Task<byte[]> GetFileAsync(string fileName, string? containerName)
  {
    var name = string.IsNullOrEmpty(containerName) ? _storageContainerName : containerName;
    var container = _blobServiceClient.GetBlobContainerClient(name);

    // Create a new list object for 
    var blobClient = container.GetBlobClient(fileName);
    if (blobClient.ExistsAsync().Result)
    {
      using (var ms = new MemoryStream())
      {
        blobClient.DownloadTo(ms);
        LogSuccessGetFileAsync(fileName);
        return ms.ToArray();
      }
    }
    return new byte[0];
  }

  public async Task SavePostiFile(byte[] file, string fileName)
  {
    var container = _blobServiceClient.GetBlobContainerClient(_storageContainerName);

    await container.UploadBlobAsync(fileName, new BinaryData(file));
    LogSuccessfulFileSave(fileName);
  }

  public async Task SaveClmProcessedFile(byte[] file, string fileName)
  {
    var container = _blobServiceClient.GetBlobContainerClient("clmupdater1");

    await container.UploadBlobAsync(fileName, new BinaryData(file));
    LogSuccessfulFileSave(fileName);
  }

  public async Task<IList<string>> GetFileNameCollection(string fileNamePart, string? containerName)
  {
    var name = string.IsNullOrEmpty(containerName) ? _storageContainerName : containerName;
    var container = _blobServiceClient.GetBlobContainerClient(name);

    // Create a new list object for
    var fileNames = new List<string>();
    await foreach (BlobItem blobItem in container.GetBlobsAsync())
    {
      fileNames.Add(blobItem.Name);
    }
    return fileNames.Where(name => name.StartsWith(fileNamePart)).ToList();
  }

  private void LogSuccessGetFileAsync(string fileName)
  {
    _logger.LogInformation("File {fileName} fetched", fileName);
  }

  private void LogSuccessfulFileSave(string fileName)
  {
    _logger.LogInformation("File {fileName} saved successfully", fileName);
  }
}
