﻿using System.Runtime.Serialization;
using System.Text.Json.Serialization;
using Newtonsoft.Json.Converters;

namespace PostiInitializer.Posti.Models;

/*public enum OperationStatus: int
{
  
  OperationSuccessful = 0,
  PersonAdded = 1,
  PersonRemoved = 2,
  //Telephone, email address, extra changed
  PersonChanged = 3,
  PersonDidNotExist = 4,
  PersonAlreadyExist = 5,
  OperationFailed = 6
}*/

[JsonConverter(typeof(StringEnumConverter))]
public enum OperationStatus
{

  [EnumMember(Value = "CHANGED")]
  CHANGED = 1,

  [EnumMember(Value = "NO_CHANGE")]
  NO_CHANGE = 2,

  [EnumMember(Value = "NOT_DETECTED")]
  NOT_DETECTED = 3,

  [EnumMember(Value = "DUPLICATE")]
  DUPLICATE = 4,
  [EnumMember(Value = "REMOVED")]
  REMOVED = 5,

}

public enum PersonStatusEnum
{
  Alive,
  MinorAlive,
  Deceased
}

public enum IdentificationStatus
{
  IdentifiedWithNameAndAddress,
  IdentifiedWithSsn,
  NotIdentified,
  Duplicate
}

public enum NameStatus
{
  CorrectName,
  LastNameChanged,
  FirstNameChanged,
  LastAndFirstNameChanged,
  NameSpellingChanged
}

public enum AddressStatus
{
  AddressCorrect,
  AddressChanged,
  AddressSpellingRevised,
  RevisionOfTheAddressWithoutAssignment,
  AddressCannotBeDeliveredOrIsNotKnown,
  ForeignAddress
}

public enum AddressLanguage
{
  Finnish,
  Swedish
}

public enum AddressType
{
  Finnish,
  Swedish
}


public enum PostiResultStatus
{
  NoChanges,
  Ok,
  FilePreparationFailed,
  FetchingFailed,
  BatchMatchingError
}

public enum CsvRecordOperation
{
  A,
  R,
  M
}

public enum FetchErrorType
{
  CustomerIdAlreadyExists,
  PersonDoesNotExist,
  Other
}

[JsonConverter(typeof(StringEnumConverter))]
public enum PostiOperations
{
  Add,
  Remove,
  Modify
}
public enum BatchOperations
{
  Add,
  Remove,
  Modify
}
public enum PostiAddressType
{
  Finnish,
  Swedish
}
