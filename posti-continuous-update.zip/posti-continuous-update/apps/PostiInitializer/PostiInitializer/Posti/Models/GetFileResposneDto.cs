﻿using Newtonsoft.Json;

namespace PostiInitializer.Posti.Models;
public record GetFileResponseDto
{
  [JsonProperty("message")]
  public Message Message { get; set; } = new Message();

  [JsonProperty("operationStatus")]
  public string OperationStatus { get; set; } = string.Empty;
}

public record Message
{
  [JsonProperty("approved")]
  public bool Approved { get; set; }

  [JsonProperty("id")]
  public string Id { get; set; }

  [JsonProperty("isApproved")]
  public bool IsApproved { get; set; }

  [JsonProperty("lastProcessingDate")]
  public DateTime LastProcessingDate { get; set; }

  [JsonProperty("lastProcessingId")]
  public string LastProcessingId { get; set; }

  [JsonProperty("status")]
  public string Status { get; set; }

  [JsonProperty("updates")]
  public List<Update> Updates { get; set; }


}

public record Deliverable
{
  [JsonProperty("createdDate")]
  public DateTime CreatedDate { get; set; }

  [JsonProperty("deliverableType")]
  public string DeliverableType { get; set; }

  [JsonProperty("id")]
  public string Id { get; set; }

  [JsonProperty("numberOfChunks")]
  public int NumberOfChunks { get; set; }

  [JsonProperty("status")]
  public string Status { get; set; }

  
}

public record Update
{
  [JsonProperty("deliverables")]
  public List<Deliverable> Deliverables { get; set; }

  [JsonProperty("id")]
  public string Id { get; set; }

  [JsonProperty("processingDate")]
  public DateTime ProcessingDate { get; set; }

  [JsonProperty("status")]
  public string Status { get; set; }
}


