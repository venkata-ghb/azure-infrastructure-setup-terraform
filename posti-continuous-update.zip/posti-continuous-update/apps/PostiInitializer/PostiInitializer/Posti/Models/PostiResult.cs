﻿namespace PostiInitializer.Posti.Models;

public record FileFetchStatus(string fileName, bool success);

/// <summary>
/// Model that containt information about posti fetch result
/// </summary>
public class PostiResult
{
  public PostiResultStatus Status { get; init; }
  public IList<FileFetchStatus>? FileFetchStatuses { get; init; }

  public PostiResult(PostiResultStatus status, IList<FileFetchStatus> fileFetchStatuses = null)
  {
    Status = status;
    FileFetchStatuses = fileFetchStatuses;
  }
}


