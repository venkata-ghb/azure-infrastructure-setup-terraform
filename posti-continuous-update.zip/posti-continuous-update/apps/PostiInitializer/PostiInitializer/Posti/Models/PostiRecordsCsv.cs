﻿using CsvHelper.Configuration.Attributes;

namespace PostiInitializer.Posti.Models;

/// <summary>
/// This class models CSV Record that will be send into PostiRegistry
/// </summary>
public class PostiRecordsCsv
{
  
  [Name("customerId")]
  [Optional]
  public string CustomerId { get; init; } = default!;
  [Name("ssnOrDateOfBirth")]
  [Optional]
  public string CustGivenSsn { get; init; } = default!;
  [Name("nFirstNames")]
  [Optional]
  public string FirstName { get; init; } = default!;
  [Name("nLastName")]
  [Optional]
  public string LastName { get; init; } = default!;
  
  [Name("dIdentificationCode")]
  [Optional]
  public IdentificationStatus? IdentificationStatus { get; init; } = default!;
  [Name("sPersonStatusCode")]
  [Optional]
  public PersonStatusEnum? PersonStatus { get; init; } = default!;

  [Name("aAddressStatusCode")]
  [Optional]
  public AddressStatus? AddressStatus { get; init; } = default!;
  [Name("aAddressLanguageCode")]
  [Optional]
  public AddressLanguage? AddressLanguage { get; init; } = default!;
  [Name("PersonLanguageCode")]
  [Optional]
  public string? PersonLanguageCode { get; init; }
  [Name("nNameStatusCode")]
  [Optional]
  public NameStatus? NameStatus { get; init; } = default!;
  
  [Name("duplicateCustomerId")]
  [Optional]
  public string? Duplicate { get; init; }
  [Name("sDayOfDeath")]
  [Optional]
  public string? DayOfDeath { get; init; }

  [Name("aRecipientAddressStartDate")]
  [Optional]
  public string? RecipientAddressStartDate { get; init; }
  [Name("aMunicipality")]
  [Optional]
  public string? Municipality { get; init; }
  [Name("aPostcode")]
  [Optional]
  public string PostCode { get; init; } = default!;
  [Name("aPostcodeName")]
  [Optional]
  public string City { get; init; } = default!;
  [Name("aStreetAddress")]
  [Optional]
  public string Address { get; init; } = default!;
  [Name("aAddressFamilyId")]
  [Optional]
  public string AddressFamilyId { get; init; } = default!;
  [Name("aOtherAddressLine1")]
  [Optional]
  public string OtherAddressLine1 { get; init; } = default!;
  [Name("aOtherAddressLine2")]
  [Optional]
  public string OtherAddressLine2 { get; init; } = default!;
  [Name("aOtherAddressLine3")]
  [Optional]
  public string OtherAddressLine3 { get; init; } = default!;
  [Name("aOtherAddressLine4")]
  [Optional]
  public string OtherAddressLine4 { get; init; } = default!;
  [Name("aCountryName")]
  [Optional]
  public string CountryName { get; init; } = default!;
  
  [Name("aOtherCountryCode")]
  [Optional]
  public string CountryCode { get; init; } = default!;
}
