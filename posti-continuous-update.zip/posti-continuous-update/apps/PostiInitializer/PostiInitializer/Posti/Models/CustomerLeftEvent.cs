﻿using Newtonsoft.Json;

namespace PostiInitializer.Posti.Models;

/// <summary>
/// Contains information about a data that went into Posti Registry
/// Used when trying to get information want when wrong Posti Registry Update
/// </summary>

public record CustomerLeftEvent
{
  [JsonProperty("eventTime")]
  public string Timestamp { get; init; }
  [JsonProperty("eventType")]
  public string EventType { get; init; } = "CUSTOMER_LEFT";
  [JsonProperty("customerId")]
  public string CustomerId { get; init; }

  [JsonProperty("accountType")]
  public string AccountType { get; init; }

  [JsonProperty("addressValidationStatus")]
  public string AddressValidationStatus { get; init; }
}
