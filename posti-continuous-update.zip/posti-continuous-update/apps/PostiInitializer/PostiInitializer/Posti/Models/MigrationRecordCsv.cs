﻿using CsvHelper.Configuration.Attributes;

namespace PostiInitializer.Posti.Models;

/// <summary>
/// This class models CSV Record that will be send into PostiRegistry
/// </summary>
public class MigrationRecordCsv
{
  [Index(0)]
  public string AccountId { get; init; }
  [Index(1)]
  public string CustomerNumber { get; init; }
  [Index(2)]
  [Optional]
  public string Ssn { get; init; }
  [Index(3)]
  public string FirstName { get; init; }
  [Index(4)]
  public string LastName { get; init; }
  [Index(5)]
  public string DateOfBirth { get; init; }
  [Index(6)]
  public string Address { get; init; }
  [Index(7)]
  public string City { get; init; }
  [Index(8)]
  public string PostalCode { get; init; }
  [Index(9)]
  [Optional]
  public string DefaultDateOfBirth { get; init; }
  [Index(10)]
  [Optional]
  public string IdentificationStatus { get; init; }
  
}
