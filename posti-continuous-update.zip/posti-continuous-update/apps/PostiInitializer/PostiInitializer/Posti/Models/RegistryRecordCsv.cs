﻿using CsvHelper.Configuration.Attributes;

namespace PostiInitializer.Posti.Models;

/// <summary>
/// This class models CSV Record that will be send into PostiRegistry
/// </summary>
public class RegistryRecordCsv
{
  [Index(0)]
  public string Operation { get; init; }
  [Index(1)]
  public string CustomerNumber { get; init; }
  [Index(2)]
  public string? IdentificationField { get; init; }
  [Index(3)]
  public string LastName { get; init; }
  [Index(4)]
  public string FirstName { get; init; }
  [Index(5)]
  public string PostalCode { get; init; }
  [Index(6)]
  public string City { get; init; }
  [Index(7)]
  public string Address { get; init; }
  [Index(8)]
  public string Telephone { get; init; }
  [Index(9)]
  public string Email { get; init; }
  [Index(10)]
  public string Extra { get; init; }
}
