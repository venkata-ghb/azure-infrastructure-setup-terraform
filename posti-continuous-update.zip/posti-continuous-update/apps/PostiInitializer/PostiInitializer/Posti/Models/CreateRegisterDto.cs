﻿using Newtonsoft.Json;

namespace PostiInitializer.Posti.Models;

public record CreateRegisterDto
{
  [JsonProperty("message")]
  public string RegistryId { get; init; }

  [JsonProperty("operationStatus")]
  public string OperationStatus { get; init; }
}

public record CreateRegisterResponse
{
  [JsonProperty("message")]
  public string RegistryId { get; init; }

  [JsonProperty("operationStatus")]
  public string OperationStatus { get; init; }
}
