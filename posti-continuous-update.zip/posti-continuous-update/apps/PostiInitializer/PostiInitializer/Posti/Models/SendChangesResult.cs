﻿namespace PostiInitializer.Posti.Models;

public interface ISendChangesResult
{
  public SendChangesStatus Status { get; init; }
}

public enum SendChangesStatus
{
  Success,
  Fail
}

public class SendChangesSuccess : ISendChangesResult
{
  public SendChangesStatus Status { get; init; } = SendChangesStatus.Success;
}

public class SendChangesFailed : ISendChangesResult
{
  public SendChangesStatus Status { get; init; } = SendChangesStatus.Fail;
  public string Code { get; init; } = "commit_fail";
  public string Message { get; init; } = "Commiting file failed";

  public static SendChangesFailed CreateCommitFailedStatus()
  {
    return new SendChangesFailed
    {
      Status = SendChangesStatus.Fail,
      Code = "commit_fail",
      Message = "Commiting file failed"
    };
  }

  public static SendChangesFailed CreateUploadFailedStatus()
  {
    return new SendChangesFailed
    {
      Status = SendChangesStatus.Fail,
      Code = "upload_failed",
      Message = "Uploading file failed"
    };
  }
}
