﻿using System.Net.Http.Headers;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using PostiInitializer.Config;

namespace PostiInitializer.Posti;

public interface ITokenService
{
  public Task<string> GetAccessToken();
  public Task<string> GetRawAccessToken();
}

public class TokenService : ITokenService
{
  private readonly HttpClient _httpClient;
  private readonly PostiAuthSettings _authSettings;
  private readonly ILogger<TokenService> _logger;

  private static readonly SemaphoreSlim _accessTokenSemaphore;
  private static AccessToken _accessToken;

  static TokenService()
  {
    _accessToken = null!;
    _accessTokenSemaphore = new SemaphoreSlim(1, 1);
  }

  public TokenService(HttpClient httpClient, IOptions<PostiAuthSettings> authSettings, ILogger<TokenService> logger)
  {
    _httpClient = httpClient;
    _authSettings = authSettings.Value;
    _httpClient.BaseAddress = new Uri(_authSettings.BaseUrl);
    _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", GenerateKey());
    _logger = logger;
  }

  private string GenerateKey()
  {
    var bytes = System.Text.Encoding.UTF8.GetBytes($"{_authSettings.ConsumerKey}:{_authSettings.ConsumerSecret}");
    
    return Convert.ToBase64String(bytes);
  }

  public async Task<string> GetAccessToken()
  {
    try
    {
      await _accessTokenSemaphore.WaitAsync();
      if (_accessToken is not null && !_accessToken.Expired)
        return _accessToken.Token;

      string path = "token?grant_type=client_credentials";
      var response = await _httpClient.PostAsync(path, null);

      var responseContentStream = await response.Content.ReadAsStringAsync();

      _accessToken = JsonConvert.DeserializeObject<AccessToken>(responseContentStream);
      LogInformationTokenAquired(_accessToken);
      _accessToken.SetThreshold(_authSettings.TokenTreshold);

      return _accessToken.Token;
    }
    finally
    {
      _accessTokenSemaphore.Release(1);
    }
  }
  public async Task<string> GetRawAccessToken()
  {
    string path = "token?grant_type=client_credentials";
    var response = await _httpClient.PostAsync(path, null);

    var responseContentStream = await response.Content.ReadAsStringAsync();

    _accessToken = JsonConvert.DeserializeObject<AccessToken>(responseContentStream);
    LogRawInformationTokenAquired(_accessToken);

    return _accessToken.Token;

  }

  private void LogRawInformationTokenAquired(AccessToken accessToken)
  {
    _logger.LogInformation("Aquired raw access token.\n" +
        "AccessToken: {token}\n" +
        "Expires in: {expiryIn}", accessToken.Token, accessToken.ExpiresInSeconds);
  }
  private void LogInformationTokenAquired(AccessToken accessToken)
  {
    _logger.LogInformation("Aquired access token.\n" +
        "AccessToken: {token}\n" +
        "Expires in: {expiryIn}", accessToken.Token, accessToken.ExpiresInSeconds);
  }
}
