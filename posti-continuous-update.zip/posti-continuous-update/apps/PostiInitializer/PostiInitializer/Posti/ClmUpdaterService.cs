﻿using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using PostiInitializer.Posti.Exceptions;
using PostiInitializer.Posti.Mappers;
using PostiInitializer.Posti.Models;
using PostiIntegration.Config.Models;

namespace PostiInitializer.Posti;
public class ClmUpdaterService : IClmUpdaterService
{
  private readonly HttpClient _httpClient;
  private readonly ILogger<ClmUpdaterService> _logger;
  private readonly ClmUpdaterSettings _settings;
  private readonly IPostiCustomerChangeDtoMapper _mapper;

  public ClmUpdaterService(HttpClient httpClient, IOptions<ClmUpdaterSettings> settings, ILogger<ClmUpdaterService> logger, IPostiCustomerChangeDtoMapper mapper)
  {
    _httpClient = httpClient;
    _settings = settings.Value;
    _httpClient.BaseAddress = new System.Uri(_settings.Url);
    _httpClient.DefaultRequestHeaders.Add("x-functions-key", _settings.HostKey);
    _logger = logger;
    _mapper = mapper;
  }

  public async Task SendChangesAsync(List<PostiChange> changes)
  {
    var mappedDto = _mapper.Map(changes);
    var jsonBody = JsonConvert.SerializeObject(mappedDto);
    var data = new StringContent(jsonBody, Encoding.UTF8, "application/json");
    //Console.WriteLine(jsonBody);
    var fileResponse = await _httpClient.PostAsync("UpdateClm", data);

    if (!fileResponse.IsSuccessStatusCode)
      throw new ClmUpdaterRequestException(fileResponse.StatusCode, fileResponse.ReasonPhrase, fileResponse.RequestMessage);
  }

  private void LogSendingChangesDisabled(string jsonBody)
  {
    _logger.LogInformation("Sending changes to CLM Updater disabled. Skipping\n" +
            "Json request: {request}", jsonBody);
  }

  private void LogClmUpdaterRequest(string jsonBody)
  {
    _logger.LogInformation("Clm Updater posti changes request body\n" +
        "Json Body: {body}", jsonBody);
  }
}
