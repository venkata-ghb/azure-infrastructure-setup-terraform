﻿using System.Globalization;
using CsvHelper;
using CsvHelper.Configuration;
using PostiInitializer.Posti.Mappers;
using PostiInitializer.Posti.Models;

namespace PostiInitializer.Posti.Csv;

public interface ICsvService
{
  public IList<MigrationRecordCsv> ReadMigrationFile(byte[] data);
  public IList<PostiRecordsCsv> ReadPostiFile(byte[] data);
  public byte[] PrepareCsv(MigrationRecordCsv[] records);
}
public class CsvService : ICsvService
{
  private readonly IRegistryRecordMapper _mapper;

  public CsvService(IRegistryRecordMapper mapper)
  {
    _mapper = mapper;
  }

  public IList<MigrationRecordCsv> ReadMigrationFile(byte[] data)
  {
    IEnumerable<MigrationRecordCsv> records;
    var config = new CsvConfiguration(CultureInfo.InvariantCulture)
    { Delimiter = ";", HasHeaderRecord = true, MissingFieldFound = null };

    using (var reader = new StreamReader(new MemoryStream(data)))
    using (var csv = new CsvReader(reader, config))
    {
      records = csv.GetRecords<MigrationRecordCsv>().ToList();
    }

    return records.ToList();
  }

  public IList<PostiRecordsCsv> ReadPostiFile(byte[] data)
  {
    IEnumerable<PostiRecordsCsv> records;
    var config = new CsvConfiguration(CultureInfo.InvariantCulture)
    { Delimiter = ";", HasHeaderRecord = true, MissingFieldFound = null };

    using (var reader = new StreamReader(new MemoryStream(data)))
    using (var csv = new CsvReader(reader, config))
    {
      records = csv.GetRecords<PostiRecordsCsv>().ToList();
    }

    return records.ToList();
  }

  public byte[] PrepareCsv(MigrationRecordCsv[] records)
  {
    //Map Dto to CSV model
    var filteredRecords = records.Where(x => x.IdentificationStatus != "NV" && !x.PostalCode.StartsWith("22") && !x.Address.Contains("C/O", StringComparison.OrdinalIgnoreCase)).ToArray();
    var mappedRecords = _mapper.Map(filteredRecords);
    //Create byte Array for all but last records
    var configWithNewLine = new CsvConfiguration(CultureInfo.InvariantCulture)
    { Delimiter = ";", HasHeaderRecord = false, };
    var recordsArray = GetByteArray(mappedRecords.Take(mappedRecords.Count - 1), configWithNewLine);

    //Create array for just last record (which can't have new line in the end
    var configWithoutNewLine = new CsvConfiguration(CultureInfo.InvariantCulture)
    { Delimiter = ";", HasHeaderRecord = false, NewLine = "", ShouldQuote = args => false };
    var lastRecordArray = GetByteArray(mappedRecords.TakeLast(1), configWithoutNewLine);

    //Merge arrays and return as ByteArrayContent
    var mergedArrays = recordsArray.Concat(lastRecordArray);
    var fileContent = new ByteArrayContent(mergedArrays.ToArray());
    return mergedArrays.ToArray();
  }

  private byte[] GetByteArray(IEnumerable<RegistryRecordCsv> records, CsvConfiguration config)
  {
    using var memoryStream = new MemoryStream();
    using var streamWriter = new StreamWriter(memoryStream);
    using var csv = new CsvWriter(streamWriter, config);

    csv.WriteRecords(records);
    csv.Flush();
    return memoryStream.ToArray();
  }
}
