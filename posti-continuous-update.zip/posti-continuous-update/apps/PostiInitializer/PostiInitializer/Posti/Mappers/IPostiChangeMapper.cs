﻿using System.Globalization;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PostiInitializer.Posti.Models;

namespace PostiInitializer.Posti.Mappers;

public interface IPostiChangesMapper
{
  public Tuple<List<PostiChange>, List<PostiChangeError>> Create(List<RegistryDto> changesCollection);

  public List<string> Duplicates(List<PostiRecordsCsv> changesCollection);
}

public class PostiChangesMapper : IPostiChangesMapper
{
  private readonly ILogger<PostiChangesMapper> _logger;

  public PostiChangesMapper(ILogger<PostiChangesMapper> logger)
  {
    _logger = logger;
  }

  public List<string> Duplicates(List<PostiRecordsCsv> changesCollection)
  {
    var dupAddressIds = new List<string>();
    dupAddressIds = changesCollection.Where(g => g.PersonStatus == PersonStatusEnum.Deceased && !string.IsNullOrEmpty(g.AddressFamilyId)).GroupBy(x => x.AddressFamilyId)
              .Where(g => g.Count() > 1)
              .Select(y => y.Key)
              .ToList();
    
    //removed = changesCollection.Where(g => g.PersonStatus == PersonStatusEnum.Deceased && !string.IsNullOrEmpty(g.AddressFamilyId)).GroupBy(x => x.AddressFamilyId)
    //.Where(g => g.Count() > 1).Select(y => y.ToList()).ToList();

    return dupAddressIds;
  }

  public Tuple<List<PostiChange>, List<PostiChangeError>> Create(List<RegistryDto> changesCollection)
  {
    var removed = new List<string>();
    var mappedCollection = new List<PostiChange>();
    var mappedErrors = new List<PostiChangeError>();
    var noChangesList = new List<PostiNoChange>();
    var notDetectedList = new List<PostiNotDetected>();
    /*changesCollection?.ForEach(run =>
    {
      
      if (run.Details.Identification.IdentificationStatus == IdentificationStatus.NotIdentified)
      {
        notDetectedList.Add(new PostiNotDetected
        {
          CustomerId = run.CustomerId,
        });
      }
      
    });*/

    LogRemovedCustomers(removed);
    /*changesCollection.Where(x => x.NameStatus == NameStatus.LastAndFirstNameChanged ||
      x.NameStatus == NameStatus.FirstNameChanged ||
      x.NameStatus == NameStatus.LastNameChanged ||
      x.NameStatus == NameStatus.NameSpellingChanged ||
      x.AddressStatus == AddressStatus.AddressChanged ||
      x.AddressStatus == AddressStatus.AddressSpellingRevised ||
      x.AddressStatus == AddressStatus.RevisionOfTheAddressWithoutAssignment ||
      x.PersonStatus == PersonStatusEnum.Deceased ||
      x.PersonStatus == PersonStatusEnum.MinorAlive ||
      x.IdentificationStatus == IdentificationStatus.Duplicate).ToList().ForEach(registryRow => mappedCollection.Add(PreparePostiChange(registryRow)));*/
    //var postChange = PreparePostiChange(changesCollection.Registry
    changesCollection.Where(x => x.Status != OperationStatus.REMOVED).ToList().ForEach(registryRow => mappedCollection.Add(PreparePostiChange(registryRow)));
    return Tuple.Create(mappedCollection, mappedErrors);
  }

  private void LogRemovedCustomers(List<string> removed)
  {
    _logger.LogInformation("Customers with following CustomerIds were removed successfully from Posti Registry \n" +
          "CustomerIds: {customerIds}", JsonConvert.SerializeObject(removed));
  }

  private PostiChange PreparePostiChange(RegistryDto registryDto)
  {
    var personStatus = new PersonStatus()
    {
      DateOfDeath = registryDto.Details?.PersonStatus?.DayOfDeath,
      IsDeceased = registryDto.Details != null && registryDto.Details?.PersonStatus != null && registryDto.Details.PersonStatus.Status.HasValue ? registryDto.Details.PersonStatus?.Status == PersonStatusEnum.Deceased : null,
      IsMinor = registryDto.Details != null && registryDto.Details?.PersonStatus != null && registryDto.Details.PersonStatus.Status.HasValue ? registryDto.Details.PersonStatus?.Status == PersonStatusEnum.MinorAlive : null,

    };

    var change = new PostiChange()
    {
      PostiChangeStatus = DtoToPostiChangeStatus(new ChangeState(
        registryDto.Status.HasValue ? registryDto.Status.Value : null,
        ((bool)(registryDto.Changes?.Name?.NameStatus != null) && (bool)(registryDto.Changes?.Name?.NameStatus.HasValue)) ? registryDto.Changes?.Name?.NameStatus.Value : null,
        ((bool)(registryDto.Changes?.Address?.AddressStatus != null) && (bool)(registryDto.Changes?.Address?.AddressStatus.HasValue)) ? registryDto.Changes?.Address?.AddressStatus.Value : null,
        registryDto.Details != null && registryDto.Details.Identification != null && registryDto.Details.Identification.IdentificationStatus != null && registryDto.Details.Identification.IdentificationStatus.HasValue ? registryDto.Details.Identification.IdentificationStatus.Value : null,
        personStatus,
        !string.IsNullOrEmpty(registryDto.Duplicate))),
      CustomerId = registryDto.CustomerId,
      DuplicatedId = string.IsNullOrEmpty(registryDto.Duplicate) ? null : registryDto.Duplicate,
      Ssn = registryDto.CustGivenSsn,
      LastName = registryDto.Changes?.Name?.LastName,
      FirstName = registryDto.Changes?.Name?.FirstName,
      Address = PrepareAddressFromDto(registryDto.Changes?.Address),
      ForeignAddress = PrepareForeignAddressFromDto(registryDto.Changes?.Address),
      PersonStatus = personStatus
    };

    return change;
  }

  private Address PrepareAddressFromDto(AddressDto addressDto)
  {
    if(addressDto == null)
    {
      return null;
    }
    //If foreign address then set address to null
    if (addressDto.AddressStatus == AddressStatus.ForeignAddress)
      return null;

    return new Address()
    {
      AddressType = AddressLanguageToType(addressDto),
      PostalCode = addressDto.PostCode,
      City = addressDto.City,
      Street = addressDto.Address
    };
  }

  private ForeignAddress PrepareForeignAddressFromDto(AddressDto addressDto)
  {
    if (addressDto == null)
    {
      return null;
    }
    //If foreign address then set address to null
    if (addressDto.AddressStatus != AddressStatus.ForeignAddress)
      return null;
    //If not foreign address then set Foreign address to null
   
    return new ForeignAddress()
    {
      CountryCode = addressDto.CountryCode == null ? "XX" : addressDto.CountryCode,
      CountryName = addressDto.CountryName == null ? "" : addressDto.CountryName,
      OtherAddressLine1 = addressDto.OtherAddressLine1,
      OtherAddressLine2 = addressDto.OtherAddressLine2,
      OtherAddressLine3 = addressDto.OtherAddressLine3,
      OtherAddressLine4 = addressDto.OtherAddressLine4
    };
  }

  private record ChangeState(OperationStatus? OperationStatus, NameStatus? NameStatus, AddressStatus? AddressStatus,
    IdentificationStatus? IdentificationStatus, PersonStatus PersonStatus, bool IsDuplicated);

  private PostiChangeStatus DtoToPostiChangeStatus(ChangeState changeStatus)
  {
    var postiChangeStatus = new PostiChangeStatus()
    {
      IsDuplicated = changeStatus.IsDuplicated,
      WasIdentified = wasIdentified(changeStatus.IdentificationStatus),
      WasModified = wasModified(changeStatus)
    };

    return postiChangeStatus;
  }

  /// <summary>
  /// Maps identification status to boolean value
  /// </summary>
  /// <param name="identificationStatus"></param>
  /// <returns></returns>
  private bool wasIdentified(IdentificationStatus? identificationStatus) =>
    identificationStatus switch
    {
      IdentificationStatus.IdentifiedWithSsn => true,
      IdentificationStatus.IdentifiedWithNameAndAddress => true,
      _ => false
    };

  /// <summary>
  /// Maps multiple statuses to inforamtion if a given person was modified
  /// </summary>
  /// <param name="changeStatus"></param>
  /// <returns></returns>
  private bool wasModified(ChangeState changeStatus)
  {
    //If OperationStatus is equal to Person changed (telephone, email or extra changed that means that a person was modified
    if (changeStatus.OperationStatus.HasValue && changeStatus.OperationStatus.Value == Models.OperationStatus.CHANGED)
      return true;

    //If Address status is not equal to address correct that means that address has changed and that the person was modified
    if (changeStatus.AddressStatus.HasValue && changeStatus.AddressStatus != AddressStatus.AddressCorrect)
      return true;

    //If Name status is other the correct one, that means that it has been changed, and a person was modifed
    if (changeStatus.NameStatus.HasValue && changeStatus.NameStatus != NameStatus.CorrectName)
      return true;

    //If any of the person status fields is not null that means that the person has been modified
    if (changeStatus.PersonStatus is not null && changeStatus.PersonStatus.IsMinor.HasValue && changeStatus.PersonStatus.IsMinor.Value == true)
      return true;

    if (changeStatus.PersonStatus is not null && changeStatus.PersonStatus.IsDeceased.HasValue && changeStatus.PersonStatus.IsDeceased.Value == true)
      return true;

    return false;
  }

  private AddressType? AddressLanguageToType(AddressDto dto)
  {
    if (dto == null)
      return null;

    return dto.AddressLanguage switch
    {
      AddressLanguage.Finnish => AddressType.Finnish,
      AddressLanguage.Swedish => AddressType.Swedish,
      _ => null
    };
  }

  private string RemovedCustomerCheck(InfoDto infoDto)
  {
    Regex regex = new Regex(@"^Customer [\w]+ was removed$", RegexOptions.Compiled | RegexOptions.IgnoreCase);

    if (!regex.IsMatch(infoDto.Message))
      return null;

    return GetIdOfRemovedUser(infoDto.Message);
  }

  private PostiChangeError PreparePostiChangeError(InfoDto errorDto)
  {
    Regex regex = new Regex(@"^Customer [\w]+ was removed$", RegexOptions.Compiled | RegexOptions.IgnoreCase);

    var error = new PostiChangeError()
    {
      Line = errorDto.Line,
      Message = errorDto.Message
    };
    return error;
  }

  private string GetIdOfRemovedUser(string infoMessage)
  {
    var split = infoMessage.Split(' ');
    return split[1];
  }
}
