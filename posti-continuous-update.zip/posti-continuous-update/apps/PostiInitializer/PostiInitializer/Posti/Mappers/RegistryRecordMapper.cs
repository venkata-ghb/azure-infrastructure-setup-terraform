﻿using System.Text;
using PostiInitializer.Posti.Models;

namespace PostiInitializer.Posti.Mappers;

public interface IRegistryRecordMapper
{
  public List<RegistryRecordCsv> Map(MigrationRecordCsv[] migrationRecords);
  public RegistryRecordCsv Map(MigrationRecordCsv migrationRecord);
}

public class RegistryRecordMapper : IRegistryRecordMapper
{
  public List<RegistryRecordCsv> Map(MigrationRecordCsv[] migrationRecords)
  {
    var mappedList = new List<RegistryRecordCsv>();
    foreach (var record in migrationRecords)
      mappedList.Add(Map(record));
    var distinctMappedList = mappedList.DistinctBy(i => i.CustomerNumber).ToList();
    return distinctMappedList;
  }

  public RegistryRecordCsv Map(MigrationRecordCsv migrationRecord)
  {
    
    var csvRecord = new RegistryRecordCsv()
    {
      Operation = CsvRecordOperation.A.ToString(),
      Address = migrationRecord.Address,
      City = migrationRecord.City,
      CustomerNumber = migrationRecord.CustomerNumber,
      FirstName = migrationRecord.FirstName,
      LastName = migrationRecord.LastName,
      PostalCode = migrationRecord.PostalCode,
      IdentificationField = GetIdField(migrationRecord),
    };
    return csvRecord;
  }

  private string? GetIdField(MigrationRecordCsv migrationRecord)
  {
    if(!string.IsNullOrEmpty(migrationRecord.Ssn))
    {
      return migrationRecord.Ssn;
    }
    if(migrationRecord.DefaultDateOfBirth != "1")
    {
      return ParseBirthDateToPostiFormat(migrationRecord.DateOfBirth);
    }
    return null;
  }

  private string ParseBirthDateToPostiFormat(string birthDate)
  {
    var datePart = birthDate.Split(' ')[0];
    var splitedBirthDate = datePart.Split('-');
    var stringBuilder = new StringBuilder();
    stringBuilder.Append(splitedBirthDate[2]);
    stringBuilder.Append(splitedBirthDate[1]);
    stringBuilder.Append(splitedBirthDate[0]);
    return stringBuilder.ToString();
  }
}
