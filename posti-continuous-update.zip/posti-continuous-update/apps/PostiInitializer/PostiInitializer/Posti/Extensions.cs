﻿using PostiInitializer.Config;
using PostiInitializer.Posti.Csv;
using PostiInitializer.Posti.Mappers;

namespace PostiInitializer.Posti;

public static class Extensions
{
  public static IServiceCollection RegisterPostiClients(this IServiceCollection services, IConfiguration configuration)
  {
    var postiAPiSettings = new PostiApiSettings();
    configuration.GetSection("PostiApiSettings").Bind(postiAPiSettings);

    services.AddTransient<BearerTokenHandler>();
    services.AddTransient<ICsvService, CsvService>();
    services.AddTransient<IRegistryRecordMapper, RegistryRecordMapper>();
    services.AddTransient<IPostiChangesMapper, PostiChangesMapper>();
    services.AddTransient<IPostiCustomerChangeDtoMapper, PostiCustomerChangeDtoMapper>();
    services.AddTransient<IPostiService, PostiService>();
    services.AddTransient<IClmUpdaterService, ClmUpdaterService>();
    services.AddTransient<IEventBatcherService, EventBatcherService>();
    services.AddTransient<IStorageAccountService, StorageAccountService>();


    services.AddHttpClient<ITokenService, TokenService>();
    services.AddHttpClient<IPostiService, PostiService>()
      .AddHttpMessageHandler<BearerTokenHandler>();

    return services;
  }
}
