﻿using System.Collections.Generic;
using System.Threading.Tasks;
using PostiInitializer.Posti.Models;

namespace PostiInitializer.Posti;
public interface IClmUpdaterService
{
  public Task SendChangesAsync(List<PostiChange> changes);
}
