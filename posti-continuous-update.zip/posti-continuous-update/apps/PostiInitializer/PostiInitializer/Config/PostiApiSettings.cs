﻿namespace PostiInitializer.Config;

public class PostiApiSettings
{
  public string BaseUrl { get; init; }
  public string RegistryId { get; init; }
  public string MigrationFileName { get; init; }
}
