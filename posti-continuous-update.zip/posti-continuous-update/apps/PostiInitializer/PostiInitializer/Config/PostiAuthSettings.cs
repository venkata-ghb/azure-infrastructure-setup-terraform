﻿namespace PostiInitializer.Config;

public class PostiAuthSettings
{
  public string BaseUrl { get; init; }
  public int TokenTreshold { get; init; }
  public string ConsumerKey { get; init; }
  public string ConsumerSecret { get; init; }
}
