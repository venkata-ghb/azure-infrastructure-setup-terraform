﻿namespace PostiIntegration.Config.Models;
public class ClmUpdaterSettings
{
  public string Url { get; init; }
  public string HostKey { get; init; }


}
