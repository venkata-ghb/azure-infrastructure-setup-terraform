﻿namespace PostiInitializer.Config;
public class EventBatcherSettings
{
  public string Url { get; init; }
  public string HostKey { get; init; }

}
