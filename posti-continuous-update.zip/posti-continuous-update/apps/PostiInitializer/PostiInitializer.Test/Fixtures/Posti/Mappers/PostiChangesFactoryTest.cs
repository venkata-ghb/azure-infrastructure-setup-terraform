﻿using FluentAssertions;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using PostiInitializer.Posti.Mappers;
using PostiInitializer.Posti.Models;
using PostiInitializer.Test;

namespace PostiIntegration.Test.Posti.Factories;
public class PostiChangesMapperTest
{
  private readonly IPostiChangesMapper _postiChangesMapper;

  public PostiChangesMapperTest(ILogger<PostiChangesMapper> logger)
  {
    _postiChangesMapper = new PostiChangesMapper(logger);
  }

  [Fact]
  public void Create_CheckAddressResponse_ValidAddressValue()
  {
    var mockGetChangesResponse = Utils.ReadFixture("PostiRegistryChange/exampleResponseWithLocalAndForeignAddress.json");
    var deserializedPostiResponse = JsonConvert.DeserializeObject<List<RegistryDto>>(mockGetChangesResponse);

    (var changes, var changesErrors) = _postiChangesMapper.Create(deserializedPostiResponse);

    changes.Should().NotBeNull();
    changes[0].Address.Should().BeNull();
    changes[0].PersonStatus.IsDeceased.Should().BeTrue();
    
  }
}
