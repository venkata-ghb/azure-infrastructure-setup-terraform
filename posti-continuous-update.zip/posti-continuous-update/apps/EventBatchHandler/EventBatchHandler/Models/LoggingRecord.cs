﻿
namespace EventBatchHandler.Models;
public class LoggingRecord
{
  public string CustomerNumber { get; init; }

}

public record EventLoggingRecord
{
  public string CustomerId { get; init; }
  public string EventType { get; init; }
  public string EventTime { get; init; }
}
public record CosmosDBLoggingRecord(string Id);

public record PostiRegistryLoggingRecord(string CustomerNumber, string Operation);
