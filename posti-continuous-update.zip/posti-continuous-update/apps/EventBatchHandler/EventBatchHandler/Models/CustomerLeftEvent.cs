﻿using Newtonsoft.Json;

namespace EventBatchHandler.Models;

/// <summary>
/// Model of the CUSTOMER_LEFT event sent from CLM.
/// Based on the data in the Excel specifying events. Only
/// defines the fields we are interested in.
/// </summary>
public record CustomerLeftEvent
{
  [JsonProperty("eventTime")]
  public string Timestamp { get; init; }

  [JsonProperty("customerId")]
  public string CustomerId { get; init; }

  [JsonProperty("accountType")]
  public string AccountType { get; init; }

  [JsonProperty("addressValidationStatus")]
  public string AddressValidationStatus { get; init; }
}
