﻿using Newtonsoft.Json;

namespace EventBatchHandler.Models;

/// <summary>
/// Model of the CUSTOMER_ENROLLED event sent from CLM.
/// Based on the data in the Excel specifying events. Only
/// defines the fields we are interested in.
/// </summary>
public record CustomerLogEvent
{
  [JsonProperty("eventTime")]
  public string Timestamp { get; init; }
  [JsonProperty("eventType")]
  public string EventType { get; init; }

  [JsonProperty("accountType")]
  public string AccountType { get; init; }

  [JsonProperty("customerId")]
  public string CustomerId { get; init; }

  [JsonProperty("firstName")]
  public string FirstName { get; init; }

  [JsonProperty("lastName")]
  public string LastName { get; init; }

  [JsonProperty("street")]
  public string StreetAddress { get; init; }
  [JsonProperty("address")]
  public string Address { get; init; }

  [JsonProperty("zipCode")]
  public string ZipCode { get; init; }

  [JsonProperty("city")]
  public string City { get; init; }

  [JsonProperty("country")]
  public string Country { get; init; }
  /// <summary>
  /// Birthdate in format DD/MM/YYYY hh:mm:ss
  /// </summary>
  [JsonProperty("birthDate")]
  public string Birthdate { get; init; }

  [JsonProperty("generatedBirthdate")]
  public bool IsGeneratedBirthdate { get; init; } = false;

  [JsonProperty("addressValidationStatus")]
  public string AddressValidationStatus { get; init; }
}
