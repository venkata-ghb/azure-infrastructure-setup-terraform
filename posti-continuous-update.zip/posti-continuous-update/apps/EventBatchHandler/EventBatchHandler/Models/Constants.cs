﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventBatchHandler.Models;
public class Constants
{
  public static readonly PostiOperations[] PostiOperationsToBeChecked = { PostiOperations.Add, PostiOperations.Modify };
}
