﻿using System.Collections.Generic;
using System;
using Newtonsoft.Json;

namespace EventBatchHandler.Models;

/// <summary>
/// Model of the CUSTOMER_BASIC_INFORMATION_UPDATED event sent from CLM.
/// Based on the data in the Excel specifying events. Only
/// defines the fields we are interested in.
/// </summary>


public class AllAttribute
{
  [JsonProperty("code")]
  public string Code { get; set; }

  [JsonProperty("value")]
  public string Value { get; set; }

  [JsonProperty("oldValue")]
  public string OldValue { get; set; }

  [JsonProperty("assignment")]
  public string Assignment { get; set; }
}

public class Assignment
{
  [JsonProperty("code")]
  public string Code { get; set; }

  [JsonProperty("id")]
  public string Id { get; set; }

}

public class Static
{
  [JsonProperty("code")]
  public string Code { get; set; }
}

public class Dynamic
{
  [JsonProperty("code")]
  public string Code { get; set; }
}

public class ModifiedAttribute
{
  [JsonProperty("assignments")]
  public List<Assignment> Assignments { get; set; }
  [JsonProperty("static")]
  public List<Static> Statics { get; set; }
  [JsonProperty("dynamic")]
  public List<Dynamic> Dynamics { get; set; }
}

public class New
{
  [JsonProperty("value")]
  public string Value { get; set; }

  [JsonProperty("startDate")]
  public DateTime StartDate { get; set; }

  [JsonProperty("endDate")]
  public string EndDate { get; set; }
}


public class Permissions
{
  [JsonProperty("adverts")]
  public string Adverts { get; set; }

  [JsonProperty("email")]
  public string Email { get; set; }

  [JsonProperty("facebook")]
  public string Facebook { get; set; }

  [JsonProperty("info")]
  public string Info { get; set; }

  [JsonProperty("phone")]
  public string Phone { get; set; }

  [JsonProperty("post")]
  public string Post { get; set; }

  [JsonProperty("push")]
  public string Push { get; set; }

  [JsonProperty("removeAvatar")]
  public string RemoveAvatar { get; set; }

  [JsonProperty("segmentation")]
  public string Segmentation { get; set; }

  [JsonProperty("sms")]
  public string Sms { get; set; }
}

public record CustomerBasicDataUpdatedEvent
{
  [JsonProperty("eventTime")]
  public string EventTime { get; set; }

  [JsonProperty("eventType")]
  public string EventType { get; set; }

  [JsonProperty("customerId")]
  public string CustomerId { get; set; }
  [JsonProperty("ssn")]
  public string Ssn { get; set; }
  [JsonProperty("customerStatus")]
  public string CustomerStatus { get; set; }
  [JsonProperty("firstName")]
  public string FirstName { get; set; }
  [JsonProperty("lastName")]
  public string LastName { get; set; }
  [JsonProperty("birthDate")]
  public string BirthDate { get; set; }

  [JsonProperty("accountId")]
  public string AccountId { get; set; }

  [JsonProperty("accountType")]
  public string AccountType { get; set; }
  [JsonProperty("addressValidationStatus")]
  public string AddressValidationStatus { get; init; }
  [JsonProperty("generatedBirthdate")]
  public bool IsGeneratedBirthdate { get; init; } = false;
  [JsonProperty("email")]
  public string Email { get; set; }

  [JsonProperty("address")]
  public string Address { get; set; }

  [JsonProperty("zipCode")]
  public string ZipCode { get; set; }

  [JsonProperty("city")]
  public string City { get; set; }

  [JsonProperty("permissions")]
  public Permissions Permissions { get; set; }
  
  [JsonProperty("modifiedAttributes")]
  public ModifiedAttribute? ModifiedAttributes { get; set; }

  [JsonProperty("updater")]
  public string Updater { get; set; }

  [JsonProperty("updateChannel")]
  public string UpdateChannel { get; set; }

  [JsonProperty("allAttributes")]
  public List<AllAttribute> AllAttributes { get; set; }
}
