﻿using System.Text.Json.Serialization;
using Newtonsoft.Json.Converters;

namespace EventBatchHandler.Models;

[JsonConverter(typeof(StringEnumConverter))]
public enum PostiOperations
{
  Add,
  Remove,
  Modify
}

[JsonConverter(typeof(StringEnumConverter))]
public enum EventBatcherOperations
{
  Add,
  Remove,
  Modify
}

public enum PostiOperationDtoBuildStatus
{
  Success,
  EventUnsupported,
  IgnoreableEvent,
  InvalidData
}

public enum FetchUnbatchedOperationsStatus
{
  Success,
  Disabled,
  NoOperationsFound,
  DatabaseError,
}

public enum FetchBatchStatus
{
  Success,
  Disabled,
  ErrorFetchingBatches
}
