﻿using EventBatchHandler.CosmosDb.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace EventBatchHandler.Models;

/// <summary>
/// Internal DTO for an operation to be performed in the
/// Posti registry.
/// </summary>
public record PostiOperationDto
{
  /// <summary>
  /// UNIX timestamp for the when the event was triggered.
  /// </summary>
  public long Timestamp { get; init; }

  /// <summary>
  /// What kind of modification to be performed in the Posti registry.
  /// </summary>
  [JsonConverter(typeof(StringEnumConverter))]
  public PostiOperations Operation { get; init; }

  /// <summary>
  /// Unique customer id provided by the CLM. Also serves as unique
  /// id in Posti.
  /// </summary>
  public string CustomerNumber { get; init; }

  /// <summary>
  /// Social security number in format DDMMYY-XXXX or date of
  /// birth in format DDMMYY. Helps Posti with identification.
  /// </summary>
  public string Ssn { get; init; }

  public string LastName { get; init; }

  public string FirstName { get; init; }

  public string PostalCode { get; init; }

  public string City { get; init; }

  public string Address { get; init; }

  public string Telephone { get; init; }

  public string Email { get; init; }

  public string Extra { get; init; }

  public static PostiOperationDto CreateFromPostiOperationDocument(PostiOperationDocument postiOperation)
  {
    return new PostiOperationDto
    {
      Timestamp = postiOperation.Timestamp,
      Operation = postiOperation.Operation,
      CustomerNumber = postiOperation.CustomerNumber,
      Ssn = postiOperation.Ssn,
      LastName = postiOperation.LastName,
      FirstName = postiOperation.FirstName,
      PostalCode = postiOperation.PostalCode,
      City = postiOperation.City,
      Address = postiOperation.Address,
      Telephone = postiOperation.Telephone,
      Email = postiOperation.Email,
      Extra = postiOperation.Extra
    };
  }
}
