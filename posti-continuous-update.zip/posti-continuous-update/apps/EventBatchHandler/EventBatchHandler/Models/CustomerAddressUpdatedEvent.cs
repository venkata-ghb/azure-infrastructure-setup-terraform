﻿using Newtonsoft.Json;

namespace EventBatchHandler.Models;

/// <summary>
/// Model of the CUSTOMER_ADDRESS_UPDATED event sent from CLM.
/// Based on the data in the Excel specifying events. Only
/// defines the fields we are interested in.
/// </summary>
public record CustomerAddressUpdatedEvent
{
  [JsonProperty("timestamp")]
  public string Timestamp { get; init; }

  [JsonProperty("accountType")]
  public string AccountType { get; init; }

  [JsonProperty("customerId")]
  public string CustomerId { get; init; }

  [JsonProperty("customerStatus")]
  public string CustomerStatus { get; init; }

  [JsonProperty("firstName")]
  public string FirstName { get; init; }

  [JsonProperty("lastName")]
  public string LastName { get; init; }

  [JsonProperty("address")]
  public string StreetAddress { get; init; }

  [JsonProperty("zip")]
  public string ZipCode { get; init; }

  [JsonProperty("city")]
  public string City { get; init; }

  [JsonProperty("country")]
  public string Country { get; init; }

  [JsonProperty("ssn")]
  public string Ssn { get; init; }

  /// <summary>
  /// Birthdate in format DD/MM/YYYY hh:mm:ss
  /// </summary>
  [JsonProperty("birthDate")]
  public string Birthdate { get; init; }

  /// <summary>
  /// Tells us whether we this customer should be tracked
  /// in Posti or not.
  /// </summary>
  [JsonProperty("addressValidationStatus")]
  public string AddressValidationStatus { get; init; }

  /// <summary>
  /// What caused the update to trigger. This can either
  /// be the customer center or API call. We only want to
  /// react to customer center, since we ourselves are the
  /// source of the API triggered events.
  /// </summary>
  [JsonProperty("updater")]
  public string UpdateSource { get; init; }
}
