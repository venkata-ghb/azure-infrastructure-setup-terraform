﻿using Microsoft.Extensions.DependencyInjection;

namespace EventBatchHandler.PostiIntegration;

public static class Extensions
{
  public static IServiceCollection RegisterPostiIntegrationService(this IServiceCollection services)
  {
    services.AddHttpClient<IPostiIntegrationService, PostiIntegrationService>();

    return services;
  }
}
