﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using EventBatchHandler.Config.Models;
using EventBatchHandler.Models;
using EventBatchHandler.PostiIntegration.Models;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace EventBatchHandler.PostiIntegration;

/// <summary>
/// Service responsible for communicating with the
/// PostiIntegration application.
/// </summary>
public interface IPostiIntegrationService
{
  /// <summary>
  /// Send a list of update operations to be performed on Posti's registry.
  /// </summary>
  /// <returns><c>bool</c> indicating if the update went through.</returns>
  public Task<bool> SendOperationsForUpdate(List<PostiOperationDto> operations);
  public  Task<bool> CommitChangesToRegistry();
}

public class PostiIntegrationService : IPostiIntegrationService
{
  private readonly HttpClient _httpClient;
  private readonly PostiIntegrationSettings _settings;
  private readonly ILogger<PostiIntegrationService> _logger;

  public PostiIntegrationService(HttpClient httpClient, PostiIntegrationSettings postiIntSettings, ILogger<PostiIntegrationService> logger)
  {
    _httpClient = httpClient;
    _httpClient.BaseAddress = new System.Uri(postiIntSettings.Url);
    _httpClient.DefaultRequestHeaders.Add("x-functions-key", postiIntSettings.HostKey);
    _httpClient.Timeout = TimeSpan.FromMinutes(5);
    _settings = postiIntSettings;

    _logger = logger;
  }

  public async Task<bool> SendOperationsForUpdate(List<PostiOperationDto> operations)
  {
    var payload = operations.Select(op => UpdateRegistyRequestRecord.FromPostiOperationDto(op)).ToList();
    HttpResponseMessage response;
    foreach (var chunk in payload.Chunk(500))
    {
      var jsonPayload = JsonConvert.SerializeObject(chunk);
      var loggingRecord = JsonConvert.DeserializeObject<List<PostiRegistryLoggingRecord>>(jsonPayload);
      var loggerPayload = JsonConvert.SerializeObject(loggingRecord);
      if (_settings.DisableSendOperationsForUpdate)
      {
        LogSendingOperationsUpdateDisabled();
        return true;
      }
      LogStartSendingOperations(loggerPayload);
      var payloadData = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

      try
      {
        response = await _httpClient.PostAsync("UpdateRegistry", payloadData);
      }
      catch (HttpRequestException ex)
      {
        LogUnexpectedHttpRequestException(ex);
        return false;
      }

      if (!response.IsSuccessStatusCode)
      {
        await HandleUnsuccessfulResponse(response);

        return false;
      }
    }


    LogSendingOperationsSuccess();
    return true;
  }

  public async Task<bool> CommitChangesToRegistry()
  {
    
    HttpResponseMessage response;
   try
      {
        response = await _httpClient.PutAsync("CommitRegistry", null);
      }
      catch (HttpRequestException ex)
      {
        LogUnexpectedHttpRequestException(ex);
        return false;
      }

      if (!response.IsSuccessStatusCode)
      {
        await HandleUnsuccessfulResponse(response);

        return false;
      }

    LogSendingOperationsSuccess();
    return true;
  }


  private async Task HandleUnsuccessfulResponse(HttpResponseMessage response)
  {
    var responseMessage = await response.Content.ReadAsStringAsync();

    switch (response.StatusCode)
    {
      case HttpStatusCode.BadRequest:
        LogBadUpdateRegistyRequest(responseMessage);
        break;

      case HttpStatusCode.RequestTimeout:
        LogRequestTimeout();
        break;

      case HttpStatusCode.InternalServerError:
        LogServerSideError();
        break;

      default:
        LogUnexpectedResponseCode(responseMessage, (int)response.StatusCode);
        break;
    }
  }

  #region Logging functions

  private void LogSendingOperationsUpdateDisabled()
  {
    _logger.LogInformation("Build And Send New Batch Alert. Sending operations to Posti Integration application for registry update is disabled. Skipping sending.\n");
  }

  private void LogStartSendingOperations(string payload)
  {
    _logger.LogInformation("Sending operations to Posti Integration application for registry update.\n" +
      "Payload: {payload}", payload);
  }

  private void LogUnexpectedHttpRequestException(HttpRequestException ex)
  {
    _logger.LogError(ex, "Build And Send New Batch Alert. Registry update request ran into an unexpected error.\n" +
      "Status code: {statusCode}\n" +
      "Message: {errorMessage}\n{stackTrace}",
      ex.StatusCode,
      ex.Message, ex.StackTrace);
  }

  private void LogBadUpdateRegistyRequest(string message)
  {
    _logger.LogError("Build And Send New Batch Alert. Request payload was invalid.\n" +
      "Response message: {responseMessage}.", message);
  }

  private void LogRequestTimeout()
  {
    _logger.LogError("Build And Send New Batch Alert. Sending operations for registry update timed out.");
  }

  private void LogServerSideError()
  {
    _logger.LogError("Build And Send New Batch Alert. Something went wrong in Posti Integration application.");
  }

  private void LogUnexpectedResponseCode(string message, int statusCode)
  {
    _logger.LogError("Build And Send New Batch Alert. Received unexpected response while sending operations for registry update.\n" +
      "Status code: {statusCode}. Response message: {responseMessage}.",
      statusCode, message);
  }

  private void LogSendingOperationsSuccess()
  {
    _logger.LogInformation("Successfully sent operations for registry update.");
  }

  #endregion
}
