﻿using EventBatchHandler.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace EventBatchHandler.PostiIntegration.Models;

public record UpdateRegistyRequestRecord
{
  [JsonProperty("operation")]
  [JsonConverter(typeof(StringEnumConverter))]
  public PostiOperations? Operation { get; init; }

  [JsonProperty("customerNumber")]
  public string CustomerNumber { get; init; }

  [JsonProperty("ssn")]
  public string Ssn { get; init; }

  [JsonProperty("lastName")]
  public string LastName { get; init; }

  [JsonProperty("firstName")]
  public string FirstName { get; init; }

  [JsonProperty("postalCode")]
  public string PostalCode { get; init; }

  [JsonProperty("city")]
  public string City { get; init; }

  [JsonProperty("address")]
  public string Address { get; init; }

  [JsonProperty("telephone")]
  public string Telephone { get; init; }

  [JsonProperty("email")]
  public string Email { get; init; }

  [JsonProperty("extra")]
  public string Extra { get; init; }

  public static UpdateRegistyRequestRecord FromPostiOperationDto(PostiOperationDto dto)
  {
    return new UpdateRegistyRequestRecord
    {
      Operation = dto.Operation,
      CustomerNumber = dto.CustomerNumber,
      Ssn = dto.Ssn,
      LastName = dto.LastName,
      FirstName = dto.FirstName,
      PostalCode = dto.PostalCode,
      City = dto.City,
      Address = dto.Address,
      Telephone = dto.Telephone,
      Email = dto.Email,
      Extra = dto.Extra,
    };
  }
}
