﻿using EventBatchHandler.Config;
using EventBatchHandler.Config.Models;
using EventBatchHandler.CosmosDb;
using EventBatchHandler.Factories;
using EventBatchHandler.PostiIntegration;
using Microsoft.ApplicationInsights.Channel;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;
using NodaTime;

[assembly: FunctionsStartup(typeof(EventBatchHandler.Startup))]

namespace EventBatchHandler;

/// <summary>
///   Initialize Application Insights settings
/// </summary>
public class CloudNameInitializer : ITelemetryInitializer
{
  /// <summary>
  ///   Set the cloud roleName so the service appears correctly in
  ///   the application map and logs
  /// </summary>
  public void Initialize(ITelemetry telemetry)
  {
    telemetry.Context.Cloud.RoleName = "EventBatchHandler";
  }
}

public class Startup : FunctionsStartup
{
  public override void Configure(IFunctionsHostBuilder builder)
  {
    builder.Services.AddLogging();
    builder.Services.AddSingleton<ITelemetryInitializer, CloudNameInitializer>();
    builder.Services.AddScoped<PostiOperationDtoFactory>();
    builder.Services.AddSingleton<IClock>(SystemClock.Instance);
    builder.Services.RegisterCosmosDbService();
    builder.Services.RegisterPostiIntegrationService();
    builder.Services.RegisterConfiguration<CosmosDbSettings>(ServiceLifetime.Scoped);
    builder.Services.RegisterConfiguration<PostiIntegrationSettings>(ServiceLifetime.Scoped);
    builder.Services.RegisterConfiguration<PilotSettings>(ServiceLifetime.Scoped);
  }
}
