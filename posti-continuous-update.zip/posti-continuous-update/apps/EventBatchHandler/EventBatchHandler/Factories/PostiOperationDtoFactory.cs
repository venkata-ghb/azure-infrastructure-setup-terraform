﻿using System;
using System.Linq;
using EventBatchHandler.Config.Models;
using EventBatchHandler.Models;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace EventBatchHandler.Factories;

public class PostiOperationDtoFactory
{
  private readonly PilotSettings _settings;
  public PostiOperationDtoFactory(PilotSettings settings)
  {
    _settings = settings;
  }
  public struct PostiOperationDtoBuildResult
  {
    public PostiOperationDtoBuildStatus Status { get; init; }
    public PostiOperationDto Dto { get; init; }
    //TC-311 - If user needs to be removed and re-added to registry
    public bool? ReAdditionNeeded { get; init; }
  }

  private const string _regularAccountValue = "REGULAR";
  private const string _finlandCountryValue = "FI";
  private const string _notToBeValidatedValue = "NV";
  private const string _reValidateValue = "RW";
  private const string _notIdentifiedValue = "NI";
  private const string _identifiedValue = "I";
  private const string _customerActiveValue = "A";
  private const string _customerClosedValue = "C";
  private const string _customerTerminatedValue = "T";
  private const string _ccUpdateValue = "CC";
  private const string _manualUpdation = "C";
  private const string _postiUpdatesUpdater = "posti_updates";
  private const string _addressValidationStatusCode = "CUS_OSOITEVALIDOINTI";
  private static readonly string[] _validFields = { "firstName", "lastName", "address.street",  "address.zipCode","address.postalCode", "ssn", "birthDate" };

  public PostiOperationDtoBuildResult BuildDto(string messageBody, ILogger logger)
  {
    var readditionNeeded = true;
    if (IsUnsupportedEvent(messageBody))
    {
      LogUnsupportedEvent(logger);
      return new PostiOperationDtoBuildResult { Status = PostiOperationDtoBuildStatus.EventUnsupported };
    }

    PostiOperationDto operationToStore;

    if (messageBody.Contains("CUSTOMER_ENROLLED"))
    {
      var enrollEvent = JsonConvert.DeserializeObject<CustomerEnrolledEvent>(messageBody);

      if (PilotSettingsValidation(_settings, enrollEvent.CustomerId))
      {
        LogNonPilotUserEvent(logger, _settings, enrollEvent.CustomerId);
        return new PostiOperationDtoBuildResult { Status = PostiOperationDtoBuildStatus.IgnoreableEvent };
      }
     if (IgnoreEnrollEvent(enrollEvent, logger)) return new PostiOperationDtoBuildResult { Status = PostiOperationDtoBuildStatus.IgnoreableEvent };
      operationToStore = CreateOperationFromEnrollEvent(enrollEvent);
    }
    else if (messageBody.Contains("CUSTOMER_LEFT"))
    {
      var leftEvent = JsonConvert.DeserializeObject<CustomerLeftEvent>(messageBody);

      if (PilotSettingsValidation(_settings, leftEvent.CustomerId))
      {
        LogNonPilotUserEvent(logger, _settings, leftEvent.CustomerId);
        return new PostiOperationDtoBuildResult { Status = PostiOperationDtoBuildStatus.IgnoreableEvent };
      }

      if (IgnoreLeftEvent(leftEvent, logger)) return new PostiOperationDtoBuildResult { Status = PostiOperationDtoBuildStatus.IgnoreableEvent };
      operationToStore = CreateOperationFromLeftEvent(leftEvent);
    }
    else if (messageBody.Contains("CUSTOMER_BASIC_INFORMATION_UPDATED"))
    {
      var updateEvent = JsonConvert.DeserializeObject<CustomerBasicDataUpdatedEvent>(messageBody);

      if (updateEvent.CustomerStatus == _customerClosedValue || updateEvent.CustomerStatus == _customerTerminatedValue)
      {
        return new PostiOperationDtoBuildResult { Status = PostiOperationDtoBuildStatus.IgnoreableEvent };
      }
      if (IgnoreUpdateEvent(updateEvent, logger)) return new PostiOperationDtoBuildResult { Status = PostiOperationDtoBuildStatus.IgnoreableEvent };

      //TC-311 - If user needs to be removed and re-added to registry
      if (ReAdditionNeededForUser(updateEvent))
      {
        readditionNeeded = true;
      }

      if (ReAdditionNeededForUserForRWStatus(updateEvent))
      {
        readditionNeeded = true;
      }

      operationToStore = GetOperationToStore(updateEvent, messageBody);

      if (operationToStore.Operation == PostiOperations.Remove) { readditionNeeded = false; }
    }
    else
    {
      throw new ArgumentException("Unexpected event type managed to sneak past supported events check. THIS SHOULD NOT HAPPEN!");
    }

    if (DataIsInvalid(operationToStore))
    {
      LogOperationDataInvalid(logger);
      return new PostiOperationDtoBuildResult { Status = PostiOperationDtoBuildStatus.InvalidData, Dto = operationToStore };
    }

    return new PostiOperationDtoBuildResult { Status = PostiOperationDtoBuildStatus.Success, Dto = operationToStore, ReAdditionNeeded = readditionNeeded };
  }

  #region Validation functions
  private static bool ReAdditionNeededForUser(CustomerBasicDataUpdatedEvent updateEvent)
  {
    //TC-311 - If user needs to be removed and re-added to registry
    return (updateEvent.AddressValidationStatus?.ToUpper() == _notIdentifiedValue || updateEvent.AddressValidationStatus?.ToUpper() == _identifiedValue || string.IsNullOrEmpty(updateEvent.AddressValidationStatus?.ToUpper()) || string.IsNullOrWhiteSpace(updateEvent.AddressValidationStatus?.ToUpper()))
      && StaticAttributesContainValidChanges(updateEvent);

  }
  private static bool ReAdditionNeededForUserForRWStatus(CustomerBasicDataUpdatedEvent updateEvent)
  {
    //TC-465 - If user needs to be removed and re-added to registry in case of RW status
    return updateEvent.AddressValidationStatus?.ToUpper() == _reValidateValue
    && updateEvent.CustomerStatus == _customerActiveValue;

  }
  private static bool IsUnsupportedEvent(string eventPayload)
  {
    return
      !eventPayload.Contains("CUSTOMER_ENROLLED") &&
      !eventPayload.Contains("CUSTOMER_LEFT") &&
      !eventPayload.Contains("CUSTOMER_BASIC_INFORMATION_UPDATED");
  }

  private static bool PilotSettingsValidation(PilotSettings settings, string customerId)
  {
    //Validate if pilot is enabled and event customer id is greater than pilot customer id then ignore the event.
    return settings.IsPilotEnabled && int.Parse(customerId) > int.Parse(settings.PilotCustomerId);
  }

  private static bool IgnoreEnrollEvent(CustomerEnrolledEvent enrollEvent, ILogger logger)
  {
    
    if (enrollEvent.AccountType.ToUpper() != _regularAccountValue)
    {
      LogNonRegularAccountType(logger);
      return true;
    }
    if (!string.IsNullOrEmpty(enrollEvent.ZipCode) && enrollEvent.ZipCode.StartsWith("22"))
    {
      LogAhvenanmaaZipCode(logger);
      return true;
    }
    if (!string.IsNullOrEmpty(enrollEvent.StreetAddress) && enrollEvent.StreetAddress.Contains("C/O", StringComparison.OrdinalIgnoreCase))
    {
      LogCareOffUsers(logger);
      return true;
    }
    if (enrollEvent.Country.ToUpper() != _finlandCountryValue)
    {
      LogNonFinnishCustomer(logger);
      return true;
    }
    if (enrollEvent.AddressValidationStatus.ToUpper() == _notToBeValidatedValue)
    {
      LogDontValidateAccount(logger);
      return true;
    }
    
    return false;
  }

  private static bool IgnoreLeftEvent(CustomerLeftEvent leftEvent, ILogger logger)
  {
    
    if (leftEvent.AccountType.ToUpper() != _regularAccountValue)
    {
      LogNonRegularAccountType(logger);
      return true;
    }
    if (leftEvent.AddressValidationStatus.ToUpper() == _notToBeValidatedValue)
    {
      LogDontValidateAccount(logger);
      return true;
    }
    
    return false;
  }

  private static bool IgnoreUpdateEvent(CustomerBasicDataUpdatedEvent basicDataUpdatedEvent, ILogger logger)
  {
   
    if (basicDataUpdatedEvent.Updater == _postiUpdatesUpdater)
    {
      LogInvalidUpdateSource(logger, basicDataUpdatedEvent.Updater);
      return true;
    }
    
    if (basicDataUpdatedEvent.AccountType.ToUpper() != _regularAccountValue)
    {
      LogNonRegularAccountType(logger);
      return true;
    }
    if (!string.IsNullOrEmpty(basicDataUpdatedEvent.ZipCode) && basicDataUpdatedEvent.ZipCode.StartsWith("22"))
    {
      LogAhvenanmaaZipCode(logger);
      return true;
    }
    if (!string.IsNullOrEmpty(basicDataUpdatedEvent.Address) && basicDataUpdatedEvent.Address.Contains("C/O", StringComparison.OrdinalIgnoreCase))
    {
      LogCareOffUsers(logger);
      return true;

    }
    if (basicDataUpdatedEvent.ModifiedAttributes != null &&
      basicDataUpdatedEvent.ModifiedAttributes.Assignments != null &&
      basicDataUpdatedEvent.ModifiedAttributes.Statics != null &&
      basicDataUpdatedEvent.ModifiedAttributes.Assignments.Find(x => x.Code == _addressValidationStatusCode) == null &&
      basicDataUpdatedEvent.ModifiedAttributes.Statics.Find(x => _validFields.ToList().Contains(x.Code)) == null)
    {
      LogInValidPostiData(logger, "No assignment or static attribute details found which are valid for updating Posti registry. Received unsupported event.");
      return true;
    }

    return false;
  }

  private static bool StaticAttributesContainValidChanges(CustomerBasicDataUpdatedEvent basicDataUpdatedEvent)
  {
    if(basicDataUpdatedEvent == null)
    {
      return false;
    }
    if(basicDataUpdatedEvent.ModifiedAttributes.Statics == null)
    {
      return false;
    }
    return basicDataUpdatedEvent.ModifiedAttributes.Statics.Find(x => _validFields.ToList().Contains(x.Code)) != null;
  }

  private static bool DataIsInvalid(PostiOperationDto dto)
  {
    bool IsNullOrEmptyOrWhitespace(string value)
    {
      return string.IsNullOrEmpty(value?.Trim());
    }

    return dto.Operation switch
    {
      PostiOperations.Add => string.IsNullOrEmpty(dto.CustomerNumber) ||
                IsNullOrEmptyOrWhitespace(dto.LastName) ||
                IsNullOrEmptyOrWhitespace(dto.FirstName) ||
                IsNullOrEmptyOrWhitespace(dto.PostalCode) ||
                IsNullOrEmptyOrWhitespace(dto.Address) ||
                (!IsNullOrEmptyOrWhitespace(dto.PostalCode) && dto.PostalCode.Length > 5),
      PostiOperations.Modify => string.IsNullOrEmpty(dto.CustomerNumber) ||
                IsNullOrEmptyOrWhitespace(dto.LastName) ||
                IsNullOrEmptyOrWhitespace(dto.FirstName) ||
                IsNullOrEmptyOrWhitespace(dto.PostalCode) ||
                IsNullOrEmptyOrWhitespace(dto.Address) ||
                (!IsNullOrEmptyOrWhitespace(dto.PostalCode) && dto.PostalCode.Length > 5),
      PostiOperations.Remove => IsNullOrEmptyOrWhitespace(dto.CustomerNumber),
      _ => true,
    };
  }

  #endregion

  #region Builder functions

  private static PostiOperationDto GetOperationToStore(CustomerBasicDataUpdatedEvent updateEvent, string messageBody)
  {
    //If addressValidationStatus field is RW, add the user to Posti register
    if (updateEvent.AddressValidationStatus?.ToUpper() == _reValidateValue && updateEvent.CustomerStatus == _customerActiveValue)
    {
      return CreateOperationFromUpdateEvent(updateEvent, true);
    }
    //If addressValidationStatus field is empty or NI, add the user to Posti register, if the Modified attributes contain valid fields.
    if ((string.IsNullOrEmpty(updateEvent.AddressValidationStatus) || updateEvent.AddressValidationStatus?.ToUpper() == _notIdentifiedValue || string.IsNullOrWhiteSpace(updateEvent.AddressValidationStatus?.ToUpper())) &&
        updateEvent.CustomerStatus == _customerActiveValue && StaticAttributesContainValidChanges(updateEvent))
    {
      return CreateOperationFromUpdateEvent(updateEvent, true);
    }
    //If addressValidationStatus field is NV, remove the user from Posti register
    if (updateEvent.AddressValidationStatus?.ToUpper() == _notToBeValidatedValue)
    {
      var leftEvent = JsonConvert.DeserializeObject<CustomerLeftEvent>(messageBody);
      return CreateOperationFromLeftEvent(leftEvent);
    }

    if (updateEvent.AddressValidationStatus?.ToUpper() == _identifiedValue && ReAdditionNeededForUser(updateEvent))
    {
      return CreateOperationFromUpdateEvent(updateEvent, true);
    }

    return CreateOperationFromUpdateEvent(updateEvent, true);
    
  }

  private static PostiOperationDto CreateOperationFromEnrollEvent(CustomerEnrolledEvent enrollEvent)
  {
    var hasSsn = !string.IsNullOrEmpty(enrollEvent.Ssn);
    var hasRealBirthdate = !string.IsNullOrEmpty(enrollEvent.Birthdate) && !enrollEvent.IsGeneratedBirthdate;
    return new PostiOperationDto()
    {
      Timestamp = Utils.ConvertIso8601StringToUnixTimestamp(enrollEvent.Timestamp),
      Operation = PostiOperations.Add,
      CustomerNumber = enrollEvent.CustomerId,
      Ssn = hasSsn ? enrollEvent.Ssn :
      hasRealBirthdate ? Utils.ParseBirthdateStringToPostiFormat(enrollEvent.Birthdate) :
      "",
      LastName = enrollEvent.LastName,
      FirstName = enrollEvent.FirstName,
      PostalCode = enrollEvent.ZipCode,
      City = enrollEvent.City,
      Address = enrollEvent.StreetAddress,
      Telephone = "",
      Email = "",
      Extra = ""
    };
  }

  private static PostiOperationDto CreateOperationFromUpdateEvent(CustomerBasicDataUpdatedEvent updateEvent, bool isEnrollment)
  {
    var hasSsn = !string.IsNullOrEmpty(updateEvent.Ssn);
    var hasRealBirthdate = !string.IsNullOrEmpty(updateEvent.BirthDate) && !updateEvent.IsGeneratedBirthdate;
    return new PostiOperationDto()
    {
      Timestamp = Utils.ConvertIso8601StringToUnixTimestamp(updateEvent.EventTime),
      Operation = isEnrollment ? PostiOperations.Add : PostiOperations.Modify,
      CustomerNumber = updateEvent.CustomerId,
      Ssn = hasSsn ? updateEvent.Ssn :
      hasRealBirthdate ? Utils.ParseBirthdateStringToPostiFormat(updateEvent.BirthDate) :
      "",
      LastName = updateEvent.LastName,
      FirstName = updateEvent.FirstName,
      PostalCode = updateEvent.ZipCode,
      City = updateEvent.City,
      Address = updateEvent.Address,
      Telephone = "",
      Email = "",
      Extra = ""
    };
  }

  private static PostiOperationDto CreateOperationFromLeftEvent(CustomerLeftEvent leftEvent)
  {
    return new PostiOperationDto()
    {
      Timestamp = Utils.ConvertIso8601StringToUnixTimestamp(leftEvent.Timestamp),
      Operation = PostiOperations.Remove,
      CustomerNumber = leftEvent.CustomerId,
      Ssn = "",
      LastName = "",
      FirstName = "",
      PostalCode = "",
      City = "",
      Address = "",
      Telephone = "",
      Email = "",
      Extra = ""
    };
  }

  #endregion

  #region Logging functions

  private static void LogUnsupportedEvent(ILogger logger)
  {
    logger.LogInformation("Received unsupported event. Skipping event.");
  }
  private static void LogNonPilotUserEvent(ILogger logger, PilotSettings settings, string customerId)
  {
    logger.LogInformation($"Received non pilot (setting is enabled: {settings.IsPilotEnabled} and pilotCustomerId: {settings.PilotCustomerId}) user event. \n" +
      $"Skipping event because the received event customer id is {customerId}.");
  }

  private static void LogInvalidUpdateSource(ILogger logger, string updater)
  {
    logger.LogInformation($"Received event triggered by user other than customer center. Updater: '{updater}'. Ignoring event.");
  }

  private static void LogInactiveAccount(ILogger logger)
  {
    logger.LogInformation("Received event with account marked as other than active. Ignoring event.");
  }
  private static void LogNonProcessCustomerIds(ILogger logger)
  {
    logger.LogInformation("Received customerId cannot be processed as it is greater than 100K. Ignoring event.");
  }
  private static void LogNonRegularAccountType(ILogger logger)
  {
    logger.LogInformation("Received event with account type other than REGULAR. Received unsupported event. Ignoring event.");
  }

  private static void LogAhvenanmaaZipCode(ILogger logger)
  {
    logger.LogInformation("Zip code belongs to Ahvenanmaa. Received unsupported event. Ignoring event.");
  }
  private static void LogCareOffUsers(ILogger logger)
  {
    logger.LogInformation("Address contains care off. Received unsupported event. Ignoring event.");
  }
  
  private static void LogNonFinnishCustomer(ILogger logger)
  {
    logger.LogInformation("Non-Finnish address received. Received unsupported event. Ignoring event.");
  }
  private static void LogOldEvent(ILogger logger, string eventName)
  {
    logger.LogInformation($"{eventName} is an old event. Ignoring event.");
  }
  private static void LogDontValidateAccount(ILogger logger)
  {
    logger.LogInformation("Customer set not to be registered in Posti. Received unsupported event. Ignoring event.");
  }

  private static void LogOperationDataInvalid(ILogger logger)
  {
    logger.LogError("Received event with invalid data.");
  }

  private static void LogInValidPostiData(ILogger logger, string message)
  {
    logger.LogInformation(message);
  }

  #endregion
}
