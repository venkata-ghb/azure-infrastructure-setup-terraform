using System;
using System.Threading.Tasks;
using EventBatchHandler.CosmosDb;
using EventBatchHandler.Models;
using EventBatchHandler.PostiIntegration;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;

namespace EventBatchHandler;

public class BuildAndSendNewBatch
{
  private readonly ICosmosDbService _cosmosService;
  private readonly IPostiIntegrationService _postiIntService;
  private readonly ILogger<BuildAndSendNewBatch> _logger;

  public BuildAndSendNewBatch(ICosmosDbService cosmosService, IPostiIntegrationService postiIntService, ILogger<BuildAndSendNewBatch> logger)
  {
    _cosmosService = cosmosService;
    _postiIntService = postiIntService;
    _logger = logger;
  }

  [FunctionName("BuildAndSendNewBatch")]
  public async Task Run(
        [TimerTrigger("%BuildAndSendNewBatchTriggerSchedule%")] TimerInfo timerInfo)
  {
    LogBatchBuildingRequestReceived();
    try
    {
      var buildResult = await _cosmosService.FetchUnbatchedOperations();
      if (buildResult.Status != FetchUnbatchedOperationsStatus.Success)
      {
        switch (buildResult.Status)
        {
          case FetchUnbatchedOperationsStatus.DatabaseError:
            LogUnbatchedErrors("Build And Send New Batch Alert. FetchUnbatchedOperations operation failed because of database error");
            break;
          case FetchUnbatchedOperationsStatus.NoOperationsFound:
            LogUnbatchedErrors("Build And Send New Batch Alert. No unbatched operations in database.");
            break;
          case FetchUnbatchedOperationsStatus.Disabled:
            LogUnbatchedErrors("Build And Send New Batch Alert. FetchUnbatchedOperations operation is in disabled state.");
            break;
        }
      }
      else
      {
        var updateSuccess = await _postiIntService.SendOperationsForUpdate(buildResult.UniqueOperationDtos);
        if (updateSuccess)
        {
          await _postiIntService.CommitChangesToRegistry();
          var dbStoreSuccess = await _cosmosService.StoreNewBatch(buildResult.OriginalOperations);
        }
      }
      

    }
    catch (Exception ex)
    {
      LogUnexpectedError(ex);

    }
  }

  private void LogBatchBuildingRequestReceived()
  {
    _logger.LogInformation("Received request to build new update batch and send it for processing.");
  }

  private void LogUnbatchedErrors(string message)
  {
    _logger.LogError(message);
  }

  private void LogUnexpectedError(Exception ex)
  {
    _logger.LogError(ex, "Build And Send New Batch Alert. Unexpected exception while building and sending batch.\n" +
      "Error message:{message}\n{stackTrace}",
      ex.Message, ex.StackTrace);
  }
}
