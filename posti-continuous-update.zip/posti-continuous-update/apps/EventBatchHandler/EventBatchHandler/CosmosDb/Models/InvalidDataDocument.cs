﻿using EventBatchHandler.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace EventBatchHandler.CosmosDb.Models;

public record InvalidDataDocument
{
  /// <summary>
  /// Id required by CosmosDB
  /// </summary>
  [JsonProperty("id")]
  public string Id { get; init; }

  /// <summary>
  /// UNIX timestamp for the when the event was triggered.
  /// </summary>
  [JsonProperty("timestamp")]
  public long Timestamp { get; init; }

  /// <summary>
  /// What kind of modification to be performed in the Posti registry.
  /// </summary>
  [JsonProperty("operation")]
  [JsonConverter(typeof(StringEnumConverter))]
  public PostiOperations Operation { get; init; }

  /// <summary>
  /// Unique customer id provided by the CLM. Also serves as unique
  /// id in Posti.
  /// </summary>
  [JsonProperty("customerNumber")]
  public string CustomerNumber { get; init; }

  /// <summary>
  /// The original raw event
  /// </summary>
  [JsonProperty("rawEvent")]
  public string RawEvent { get; init; }

  public static InvalidDataDocument FromPostiOperationDto(PostiOperationDto operation, string rawEvent)
  {
    return new InvalidDataDocument()
    {
      Id = $"{operation.Timestamp}::{operation.CustomerNumber}::{operation.Operation}",
      Timestamp = operation.Timestamp,
      Operation = operation.Operation,
      CustomerNumber = operation.CustomerNumber,
      RawEvent = rawEvent
    };
  }
}
