﻿using System;
using EventBatchHandler.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace EventBatchHandler.CosmosDb.Models;

public record CustomerDocument
{

  [JsonProperty("id")]
  public string Id { get; init; }

  [JsonProperty("timestamp")]
  public DateTime Timestamp { get; init; } = DateTime.Now;

  [JsonProperty("eventType")]
  public string EventType { get; init; }

  [JsonProperty("ttl")]
  public long? Ttl { get; init; }

}
