﻿using EventBatchHandler.Models;

namespace EventBatchHandler.CosmosDb.Models;

public record FetchBatchResult
{
  public FetchBatchStatus Status { get; init; }

  public BatchDocument Batch { get; init; }
}
