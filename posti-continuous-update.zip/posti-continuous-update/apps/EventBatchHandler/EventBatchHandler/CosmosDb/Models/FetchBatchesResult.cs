﻿using System.Collections.Generic;
using EventBatchHandler.Models;

namespace EventBatchHandler.CosmosDb.Models;

public record FetchBatchesResult
{
  public FetchBatchStatus Status { get; init; }

  public List<BatchDocument> Batches { get; init; }
}
