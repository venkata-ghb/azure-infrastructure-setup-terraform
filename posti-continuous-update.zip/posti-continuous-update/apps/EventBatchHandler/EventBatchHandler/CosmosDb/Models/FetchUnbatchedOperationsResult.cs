﻿using System.Collections.Generic;
using EventBatchHandler.Models;

namespace EventBatchHandler.CosmosDb.Models;

public record FetchUnbatchedOperationsResult
{
  /// <summary>
  /// Status field describing the result of the fetch.
  /// </summary>
  public FetchUnbatchedOperationsStatus Status { get; init; }

  /// <summary>
  /// Operation DTOs to pass forward to Posti integration.
  /// Are ordered in ascending order accroding to timestamp.
  /// </summary>
  public List<PostiOperationDto> OperationDtos { get; init; }

  /// <summary>
  /// The original unbatched operations fetched from database.
  /// Needed for 
  /// </summary>
  public List<PostiOperationDocument> OriginalOperations { get; init; }

  public List<PostiOperationDto> UniqueOperationDtos { get; init; }

  public List<PostiOperationDocument> UniqueOriginalOperations { get; init; }
}
