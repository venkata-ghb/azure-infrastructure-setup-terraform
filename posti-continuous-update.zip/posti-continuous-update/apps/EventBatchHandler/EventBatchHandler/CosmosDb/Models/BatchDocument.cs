﻿using System.Collections.Generic;
using EventBatchHandler.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace EventBatchHandler.CosmosDb.Models;

public record BatchDocument
{
  /// <summary>
  /// ISO 8601 timestamp for when batch was created, doubling up as id for the batch.
  /// </summary>
  [JsonProperty("id")]
  public string Id { get; init; }

  [JsonProperty("partitionKey")]
  public string PartitionKey { get; init; }

  [JsonProperty("operations")]
  public List<BatchOperation> Operations { get; init; }
}

public record BatchOperation
{
  /// <summary>
  /// Id of corresponding <c>PostiOperationDocument</c> in the Operations container
  /// </summary>
  [JsonProperty("id")]
  public string Id { get; init; }

  /// <summary>
  /// UNIX timestamp for the when the event was triggered.
  /// </summary>
  [JsonProperty("timestamp")]
  public long Timestamp { get; init; }

  /// <summary>
  /// What kind of modification to be performed in the Posti registry.
  /// </summary>
  [JsonProperty("operation")]
  [JsonConverter(typeof(StringEnumConverter))]
  public PostiOperations Operation { get; init; }

  /// <summary>
  /// Unique customer id provided by the CLM. Also serves as unique
  /// id in Posti.
  /// </summary>
  [JsonProperty("customerNumber")]
  public string CustomerNumber { get; init; }

  /// <summary>
  /// Social security number in format DDMMYY-XXXX or date of
  /// birth in format DDMMYY. Helps Posti with identification.
  /// </summary>
  [JsonProperty("ssn")]
  public string Ssn { get; init; }

  [JsonProperty("lastName")]
  public string LastName { get; init; }

  [JsonProperty("firstName")]
  public string FirstName { get; init; }

  [JsonProperty("postalCode")]
  public string PostalCode { get; init; }

  [JsonProperty("city")]
  public string City { get; init; }

  [JsonProperty("address")]
  public string Address { get; init; }

  [JsonProperty("telephone")]
  public string Telephone { get; init; }

  [JsonProperty("email")]
  public string Email { get; init; }

  [JsonProperty("extra")]
  public string Extra { get; init; }

  public static BatchOperation CreateFromPostiOperationDocument(PostiOperationDocument sourceDoc)
  {
    return new BatchOperation
    {
      Id = sourceDoc.Id,
      Timestamp = sourceDoc.Timestamp,
      Operation = sourceDoc.Operation,
      CustomerNumber = sourceDoc.CustomerNumber,
      Ssn = sourceDoc.Ssn,
      LastName = sourceDoc.LastName,
      FirstName = sourceDoc.FirstName,
      PostalCode = sourceDoc.PostalCode,
      City = sourceDoc.City,
      Address = sourceDoc.Address,
      Telephone = sourceDoc.Telephone,
      Email = sourceDoc.Email,
      Extra = sourceDoc.Extra,
    };
  }
}
