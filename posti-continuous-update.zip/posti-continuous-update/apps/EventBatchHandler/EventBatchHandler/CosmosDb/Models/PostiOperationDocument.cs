﻿using EventBatchHandler.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace EventBatchHandler.CosmosDb.Models;

/// <summary>
/// Model of CosmosDB document representing an operation to be performed
/// in the Posti registry.
/// </summary>
public record PostiOperationDocument
{
  /// <summary>
  /// Id required by CosmosDB
  /// </summary>
  [JsonProperty("id")]
  public string Id { get; init; }

  /// <summary>
  /// The id of the batch the operation is part of. Also
  /// serves as the partition key for operations.
  /// For unsent batches this should be the hardcoded
  /// id denoting the operation as unsent.
  /// </summary>
  [JsonProperty("batchId")]
  public string BatchId { get; init; }

  /// <summary>
  /// UNIX timestamp for the when the event was triggered.
  /// </summary>
  [JsonProperty("timestamp")]
  public long Timestamp { get; init; }

  /// <summary>
  /// What kind of modification to be performed in the Posti registry.
  /// </summary>
  [JsonProperty("operation")]
  [JsonConverter(typeof(StringEnumConverter))]
  public PostiOperations Operation { get; init; }

  /// <summary>
  /// Unique customer id provided by the CLM. Also serves as unique
  /// id in Posti.
  /// </summary>
  [JsonProperty("customerNumber")]
  public string CustomerNumber { get; init; }

  /// <summary>
  /// Social security number in format DDMMYY-XXXX or date of
  /// birth in format DDMMYY. Helps Posti with identification.
  /// </summary>
  [JsonProperty("ssn")]
  public string Ssn { get; init; }

  [JsonProperty("lastName")]
  public string LastName { get; init; }

  [JsonProperty("firstName")]
  public string FirstName { get; init; }

  [JsonProperty("postalCode")]
  public string PostalCode { get; init; }

  [JsonProperty("city")]
  public string City { get; init; }

  [JsonProperty("address")]
  public string Address { get; init; }

  [JsonProperty("telephone")]
  public string Telephone { get; init; }

  [JsonProperty("email")]
  public string Email { get; init; }

  [JsonProperty("extra")]
  public string Extra { get; init; }

  public static PostiOperationDocument FromPostiOperationDto(string batchId, PostiOperationDto operation)
  {
    return new PostiOperationDocument()
    {
      Id = $"{operation.Timestamp}::{operation.CustomerNumber}::{operation.Operation}",
      BatchId = batchId,
      Timestamp = operation.Timestamp,
      Operation = operation.Operation,
      CustomerNumber = operation.CustomerNumber,
      Ssn = operation.Ssn,
      LastName = operation.LastName,
      FirstName = operation.FirstName,
      PostalCode = operation.PostalCode,
      City = operation.City,
      Address = operation.Address,
      Telephone = operation.Telephone,
      Email = operation.Email,
      Extra = operation.Extra,
    };
  }

  public static PostiOperationDocument CreateRemovalDocument(string batchId, PostiOperationDto operation)
  {
    return new PostiOperationDocument()
    {
      Id = $"{operation.Timestamp}::{operation.CustomerNumber}::{PostiOperations.Remove}",
      BatchId = batchId,
      Timestamp = operation.Timestamp,
      Operation = PostiOperations.Remove,
      CustomerNumber = operation.CustomerNumber,
      Ssn = "",
      LastName = "",
      FirstName = "",
      PostalCode = "",
      City = "",
      Address = "",
      Telephone = "",
      Email = "",
      Extra = "",
    };
  }
}
