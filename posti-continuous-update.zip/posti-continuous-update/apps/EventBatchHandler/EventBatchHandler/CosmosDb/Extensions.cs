﻿using EventBatchHandler.Config.Models;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.DependencyInjection;

namespace EventBatchHandler.CosmosDb;

public static class Extensions
{
  public static IServiceCollection RegisterCosmosDbService(this IServiceCollection services)
  {
    services.AddSingleton(serviceProvider =>
    {
      var dbSettings = serviceProvider.GetService<CosmosDbSettings>();
      var options = new CosmosClientOptions
      {
        AllowBulkExecution = true,
      };
      return new CosmosClient(dbSettings.ConnectionString, options);
    });
    services.AddScoped<ICosmosLinqQuery, CosmosLinqQueryWrapper>();
    services.AddScoped<ICosmosDbService, CosmosDbService>();

    return services;
  }
}
