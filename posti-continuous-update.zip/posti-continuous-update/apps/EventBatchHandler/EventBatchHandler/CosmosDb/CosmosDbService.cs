﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Azure;
using EventBatchHandler.Config.Models;
using EventBatchHandler.CosmosDb.Models;
using EventBatchHandler.Models;
using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.DataContracts;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NodaTime;

namespace EventBatchHandler.CosmosDb;

public interface ICosmosDbService
{
  /// <summary>
  /// Store the Posti operation in CosmosDB. New operations will
  /// be stored using the hardcoded un-batched partition key.
  /// The function swallows any CosmosExceptions and logs the data.
  /// This is because if we fail to store the operation there is
  /// not anything else that can be done except logging the data.
  /// We just return a boolean singaling success.
  /// </summary>
  public Task<bool> StoreNewPostiOperation(PostiOperationDto operation, bool? reAdditionNeeded = false);

  /// <summary>
  /// Store operation with invalid data in database for potential
  /// future processing.
  /// </summary>
  public Task<bool> StoreInvalidData(PostiOperationDto operation, string originalBody);

  /// <summary>
  /// Store operations and add customer to CustomersLeftEvent container
  /// </summary>
  /// <param name="operation"></param>
  /// <returns></returns>
  public Task<bool> StorePostiOperationWithCheckForLeftEvent(PostiOperationDto operation);

  /// <summary>
  /// Check if customer exists in CustomersLeftEvent container
  /// </summary>
  /// <param name="operation"></param>
  /// <returns></returns>
  public Task<bool> CheckIfCustomerMarkedAsLeft(string customerId);

  public Task<bool> CheckIfCustomerAddOperationAlreadyExists(PostiOperationDto dto); 
  /// <summary>
  /// Build a new batch out of the currently unbatched operations
  /// in the database.
  /// </summary>
  public Task<FetchUnbatchedOperationsResult> FetchUnbatchedOperations();

  /// <summary>
  /// Store a new batch in the database. The included
  /// operations have their batch id updated to mark them as having
  /// been batched.
  /// </summary>
  public Task<bool> StoreNewBatch(List<PostiOperationDocument> batchOperations);

  /// <summary>
  /// Fetching batch for closest date lower than one provieded in parameter
  /// If the parameter is null return latest batch
  /// </summary>
  public Task<FetchBatchResult> GetBatch(DateTime? batchTime);

  /// <summary>
  /// Fetching all batches
  /// </summary>
  public Task<FetchBatchesResult> GetAllBatches();

  /// <summary>
  /// Fetching all batches
  /// </summary>
  public Task<bool> DeleteOldBatches(DateTime? batchTime = null);

  /// <summary>
  /// Clearing all 3 Cosmos Db Containers
  /// Operations, Batches and InvalidData
  /// </summary>
  public Task<bool> ClearContainers();

  /// <summary>
  /// Helper method for health check calls
  /// </summary>
  /// <returns></returns>
  public Task HealthCheckCall();
}

public class CosmosDbService : ICosmosDbService
{
  private readonly ILogger<CosmosDbService> _logger;
  private readonly IClock _clock;
  private readonly CosmosDbSettings _settings;
  private readonly CosmosClient _cosmosClient;
  private readonly TelemetryClient _telemetryClient;
  private readonly ICosmosLinqQuery _cosmosLinqQueryWrapper;

  // The number of batches should be low enough that we set a
  // single static partition key for all batches. This way we
  // can also fetch all batches without big costs.
  private const string _batchesPartitionKey = "key";
  private readonly ItemRequestOptions _defaultOptions = new() { EnableContentResponseOnWrite = false };

  public CosmosDbService(
    ILogger<CosmosDbService> logger,
    IClock clock,
    CosmosDbSettings settings,
    CosmosClient cosmosClient,
    TelemetryConfiguration telemetryConfiguration,
    ICosmosLinqQuery cosmosLinqQueryWrapper)
  {
    _logger = logger;
    _clock = clock;
    _settings = settings;
    _cosmosClient = cosmosClient;
    _telemetryClient = new TelemetryClient(telemetryConfiguration);
    _cosmosLinqQueryWrapper = cosmosLinqQueryWrapper;
  }

  #region Interface implementation
  public async Task HealthCheckCall()
  {
    await _cosmosClient.GetContainer(_settings.Name, "Operations").ReadContainerAsync();
    await _cosmosClient.GetContainer(_settings.Name, "Configuration").ReadContainerAsync();
  }

  public async Task<bool> StorePostiOperationWithCheckForLeftEvent(PostiOperationDto operation)
  {
    var document = PostiOperationDocument.FromPostiOperationDto(_settings.OperationsUnbatchedPartitionKey, operation);
    if (_settings.DisableStoreNewOperations)
    {
      LogStoringOfNewOperationDisabled();
      return true;
    }
    if(document.Operation == PostiOperations.Remove)
    {
      await StoreRemovedCustomers(new CustomerDocument {
        Id = operation.CustomerNumber,
        EventType = "CUSTOMER_LEFT",
        Ttl = (int)TimeSpan.FromDays(_settings.CustomerLeftDocumentTtl).TotalSeconds
      });
    }

    var operations = await GetUnbatchedAddOperation(operation);
    if (operations != null && operations.Count > 0)
    {
      foreach(var doc in operations)
      {
        await DeletePostiOperation(doc.Id, _settings.OperationsUnbatchedPartitionKey);
      }
    }

    return await StorePostiOperation(document, _settings.OperationsUnbatchedPartitionKey);
  }

  public async Task<bool> StoreNewPostiOperation(PostiOperationDto operation, bool? reAdditionNeeded = false)
  {
    var document = PostiOperationDocument.FromPostiOperationDto(_settings.OperationsUnbatchedPartitionKey, operation);
    if (_settings.DisableStoreNewOperations)
    {
      LogStoringOfNewOperationDisabled();
      return true;
    }
    if(reAdditionNeeded != null && reAdditionNeeded == true)
    {
      var removalDocument = PostiOperationDocument.CreateRemovalDocument(_settings.OperationsUnbatchedPartitionKey, operation);
      LogReAdditionOfCustomer(removalDocument);
      await StorePostiOperation(removalDocument, _settings.OperationsUnbatchedPartitionKey);
      Thread.Sleep(1000);
    }

    var operations = await GetUnbatchedAddOperation(operation);
    if (operations != null && operations.Count > 0)
    {
      foreach (var doc in operations)
      {
        await DeletePostiOperation(doc.Id, _settings.OperationsUnbatchedPartitionKey);
      }
    }

    return await StorePostiOperation(document, _settings.OperationsUnbatchedPartitionKey);
  }

  public async Task<bool> CheckIfCustomerMarkedAsLeft(string customerId)
  {
    var customerDetails = await GetCustomer(customerId);

    if(customerDetails != null)
    {
      return customerDetails.EventType == "CUSTOMER_LEFT";
    }
    return false;
    
  }

  public async Task<bool> CheckIfCustomerAddOperationAlreadyExists(PostiOperationDto dto)
  {
    var customerOperationDetails = await GetCustomerOperation(dto);

    return customerOperationDetails != null && customerOperationDetails.Count > 0;

  }
  private async Task<List<PostiOperationDocument>> GetCustomerOperation(PostiOperationDto dto)
  {
    _logger.LogInformation($"Fetching customer id {dto.CustomerNumber} information from Operations container.");

    var cosmosOperation = new CosmosDependencyOperation("GetCustomerOperation");

    var operationContainer = _cosmosClient.GetContainer(_settings.Name, _settings.OperationsContainer);
    var cosmosQuery = operationContainer
        .GetItemLinqQueryable<PostiOperationDocument>()
        .Where(op => op.BatchId == _settings.OperationsUnbatchedPartitionKey &&
        op.CustomerNumber == dto.CustomerNumber &&
        op.Operation == PostiOperations.Add &&
        op.Address.Equals(dto.Address, StringComparison.OrdinalIgnoreCase) &&
        op.PostalCode == dto.PostalCode &&
        op.City.ToUpper() == dto.City.ToUpper() &&
        op.FirstName.Equals(dto.FirstName, StringComparison.OrdinalIgnoreCase) &&
        op.LastName.Equals(dto.LastName, StringComparison.OrdinalIgnoreCase));

    cosmosOperation.Data = _cosmosLinqQueryWrapper.GetQueryText(cosmosQuery);
    var resultsIterator = _cosmosLinqQueryWrapper.GetFeedIterator(cosmosQuery);

    try
    {
      var results = new List<PostiOperationDocument>();

      while (resultsIterator.HasMoreResults)
      {
        var response = await resultsIterator.ReadNextAsync();
        cosmosOperation.StatusCode = (int)response.StatusCode;
        cosmosOperation.RequestCharge += response.RequestCharge;
        foreach (PostiOperationDocument doc in response)
        {
          results.Add(doc);
        }
      }
      cosmosOperation.Success = true;
      results = results.OrderBy(op => op.Timestamp).ToList();
      var loggingBody = results.Select(x => new CosmosDBLoggingRecord(x.Id)).ToList();
      LogSuccessfullyFetchedOperationsByCustomerNumber(loggingBody);
      
      return results;
    }
    catch (CosmosException ex)
    {
      LogFailedFetchOfOperationsByCustomerId(ex, dto.CustomerNumber);
      cosmosOperation.StatusCode = (int)ex.StatusCode;
      cosmosOperation.RequestCharge = ex.RequestCharge;
      return null;
    }
    finally
    {
      TrackCosmosDependency(cosmosOperation);
    }
  }

  public async Task<List<PostiOperationDocument>> GetUnbatchedAddOperation(PostiOperationDto dto)
  {
    _logger.LogInformation($"Fetching customer id {dto.CustomerNumber} information from Operations container.");

    var cosmosOperation = new CosmosDependencyOperation("GetCustomerOperation");

    var operationContainer = _cosmosClient.GetContainer(_settings.Name, _settings.OperationsContainer);
    var cosmosQuery = operationContainer
        .GetItemLinqQueryable<PostiOperationDocument>()
        .Where(op => op.BatchId == _settings.OperationsUnbatchedPartitionKey &&
        op.CustomerNumber == dto.CustomerNumber &&
        op.Operation == PostiOperations.Add);

    cosmosOperation.Data = _cosmosLinqQueryWrapper.GetQueryText(cosmosQuery);
    var resultsIterator = _cosmosLinqQueryWrapper.GetFeedIterator(cosmosQuery);

    try
    {
      var results = new List<PostiOperationDocument>();

      while (resultsIterator.HasMoreResults)
      {
        var response = await resultsIterator.ReadNextAsync();
        cosmosOperation.StatusCode = (int)response.StatusCode;
        cosmosOperation.RequestCharge += response.RequestCharge;
        foreach (PostiOperationDocument doc in response)
        {
          results.Add(doc);
        }
      }
      cosmosOperation.Success = true;
      results = results.OrderBy(op => op.Timestamp).ToList();
      var loggingBody = results.Select(x => new CosmosDBLoggingRecord(x.Id)).ToList();
      LogSuccessfullyFetchedOperationsByCustomerNumber(loggingBody);

      return results;
    }
    catch (CosmosException ex)
    {
      LogFailedFetchOfOperationsByCustomerId(ex, dto.CustomerNumber);
      cosmosOperation.StatusCode = (int)ex.StatusCode;
      cosmosOperation.RequestCharge = ex.RequestCharge;
      return null;
    }
    finally
    {
      TrackCosmosDependency(cosmosOperation);
    }
  }
  private async Task<CustomerDocument> GetCustomer(string customerId)
  {
    var cosmosOperation = new CosmosDependencyOperation("GetCustomer");
    var partitionKey = new PartitionKey(customerId);

    try
    {
      var customerContainer = _cosmosClient.GetContainer(_settings.Name, _settings.CustomerContainer);
      using ResponseMessage response = await customerContainer.ReadItemStreamAsync(partitionKey: partitionKey,id: customerId);
      if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
      {
        cosmosOperation.StatusCode = (int)response.StatusCode;
        return null;
      }
      if (!response.IsSuccessStatusCode)
      {
        cosmosOperation.StatusCode = (int)response.StatusCode;
        return null;
      }

      LogSuccessfullyFetchedCustomer(customerId);
      using var streamReader = new StreamReader(response.Content);
      var content = await streamReader.ReadToEndAsync();
      return JsonConvert.DeserializeObject<CustomerDocument>(content);
    }
    catch (CosmosException ex)
    {
      LogFailedFetchOfCustomer(ex, customerId);
      cosmosOperation.StatusCode = (int)ex.StatusCode;
      cosmosOperation.RequestCharge = ex.RequestCharge;
      return null;
    }
    finally
    {
      TrackCosmosDependency(cosmosOperation);
    }
  }

  public async Task<bool> StoreInvalidData(PostiOperationDto operation, string originalBody)
  {
    var partitionKey = new PartitionKey(operation.Operation.ToString());
    var document = InvalidDataDocument.FromPostiOperationDto(operation, originalBody);
    if (_settings.DisableStoreInvalidData)
    {
      LogStoringOfInvalidDataDisabled(document);
      return true;
    }

    var cosmosOperation = new CosmosDependencyOperation("StoreInvalidData");

    try
    {
      var operationContainer = _cosmosClient.GetContainer(_settings.Name, _settings.InvalidDataContainer);
      var response = await operationContainer.CreateItemAsync(document, partitionKey, _defaultOptions);
      LogSuccessfulStoringOfInvalidData(document);

      cosmosOperation.Success = true;
      cosmosOperation.StatusCode = (int)response.StatusCode;
      cosmosOperation.RequestCharge = response.RequestCharge;
      return true;
    }
    catch (CosmosException ex)
    {
      LogFailedStoringOfInvalidData(ex, document);
      cosmosOperation.StatusCode = (int)ex.StatusCode;
      cosmosOperation.RequestCharge = ex.RequestCharge;
      return false;
    }
    finally
    {
      TrackCosmosDependency(cosmosOperation);
    }
  }

  public async Task<FetchUnbatchedOperationsResult> FetchUnbatchedOperations()
  {
    if (_settings.DisableBuildNewBatch)
    {
      LogBuildingBatchDisabled();
      return new FetchUnbatchedOperationsResult { Status = FetchUnbatchedOperationsStatus.Disabled };
    }

    LogStartFetchingUnbatchedOperations();

    var unbatchedOperations = await GetOperationsByBatchId(_settings.OperationsUnbatchedPartitionKey);
    if (unbatchedOperations is null) return new FetchUnbatchedOperationsResult { Status = FetchUnbatchedOperationsStatus.DatabaseError };
    if (!unbatchedOperations.Any()) return new FetchUnbatchedOperationsResult { Status = FetchUnbatchedOperationsStatus.NoOperationsFound };

    var groupedRecords = unbatchedOperations.GroupBy(r => r.CustomerNumber).ToList();
    var uniqueUnbatchedOperations = new List<PostiOperationDocument>();

    foreach (var group in groupedRecords)
    {
      var events = group.OrderBy(r => r.Timestamp).ToList(); // Sort by timestamp
      if (events.Count == 1)
      {
        // Only one record, keep it as is
        uniqueUnbatchedOperations.Add(events.First());
        continue;
      }

      //Handling cases where red-Addtition is needed
      if (events.Count >= 2 &&
        events.First().Operation == PostiOperations.Remove &&
        events.Last().Operation == PostiOperations.Add)
      {
        if (await CheckIfCustomerMarkedAsLeft(events.FirstOrDefault().CustomerNumber))
        {
          uniqueUnbatchedOperations.Add(events.First());
          continue;
        }
        uniqueUnbatchedOperations.Add(events.First());
        uniqueUnbatchedOperations.Add(events.Last());
        continue;
      }

      //Handling cases where only remove operations are there
      if (!events.Any(e => e.Operation == PostiOperations.Add) && !events.Any(e => e.Operation == PostiOperations.Modify))
      {
        uniqueUnbatchedOperations.Add(events.First());
        continue;
      }

      // Multiple records exist for this customer
      bool hasAddEvent = events.Any(e => e.Operation == PostiOperations.Add);

      if (hasAddEvent)
      {
        // If "Add" exists, we take the latest event’s data but set operation as "Add"
        var latestEvent = events.Last();
        latestEvent = latestEvent with { Operation = PostiOperations.Add }; // Ensure operation is set to Add
        uniqueUnbatchedOperations.Add(latestEvent);
      }
      else
      {
        // No "Add", take the latest update
        var latestUpdate = events.LastOrDefault(e => e.Operation == PostiOperations.Modify);
        if (latestUpdate != null)
        {
          uniqueUnbatchedOperations.Add(latestUpdate);
        }
      }
    }

    return new FetchUnbatchedOperationsResult
    {
      Status = FetchUnbatchedOperationsStatus.Success,
      OperationDtos = unbatchedOperations
      .OrderBy(op => op.Timestamp)
      .Select(op => PostiOperationDto.CreateFromPostiOperationDocument(op))
      .ToList(),
      OriginalOperations = unbatchedOperations.ToList(),
      UniqueOperationDtos = uniqueUnbatchedOperations?
      .OrderBy(op => op.Timestamp)
      .Select(op => PostiOperationDto.CreateFromPostiOperationDocument(op))
      .ToList(),
      UniqueOriginalOperations = uniqueUnbatchedOperations?.ToList()
    };
  }

  public async Task<bool> StoreNewBatch(List<PostiOperationDocument> batchOperations)
  {
    const int maxBatchSize = 500;

    // Split the operations into chunks of 500
    var batches = batchOperations
        .OrderBy(op => op.Timestamp)
        .Select((op, index) => new { op, index })
        .GroupBy(x => x.index / maxBatchSize)
        .Select(group => group.Select(x => x.op).ToList())
        .ToList();

    foreach (var batch in batches)
    {
      var newBatch = new BatchDocument
      {
        Id = _clock.GetCurrentInstant().ToString("yyyy-MM-ddTHH:mm:ss:fff", CultureInfo.InvariantCulture),
        PartitionKey = _batchesPartitionKey,
        Operations = batch
                .Select(op => BatchOperation.CreateFromPostiOperationDocument(op))
                .ToList()
      };

      if (_settings.DisableStoreNewBatch)
      {
        LogStoringBatchDisabled(newBatch);
        return false;
      }

      var storeBatchSuccess = await StoreBatch(newBatch);
      if (!storeBatchSuccess) return false;

      await UpdateOperationBatchIds(batch, newBatch.Id);
      LogBatchCreationCompleted(newBatch.Id);
    }

    return true;
  }

  public async Task<FetchBatchResult> GetBatch(DateTime? batchTime = null)
  {
    if (_settings.DisableFetchingBatches)
    {
      LogDisabledBatchFetch();
      return new FetchBatchResult() { Status = FetchBatchStatus.Disabled };
    }

    LogBatchRequest(batchTime);
    var allBatchesResult = await GetAllBatches();

    if (allBatchesResult.Status == FetchBatchStatus.ErrorFetchingBatches)
      return new FetchBatchResult() { Status = FetchBatchStatus.ErrorFetchingBatches };

    var allBatchesOrdered = allBatchesResult.Batches.OrderByDescending(x => DateTime.Parse(x.Id));

    //Get closest batch for given DateTime.
    //If batch datetime has no value, return true, so latest batch will be returned
    var predicate = (BatchDocument batch) =>
      batchTime.HasValue ?
      batchTime.Value >= DateTime.Parse(batch.Id).ToUniversalTime() :
      true;

    var resultBatchDocument = allBatchesOrdered.FirstOrDefault(predicate);
    LogFetchedBatch(resultBatchDocument);
    return new FetchBatchResult() { Status = FetchBatchStatus.Success, Batch = resultBatchDocument };

  }

  public async Task<FetchBatchesResult> GetAllBatches()
  {
    if (_settings.DisableFetchingBatches)
    {
      LogDisabledBatchFetch();
      return new FetchBatchesResult() { Status = FetchBatchStatus.Disabled };
    }

    var operationContainer = _cosmosClient.GetContainer(_settings.Name, _settings.BatchesContainer);
    var cosmosQuery = operationContainer
        .GetItemLinqQueryable<BatchDocument>().Select(document => document);
    var cosmosOperation = new CosmosDependencyOperation("GetAllBatches");

    cosmosOperation.Data = _cosmosLinqQueryWrapper.GetQueryText(cosmosQuery);
    var resultsIterator = _cosmosLinqQueryWrapper.GetFeedIterator(cosmosQuery);

    try
    {
      var results = new List<BatchDocument>();

      while (resultsIterator.HasMoreResults)
      {
        var response = await resultsIterator.ReadNextAsync();
        cosmosOperation.StatusCode = (int)response.StatusCode;
        cosmosOperation.RequestCharge += response.RequestCharge;
        foreach (var doc in response)
        {
          results.Add(doc);
        }
      }
      cosmosOperation.Success = true;
      LogSuccessfullyFetchedBatches(results);

      return new FetchBatchesResult() { Status = FetchBatchStatus.Success, Batches = results };
    }
    catch (CosmosException ex)
    {
      LogFailedFetchedBatches(ex);
      cosmosOperation.StatusCode = (int)ex.StatusCode;
      cosmosOperation.RequestCharge = ex.RequestCharge;
      return new FetchBatchesResult() { Status = FetchBatchStatus.ErrorFetchingBatches };
    }
    finally
    {
      TrackCosmosDependency(cosmosOperation);
    }
  }

  public async Task<bool> DeleteOldBatches(DateTime? batchTime = null)
  {
    var allBatchesResult = await GetAllBatches();

    if (allBatchesResult.Status == FetchBatchStatus.Disabled)
      return false;

    if (allBatchesResult.Status == FetchBatchStatus.ErrorFetchingBatches)
      return false;

    var batchesToRemove = batchTime == null ?
      allBatchesResult.Batches :
      allBatchesResult.Batches.Where(batch => DateTime.Parse(batch.Id).ToUniversalTime() <= batchTime).ToList();

    var deletionTasks = new List<Task<bool>>();
    foreach (var batchToRemove in batchesToRemove)
    {
      deletionTasks.Add(DeleteBatch(batchToRemove.Id, _batchesPartitionKey));
    }
    var deletionResults = await Task.WhenAll(deletionTasks);

    return deletionResults.All(x => x);
  }

  public async Task<bool> ClearContainers()
  {
    var deletionTasks = new List<Task<bool>>();
    deletionTasks.Add(DeleteOldBatches());
    deletionTasks.Add(DeletePostiOperations());
    deletionTasks.Add(DeleteAllInvalidData());

    var deletionResults = await Task.WhenAll(deletionTasks);

    return deletionResults.All(x => x);
  }

  #endregion

  #region Private functions

  /// <summary>
  /// Remove batch from batch container by batch id 
  /// </summary>
  /// <param name="batchid"></param>
  /// <param name="batchId"></param>
  /// <returns></returns>
  private async Task<bool> DeleteBatch(string batchId, string partitionKeyString)
  {
    LogDeletingBatch(batchId);

    var partitionKey = new PartitionKey(partitionKeyString);
    var cosmosOperation = new CosmosDependencyOperation("DeleteBatch");

    try
    {
      var operationContainer = _cosmosClient.GetContainer(_settings.Name, _settings.BatchesContainer);
      var response = await operationContainer.DeleteItemAsync<BatchDocument>(batchId, partitionKey, _defaultOptions);
      LogSuccesfulDeletionOfBatch(batchId);

      cosmosOperation.Success = true;
      cosmosOperation.StatusCode = (int)response.StatusCode;
      cosmosOperation.RequestCharge = response.RequestCharge;
      return true;
    }
    catch (CosmosException ex)
    {
      LogFailedDeletionOfBatch(ex, batchId);
      cosmosOperation.StatusCode = (int)ex.StatusCode;
      cosmosOperation.RequestCharge = ex.RequestCharge;
      return false;
    }
    finally
    {
      TrackCosmosDependency(cosmosOperation);
    }
  }

  /// <summary>
  /// Get all stored operations that are part of the given batch.
  /// </summary>
  /// <returns>
  /// A list containing all operations that are part of the
  /// given batch. Returns <c>null</c> in case of an error.
  /// </returns>
  private async Task<IEnumerable<PostiOperationDocument>> GetOperationsByBatchId(string batchId)
  {
    LogFetchingOperationsForBatchId(batchId);

    var cosmosOperation = new CosmosDependencyOperation("GetOperationsByBatchId");

    var operationContainer = _cosmosClient.GetContainer(_settings.Name, _settings.OperationsContainer);
    var cosmosQuery = operationContainer
        .GetItemLinqQueryable<PostiOperationDocument>()
        .Where(op => op.BatchId == batchId);
    cosmosOperation.Data = _cosmosLinqQueryWrapper.GetQueryText(cosmosQuery);
    var resultsIterator = _cosmosLinqQueryWrapper.GetFeedIterator(cosmosQuery);

    try
    {
      var results = new List<PostiOperationDocument>();

      while (resultsIterator.HasMoreResults)
      {
        var response = await resultsIterator.ReadNextAsync();
        cosmosOperation.StatusCode = (int)response.StatusCode;
        cosmosOperation.RequestCharge += response.RequestCharge;
        foreach (PostiOperationDocument doc in response)
        {
          results.Add(doc);
        }
      }
      cosmosOperation.Success = true;
      results = results.OrderBy(op => op.Timestamp).ToList();
      var loggingBody = results.Select(x => new CosmosDBLoggingRecord(x.Id)).ToList();
      LogSuccessfullyFetchedOperationsByBatchId(batchId, loggingBody);
      
      return results;
    }
    catch (CosmosException ex)
    {
      LogFailedFetchOfOperationsByBatchId(ex, batchId);
      cosmosOperation.StatusCode = (int)ex.StatusCode;
      cosmosOperation.RequestCharge = ex.RequestCharge;
      return null;
    }
    finally
    {
      TrackCosmosDependency(cosmosOperation);
    }
  }


  /// <summary>
  /// Get all stored operations that are part of the given batch.
  /// </summary>
  /// <returns>
  /// A list containing all operations that are part of the
  /// given batch. Returns <c>null</c> in case of an error.
  /// </returns>
  private async Task<IEnumerable<PostiOperationDocument>> GetAllOperations()
  {
    LogFetchingAllOperations();

    var cosmosOperation = new CosmosDependencyOperation("GetAllOperations");

    var operationContainer = _cosmosClient.GetContainer(_settings.Name, _settings.OperationsContainer);
    var cosmosQuery = operationContainer
        .GetItemLinqQueryable<PostiOperationDocument>()
        .Select(document => document);
    cosmosOperation.Data = _cosmosLinqQueryWrapper.GetQueryText(cosmosQuery);
    var resultsIterator = _cosmosLinqQueryWrapper.GetFeedIterator(cosmosQuery);

    try
    {
      var results = new List<PostiOperationDocument>();

      while (resultsIterator.HasMoreResults)
      {
        var response = await resultsIterator.ReadNextAsync();
        cosmosOperation.StatusCode = (int)response.StatusCode;
        cosmosOperation.RequestCharge += response.RequestCharge;
        foreach (PostiOperationDocument doc in response)
        {
          results.Add(doc);
        }
      }
      cosmosOperation.Success = true;
      LogSuccessfullyFetchedAllOperations(results);

      return results;
    }
    catch (CosmosException ex)
    {
      LogFailedFetchOfAllOperations(ex);
      cosmosOperation.StatusCode = (int)ex.StatusCode;
      cosmosOperation.RequestCharge = ex.RequestCharge;
      return null;
    }
    finally
    {
      TrackCosmosDependency(cosmosOperation);
    }
  }

  private async Task<bool> StorePostiOperation(PostiOperationDocument document, string batchId)
  {
    LogStoringOfOperation(document);

    var partitionKey = new PartitionKey(batchId);
    var cosmosOperation = new CosmosDependencyOperation("StoreOperation");

    try
    {
      var operationContainer = _cosmosClient.GetContainer(_settings.Name, _settings.OperationsContainer);
      var response = await operationContainer.UpsertItemAsync(document, partitionKey, _defaultOptions);
      LogSuccessfulStoringOfOperation(document);

      cosmosOperation.Success = true;
      cosmosOperation.StatusCode = (int)response.StatusCode;
      cosmosOperation.RequestCharge = response.RequestCharge;
      return true;
    }
    catch (CosmosException ex)
    {
      LogFailedStoringOfOperation(ex, document);
      cosmosOperation.StatusCode = (int)ex.StatusCode;
      cosmosOperation.RequestCharge = ex.RequestCharge;
      return false;
    }
    finally
    {
      TrackCosmosDependency(cosmosOperation);
    }
  }

  private async Task<bool> StoreRemovedCustomers(CustomerDocument document)
  {
    LogStoringOfCustomerLeftDocument(document);

    var partitionKey = new PartitionKey(document.Id);
    var cosmosOperation = new CosmosDependencyOperation("StoreRemovedCustomers");

    try
    {
      var customerContainer = _cosmosClient.GetContainer(_settings.Name, _settings.CustomerContainer);
      var response = await customerContainer.UpsertItemAsync(document, partitionKey, _defaultOptions);
      LogSuccessfulStoringOfCustomerLeftDocument(document);

      cosmosOperation.Success = true;
      cosmosOperation.StatusCode = (int)response.StatusCode;
      cosmosOperation.RequestCharge = response.RequestCharge;
      return true;
    }
    catch (CosmosException ex)
    {
      LogFailedStoringOfCustomerLeftDocument(ex, document);
      cosmosOperation.StatusCode = (int)ex.StatusCode;
      cosmosOperation.RequestCharge = ex.RequestCharge;
      return false;
    }
    finally
    {
      TrackCosmosDependency(cosmosOperation);
    }
  }


  private async Task<bool> DeletePostiOperations()
  {
    var allOperations = await GetAllOperations();

    var deletionTasks = new List<Task<bool>>();
    foreach (var operationToRemove in allOperations)
    {
      deletionTasks.Add(DeletePostiOperation(operationToRemove.Id, operationToRemove.BatchId));
    }
    var deletionResults = await Task.WhenAll(deletionTasks);

    return deletionResults.All(x => x);
  }

  private async Task<List<InvalidDataDocument>> GetAllInvalidData()
  {
    var operationContainer = _cosmosClient.GetContainer(_settings.Name, _settings.InvalidDataContainer);
    var cosmosQuery = operationContainer
        .GetItemLinqQueryable<InvalidDataDocument>().Select(document => document);
    var cosmosOperation = new CosmosDependencyOperation("GetAllInvalidData");

    cosmosOperation.Data = _cosmosLinqQueryWrapper.GetQueryText(cosmosQuery);
    var resultsIterator = _cosmosLinqQueryWrapper.GetFeedIterator(cosmosQuery);

    try
    {
      var results = new List<InvalidDataDocument>();

      while (resultsIterator.HasMoreResults)
      {
        var response = await resultsIterator.ReadNextAsync();
        cosmosOperation.StatusCode = (int)response.StatusCode;
        cosmosOperation.RequestCharge += response.RequestCharge;
        foreach (var doc in response)
        {
          results.Add(doc);
        }
      }
      cosmosOperation.Success = true;
      LogSuccessfullyFetchedAllInvalidData(results);

      return results;
    }
    catch (CosmosException ex)
    {
      LogFailedFetchOfAllInvalidData(ex);
      cosmosOperation.StatusCode = (int)ex.StatusCode;
      cosmosOperation.RequestCharge = ex.RequestCharge;
      return null; ;
    }
    finally
    {
      TrackCosmosDependency(cosmosOperation);
    }
  }

  private async Task<bool> DeleteInvalidData(string invalidDataId, string operation)
  {
    LogDeletingInvalidData(invalidDataId);

    var partitionKey = new PartitionKey(operation);
    var cosmosOperation = new CosmosDependencyOperation("DeleteInvalidData");

    try
    {
      var operationContainer = _cosmosClient.GetContainer(_settings.Name, _settings.InvalidDataContainer);
      var response = await operationContainer.DeleteItemAsync<InvalidDataDocument>(invalidDataId, partitionKey, _defaultOptions);
      LogSuccesfulDeletionOfInvalidData(invalidDataId);

      cosmosOperation.Success = true;
      cosmosOperation.StatusCode = (int)response.StatusCode;
      cosmosOperation.RequestCharge = response.RequestCharge;
      return true;
    }
    catch (CosmosException ex)
    {
      LogFailedDeletionOfInvalidData(ex, invalidDataId);
      cosmosOperation.StatusCode = (int)ex.StatusCode;
      cosmosOperation.RequestCharge = ex.RequestCharge;
      return false;
    }
    finally
    {
      TrackCosmosDependency(cosmosOperation);
    }
  }

  private async Task<bool> DeleteAllInvalidData()
  {
    var allInvalidData = await GetAllInvalidData();

    var deletionTasks = new List<Task<bool>>();
    foreach (var operationToRemove in allInvalidData)
    {
      deletionTasks.Add(DeleteInvalidData(operationToRemove.Id, operationToRemove.Operation.ToString()));
    }
    var deletionResults = await Task.WhenAll(deletionTasks);

    return deletionResults.All(x => x);
  }


  private async Task<bool> DeletePostiOperation(string operationId, string batchId)
  {
    LogDeletingOperation(operationId);

    var partitionKey = new PartitionKey(batchId);
    var cosmosOperation = new CosmosDependencyOperation("DeleteOperation");

    try
    {
      var operationContainer = _cosmosClient.GetContainer(_settings.Name, _settings.OperationsContainer);
      var response = await operationContainer.DeleteItemAsync<PostiOperationDocument>(operationId, partitionKey, _defaultOptions);
      LogSuccesfulDeletionOfOperation(operationId);

      cosmosOperation.Success = true;
      cosmosOperation.StatusCode = (int)response.StatusCode;
      cosmosOperation.RequestCharge = response.RequestCharge;
      return true;
    }
    catch (CosmosException ex)
    {
      LogFailedDeletionOfOperation(ex, operationId);
      cosmosOperation.StatusCode = (int)ex.StatusCode;
      cosmosOperation.RequestCharge = ex.RequestCharge;
      return false;
    }
    finally
    {
      TrackCosmosDependency(cosmosOperation);
    }
  }

  private async Task<bool> StoreBatch(BatchDocument batch)
  {
    LogStoringOfBatch(batch);

    var partitionKey = new PartitionKey(_batchesPartitionKey);
    var cosmosOperation = new CosmosDependencyOperation("StoreBatch");

    try
    {
      var operationContainer = _cosmosClient.GetContainer(_settings.Name, _settings.BatchesContainer);
      var response = await operationContainer.CreateItemAsync(batch, partitionKey, _defaultOptions);

      LogSuccessfulStoringOfBatch(batch.Id);

      cosmosOperation.Success = true;
      cosmosOperation.StatusCode = (int)response.StatusCode;
      cosmosOperation.RequestCharge = response.RequestCharge;
      return true;
    }
    catch (CosmosException ex)
    {
      LogFailedStoringOfBatch(ex, batch.Id);
      cosmosOperation.StatusCode = (int)ex.StatusCode;
      cosmosOperation.RequestCharge = ex.RequestCharge;
      return false;
    }
    finally
    {
      TrackCosmosDependency(cosmosOperation);
    }
  }

  private async Task UpdateOperationBatchIds(IEnumerable<PostiOperationDocument> originalDocs, string newBatchId)
  {
    LogUpdatingOperationBatchIds(newBatchId, originalDocs);

    var deletionTasks = new List<Task<bool>>();
    foreach (var oldDoc in originalDocs)
    {
      deletionTasks.Add(DeletePostiOperation(oldDoc.Id, _settings.OperationsUnbatchedPartitionKey));
    }
    var deletionResults = await Task.WhenAll(deletionTasks);

    var reCreateTasks = new List<Task<bool>>();
    for (int i = 0; i < originalDocs.Count(); i++)
    {
      if (deletionResults[i])
      {
        var newDoc = originalDocs.ElementAt(i) with { BatchId = newBatchId };
        reCreateTasks.Add(StorePostiOperation(newDoc, newBatchId));
      }
    }
    await Task.WhenAll(reCreateTasks);
  }

  private struct CosmosDependencyOperation
  {
    public string Name { get; set; }
    public DateTime StartTime { get; set; } = DateTime.UtcNow;
    public bool Success { get; set; } = false;
    public int StatusCode { get; set; } = 0;
    public double RequestCharge { get; set; } = 0.0;
    public string Data { get; set; } = "";

    public CosmosDependencyOperation(string name)
    {
      Name = name;
    }
  }

  private void TrackCosmosDependency(CosmosDependencyOperation operation)
  {
    var dependency = new DependencyTelemetry()
    {
      Name = operation.Name,
      Target = _cosmosClient.Endpoint.Host,
      Data = operation.Data,
      Type = "Azure DocumentDB",
      Timestamp = operation.StartTime,
      Duration = DateTime.UtcNow - operation.StartTime,
      ResultCode = $"{operation.StatusCode}",
      Success = operation.Success,
    };
    dependency.Properties["requestCharge"] = operation.RequestCharge.ToString(CultureInfo.InvariantCulture);
    _telemetryClient.TrackDependency(dependency);
  }

  #endregion

  #region Logging functions

  private void LogDisabledBatchFetch()
  {
    _logger.LogInformation("Fetching batches was disabled");
  }

  private void LogBuildingBatchDisabled()
  {
    _logger.LogInformation("Batch building is disabled. Skipping building.");
  }

  private void LogStoringBatchDisabled(BatchDocument batch)
  {
    _logger.LogInformation("Storing batches is disabled. Skipping storing.\n" +
      "Batch: {batch}", JsonConvert.SerializeObject(batch));
  }

  private void LogStartFetchingUnbatchedOperations()
  {
    _logger.LogInformation("Beginning fetching of unbatched operations.");
  }

  private void LogBatchCreationCompleted(string batchId)
  {
    _logger.LogInformation("Finished building and storing batch.\n" +
      "Batch id: {batchId}.", batchId);
  }

  private void LogFetchingOperationsForBatchId(string batchId)
  {
    _logger.LogInformation("Fetching all operations in given batch.\n" +
      "Batch id: {batchId}", batchId);
  }

  private void LogReAdditionOfCustomer(PostiOperationDocument removalDocument)
  {
    _logger.LogInformation("ReAddition of customer needed. Removal document created for customer.\n" +
      "Customer id: {customerId}.\n" +
      "Removal Document:\n{removalDocument}", removalDocument.CustomerNumber, JsonConvert.SerializeObject(removalDocument));
  }

  private void LogFetchingAllOperations()
  {
    _logger.LogInformation("Fetching all operations");
  }

  private void LogSuccessfullyFetchedCustomer(string customerId)
  {
    _logger.LogInformation("Successfully fetched customer.\n" +
      "Customer id: {customerId}.\n",
      customerId);
  }
  private void LogSuccessfullyFetchedOperationsByBatchId(string batchId, List<CosmosDBLoggingRecord> fetchedDocs)
  {
    _logger.LogInformation("Successfully fetched operations in given batch.\n" +
      "Batch id: {batchId}.\n" +
      "Documents:\n{documents}",
      batchId,
      string.Join("\n", fetchedDocs.Select(doc => JsonConvert.SerializeObject(doc))));
  }
  private void LogSuccessfullyFetchedOperationsByCustomerNumber(List<CosmosDBLoggingRecord> fetchedDocs)
  {
    _logger.LogInformation("Successfully fetched customer operations in given batch.\n" +
      "Batch id: unbatched.\n" +
      "Documents:\n{documents}",
      string.Join("\n", fetchedDocs.Select(doc => JsonConvert.SerializeObject(doc))));
  }
  private void LogSuccessfullyFetchedAllOperations(List<PostiOperationDocument> fetchedDocs)
  {
    _logger.LogInformation("Successfully fetched all operations.\n" +
      "Documents:\n{documents}",
      string.Join("\n", fetchedDocs.Select(doc => JsonConvert.SerializeObject(doc))));
  }

  private void LogFailedFetchOfCustomer(CosmosException ex, string customerId)
  {
    _logger.LogError(ex, "Failed to fetch customer data for given customerId.\n" +
      "Batch id: {customerId}.\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      customerId,
      ex.Message, ex.StackTrace);
  }
  private void LogFailedFetchOfOperationsByBatchId(CosmosException ex, string batchId)
  {
    _logger.LogError(ex, "Failed to fetch operations for given batch id.\n" +
      "Batch id: {batchId}.\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      batchId,
      ex.Message, ex.StackTrace);
  }

  private void LogFailedFetchOfOperationsByCustomerId(CosmosException ex, string customerId)
  {
    _logger.LogError(ex, "Failed to fetch operations for given customerId.\n" +
      "CustomerId id: {customerId}.\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      customerId,
      ex.Message, ex.StackTrace);
  }

  private void LogFailedFetchOfAllOperations(CosmosException ex)
  {
    _logger.LogError(ex, "Failed to fetch all operations.\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      ex.Message, ex.StackTrace);
  }

  private void LogSuccessfullyFetchedBatches(List<BatchDocument> fetchedBatches)
  {
    _logger.LogInformation("Successfully fetched all batches.\n" +
      "Documents:\n{documents}",
      string.Join("\n", fetchedBatches.Select(doc => JsonConvert.SerializeObject(doc))));
  }

  private void LogFailedFetchedBatches(CosmosException ex)
  {
    _logger.LogError(ex, "Failed to fetch all batches.\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      ex.Message, ex.StackTrace);
  }

  private void LogSuccessfullyFetchedAllInvalidData(List<InvalidDataDocument> fetchedDocs)
  {
    _logger.LogInformation("Successfully fetched all invalid data.\n" +
      "Documents:\n{documents}",
      string.Join("\n", fetchedDocs.Select(doc => JsonConvert.SerializeObject(doc))));
  }

  private void LogFailedFetchOfAllInvalidData(CosmosException ex)
  {
    _logger.LogError(ex, "Failed to fetch all invalid data.\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      ex.Message, ex.StackTrace);
  }

  private void LogStoringOfBatch(BatchDocument batch)
  {
    _logger.LogInformation("Beginning storing of batch.");
  }

  private void LogSuccessfulStoringOfBatch(string batchId)
  {
    _logger.LogInformation("Successfully stored batch in database.\n" +
      "Batch id: {batchId}.", batchId);
  }

  private void LogFailedStoringOfBatch(CosmosException ex, string batchId)
  {
    _logger.LogError(ex, "Failed to store batch in database.\n" +
      "BatchId: {batchId}.\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      batchId,
      ex.Message, ex.StackTrace);
  }

  private void LogUpdatingOperationBatchIds(string newBatchId, IEnumerable<PostiOperationDocument> batchedDocs)
  {
    _logger.LogInformation("Starting update of batch ids for batched operations.\n" +
      "New batch id: {newBatchId}.\n",
      newBatchId);
  }

  private void LogStoringOfNewOperationDisabled()
  {
    _logger.LogInformation("Storing of new operations is disabled. Skipping storage.\n");
  }
  private void LogStoringOfCustomerLeftDocument(CustomerDocument document)
  {
    _logger.LogInformation("Begin storing of customer left document.\n" +
      "Customer number: {customerNumber}. Timestamp: {timestamp}.",
      document.Id, document.Timestamp);
  }

  private void LogSuccessfulStoringOfCustomerLeftDocument(CustomerDocument document)
  {
    _logger.LogInformation("Begin storing of customer left document.\n" +
      "Customer number: {customerNumber}. Timestamp: {timestamp}.",
      document.Id, document.Timestamp);
  }

  private void LogFailedStoringOfCustomerLeftDocument(CosmosException ex, CustomerDocument document)
  {
    _logger.LogError(ex, "Failed to store customer left document in database.\n" +
      "Customer Id: {operationDocument}\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      document.Id,
      ex.Message, ex.StackTrace);
    
  }

  private void LogStoringOfOperation(PostiOperationDocument document)
  {
    _logger.LogInformation("Begin storing of operation document.\n" +
      "Customer number: {customerNumber}. Operation: {operation}. Timestamp: {timestamp}.",
      document.CustomerNumber, document.Operation, document.Timestamp);
  }

  private void LogSuccessfulStoringOfOperation(PostiOperationDocument document)
  {
    _logger.LogInformation("Successfully added operation to database.\n" +
      "Customer number: {customerNumber}. Operation: {operation}. Timestamp: {timestamp}.",
      document.CustomerNumber, document.Operation, document.Timestamp);
  }

  private void LogFailedStoringOfOperation(CosmosException ex, PostiOperationDocument document)
  {
    _logger.LogError(ex, "Failed to store operation in database.\n" +
      "Operation: {operationDocument}\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      document.Id,
      ex.Message, ex.StackTrace);
  }

  private void LogDeletingOperation(string operationId)
  {
    _logger.LogInformation("Begin deletion of operation from database.\n" +
      "Operation id: {operationId}.", operationId);
  }

  private void LogDeletingBatch(string batchId)
  {
    _logger.LogInformation("Begin deletion of Batch from database.\n" +
      "Batch id: {batchId}.", batchId);
  }

  private void LogSuccesfulDeletionOfOperation(string operationId)
  {
    _logger.LogInformation("Successfully deleted operation.\n" +
      "Operation id: {operationId}.", operationId);
  }

  private void LogSuccesfulDeletionOfBatch(string batchId)
  {
    _logger.LogInformation("Successfully deleted batch.\n" +
      "Batch id: {batchId}.", batchId);
  }

  private void LogDeletingInvalidData(string invalidDataId)
  {
    _logger.LogInformation("Begin deletion of invalid data from database.\n" +
      "Invalid data id: {operationId}.", invalidDataId);
  }

  private void LogSuccesfulDeletionOfInvalidData(string invalidDataId)
  {
    _logger.LogInformation("Successfully deleted invalid data.\n" +
      "Operation id: {operationId}.", invalidDataId);
  }

  private void LogFailedDeletionOfInvalidData(CosmosException ex, string invalidDataId)
  {
    _logger.LogError(ex, "Failed to delete invalid data.\n" +
      "Operation id: {operationId}.\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      invalidDataId,
      ex.Message, ex.StackTrace);
  }

  private void LogFailedDeletionOfOperation(CosmosException ex, string operationId)
  {
    _logger.LogError(ex, "Failed to delete operation.\n" +
      "Operation id: {operationId}.\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      operationId,
      ex.Message, ex.StackTrace);
  }

  private void LogFailedDeletionOfBatch(CosmosException ex, string batchId)
  {
    _logger.LogError(ex, "Failed to delete batch.\n" +
      "Batch id: {batchId}.\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      batchId,
      ex.Message, ex.StackTrace);
  }

  private void LogStoringOfInvalidDataDisabled(InvalidDataDocument document)
  {
    _logger.LogInformation("Storage of invalid data is disabled. Skipping storage.\n" +
      "Customer number: {customerNumber}. Operation: {operation}. Timestamp: {timestamp}.",
      document.CustomerNumber, document.Operation, document.Timestamp);
  }

  private void LogStoringOfInvalidData(InvalidDataDocument document)
  {
    _logger.LogInformation("Begin storing of invalid data document.\n" +
      "Invalid data: {invalidDataDocument}", JsonConvert.SerializeObject(document));
  }

  private void LogSuccessfulStoringOfInvalidData(InvalidDataDocument document)
  {
    _logger.LogInformation("Successfully added invalid data to database.\n" +
      "Customer number: {customerNumber}. Operation: {operation}. Timestamp: {timestamp}.",
      document.CustomerNumber, document.Operation, document.Timestamp);
  }

  private void LogFailedStoringOfInvalidData(CosmosException ex, InvalidDataDocument document)
  {
    _logger.LogError(ex, "Failed to store invalid data in database.\n" +
      "Customer number: {customerNumber}. Operation: {operation}. Timestamp: {timestamp}.\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      document.CustomerNumber, document.Operation, document.Timestamp,
      ex.Message, ex.StackTrace);
  }

  private void LogFetchedBatch(BatchDocument resultBatchDocument)
  {
    _logger.LogInformation("Batch fetched");
  }

  private void LogBatchRequest(DateTime? batchTime)
  {
    _logger.LogInformation("Fetched batch time.\n" +
          "DateTime: {batchTime}", batchTime.HasValue ? batchTime.Value : null);
  }

  #endregion
}
