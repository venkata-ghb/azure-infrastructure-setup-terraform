using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EventBatchHandler.CosmosDb;
using EventBatchHandler.Factories;
using EventBatchHandler.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace EventBatchHandler;
public class StoreCaputredEvents
{
  private readonly ILogger<StoreCaputredEvents> _logger;
  private readonly ICosmosDbService _cosmosDbService;
  private readonly PostiOperationDtoFactory _dtoFactory;

  public StoreCaputredEvents(ILogger<StoreCaputredEvents> logger, ICosmosDbService cosmosDbService, PostiOperationDtoFactory dtoFactory)
  {
    _logger = logger;
    _cosmosDbService = cosmosDbService;
    _dtoFactory = dtoFactory;
  }

  [FunctionName("StoreCaputredEvents")]
  public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req)
  {
    IList<JObject> records = null;
    IList<bool> results = new List<bool>();
    try
    {
      //Get body and deserialize it into JObject
      var json = await req.ReadAsStringAsync();
      records = JsonConvert.DeserializeObject<IList<JObject>>(json);
      foreach (var record in records)
      {
        var messageBody = JsonConvert.SerializeObject(record);
        LogReceivedEvent(messageBody);
        var buildResult = _dtoFactory.BuildDto(messageBody, _logger);
        var success = buildResult.Status switch
        {
          PostiOperationDtoBuildStatus.InvalidData => await _cosmosDbService.StoreInvalidData(buildResult.Dto, messageBody),
          PostiOperationDtoBuildStatus.Success => await _cosmosDbService.StoreNewPostiOperation(buildResult.Dto),
          PostiOperationDtoBuildStatus.EventUnsupported => true,
          PostiOperationDtoBuildStatus.IgnoreableEvent => true,
          _ => false
        };
        results.Add(success);
      }

      if (results.Any(item => item != true))
        return new StatusCodeResult(StatusCodes.Status500InternalServerError);

      return new NoContentResult();
    }
    catch (Exception ex)
    {
      LogUnexpectedError(ex);
      return new StatusCodeResult(StatusCodes.Status500InternalServerError);
    }
  }

  private void LogUnexpectedError(Exception ex)
  {
    _logger.LogError("There was an unexpected error:\n" +
        "Error: {error}\n" +
        "Stack trace: {trace}",
        ex, ex.StackTrace);
  }

  private void LogReceivedEvent(string eventBody)
  {
    _logger.LogInformation("Captured event body.\n" +
      "Event body:\n{eventBody}", eventBody);
  }
}
