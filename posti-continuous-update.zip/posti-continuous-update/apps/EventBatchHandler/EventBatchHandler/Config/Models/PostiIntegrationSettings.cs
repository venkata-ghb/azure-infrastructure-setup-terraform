﻿namespace EventBatchHandler.Config.Models;

public class PostiIntegrationSettings : ICustomApplicationSetting
{
  public string Url { get; init; }
  public string HostKey { get; init; }
  // Feature flags
  public bool DisableSendOperationsForUpdate { get; init; }
}
