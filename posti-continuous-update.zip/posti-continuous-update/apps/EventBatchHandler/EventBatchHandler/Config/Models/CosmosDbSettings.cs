﻿namespace EventBatchHandler.Config.Models;
public class CosmosDbSettings : ICustomApplicationSetting
{
  public string Name { get; init; }
  public string ConnectionString { get; init; }
  public string InvalidDataContainer { get; init; }
  public string OperationsContainer { get; init; }
  public string OperationsUnbatchedPartitionKey { get; init; }
  public string BatchesContainer { get; init; }
  public string CustomerContainer { get; init; }
  public int CustomerLeftDocumentTtl { get; init; }
  // Feature flags
  public bool DisableStoreNewOperations { get; init; }
  public bool DisableStoreInvalidData { get; init; }
  public bool DisableBuildNewBatch { get; init; }
  public bool DisableStoreNewBatch { get; init; }
  public bool DisableFetchingBatches { get; init; }
}
