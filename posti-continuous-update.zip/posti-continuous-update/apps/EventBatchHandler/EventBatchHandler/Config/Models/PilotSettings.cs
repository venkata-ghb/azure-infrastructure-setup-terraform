﻿namespace EventBatchHandler.Config.Models;

public class PilotSettings : ICustomApplicationSetting
{
  public string PilotCustomerId { get; init; }
  public bool IsPilotEnabled { get; init; }
}
