using System;
using System.Threading.Tasks;
using EventBatchHandler.CosmosDb;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;

namespace EventBatchHandler;
public class DeleteOldBatches
{
  private readonly ILogger<DeleteOldBatches> _logger;
  private readonly ICosmosDbService _cosmosDbService;

  public DeleteOldBatches(ILogger<DeleteOldBatches> logger, ICosmosDbService cosmosDbService)
  {
    _logger = logger;
    _cosmosDbService = cosmosDbService;
  }

  [FunctionName("DeleteOldBatches")]
  public async Task Run(
        [TimerTrigger("0 30 23 * * *")] TimerInfo timerInfo)
  {
    try
    {
      //Get parameter and delete records
      var batchDateTime = DateTime.Now.AddDays(-30);
      var batchResult = await _cosmosDbService.DeleteOldBatches(batchDateTime);

      if (batchResult != true)
        LogMessages("Failed to process delete old batches or no batches to process");

      else
        LogMessages("Old batch deletion successful");
    }
    catch (Exception ex)
    {
      LogUnexpectedError(ex);
    }
  }

  private DateTime? GetBatchDateTimeFromQueryParam(HttpRequest req)
  {
    var batchDateTimeQuery = req.Query["BatchDateTime"];
    if (string.IsNullOrEmpty(batchDateTimeQuery))
    {
      LogEmptyBatchDateTime();
      return null;
    }

    LogBatchRequest(batchDateTimeQuery);
    return DateTime.Parse(batchDateTimeQuery).ToUniversalTime();
  }

  private void LogEmptyBatchDateTime()
  {
    _logger.LogInformation("Batch DateTime is empty. Delete all batches");
  }
  private void LogMessages(string message)
  {
    _logger.LogInformation(message);
  }

  private void LogBatchRequest(string dateTimeRequest)
  {
    _logger.LogInformation("Incoming batch deletion request request\n" +
      "Batch deletion request dateTime: {request}", dateTimeRequest);
  }
  private void LogUnexpectedError(Exception ex)
  {
    _logger.LogError("There was an unexpected error:\n" +
        "Error: {error}\n" +
        "Stack trace: {trace}",
        ex, ex.StackTrace);
  }
}
