using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Azure.Messaging.EventHubs;
using EventBatchHandler.CosmosDb;
using EventBatchHandler.Factories;
using EventBatchHandler.Models;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace EventBatchHandler;

public class ReceiveLifecycleEvent
{
  private readonly ICosmosDbService _dbService;
  private readonly PostiOperationDtoFactory _dtoFactory;
  private readonly ILogger<ReceiveLifecycleEvent> _logger;

  public ReceiveLifecycleEvent(ICosmosDbService dbService, PostiOperationDtoFactory dtoFactory, ILogger<ReceiveLifecycleEvent> logger)
  {
    _dbService = dbService;
    _dtoFactory = dtoFactory;
    _logger = logger;
  }

  [FunctionName("ReceiveLifecycleEvent")]
  public async Task Run(
    [EventHubTrigger(
    "%CustomerLifeCycleHub:hubName%",
    Connection = "CustomerLifeCycleHub",
    ConsumerGroup = "%CustomerLifeCycleHub:consumerGroupName%")] EventData lifeCycleEvent)
  {
    string messageBody = Encoding.UTF8.GetString(lifeCycleEvent.EventBody);
    try
    {
      LogReceivedEvent(messageBody);
      var buildResult = _dtoFactory.BuildDto(messageBody, _logger);
      /**
       * Check if the customer has already left (has trigerred CUSTOMER_LEFT event from CLM).
       * Do not send such events to Posti.
       * Customers are kept in Customer container and validated customer's existence in the container.
       * Check ticket TC-305
      **/
      if (buildResult.Status == PostiOperationDtoBuildStatus.Success && await IsCustomerMarkedAsLeftInClm(buildResult.Dto))
      {
        _logger.LogInformation($"{buildResult.Dto.CustomerNumber} Customer was marked as CUSTOMER_LEFT previously. Ignoring event.");
      }
      /**
       * If customer already exists as an 'unbatched' operation (New operation not sent to posti yet), and if a new event comes
       * which contains similar customer data as the existing saved operation, do not send such duplicate events to Posti.
       * Data checked is as follows:
       * Operation type is ADD, Matches customerNumber, matches Address, matches Postal Code, matches City and matches First
       * and Last Name.
       **/ 
      else if (buildResult.Status == PostiOperationDtoBuildStatus.Success && await CustomerAlreadyExists(buildResult.Dto))
      {
        _logger.LogInformation($"{buildResult.Dto.CustomerNumber} Customer with ADD operation already exists in Unbatched operations. Ignoring event.");
      }
      else
      {
        var success = buildResult.Status switch
        {
          PostiOperationDtoBuildStatus.InvalidData => await _dbService.StoreInvalidData(buildResult.Dto, messageBody),
          PostiOperationDtoBuildStatus.Success => await _dbService.StorePostiOperationWithCheckForLeftEvent(buildResult.Dto),
          PostiOperationDtoBuildStatus.EventUnsupported => true,
          PostiOperationDtoBuildStatus.IgnoreableEvent => true,
          _ => false
        };
      }
      
    }
    catch (Exception ex)
    {
      LogUnexpectedError(ex, messageBody);
    }
  }

  //This check is make sure that the customer is not re-added to posti register
  private async Task<bool> IsCustomerMarkedAsLeftInClm(PostiOperationDto operationDto)
  {
    return Constants.PostiOperationsToBeChecked.Contains(operationDto.Operation)
      && await _dbService.CheckIfCustomerMarkedAsLeft(operationDto.CustomerNumber);
    
  }

  private async Task<bool> CustomerAlreadyExists(PostiOperationDto operationDto)
  {
    return operationDto.Operation == PostiOperations.Add
      && await _dbService.CheckIfCustomerAddOperationAlreadyExists(operationDto);
  }
  #region Logging functions

  private void LogReceivedEvent(string eventBody)
  {
    var customerData = JsonConvert.DeserializeObject<CustomerLogEvent>(eventBody);
    _logger.LogInformation("Received event from customer life cycle hub.\n" +
      "Event Time: {time}\n" +
      "Event Type: {eventType}\n" +
      "Customer Id: {customerId}\n" +
      "Last Name: {lastName}\n" +
      "Address Validation Status: {addressValidationStatus}\n" +
      "Account Type: {accountType}\n" +
      "Is Generated Birthdate: {isGenerated}\n",
      customerData.Timestamp,
      customerData.EventType,
      customerData.CustomerId,
      customerData.LastName ,
      customerData.AddressValidationStatus,
      customerData.AccountType,
      customerData.IsGeneratedBirthdate);
  }

  private void LogUnexpectedError(Exception ex, string body)
  {
    var customerData = JsonConvert.DeserializeObject<CustomerLogEvent>(body);
    _logger.LogError(ex,
      "Unexpected error while receiving event.\n" +
      "Event Time: {time}\n" +
      "Event Type: {eventType}\n" +
      "Customer Id: {customerId}\n" +
      "Last Name: {lastName}\n" +
      "Address Validation Status: {addressValidationStatus}\n" +
      "Account Type: {accountType}\n" +
      "Is Generated Birthdate: {isGenerated}\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      customerData.Timestamp,
      customerData.EventType,
      customerData.CustomerId,
      customerData.LastName,
      customerData.AddressValidationStatus,
      customerData.AccountType,
      customerData.IsGeneratedBirthdate,
      ex.Message, ex.StackTrace);
  }

  #endregion
}
