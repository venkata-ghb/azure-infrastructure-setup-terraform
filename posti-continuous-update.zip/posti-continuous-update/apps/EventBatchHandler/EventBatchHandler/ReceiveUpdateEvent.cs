using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Azure.Messaging.EventHubs;
using EventBatchHandler.CosmosDb;
using EventBatchHandler.Factories;
using EventBatchHandler.Models;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace EventBatchHandler;

public class ReceiveUpdateEvent
{
  private readonly ICosmosDbService _dbService;
  private readonly PostiOperationDtoFactory _dtoFactory;
  private readonly ILogger<ReceiveUpdateEvent> _logger;

  public ReceiveUpdateEvent(ICosmosDbService dbService, PostiOperationDtoFactory dtoFactory, ILogger<ReceiveUpdateEvent> logger)
  {
    _dbService = dbService;
    _dtoFactory = dtoFactory;
    _logger = logger;
  }

  [FunctionName("ReceiveUpdateEvent")]
  public async Task Run(
    [EventHubTrigger(
    "%CustomerInfoUpdateHub:hubName%",
    Connection = "CustomerLifeCycleHub",
    ConsumerGroup = "%CustomerInfoUpdateHub:consumerGroupName%")] EventData updateEvent)
  {
    string messageBody = Encoding.UTF8.GetString(updateEvent.EventBody);
    try
    {
      LogReceivedEvent(messageBody);
      var buildResult = _dtoFactory.BuildDto(messageBody, _logger);
      if (buildResult.Status == PostiOperationDtoBuildStatus.Success && await IsCustomerMarkedAsLeftInClm(buildResult.Dto))
      {
        _logger.LogInformation($"{buildResult.Dto.CustomerNumber} Customer was marked as CUSTOMER_LEFT previously. Ignoring event.");
      }
      else if (buildResult.Status == PostiOperationDtoBuildStatus.Success && await CustomerAlreadyExists(buildResult.Dto))
      {
        _logger.LogInformation($"{buildResult.Dto.CustomerNumber} Customer with ADD operation already exists in Unbatched operations. Ignoring event.");
      }
      else
      {
        var success = buildResult.Status switch
        {
          PostiOperationDtoBuildStatus.InvalidData => await _dbService.StoreInvalidData(buildResult.Dto, messageBody),
          PostiOperationDtoBuildStatus.Success => await _dbService.StoreNewPostiOperation(buildResult.Dto, buildResult.ReAdditionNeeded),
          PostiOperationDtoBuildStatus.EventUnsupported => true,
          PostiOperationDtoBuildStatus.IgnoreableEvent => true,
          _ => false
        };
      }
      
    }
    catch (Exception ex)
    {
      LogUnexpectedError(ex, messageBody);
    }
  }
  //This check is make sure that the customer is not re-added to posti register
  private async Task<bool> IsCustomerMarkedAsLeftInClm(PostiOperationDto operationDto)
  {
    return Constants.PostiOperationsToBeChecked.Contains(operationDto.Operation)
      && await _dbService.CheckIfCustomerMarkedAsLeft(operationDto.CustomerNumber);
  }
  private async Task<bool> CustomerAlreadyExists(PostiOperationDto operationDto)
  {
    return operationDto.Operation == PostiOperations.Add
      && await _dbService.CheckIfCustomerAddOperationAlreadyExists(operationDto);
  }
  #region Logging functions

  private void LogReceivedEvent(string eventBody)
  {
    var customerData = JsonConvert.DeserializeObject<CustomerLogEvent>(eventBody);
    _logger.LogInformation("Received event from customer update hub.\n" +
      "Event Time: {time}\n" +
      "Event Type: {eventType}\n" +
      "Customer Id: {customerId}\n" +
      "Last Name: {lastName}\n" +
      "Address Validation Status: {addressValidationStatus}\n" +
      "Account Type: {accountType}\n" +
      "Is Generated Birthdate: {isGenerated}\n",
      customerData.Timestamp,
      customerData.EventType,
      customerData.CustomerId,
      customerData.LastName,
      customerData.AddressValidationStatus,
      customerData.AccountType,
      customerData.IsGeneratedBirthdate);
  }

  private void LogUnexpectedError(Exception ex, string body)
  {
    var customerData = JsonConvert.DeserializeObject<CustomerLogEvent>(body);
    _logger.LogError(ex,
      "Unexpected error while receiving event.\n" +
      "Event Time: {time}\n" +
      "Event Type: {eventType}\n" +
      "Customer Id: {customerId}\n" +
      "Last Name: {lastName}\n" +
      "Address Validation Status: {addressValidationStatus}\n" +
      "Account Type: {accountType}\n" +
      "Is Generated Birthdate: {isGenerated}\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      customerData.Timestamp,
      customerData.EventType,
      customerData.CustomerId,
      customerData.LastName,
      customerData.AddressValidationStatus,
      customerData.AccountType,
      customerData.IsGeneratedBirthdate,
      ex.Message, ex.StackTrace);
  }

  #endregion
}
