using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using EventBatchHandler.CosmosDb;
using EventBatchHandler.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;

namespace EventBatchHandler;
public class GetBatch
{
  private readonly ILogger<GetBatch> _logger;
  private readonly ICosmosDbService _cosmosDbService;

  public GetBatch(ILogger<GetBatch> logger, ICosmosDbService cosmosDbService)
  {
    _logger = logger;
    _cosmosDbService = cosmosDbService;
  }

  [FunctionName("GetBatch")]
  public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "get", Route = null)] HttpRequest req)
  {
    try
    {
      //Get parameter and fetch records
      var batchDateTime = GetBatchDateTimeFromQueryParam(req);
      var batchResult = await _cosmosDbService.GetBatch(batchDateTime);

      //Return Internal error if disabled or when cosmos db Error found
      if (batchResult.Status == FetchBatchStatus.Disabled) return new StatusCodeResult(StatusCodes.Status500InternalServerError);
      if (batchResult.Status == FetchBatchStatus.ErrorFetchingBatches) return new StatusCodeResult(StatusCodes.Status500InternalServerError);

      //Map cosmos document to dto and return 
      var batchRecordsDto = new List<BatchRecordDto>();
      batchResult.Batch?.Operations.ForEach(operation => batchRecordsDto.Add(BatchRecordDto.CreateFromBatchOperation(operation)));

      return new OkObjectResult(batchRecordsDto);
    }
    catch (Exception ex)
    {
      LogUnexpectedError(ex);
      return new StatusCodeResult(StatusCodes.Status500InternalServerError);
    }
  }

  private DateTime? GetBatchDateTimeFromQueryParam(HttpRequest req)
  {
    var batchDateTimeQuery = req.Query["BatchDateTime"];
    if (string.IsNullOrEmpty(batchDateTimeQuery))
    {
      LogEmptyBatchDateTime();
      return null;
    }

    LogBatchRequest(batchDateTimeQuery);
    return DateTime.Parse(batchDateTimeQuery).ToUniversalTime();
  }

  private void LogEmptyBatchDateTime()
  {
    _logger.LogInformation("Batch DateTime is empty. Query for the latest batch");
  }

  private void LogBatchRequest(string dateTimeRequest)
  {
    _logger.LogInformation("Incoming batch request\n" +
      "Batch request dateTime: {request}", dateTimeRequest);
  }
  private void LogUnexpectedError(Exception ex)
  {
    _logger.LogError("There was an unexpected error:\n" +
        "Error: {error}\n" +
        "Stack trace: {trace}",
        ex, ex.StackTrace);
  }
}
