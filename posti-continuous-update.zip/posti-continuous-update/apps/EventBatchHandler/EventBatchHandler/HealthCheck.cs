using System;
using System.Threading.Tasks;
using System.Web.Http;
using EventBatchHandler.CosmosDb;
using EventBatchHandler.PostiIntegration;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;

namespace EventBatchHandler;

public class HealthCheck
{
  private readonly ICosmosDbService _cosmosService;
  private readonly ILogger<HealthCheck> _logger;

  public HealthCheck(ICosmosDbService cosmosService, ILogger<HealthCheck> log)
  {
    _cosmosService = cosmosService;
    _logger = log;
  }
  [FunctionName("HealthCheck")]
  public async Task<IActionResult> Run(
      [HttpTrigger(AuthorizationLevel.Function, "get", Route = "emUsFFRPInCfXnK7612cT9JL/health-check")] HttpRequest req)
  {

    try
    {
      _logger.LogInformation("Running Health Check");

      await _cosmosService.HealthCheckCall();

      return new OkResult();
    }
    catch (Exception ex)
    {
      _logger.LogError(ex, "Healthcheck failed with exception.\n" +
      "Error message: {errorMessage}\n{stackTrace}",
      ex.Message, ex.StackTrace);
      return new InternalServerErrorResult();
    }

  }
}
