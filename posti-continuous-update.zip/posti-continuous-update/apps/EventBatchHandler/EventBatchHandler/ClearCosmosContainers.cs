using System;
using System.Threading.Tasks;
using EventBatchHandler.CosmosDb;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;

namespace EventBatchHandler;
public class ClearCosmosContainers
{
  private readonly ILogger<ClearCosmosContainers> _logger;
  private readonly ICosmosDbService _cosmosDbService;

  public ClearCosmosContainers(ILogger<ClearCosmosContainers> logger, ICosmosDbService cosmosDbService)
  {
    _logger = logger;
    _cosmosDbService = cosmosDbService;
  }

  [FunctionName("ClearCosmosContainers")]
  public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Admin, "delete", Route = null)] HttpRequest req)
  {
    try
    {
      var batchResult = await _cosmosDbService.ClearContainers();

      if (batchResult != true)
        return new StatusCodeResult(StatusCodes.Status500InternalServerError);

      return new NoContentResult();
    }
    catch (Exception ex)
    {
      LogUnexpectedError(ex);
      return new StatusCodeResult(StatusCodes.Status500InternalServerError);
    }
  }

  private void LogEmptyBatchDateTime()
  {
    _logger.LogInformation("Batch DateTime is empty. Delete all batches");
  }

  private void LogBatchRequest(string dateTimeRequest)
  {
    _logger.LogInformation("Incoming batch deletion request request\n" +
      "Batch deletion request dateTime: {request}", dateTimeRequest);
  }
  private void LogUnexpectedError(Exception ex)
  {
    _logger.LogError("There was an unexpected error:\n" +
        "Error: {error}\n" +
        "Stack trace: {trace}",
        ex, ex.StackTrace);
  }
}
