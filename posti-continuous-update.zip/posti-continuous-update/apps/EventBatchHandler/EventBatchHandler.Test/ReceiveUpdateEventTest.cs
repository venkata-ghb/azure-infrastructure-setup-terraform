﻿using Azure.Messaging.EventHubs;
using EventBatchHandler.Config.Models;
using EventBatchHandler.CosmosDb;
using EventBatchHandler.Factories;
using EventBatchHandler.Models;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace EventBatchHandler.Test;

public class ReceiveUpdateEventTest
{
  private readonly Mock<ICosmosDbService> _mockDbService;
  private readonly ReceiveUpdateEvent _testTrigger;
  private readonly PilotSettings _testSettings;
  public ReceiveUpdateEventTest(ILogger<ReceiveUpdateEvent> logger)
  {
    _mockDbService = new Mock<ICosmosDbService>();
    _testSettings = new PilotSettings
    {
      IsPilotEnabled = false,
      PilotCustomerId = "15200"
    };
    _testTrigger = new ReceiveUpdateEvent(_mockDbService.Object, new PostiOperationDtoFactory(_testSettings), logger);
  }

  [Fact]
  public async void UnsupportedEvent_DoesntCallDbService()
  {
    // ARRANGE
    var eventBody = Utils.ReadFixture("unsupported_event.json");
    var testEventData = new EventData(eventBody);

    // ACT
    await _testTrigger.Run(testEventData);

    // ASSERT
    _mockDbService.VerifyNoOtherCalls();
  }

  #region CUSTOMER_BASIC_DATA_UPDATED

  [Theory]
  [InlineData("customer_basic_data_updated/valid_w_ssn.json", true, true)]
  public async void CustomerUpdated_CustomerMarkedAsLeft_NoEventStored(string fixtureFile, bool hasSsn, bool hasRealBday)
  {
    // ARRANGE
    var eventBody = Utils.ReadFixture(fixtureFile);
    var testEventData = new EventData(eventBody);

    
    _mockDbService
      .Setup(dbService => dbService.CheckIfCustomerMarkedAsLeft(It.IsAny<string>()))
      .ReturnsAsync(true)
      .Verifiable();
    

    // ACT
    await _testTrigger.Run(testEventData);

    // ASSERT
    _mockDbService.Verify();
    _mockDbService.VerifyNoOtherCalls();
  }

  [Theory]
  [InlineData("customer_basic_data_updated/valid_w_ssn_manual_updater.json", true, true)]
  public async void CustomerUpdated_CustomerAlreadyAdded_NoEventStored(string fixtureFile, bool hasSsn, bool hasRealBday)
  {
    // ARRANGE
    var eventBody = Utils.ReadFixture(fixtureFile);
    var testEventData = new EventData(eventBody);

    _mockDbService
      .Setup(dbService => dbService.CheckIfCustomerMarkedAsLeft(It.IsAny<string>()))
      .ReturnsAsync(false)
      .Verifiable();
    _mockDbService
      .Setup(dbService => dbService.CheckIfCustomerAddOperationAlreadyExists(It.IsAny<PostiOperationDto>()))
      .ReturnsAsync(true)
      .Verifiable();
    

    // ACT
    await _testTrigger.Run(testEventData);

    // ASSERT
    _mockDbService.Verify();
    _mockDbService.VerifyNoOtherCalls();
  }

  [Theory]
  [InlineData("customer_basic_data_updated/valid_w_ssn.json", true, true)]
  [InlineData("customer_basic_data_updated/valid_no_ssn_real_bday.json", false, true)]
  [InlineData("customer_basic_data_updated/valid_no_ssn_fake_bday.json", false, false)]
  public async void CustomerUpdated_ValidModifyEventsToStore_StoresRightData(string fixtureFile, bool hasSsn, bool hasRealBday)
  {
    // ARRANGE
    var eventBody = Utils.ReadFixture(fixtureFile);
    var testEventData = new EventData(eventBody);

    // Taken from fixture files
    var expectedDto = new PostiOperationDto()
    {
      Timestamp = 1710854844,
      Operation = PostiOperations.Add,
      CustomerNumber = "123",
      Ssn = hasSsn ? "010100-0000": hasRealBday ? "01012000": "",
      LastName = "Joukahaiska-Eventtiskä",
      FirstName = "Mesikämmein",
      PostalCode = "21832",
      City = "Perämyy",
      Address = "Pääskyinen yöpolku 42 Ö 4",
      Telephone = "",
      Email = "",
      Extra = ""
    };

    _mockDbService
      .Setup(dbService => dbService.CheckIfCustomerMarkedAsLeft(It.IsAny<string>()))
      .ReturnsAsync(false)
      .Verifiable();
    
    _mockDbService
      .Setup(dbService => dbService.StoreNewPostiOperation(It.Is<PostiOperationDto>(dto => dto == expectedDto), true))
      .ReturnsAsync(true)
      .Verifiable();

    // ACT
    await _testTrigger.Run(testEventData);

    // ASSERT
    _mockDbService.Verify();
  }

  [Theory]
  [InlineData("customer_basic_data_updated/valid_add_event_NI.json")]
  [InlineData("customer_basic_data_updated/valid_add_event_empty.json")]
  public async void CustomerUpdated_ValidAddEventsToStore_StoresRightData(string fixtureFile)
  {
    // ARRANGE
    var eventBody = Utils.ReadFixture(fixtureFile);
    var testEventData = new EventData(eventBody);

    // Taken from fixture files
    var expectedDto = new PostiOperationDto()
    {
      Timestamp = 1710854844,
      Operation = PostiOperations.Add,
      CustomerNumber = "123",
      Ssn = "010100-0000",
      LastName = "Joukahaiska-Eventtiskä",
      FirstName = "Mesikämmein",
      PostalCode = "21832",
      City = "Perämyy",
      Address = "Pääskyinen yöpolku 42 Ö 4",
      Telephone = "",
      Email = "",
      Extra = ""
    };

    _mockDbService
      .Setup(dbService => dbService.CheckIfCustomerMarkedAsLeft(It.IsAny<string>()))
      .ReturnsAsync(false)
      .Verifiable();

    _mockDbService
      .Setup(dbService => dbService.CheckIfCustomerAddOperationAlreadyExists(It.IsAny<PostiOperationDto>()))
      .ReturnsAsync(false)
      .Verifiable();

    _mockDbService
      .Setup(dbService => dbService.StoreNewPostiOperation(It.Is<PostiOperationDto>(dto => dto == expectedDto), true))
      .ReturnsAsync(true)
      .Verifiable();

    // ACT
    await _testTrigger.Run(testEventData);

    // ASSERT
    _mockDbService.Verify();
    _mockDbService.VerifyNoOtherCalls();
  }

  [Theory]
  [InlineData("customer_basic_data_updated/valid_left_event_NV.json")]
  public async void CustomerUpdated_ValidLeftEventsToStore_StoresRightData(string fixtureFile)
  {
    // ARRANGE
    var eventBody = Utils.ReadFixture(fixtureFile);
    var testEventData = new EventData(eventBody);

    // Taken from fixture files
    var expectedDto = new PostiOperationDto()
    {
      Timestamp = 1710854844,
      Operation = PostiOperations.Remove,
      CustomerNumber = "123",
      Ssn = "",
      LastName = "",
      FirstName = "",
      PostalCode = "",
      City = "",
      Address = "",
      Telephone = "",
      Email = "",
      Extra = ""
    };

    _mockDbService
      .Setup(dbService => dbService.StoreNewPostiOperation(It.Is<PostiOperationDto>(dto => dto == expectedDto), false))
      .ReturnsAsync(true)
      .Verifiable();

    // ACT
    await _testTrigger.Run(testEventData);

    // ASSERT
    _mockDbService.Verify();
    _mockDbService.VerifyNoOtherCalls();
  }

  [Theory]
  [InlineData("customer_basic_data_updated/valid_readdition.json")]
  public async void CustomerUpdated_ValidReaddition_StoresRightData(string fixtureFile)
  {
    // ARRANGE
    var eventBody = Utils.ReadFixture(fixtureFile);
    var testEventData = new EventData(eventBody);

    // Taken from fixture files
    var expectedDto = new PostiOperationDto()
    {
      Timestamp = 1710854844,
      Operation = PostiOperations.Add,
      CustomerNumber = "123",
      Ssn = "010100-0000",
      LastName = "Joukahaiska-Eventtiskä",
      FirstName = "Mesikämmein",
      PostalCode = "21832",
      City = "Perämyy",
      Address = "Pääskyinen yöpolku 42 Ö 4",
      Telephone = "",
      Email = "",
      Extra = ""
    };

    _mockDbService
      .Setup(dbService => dbService.CheckIfCustomerMarkedAsLeft(It.IsAny<string>()))
      .ReturnsAsync(false)
      .Verifiable();

    _mockDbService
      .Setup(dbService => dbService.CheckIfCustomerAddOperationAlreadyExists(It.IsAny<PostiOperationDto>()))
      .ReturnsAsync(false)
      .Verifiable();

    _mockDbService
      .Setup(dbService => dbService.StoreNewPostiOperation(It.Is<PostiOperationDto>(dto => dto == expectedDto), true))
      .ReturnsAsync(true)
      .Verifiable();

    // ACT
    await _testTrigger.Run(testEventData);

    // ASSERT
    _mockDbService.Verify();
    _mockDbService.VerifyNoOtherCalls();
  }

  [Theory]
  [InlineData("customer_basic_data_updated/invalid_cus_number_empty.json",   "",    "Joukahaiska-Eventtiskä", "Mesikämmein", "21832", "Pääskyinen yöpolku 42 Ö 4")]
  [InlineData("customer_basic_data_updated/invalid_cus_number_missing.json", null,  "Joukahaiska-Eventtiskä", "Mesikämmein", "21832", "Pääskyinen yöpolku 42 Ö 4")]
  [InlineData("customer_basic_data_updated/invalid_cus_number_null.json",    null,  "Joukahaiska-Eventtiskä", "Mesikämmein", "21832", "Pääskyinen yöpolku 42 Ö 4")]
  [InlineData("customer_basic_data_updated/invalid_lastname_empty.json",     "123", "",         "Mesikämmein", "21832", "Pääskyinen yöpolku 42 Ö 4")]
  [InlineData("customer_basic_data_updated/invalid_lastname_missing.json",   "123", null,       "Mesikämmein", "21832", "Pääskyinen yöpolku 42 Ö 4")]
  [InlineData("customer_basic_data_updated/invalid_lastname_null.json",      "123", null,       "Mesikämmein", "21832", "Pääskyinen yöpolku 42 Ö 4")]
  [InlineData("customer_basic_data_updated/invalid_firstname_empty.json",    "123", "Joukahaiska-Eventtiskä", ""     , "21832", "Pääskyinen yöpolku 42 Ö 4")]
  [InlineData("customer_basic_data_updated/invalid_firstname_missing.json",  "123", "Joukahaiska-Eventtiskä", null   , "21832", "Pääskyinen yöpolku 42 Ö 4")]
  [InlineData("customer_basic_data_updated/invalid_firstname_null.json",     "123", "Joukahaiska-Eventtiskä", null   , "21832", "Pääskyinen yöpolku 42 Ö 4")]
  [InlineData("customer_basic_data_updated/invalid_postcode_empty.json",     "123", "Joukahaiska-Eventtiskä", "Mesikämmein", ""      , "Pääskyinen yöpolku 42 Ö 4")]
  [InlineData("customer_basic_data_updated/invalid_postcode_missing.json",   "123", "Joukahaiska-Eventtiskä", "Mesikämmein", null    , "Pääskyinen yöpolku 42 Ö 4")]
  [InlineData("customer_basic_data_updated/invalid_postcode_null.json",      "123", "Joukahaiska-Eventtiskä", "Mesikämmein", null    , "Pääskyinen yöpolku 42 Ö 4")]
  [InlineData("customer_basic_data_updated/invalid_address_empty.json",      "123", "Joukahaiska-Eventtiskä", "Mesikämmein", "21832", "")]
  [InlineData("customer_basic_data_updated/invalid_address_missing.json",    "123", "Joukahaiska-Eventtiskä", "Mesikämmein", "21832", null)]
  [InlineData("customer_basic_data_updated/invalid_address_null.json",       "123", "Joukahaiska-Eventtiskä", "Mesikämmein", "21832", null)]
  public async void CustomerEnrolled_InvalidBody_StoresInvalidData(
    string fixtureFile,
    string expectedCustomerNumber,
    string expectedLastName,
    string expectedFirstName,
    string expectedPostalCode,
    string expectedAddress)
  {
    // ARRANGE
    var eventBody = Utils.ReadFixture(fixtureFile);
    var testEventData = new EventData(eventBody);

    // Taken from fixture files
    var expectedDto = new PostiOperationDto()
    {
      Timestamp = 1710854844,
      Operation = PostiOperations.Add,
      CustomerNumber = expectedCustomerNumber,
      Ssn = "010100-0000",
      LastName = expectedLastName,
      FirstName = expectedFirstName,
      PostalCode = expectedPostalCode,
      City = "Perämyy",
      Address = expectedAddress,
      Telephone = "",
      Email = "",
      Extra = ""
    };
    
    _mockDbService
      .Setup(dbService => dbService.StoreInvalidData(It.Is<PostiOperationDto>(dto => dto == expectedDto), It.IsAny<string>()))
      .ReturnsAsync(true)
      .Verifiable();

    // ACT
    await _testTrigger.Run(testEventData);

    // ASSERT
    _mockDbService.Verify();
    _mockDbService.VerifyNoOtherCalls();
  }
  
  [Fact]
  public async void CustomerEnrolled_NotRegularAccountType_IgnoresEvent()
  {
    // ARRANGE
    var eventBody = Utils.ReadFixture("customer_basic_data_updated/valid_non_regular_account_type.json");
    var testEventData = new EventData(eventBody);

    // ACT
    await _testTrigger.Run(testEventData);

    // ASSERT
    _mockDbService.VerifyNoOtherCalls();
  }
  
  [Fact]
  public async void CustomerEnrolled_AhvenanmaaZipCode_IgnoresEvent()
  {
    // ARRANGE
    var eventBody = Utils.ReadFixture("customer_basic_data_updated/valid_ahvenanmaa_zip_code.json");
    var testEventData = new EventData(eventBody);

    // ACT
    await _testTrigger.Run(testEventData);

    // ASSERT
    _mockDbService.VerifyNoOtherCalls();
  }

  [Fact]
  public async void CustomerEnrolled_NonFinnishCountry_IgnoresEvent()
  {
    // ARRANGE
    var eventBody = Utils.ReadFixture("customer_basic_data_updated/valid_non_finnish_country.json");
    var testEventData = new EventData(eventBody);

    // ACT
    await _testTrigger.Run(testEventData);

    // ASSERT
    _mockDbService.VerifyNoOtherCalls();
  }
  
  [Fact]
  public async void CustomerEnrolled_DoNotValidateAccount_IgnoresEvent()
  {
    // ARRANGE
    var eventBody = Utils.ReadFixture("customer_enrolled_event/valid_do_not_validate.json");
    var testEventData = new EventData(eventBody);

    // ACT
    await _testTrigger.Run(testEventData);

    // ASSERT
    _mockDbService.VerifyNoOtherCalls();
  }
  #endregion

}
