﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Bogus;
using EventBatchHandler.CosmosDb;
using EventBatchHandler.CosmosDb.Models;
using EventBatchHandler.Models;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace EventBatchHandler.Test;

public class GetBatchTest
{
  private readonly Mock<ICosmosDbService> _mockDbService;
  private readonly GetBatch _testTrigger;

  public GetBatchTest(ILogger<GetBatch> logger)
  {
    _mockDbService = new Mock<ICosmosDbService>();
    _testTrigger = new GetBatch(logger, _mockDbService.Object);
  }

  [Theory]
  [InlineData(null)]
  [InlineData("2022-07-05T13:00:27Z")]
  public async void ValidRequest_SuccessResponse(string requestParam)
  {
    DateTime? param = !string.IsNullOrEmpty(requestParam) ? DateTime.Parse(requestParam) : null;
    (var fetchResult, var dtos) = GenerateFetchBatchResultAndDtos(FetchBatchStatus.Success);
    var request = Utils.CreateMockRequestWithQuery(new Dictionary<string, Microsoft.Extensions.Primitives.StringValues>() {
      {"BatchDateTime", requestParam }
    });
    _mockDbService.Setup(x => x.GetBatch(It.IsAny<DateTime?>())).ReturnsAsync(fetchResult);

    //Act
    Func<Task<IActionResult>> act = () => _testTrigger.Run(request.Object);

    //Assert            
    var result = await act.Should().NotThrowAsync();
    var doc = result.Which;
    doc.Should().BeAssignableTo<OkObjectResult>();
    doc.As<OkObjectResult>().Should().NotBeNull();
    doc.As<OkObjectResult>().Value.As<List<BatchRecordDto>>().Should().NotBeNull();
    doc.As<OkObjectResult>().Value.As<List<BatchRecordDto>>().Should().BeEquivalentTo(dtos);
  }

  [Theory]
  [InlineData(null, FetchBatchStatus.Disabled)]
  [InlineData("2022-07-05T13:00:27Z", FetchBatchStatus.Disabled)]
  [InlineData(null, FetchBatchStatus.ErrorFetchingBatches)]
  [InlineData("2022-07-05T13:00:27Z", FetchBatchStatus.ErrorFetchingBatches)]
  public async void ValidRequest_ErrorResponse(string requestParam, FetchBatchStatus status)
  {
    DateTime? param = !string.IsNullOrEmpty(requestParam) ? DateTime.Parse(requestParam) : null;
    (var fetchResult, _) = GenerateFetchBatchResultAndDtos(status);
    var request = Utils.CreateMockRequestWithQuery(new Dictionary<string, Microsoft.Extensions.Primitives.StringValues>() {
      {"BatchDateTime", requestParam }
    });
    _mockDbService.Setup(x => x.GetBatch(It.IsAny<DateTime?>())).ReturnsAsync(fetchResult);

    //Act
    Func<Task<IActionResult>> act = () => _testTrigger.Run(request.Object);

    //Assert            
    var result = await act.Should().NotThrowAsync();
    var doc = result.Which;
    doc.Should().BeAssignableTo<StatusCodeResult>();
    doc.As<StatusCodeResult>().Should().NotBeNull();
    doc.As<StatusCodeResult>().StatusCode.Should().Be(500);
  }

  private (FetchBatchResult result, List<BatchRecordDto> dtos) GenerateFetchBatchResultAndDtos(FetchBatchStatus status)
  {
    if (status != FetchBatchStatus.Success)
      return (new FetchBatchResult() { Status = status }, new List<BatchRecordDto>());

    (var doc, var dtos) = GenerateBatchDocAndDto();

    var faker = new Faker<FetchBatchResult>()
      .RuleFor(result => result.Status, f => status)
      .RuleFor(result => result.Batch, faker => doc);

    return (faker.Generate(), dtos);
  }

  private (BatchDocument doc, List<BatchRecordDto> dtos) GenerateBatchDocAndDto()
  {
    var operations = Utils.GenerateBatchOperation(1);
    var faker = new Faker<BatchDocument>()
      .RuleFor(doc => doc.Id, f => "2022-07-05T13:00:27Z")
      .RuleFor(doc => doc.Operations, f => operations);

    var doc = faker.Generate();
    var dtos = new List<BatchRecordDto>();
    doc.Operations.ForEach(doc => dtos.Add(BatchRecordDto.CreateFromBatchOperation(doc)));

    return (doc, dtos);
  }


}
