﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using Bogus;
using EventBatchHandler.CosmosDb.Models;
using EventBatchHandler.Models;
using EventBatchHandler.PostiIntegration.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Internal;
using Microsoft.Extensions.Primitives;
using Moq;
using Newtonsoft.Json;

namespace EventBatchHandler.Test;

internal static class Utils
{
  public static Mock<HttpRequest> CreateMockRequestWithBody(object? body)
  {
    var memoryStream = new MemoryStream();
    var streamWriter = new StreamWriter(memoryStream);

    var json = JsonConvert.SerializeObject(body);

    streamWriter.Write(json);
    streamWriter.Flush();

    memoryStream.Position = 0;

    var mockRequest = new Mock<HttpRequest>();
    mockRequest.Setup(req => req.Body).Returns(memoryStream);

    return mockRequest;
  }

  public static Mock<HttpRequest> CreateMockRequestWithQuery(Dictionary<string, StringValues> query)
  {
    var q = new QueryCollection(query);

    var mockRequest = new Mock<HttpRequest>();
    mockRequest.Setup(req => req.Query).Returns(q);

    return mockRequest;
  }

  public static string ReadFixture(string filename)
  {
    var directory = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);

    return File.ReadAllText(Path.Combine(directory, "Fixtures", filename));
  }

  public static IEnumerable<PostiOperationDocument> GenerateOperationDocs(int count, string batchId)
  {
    var docFaker = new Faker<PostiOperationDocument>()
      .RuleFor(doc => doc.Operation, f => f.PickRandom<PostiOperations>())
      .RuleFor(doc => doc.Timestamp, f => f.Random.Long(1600000000, 1700000000))
      .RuleFor(doc => doc.CustomerNumber, f => f.Random.Int(0, 10000).ToString())
      .RuleFor(doc => doc.Id, (f, doc) => $"{doc.Timestamp}::{doc.CustomerNumber}::{doc.Operation}")
      .RuleFor(doc => doc.BatchId, f => batchId)
      .RuleFor(doc => doc.Ssn, f => $"{f.Random.Int(1, 31)}{f.Random.Int(1, 12)}{f.Random.Int(50, 99)}-{f.Random.String(4)}")
      .RuleFor(doc => doc.LastName, f => f.Name.LastName())
      .RuleFor(doc => doc.FirstName, f => f.Name.FirstName())
      .RuleFor(doc => doc.PostalCode, f => f.Address.ZipCode("#####"))
      .RuleFor(doc => doc.City, f => f.Address.City())
      .RuleFor(doc => doc.Address, f => f.Address.StreetAddress())
      .RuleFor(doc => doc.Telephone, f => f.Phone.PhoneNumber("### ### ####"))
      .RuleFor(doc => doc.Email, (f, doc) => f.Internet.Email(doc.FirstName, doc.LastName))
      .RuleFor(doc => doc.Extra, f => "");
    return docFaker.Generate(count);
  }

  public static IEnumerable<BatchOperation> GenerateBatchOperation(int count)
  {
    var docFaker = new Faker<BatchOperation>()
      .RuleFor(doc => doc.Operation, f => f.PickRandom<PostiOperations>())
      .RuleFor(doc => doc.Timestamp, f => f.Random.Long(1600000000, 1700000000))
      .RuleFor(doc => doc.CustomerNumber, f => f.Random.Int(0, 10000).ToString())
      .RuleFor(doc => doc.Id, (f, doc) => $"{doc.Timestamp}::{doc.CustomerNumber}::{doc.Operation}")
      .RuleFor(doc => doc.Ssn, f => $"{f.Random.Int(1, 31)}{f.Random.Int(1, 12)}{f.Random.Int(50, 99)}-{f.Random.String(4)}")
      .RuleFor(doc => doc.LastName, f => f.Name.LastName())
      .RuleFor(doc => doc.FirstName, f => f.Name.FirstName())
      .RuleFor(doc => doc.PostalCode, f => f.Address.ZipCode("#####"))
      .RuleFor(doc => doc.City, f => f.Address.City())
      .RuleFor(doc => doc.Address, f => f.Address.StreetAddress())
      .RuleFor(doc => doc.Telephone, f => f.Phone.PhoneNumber("### ### ####"))
      .RuleFor(doc => doc.Email, (f, doc) => f.Internet.Email(doc.FirstName, doc.LastName))
      .RuleFor(doc => doc.Extra, f => "");
    return docFaker.Generate(count);
  }

  public static List<PostiOperationDto> GeneratatePostiOperationDtos(int count)
  {
    var faker = new Faker<PostiOperationDto>()
      .RuleFor(doc => doc.Timestamp, f => f.Random.Long(1600000000, 1700000000))
      .RuleFor(doc => doc.Operation, f => f.PickRandom<PostiOperations>())
      .RuleFor(doc => doc.CustomerNumber, f => f.Random.Int(0, 10000).ToString())
      .RuleFor(doc => doc.Ssn, f => $"{f.Random.Int(1, 31)}{f.Random.Int(1, 12)}{f.Random.Int(50, 99)}-{f.Random.AlphaNumeric(4)}")
      .RuleFor(doc => doc.LastName, f => f.Name.LastName())
      .RuleFor(doc => doc.FirstName, f => f.Name.FirstName())
      .RuleFor(doc => doc.PostalCode, f => f.Address.ZipCode("#####"))
      .RuleFor(doc => doc.City, f => f.Address.City())
      .RuleFor(doc => doc.Address, f => f.Address.StreetAddress())
      .RuleFor(doc => doc.Telephone, f => f.Phone.PhoneNumber("### ### ####"))
      .RuleFor(doc => doc.Email, (f, doc) => f.Internet.Email(doc.FirstName, doc.LastName))
      .RuleFor(doc => doc.Extra, f => "");
    return faker.Generate(count).OrderBy(op => op.Timestamp).ToList();
  }

  public static (List<PostiOperationDto> operationsToSend, string expectedPayload) GenerateRegistryUpdateOperations(int count)
  {
    var orderedOps = GeneratatePostiOperationDtos(count);
    var payload = JsonConvert.SerializeObject(
      orderedOps
      .Select(op => UpdateRegistyRequestRecord.FromPostiOperationDto(op))
      .ToList());
    return (orderedOps, payload);
  }
}
