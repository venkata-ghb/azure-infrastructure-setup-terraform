﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using EventBatchHandler.Config.Models;
using EventBatchHandler.CosmosDb;
using EventBatchHandler.CosmosDb.Models;
using EventBatchHandler.Models;
using FluentAssertions;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using NodaTime;
using NodaTime.Testing;
using Xunit;

namespace EventBatchHandler.Test.CosmosDb;

public class CosmosDbServiceTest
{
  private readonly FakeClock _testClock;
  private readonly CosmosDbSettings _mockSettings;
  private readonly Mock<CosmosClient> _mockCosmosClient;
  private readonly Mock<Container> _mockInvalidDataContainer;
  private readonly Mock<Container> _mockOperationsContainer;
  private readonly Mock<Container> _mockBatchesContainer;
  private readonly Mock<Container> _mockCustomerContainer;
  private readonly Mock<ICosmosLinqQuery> _mockCosmosLinqQueryWrapper;

  private readonly Mock<ItemResponse<PostiOperationDocument>> _mockStoreOperationDocumentResponse;
  private readonly Mock<ItemResponse<InvalidDataDocument>> _mockStoreInvalidDataDocumentResponse;
  private readonly Mock<ItemResponse<BatchDocument>> _mockStoreBatchResponse;
  private readonly Mock<ItemResponse<PostiOperationDocument>> _mockDeletePostiOperationResponse;
  private readonly Mock<ItemResponse<BatchDocument>> _mockDeleteBatchResponse;
  private readonly Mock<ItemResponse<CustomerDocument>> _mockCustomerResponse;
  private readonly Mock<ItemResponse<InvalidDataDocument>> _mockDeleteInvalidDataResponse;

  private readonly CosmosDbService _testService;

  public CosmosDbServiceTest(ILogger<CosmosDbService> logger)
  {
    var testTime = new DateTime(2022, 1, 10, 7, 30, 45, DateTimeKind.Utc);
    var testInstant = Instant.FromDateTimeUtc(testTime);
    _testClock = new FakeClock(testInstant);

  _mockSettings = new CosmosDbSettings()
    {
      Name = "FakeDb",
      ConnectionString = "ConnectToDb",
      InvalidDataContainer = "InvalidData",
      OperationsContainer = "Operations",
      CustomerContainer = "Customer",
      CustomerLeftDocumentTtl = 30,
      OperationsUnbatchedPartitionKey = "Unbatched",
      BatchesContainer = "Batches",
      DisableStoreInvalidData = false,
      DisableBuildNewBatch = false,
      DisableStoreNewBatch = false,
      DisableStoreNewOperations = false,
      DisableFetchingBatches = false,
    };
    _mockCosmosClient = new Mock<CosmosClient>();
    // Setup URI return for telemetry calls
    _mockCosmosClient
      .Setup(c => c.Endpoint)
      .Returns(new Uri("https://some-cosmos.db"));
    // Setup fetching of containers
    _mockInvalidDataContainer = new Mock<Container>();
    _mockCosmosClient
        .Setup(c => c.GetContainer(_mockSettings.Name, _mockSettings.InvalidDataContainer))
        .Returns(_mockInvalidDataContainer.Object)
        .Verifiable();
    _mockOperationsContainer = new Mock<Container>(MockBehavior.Strict);
    _mockCosmosClient
        .Setup(c => c.GetContainer(_mockSettings.Name, _mockSettings.OperationsContainer))
        .Returns(_mockOperationsContainer.Object)
        .Verifiable();
    _mockBatchesContainer = new Mock<Container>();
    _mockCosmosClient
        .Setup(c => c.GetContainer(_mockSettings.Name, _mockSettings.BatchesContainer))
        .Returns(_mockBatchesContainer.Object)
        .Verifiable();
    _mockCustomerContainer = new Mock<Container>();
    _mockCosmosClient
        .Setup(c => c.GetContainer(_mockSettings.Name, _mockSettings.CustomerContainer))
        .Returns(_mockCustomerContainer.Object)
        .Verifiable();
    _mockCosmosLinqQueryWrapper = new Mock<ICosmosLinqQuery>();

    _mockStoreOperationDocumentResponse = new Mock<ItemResponse<PostiOperationDocument>>();
    _mockStoreInvalidDataDocumentResponse = new Mock<ItemResponse<InvalidDataDocument>>();
    _mockStoreBatchResponse = new Mock<ItemResponse<BatchDocument>>();
    _mockDeletePostiOperationResponse = new Mock<ItemResponse<PostiOperationDocument>>();
    _mockDeleteBatchResponse = new Mock<ItemResponse<BatchDocument>>();
    _mockDeleteInvalidDataResponse = new Mock<ItemResponse<InvalidDataDocument>>();
    _mockCustomerResponse = new Mock<ItemResponse<CustomerDocument>>();

    _testService = new CosmosDbService(
      logger,
      _testClock,
      _mockSettings,
      _mockCosmosClient.Object,
      new TelemetryConfiguration(),
      _mockCosmosLinqQueryWrapper.Object);
  }

  [Fact]
  public async void StorePostiOperation_OperationSuccessfullyStored_ReturnsTrue()
  {
    // ASSIGN
    var inputDto = GenerateTestOperation();
    var expectedDocument = new PostiOperationDocument()
    {
      Id = $"{inputDto.Timestamp}::{inputDto.CustomerNumber}::{inputDto.Operation}",
      BatchId = _mockSettings.OperationsUnbatchedPartitionKey,
      Timestamp = inputDto.Timestamp,
      Operation = inputDto.Operation,
      CustomerNumber = inputDto.CustomerNumber,
      Ssn = inputDto.Ssn,
      LastName = inputDto.LastName,
      FirstName = inputDto.FirstName,
      PostalCode = inputDto.PostalCode,
      City = inputDto.City,
      Address = inputDto.Address,
      Telephone = inputDto.Telephone,
      Email = inputDto.Email,
      Extra = inputDto.Extra,
    };
    var expectedPartitionKey = new PartitionKey(_mockSettings.OperationsUnbatchedPartitionKey);
    _mockOperationsContainer
      .Setup(container => container.UpsertItemAsync(
        It.Is<PostiOperationDocument>(doc => doc == expectedDocument),
        It.Is<PartitionKey>(key => key == expectedPartitionKey),
        It.IsAny<ItemRequestOptions>(),
        default))
      .ReturnsAsync(_mockStoreOperationDocumentResponse.Object)
      .Verifiable();
    var mockDocuments = new List<PostiOperationDocument>
    {
        new PostiOperationDocument
        {
            BatchId = _mockSettings.OperationsUnbatchedPartitionKey,
            CustomerNumber = "CustomerNumber1",
            Operation = PostiOperations.Add
        },
        new PostiOperationDocument
        {
            BatchId = _mockSettings.OperationsUnbatchedPartitionKey,
            CustomerNumber = "CustomerNumber1",
            Operation = PostiOperations.Add
        }
    };
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetQueryText(It.IsAny<IQueryable<PostiOperationDocument>>()))
      .Returns("Some query");
    var mockFeedIterator = new Mock<FeedIterator<PostiOperationDocument>>();
    mockFeedIterator
      .Setup(fi => fi.HasMoreResults)
      .Returns(false);
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetFeedIterator(It.IsAny<IQueryable<PostiOperationDocument>>()))
      .Returns(mockFeedIterator.Object);
    _mockOperationsContainer
      .Setup(c => c.GetItemLinqQueryable<PostiOperationDocument>(false, null, null, null))
      .Returns(new EnumerableQuery<PostiOperationDocument>(mockDocuments))
      .Verifiable();

    // ACT
    var success = await _testService.StoreNewPostiOperation(inputDto);

    // ASSERT
    success.Should().BeTrue();
    _mockOperationsContainer.Verify();
    _mockOperationsContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void StorePostiOperation_OperationSuccessfullyStored_WithReaddition_ReturnsTrue()
  {
    // ASSIGN
    var inputDto = GenerateTestOperation();
    var expectedDocument = new PostiOperationDocument()
    {
      Id = $"{inputDto.Timestamp}::{inputDto.CustomerNumber}::{inputDto.Operation}",
      BatchId = _mockSettings.OperationsUnbatchedPartitionKey,
      Timestamp = inputDto.Timestamp,
      Operation = inputDto.Operation,
      CustomerNumber = inputDto.CustomerNumber,
      Ssn = inputDto.Ssn,
      LastName = inputDto.LastName,
      FirstName = inputDto.FirstName,
      PostalCode = inputDto.PostalCode,
      City = inputDto.City,
      Address = inputDto.Address,
      Telephone = inputDto.Telephone,
      Email = inputDto.Email,
      Extra = inputDto.Extra,
    };
    var expectedRemovalDocument = new PostiOperationDocument()
    {
      Id = $"{inputDto.Timestamp}::{inputDto.CustomerNumber}::Remove",
      BatchId = _mockSettings.OperationsUnbatchedPartitionKey,
      Timestamp = inputDto.Timestamp,
      Operation = PostiOperations.Remove,
      CustomerNumber = inputDto.CustomerNumber,
      Ssn = "",
      LastName = "",
      FirstName = "",
      PostalCode = "",
      City = "",
      Address = "",
      Telephone = "",
      Email = "",
      Extra = "",
    };
    var mockDocuments = new List<PostiOperationDocument>
    {
        new PostiOperationDocument
        {
            BatchId = _mockSettings.OperationsUnbatchedPartitionKey,
            CustomerNumber = "CustomerNumber1",
            Operation = PostiOperations.Add
        },
        new PostiOperationDocument
        {
            BatchId = _mockSettings.OperationsUnbatchedPartitionKey,
            CustomerNumber = "CustomerNumber1",
            Operation = PostiOperations.Add
        }
    };
    var expectedPartitionKey = new PartitionKey(_mockSettings.OperationsUnbatchedPartitionKey);
    var sequence = new MockSequence();
    _mockOperationsContainer.InSequence(sequence).Setup(container => container.UpsertItemAsync(
        It.Is<PostiOperationDocument>(doc => doc == expectedRemovalDocument),
        It.Is<PartitionKey>(key => key == expectedPartitionKey),
        It.IsAny<ItemRequestOptions>(),
        default))
      .ReturnsAsync(_mockStoreOperationDocumentResponse.Object)
      .Verifiable();
    _mockOperationsContainer.InSequence(sequence).Setup(container => container.UpsertItemAsync(
        It.Is<PostiOperationDocument>(doc => doc == expectedDocument),
        It.Is<PartitionKey>(key => key == expectedPartitionKey),
        It.IsAny<ItemRequestOptions>(),
        default))
      .ReturnsAsync(_mockStoreOperationDocumentResponse.Object)
      .Verifiable();
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetQueryText(It.IsAny<IQueryable<PostiOperationDocument>>()))
      .Returns("Some query");
    var mockFeedIterator = new Mock<FeedIterator<PostiOperationDocument>>();
    mockFeedIterator
      .Setup(fi => fi.HasMoreResults)
      .Returns(false);
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetFeedIterator(It.IsAny<IQueryable<PostiOperationDocument>>()))
      .Returns(mockFeedIterator.Object);
    _mockOperationsContainer
      .Setup(c => c.GetItemLinqQueryable<PostiOperationDocument>(false, null, null, null))
      .Returns(new EnumerableQuery<PostiOperationDocument>(mockDocuments))
      .Verifiable();

    // ACT
    var success = await _testService.StoreNewPostiOperation(inputDto, true);

    // ASSERT
    success.Should().BeTrue();
    _mockOperationsContainer.Verify();
    _mockOperationsContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void StorePostiOperation_CosmosExceptionThrown_ReturnsFalse()
  {
    // ASSIGN
    var inputDto = GenerateTestOperation();
    var expectedDocument = new PostiOperationDocument()
    {
      Id = $"{inputDto.Timestamp}::{inputDto.CustomerNumber}::{inputDto.Operation}",
      BatchId = _mockSettings.OperationsUnbatchedPartitionKey,
      Timestamp = inputDto.Timestamp,
      Operation = inputDto.Operation,
      CustomerNumber = inputDto.CustomerNumber,
      Ssn = inputDto.Ssn,
      LastName = inputDto.LastName,
      FirstName = inputDto.FirstName,
      PostalCode = inputDto.PostalCode,
      City = inputDto.City,
      Address = inputDto.Address,
      Telephone = inputDto.Telephone,
      Email = inputDto.Email,
      Extra = inputDto.Extra,
    };
    var mockDocuments = new List<PostiOperationDocument>
    {
        new PostiOperationDocument
        {
            BatchId = _mockSettings.OperationsUnbatchedPartitionKey,
            CustomerNumber = "CustomerNumber1",
            Operation = PostiOperations.Add
        },
        new PostiOperationDocument
        {
            BatchId = _mockSettings.OperationsUnbatchedPartitionKey,
            CustomerNumber = "CustomerNumber1",
            Operation = PostiOperations.Add
        }
    };
    var expectedPartitionKey = new PartitionKey(_mockSettings.OperationsUnbatchedPartitionKey);
    _mockOperationsContainer
      .Setup(container => container.UpsertItemAsync(
        It.Is<PostiOperationDocument>(doc => doc == expectedDocument),
        It.Is<PartitionKey>(key => key == expectedPartitionKey),
        It.IsAny<ItemRequestOptions>(),
        default))
      .ThrowsAsync(new CosmosException("Oops", HttpStatusCode.BadRequest, 440, "id", 0.1))
      .Verifiable();
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetQueryText(It.IsAny<IQueryable<PostiOperationDocument>>()))
      .Returns("Some query");
    var mockFeedIterator = new Mock<FeedIterator<PostiOperationDocument>>();
    mockFeedIterator
      .Setup(fi => fi.HasMoreResults)
      .Returns(false);
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetFeedIterator(It.IsAny<IQueryable<PostiOperationDocument>>()))
      .Returns(mockFeedIterator.Object);
    _mockOperationsContainer
      .Setup(c => c.GetItemLinqQueryable<PostiOperationDocument>(false, null, null, null))
      .Returns(new EnumerableQuery<PostiOperationDocument>(mockDocuments))
      .Verifiable();

    // ACT
    var success = await _testService.StoreNewPostiOperation(inputDto);

    // ASSERT
    success.Should().BeFalse();
    _mockOperationsContainer.Verify();
    _mockOperationsContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void StoreInvalidData_InvalidDataSuccessfullyStored_ReturnsTrue()
  {
    // ASSIGN
    var inputDto = GenerateTestOperation();
    var mockInvalidBody = "{ \"this\": \"isn't right\" }";
    var expectedDocument = new InvalidDataDocument()
    {
      Id = $"{inputDto.Timestamp}::{inputDto.CustomerNumber}::{inputDto.Operation}",
      Timestamp = inputDto.Timestamp,
      Operation = inputDto.Operation,
      CustomerNumber = inputDto.CustomerNumber,
      RawEvent = mockInvalidBody
    };
    var expectedPartitionKey = new PartitionKey(inputDto.Operation.ToString());
    _mockInvalidDataContainer
      .Setup(container => container.CreateItemAsync(
        It.Is<InvalidDataDocument>(doc => doc == expectedDocument),
        It.Is<PartitionKey>(key => key == expectedPartitionKey),
        It.IsAny<ItemRequestOptions>(),
        default))
      .ReturnsAsync(_mockStoreInvalidDataDocumentResponse.Object)
      .Verifiable();

    // ACT
    var success = await _testService.StoreInvalidData(inputDto, mockInvalidBody);

    // ASSERT
    success.Should().BeTrue();
    _mockInvalidDataContainer.Verify();
    _mockInvalidDataContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void StoreInvalidData_CosmosExceptionThrown_ReturnsFalse()
  {
    // ASSIGN
    var inputDto = GenerateTestOperation();
    var mockInvalidBody = "{ \"this\": \"isn't right\" }";
    var expectedDocument = new InvalidDataDocument()
    {
      Id = $"{inputDto.Timestamp}::{inputDto.CustomerNumber}::{inputDto.Operation}",
      Timestamp = inputDto.Timestamp,
      Operation = inputDto.Operation,
      CustomerNumber = inputDto.CustomerNumber,
      RawEvent = mockInvalidBody
    };
    var expectedPartitionKey = new PartitionKey(inputDto.Operation.ToString());
    _mockInvalidDataContainer
      .Setup(container => container.CreateItemAsync(
        It.Is<InvalidDataDocument>(doc => doc == expectedDocument),
        It.Is<PartitionKey>(key => key == expectedPartitionKey),
        It.IsAny<ItemRequestOptions>(),
        default))
      .ThrowsAsync(new CosmosException("Oops", HttpStatusCode.BadRequest, 440, "id", 0.1))
      .Verifiable();

    // ACT
    var success = await _testService.StoreInvalidData(inputDto, mockInvalidBody);

    // ASSERT
    success.Should().BeFalse();
    _mockInvalidDataContainer.Verify();
    _mockInvalidDataContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void FetchUnbatchedOperations_ErrorFetchingUnbatchedOperations_ReturnsCorrespondingStatus()
  {
    // ARRANGE
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetQueryText(It.IsAny<IQueryable<PostiOperationDocument>>()))
      .Returns("Some query");
    var mockFeedIterator = new Mock<FeedIterator<PostiOperationDocument>>();
    mockFeedIterator
      .SetupSequence(fi => fi.HasMoreResults)
      .Returns(true)
      .Returns(false);
    mockFeedIterator
      .Setup(fi => fi.ReadNextAsync(default))
      .ThrowsAsync(new CosmosException("Oops!", HttpStatusCode.InternalServerError, 500, "id", 1.0));
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetFeedIterator(It.IsAny<IQueryable<PostiOperationDocument>>()))
      .Returns(mockFeedIterator.Object);
    _mockOperationsContainer
      .Setup(c => c.GetItemLinqQueryable<PostiOperationDocument>(false, null, null, null))
      .Returns(new EnumerableQuery<PostiOperationDocument>(new List<PostiOperationDocument>()))
      .Verifiable();

    // ACT
    var result = await _testService.FetchUnbatchedOperations();

    //ASSERT
    result.Status.Should().Be(FetchUnbatchedOperationsStatus.DatabaseError);
    _mockOperationsContainer.Verify();
    _mockOperationsContainer.VerifyNoOtherCalls();
    _mockInvalidDataContainer.VerifyNoOtherCalls();
    _mockBatchesContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void FetchUnbatchedOperations_NoOperationsFound_ReturnsCorrespondingStatus()
  {
    // ARRANGE
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetQueryText(It.IsAny<IQueryable<PostiOperationDocument>>()))
      .Returns("Some query");
    var mockFeedIterator = new Mock<FeedIterator<PostiOperationDocument>>();
    mockFeedIterator
      .Setup(fi => fi.HasMoreResults)
      .Returns(false);
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetFeedIterator(It.IsAny<IQueryable<PostiOperationDocument>>()))
      .Returns(mockFeedIterator.Object);
    _mockOperationsContainer
      .Setup(c => c.GetItemLinqQueryable<PostiOperationDocument>(false, null, null, null))
      .Returns(new EnumerableQuery<PostiOperationDocument>(new List<PostiOperationDocument>()))
      .Verifiable();

    // ACT
    var result = await _testService.FetchUnbatchedOperations();

    //ASSERT
    result.Status.Should().Be(FetchUnbatchedOperationsStatus.NoOperationsFound);
    _mockOperationsContainer.Verify();
    _mockOperationsContainer.VerifyNoOtherCalls();
    _mockInvalidDataContainer.VerifyNoOtherCalls();
    _mockBatchesContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void FetchUnbatchedOperations_SuccessfullyFetch_ReturnsCorrespondingStatusAndOperations()
  {
    // ARRANGE
    var (unbatchedOps, _, _, _, expectedDtos) = GenerateBatchBuildingTestData();
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetQueryText(It.IsAny<IQueryable<PostiOperationDocument>>()))
      .Returns("Some query");
    var mockFeedIterator = new Mock<FeedIterator<PostiOperationDocument>>();
    mockFeedIterator
      .SetupSequence(fi => fi.HasMoreResults)
      .Returns(true)
      .Returns(false);
    var mockFeedResponse = new Mock<FeedResponse<PostiOperationDocument>>();
    mockFeedResponse
        .Setup(fr => fr.GetEnumerator()).Returns(unbatchedOps.GetEnumerator());
    mockFeedIterator
        .SetupSequence(fi => fi.ReadNextAsync(default))
        .ReturnsAsync(mockFeedResponse.Object);
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetFeedIterator(It.IsAny<IQueryable<PostiOperationDocument>>()))
      .Returns(mockFeedIterator.Object);
    _mockOperationsContainer
      .Setup(c => c.GetItemLinqQueryable<PostiOperationDocument>(false, null, null, null))
      .Returns(new EnumerableQuery<PostiOperationDocument>(new List<PostiOperationDocument>()))
      .Verifiable();

    // ACT
    var result = await _testService.FetchUnbatchedOperations();

    //ASSERT
    result.Status.Should().Be(FetchUnbatchedOperationsStatus.Success);
    result.OperationDtos.Should().BeEquivalentTo(expectedDtos);
    result.OriginalOperations.Should().BeEquivalentTo(unbatchedOps.ToList());
    _mockOperationsContainer.Verify();
    _mockOperationsContainer.VerifyNoOtherCalls();
    _mockInvalidDataContainer.VerifyNoOtherCalls();
    _mockBatchesContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void StoreNewBatch_ErrorStoringNewBatch_ReturnsFalse()
  {
    // ARRANGE
    var (unbatchedOps, expectedBatch, _, _, _) = GenerateBatchBuildingTestData();
    _mockBatchesContainer
      .Setup(c => c.CreateItemAsync(
        It.Is<BatchDocument>(batch => batch.Id == expectedBatch.Id && batch.PartitionKey == expectedBatch.PartitionKey && batch.Operations.SequenceEqual(expectedBatch.Operations)),
        It.Is<PartitionKey>(key => key == new PartitionKey("key")),
        It.IsAny<ItemRequestOptions>(),
        default))
      .ThrowsAsync(new CosmosException("Oops!", HttpStatusCode.InternalServerError, 500, "id", 1.0))
      .Verifiable();

    // ACT

    var result = await _testService.StoreNewBatch(unbatchedOps.ToList());

    //ASSERT

    result.Should().BeFalse();
    _mockOperationsContainer.Verify();
    _mockOperationsContainer.VerifyNoOtherCalls();
    _mockBatchesContainer.Verify();
    _mockBatchesContainer.VerifyNoOtherCalls();
    _mockInvalidDataContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void StoreNewBatch_SuccessfullyBuildBatch_ReturnsTrue()
  {
    // ARRANGE

    var (unbatchedOps, expectedBatch, delIds, recreateDocs, _) = GenerateBatchBuildingTestData();
    // Configure storing new batch
    _mockBatchesContainer
      .Setup(c => c.CreateItemAsync(
        It.Is<BatchDocument>(batch => batch.Id == expectedBatch.Id && batch.PartitionKey == expectedBatch.PartitionKey && batch.Operations.SequenceEqual(expectedBatch.Operations)),
        It.Is<PartitionKey>(key => key == new PartitionKey("key")),
        It.IsAny<ItemRequestOptions>(),
        default))
      .ReturnsAsync(_mockStoreBatchResponse.Object)
      .Verifiable();
    // Configure deleting old docs
    foreach (var docId in delIds)
    {
      _mockOperationsContainer
        .Setup(c => c.DeleteItemAsync<PostiOperationDocument>(
          It.Is<string>(id => id == docId),
          It.Is<PartitionKey>(key => key == new PartitionKey(_mockSettings.OperationsUnbatchedPartitionKey)),
          It.IsAny<ItemRequestOptions>(),
          default))
        .ReturnsAsync(_mockDeletePostiOperationResponse.Object)
        .Verifiable();
    }
    // Configure recreating docs
    foreach (var recreateDoc in recreateDocs)
    {
      _mockOperationsContainer
        .Setup(container => container.UpsertItemAsync(
          It.Is<PostiOperationDocument>(doc => doc == recreateDoc),
          It.Is<PartitionKey>(key => key == new PartitionKey(expectedBatch.Id)),
          It.IsAny<ItemRequestOptions>(),
          default))
        .ReturnsAsync(_mockStoreOperationDocumentResponse.Object)
        .Verifiable();
    }

    // ACT

    var result = await _testService.StoreNewBatch(unbatchedOps.ToList());

    //ASSERT

    result.Should().BeTrue();
    _mockOperationsContainer.Verify();
    _mockOperationsContainer.VerifyNoOtherCalls();
    _mockBatchesContainer.Verify();
    _mockBatchesContainer.VerifyNoOtherCalls();
    _mockInvalidDataContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void GetAllBatches_SuccessfullyGetBatches_ReturnBatchRecordDtoCollection()
  {
    // ARRANGE
    var batchesResponse = GenerateBatchDocumentCollection();
    // Configure fetching batches
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetQueryText(It.IsAny<IQueryable<BatchDocument>>()))
      .Returns("Some query");
    var mockFeedIterator = new Mock<FeedIterator<BatchDocument>>();
    mockFeedIterator
      .SetupSequence(fi => fi.HasMoreResults)
      .Returns(true)
      .Returns(false);
    var mockFeedResponse = new Mock<FeedResponse<BatchDocument>>();
    mockFeedResponse
        .Setup(fr => fr.GetEnumerator()).Returns(batchesResponse.GetEnumerator());
    mockFeedIterator
        .SetupSequence(fi => fi.ReadNextAsync(default))
        .ReturnsAsync(mockFeedResponse.Object);
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetFeedIterator(It.IsAny<IQueryable<BatchDocument>>()))
      .Returns(mockFeedIterator.Object);
    _mockBatchesContainer
      .Setup(c => c.GetItemLinqQueryable<BatchDocument>(false, null, null, null))
      .Returns(new EnumerableQuery<BatchDocument>(new List<BatchDocument>()))
      .Verifiable();

    // ACT
    var result = await _testService.GetAllBatches();

    // ASSERT
    result.Status.Should().Be(FetchBatchStatus.Success);
    result.Batches.Should().BeEquivalentTo(batchesResponse);
    _mockOperationsContainer.Verify();
    _mockOperationsContainer.VerifyNoOtherCalls();
    _mockBatchesContainer.Verify();
    _mockBatchesContainer.VerifyNoOtherCalls();
    _mockInvalidDataContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void GetAllBatches_FailedBatchFetch_ReturnNull()
  {
    // ARRANGE
    var batchesResponse = GenerateBatchDocumentCollection();
    // Configure fetching batches
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetQueryText(It.IsAny<IQueryable<BatchDocument>>()))
      .Returns("Some query");
    var mockFeedIterator = new Mock<FeedIterator<BatchDocument>>();
    mockFeedIterator
      .SetupSequence(fi => fi.HasMoreResults)
      .Returns(true)
      .Returns(false);
    mockFeedIterator
      .Setup(fi => fi.ReadNextAsync(default))
      .ThrowsAsync(new CosmosException("Oops!", HttpStatusCode.InternalServerError, 500, "id", 1.0));
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetFeedIterator(It.IsAny<IQueryable<BatchDocument>>()))
      .Returns(mockFeedIterator.Object);
    _mockBatchesContainer
      .Setup(c => c.GetItemLinqQueryable<BatchDocument>(false, null, null, null))
      .Returns(new EnumerableQuery<BatchDocument>(new List<BatchDocument>()))
      .Verifiable();

    // ACT
    var result = await _testService.GetAllBatches();

    // ASSERT
    result.Status.Should().Be(FetchBatchStatus.ErrorFetchingBatches);
    result.Batches.Should().BeNull();
    _mockOperationsContainer.Verify();
    _mockOperationsContainer.VerifyNoOtherCalls();
    _mockBatchesContainer.Verify();
    _mockBatchesContainer.VerifyNoOtherCalls();
    _mockInvalidDataContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void GetAllBatches_EmptyResult_ReturnEmptyBatchRecordDtoCollection()
  {
    // ARRANGE
    var batchesResponse = new List<BatchDocument>();
    // Configure fetching unbatched operations
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetQueryText(It.IsAny<IQueryable<BatchDocument>>()))
      .Returns("Some query");
    var mockFeedIterator = new Mock<FeedIterator<BatchDocument>>();
    mockFeedIterator
      .SetupSequence(fi => fi.HasMoreResults)
      .Returns(true)
      .Returns(false);
    var mockFeedResponse = new Mock<FeedResponse<BatchDocument>>();
    mockFeedResponse
        .Setup(fr => fr.GetEnumerator()).Returns(batchesResponse.GetEnumerator());
    mockFeedIterator
        .SetupSequence(fi => fi.ReadNextAsync(default))
        .ReturnsAsync(mockFeedResponse.Object);
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetFeedIterator(It.IsAny<IQueryable<BatchDocument>>()))
      .Returns(mockFeedIterator.Object);
    _mockBatchesContainer
      .Setup(c => c.GetItemLinqQueryable<BatchDocument>(false, null, null, null))
      .Returns(new EnumerableQuery<BatchDocument>(new List<BatchDocument>()))
      .Verifiable();

    // ACT
    var result = await _testService.GetAllBatches();

    // ASSERT
    result.Status.Should().Be(FetchBatchStatus.Success);
    result.Batches.Should().BeEquivalentTo(batchesResponse);
    _mockOperationsContainer.Verify();
    _mockOperationsContainer.VerifyNoOtherCalls();
    _mockBatchesContainer.Verify();
    _mockBatchesContainer.VerifyNoOtherCalls();
    _mockInvalidDataContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void GetBatch_SuccessfullyGetLatest_ReturnBatchDocument()
  {
    // ARRANGE
    var batchesResponse = GenerateBatchDocumentCollection();
    // Configure fetching unbatched operations
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetQueryText(It.IsAny<IQueryable<BatchDocument>>()))
      .Returns("Some query");
    var mockFeedIterator = new Mock<FeedIterator<BatchDocument>>();
    mockFeedIterator
      .SetupSequence(fi => fi.HasMoreResults)
      .Returns(true)
      .Returns(false);
    var mockFeedResponse = new Mock<FeedResponse<BatchDocument>>();
    mockFeedResponse
        .Setup(fr => fr.GetEnumerator()).Returns(batchesResponse.GetEnumerator());
    mockFeedIterator
        .SetupSequence(fi => fi.ReadNextAsync(default))
        .ReturnsAsync(mockFeedResponse.Object);
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetFeedIterator(It.IsAny<IQueryable<BatchDocument>>()))
      .Returns(mockFeedIterator.Object);
    _mockBatchesContainer
      .Setup(c => c.GetItemLinqQueryable<BatchDocument>(false, null, null, null))
      .Returns(new EnumerableQuery<BatchDocument>(new List<BatchDocument>()))
      .Verifiable();

    // ACT
    var result = await _testService.GetBatch();

    //ASSERT
    result.Status.Should().Be(FetchBatchStatus.Success);
    result.Batch.Should().BeEquivalentTo(batchesResponse.LastOrDefault());
    _mockOperationsContainer.VerifyNoOtherCalls();
    _mockBatchesContainer.Verify();
    _mockBatchesContainer.VerifyNoOtherCalls();
    _mockInvalidDataContainer.VerifyNoOtherCalls();
  }
  [Fact]
  public async void CheckIfCustomerAddOperationAlreadyExists_ReturnTrue()
  {
    // ARRANGE
    var inputDto = GenerateTestOperation(operation: PostiOperations.Add);
    var (unbatchedOps, _, _, _, _) = GenerateBatchBuildingTestData();
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetQueryText(It.IsAny<IQueryable<PostiOperationDocument>>()))
      .Returns("Some query");
    var mockFeedIterator = new Mock<FeedIterator<PostiOperationDocument>>();
    mockFeedIterator
      .SetupSequence(fi => fi.HasMoreResults)
      .Returns(true)
      .Returns(false);
    var mockFeedResponse = new Mock<FeedResponse<PostiOperationDocument>>();
    mockFeedResponse
        .Setup(fr => fr.GetEnumerator()).Returns(unbatchedOps.GetEnumerator());
    mockFeedIterator
        .SetupSequence(fi => fi.ReadNextAsync(default))
        .ReturnsAsync(mockFeedResponse.Object);
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetFeedIterator(It.IsAny<IQueryable<PostiOperationDocument>>()))
      .Returns(mockFeedIterator.Object);
    _mockOperationsContainer
      .Setup(c => c.GetItemLinqQueryable<PostiOperationDocument>(false, null, null, null))
      .Returns(new EnumerableQuery<PostiOperationDocument>(new List<PostiOperationDocument>()))
      .Verifiable();

    // ACT
    var result = await _testService.CheckIfCustomerAddOperationAlreadyExists(inputDto);

    //ASSERT
    result.Should().Be(true);
    _mockOperationsContainer.Verify();
    _mockOperationsContainer.VerifyNoOtherCalls();
    _mockInvalidDataContainer.VerifyNoOtherCalls();
    _mockBatchesContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void CheckIfCustomerAddOperationAlreadyExists_ReturnFalse()
  {
    // ARRANGE
    var inputDto = GenerateTestOperation(operation: PostiOperations.Add);
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetQueryText(It.IsAny<IQueryable<PostiOperationDocument>>()))
      .Returns("Some query");
    var mockFeedIterator = new Mock<FeedIterator<PostiOperationDocument>>();
    mockFeedIterator
      .Setup(fi => fi.HasMoreResults)
      .Returns(false);
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetFeedIterator(It.IsAny<IQueryable<PostiOperationDocument>>()))
      .Returns(mockFeedIterator.Object);
    _mockOperationsContainer
      .Setup(c => c.GetItemLinqQueryable<PostiOperationDocument>(false, null, null, null))
      .Returns(new EnumerableQuery<PostiOperationDocument>(new List<PostiOperationDocument>()))
      .Verifiable();
    

    // ACT
    var result = await _testService.CheckIfCustomerAddOperationAlreadyExists(inputDto);

    //ASSERT
    result.Should().Be(false);
    _mockOperationsContainer.Verify();
    _mockOperationsContainer.VerifyNoOtherCalls();
    _mockInvalidDataContainer.VerifyNoOtherCalls();
    _mockBatchesContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void CheckIfCustomerAddOperationAlreadyExists_ThrowsError_ReturnFalse()
  {
    // ARRANGE
    var inputDto = GenerateTestOperation(operation: PostiOperations.Add);
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetQueryText(It.IsAny<IQueryable<PostiOperationDocument>>()))
      .Returns("Some query");
    var mockFeedIterator = new Mock<FeedIterator<PostiOperationDocument>>();
    mockFeedIterator
      .SetupSequence(fi => fi.HasMoreResults)
      .Returns(true)
      .Returns(false);
    mockFeedIterator
      .Setup(fi => fi.ReadNextAsync(default))
      .ThrowsAsync(new CosmosException("Oops!", HttpStatusCode.InternalServerError, 500, "id", 1.0));
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetFeedIterator(It.IsAny<IQueryable<PostiOperationDocument>>()))
      .Returns(mockFeedIterator.Object);
    _mockOperationsContainer
      .Setup(c => c.GetItemLinqQueryable<PostiOperationDocument>(false, null, null, null))
      .Returns(new EnumerableQuery<PostiOperationDocument>(new List<PostiOperationDocument>()))
      .Verifiable();

    // ACT
    var result = await _testService.CheckIfCustomerAddOperationAlreadyExists(inputDto);

    //ASSERT
    result.Should().Be(false);
    _mockOperationsContainer.Verify();
    _mockOperationsContainer.VerifyNoOtherCalls();
    _mockInvalidDataContainer.VerifyNoOtherCalls();
    _mockBatchesContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void StorePostiOperationWithCheckForLeftEvent_OperationStored_ReturnsTrue()
  {
    // Arrange
    var inputDto = GenerateTestOperation(operation: PostiOperations.Remove);
    var expectedDocument = new PostiOperationDocument()
    {
      Id = $"{inputDto.Timestamp}::{inputDto.CustomerNumber}::{inputDto.Operation}",
      BatchId = _mockSettings.OperationsUnbatchedPartitionKey,
      Timestamp = inputDto.Timestamp,
      Operation = inputDto.Operation,
      CustomerNumber = inputDto.CustomerNumber,
      Ssn = inputDto.Ssn,
      LastName = inputDto.LastName,
      FirstName = inputDto.FirstName,
      PostalCode = inputDto.PostalCode,
      City = inputDto.City,
      Address = inputDto.Address,
      Telephone = inputDto.Telephone,
      Email = inputDto.Email,
      Extra = inputDto.Extra,
    };

    var expectedCustomer = new CustomerDocument
    {
      Id = inputDto.CustomerNumber,
      EventType = "CUSTOMER_LEFT",
      Ttl = _mockSettings.CustomerLeftDocumentTtl
    };
    var mockDocuments = new List<PostiOperationDocument>
    {
        new PostiOperationDocument
        {
            BatchId = _mockSettings.OperationsUnbatchedPartitionKey,
            CustomerNumber = "CustomerNumber1",
            Operation = PostiOperations.Add
        },
        new PostiOperationDocument
        {
            BatchId = _mockSettings.OperationsUnbatchedPartitionKey,
            CustomerNumber = "CustomerNumber1",
            Operation = PostiOperations.Add
        }
    };


    var expectedPartitionKey = new PartitionKey(_mockSettings.OperationsUnbatchedPartitionKey);
    var expectedCustomerPartitionKey = new PartitionKey(inputDto.CustomerNumber);
    _mockOperationsContainer
      .Setup(container => container.UpsertItemAsync(
        It.Is<PostiOperationDocument>(doc => doc == expectedDocument),
        It.Is<PartitionKey>(key => key == expectedPartitionKey),
        It.IsAny<ItemRequestOptions>(),
        default))
      .ReturnsAsync(_mockStoreOperationDocumentResponse.Object)
      .Verifiable();

    _mockCustomerContainer
      .Setup(container => container.UpsertItemAsync(
        It.Is<CustomerDocument>(doc => doc.Id == expectedCustomer.Id),
        It.Is<PartitionKey>(key => key == expectedCustomerPartitionKey),
        It.IsAny<ItemRequestOptions>(),
        default))
      .ReturnsAsync(_mockCustomerResponse.Object)
      .Verifiable();
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetQueryText(It.IsAny<IQueryable<PostiOperationDocument>>()))
      .Returns("Some query");
    var mockFeedIterator = new Mock<FeedIterator<PostiOperationDocument>>();
    mockFeedIterator
      .Setup(fi => fi.HasMoreResults)
      .Returns(false);
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetFeedIterator(It.IsAny<IQueryable<PostiOperationDocument>>()))
      .Returns(mockFeedIterator.Object);
    _mockOperationsContainer
      .Setup(c => c.GetItemLinqQueryable<PostiOperationDocument>(false, null, null, null))
      .Returns(new EnumerableQuery<PostiOperationDocument>(mockDocuments))
      .Verifiable();

    // Act
    var result = await _testService.StorePostiOperationWithCheckForLeftEvent(inputDto);

    // Assert
    result.Should().BeTrue();
    _mockOperationsContainer.Verify();
    _mockOperationsContainer.VerifyNoOtherCalls();
    _mockCustomerContainer.Verify();
    _mockCustomerContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void CheckIfCustomerMarkedAsLeft_ReturnsTrue()
  {
    // Arrange
    var customerId = "1000001";
    var expectedCustomer = new CustomerDocument
    {
      Id = customerId,
      EventType = "CUSTOMER_LEFT",
      Ttl = _mockSettings.CustomerLeftDocumentTtl
    };
    var expectedCustomerJson = JsonConvert.SerializeObject(expectedCustomer);

    var mockCustomerResponse = new Mock<ResponseMessage>();
    mockCustomerResponse.Setup(r => r.StatusCode).Returns(HttpStatusCode.OK);
    mockCustomerResponse.Setup(r => r.IsSuccessStatusCode).Returns(true);
    mockCustomerResponse.Setup(r => r.Content).Returns(new MemoryStream(Encoding.UTF8.GetBytes(expectedCustomerJson)));


    var expectedPartitionKey = new PartitionKey(customerId);
    _mockCustomerContainer
      .Setup(container => container.ReadItemStreamAsync(
        It.Is<string>(id => id == customerId),
        It.Is<PartitionKey>(key => key == expectedPartitionKey),
        It.IsAny<ItemRequestOptions>(),
        default))
      .Returns(() => Task.FromResult(mockCustomerResponse.Object))
      .Verifiable();

    // Act
    var result = await _testService.CheckIfCustomerMarkedAsLeft(customerId);

    // Assert
    result.Should().BeTrue();
    _mockCustomerContainer.Verify();
    _mockCustomerContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void CheckIfCustomerMarkedAsLeft_ThrowsError_ReturnsFalse()
  {
    // Arrange
    var customerId = "1000001";
    var exception = new CosmosException("mocked exception", HttpStatusCode.InternalServerError, 0, string.Empty, 0);
    var expectedCustomer = new CustomerDocument
    {
      Id = customerId,
      EventType = "CUSTOMER_LEFT",
      Ttl = _mockSettings.CustomerLeftDocumentTtl
    };
    var expectedCustomerJson = JsonConvert.SerializeObject(expectedCustomer);

    var mockCustomerResponse = new Mock<ResponseMessage>();
    mockCustomerResponse.Setup(r => r.StatusCode).Returns(HttpStatusCode.OK);
    mockCustomerResponse.Setup(r => r.IsSuccessStatusCode).Returns(true);
    mockCustomerResponse.Setup(r => r.Content).Returns(new MemoryStream(Encoding.UTF8.GetBytes(expectedCustomerJson)));


    var expectedPartitionKey = new PartitionKey(customerId);
    _mockCustomerContainer
      .Setup(container => container.ReadItemStreamAsync(
        It.Is<string>(id => id == customerId),
        It.Is<PartitionKey>(key => key == expectedPartitionKey),
        It.IsAny<ItemRequestOptions>(),
        default))
      .Throws(exception)
      .Verifiable();

    // Act
    var result = await _testService.CheckIfCustomerMarkedAsLeft(customerId);

    // Assert
    result.Should().BeFalse();
    _mockCustomerContainer.Verify();
    _mockCustomerContainer.VerifyNoOtherCalls();
  }

  [Theory]
  [InlineData(HttpStatusCode.NotFound, true, "CUSTOMER_LEFT")]
  [InlineData(HttpStatusCode.OK, false, "CUSTOMER_LEFT")]
  [InlineData(HttpStatusCode.OK, true, "NOT_VALID")]
  public async void CheckIfCustomerMarkedAsLeft_ReturnsFalse(HttpStatusCode code, bool isSuccess, string eventType)
  {
    // Arrange
    var customerId = "1000001";
    var expectedCustomer = new CustomerDocument
    {
      Id = customerId,
      EventType = eventType,
      Ttl = _mockSettings.CustomerLeftDocumentTtl
    };
    var expectedCustomerJson = JsonConvert.SerializeObject(expectedCustomer);

    var mockCustomerResponse = new Mock<ResponseMessage>();
    mockCustomerResponse.Setup(r => r.StatusCode).Returns(code);
    mockCustomerResponse.Setup(r => r.IsSuccessStatusCode).Returns(isSuccess);
    mockCustomerResponse.Setup(r => r.Content).Returns(new MemoryStream(Encoding.UTF8.GetBytes(expectedCustomerJson)));


    var expectedPartitionKey = new PartitionKey(customerId);
    _mockCustomerContainer
      .Setup(container => container.ReadItemStreamAsync(
        It.Is<string>(id => id == customerId),
        It.Is<PartitionKey>(key => key == expectedPartitionKey),
        It.IsAny<ItemRequestOptions>(),
        default))
      .Returns(() => Task.FromResult(mockCustomerResponse.Object))
      .Verifiable();

    // Act
    var result = await _testService.CheckIfCustomerMarkedAsLeft(customerId);

    // Assert
    result.Should().BeFalse();
    _mockCustomerContainer.Verify();
    _mockCustomerContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void GetBatch_FailedGettingAllBatches_ReturnBatchDocument()
  {
    // ARRANGE
    var batchesResponse = GenerateBatchDocumentCollection();
    // Configure fetching unbatched operations
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetQueryText(It.IsAny<IQueryable<BatchDocument>>()))
      .Returns("Some query");
    var mockFeedIterator = new Mock<FeedIterator<BatchDocument>>();
    mockFeedIterator
      .SetupSequence(fi => fi.HasMoreResults)
      .Returns(true)
      .Returns(false);
    mockFeedIterator
       .Setup(fi => fi.ReadNextAsync(default))
       .ThrowsAsync(new CosmosException("Oops!", HttpStatusCode.InternalServerError, 500, "id", 1.0));
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetFeedIterator(It.IsAny<IQueryable<BatchDocument>>()))
      .Returns(mockFeedIterator.Object);
    _mockBatchesContainer
      .Setup(c => c.GetItemLinqQueryable<BatchDocument>(false, null, null, null))
      .Returns(new EnumerableQuery<BatchDocument>(new List<BatchDocument>()))
      .Verifiable();

    // ACT
    var result = await _testService.GetBatch();

    //ASSERT
    result.Status.Should().Be(FetchBatchStatus.ErrorFetchingBatches);
    _mockOperationsContainer.VerifyNoOtherCalls();
    _mockBatchesContainer.Verify();
    _mockBatchesContainer.VerifyNoOtherCalls();
    _mockInvalidDataContainer.VerifyNoOtherCalls();
  }

  [Theory]
  [InlineData(10, 0)]
  [InlineData(11, 1)]
  [InlineData(12, 2)]
  [InlineData(13, 3)]
  [InlineData(14, 4)]
  public async void GetBatch_GetBatchByDateTime_ReturnSuccessResult(int day, int collectionElement)
  {
    // ARRANGE
    var batchesResponse = GenerateBatchDocumentCollection();
    // Configure fetching unbatched operations
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetQueryText(It.IsAny<IQueryable<BatchDocument>>()))
      .Returns("Some query");
    var mockFeedIterator = new Mock<FeedIterator<BatchDocument>>();
    mockFeedIterator
      .SetupSequence(fi => fi.HasMoreResults)
      .Returns(true)
      .Returns(false);
    var mockFeedResponse = new Mock<FeedResponse<BatchDocument>>();
    mockFeedResponse
        .Setup(fr => fr.GetEnumerator()).Returns(batchesResponse.GetEnumerator());
    mockFeedIterator
        .SetupSequence(fi => fi.ReadNextAsync(default))
        .ReturnsAsync(mockFeedResponse.Object);
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetFeedIterator(It.IsAny<IQueryable<BatchDocument>>()))
      .Returns(mockFeedIterator.Object);
    _mockBatchesContainer
      .Setup(c => c.GetItemLinqQueryable<BatchDocument>(false, null, null, null))
      .Returns(new EnumerableQuery<BatchDocument>(new List<BatchDocument>()))
      .Verifiable();

    var date = new DateTime(2022, 1, day, 7, 30, 45, DateTimeKind.Utc);

    // ACT
    var result = await _testService.GetBatch(date);

    //ASSERT
    result.Status.Should().Be(FetchBatchStatus.Success);
    result.Batch.Should().BeEquivalentTo(batchesResponse.ToList()[collectionElement]);
    _mockOperationsContainer.VerifyNoOtherCalls();
    _mockBatchesContainer.Verify();
    _mockBatchesContainer.VerifyNoOtherCalls();
    _mockInvalidDataContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void GetBatch_NoBatches_ReturnSuccessWithEmptyBatch()
  {
    // ARRANGE
    var batchesResponse = new List<BatchDocument>();
    // Configure fetching unbatched operations
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetQueryText(It.IsAny<IQueryable<BatchDocument>>()))
      .Returns("Some query");
    var mockFeedIterator = new Mock<FeedIterator<BatchDocument>>();
    mockFeedIterator
      .SetupSequence(fi => fi.HasMoreResults)
      .Returns(true)
      .Returns(false);
    var mockFeedResponse = new Mock<FeedResponse<BatchDocument>>();
    mockFeedResponse
        .Setup(fr => fr.GetEnumerator()).Returns(batchesResponse.GetEnumerator());
    mockFeedIterator
        .SetupSequence(fi => fi.ReadNextAsync(default))
        .ReturnsAsync(mockFeedResponse.Object);
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetFeedIterator(It.IsAny<IQueryable<BatchDocument>>()))
      .Returns(mockFeedIterator.Object);
    _mockBatchesContainer
      .Setup(c => c.GetItemLinqQueryable<BatchDocument>(false, null, null, null))
      .Returns(new EnumerableQuery<BatchDocument>(new List<BatchDocument>()))
      .Verifiable();


    // ACT
    var result = await _testService.GetBatch();

    //ASSERT
    result.Status.Should().Be(FetchBatchStatus.Success);
    result.Batch.Should().BeNull();
    _mockOperationsContainer.VerifyNoOtherCalls();
    _mockBatchesContainer.Verify();
    _mockBatchesContainer.VerifyNoOtherCalls();
    _mockInvalidDataContainer.VerifyNoOtherCalls();
  }

  [Theory]
  [InlineData(0, 0)]
  [InlineData(9, 5)]
  [InlineData(10, 4)]
  [InlineData(11, 3)]
  [InlineData(12, 2)]
  [InlineData(13, 1)]
  [InlineData(14, 0)]
  [InlineData(15, 0)]
  public async void DeleteOldbatches_ByDateTimeParameter_ReturnTrue(int day, int collectionCount)
  {
    // ARRANGE
    var batchesResponse = GenerateBatchDocumentCollection().OrderByDescending(x => DateTime.Parse(x.Id));
    // Configure fetching batches
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetQueryText(It.IsAny<IQueryable<BatchDocument>>()))
      .Returns("Some query");
    var mockFeedIterator = new Mock<FeedIterator<BatchDocument>>();
    mockFeedIterator
      .SetupSequence(fi => fi.HasMoreResults)
      .Returns(true)
      .Returns(false);
    var mockFeedResponse = new Mock<FeedResponse<BatchDocument>>();
    mockFeedResponse
        .Setup(fr => fr.GetEnumerator()).Returns(batchesResponse.GetEnumerator());
    mockFeedIterator
        .SetupSequence(fi => fi.ReadNextAsync(default))
        .ReturnsAsync(mockFeedResponse.Object);
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetFeedIterator(It.IsAny<IQueryable<BatchDocument>>()))
      .Returns(mockFeedIterator.Object);
    _mockBatchesContainer
      .Setup(c => c.GetItemLinqQueryable<BatchDocument>(false, null, null, null))
      .Returns(new EnumerableQuery<BatchDocument>(new List<BatchDocument>()))
      .Verifiable();

    //get list of ids for deletion
    var ids = batchesResponse.Skip(collectionCount).Select(item => item.Id);

    // Configure deleting old batches
    foreach (var batchId in ids)
    {
      _mockBatchesContainer
        .Setup(c => c.DeleteItemAsync<BatchDocument>(
          It.Is<string>(id => id == batchId),
          It.Is<PartitionKey>(key => key == new PartitionKey("key")),
          It.IsAny<ItemRequestOptions>(),
          default))
        .ReturnsAsync(_mockDeleteBatchResponse.Object)
        .Verifiable();
    }

    DateTime? date = day == 0 ? null : new DateTime(2022, 1, day, 7, 30, 45, DateTimeKind.Utc);

    // ACT
    var result = await _testService.DeleteOldBatches(date);

    // ASSERT
    result.Should().BeTrue();

    _mockOperationsContainer.Verify();
    _mockOperationsContainer.VerifyNoOtherCalls();
    _mockBatchesContainer.Verify();
    _mockBatchesContainer.VerifyNoOtherCalls();
    _mockInvalidDataContainer.VerifyNoOtherCalls();
  }

  [Fact]
  public async void ClearContainers_ReturnTrue()
  {
    // ARRANGE
    var batchesResponse = GenerateBatchDocumentCollection();
    var (operationsResponse, _, _, _, _) = GenerateBatchBuildingTestData();
    var invalidDataResponse = GenerateInvalidDataCollection();

    SetupFetchingAndDeletingBatches(batchesResponse);
    SetupFetchingAndDeletingPostiOperations(operationsResponse);
    SetupFetchingAndDeletingInvalidData(invalidDataResponse);

    // ACT
    var result = await _testService.ClearContainers();

    // ASSERT
    result.Should().BeTrue();

    _mockOperationsContainer.Verify();
    _mockOperationsContainer.VerifyNoOtherCalls();
    _mockBatchesContainer.Verify();
    _mockBatchesContainer.VerifyNoOtherCalls();
    _mockInvalidDataContainer.Verify();
    _mockInvalidDataContainer.VerifyNoOtherCalls();
  }

  private void SetupFetchingAndDeletingBatches(IEnumerable<BatchDocument> batchesResponse)
  {
    // Configure fetching batches
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetQueryText(It.IsAny<IQueryable<BatchDocument>>()))
      .Returns("Some query");
    var mockFeedIteratorBatches = new Mock<FeedIterator<BatchDocument>>();
    mockFeedIteratorBatches
      .SetupSequence(fi => fi.HasMoreResults)
      .Returns(true)
      .Returns(false);
    var mockFeedBatchesResponse = new Mock<FeedResponse<BatchDocument>>();
    mockFeedBatchesResponse
        .Setup(fr => fr.GetEnumerator()).Returns(batchesResponse.GetEnumerator());
    mockFeedIteratorBatches
        .SetupSequence(fi => fi.ReadNextAsync(default))
        .ReturnsAsync(mockFeedBatchesResponse.Object);
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetFeedIterator(It.IsAny<IQueryable<BatchDocument>>()))
      .Returns(mockFeedIteratorBatches.Object);
    _mockBatchesContainer
      .Setup(c => c.GetItemLinqQueryable<BatchDocument>(false, null, null, null))
      .Returns(new EnumerableQuery<BatchDocument>(new List<BatchDocument>()))
      .Verifiable();

    var batchesIds = batchesResponse.Select(item => item.Id).ToList() ;

    // Configure deleting batches
    foreach (var batchId in batchesIds)
    {
      _mockBatchesContainer
        .Setup(c => c.DeleteItemAsync<BatchDocument>(
          It.Is<string>(id => id == batchId),
          It.Is<PartitionKey>(key => key == new PartitionKey("key")),
          It.IsAny<ItemRequestOptions>(),
          default))
        .ReturnsAsync(_mockDeleteBatchResponse.Object)
        .Verifiable();
    }
  }

  private void SetupFetchingAndDeletingPostiOperations(IEnumerable<PostiOperationDocument>? operationsResponse)
  {
    // Configure fetching posti operations
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetQueryText(It.IsAny<IQueryable<PostiOperationDocument>>()))
      .Returns("Some query");
    var mockFeedIteratorPostiOperations = new Mock<FeedIterator<PostiOperationDocument>>();
    mockFeedIteratorPostiOperations
      .SetupSequence(fi => fi.HasMoreResults)
      .Returns(true)
      .Returns(false);
    var mockFeedPostiOperationsResponse = new Mock<FeedResponse<PostiOperationDocument>>();
    _ = mockFeedPostiOperationsResponse
        .Setup(fr => fr.GetEnumerator()).Returns(operationsResponse.GetEnumerator());
    mockFeedIteratorPostiOperations
        .SetupSequence(fi => fi.ReadNextAsync(default))
        .ReturnsAsync(mockFeedPostiOperationsResponse.Object);
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetFeedIterator(It.IsAny<IQueryable<PostiOperationDocument>>()))
      .Returns(mockFeedIteratorPostiOperations.Object);
    _mockOperationsContainer
      .Setup(c => c.GetItemLinqQueryable<PostiOperationDocument>(false, null, null, null))
      .Returns(new EnumerableQuery<PostiOperationDocument>(new List<PostiOperationDocument>()))
      .Verifiable();

    var operationsIds = operationsResponse.Select(item => item.Id).ToList() ;

    // Configure deleting posti operations
    foreach (var operation in operationsResponse)
    {
      _mockOperationsContainer
        .Setup(c => c.DeleteItemAsync<PostiOperationDocument>(
          It.Is<string>(id => id == operation.Id),
          It.Is<PartitionKey>(key => key == new PartitionKey(_mockSettings.OperationsUnbatchedPartitionKey)),
          It.IsAny<ItemRequestOptions>(),
          default))
        .ReturnsAsync(_mockDeletePostiOperationResponse.Object)
        .Verifiable();
    }
  }

  private void SetupFetchingAndDeletingInvalidData(IEnumerable<InvalidDataDocument> invalidDataResponse)
  {
    // Configure fetching invalid data
    _mockCosmosLinqQueryWrapper
      .Setup(w => w.GetQueryText(It.IsAny<IQueryable<InvalidDataDocument>>()))
      .Returns("Some query");
    var mockFeedIteratorInvalidData = new Mock<FeedIterator<InvalidDataDocument>>();
    mockFeedIteratorInvalidData
      .SetupSequence(fi => fi.HasMoreResults)
      .Returns(true)
      .Returns(false);
    var mockFeedInvalidDataResponse = new Mock<FeedResponse<InvalidDataDocument>>();
    mockFeedInvalidDataResponse
        .Setup(fr => fr.GetEnumerator()).Returns(invalidDataResponse.GetEnumerator());
    mockFeedIteratorInvalidData
        .SetupSequence(fi => fi.ReadNextAsync(default))
        .ReturnsAsync(mockFeedInvalidDataResponse.Object);
    _mockCosmosLinqQueryWrapper
     .Setup(w => w.GetFeedIterator(It.IsAny<IQueryable<InvalidDataDocument>>()))
     .Returns(mockFeedIteratorInvalidData.Object);
    _mockInvalidDataContainer
      .Setup(c => c.GetItemLinqQueryable<InvalidDataDocument>(false, null, null, null))
      .Returns(new EnumerableQuery<InvalidDataDocument>(new List<InvalidDataDocument>()))
      .Verifiable();

    // Configure deleting invalid data
    foreach (var invalidData in invalidDataResponse)
    {
      _mockInvalidDataContainer
        .Setup(c => c.DeleteItemAsync<InvalidDataDocument>(
          It.Is<string>(id => id == invalidData.Id),
          It.Is<PartitionKey>(key => key == new PartitionKey(invalidData.Operation.ToString())),
          It.IsAny<ItemRequestOptions>(),
          default))
        .ReturnsAsync(_mockDeleteInvalidDataResponse.Object)
        .Verifiable();
    }
  }

  #region Data generators

  private static PostiOperationDto GenerateTestOperation(
    long timestamp = 1234567,
    PostiOperations operation = PostiOperations.Add,
    string customerNumber = "000000",
    string ssn = "010100-0000",
    string lastName = "Teekkari",
    string firstName = "Teemu",
    string postalCode = "00100",
    string city = "Helsinki",
    string address = "Feikkikatu 1",
    string telephone = "0401112222",
    string email = "teemu.teekkari@mailplace.com",
    string extra = "")
  {
    return new PostiOperationDto()
    {
      Timestamp = timestamp,
      Operation = operation,
      CustomerNumber = customerNumber,
      Ssn = ssn,
      LastName = lastName,
      FirstName = firstName,
      PostalCode = postalCode,
      City = city,
      Address = address,
      Telephone = telephone,
      Email = email,
      Extra = extra
    };
  }
 
  private (
    IEnumerable<PostiOperationDocument> unbatchedOperations,
    BatchDocument expectedBatch,
    IEnumerable<string> expectedDeletionIds,
    IEnumerable<PostiOperationDocument> expectedRecreationDocs,
    List<PostiOperationDto> expectedBatchOperations)
    GenerateBatchBuildingTestData()
  {
    var unbatchedOps = Utils.GenerateOperationDocs(4, _mockSettings.OperationsUnbatchedPartitionKey);
    var batch = new BatchDocument()
    {
      Id = _testClock.GetCurrentInstant().ToString("yyyy-MM-ddTHH:mm:ss:fff", CultureInfo.InvariantCulture),
      PartitionKey = "key",
      Operations = unbatchedOps
      .OrderBy(op => op.Timestamp)
      .Select(op => BatchOperation.CreateFromPostiOperationDocument(op))
      .ToList()
    };
    var deleteIds = unbatchedOps.Select(op => op.Id);
    var recreateDocs = unbatchedOps
      .Select(op => op with { BatchId = batch.Id });
    var batchOperations = unbatchedOps
      .OrderBy(op => op.Timestamp)
      .Select(op => PostiOperationDto.CreateFromPostiOperationDocument(op))
      .ToList();
    return (unbatchedOps, batch, deleteIds, recreateDocs, batchOperations);
  }

  private IEnumerable<BatchDocument> GenerateBatchDocumentCollection()
  {
    var batchCollection = new List<BatchDocument>();
    for (int i = 0; i < 5; i++)
    {
      var clock = _testClock.GetCurrentInstant().Plus(Duration.FromDays(i));

      var unbatchedOps = Utils.GenerateOperationDocs(4, _mockSettings.OperationsUnbatchedPartitionKey);
      var batch = new BatchDocument()
      {
        Id = clock.ToString("g", CultureInfo.InvariantCulture),
        PartitionKey = "key",
        Operations = unbatchedOps
      .OrderBy(op => op.Timestamp)
      .Select(op => BatchOperation.CreateFromPostiOperationDocument(op))
      .ToList()
      };
      batchCollection.Add(batch);
    }
    return batchCollection;
  }

  private IEnumerable<InvalidDataDocument> GenerateInvalidDataCollection()
  {
    // ASSIGN
    var inputDto = GenerateTestOperation();
    var mockInvalidBody = "{ \"this\": \"isn't right\" }";
    var expectedDocument = new InvalidDataDocument()
    {
      Id = $"{inputDto.Timestamp}::{inputDto.CustomerNumber}::{inputDto.Operation}",
      Timestamp = inputDto.Timestamp,
      Operation = inputDto.Operation,
      CustomerNumber = inputDto.CustomerNumber,
      RawEvent = mockInvalidBody
    };

    return new List<InvalidDataDocument>() { expectedDocument };
  }

  #endregion
}
