﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using EventBatchHandler.Config.Models;
using EventBatchHandler.CosmosDb;
using EventBatchHandler.Factories;
using EventBatchHandler.Models;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Xunit;

namespace EventBatchHandler.Test;
public class StoreCaputredEventsTest
{
  private readonly Mock<ICosmosDbService> _mockDbService;
  private readonly StoreCaputredEvents _testTrigger;
  private readonly PilotSettings _testSettings;
  public StoreCaputredEventsTest(ILogger<StoreCaputredEvents> logger)
  {
    _mockDbService = new Mock<ICosmosDbService>();
    _testSettings = new PilotSettings
    {
      IsPilotEnabled = false,
      PilotCustomerId = "15200"
    };
    _testTrigger = new StoreCaputredEvents(logger, _mockDbService.Object, new PostiOperationDtoFactory(_testSettings));
  }

  [Fact]
  public async void ValidRequest_SuccessResponse()
  {
    string body = Utils.ReadFixture("capturedEventsBody.json");
    var test = JsonConvert.DeserializeObject<List<JObject>>(body);
    var request = Utils.CreateMockRequestWithBody(test);
    _mockDbService.Setup(x => x.StoreInvalidData(It.IsAny<PostiOperationDto>(), It.IsAny<string>())).ReturnsAsync(true);
    _mockDbService.Setup(x => x.StoreNewPostiOperation(It.IsAny<PostiOperationDto>(), false)).ReturnsAsync(true);

    //Act
    Func<Task<IActionResult>> act = () => _testTrigger.Run(request.Object);

    //Assert            
    var result = await act.Should().NotThrowAsync();
    var response = result.Which;
    response.Should().BeAssignableTo<NoContentResult>();
  }

  [Fact]
  public async void ValidRequest_PilotSettings()
  {
    var testSettings = new PilotSettings
    {
      IsPilotEnabled = true,
      PilotCustomerId = "15"
    };
    var testTrigger = new StoreCaputredEvents(Mock.Of<ILogger<StoreCaputredEvents>>(), _mockDbService.Object, new PostiOperationDtoFactory(testSettings));
    string body = Utils.ReadFixture("capturedEventsBody_pilot.json");
    var test = JsonConvert.DeserializeObject<List<JObject>>(body);
    var request = Utils.CreateMockRequestWithBody(test);

    //Act
    Func<Task<IActionResult>> act = () => testTrigger.Run(request.Object);

    //Assert            
    var result = await act.Should().NotThrowAsync();
    var response = result.Which;
    response.Should().BeAssignableTo<NoContentResult>();
  }

  [Theory]
  [InlineData(false, true)]
  [InlineData(true, false)]
  [InlineData(false, false)]
  public async void ValidRequest_UnsuccessfulStoringResponse(bool storeInvalidResult, bool storeOperationResult)
  {
    string body = Utils.ReadFixture("capturedEventsBody.json");
    var test = JsonConvert.DeserializeObject<List<JObject>>(body);
    var request = Utils.CreateMockRequestWithBody(test);
    _mockDbService.Setup(x => x.StoreInvalidData(It.IsAny<PostiOperationDto>(), It.IsAny<string>())).ReturnsAsync(storeInvalidResult);
    _mockDbService.Setup(x => x.StoreNewPostiOperation(It.IsAny<PostiOperationDto>(), false)).ReturnsAsync(storeOperationResult);

    //Act
    Func<Task<IActionResult>> act = () => _testTrigger.Run(request.Object);

    //Assert            
    var result = await act.Should().NotThrowAsync();
    var response = result.Which;
    response.Should().BeAssignableTo<StatusCodeResult>();
    response.As<StatusCodeResult>().StatusCode.Should().Be(StatusCodes.Status500InternalServerError);
  }
}
