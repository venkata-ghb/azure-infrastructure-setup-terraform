﻿using Microsoft.Extensions.Logging;
using Xunit.DependencyInjection;
using Xunit.DependencyInjection.Logging;

namespace EventBatchHandler.Test;

public class Startup
{
  public void Configure(ILoggerFactory loggerFactory, ITestOutputHelperAccessor accessor) =>
    loggerFactory.AddProvider(new XunitTestOutputLoggerProvider(accessor));
}
