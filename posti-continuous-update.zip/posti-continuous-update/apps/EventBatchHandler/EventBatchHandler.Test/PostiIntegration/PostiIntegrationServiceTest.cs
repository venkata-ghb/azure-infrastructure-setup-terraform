﻿using System.Net;
using System.Net.Http;
using EventBatchHandler.Config.Models;
using EventBatchHandler.PostiIntegration;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using RichardSzalay.MockHttp;
using Xunit;

namespace EventBatchHandler.Test.PostiIntegration;

public class PostiIntegrationServiceTest
{
  private readonly MockHttpMessageHandler _mockHttp;
  private readonly PostiIntegrationSettings _testSettings;
  private readonly ILogger<PostiIntegrationService> _logger;

  public PostiIntegrationServiceTest(ILogger<PostiIntegrationService> logger)
  {
    _mockHttp = new MockHttpMessageHandler();
    _testSettings = new PostiIntegrationSettings
    {
      HostKey = "key",
      Url = "https://some.domain/api/",
      DisableSendOperationsForUpdate = false,
    };
    _logger = logger;
  }

  [Fact]
  public async void SendOperationsForUpdate_SuccessfullySendUpdates_ReturnsTrue()
  {
    // ASSIGN
    (var updateOperations, var expectedPayload) = Utils.GenerateRegistryUpdateOperations(50);
    var mockRequest = _mockHttp
      .When(HttpMethod.Post, _testSettings.Url + "UpdateRegistry")
      .WithContent(expectedPayload)
      .Respond(HttpStatusCode.OK);
    var testService = new PostiIntegrationService(_mockHttp.ToHttpClient(), _testSettings, _logger);

    // ACT
    var success = await testService.SendOperationsForUpdate(updateOperations);

    //ASSERT
    success.Should().BeTrue();
    _mockHttp.GetMatchCount(mockRequest).Should().Be(1);
  }

  [Theory]
  [InlineData(HttpStatusCode.BadRequest)]
  [InlineData(HttpStatusCode.RequestTimeout)]
  [InlineData(HttpStatusCode.InternalServerError)]
  [InlineData(HttpStatusCode.Forbidden)]
  public async void SendOperationsForUpdate_NonSuccessStatusCode_ReturnsFalse(HttpStatusCode code)
  {
    // ASSIGN
    (var updateOperations, var expectedPayload) = Utils.GenerateRegistryUpdateOperations(50);
    var mockRequest = _mockHttp
      .When(HttpMethod.Post, _testSettings.Url + "UpdateRegistry")
      .WithContent(expectedPayload)
      .Respond(code);
    var testService = new PostiIntegrationService(_mockHttp.ToHttpClient(), _testSettings, _logger);

    // ACT
    var success = await testService.SendOperationsForUpdate(updateOperations);

    //ASSERT
    success.Should().BeFalse();
    _mockHttp.GetMatchCount(mockRequest).Should().Be(1);
  }

  [Fact]
  public async void SendOperationsForUpdate_HttpRequestException_ReturnsFalse()
  {
    // ASSIGN
    (var updateOperations, var expectedPayload) = Utils.GenerateRegistryUpdateOperations(50);
    var mockRequest = _mockHttp
      .When(HttpMethod.Post, _testSettings.Url + "UpdateRegistry")
      .WithContent(expectedPayload)
      .Throw(new HttpRequestException("Oops!", null, HttpStatusCode.NotAcceptable));
    var testService = new PostiIntegrationService(_mockHttp.ToHttpClient(), _testSettings, _logger);

    // ACT
    var success = await testService.SendOperationsForUpdate(updateOperations);

    //ASSERT
    success.Should().BeFalse();
    _mockHttp.GetMatchCount(mockRequest).Should().Be(1);
  }
}
