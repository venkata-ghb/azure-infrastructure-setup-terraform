﻿using Azure.Messaging.EventHubs;
using EventBatchHandler.Config.Models;
using EventBatchHandler.CosmosDb;
using EventBatchHandler.Factories;
using EventBatchHandler.Models;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace EventBatchHandler.Test;

public class ReceiveLifecycleEventTest
{
  private readonly Mock<ICosmosDbService> _mockDbService;
  private readonly ReceiveLifecycleEvent _testTrigger;
  private readonly PilotSettings _testSettings;
  public ReceiveLifecycleEventTest(ILogger<ReceiveLifecycleEvent> logger)
  {
    _mockDbService = new Mock<ICosmosDbService>();
    _testSettings = new PilotSettings
    {
      IsPilotEnabled = false,
      PilotCustomerId = "15200"
    };
    _testTrigger = new ReceiveLifecycleEvent(_mockDbService.Object, new PostiOperationDtoFactory(_testSettings), logger);
  }

  [Fact]
  public async void UnsupportedEvent_DoesntCallDbService()
  {
    // ARRANGE
    var eventBody = Utils.ReadFixture("unsupported_event.json");
    var testEventData = new EventData(eventBody);

    // ACT
    await _testTrigger.Run(testEventData);

    // ASSERT
    _mockDbService.VerifyNoOtherCalls();
  }

  #region CUSTOMER_ENROLLED

  [Theory]
  [InlineData("customer_enrolled_event/valid_w_ssn.json", true, true)]
  public async void CustomerEnrolled_CustomerMarkedAsLeft_NoEventStored(string fixtureFile, bool hasSsn, bool hasRealBday)
  {
    // ARRANGE
    var eventBody = Utils.ReadFixture(fixtureFile);
    var testEventData = new EventData(eventBody);

    // Taken from fixture files
    var expectedDto = new PostiOperationDto()
    {
      Timestamp = 1861957845,
      Operation = PostiOperations.Add,
      CustomerNumber = "123",
      Ssn = hasSsn ? "010100-0000": hasRealBday ? "01012000": "",
      LastName = "Teekkari",
      FirstName = "Teemu",
      PostalCode = "00110",
      City = "Helsinki",
      Address = "Jokukatu 1",
      Telephone = "",
      Email = "",
      Extra = ""
    };

    _mockDbService
      .Setup(dbService => dbService.CheckIfCustomerMarkedAsLeft(It.IsAny<string>()))
      .ReturnsAsync(true)
      .Verifiable();
    

    // ACT
    await _testTrigger.Run(testEventData);

    // ASSERT
    _mockDbService.Verify();
    _mockDbService.VerifyNoOtherCalls();
  }

  [Theory]
  [InlineData("customer_enrolled_event/valid_w_ssn.json", true, true)]
  public async void CustomerEnrolled_CustomerAlreadyAdded_NoEventStored(string fixtureFile, bool hasSsn, bool hasRealBday)
  {
    // ARRANGE
    var eventBody = Utils.ReadFixture(fixtureFile);
    var testEventData = new EventData(eventBody);

    // Taken from fixture files
    var expectedDto = new PostiOperationDto()
    {
      Timestamp = 1861957845,
      Operation = PostiOperations.Add,
      CustomerNumber = "123",
      Ssn = hasSsn ? "010100-0000": hasRealBday ? "01012000": "",
      LastName = "Teekkari",
      FirstName = "Teemu",
      PostalCode = "00110",
      City = "Helsinki",
      Address = "Jokukatu 1",
      Telephone = "",
      Email = "",
      Extra = ""
    };

    _mockDbService
      .Setup(dbService => dbService.CheckIfCustomerMarkedAsLeft(It.IsAny<string>()))
      .ReturnsAsync(false)
      .Verifiable();
    _mockDbService
      .Setup(dbService => dbService.CheckIfCustomerAddOperationAlreadyExists(It.IsAny<PostiOperationDto>()))
      .ReturnsAsync(true)
      .Verifiable();
    

    // ACT
    await _testTrigger.Run(testEventData);

    // ASSERT
    _mockDbService.Verify();
    _mockDbService.VerifyNoOtherCalls();
  }

  [Theory]
  [InlineData("customer_enrolled_event/valid_w_ssn.json", true, true)]
  [InlineData("customer_enrolled_event/valid_no_ssn_real_bday.json", false, true)]
  [InlineData("customer_enrolled_event/valid_no_ssn_fake_bday.json", false, false)]
  public async void CustomerEnrolled_ValidEventToStore_StoresRightData(string fixtureFile, bool hasSsn, bool hasRealBday)
  {
    // ARRANGE
    var eventBody = Utils.ReadFixture(fixtureFile);
    var testEventData = new EventData(eventBody);

    // Taken from fixture files
    var expectedDto = new PostiOperationDto()
    {
      Timestamp = 1861957845,
      Operation = PostiOperations.Add,
      CustomerNumber = "123",
      Ssn = hasSsn ? "010100-0000": hasRealBday ? "01012000": "",
      LastName = "Teekkari",
      FirstName = "Teemu",
      PostalCode = "00110",
      City = "Helsinki",
      Address = "Jokukatu 1",
      Telephone = "",
      Email = "",
      Extra = ""
    };

    _mockDbService
      .Setup(dbService => dbService.CheckIfCustomerMarkedAsLeft(It.IsAny<string>()))
      .ReturnsAsync(false)
      .Verifiable();
    _mockDbService
      .Setup(dbService => dbService.CheckIfCustomerAddOperationAlreadyExists(It.IsAny<PostiOperationDto>()))
      .ReturnsAsync(false)
      .Verifiable();
    _mockDbService
      .Setup(dbService => dbService.StorePostiOperationWithCheckForLeftEvent(It.Is<PostiOperationDto>(dto => dto == expectedDto)))
      .ReturnsAsync(true)
      .Verifiable();

    // ACT
    await _testTrigger.Run(testEventData);

    // ASSERT
    _mockDbService.Verify();
    _mockDbService.VerifyNoOtherCalls();
  }

  [Theory]
  [InlineData("customer_enrolled_event/invalid_cus_number_empty.json",   "",    "Teekkari", "Teemu", "001100", "Jokukatu 1")]
  [InlineData("customer_enrolled_event/invalid_cus_number_missing.json", null,  "Teekkari", "Teemu", "001100", "Jokukatu 1")]
  [InlineData("customer_enrolled_event/invalid_cus_number_null.json",    null,  "Teekkari", "Teemu", "001100", "Jokukatu 1")]
  [InlineData("customer_enrolled_event/invalid_lastname_empty.json",     "123", "",         "Teemu", "001100", "Jokukatu 1")]
  [InlineData("customer_enrolled_event/invalid_lastname_missing.json",   "123", null,       "Teemu", "001100", "Jokukatu 1")]
  [InlineData("customer_enrolled_event/invalid_lastname_null.json",      "123", null,       "Teemu", "001100", "Jokukatu 1")]
  [InlineData("customer_enrolled_event/invalid_firstname_empty.json",    "123", "Teekkari", ""     , "001100", "Jokukatu 1")]
  [InlineData("customer_enrolled_event/invalid_firstname_missing.json",  "123", "Teekkari", null   , "001100", "Jokukatu 1")]
  [InlineData("customer_enrolled_event/invalid_firstname_null.json",     "123", "Teekkari", null   , "001100", "Jokukatu 1")]
  [InlineData("customer_enrolled_event/invalid_postcode_empty.json",     "123", "Teekkari", "Teemu", ""      , "Jokukatu 1")]
  [InlineData("customer_enrolled_event/invalid_postcode_missing.json",   "123", "Teekkari", "Teemu", null    , "Jokukatu 1")]
  [InlineData("customer_enrolled_event/invalid_postcode_null.json",      "123", "Teekkari", "Teemu", null    , "Jokukatu 1")]
  [InlineData("customer_enrolled_event/invalid_address_empty.json",      "123", "Teekkari", "Teemu", "001100", "")]
  [InlineData("customer_enrolled_event/invalid_address_missing.json",    "123", "Teekkari", "Teemu", "001100", null)]
  [InlineData("customer_enrolled_event/invalid_address_null.json",       "123", "Teekkari", "Teemu", "001100", null)]
  public async void CustomerEnrolled_InvalidBody_StoresInvalidData(
    string fixtureFile,
    string expectedCustomerNumber,
    string expectedLastName,
    string expectedFirstName,
    string expectedPostalCode,
    string expectedAddress)
  {
    // ARRANGE
    var eventBody = Utils.ReadFixture(fixtureFile);
    var testEventData = new EventData(eventBody);

    // Taken from fixture files
    var expectedDto = new PostiOperationDto()
    {
      Timestamp = 1861957845,
      Operation = PostiOperations.Add,
      CustomerNumber = expectedCustomerNumber,
      Ssn = "010100-0000",
      LastName = expectedLastName,
      FirstName = expectedFirstName,
      PostalCode = expectedPostalCode,
      City = "Helsinki",
      Address = expectedAddress,
      Telephone = "",
      Email = "",
      Extra = ""
    };
    
    _mockDbService
      .Setup(dbService => dbService.StoreInvalidData(It.Is<PostiOperationDto>(dto => dto == expectedDto), It.IsAny<string>()))
      .ReturnsAsync(true)
      .Verifiable();

    // ACT
    await _testTrigger.Run(testEventData);

    // ASSERT
    _mockDbService.Verify();
    _mockDbService.VerifyNoOtherCalls();
  }

  [Fact]
  public async void CustomerEnrolled_NotRegularAccountType_IgnoresEvent()
  {
    // ARRANGE
    var eventBody = Utils.ReadFixture("customer_enrolled_event/valid_non_regular_account_type.json");
    var testEventData = new EventData(eventBody);

    // ACT
    await _testTrigger.Run(testEventData);

    // ASSERT
    _mockDbService.VerifyNoOtherCalls();
  }

  [Fact]
  public async void CustomerEnrolled_AhvenanmaaZipCode_IgnoresEvent()
  {
    // ARRANGE
    var eventBody = Utils.ReadFixture("customer_enrolled_event/valid_ahvenanmaa_zip_code.json");
    var testEventData = new EventData(eventBody);

    // ACT
    await _testTrigger.Run(testEventData);

    // ASSERT
    _mockDbService.VerifyNoOtherCalls();
  }

  [Fact]
  public async void CustomerEnrolled_NonFinnishCountry_IgnoresEvent()
  {
    // ARRANGE
    var eventBody = Utils.ReadFixture("customer_enrolled_event/valid_non_finnish_country.json");
    var testEventData = new EventData(eventBody);

    // ACT
    await _testTrigger.Run(testEventData);

    // ASSERT
    _mockDbService.VerifyNoOtherCalls();
  }

  [Fact]
  public async void CustomerEnrolled_DoNotValidateAccount_IgnoresEvent()
  {
    // ARRANGE
    var eventBody = Utils.ReadFixture("customer_enrolled_event/valid_do_not_validate.json");
    var testEventData = new EventData(eventBody);

    // ACT
    await _testTrigger.Run(testEventData);

    // ASSERT
    _mockDbService.VerifyNoOtherCalls();
  }

  #endregion

  #region CUSTOMER_LEFT

  [Fact]
  public async void CustomerLeft_ValidEvent_StoresRightData()
  {
    // ARRANGE
    var eventBody = Utils.ReadFixture("customer_left_event/valid.json");
    var testEventData = new EventData(eventBody);

    // Taken from fixture files
    var expectedDto = new PostiOperationDto()
    {
      Timestamp = 1861957845,
      Operation = PostiOperations.Remove,
      CustomerNumber = "123",
      Ssn = "",
      LastName = "",
      FirstName = "",
      PostalCode = "",
      City = "",
      Address = "",
      Telephone = "",
      Email = "",
      Extra = ""
    };

    _mockDbService
      .Setup(dbService => dbService.StorePostiOperationWithCheckForLeftEvent(It.Is<PostiOperationDto>(dto => dto == expectedDto)))
      .ReturnsAsync(true)
      .Verifiable();

    // ACT
    await _testTrigger.Run(testEventData);

    // ASSERT
    _mockDbService.Verify();
    _mockDbService.VerifyNoOtherCalls();
  }

  [Theory]
  [InlineData("customer_left_event/invalid_cus_number_empty.json",   "" )]
  [InlineData("customer_left_event/invalid_cus_number_missing.json", null)]
  [InlineData("customer_left_event/invalid_cus_number_null.json",    null)]
  public async void CustomerLeft_InvalidBody_StoresInvalidData(string fixtureFile, string expectedCustomerId)
  {
    // ARRANGE
    var eventBody = Utils.ReadFixture(fixtureFile);
    var testEventData = new EventData(eventBody);

    // Taken from fixture files
    var expectedDto = new PostiOperationDto()
    {
      Timestamp = 1861957845,
      Operation = PostiOperations.Remove,
      CustomerNumber = expectedCustomerId,
      Ssn = "",
      LastName = "",
      FirstName = "",
      PostalCode = "",
      City = "",
      Address = "",
      Telephone = "",
      Email = "",
      Extra = ""
    };
    _mockDbService
      .Setup(dbService => dbService.StoreInvalidData(It.Is<PostiOperationDto>(dto => dto == expectedDto), It.IsAny<string>()))
      .ReturnsAsync(true)
      .Verifiable();

    // ACT
    await _testTrigger.Run(testEventData);

    // ASSERT
    _mockDbService.Verify();
    _mockDbService.VerifyNoOtherCalls();
  }

  [Fact]
  public async void CustomerLeft_NonRegularAccount_IgnoresEvent()
  {
    // ARRANGE
    var eventBody = Utils.ReadFixture("customer_left_event/valid_non_regular_account_type.json");
    var testEventData = new EventData(eventBody);

    // ACT
    await _testTrigger.Run(testEventData);

    // ASSERT
    _mockDbService.VerifyNoOtherCalls();
  }

  [Fact]
  public async void CustomerLeft_DoNotValidate_IgnoresEvent()
  {
    // ARRANGE
    var eventBody = Utils.ReadFixture("customer_left_event/valid_do_not_validate.json");
    var testEventData = new EventData(eventBody);

    // ACT
    await _testTrigger.Run(testEventData);

    // ASSERT
    _mockDbService.VerifyNoOtherCalls();
  }

  #endregion
}
