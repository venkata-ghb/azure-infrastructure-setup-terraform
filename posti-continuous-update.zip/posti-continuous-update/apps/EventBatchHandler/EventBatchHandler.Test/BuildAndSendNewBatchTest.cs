﻿using System.Collections.Generic;
using System.Linq;
using EventBatchHandler.CosmosDb;
using EventBatchHandler.CosmosDb.Models;
using EventBatchHandler.Models;
using EventBatchHandler.PostiIntegration;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace EventBatchHandler.Test;

public class BuildAndSendNewBatchTest
{
  public readonly Mock<ICosmosDbService> _mockCosmosService;
  public readonly Mock<IPostiIntegrationService> _mockPostiIntService;

  private readonly BuildAndSendNewBatch _testTrigger;

  public BuildAndSendNewBatchTest(ILogger<BuildAndSendNewBatch> logger)
  {
    _mockCosmosService = new Mock<ICosmosDbService>();
    _mockPostiIntService = new Mock<IPostiIntegrationService>();

    _testTrigger = new BuildAndSendNewBatch(_mockCosmosService.Object, _mockPostiIntService.Object, logger)
;
  }

  [Fact]
  public async void SuccessfullyBuildAndSendBatch_ReturnsOk()
  {
    // ARRANGE
    var batchedOperations = Utils.GeneratatePostiOperationDtos(50);
    var uniqueBatchedOperations = Utils.GeneratatePostiOperationDtos(40);
    var originalDocs = Utils.GenerateOperationDocs(50, "batch").ToList();
    _mockCosmosService
      .Setup(service => service.FetchUnbatchedOperations())
      .ReturnsAsync(new FetchUnbatchedOperationsResult() { Status = FetchUnbatchedOperationsStatus.Success, OperationDtos = batchedOperations, UniqueOperationDtos = uniqueBatchedOperations, OriginalOperations = originalDocs })
      .Verifiable();
    _mockPostiIntService
      .Setup(service => service.SendOperationsForUpdate(It.Is<List<PostiOperationDto>>(operations => operations.SequenceEqual(uniqueBatchedOperations))))
      .ReturnsAsync(true)
      .Verifiable();
    _mockPostiIntService
      .Setup(service => service.CommitChangesToRegistry())
      .ReturnsAsync(true)
      .Verifiable();
    _mockCosmosService
      .Setup(service => service.StoreNewBatch(It.Is<List<PostiOperationDocument>>(docs => docs == originalDocs)))
      .ReturnsAsync(true)
      .Verifiable();

    // ACT
    await _testTrigger.Run(null);

    // ASSERT
    
    _mockCosmosService.Verify();
    _mockCosmosService.VerifyNoOtherCalls();
    _mockPostiIntService.Verify();
    _mockPostiIntService.VerifyNoOtherCalls();
  }

  [Fact]
  public async void DbFailureDuringBatchBuild_ReturnsBadGateway()
  {
    // ARRANGE
    _mockCosmosService
      .Setup(service => service.FetchUnbatchedOperations())
      .ReturnsAsync(new FetchUnbatchedOperationsResult() { Status = FetchUnbatchedOperationsStatus.DatabaseError })
      .Verifiable();

    // ACT
    await _testTrigger.Run(null);

    // ASSERT
    _mockCosmosService.Verify();
    _mockCosmosService.VerifyNoOtherCalls();
    _mockPostiIntService.VerifyNoOtherCalls();
  }

  [Fact]
  public async void NoUnbatchedOperationsFound_ReturnsOkWithMessage()
  {
    // ARRANGE
    _mockCosmosService
      .Setup(service => service.FetchUnbatchedOperations())
      .ReturnsAsync(new FetchUnbatchedOperationsResult() { Status = FetchUnbatchedOperationsStatus.NoOperationsFound })
      .Verifiable();

    // ACT
    await _testTrigger.Run(null);

    // ASSERT
    _mockCosmosService.Verify();
    _mockCosmosService.VerifyNoOtherCalls();
    _mockPostiIntService.VerifyNoOtherCalls();
  }

  [Fact]
  public async void BatchBuildingDisabled_ReturnsServiceUnavailable()
  {
    // ARRANGE
    _mockCosmosService
      .Setup(service => service.FetchUnbatchedOperations())
      .ReturnsAsync(new FetchUnbatchedOperationsResult() { Status = FetchUnbatchedOperationsStatus.Disabled })
      .Verifiable();

    // ACT
    await _testTrigger.Run(null);

    // ASSERT
    _mockCosmosService.Verify();
    _mockCosmosService.VerifyNoOtherCalls();
    _mockPostiIntService.VerifyNoOtherCalls();
  }

  [Fact]
  public async void FailToSendToPostiIntegration_ReturnsBadGateway()
  {
    // ARRANGE
    var batchedOperations = Utils.GeneratatePostiOperationDtos(50);
    var uniqueBatchedOperations = Utils.GeneratatePostiOperationDtos(40);
    _mockCosmosService
      .Setup(service => service.FetchUnbatchedOperations())
      .ReturnsAsync(new FetchUnbatchedOperationsResult() { Status = FetchUnbatchedOperationsStatus.Success, OperationDtos = batchedOperations, UniqueOperationDtos = uniqueBatchedOperations })
      .Verifiable();
    _mockPostiIntService
      .Setup(service => service.SendOperationsForUpdate(It.Is<List<PostiOperationDto>>(operations => operations.SequenceEqual(uniqueBatchedOperations))))
      .ReturnsAsync(false)
      .Verifiable();

    // ACT
    await _testTrigger.Run(null);

    // ASSERT
    _mockCosmosService.Verify();
    _mockCosmosService.VerifyNoOtherCalls();
    _mockPostiIntService.Verify();
    _mockPostiIntService.VerifyNoOtherCalls();
  }

  [Fact]
  public async void UnexpectedException_ReturnsInternalServerError()
  {
    // ARRANGE
    var batchedOperations = Utils.GeneratatePostiOperationDtos(50);
    var uniqueBatchedOperations = Utils.GeneratatePostiOperationDtos(40);
    _mockCosmosService
      .Setup(service => service.FetchUnbatchedOperations())
      .ReturnsAsync(new FetchUnbatchedOperationsResult() { Status = FetchUnbatchedOperationsStatus.Success, OperationDtos = batchedOperations, UniqueOperationDtos = uniqueBatchedOperations })
      .Verifiable();
    _mockPostiIntService
      .Setup(service => service.SendOperationsForUpdate(It.Is<List<PostiOperationDto>>(operations => operations.SequenceEqual(uniqueBatchedOperations))))
      .ThrowsAsync(new System.Exception("Oh no!"))
      .Verifiable();

    // ACT
    await _testTrigger.Run(null);

    // ASSERT
    _mockCosmosService.Verify();
    _mockCosmosService.VerifyNoOtherCalls();
    _mockPostiIntService.Verify();
    _mockPostiIntService.VerifyNoOtherCalls();
  }
}
