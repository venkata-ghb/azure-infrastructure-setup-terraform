﻿using System;
using System.Threading.Tasks;
using EventBatchHandler.CosmosDb;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace EventBatchHandler.Test;
public class ClearCosmosContainersTest
{
  private readonly Mock<ICosmosDbService> _mockDbService;
  private readonly ClearCosmosContainers _testTrigger;

  public ClearCosmosContainersTest(ILogger<ClearCosmosContainers> logger)
  {
    _mockDbService = new Mock<ICosmosDbService>();
    _testTrigger = new ClearCosmosContainers(logger, _mockDbService.Object);
  }

  [Fact]
  public async void ValidRequest_SuccessResponse()
  {

    var request = Utils.CreateMockRequestWithBody(null);
    _mockDbService.Setup(x => x.ClearContainers()).ReturnsAsync(true);

    //Act
    Func<Task<IActionResult>> act = () => _testTrigger.Run(request.Object);

    //Assert            
    var result = await act.Should().NotThrowAsync();
    var response = result.Which;
    response.Should().BeAssignableTo<NoContentResult>();
  }

  [Fact]
  public async void ValidRequest_500ResponseAferFailedDeletion()
  {
    var request = Utils.CreateMockRequestWithBody(null);
    _mockDbService.Setup(x => x.ClearContainers()).ReturnsAsync(false);

    //Act
    Func<Task<IActionResult>> act = () => _testTrigger.Run(request.Object);

    //Assert            
    var result = await act.Should().NotThrowAsync();
    var response = result.Which;
    response.Should().BeAssignableTo<StatusCodeResult>();
    response.As<StatusCodeResult>().Should().NotBeNull();
    response.As<StatusCodeResult>().StatusCode.Should().Be(500);
  }
}
