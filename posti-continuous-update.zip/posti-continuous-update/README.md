# Loyalty Platform Posti Continuous Update (LPPCU)

This is a monorepository that contains all the code of the integration with Posti's Continuous Update API.

The directory structure is following:

- [apps](./apps/) contains C# Function app .
- [azure-pipelines](./azure-pipelines/) contains re-usable Azure DevOps steps and jobs.
- [infra](./infra/) contains all infra-as-code files.
- [azure-pipelines.yml](./azure-pipelines.yml) is the LPPCU Azure DevOps pipeline specification.

