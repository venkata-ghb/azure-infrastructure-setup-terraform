﻿using Loyalty.Common.Constants.Applications;
using Loyalty.Common.Constants.CLM;
using Loyalty.Common.Extensions;
using Loyalty.Domain.Contracts.Request.Clm;
using Loyalty.Domain.Entities;
using Loyalty.Domain.Entities.Clm;
using Loyalty.Domain.Entities.Cosmos;

namespace Loyalty.Common.Adapters;

public static class BankApplicationAdapter
{
    public static ApplicationEnrollmentInfo ToApplicationEnrollmentInfo(this BankApplication bankApplication)
        => new ()
        {
            ApplicationDate = Convert.ToDateTime(bankApplication.GeneralRulesAcceptanceDate),
            FirstName = bankApplication.FirstName,
            LastName = bankApplication.LastName,
            BirthDate = bankApplication.DateOfBirth,
            Gender = bankApplication.Gender,
            Language = bankApplication.Language,
            Permissions = ApplicationExtensions.CreatePermissions(bankApplication.MarketingPermission),
            CompanyName = bankApplication.CompanyName,
            BusinessId = bankApplication.BusinessId,
            Address = new AddressBaseExt
            {
                City = bankApplication.City,
                Country = bankApplication.Country,
                Email = bankApplication.EmailAddress,
                Mobile = bankApplication.MobilePhone,
                Phone = bankApplication.PhoneNumber,
                PostalCode = bankApplication.PostCode,
                Street = bankApplication.StreetAddress,
            },
            Ssn = bankApplication.NationalIdentificationNumber,
            IdentifierType = bankApplication.IdentifierType,
            AccountId = bankApplication.AccountId ?? string.Empty,
            Cobranded = bankApplication.Cobranded,
            IdentifierNo = bankApplication.IdentifierNo,
            IdentifierAttributes = bankApplication.CardTypeCode != ApplicationAttributes.CardType.CodeForEnrollment ? null : new AttributeExt[]
                    {
                            new()
                            {
                                Code = ApplicationAttributes.SubType.Code,
                                Value = ApplicationAttributes.SubType.PaymentTime
                            }
                    }
        };
}