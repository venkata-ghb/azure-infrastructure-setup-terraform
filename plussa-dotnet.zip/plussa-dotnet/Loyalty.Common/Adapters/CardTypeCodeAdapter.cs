﻿namespace Loyalty.Common.Adapters;

public static class CardTypeCodeAdapter
{
    public static (string cardTypeCodeDescription, string cardTypeCode) GetCardTypeCodeDetails(string cardNo)
    {
        switch (cardNo[..8])
        {
            case "70324090": return ("Electronic – K-Plussa-Mobiilikortti", "E");
            case "70324091": return ("Electronic – Mobile Pay", "E");
            case "70324049": return ("Physical – Traveller Card", "P");
            case "70324080": return ("Physical – Osuuspankki Bank", "B");
            case "70324082": return ("Physical – Osuuspankki Bank", "B");
            case "70324085": return ("Physical – Osuuspankki Bank", "B");
            case "70324087": return ("Physical – Osuuspankki Bank", "B");
            case "70324081": return ("Physical – Nordea Pankki Bank", "B");
            case "70324084": return ("Physical – Nordea Pankki Bank", "B");
            case "70324083": return ("Physical – Danske Bank", "B");
            case "70324086": return ("Physical – Säästöpankki Bank", "B");
            default:
                switch (cardNo[..7])
                {
                    case "7032400": return ("Physical - Temporary", "P");
                    case "7032404": return ("Physical - Temporary", "P");
                    case "7032401": return ("Physical – Cash Card", "P");
                    case "7032402": return ("Physical – Cash Card", "P");
                    case "7032403": return ("Physical – Cash Card", "P");
                    case "7032405": return ("Physical – Cash Card", "P");
                    case "7032406": return ("Physical – Cash Card", "P");
                    case "7032407": return ("Physical – Cash Card", "P");
                }
                break;
        }
        return ("P", "Physical");
    }
}
