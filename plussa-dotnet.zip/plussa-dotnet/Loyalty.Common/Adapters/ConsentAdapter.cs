using Loyalty.Common.Services;
using Loyalty.Domain.Constants;
using Loyalty.Domain.Contracts.Request;
using Loyalty.Domain.Contracts.Responses;
using Loyalty.Domain.Entities.Clm;
using Loyalty.Domain.Entities.Interfaces;
using Loyalty.Domain.Enums;

namespace Loyalty.Common.Adapters;

public static class ConsentAdapter
{
    private const int LowerLevelConsentCount = 14; //NesteK removed but Insurance was not counted earlier
    public static IEnumerable<EmailConsent> GetDesiredEmailConsents(this MarketingConsents dto)
    {
        var lowerLevelConsents = dto.GetLowerLevelEmailConsents().ToArray();
        var allSelected = lowerLevelConsents.Length == LowerLevelConsentCount;
        var noneSelected = !lowerLevelConsents.Any();
        if (allSelected || (noneSelected && dto.PlussaNetwork == true))
        {
            yield return EmailConsent.PlussaNetwork;
        }
        else
        {
            foreach (var consent in lowerLevelConsents) yield return consent;
        }
    }


    public static IEnumerable<NLConsent> GetDesiredNLConsents(this ProductsNL dto)
    {
        var lowerLevelConsents = dto.GetLowerLevelNLConsents().ToArray();
        foreach (var consent in lowerLevelConsents) yield return consent;
    }

    public static MarketingConsents ToMarketingConsents(this IAssignmentExt[] assignments) =>
        new()
        {
            BudgetSport = assignments.Any(x => IsGivenEmailConsent(x, EmailConsent.BudgetSport)),
            Intersport = assignments.Any(x => IsGivenEmailConsent(x, EmailConsent.Intersport)),
            KCitymarket = assignments.Any(x => IsGivenEmailConsent(x, EmailConsent.KCitymarket)),
            KMarket = assignments.Any(x => IsGivenEmailConsent(x, EmailConsent.KMarket)),
            ServiceStations = assignments.Any(x => IsGivenEmailConsent(x, EmailConsent.ServiceStations)),
            KRauta = assignments.Any(x => IsGivenEmailConsent(x, EmailConsent.KRauta)),
            KSupermarket = assignments.Any(x => IsGivenEmailConsent(x, EmailConsent.KSupermarket)),
            KAuto = assignments.Any(x => IsGivenEmailConsent(x, EmailConsent.KAuto)),
            Restaurants = assignments.Any(x => IsGivenEmailConsent(x, EmailConsent.Restaurants)),
            Leisure = assignments.Any(x => IsGivenEmailConsent(x, EmailConsent.Leisure)),
            PirkkaNewsletter = assignments.Any(x => IsGivenEmailConsent(x, EmailConsent.PirkkaNewsletter)),
            KRuokaNewsletter = assignments.Any(x => IsGivenEmailConsent(x, EmailConsent.KRuokaNewsletter)),
            Hanakat = assignments.Any(x => IsGivenEmailConsent(x, EmailConsent.Hanakat)),
            PlussaNetwork = assignments.Any(x => IsGivenEmailConsent(x, EmailConsent.PlussaNetwork)),

            Sms = assignments.Any(x => x.Code == CustomerAssignments.SmsMarketingPermission),
            Insurances = assignments.Any(x => IsGivenEmailConsent(x, EmailConsent.Insurances)),
        };

    public static MarketingConsents ToMarketingConsents(this HigherLevelMarketingConsents assignments) =>
        new()
        {
            BudgetSport = assignments.PlussaNetwork,
            Intersport = assignments.PlussaNetwork,
            KCitymarket = assignments.PlussaNetwork,
            KMarket = assignments.PlussaNetwork,
            ServiceStations = assignments.PlussaNetwork,
            KRauta = assignments.PlussaNetwork,
            KSupermarket = assignments.PlussaNetwork,
            KAuto = assignments.PlussaNetwork,
            Restaurants = assignments.PlussaNetwork,
            Leisure = assignments.PlussaNetwork,
            PirkkaNewsletter = assignments.PlussaNetwork,
            KRuokaNewsletter = assignments.PlussaNetwork,
            Hanakat = assignments.PlussaNetwork,
            PlussaNetwork = assignments.PlussaNetwork,
            Sms = assignments.Sms,
        };

    private static bool IsGivenEmailConsent(IAssignmentExt assignment, EmailConsent consent)
        => assignment.Code == CustomerAssignments.EmailMarketingPermission && string.Equals(assignment.Value, consent.ToConsentValue(), StringComparison.Ordinal);

    private static IEnumerable<EmailConsent> GetLowerLevelEmailConsents(this MarketingConsents dto)
    {
        if (dto.BudgetSport == true) yield return EmailConsent.BudgetSport;
        if (dto.Intersport == true) yield return EmailConsent.Intersport;
        if (dto.KCitymarket == true) yield return EmailConsent.KCitymarket;
        if (dto.KMarket == true) yield return EmailConsent.KMarket;
        if (dto.ServiceStations == true) yield return EmailConsent.ServiceStations;
        if (dto.KRauta == true) yield return EmailConsent.KRauta;
        if (dto.KSupermarket == true) yield return EmailConsent.KSupermarket;
        if (dto.KAuto == true) yield return EmailConsent.KAuto;
        if (dto.Restaurants == true) yield return EmailConsent.Restaurants;
        if (dto.Leisure == true) yield return EmailConsent.Leisure;
        if (dto.PirkkaNewsletter == true) yield return EmailConsent.PirkkaNewsletter;
        if (dto.KRuokaNewsletter == true) yield return EmailConsent.KRuokaNewsletter;
        if (dto.Hanakat == true) yield return EmailConsent.Hanakat;
        if (dto.Insurances == true) yield return EmailConsent.Insurances;
    }

    private static IEnumerable<NLConsent> GetLowerLevelNLConsents(this ProductsNL dto)
    {
        if (dto.NLVS == true) yield return NLConsent.NLVS;
        if (dto.NLPT == true) yield return NLConsent.NLPT;
        if (dto.NLK == true) yield return NLConsent.NLK;
        if (dto.NLT == true) yield return NLConsent.NLT;
        if (dto.NLTV == true) yield return NLConsent.NLTV;
    }

    public static MarketingConsents UpdateFromCLM(this MarketingConsents dto, IAssignmentExt[] currentAssignments)
    {
        return dto with
        {
            BudgetSport = CheckAssignmentStatus(currentAssignments, dto.BudgetSport, EmailConsent.BudgetSport),
            Intersport = CheckAssignmentStatus(currentAssignments, dto.Intersport, EmailConsent.Intersport),
            KCitymarket = CheckAssignmentStatus(currentAssignments, dto.KCitymarket, EmailConsent.KCitymarket),
            KMarket = CheckAssignmentStatus(currentAssignments, dto.KMarket, EmailConsent.KMarket),
            ServiceStations = CheckAssignmentStatus(currentAssignments, dto.ServiceStations, EmailConsent.ServiceStations),
            KRauta = CheckAssignmentStatus(currentAssignments, dto.KRauta, EmailConsent.KRauta),
            KSupermarket = CheckAssignmentStatus(currentAssignments, dto.KSupermarket, EmailConsent.KSupermarket),
            KAuto = CheckAssignmentStatus(currentAssignments, dto.KAuto, EmailConsent.KAuto),
            Restaurants = CheckAssignmentStatus(currentAssignments, dto.Restaurants, EmailConsent.Restaurants),
            Leisure = CheckAssignmentStatus(currentAssignments, dto.Leisure, EmailConsent.Leisure),
            PirkkaNewsletter = CheckAssignmentStatus(currentAssignments, dto.PirkkaNewsletter, EmailConsent.PirkkaNewsletter),
            KRuokaNewsletter = CheckAssignmentStatus(currentAssignments, dto.KRuokaNewsletter, EmailConsent.KRuokaNewsletter),
            Hanakat = CheckAssignmentStatus(currentAssignments, dto.Hanakat, EmailConsent.Hanakat),
            Insurances = CheckAssignmentStatus(currentAssignments, dto.Insurances, EmailConsent.Insurances),

        };

    }

    public static ProductsNLResponse ToMarketingConsentsNL(this AssignmentExt[] assignments) =>
    new()
    {
        NLVS = assignments.Any(x => string.Equals(x.Value, CustomerAssignments.NLConsentNLVSValue, StringComparison.Ordinal)),
        NLPT = assignments.Any(x => string.Equals(x.Value, CustomerAssignments.NLConsentNLPTValue, StringComparison.Ordinal)),
        NLK = assignments.Any(x => string.Equals(x.Value, CustomerAssignments.NLConsentNLKValue, StringComparison.Ordinal)),
        NLT = assignments.Any(x => string.Equals(x.Value, CustomerAssignments.NLConsentNLTValue, StringComparison.Ordinal)),
        NLTV = assignments.Any(x => string.Equals(x.Value, CustomerAssignments.NLConsentNLTVValue, StringComparison.Ordinal))
    };

    public static ProductsNL UpdateFromCLM(this ProductsNL dto, IAssignmentExt[] currentAssignments)
    {
        return dto with
        {
            NLVS = CheckAssignmentStatusNL(currentAssignments, dto.NLVS, NLConsent.NLVS),
            NLPT = CheckAssignmentStatusNL(currentAssignments, dto.NLPT, NLConsent.NLPT),
            NLK = CheckAssignmentStatusNL(currentAssignments, dto.NLK, NLConsent.NLK),
            NLT = CheckAssignmentStatusNL(currentAssignments, dto.NLT, NLConsent.NLT),
            NLTV = CheckAssignmentStatusNL(currentAssignments, dto.NLTV, NLConsent.NLTV)
        };

    }

    private static bool CheckAssignmentStatus(IAssignmentExt[] currentAssignments, bool? desiredConsentStatus, EmailConsent consent)
    {
        if (desiredConsentStatus != null) return (bool)desiredConsentStatus;
        var currentAssignment = currentAssignments.FirstOrDefault(x => x.Value == consent.ToConsentValue());
        if (currentAssignment is null) return false;
        var isCurrent = ConsentService.IsCurrentConsent(currentAssignment);
        return isCurrent;

    }

    private static bool CheckAssignmentStatusNL(IAssignmentExt[] currentAssignments, bool? desiredConsentStatus, NLConsent consent)
    {
        if (desiredConsentStatus != null) return (bool)desiredConsentStatus;
        var currentAssignment = currentAssignments.FirstOrDefault(x => x.Value == consent.ToConsentValue());
        if (currentAssignment is null) return false;
        var isCurrent = ConsentService.IsCurrentConsent(currentAssignment);
        return isCurrent;

    }
}
