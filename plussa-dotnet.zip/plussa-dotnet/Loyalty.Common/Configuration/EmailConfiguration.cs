﻿using System.ComponentModel.DataAnnotations;

namespace Loyalty.Common.Configuration;

public record EmailConfiguration
{
    public string ApiKey { get; init; } = string.Empty;
    public string HashKey { get; init; } = string.Empty;
    public string EmailFrom { get; init; } = string.Empty;
    public string RegisterVerificationUrl { get; init; } = string.Empty;
    public string ChangeEmailVerificationUrl { get; init; } = string.Empty;
    public string InvitationReturnUrl { get; init; } = string.Empty;
    public string StudentProgramVerificationUrl { get; init; } = string.Empty;
}
