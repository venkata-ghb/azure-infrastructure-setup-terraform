﻿namespace Loyalty.Common.Configuration;

/// <summary>
/// Configuration contract for MobilePay services
/// </summary>
public record MobilePayConfiguration
{
    /// <summary>
    /// Base url for the mobile pay api
    /// </summary>
    public string BaseUrl { get; init; } = string.Empty;

    /// <summary>
    /// mobile pay client Id 
    /// </summary>
    public string ClientId { get; init; } = string.Empty;

    /// <summary>
    /// mobile pay client secret
    /// </summary>
    public string ClientSecret { get; init; } = string.Empty;

    /// <summary>
    /// scheme id for mobile pay
    /// </summary>
    public string SchemeId { get; init; } = string.Empty;

    /// <summary>
    /// scheme name for mobile pay
    /// </summary>
    public string SchemeName { get; init; } = string.Empty;

    /// <summary>
    /// Subscription api key for mobile pay api proxy
    /// </summary>
    public string APIKey { get; init; } = string.Empty;
}