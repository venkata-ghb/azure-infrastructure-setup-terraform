﻿namespace Loyalty.Common.Configuration
{
    public class JanitorConfiguration
    {
        public string Increased_Throughput { get; init; } = string.Empty;
        public string Decreased_Throughput { get; init; } = string.Empty;
    }
}
