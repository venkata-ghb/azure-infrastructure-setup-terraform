﻿namespace Loyalty.Common.Configuration
{
    public record CosmosDbConfiguration
    {
        public string ConnectionString { get; init; } = string.Empty;
        public string AuxiliaryDbName { get; init; } = "loyalty-auxiliary";
        public string DbName { get; init; } = string.Empty;
        public string ReceiptDbName { get; init; } = "loyalty-transactions";
        public string ApplicationContainer { get; init; } = "Application";
        public string TokenContainer { get; init; } = "Tokens";
        public string IdentifiersContainer { get; init; } = "Identifiers";
        public string SponsorshipContainer { get; init; } = "Sponsorship";
        public string HouseholdSponsorshipContainer { get; init; } = "HouseholdSponsorship";
        public string PersonAddressContainer { get; init; } = "PersonAddress";
        public string PersonPropertiesContainer { get; init; } = "PersonProperties";
        public string AslisaContainer { get; init; } = "Aslisa";
        public string TiersDataContainer { get; init; } = "TierData";
        public string WarrantyReceiptsContainer { get; init; } = "WarrantyReceipts";
        public string PurchaseHistorySummaryContainer { get; init; } = "PurchasesSummary";
        public string RollingPurchaseHistoryContainer { get; init; } = "RollingPurchasesSummary";
        public string PurchaseHistoryReceiptContainer { get; init; } = "Receipts";
        public string PurchaseHistoryPointsContainer { get; init; } = "Points";
        public string ConfigurationContainer { get; init; } = "Configuration";
        public string CustomerDataMigrationContainer { get; init; } = "CustomerDataMigration";
        public string BasicCustomerDataContainer { get; init; } = "BasicCustomerData";
        public string BasicCustomerDataStaticContainer { get; init; } = "CustomerData";
        public string LogsContainer { get; init; } = "Logs";
        public string UserArchive { get; init; } = "UserArchive";
        public string PreferencesContainer { get; init; } = "Preferences";
        public string DeliveryAddress { get; init; } = "DeliveryAddress";
        public string PreferencesPlussaContainer { get; init; } = "PreferencesPlussa";
        public string CustomerAttributesContainer { get; init; } = "CustomerAttributes";
        public string EAIOutboxContainer { get; init; } = "EAIOutbox";
        public string HouseholdMainStoresContainer { get; init; } = "HouseholdMainStores";

    }
}
