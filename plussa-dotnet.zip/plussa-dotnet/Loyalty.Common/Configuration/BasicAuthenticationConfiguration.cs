﻿namespace Loyalty.Common.Configuration;

public record BasicAuthenticationConfiguration
{
    public string UserId { get; init; } = string.Empty;
    public string Password { get; init; } = string.Empty;
}