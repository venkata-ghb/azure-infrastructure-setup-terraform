﻿namespace Loyalty.Common.Configuration;

public class PreferenceToCdpConfiguration
{
    public Configurations PreferenceToCdp { get; init; }
    public Connections ConnectionStrings { get; init; }

    public class Connections
    {
        public string NotifyCdpServiceBusConnection { get; init; } = string.Empty;
    }

    public class Configurations
    {
        public string NotifyQueueName { get; init; } = string.Empty;

    }
}