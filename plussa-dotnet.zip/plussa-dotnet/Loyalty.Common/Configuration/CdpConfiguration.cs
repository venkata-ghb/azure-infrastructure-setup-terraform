﻿using Loyalty.Domain.Enums;

namespace Loyalty.Common.Configuration;

public record CdpConfiguration
{
    public string BusinessUnitId { get; init; } = string.Empty;
    public string ApplicationId { get; init; } = string.Empty;
    public string UserKey { get; init; } = string.Empty;
    public string Secret { get; init; } = string.Empty;
    public string PurposeId { get; init; } = string.Empty;
    public string AdminUserKey { get; init; } = string.Empty;
    public string AdminSecret { get; init; } = string.Empty;

    public string CustomerInformationUpdatedEventId { get; init; } = string.Empty;
    public string CustomerToBeTerminatedEventId { get; init; } = string.Empty;
    public string CustomerBlockedEventId { get; init; } = string.Empty;
    public string CustomerLeftEventId { get; init; } = string.Empty;
    public string CustomerUnblockedEventId { get; init; } = string.Empty;
    public string CustomerViewId { get; init; } = string.Empty;
    public string MarketingPermissionEventId { get; init; } = string.Empty;

    public string ApiKey { get; init; } = string.Empty;
    public string BaseUrl { get; init; } = string.Empty;
    public string AdminBaseUrl { get; init; } = string.Empty;

    public string RsaPrivateKey { get; init; } = string.Empty;
    public string AdminRsaPrivateKey { get; init; } = string.Empty;


    //Which events contain multiple customers are mentioned here https://confluence.kesko.fi/display/LP/Customer+lifecycle
    public (string, string) GetEventDetails(string eventType)
    {
        var cdpEventType = "";
        var cdpURLType = "";
        if (Enum.TryParse(typeof(EventTypes), eventType, out var type))
        {
            switch (type)
            {
                case EventTypes.CUSTOMER_TO_BE_TERMINATED:
                    cdpEventType = CustomerToBeTerminatedEventId;
                    cdpURLType = "event";
                    break;
                case EventTypes.CUSTOMER_BLOCKED:
                    cdpEventType = CustomerBlockedEventId;
                    cdpURLType = "views";
                    break;
                case EventTypes.CUSTOMER_LEFT:
                    cdpEventType = CustomerLeftEventId;
                    cdpURLType = "views";
                    break;
                case EventTypes.CUSTOMER_UNBLOCKED:
                    cdpEventType = CustomerUnblockedEventId;
                    cdpURLType = "event";
                    break;
                case EventTypes.CUSTOMER_BASIC_INFORMATION_UPDATED:
                    cdpEventType = CustomerInformationUpdatedEventId;
                    cdpURLType = "event";
                    break;
            }
        }
        else if (eventType == "SOME_Marketing_permission")
        {
            cdpEventType = MarketingPermissionEventId;
            cdpURLType = "event";
        }

        return (cdpEventType, cdpURLType);
    }

}
