﻿namespace Loyalty.Common.Configuration
{
    public record KKylaConfiguration
    {
        public string ProxyUrl { get; init; } = string.Empty;
        public string SecretKey { get; init; } = string.Empty;
        public string SubscriptionKey {  get; init; } = string.Empty;
    }
}
