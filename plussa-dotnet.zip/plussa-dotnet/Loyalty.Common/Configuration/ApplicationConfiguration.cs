﻿using Loyalty.Common.Constants.CLM;
using Microsoft.Extensions.Options;

namespace Loyalty.Common.Configuration;

public record ApplicationConfiguration : IApplicationConfiguration
{
    public int RemoveDraftsAfterDays { get; init; } = 90;
    public int RemoveSuccessAfterDays { get; init; } = 90;
    public int RemoveErroneousAfterDays { get; init; } = 90;
    public int RemoveDeletedAfterDays { get; init; } = 90;
    public int RemovePendingAfterDays { get; init; } = 90;
    public string DefaultIdentifierType { get; init; } = IdentifierTypes.Webkateis;
}