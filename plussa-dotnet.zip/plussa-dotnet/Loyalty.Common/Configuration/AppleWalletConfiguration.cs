﻿namespace Loyalty.Common.Configuration
{
    /// <summary>
    /// Configuration contract for Apple Wallet Event services
    /// </summary>
    public record AppleWalletConfiguration
    {
        /// <summary>
        /// Base url for the stamp collection api
        /// </summary>
        public string BaseUrl { get; init; } = string.Empty;

        /// <summary>
        /// Subscription api key for stamp collection api 
        /// </summary>
        public string APIKey { get; init; } = string.Empty;    
    }
}
