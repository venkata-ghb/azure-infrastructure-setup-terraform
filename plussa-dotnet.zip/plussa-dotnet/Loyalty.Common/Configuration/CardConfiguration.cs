﻿namespace Loyalty.Common.Configuration;

public record CardConfiguration
{
    private string[]? _splitCardTypes;
    private string[]? _splitMobilePayCardTypes;
    private string[]? _splitMobilePlussaCardTypes;
    private string[]? _splitNLPlussaCardTypes;

    public bool IsInCardTypes(string toCheck)
    {
        // Lazy load the split -- can't use constructor, because how object binding works in IOptions:
        // the configuration is still empty string at that time
        _splitCardTypes ??= SelfServiceCardTypes.Split(',');
        return _splitCardTypes.Contains(toCheck);
    }

    public bool IsInMobilePayCardTypes(string toCheck)
    {
        // Lazy load the split -- can't use constructor, because how object binding works in IOptions:
        // the configuration is still empty string at that time
        _splitMobilePayCardTypes ??= MobilePayCardTypes.Split(',');
        return _splitMobilePayCardTypes.Contains(toCheck);
    }

    public bool IsInMobilePlussaCardTypes(string toCheck)
    {
        // Lazy load the split -- can't use constructor, because how object binding works in IOptions:
        // the configuration is still empty string at that time
        _splitMobilePlussaCardTypes ??= MobilePlussaCardTypes.Split(',');
        return _splitMobilePlussaCardTypes.Contains(toCheck);
    }

    public bool IsInNLPlussaCardTypes(string toCheck)
    {
        // Lazy load the split -- can't use constructor, because how object binding works in IOptions:
        // the configuration is still empty string at that time
        _splitNLPlussaCardTypes ??= NLPlussaCardTypes.Split(',');
        return _splitNLPlussaCardTypes.Contains(toCheck);
    }

    public string SelfServiceCardTypes { get; init; } = string.Empty;

    public string MobilePayCardTypes { get; init; } = string.Empty;

    public string MobilePlussaCardTypes { get; init; } = string.Empty;

    public string NLPlussaCardTypes { get; init; } = string.Empty;

    public string NLPlussaCardSeries { get; init; } = string.Empty;

    public string NLProxyDeleteCardUrl { get; init; } = string.Empty;

    public string NLProxyCertificate { get; init; } = string.Empty;

    public string NLProxyCertificatePassword { get; init; } = string.Empty;
}
