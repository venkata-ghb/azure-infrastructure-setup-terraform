namespace Loyalty.Common.Configuration;

public class FetchUpdateUserDetailsConfigurations
{
    public Configurations FetchUpdateUserDetails { get; init; }
    public Connections ConnectionStrings { get; init; }

    public class Connections
    {
        public string NotifyServiceBusConnection { get; init; } = String.Empty;
    }

    public class Configurations
    {
        public string NotifyQueueName { get; init; } = String.Empty;

        public string MaxRetryCount { get; init; } = "12";
        public string RetryDelay { get; init; } = "3600";
    }
}