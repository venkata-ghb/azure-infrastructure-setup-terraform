﻿namespace Loyalty.Common.Configuration
{
    public record IntegrationHubConfiguration
    {
        public string TokenUrl { get; init; } = string.Empty;
        public string ClientId { get; init; } = string.Empty;
        public string ClientSecret { get; init; } = string.Empty;
        public string BaseUrl { get; init; } = string.Empty;
        public string Scope { get; init; } = "integration-hub/events.write";
    }
}
