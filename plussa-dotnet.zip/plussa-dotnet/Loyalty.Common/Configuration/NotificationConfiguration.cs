﻿using System.ComponentModel.DataAnnotations;

namespace Loyalty.Common.Configuration;

public record NotificationConfiguration
{
    public string ApiKey { get; init; } = string.Empty;
    public string BaseUrl { get; init; } = string.Empty;
}
