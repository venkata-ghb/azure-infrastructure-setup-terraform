﻿namespace Loyalty.Common.Configuration;

public record EReceiptConsentConfiguration
{
    /// <summary>
    /// The API key for calling the 'proxy-api' in front of CLM. We are trying to get rid of this, and allow calls directly from function app in vnet.
    /// </summary>
    public string EReceiptConsentApiKey { get; init; } = string.Empty;

    /// <summary>
    /// Url for the ereceipt consent api 
    /// </summary>
    public string EReceiptConsentEndpoint { get; init; } = string.Empty;
}