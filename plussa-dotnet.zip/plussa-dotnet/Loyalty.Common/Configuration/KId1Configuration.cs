﻿namespace Loyalty.Common.Configuration;

public record KId1Configuration
{
    public string JwtIssuer { get; init; } = string.Empty;
    public string JwkEndpoint { get; init; } = string.Empty;
    public string GetTokenUri { get; init; } = string.Empty;
}