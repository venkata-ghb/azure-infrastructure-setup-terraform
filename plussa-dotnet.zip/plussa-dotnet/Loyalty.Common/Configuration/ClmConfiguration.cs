﻿namespace Loyalty.Common.Configuration;

/// <summary>
/// Configuration contract for CLM services
/// </summary>
public record ClmConfiguration
{
    /// <summary>
    /// The API key for calling the 'proxy-api' in front of CLM. We are trying to get rid of this, and allow calls directly from function app in vnet.
    /// </summary>
    public string ApiKey { get; init; } = string.Empty;

    /// <summary>
    /// Clm client Id 
    /// </summary>
    public string ClientId { get; init; } = string.Empty;

    /// <summary>
    /// Clm client secret
    /// </summary>
    public string ClientSecret { get; init; } = string.Empty;

    /// <summary>
    /// Base url for the clm api (currently the APIM proxy)
    /// </summary>
    public string ClmEndpoint { get; init; } = string.Empty;
}