﻿namespace Loyalty.Common.Configuration;

public record KId2Configuration
{
    public string OpenIdDiscovery { get; set; } = string.Empty;
    public string StrongAuthPrimarySecret { get; set; } = string.Empty;
    public string StrongAuthFallbackSecret { get; set; } = string.Empty;
}
