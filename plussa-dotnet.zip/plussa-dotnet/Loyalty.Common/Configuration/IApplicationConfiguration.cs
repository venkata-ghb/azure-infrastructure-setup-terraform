﻿namespace Loyalty.Common.Configuration;

public interface IApplicationConfiguration
{
    int RemoveDeletedAfterDays { get; init; }
}