﻿namespace Loyalty.Common.Configuration;

public record EncryptionConfiguration
{
    public string Passphrase { get; init; } = string.Empty;

    //Reason for providing a static IV value is that the IV string is not intended to be exposed.
    //Since this is initial implementation and to encrypt data for logging.
    //For a different scenarios it would be ideal to get the dynamically generated IV.
    public string InitializationVector { get; init; } = string.Empty;

    public string HashSecret { get; init; } = string.Empty;
}