﻿namespace Loyalty.Common.Configuration;

public record LoggingConfiguration
{
    //This switch is to disable logging if there is an error and hampering with APIs
    public string LoggingEnabled { get; init; } = string.Empty;

}