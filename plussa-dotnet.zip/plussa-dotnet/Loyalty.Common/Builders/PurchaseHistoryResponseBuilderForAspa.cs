﻿using Loyalty.Common.Constants;
using Loyalty.Common.Constants.PurchaseHistory;
using Loyalty.Common.Events.PurchaseHistory;
using Loyalty.Domain.Contracts.Responses;

namespace Loyalty.Common.Builders;

public class PurchaseHistoryResponseBuilderForAspa
{
    public static PurchaseHistoryResponseForAspa Build(
        List<Receipt> receipts,
        DateTime startDate,
        DateTime endDate,
        string[]? kruokaChains = null)
    {
        return new PurchaseHistoryResponseForAspa
        {
            Date = DateTime.Now.ToString("yyyy-MM-dd"),
            PurchaseHistory = new PurchaseHistoryResponseForAspa.PersonPurchaseHistory(
                startDate.ToString("yyyy-MM-dd"),
                endDate.ToString("yyyy-MM-dd"),
                receipts
                    .Select(r => new PurchaseHistoryResponseForAspa.PurchaseForAspa(
                        kruokaChains is null ? r.Chain : new Domain.Entities.Clm.Chain(r.Chain.Id, r.Chain.Name, kruokaChains.Contains(r.Chain.Id) ? "1" : "2"),
                        r.Date,
                        r.Id,
                        r.CustomerId,
                        Discounts.GetDiscountAttributes(r.Attributes)
                            ?.Select(a => new PurchaseHistoryResponseForAspa.Discount(a.Value, a.Code, string.Empty))
                            ?.ToArray() ?? Array.Empty<PurchaseHistoryResponseForAspa.Discount>(),
                        r.Store,
                        Math.Round(r.GetBasketValue(), 2),
                        Math.Round(r.GetTotalValue(), 2),
                        r.IdentifierNo,
                        r.GetBestCustomerValue(),
                        (int)(r.Points ?? 0.0m),
                        string.IsNullOrEmpty(r.ProcessingDate) ? r.EventTime : r.ProcessingDate
                        ))
                    .ToArray()
                )
        };
    }

    public static List<MonthlyGroupedPurchaseSummary> BuildByMonths(List<PurchaseSummaryWithMonth> summaries, DateTime startDate, DateTime endDate, string[] kruokaChains)
    {
        var months = GetMonthsInDateRange(startDate, endDate);
        var enrichedSummaries = summaries
            .Select(summary => summary with
            {
                PointGroup = kruokaChains.Contains(summary.ChainId)
                    ? EnumConstants.PointGroups.Progressive
                    : EnumConstants.PointGroups.NonProgressive
            })
            .ToList();

        return months
            .Select(month => new MonthlyGroupedPurchaseSummary(month, enrichedSummaries
                .Where(s => s.Month == month)
                .Select(s => new PurchaseSummary(s.ChainId, s.ChainName, s.TotalSum, s.DiscountSum) { PointGroup = s.PointGroup })
                .ToArray()))
            .ToList();
    }

    private static IEnumerable<string> GetMonthsInDateRange(DateTime startDate, DateTime endDate)
    {
        while (startDate.Year < endDate.Year || (startDate.Year == endDate.Year && startDate.Month <= endDate.Month))
        {
            yield return $"{startDate.Year}-{startDate.Month}";
            startDate = startDate.AddMonths(1);
        }
    }
}