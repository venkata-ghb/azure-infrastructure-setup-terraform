﻿using Loyalty.Common.Constants.CLM;
using Loyalty.Common.Constants.PurchaseHistory;
using Loyalty.Common.Events.PurchaseHistory;
using Loyalty.Domain.Contracts.Responses;

namespace Loyalty.Common.Builders;

public class PersonPurchaseHistoryResponseBuilder
{
    public static PersonPurchaseHistoryResponse Build(
        List<Receipt> receipts,
        DateTime startDate,
        DateTime endDate)
    {
        return new PersonPurchaseHistoryResponse
        {
            Date = DateTime.Now.ToString("yyyy-MM-dd"),
            PurchaseHistory = new PersonPurchaseHistoryResponse.PersonPurchaseHistory(
                startDate.ToString("yyyy-MM-dd"),
                endDate.ToString("yyyy-MM-dd"),
                receipts
                    .Select(r => new PersonPurchaseHistoryResponse.Purchase(
                        r.Chain,
                        r.Date,
                        Discounts.GetDiscountAttributes(r.Attributes)
                            ?.Select(a => new PersonPurchaseHistoryResponse.Discount(a.Value, a.Code, string.Empty))
                            ?.ToArray() ?? Array.Empty<PersonPurchaseHistoryResponse.Discount>(),
                        r.Store,
                        Math.Round(r.GetBasketValue(), 2),
                        Math.Round(r.GetTotalValue(), 2),
                        (int) (r.Points ?? 0.0m)
                        ))
                    .ToArray()
                )
        };
    }
}