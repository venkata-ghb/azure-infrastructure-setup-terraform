﻿using Loyalty.Common.DTOs;
using Loyalty.Common.Helpers;
using Loyalty.Common.Models.Calculator.Calculator.Tranactions;
using Loyalty.Domain.Entities.Cosmos;

namespace Loyalty.Common.Builders
{
    public class BestCustomerPurchasesResponseBuilder
    {
        public static BestCustomerPurchasesResponse Build(
        TransactionSummary summary,
        DateTime startDate,
        DateTime endDate)
        {
            var months = summary.GetMonthsInDateRange(startDate, endDate);
            return new BestCustomerPurchasesResponse
            {
                StartDate = startDate.ToString("yyyy-MM-dd"),
                EndDate = endDate.ToString("yyyy-MM-dd"),
                BestCustomerPurchaseSumTotal = months
                    .Sum(m => (m.GetBestCustomerTotalSum() ?? 0)),
                MonthlyPurchases = months
                    .Select(x => new BestCustomerPurchasesResponse.MonthlyPurchase(
                        $"{x.Year}-{x.Month.ToString("00")}",
                        Math.Round((x.GetBestCustomerTotalSum() ?? 0), 2)))
                    .ToArray()
            };
        }

        public static BestCustomerPurchasesResponse BuildForPerson(
            List<PersonBestCustomerSummary> receipts,
            DateTime startDate,
            DateTime endDate)
        {

            return new BestCustomerPurchasesResponse
            {
                StartDate = startDate.ToString("yyyy-MM-dd"),
                EndDate = endDate.ToString("yyyy-MM-dd"),
                BestCustomerPurchaseSumTotal = Math.Round(receipts.ToArray()
                    .Sum(m => m.PurchaseSumBestCustomer), 2),
                MonthlyPurchases = receipts.ToArray()
                    .Select(x => new BestCustomerPurchasesResponse.MonthlyPurchase(
                        x.Month,
                        Math.Round(x.PurchaseSumBestCustomer, 2)))
                    .ToArray()
            };
        }
    }
}
