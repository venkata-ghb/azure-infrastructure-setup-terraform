﻿using Loyalty.Common.Models.Calculator.Calculator;
using Loyalty.Common.Models.Calculator.Calculator.Points;
using Loyalty.Common.Models.Calculator.Calculator.Tranactions;
using Loyalty.Domain.Constants;
using Loyalty.Domain.Contracts.Responses;
using Loyalty.Domain.Entities;
using Loyalty.Domain.Entities.Clm;
using Loyalty.Domain.Entities.Cosmos;

namespace Loyalty.Common.Builders;

public class HouseholdLoyaltyPointsBuilder
{
    public static MonthlyLoyaltyPointsResponse Build(
        string accountId,
        PointSummary pointSummary,
        TransactionSummary transactionSummary,
        ProgressivePlussaPoints progressivePointTable,
        Dictionary<(int year, int month, string eventType), ProgressivePointsData> progressivePoints,
        HouseholdPointBalanceExt currentMonthPoints,
        DateTime firstDate,
        DateTime lastDate,
        TransactionsResult[]? loyaltyMoneyTransactions = null
        )
    {
        var currentMonth = transactionSummary?.TransactionMonths.FirstOrDefault(m => m.Year == DateTime.Now.Year && m.Month == DateTime.Now.Month);
        var currentPointMonth = new PointsMonthTotal
        {
            Month = DateTime.Now.Month,
            Year = DateTime.Now.Year

        };
        var sumOfPurchases = currentMonth?.ProgressivePurchaseSum ?? 0.0m;
        var progression = progressivePointTable.FindProgressionFor(sumOfPurchases);
        var currentMonthPointsData = currentMonthPoints.PointBalances.GroupBy(s => s.PointType)
            .ToDictionary(keySelector: k => k.Key, elementSelector: es => es.Sum(e => e.Points));
        var currentPointsMonth = pointSummary?.Months?.FirstOrDefault(m => m.Year == DateTime.Now.Year && m.Month == DateTime.Now.Month);
        var pointsMonth = pointSummary?.Months;
        if (currentPointsMonth == null)
        {
            pointsMonth = pointsMonth?.Concat(new[] { currentPointMonth }).ToArray();
        }

            DateTime now = DateTime.Now;

     DateTime last12thMonthStartDate = new DateTime(now.Year, now.Month, 1).AddMonths(-11);
     DateTime endDateOfCurrentMonth = new DateTime(now.Year, now.Month, DateTime.DaysInMonth(now.Year, now.Month));

        return new MonthlyLoyaltyPointsResponse
        {
            HouseholdId = accountId,
            PointsCalculationDate = DateTime.Now.ToString("yyyy-MM-dd"),
            EurosNeededForNextPointProgression = (int)Math.Round(progression.eurosNeededForNextPointProgression, MidpointRounding.AwayFromZero),
            NextPointProgressionLevel = (int)Math.Round(progression.nextPointProgressionLevel, MidpointRounding.AwayFromZero),
            RewardPointsToBeGained = progression.rewardPointsToBeGained,
            LoyaltyMoneyEarnedLastTwelveMonth = loyaltyMoneyTransactions?.Where(lt =>
                                                       lt.AccountEventDateTime.DateTime >= last12thMonthStartDate
                                                       && lt.AccountEventDateTime.DateTime <= endDateOfCurrentMonth &&
                                                       LoyaltyMoney.BalanceTransactionTypes.Contains(lt.Type) &&
                                                       lt.Amount > 0)
                                                   .Sum(trasactions => trasactions.Amount) ?? 0,
            MonthlyTransferPoints = pointSummary?.TransferPointSummaries?.Where(month => IsInTimeRange(month, firstDate, lastDate))
                                            .Select(month => new MonthlyTransferPoints
                                            {
                                                Month = month.Month,
                                                Year = month.Year,
                                                BasicPoints = (int)month.BasicPoints,
                                                ExtraPoints = (int)month.ExtraPoints,
                                                PaymentcardPoints = (int)month.PaymentcardPoints,
                                                ProgressivePoints = (int)month.ProgressivePoints,
                                                StudentPoints = (int)month.StudentPoints,
                                                CorrectedPoints = (int)month.CorrectedPoints,
                                                MigratedPoints = (int)month.MigratedPoints,
                                            }).OrderByDescending(x => x.Month)
                                            .ToArray()
                                             ?? Array.Empty<MonthlyTransferPoints>(),
            MonthlyLoyaltyPoints = pointsMonth?
                                       .Where(month => IsInTimeRange(month, firstDate, lastDate))
                                       .Select(month => (PointsMonthTotal)month)
                                       .Select(month =>
                                       {
                                           // This calculation is made specifically for migrated data logic, as migrated data is different than CLM data
                                           // This can be removed in 2024.
                                           var progressivePointBalanceAmount = month.Year < Points.CLMUsageStartYear || (month.Year == Points.CLMUsageStartYear && month.Month < Points.CLMUsageStartMonth)
                                           ? (int)month.ProgressivePointsBalance
                                           : progressivePoints.ContainsKey((month.Year, month.Month, Points.ProgressivePoints))
                                               ? progressivePoints[(month.Year, month.Month, Points.ProgressivePoints)].Amount
                                               : 0;
                                           var studentPointBalanceAmount = month.Year < Points.CLMUsageStartYear || (month.Year == Points.CLMUsageStartYear && month.Month < Points.CLMUsageStartMonth)
                                           ? (int)month.StudentPointsBalance
                                           : progressivePoints.ContainsKey((month.Year, month.Month, Points.StudentPoints))
                                               ? progressivePoints[(month.Year, month.Month, Points.StudentPoints)].Amount
                                               : (int)month.StudentPointsBalance;

                                           if (IsCurrentMonth(month.Year, month.Month))
                                           {
                                               var loyaltyMoneyCurrentMonth = (decimal)(currentMonthPoints.TotalPointBalance * 0.005 * 100) / 100;
                                               if (loyaltyMoneyCurrentMonth < 0)
                                                   loyaltyMoneyCurrentMonth = 0;

                                               return new MonthlyLoyaltyPoints
                                               {
                                                   Month = month.Month,
                                                   Year = month.Year,
                                                   AllBalance = (int)currentMonthPoints.TotalPointBalance,
                                                   BasicPointsBalance = currentMonthPointsData.ContainsKey((Points.BasicPoints)) ? (int)currentMonthPointsData[Points.BasicPoints] : 0,
                                                   ExtraPointsBalance = currentMonthPointsData.ContainsKey((Points.ExtraPoints)) ? (int)currentMonthPointsData[Points.ExtraPoints] : 0,
                                                   PaymentcardPointsBalance = currentMonthPointsData.ContainsKey((Points.PaymntCardPoints)) ? (int)currentMonthPointsData[Points.PaymntCardPoints] : 0,
                                                   ProgressivePointsBalance = currentMonthPointsData.ContainsKey((Points.ProgressivePoints)) ? (int)currentMonthPointsData[Points.ProgressivePoints] : 0,
                                                   StudentPointsBalance = currentMonthPointsData.ContainsKey((Points.StudentPoints)) ? (int)currentMonthPointsData[Points.StudentPoints] : 0,
                                                   CorrectedPointsBalance = currentMonthPointsData.ContainsKey((Points.CorrectedPoints)) ? (int)currentMonthPointsData[Points.CorrectedPoints] : 0,
                                                   MigratedPointsBalance = currentMonthPointsData.ContainsKey((Points.MigratedPoints)) ? (int)currentMonthPointsData[Points.MigratedPoints] : 0,
                                                   LoyaltyMoneyEarned = loyaltyMoneyCurrentMonth,
                                               };
                                           }

                                           //// calculate the start and end date for solteq api to calculate loyalty money earned
                                           var solteqStartDate = new DateTime(month.Year, month.Month, 1).AddMonths(1);
                                           var solteqEndDate = solteqStartDate.AddMonths(1).AddDays(-1);

                                           return new MonthlyLoyaltyPoints
                                           {
                                               Month = month.Month,
                                               Year = month.Year,
                                               AllBalance = (int)(month.AllBalance - month.ProgressivePointsBalance - month.StudentPointsBalance + studentPointBalanceAmount + progressivePointBalanceAmount),
                                               BasicPointsBalance = (int)month.BasicPointsBalance,
                                               ExtraPointsBalance = (int)month.ExtraPointsBalance,
                                               PaymentcardPointsBalance = (int)month.PaymentcardPointsBalance,
                                               ProgressivePointsBalance = progressivePointBalanceAmount,
                                               StudentPointsBalance = studentPointBalanceAmount,
                                               CorrectedPointsBalance = (int)month.CorrectedPointsBalance,
                                               MigratedPointsBalance = (int)month.MigratedPointsBalance,
                                               LoyaltyMoneyEarned = loyaltyMoneyTransactions?.Where(lt =>
                                                       lt.AccountEventDateTime.DateTime >= solteqStartDate
                                                       && lt.AccountEventDateTime.DateTime <= solteqEndDate &&
                                                       LoyaltyMoney.BalanceTransactionTypes.Contains(lt.Type) &&
                                                       lt.Amount > 0)
                                                   .Sum(trasactions => trasactions.Amount) ?? 0,
                                           };
                                       })
                                       .OrderByDescending(x => x.Month)
                                       .ToArray()
                                   ?? Array.Empty<MonthlyLoyaltyPoints>(),

        };
    }

    private static bool IsInTimeRange(IMonthTotal month, DateTime firstDate, DateTime lastDate)
    {
        if (firstDate != DateTime.MinValue && ((firstDate.Year == month.Year && firstDate.Month > month.Month) || firstDate.Year > month.Year))
            return false;
        if (lastDate != DateTime.MinValue && ((lastDate.Year == month.Year && lastDate.Month < month.Month) || lastDate.Year < month.Year))
            return false;
        return true;
    }

    private static bool IsInTimeRange(TransferPointSum month, DateTime firstDate, DateTime lastDate)
    {
        if (firstDate != DateTime.MinValue && ((firstDate.Year == month.Year && firstDate.Month > month.Month) || firstDate.Year > month.Year))
            return false;
        if (lastDate != DateTime.MinValue && ((lastDate.Year == month.Year && lastDate.Month < month.Month) || lastDate.Year < month.Year))
            return false;
        return true;
    }

    private static bool IsCurrentMonth(int year, int month)
    {
        return (year == DateTime.Now.Year && month == DateTime.Now.Month);
    }
}