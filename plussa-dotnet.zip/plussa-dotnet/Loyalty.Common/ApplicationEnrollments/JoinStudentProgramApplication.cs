using Loyalty.Common.Configuration;
using Loyalty.Common.Services;
using Loyalty.Domain.Contracts.Responses;
using Loyalty.Domain.Entities.Cosmos;
using Microsoft.Extensions.Options;

namespace Loyalty.Common.ApplicationEnrollments;

public class JoinStudentProgramApplication : ApplicationEnrollmentBase<StudentBenefitJoinApplication>
{
    private readonly IApplicationService _applicationService;
    private readonly ISendEmailService _sendEmailService;

    public JoinStudentProgramApplication(IApplicationService applicationService, ISendEmailService sendEmailService, IOptions<ApplicationConfiguration> options) : base(applicationService, options)
    {
        _applicationService = applicationService;
        _sendEmailService = sendEmailService;
    }

    public override async Task<ApplicationEnrollmentResponse> HandleApplication(StudentBenefitJoinApplication applicationDetails, CancellationToken token)
    {
        var applicationId = await _applicationService.CreateApplicationAsync(
            new StudentBenefitJoinApplication
            {
                EmailAddress = applicationDetails.EmailAddress,
                CustomerId = applicationDetails.CustomerId
            }, token);

        await _sendEmailService.SendStudentProgramConfirmationEmail(applicationDetails.EmailAddress, applicationId, token);

        return ApplicationEnrollmentResponse.Empty();
    }
}