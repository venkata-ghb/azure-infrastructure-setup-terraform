
using Loyalty.Domain.Contracts.Responses;
using Newtonsoft.Json.Linq;

namespace Loyalty.Common.ApplicationEnrollments;

public interface IApplicationEnrollment
{
    Task<ApplicationEnrollmentResponse> EnrollApplication(Guid applicationId, CancellationToken token);

    public Task<ApplicationEnrollmentResponse> EnrollApplication(JObject applicationData, CancellationToken token);
}