using Loyalty.Common.Configuration;
using Loyalty.Common.Constants.Applications;
using Loyalty.Common.Exceptions;
using Loyalty.Common.Services;
using Loyalty.Common.Validators;
using Loyalty.Domain.Contracts.Responses;
using Loyalty.Domain.Entities.Clm;
using Loyalty.Domain.Entities.Cosmos;
using Loyalty.Domain.Entities.Interfaces;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System.Globalization;

namespace Loyalty.Common.ApplicationEnrollments;

public class BankUpdateCardApplicationEnrollment : ApplicationEnrollmentBase<BankUpdateCardApplication>,
    IApplicationEnrollment
{
    private readonly IApplicationService _applicationService;
    private readonly ICardService _cardService;
    private readonly ICustomerIdentifierService _customerIdentifierService;
    private readonly ICustomerService _customerService;

    public BankUpdateCardApplicationEnrollment(
        IApplicationService applicationService, 
        ICardService cardService, 
        ICustomerIdentifierService customerIdentifierService,
        ICustomerService customerService,
        IOptions<ApplicationConfiguration> options) 
        : base(applicationService, options)
    {
        _applicationService = applicationService;
        _cardService = cardService;
        _customerIdentifierService = customerIdentifierService;
        _customerService = customerService;
    }

    public override async Task<ApplicationEnrollmentResponse> HandleApplication(
        BankUpdateCardApplication applicationDetails, CancellationToken token)
    {
        try
        {
            var identifierDetails =
                await _cardService.GetIdentifierByCardNumber(applicationDetails.CardNumberToBeDeleted, token);

            await ValidateAndAddIdentifier(identifierDetails, applicationDetails,
                applicationDetails.CardNumberToBeAdded, token);

            await _applicationService.CreateApplicationAsync(applicationDetails, token);
        }
        catch (NoMatchingCustomerFoundException e)
        {
            await SetErrorState(applicationDetails, e.Error, token);
            throw;
        }
        catch (Exception ex)
        {
            await SetErrorState(applicationDetails, new() {Error = ex.Message, Message = ex.Message}, token);
            throw;
        }

        return new ApplicationEnrollmentResponse
        {
            CardNumber = applicationDetails.CardNumberToBeAdded
        };
    }

    private async Task ValidateAndAddIdentifier(
        IdentifierExtBase identifierDetails,
        BankUpdateCardApplication application,
        string cardNumberToBeAdded,
        CancellationToken token)
    {
        try
        {
            var identifier = await _cardService.GetIdentifierByCardNumberNotThrowException(cardNumberToBeAdded, token);

            if (identifier != null && _customerIdentifierService.CheckIfIdentifierBelongToSameCustomer(identifierDetails.CustomerId, identifier.CustomerId, cardNumberToBeAdded)) return;

            if(!string.IsNullOrEmpty(application.FirstName) && !string.IsNullOrEmpty(application.LastName) && !string.IsNullOrEmpty(application.DateOfBirth))
            {
                var customer = await _customerService.GetCustomer(identifierDetails.CustomerId, token);
                if(!RequestCustomerDetailsMatches(application, customer)) throw new NoMatchingCustomerFoundException(new ApplicationError
                {
                    Error = "No Matching Customer Found",
                    Message = "No Matching Customer Found",
                    TimeStamp = DateTime.Now
                });
            }

            await _customerIdentifierService.AssociateIdentifierToCustomer(identifierDetails.CustomerId, cardNumberToBeAdded, token);
            if (application.ApplicationTypeCode != ApplicationAttributes.CardType.CodeForEnrollment) return;

            var newIdentifierDetails = await _cardService.GetIdentifierByCardNumber(cardNumberToBeAdded, token);
            var lastModifyDate = newIdentifierDetails.LastModify;
            var redemptionEnabled = newIdentifierDetails.RedemptionEnabled;
            var attributes = new AttributeExt[]
            {
                new()
                {
                    Code = ApplicationAttributes.SubType.Code,
                    Value = ApplicationAttributes.SubType.PaymentTime
                }
            };
            await _cardService.AddAttributesByCardNumber(cardNumberToBeAdded, attributes, lastModifyDate, redemptionEnabled, token);
        }
        catch (UpstreamException ex)
        {
            var error = JsonConvert.DeserializeObject<ApplicationError>(ex.Message) ??
                        throw new UpstreamException("Could not deserialize the response.", ex);
            await SetErrorState(application, error, token);
            throw;
        }
        
    }

    private static bool RequestCustomerDetailsMatches(BankUpdateCardApplication dto, ICustomerExt customer)
    {
        if(customer == null || customer.Status != "A") return false;

        DateTime.TryParseExact(customer.BirthDate, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var dateFromCLM);
        DateTime.TryParseExact(dto.DateOfBirth, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var dateFromRequest);
        var matches = false;
        if (!string.IsNullOrEmpty(dto.NationalIdentificationNumber) && !string.IsNullOrEmpty(customer.Ssn))
        {
            matches = CustomerNameValidator.TryValidate(customer, dto.FirstName, dto.LastName) && dto.NationalIdentificationNumber.Equals(customer.Ssn);
        }
        if (!matches) return CustomerNameValidator.TryValidate(customer, dto.FirstName, dto.LastName) &&
               (DateTime.Equals(dateFromCLM, dateFromRequest) || (dateFromCLM.Year == dateFromRequest.Year && dateFromCLM.Month == 12 && dateFromCLM.Day == 31));

        return matches;
    }

}