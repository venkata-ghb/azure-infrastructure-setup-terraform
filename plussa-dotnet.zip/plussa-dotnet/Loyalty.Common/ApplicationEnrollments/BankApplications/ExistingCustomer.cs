using Loyalty.Common.Constants.Applications;
using Loyalty.Common.Exceptions;
using Loyalty.Common.Services;
using Loyalty.Common.Validators;
using Loyalty.Domain.Constants;
using Loyalty.Domain.Contracts.Request.Clm;
using Loyalty.Domain.Entities.Clm;
using Loyalty.Domain.Entities.Cosmos;
using Loyalty.Domain.Entities.Interfaces;
using Newtonsoft.Json;
using System.Globalization;

namespace Loyalty.Common.ApplicationEnrollments.BankApplications;

public class ExistingCustomer
{
    private readonly ICustomerService _customerService;
    private readonly ICardService _cardService;
    private readonly ICustomerIdentifierService _customerIdentifierService;
    private readonly Func<BankApplication, ApplicationError, CancellationToken, Task> _setErrorState;
    public ExistingCustomer(ICustomerService customerService, ICustomerIdentifierService customerIdentifierService, ICardService cardService, Func<BankApplication, ApplicationError, CancellationToken, Task> setErrorState)
    {
        _customerService = customerService;
        _customerIdentifierService = customerIdentifierService;
        _setErrorState = setErrorState;
        _cardService = cardService;
    }

    public async Task AssociateIdentifier(BankApplication application, IAccountSummaryExt accountDetails, CancellationToken token)
    {
        try
        {
            var matchedCustomer = accountDetails.Customers.FirstOrDefault(customer => IfRequestCustomerDetailsMatches(application, customer)) ??
                                  throw new NoMatchingCustomerFoundException(new ApplicationError
                                  {
                                      Error = "No Matching Customer Found",
                                      Message = "No Matching Customer Found",
                                      TimeStamp = DateTime.Now
                                  });

            var identifier = await _cardService.GetIdentifierByCardNumberNotThrowException(application.IdentifierNo, token);

            if (identifier != null && _customerIdentifierService.CheckIfIdentifierBelongToSameCustomer(matchedCustomer.Id, identifier.CustomerId, application.IdentifierNo)) return;

            await _customerIdentifierService.AssociateIdentifierToCustomer(matchedCustomer.Id, application.IdentifierNo, token);
            if (application.CardTypeCode == ApplicationAttributes.CardType.CodeForEnrollment)
            {
                await AddCardAttribute(application.IdentifierNo, token);
            }

            var customerRecord = await _customerService.GetCustomer(matchedCustomer.Id, token);
            if (customerRecord is not null)
            {
                await UpdateCustomerData(customerRecord, application, token);
            }
        }
        catch (UpstreamException e)
        {
            var error = JsonConvert.DeserializeObject<ApplicationError>(e.Message.Split("\n").Last())
                        ?? throw new UpstreamException("Could not deserialize the response.", e);
            await _setErrorState(application, error, token);

            throw;
        }
        catch (NoMatchingCustomerFoundException e)
        {
            await _setErrorState(application, e.Error, token);
            throw;
        }
        catch (ConflictException e)
        {
            await _setErrorState(application, new ApplicationError
            {
                Error = e.Message,
                Message = e.Message,
                TimeStamp = DateTime.Now
            }, token);
            throw;
        }
    }

    private static bool IfRequestCustomerDetailsMatches(BankApplication dto, CustomerSummaryExt customer)
    {
        DateTime.TryParseExact(customer.BirthDate, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var dateFromCLM);
        DateTime.TryParseExact(dto.DateOfBirth, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var dateFromRequest);
        var matches = false;
        if (!string.IsNullOrEmpty(dto.NationalIdentificationNumber) && !string.IsNullOrEmpty(customer.Ssn))
        {
            matches = CustomerNameValidator.TryValidate(customer, dto.FirstName, dto.LastName) && dto.NationalIdentificationNumber.Equals(customer.Ssn);
        }
        if (!matches) return CustomerNameValidator.TryValidate(customer, dto.FirstName, dto.LastName) &&
               (DateTime.Equals(dateFromCLM, dateFromRequest) || (dateFromCLM.Year == dateFromRequest.Year && dateFromCLM.Month == 12 && dateFromCLM.Day == 31));

        return matches;
    }


    private async Task AddCardAttribute(string cardNumber, CancellationToken token)
    {
        var newIdentifierDetails = await _cardService.GetIdentifierByCardNumber(cardNumber, token);
        var lastModifyDate = newIdentifierDetails.LastModify;
        var redemptionEnabled = newIdentifierDetails.RedemptionEnabled;
        var attributes = new AttributeExt[]
        {
                new()
                {
                    Code = ApplicationAttributes.SubType.Code,
                    Value = ApplicationAttributes.SubType.PaymentTime
                }
        };
        await _cardService.AddAttributesByCardNumber(cardNumber, attributes, lastModifyDate, redemptionEnabled, token);
    }

    private async Task UpdateCustomerData(ICustomerExt customerRecord, BankApplication dto, CancellationToken token)
    {
        var customerAssignments = await _customerService.GetCustomerAssignments(customerRecord.Id, token);
        if (CustomerHasOptedForSmsPermission(dto))
        {
            await _customerService.UpdateCustomer(customerRecord.Id, new CustomerUpdateExt
            {
                Address =
                {
                    Mobile = dto.MobilePhone,
                }
            }, token);

            if (!HasActiveAssignment(customerAssignments, CustomerAssignments.SmsMarketingPermission, CustomerAssignments.SmsMarketingPermissionValue))
            {
                await _customerService.SetCustomerAssignment(customerRecord.Id, CustomerAssignments.SmsMarketingPermission, DateTime.UtcNow, CustomerAssignments.SmsMarketingPermissionValue, token);
            }
        }

        if (CustomerHasOptedForEmailPermission(dto))
        {
            await _customerService.UpdateCustomerEmail(customerRecord.Id, dto.EmailAddress, token);
            if (!HasActiveAssignment(customerAssignments, CustomerAssignments.EmailMarketingPermission, CustomerAssignments.EmailMarketingPermissionValue))
            {
                await _customerService.SetCustomerAssignment(customerRecord.Id, CustomerAssignments.EmailMarketingPermission, DateTime.UtcNow, CustomerAssignments.EmailMarketingPermissionValue, token);
            }

        }

        if (CustomerHasUnknownDob(customerRecord))
        {
            var attributes = customerRecord.Attributes.Select(x => new AttributeExt
            {
                Value = x.Code == ApplicationAttributes.UnknownDateOfBirth ? ApplicationAttributes.False : x.Value,
                Code = x.Code
            }).ToArray();

            await _customerService.UpdateBankApplicationCustomerDateOfBirth(customerRecord.Id, dto.DateOfBirth, attributes, token);
        }

    }

    private static bool CustomerHasOptedForEmailPermission(BankApplication dto)
    {
        return dto.EmailMarketingPermission && !string.IsNullOrWhiteSpace(dto.EmailAddress);
    }

    private static bool CustomerHasOptedForSmsPermission(BankApplication dto)
    {
        return dto.SmsMarketingPermission && !string.IsNullOrWhiteSpace(dto.MobilePhone);
    }

    private static bool HasActiveAssignment(IAssignmentExt[] assignments, string assignmentCode, string assignmentValue)
    {
        var activeAssignment = assignments
            .FirstOrDefault(a =>
                string.Equals(a.Code, assignmentCode, StringComparison.OrdinalIgnoreCase)
                && string.Equals(a.Value, assignmentValue, StringComparison.OrdinalIgnoreCase)
                && (a.EndDate == null || a.EndDate >= DateTime.Now.Date));

        return activeAssignment != null;
    }

    public static bool CustomerHasUnknownDob(ICustomerExt customer)
    {
        if (customer == null) return false;

        var unknownDateOfBirth = customer.Attributes.FirstOrDefault(attribute =>
        attribute.Code == ApplicationAttributes.UnknownDateOfBirth &&
        (attribute.Value == ApplicationAttributes.True || attribute.Value == "1"));

        if (unknownDateOfBirth == null) return false;

        return true;
    }
}