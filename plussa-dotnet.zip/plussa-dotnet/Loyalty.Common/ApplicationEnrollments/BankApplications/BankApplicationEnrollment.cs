using Loyalty.Common.Configuration;
using Loyalty.Common.Constants.Applications;
using Loyalty.Common.Exceptions;
using Loyalty.Common.Services;
using Loyalty.Common.Types;
using Loyalty.Domain.Contracts.Request.Clm;
using Loyalty.Domain.Contracts.Responses;
using Loyalty.Domain.Entities.Clm;
using Loyalty.Domain.Entities.Cosmos;
using Loyalty.Domain.Entities.Interfaces;
using Microsoft.Extensions.Options;

namespace Loyalty.Common.ApplicationEnrollments.BankApplications;

public class BankApplicationEnrollment : ApplicationEnrollmentBase<BankApplication>, IApplicationEnrollment
{

    private readonly IApplicationService _applicationService;
    private readonly ISearchService _service;
    private readonly IApplicationEnrollmentService _applicationEnrollmentService;
    private readonly IApplicationEnrollmentServiceRetry _applicationEnrollmentServiceRetry;
    private readonly ICustomerService _customerService;
    private readonly ICustomerIdentifierService _customerIdentifierService;
    private readonly ICardService _cardService;

    public BankApplicationEnrollment(
        IApplicationService applicationService,
        ISearchService service,
        IApplicationEnrollmentService applicationEnrollmentService,
        IApplicationEnrollmentServiceRetry applicationEnrollmentServiceRetry,
        ICustomerIdentifierService customerIdentifierService,
        ICustomerService customerService,
        ICardService cardService,
        IOptions<ApplicationConfiguration> options)
        : base(applicationService, options)
    {
        _applicationService = applicationService;
        _service = service;
        _applicationEnrollmentService = applicationEnrollmentService;
        _applicationEnrollmentServiceRetry = applicationEnrollmentServiceRetry;
        _customerService = customerService;
        _cardService = cardService;
        _customerIdentifierService = customerIdentifierService;
    }

    public override async Task<ApplicationEnrollmentResponse> HandleApplication(BankApplication applicationDetails, CancellationToken token)
    {
        IAccountSummaryExt[] searchResult = Array.Empty<IAccountSummaryExt>();
        IAccountSummaryExt[] businessIdSearchResult = Array.Empty<IAccountSummaryExt>();
        const string B2BAccountType = "COMPANY";
        switch (applicationDetails.CardTypeCode)
        {
            case (ApplicationAttributes.CardType.CodeForEnrollment):
                if (!string.IsNullOrWhiteSpace(applicationDetails.NationalIdentificationNumber))
                {
                    searchResult = await _service.Search(GenerateSSNSearchQuery(applicationDetails), token);
                    if (searchResult.Length == 0 && !string.IsNullOrEmpty(applicationDetails.ExistingIdentifierNo))
                    {
                        searchResult = await _service.Search(GenerateIdentifierSearchQuery(applicationDetails), token);
                    }
                }
                else
                {
                    searchResult = await _service.Search(GenerateIdentifierSearchQuery(applicationDetails), token);
                }

                if (searchResult.Length == 0)
                {
                    searchResult = await _service.Search(GenerateAddressBasedSearchQuery(applicationDetails), token);
                }

                break;
            case (ApplicationAttributes.CardType.CodeForOmaSPB2BEnrollment):
                if(!string.IsNullOrWhiteSpace(applicationDetails.BusinessId)) 
                {
                    businessIdSearchResult = await _service.Search(GenerateBusinessIdSearchQuery(applicationDetails), token);
                    if(businessIdSearchResult.Length != 0)
                    {
                        if (!string.IsNullOrWhiteSpace(applicationDetails.ExistingIdentifierNo) &&
                        applicationDetails.ExistingIdentifierNo[..8] == OmaSPBankCardType.B2BCodeSubstring)
                        {
                            searchResult = await _service.Search(GenerateBusinessIDWithIdentifierSearchQuery(applicationDetails), token);
                        }

                        if (searchResult.Length == 0)
                        {
                            searchResult = await _service.Search(GenerateBusinessIDWithCustomerDetails(applicationDetails), token);
                        }
                    }
                    
                }
                break;
            default:
                if (!string.IsNullOrWhiteSpace(applicationDetails.NationalIdentificationNumber))
                {
                    searchResult = await _service.Search(GenerateSSNSearchQuery(applicationDetails), token);
                    if (searchResult.Length == 0)
                    {
                        searchResult = await _service.Search(GenerateIdentifierSearchQuery(applicationDetails), token);
                    }
                }
                else
                {
                    searchResult = await _service.Search(GenerateIdentifierSearchQuery(applicationDetails), token);
                }
                break;

        }

        switch (searchResult)
        {
            case { Length: 0 }:
                var newCustomer = new NewCustomer(_applicationEnrollmentServiceRetry, _service, _customerService, SetErrorState);
                await newCustomer.Enroll(applicationDetails, token);
                break;

            case { Length: 1 }:
                var existingCustomer = new ExistingCustomer(_customerService, _customerIdentifierService, _cardService, SetErrorState);
                await existingCustomer.AssociateIdentifier(applicationDetails, searchResult[0], token);

                break;

            default:
                await SetErrorState(applicationDetails, new ApplicationError
                {
                    Error = "Multiple customer accounts exists, hence enrollment and identifier association is not possible.",
                    Message = "Multiple customer accounts exists, hence enrollment and identifier association is not possible."
                }, token);
                throw new ConflictException("Multiple customer accounts exists");
        }

        await _applicationService.CreateApplicationAsync(applicationDetails, token);
        return ApplicationEnrollmentResponse.Empty();
    }

    private static SearchRequestExt CommonSearchRequestObject(BankApplication dto)
    {
        return new SearchRequestExt
        {
            Customer = new()
            {
                LastName = dto.LastName,
                Status = Statuses.Active
            },

        };
    }

    private static SearchRequestExt GenerateAddressBasedSearchQuery(BankApplication dto)
    {
        var searchRequest = CommonSearchRequestObject(dto);

        searchRequest = searchRequest with
        {
            Customer = searchRequest.Customer with
            {
                Address = new()
                {
                    Street = dto.StreetAddress,
                    ZipCode = dto.PostCode
                }
            }
        };

        return searchRequest;
    }

    private static SearchRequestExt GenerateBusinessIdSearchQuery(BankApplication dto)
    {
        var searchRequest = new SearchRequestExt();
        var newSearchRequest = searchRequest with
        {
            BusinessId = dto.BusinessId
        };

        return newSearchRequest;
    }

    private static SearchRequestExt GenerateIdentifierSearchQuery(BankApplication dto)
    {
        var searchRequest = CommonSearchRequestObject(dto);

        searchRequest = searchRequest with
        {
            Identifier = new()
            {
                No = dto.ExistingIdentifierNo
            }
        };

        return searchRequest;
    }

    private static SearchRequestExt GenerateSSNSearchQuery(BankApplication dto)
    {
        var searchRequest = CommonSearchRequestObject(dto);

        return searchRequest with
        {
            Customer = searchRequest.Customer with
            {
                Ssn = dto.NationalIdentificationNumber
            }
        };
    }
    private static SearchRequestExt GenerateBusinessIDWithIdentifierSearchQuery(BankApplication dto)
    {
        var searchRequest = new SearchRequestExt();

        var newSearchRequest = searchRequest with
        {
            BusinessId = dto.BusinessId,
            Identifier = new()
            {
                No = dto.ExistingIdentifierNo
            },
            Customer = searchRequest.Customer with
            {
                FirstName = dto.FirstName,
                LastName = dto.LastName
            }
        };

        return newSearchRequest;

    }

    private static SearchRequestExt GenerateBusinessIDWithCustomerDetails(BankApplication dto)
    {
        var searchRequest = new SearchRequestExt();

        var newSearchRequest = searchRequest with
        {
            BusinessId = dto.BusinessId,
            Customer = searchRequest.Customer with
            {
                FirstName = dto.FirstName,
                LastName = dto.LastName,
                Address = new()
                {
                    Street = dto.StreetAddress,
                    ZipCode = dto.PostCode
                }
            }
        };

        return newSearchRequest;
    }
}