using Loyalty.Common.Adapters;
using Loyalty.Common.Constants.Applications;
using Loyalty.Common.Exceptions;
using Loyalty.Common.Extensions.Clm;
using Loyalty.Common.Services;
using Loyalty.Common.Types;
using Loyalty.Domain.Constants;
using Loyalty.Domain.Entities.Cosmos;
using Loyalty.Domain.Entities.Interfaces;
using Newtonsoft.Json;
using Polly.Retry;
using Polly;

namespace Loyalty.Common.ApplicationEnrollments.BankApplications;

internal class NewCustomer
{
    private readonly IApplicationEnrollmentServiceRetry _applicationEnrollmentServiceRetry;
    private readonly ISearchService _searchService;
    private readonly ICustomerService _customerService;
    private readonly Func<BankApplication, ApplicationError, CancellationToken, Task> _setErrorState;

    private static AsyncRetryPolicy RetryIfException = Policy.Handle<InternalServerException>()
     .WaitAndRetryAsync(5, _ => TimeSpan.FromMilliseconds(5000));

    private const string CustomerApplicationErrorWithSSN = "Customer details not found from CLM using the fields First Name, Last Name and SSN.";
    private const string CustomerApplicationErrorWithoutSSN = "Customer details not found from CLM. Please check details in fields First Name, Last Name, Date of Birth, Address, Postcode and Existing card.";
    public NewCustomer(
        IApplicationEnrollmentServiceRetry applicationEnrollmentServiceRetry,
        ISearchService searchService, 
        ICustomerService customerService, 
        Func<BankApplication, ApplicationError, CancellationToken, Task> setErrorState)
    {
        _applicationEnrollmentServiceRetry = applicationEnrollmentServiceRetry;
        _searchService = searchService;
        _customerService = customerService;
        _setErrorState = setErrorState;
    }

    public async Task Enroll(BankApplication application, CancellationToken token)
    {
        await EnrollNewCustomer(application, token);
        if (application.SmsMarketingPermission || application.EmailMarketingPermission)
        {
            await SetCustomerAssignments(application.SmsMarketingPermission, application.EmailMarketingPermission, application.EmailAddress, token);
        }
    }

    private async Task EnrollNewCustomer(BankApplication application, CancellationToken token)
    {
        try
        {
            if ((!OPBankCardType.CardTypes.Contains(application.IdentifierType) || application.CardTypeCode != ApplicationAttributes.CardType.CodeForEnrollment) && 
                (application.CardTypeCode != ApplicationAttributes.CardType.CodeForOmaSPB2BEnrollment))
            {
                
                throw new NoMatchingCustomerFoundException(new ApplicationError
                {
                    Error = string.IsNullOrWhiteSpace(application.NationalIdentificationNumber) ? CustomerApplicationErrorWithoutSSN : CustomerApplicationErrorWithSSN,
                    Message = string.IsNullOrWhiteSpace(application.NationalIdentificationNumber) ? CustomerApplicationErrorWithoutSSN : CustomerApplicationErrorWithSSN,
                    TimeStamp = DateTime.Now
                });
            }

            var bankApplication = application.ToApplicationEnrollmentInfo();
            await RetryIfException.ExecuteAsync(async () => await _applicationEnrollmentServiceRetry.EnrollApplicationRetry(bankApplication, token)); 
        }
        catch (InternalServerException e)
        {
            var error = JsonConvert.DeserializeObject<ApplicationError>(e.Message)
                        ?? throw new UpstreamException("Could not deserialize the response.", e);
            await _setErrorState(application, error, token);
            throw;
        }
        catch (UpstreamException e)
        {
            var error = JsonConvert.DeserializeObject<ApplicationError>(e.Message)
                        ?? throw new UpstreamException("Could not deserialize the response.", e);
            await _setErrorState(application, error, token);
            throw;
        }
        catch (NoMatchingCustomerFoundException e)
        {
            await _setErrorState(application, e.Error, token);
            throw;
        }
    }

    private async Task SetCustomerAssignments(bool smsMarketingPermission, bool emailMarketingPermission, string emailAddress, CancellationToken token)
    {
        var tasks = new List<Task>();
        var searchContract = ClmQueryExtensions.EmailAddressSearchContract(emailAddress);
        var accountSummaryData = await _searchService.Search(searchContract, token);
        var customerId = GetCustomerId(accountSummaryData, emailAddress);
        if (smsMarketingPermission)
        {
            tasks.Add(_customerService.SetCustomerAssignment(customerId, CustomerAssignments.SmsMarketingPermission, DateTime.UtcNow, CustomerAssignments.SmsMarketingPermissionValue, token));
        }
        if (emailMarketingPermission)
        {
            tasks.Add(_customerService.SetCustomerAssignment(customerId, CustomerAssignments.EmailMarketingPermission, DateTime.UtcNow, CustomerAssignments.EmailMarketingPermissionValue, token));
        }
        await Task.WhenAll(tasks);
    }

    private static int GetCustomerId(IAccountSummaryExt[] accountSummaryData, string email)
    {
        var customers = accountSummaryData
            .SelectMany(a => a.Customers)
            .Where(customer => customer.Address.Email.Equals(email, StringComparison.OrdinalIgnoreCase))
            .Select(customer => customer.Id)
            .ToList();

        if (customers.Count == 0) throw new NotFoundException("Customer Id number not found");
        return customers.First();
    }
}