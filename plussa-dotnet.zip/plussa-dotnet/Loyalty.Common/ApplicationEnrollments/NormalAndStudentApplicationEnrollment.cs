using Loyalty.Common.Configuration;
using Loyalty.Common.Constants.CLM;
using Loyalty.Common.Exceptions;
using Loyalty.Common.Extensions;
using Loyalty.Common.Extensions.Clm;
using Loyalty.Common.Services;
using Loyalty.Domain.Constants;
using Loyalty.Domain.Contracts.Request.Clm;
using Loyalty.Domain.Contracts.Responses;
using Loyalty.Domain.Entities.Clm;
using Loyalty.Domain.Entities.Cosmos;
using Loyalty.Domain.Enums;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Polly;
using Polly.Retry;

namespace Loyalty.Common.ApplicationEnrollments;

public class NormalAndStudentApplicationEnrollment : ApplicationEnrollmentBase<HouseholdEnrollmentApplication>, IApplicationEnrollment
{
    private readonly IApplicationEnrollmentService _applicationEnrollmentService;
    private readonly ICustomerService _customerService;
    private readonly ISearchService _searchService;
    private readonly IBarcodeGeneratorService _barcodeGenerator;
    private readonly ISendEmailService _sendEmailService;
    private static AsyncRetryPolicy RetryIfException = Policy.Handle<Exception>()
        .WaitAndRetryAsync(3, attempt => TimeSpan.FromMilliseconds(10000 * attempt));

    public NormalAndStudentApplicationEnrollment(
        IApplicationService applicationService,
        IApplicationEnrollmentService applicationEnrollmentService,
        ICustomerService customerService,
        ISearchService searchService,
        IBarcodeGeneratorService barcodeGenerator,
        ISendEmailService sendEmailService,
        IOptions<ApplicationConfiguration> options) : base(applicationService, options)
    {
        _applicationEnrollmentService = applicationEnrollmentService;
        _customerService = customerService;
        _searchService = searchService;
        _barcodeGenerator = barcodeGenerator;
        _sendEmailService = sendEmailService;
    }

    public override async Task<ApplicationEnrollmentResponse> HandleApplication(HouseholdEnrollmentApplication applicationDetails, CancellationToken token)
    {
        try
        {
            var applicationData = CreateApplicationData(applicationDetails);
            await _applicationEnrollmentService.EnrollApplication(applicationData, token);
        }
        catch (UpstreamException e)
        {
            var error = JsonConvert.DeserializeObject<ApplicationError>(e.Message)
                          ?? throw new UpstreamException("Could not deserialize the response.", e);

            await SetErrorState(applicationDetails, error, token);
            throw;
        }

        await SetSucccessState(applicationDetails, token);
        var searchContract = ClmQueryExtensions.EmailAddressSearchContract(applicationDetails.EmailAddress);
        var accountSummaryData = await _searchService.Search(searchContract, token);
        //TODO
        var customer = new CustomerSummaryExt();//accountSummaryData.GetCustomer(applicationDetails.EmailAddress);
        if (applicationDetails.MarketingPermission)
        {
            await RetryIfException.ExecuteAsync(async () => await SetMarketingAssignments(customer, token));
        }

        var cardNumber = customer.MainIdentifier;
        var cardHolderName = string.Concat(customer.FirstName, " ", customer.LastName);
        var barcode = _barcodeGenerator.BarcodeGenerator(cardNumber, cardHolderName, token);
        await _sendEmailService.SendEmailWithBarcode(applicationDetails.Language, applicationDetails.EmailAddress, barcode, applicationDetails.CardType,applicationDetails.ApplicationType.ToString(), cardNumber, token);

        var response = customer.ToApplicationEnrollmentResponse() with
        {
            ApplicationType = applicationDetails.ApplicationType.ToString()
        };
        return response;
    }

    private async Task SetMarketingAssignments(CustomerSummaryExt customer, CancellationToken token)
    {
        await _customerService.SetCustomerAssignment(customer.Id, CustomerAssignments.EmailMarketingPermission,
            DateTime.UtcNow, CustomerAssignments.EmailMarketingPermissionValue, token);
    }

    private static ApplicationEnrollmentInfo CreateApplicationData(HouseholdEnrollmentApplication applicationDetails)
    {
        var customerAttributes = new List<AttributeExt>();

        if (applicationDetails.ApplicationType == ApplicationTypes.SH)
        {
            customerAttributes.Add(new AttributeExt
            {
                Code = CustomerAttributes.StudentEmail,
                Value = applicationDetails.EmailAddress
            });
        }

        if (applicationDetails.PurchaseRecordingLevel != null)
        {
            customerAttributes.Add(new AttributeExt
            {
                Code = CustomerAttributes.PurchaseRecordingLevel,
                Value = applicationDetails.PurchaseRecordingLevel.GetEnumMember().Value
            });
        }

        return new ApplicationEnrollmentInfo
        {
            FirstName = applicationDetails.FirstName,
            LastName = applicationDetails.LastName,
            BirthDate = applicationDetails.DateOfBirth,
            Gender = applicationDetails.Gender,
            Language = applicationDetails.Language,
            Permissions = ApplicationExtensions.CreatePermissions(applicationDetails.MarketingPermission),
            Address = new AddressBaseExt
            {
                City = applicationDetails.City,
                Country = applicationDetails.Country,
                Email = applicationDetails.EmailAddress,
                Mobile = applicationDetails.PhoneNumber,
                PostalCode = applicationDetails.PostCode,
                Street = applicationDetails.StreetAddress,
            },
            Ssn = applicationDetails.NationalIdentificationNumber,
            CustomerAttributes = customerAttributes.ToArray(),
            IdentifierType = applicationDetails.CardType.ToLower() == "webkaties" ? IdentifierTypes.Webkateis : IdentifierTypes.PlussaDigi,
        };
    }
}
