using Loyalty.Common.Configuration;
using Loyalty.Common.Services;
using Loyalty.Domain.Contracts.Responses;
using Loyalty.Domain.Entities.Cosmos;
using Loyalty.Domain.Enums;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;

namespace Loyalty.Common.ApplicationEnrollments;

public abstract class ApplicationEnrollmentBase<TApplication> where TApplication : BaseApplication
{
    private readonly IApplicationService _applicationService;

    public abstract Task<ApplicationEnrollmentResponse> HandleApplication(
        TApplication applicationDetails, 
        CancellationToken token);

    protected ApplicationEnrollmentBase(IApplicationService applicationService, IOptions<ApplicationConfiguration> options)
    {
        _applicationService = applicationService;
        Options = options.Value;
    }

    public async Task<ApplicationEnrollmentResponse> EnrollApplication(Guid applicationId, CancellationToken token)
    {
        var application = await _applicationService.GetApplicationByIdAsync<TApplication>(applicationId.ToString(), token);
        return await HandleApplication(application, token);
    }

    public Task<ApplicationEnrollmentResponse> EnrollApplication(JObject applicationData, CancellationToken token)
    {
        var appData = applicationData.ToObject<TApplication>();
        if (appData is null) throw new ArgumentNullException(nameof(applicationData));
        
        return HandleApplication(appData, token);
    }

    public async Task SetErrorState(TApplication application, ApplicationError error, CancellationToken token) 
    {
        var errorApplicationToUpdate = application with
        {
            ApplicationStatus = ApplicationStatuses.ERROR,
            Errors = new List<ApplicationError> { error },
            Ttl = (int)TimeSpan.FromDays(Options.RemoveErroneousAfterDays).TotalSeconds
        };

        await _applicationService.UpsertApplicationAsync(errorApplicationToUpdate, token);
    }

    public async Task SetSucccessState(TApplication application, CancellationToken token) 
    {
        var errorApplicationToUpdate = application with
        {
            ApplicationStatus = ApplicationStatuses.SUCCESS,
            Ttl = (int)TimeSpan.FromDays(Options.RemoveSuccessAfterDays).TotalSeconds
        };

        await _applicationService.UpsertApplicationAsync(errorApplicationToUpdate, token);
    }

    public ApplicationConfiguration Options { get; init; }
}