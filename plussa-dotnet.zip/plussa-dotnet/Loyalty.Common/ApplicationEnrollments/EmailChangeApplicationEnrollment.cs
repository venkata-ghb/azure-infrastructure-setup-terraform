using Loyalty.Common.Configuration;
using Loyalty.Common.Exceptions;
using Loyalty.Common.Services;
using Loyalty.Domain.Contracts.Responses;
using Loyalty.Domain.Entities.Cosmos;
using Loyalty.Domain.Enums;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;

namespace Loyalty.Common.ApplicationEnrollments;

public class EmailChangeApplicationEnrollment: ApplicationEnrollmentBase<EmailChangeApplication>, IApplicationEnrollment
{
    private readonly ICustomerService _customerService;

    public EmailChangeApplicationEnrollment(IApplicationService applicationService, ICustomerService customerService, IOptions<ApplicationConfiguration> options) 
        : base(applicationService, options)
    {
        _customerService = customerService;
    }

    public override async Task<ApplicationEnrollmentResponse> HandleApplication(
        EmailChangeApplication application, CancellationToken token)
    {
        try
        {
            if (application.ApplicationStatus != ApplicationStatuses.DRAFT)
            {
                throw new ConflictException("This email application request was already handled.");
            }

            await _customerService.UpdateCustomerEmail(application.CustomerId, application.EmailAddress, token);
        }
        catch (UpstreamException ex)
        {
            var error = JsonConvert.DeserializeObject<ApplicationError>(ex.Message)
                        ?? throw new UpstreamException("Could not deserialize the response.", ex);

            await SetErrorState(application, error, token);
            throw;
        }
        catch (Exception ex)
        {
            await SetErrorState(application, new() { Error = ex.Message, Message = ex.Message }, token);
            throw;
        }

        await SetSucccessState(application, token);
        return ApplicationEnrollmentResponse.Empty();
    }
}