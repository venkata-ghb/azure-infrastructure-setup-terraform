using Loyalty.Common.Configuration;
using Loyalty.Common.Services;
using Loyalty.Domain.Contracts.Responses;
using Loyalty.Domain.Entities.Cosmos;
using Microsoft.Extensions.Options;

namespace Loyalty.Common.ApplicationEnrollments;

public class UpdateEmailAddressApplication : ApplicationEnrollmentBase<EmailChangeApplication>
{
    private readonly IApplicationService _applicationService;
    private readonly ISendEmailService _sendEmailService;

    public UpdateEmailAddressApplication(IApplicationService applicationService, ISendEmailService sendEmailService, IOptions<ApplicationConfiguration> options) : base(applicationService, options)
    {
        _applicationService = applicationService;
        _sendEmailService = sendEmailService;
    }

    public override async Task<ApplicationEnrollmentResponse> HandleApplication(EmailChangeApplication applicationDetails, CancellationToken token)
    {
        var applicationId = await _applicationService.CreateApplicationAsync(
            new EmailChangeApplication
            {
                EmailAddress = applicationDetails.EmailAddress,
                CustomerId = applicationDetails.CustomerId
            }, token);

        await _sendEmailService.SendEmailChangeConfirmationEmail(applicationDetails.EmailAddress, applicationId, token);
        return ApplicationEnrollmentResponse.Empty();
    }
}