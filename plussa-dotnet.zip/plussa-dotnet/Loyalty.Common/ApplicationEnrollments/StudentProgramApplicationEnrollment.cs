using Loyalty.Common.Configuration;
using Loyalty.Common.Constants.CLM;
using Loyalty.Common.Exceptions;
using Loyalty.Common.Services;
using Loyalty.Domain.Contracts.Request.Clm;
using Loyalty.Domain.Contracts.Responses;
using Loyalty.Domain.Entities.Cosmos;
using Loyalty.Domain.Enums;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;

namespace Loyalty.Common.ApplicationEnrollments;

public class StudentProgramApplicationEnrollment : ApplicationEnrollmentBase<StudentBenefitJoinApplication>, IApplicationEnrollment
{
    private readonly ICustomerService _customerService;

    public StudentProgramApplicationEnrollment(IApplicationService applicationService, ICustomerService customerService, IOptions<ApplicationConfiguration> options) 
        : base(applicationService, options)
    {
        _customerService = customerService;
    }

    public override async Task<ApplicationEnrollmentResponse> HandleApplication(
        StudentBenefitJoinApplication application, CancellationToken token)
    {
        try
        {
            if (application.ApplicationStatus != ApplicationStatuses.DRAFT)
            {
                throw new ConflictException(("User attempted to verify student email address that was already handled!"));
            }

            await _customerService.UpdateCustomerAttributes(
                application.CustomerId,
                new CustomerAttributeUpdateExt
                {
                    PatchAttributes = new[]
                    {
                        new CustomerAttributeUpdateExt.AttributePatchExt(
                            CustomerAttributeUpdateExt.PatchOperationType.Add, CustomerAttributes.StudentEmail,
                            application.EmailAddress)
                    }
                }, token);
        }
        catch (UpstreamException ex)
        {
            var error = JsonConvert.DeserializeObject<ApplicationError>(ex.Message)
                        ?? throw new UpstreamException("Could not deserialize the response.", ex);

            await SetErrorState(application, error, token);
            throw;
        }

        await SetSucccessState(application, token);
        return ApplicationEnrollmentResponse.Empty();
    }
}