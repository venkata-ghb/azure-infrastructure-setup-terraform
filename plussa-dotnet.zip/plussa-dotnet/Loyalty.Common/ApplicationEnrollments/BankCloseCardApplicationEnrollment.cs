using Loyalty.Common.Configuration;
using Loyalty.Common.Constants.CLM;
using Loyalty.Common.Services;
using Loyalty.Common.Types;
using Loyalty.Domain.Contracts.Responses;
using Loyalty.Domain.Entities.Clm;
using Loyalty.Domain.Entities.Cosmos;
using Loyalty.Domain.Entities.CosmosCLM;
using Loyalty.Domain.Entities.Interfaces;
using Loyalty.Domain.Enums;
using Microsoft.Extensions.Options;

namespace Loyalty.Common.ApplicationEnrollments;

public class BankCloseCardApplicationEnrollment : ApplicationEnrollmentBase<BankCloseCardApplication>, IApplicationEnrollment
{
    private readonly IApplicationService _applicationService;
    private readonly ICardService _cardService;
    private readonly ICustomerService _customerService;

    public BankCloseCardApplicationEnrollment(IApplicationService applicationService, ICardService cardService, ICustomerService customerService, IOptions<ApplicationConfiguration> options) : base(applicationService, options)
    {
        _applicationService = applicationService;
        _cardService = cardService;
        _customerService = customerService;
    }

    public override async Task<ApplicationEnrollmentResponse> HandleApplication(
        BankCloseCardApplication applicationDetails, CancellationToken token)
    {
        try
        {
            var cardToClose = await _cardService.GetIdentifierByCardNumber(applicationDetails.CardNumber, token);
            if (cardToClose.Status != CardStatus.Active)
            {
                return new ApplicationEnrollmentResponse();
            }

            await _cardService.BlockCardByCardNumber(applicationDetails.CardNumber, applicationDetails.ClosingReason, token);
            var customerDetails = _customerService.GetCustomer(cardToClose.CustomerId, token);
            var customerIdentifiers = _customerService.GetCustomerIdentifiers(cardToClose.CustomerId, token);
            await Task.WhenAll(customerDetails, customerIdentifiers);

            var orderPhysicalCard = false;
            var newCardNumber = string.Empty;
            if (isActiveCustomer(customerDetails.Result) && hasNoActiveCards(customerIdentifiers.Result) && applicationDetails.CardNumber[..8] != OmaSPBankCardType.B2BCodeSubstring)
            {
                // Request for new card number if no active cards left
                newCardNumber = await _cardService.RequestNewCardForCustomer(cardToClose.CustomerId, IdentifierTypes.Webkateis, token);
                orderPhysicalCard = true;
            }

            // temporary we are putting below code under try-catch to avoid issue in other process.
            // Order physical card 
            try
            {
                if (orderPhysicalCard && !string.IsNullOrEmpty(newCardNumber) && applicationDetails.ApplicationType == ApplicationTypes.BD)
                {
                    // Order physical card 
                    await _cardService.OrderNewCardForCustomer(cardToClose.CustomerId, newCardNumber, token);
                }
            }
            catch (Exception e)
            {
                // ignored
            }

            await _applicationService.CreateApplicationAsync(applicationDetails, token);
            return ApplicationEnrollmentResponse.Empty();
        }
        catch (Exception ex)
        {
            var error = new ApplicationError
            {
                Error = ex.Message,
                Message = ex.Message,
                TimeStamp = DateTime.Now
            };

            await SetErrorState(applicationDetails, error, token);
            throw;
        }
    }

    private bool hasNoActiveCards(CustomerIdentifierExt[] identifiers)
    {
        var activeCard = identifiers.FirstOrDefault(id => id.Status == CardStatus.Active);
        return activeCard == null;
    }
    private bool isActiveCustomer(ICustomerExt customer)
    {
        return customer != null && customer.Status == CustomerStatus.Active;
    }
}