using Loyalty.Common.Configuration;
using Loyalty.Common.Constants.CLM;
using Loyalty.Common.Exceptions;
using Loyalty.Common.Extensions;
using Loyalty.Common.Extensions.Clm;
using Loyalty.Common.Services;
using Loyalty.Domain.Constants;
using Loyalty.Domain.Contracts.Request.Clm;
using Loyalty.Domain.Contracts.Responses;
using Loyalty.Domain.Entities.Clm;
using Loyalty.Domain.Entities.Cosmos;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;

namespace Loyalty.Common.ApplicationEnrollments;

public class ParallelPersonApplicationEnrollment : ApplicationEnrollmentBase<ParallelAdultApplication>, IApplicationEnrollment
{
    private readonly IApplicationEnrollmentService _applicationEnrollmentService;
    private readonly ISearchService _searchService;
    private readonly ICustomerService _customerService;
    private readonly IBarcodeGeneratorService _barcodeGenerator;
    private readonly ISendEmailService _sendEmailService;

    public ParallelPersonApplicationEnrollment(IApplicationService applicationService,
        IApplicationEnrollmentService applicationEnrollmentService,
        IOptions<ApplicationConfiguration> options,
        ISearchService searchService,
        IBarcodeGeneratorService barcodeGenerator,
        ISendEmailService sendEmailService,
        ICustomerService customerService) : base(applicationService, options)
    {
        _applicationEnrollmentService = applicationEnrollmentService;
        _searchService = searchService;
        _customerService = customerService;
        _barcodeGenerator = barcodeGenerator;
        _sendEmailService = sendEmailService;
    }

    public override async Task<ApplicationEnrollmentResponse> HandleApplication(ParallelAdultApplication applicationDetails, CancellationToken token)
    {
        try
        {
            var customerAttributes = new List<AttributeExt>();
            if (applicationDetails.PurchaseRecordingLevel != null)
            {
                customerAttributes.Add(new AttributeExt
                {
                    Code = CustomerAttributes.PurchaseRecordingLevel,
                    Value = applicationDetails.PurchaseRecordingLevel.GetEnumMember().Value
                });
            }

            var applicationData = new ApplicationEnrollmentInfo
            {
                FirstName = applicationDetails.FirstName,
                LastName = applicationDetails.LastName,
                BirthDate = applicationDetails.DateOfBirth,
                Gender = applicationDetails.Gender,
                Language = applicationDetails.Language,
                Permissions = applicationDetails.MarketingPermission.CreatePermissions(),
                Address = new AddressBaseExt
                {
                    City = applicationDetails.City,
                    Country = applicationDetails.Country,
                    Email = applicationDetails.EmailAddress,
                    Mobile = applicationDetails.PhoneNumber,
                    PostalCode = applicationDetails.PostCode,
                    Street = applicationDetails.StreetAddress,
                },
                Ssn = applicationDetails.NationalIdentificationNumber,
                IdentifierType = applicationDetails.CardType.ToLower() == "webkaties" ? IdentifierTypes.Webkateis : IdentifierTypes.PlussaDigi,
                AccountId = applicationDetails.HouseholdId,
                CustomerAttributes = customerAttributes.ToArray(),
            };

            await _applicationEnrollmentService.EnrollApplication(applicationData, token);
        }
        catch (UpstreamException e)
        {
            var error = JsonConvert.DeserializeObject<ApplicationError>(e.Message)
                          ?? throw new UpstreamException("Could not deserialize the response.", e);
            await SetErrorState(applicationDetails, error, token);
            throw;
        }

        // Fetch created customer with email search
        var customer = await _searchService.GetCustomerByEmail(applicationDetails.EmailAddress, token);

        // Additional setup for created customer
    
        if (applicationDetails.CanUsePlussaMoney)
        {
            await _customerService.UpdateCustomerRedemption(customer.Id, applicationDetails, token);
        }
        if (applicationDetails.MarketingPermission)
        {
            await SetMarketingAssignments(customer, token);
        }

        // Finalize the application in cosmos
        await SetSucccessState(applicationDetails, token);

        var cardNumber = customer.MainIdentifier;
        var cardHolderName = string.Concat(customer.FirstName, " ", customer.LastName);
        var barcode = _barcodeGenerator.BarcodeGenerator(cardNumber, cardHolderName, token);
        await _sendEmailService.SendEmailWithBarcode(applicationDetails.Language, applicationDetails.EmailAddress, barcode, applicationDetails.CardType, applicationDetails.ApplicationType.ToString(),cardNumber, token);

        var response = customer.ToApplicationEnrollmentResponse() with
        {
            ApplicationType = applicationDetails.ApplicationType.ToString()
        };
        return response;
    }

    private async Task SetMarketingAssignments(CustomerSummaryExt customer, CancellationToken token)
    {
        await _customerService.SetCustomerAssignment(customer.Id, CustomerAssignments.EmailMarketingPermission,
            DateTime.UtcNow, CustomerAssignments.EmailMarketingPermissionValue, token);
    }
    private async Task SetPurchaseRecordingLevelAssignment(CustomerSummaryExt customer, string purchaseRecordingLevel, CancellationToken token)
    {
        await _customerService.SetCustomerAssignment(customer.Id, CustomerAssignments.PurchasePermissionsCode,
            DateTime.UtcNow, purchaseRecordingLevel, token);
    }
}