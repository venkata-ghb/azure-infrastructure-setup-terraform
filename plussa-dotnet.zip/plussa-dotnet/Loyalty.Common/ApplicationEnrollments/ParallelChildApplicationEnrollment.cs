using Loyalty.Common.Configuration;
using Loyalty.Common.Exceptions;
using Loyalty.Common.Extensions;
using Loyalty.Common.Extensions.Clm;
using Loyalty.Common.Services;
using Loyalty.Domain.Constants;
using Loyalty.Domain.Contracts.Request.Clm;
using Loyalty.Domain.Contracts.Responses;
using Loyalty.Domain.Entities.Clm;
using Loyalty.Domain.Entities.Cosmos;
using Mapster;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Polly;
using Polly.Retry;

namespace Loyalty.Common.ApplicationEnrollments;

public class ParallelChildApplicationEnrollment : ApplicationEnrollmentBase<ChildApplicationEnrollment>, IApplicationEnrollment
{
    private readonly IApplicationEnrollmentService _applicationEnrollmentService;
    private readonly ICustomerService _customerService;
    private readonly ISearchService _searchService;
    private static AsyncRetryPolicy RetryIfException = Policy.Handle<Exception>()
        .WaitAndRetryAsync(3, attempt => TimeSpan.FromMilliseconds(10000 * attempt));

    public ParallelChildApplicationEnrollment(
        IApplicationService applicationService,
        IApplicationEnrollmentService applicationEnrollmentService,
        ICustomerService customerService,
        ISearchService searchService,
        IOptions<ApplicationConfiguration> options) : base(applicationService, options)
    {
        _applicationEnrollmentService = applicationEnrollmentService;
        _customerService = customerService;
        _searchService = searchService;
    }

    public override async Task<ApplicationEnrollmentResponse> HandleApplication(ChildApplicationEnrollment application, CancellationToken token)
    {
        try
        {
            var request = application.Adapt<ParallelChildApplicationRequest>();
            await _applicationEnrollmentService.EnrollChildApplication(application.CustomerId, request, token);
        }
        catch (UpstreamException e)
        {
            var error = JsonConvert.DeserializeObject<ApplicationError>(e.Message.Split("\n").Last())
                        ?? throw new UpstreamException("Could not deserialize the response.", e);
            await SetErrorState(application, error, token);
            throw;
        }

        // Fetch created child
        var customer = await GetEnrolledChildCustomer(application, token);

        // Update redemption for created child
        await _customerService.UpdateCustomerRedemption(customer.Id, application, token);

        await SetSucccessState(application, token);
        var response = customer.ToApplicationEnrollmentResponse() with
        {
            ApplicationType = application.ApplicationType.ToString()
        };
        return response;
    }


    public async Task<CustomerSummaryExt> GetEnrolledChildCustomer(ChildApplicationEnrollment application, CancellationToken token)
    {
        if (!string.IsNullOrEmpty(application.Address.Email))
        {
            var childEmailAddress = application.Address.Email;
            var customer = await _searchService.GetCustomerByEmail(childEmailAddress, token);
            return customer;
        }
        else
        {
            var searchResults = await _searchService.Search(ClmQueryExtensions.CustomerIdSearchContract(application.CustomerId), token);
            return searchResults.First().Customers.First(cust => cust.FirstName == application.FirstName && cust.LastName == application.LastName);
        }
    }
}
