# Deploy Azure Function dotnet code

This docu explains, what needs to be prepared to deploy Azure Function first time. 

## Description

When we want to deploy Azure Function code with new API first time we need to prepare config files described below. 
* We need to generate openapi spec (file name openapi.yml) with code. 
* Create and fulfill file apiconfig.yml - described below. API config is part of the solution Azure API Management DevOps Resource Kit and it's needed to generate ARM templates with DevOps Resource Kit tool.

```
version: 0.0.1
apimServiceName: K-apim-dev
apiVersionSets:
  - id: loyalty-clm-aspa-version-set <- name of the version sets
    displayName: Loyalty CLM ASPA
    description: Loyalty CLM ASPA
    versioningScheme: Segment
apis:
  - name: loyalty-clm-aspa <- name of api
    displayName: Loyalty CLM ASPA
    policy: ../../Loyalty.Aspa/api-policy.xml <- file with api policy
    type: http
    description: "Implements endpoints for ASPA UI."
    openApiSpec: ../../Loyalty.Aspa/openapi.yml <- path to openapi spec
    suffix: loyalty-clm/aspa <- suffix in url 
    subscriptionRequired: true
    apiVersionSetId: loyalty-clm-aspa-version-set
    apiVersion: v1
    isCurrent: true
    tags: Loyalty
    products: loyalty-aspa-api
    serviceUrl: "https://prr-nlp-test-aspa-dt-func.azurewebsites.net/api" <- azure function url
    subscriptionKeyParameterNames:
      header: "Ocp-Apim-Subscription-Key"

tags:
  - displayName: Loyalty
outputLocation: ../../Loyalty.Aspa/arm-templates
linked: true
linkedTemplatesBaseUrl: ./
linkedTemplatesUrlQueryString: ''
```

More details about this config file we can find in https://github.com/Azure/azure-api-management-devops-resource-kit.

We have to also prepare azure pipeline file which triggers pipeline. We need to copy azure-pipelines.yml from another function and modify it.

* Modify path to Azure Function

```
trigger:
  branches:
    include:
      - develop
  paths:
    include:
      - Loyalty.Aspa/* <- here should be placed catalog with function >
      - Loyalty.Common/*
      - Loyalty.Domain/*
```

* Change variable functionName to a unique one

```
variables:
  functionName: "aspa"
```

* Check parameters. For Dev environment there is no need to change it.

```
parameters:
    env: 'dev'
    functionApp: $(functionName)
    serviceConnection: 'Plussa Dev'
    armSubscription: 'Plussa Dev'
    armStorage: 'prrnlpdevarmtmpl'
    apimName: 'K-apim-dev'
    apimSubscriptionID: '44ee698c-13cb-4e38-8a00-5a2cb8abb6d0'
    apimSubscription: 'PlussaInterfaces APIM Dev'
    apimResourceGroup: 'Kesko_WE_RG_APIM_DEV001'
```

At the end you must create Azure DevOps pipeline based on existing template, and run it.

Inspiration, code snippets, etc.
* [Azure-devops-resource-kit](https://github.com/Azure/azure-api-management-devops-resource-kit)



