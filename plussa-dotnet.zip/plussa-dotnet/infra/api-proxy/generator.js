#!/usr/bin/env node
const wap = require("webapi-parser").WebApiParser;
const path = require("path");
const fs = require("fs");
const { merge, isErrorResult } = require("openapi-merge");
const yaml = require("js-yaml");
const args = process.argv.slice(2);

console.log("Running yml generator script with following args:", args);

async function raml2Oas(api) {
  const inFolder = path.join(__dirname, "./clm_raml/", api);
  const inPath = path.join(inFolder, "api.raml");
  console.log("-- input path: ");
  const model = await wap.raml10.parse(`file://${inPath}`);
  console.log("-- model parsed");

  // Resolve imports in model
  const out = await wap.raml10.resolve(model);
  console.log("-- resolved base");

  const outPath = path.join(__dirname, "./clm_output/", api, "api.yaml");
  console.log("-- output path: ", outPath);
  const outDir = path.join(__dirname, "./clm_output/", api);
  console.log("-- output dir: ", outDir);

  console.log("-- generating file to:", outPath);
  if (!fs.existsSync(outDir)) {
    fs.mkdirSync(outDir, { recursive: true });
  }

  // Generate extension-api if there is one
  const extensionPath = path.join(__dirname, "./clm_raml/", api, "/extensions");
  if (!fs.existsSync(extensionPath)) {
    // Generate OAS 3.0 YAML file
    console.log("---- without extensions");
    await wap.oas30.generateYamlFile(out, `file://${outPath}`);
    return;
  }

  console.log("---- with extensions");

  const extensionModel = await wap.raml10.parse(
    `file://${extensionPath}/ext_api.raml`
  );
  console.log("---- parsed", `file://${extensionPath}/ext_api.raml`);
  const extensionOut = await wap.raml10.resolve(extensionModel);
  console.log("---- resolved extension");

  // Generate OAS 3.0 YAML file
  const output = await wap.oas30.generateYamlString(out);
  console.log("---- resolved base yml strings");

  var extensionOutput = await wap.oas30.generateYamlString(extensionOut);
  console.log("---- resolved extension yml strings");

  var coreYaml = yaml.load(output);
  var extensionYaml = yaml.load(extensionOutput);

  expandAmf(
    coreYaml,
    path.join(inFolder, "resourceTypes.raml"),
    "resourceTypes."
  );
  console.log("---- expanded base oas");
  expandAmf(
    extensionYaml,
    path.join(inFolder, "resourceTypes.raml"),
    "resourceTypes."
  );
  if (fs.existsSync(path.join(extensionPath, "ext_resourceTypes.raml"))) {
    expandAmf(extensionYaml, path.join(extensionPath, 'ext_resourceTypes.raml'), 'extResourceTypes.');
    console.log('---- expanded extension yml')
  }

  let keys = Object.keys(extensionYaml.paths);

  console.log('---- remove duplicate paths from extensionYaml')
  keys.map((x) => {
    if (Object.entries(coreYaml.paths).some((path) => path[0] == x)) {
      console.log('Deleting duplicate Path ' + x);
      delete extensionYaml.paths[x]
    }
  });

  const mergeResult = merge([
    {
      oas: coreYaml,
    },
    {
      oas: extensionYaml,
    },
  ]);
  console.log("---- merged");

  if (isErrorResult(mergeResult)) {
    console.error(`${mergeResult.message} (${mergeResult.type})`);
    return;
  }

  console.log("---- Dumping the yaml");

  fs.writeFile(outPath, yaml.dump(mergeResult.output), (err) => {
    if (err) {
      console.error(err);
      return;
    }
  });
}

const verbs = ["get", "put", "post", "delete", "patch"];
const resourceTypePrefix = "resourceTypes.";

/**
 * Expands open api specification document with data that was lost in translation and placed in x-amf- nodes.
 * @param {*} yaml
 * @param {*} resourcePath
 */
function expandAmf(yaml, resourcePath, resourceTypePrefix) {
  const resourceTypes = getAvailableResourceTypes(resourcePath);

  console.log(yaml);

  for (let apiPath of Object.entries(yaml.paths)) {
    const detailsObject = apiPath[1];
    const amfType = detailsObject["x-amf-type"];
    if (amfType) {
      const keys = Object.keys(amfType);
      if (keys.length > 0 && keys[0].startsWith(resourceTypePrefix)) {
        const resourceType = keys[0].split(resourceTypePrefix)[1];
        appendResourceTypeOperations(
          amfType,
          detailsObject,
          resourceType,
          resourceTypes,
          resourceTypePrefix
        );
      }
    }
  }
}

/**
 * Fetches resource types from file
 * @param {*} resourcePath
 * @returns
 */
function getAvailableResourceTypes(resourcePath) {
  const resoureTypesYaml = fs.readFileSync(resourcePath);
  var resourceTypes = yaml.load(resoureTypesYaml);

  return resourceTypes.resourceTypes;
}

/**
 * Appends endpoints defined in resource types to the open api specification
 * @param {*} amfType the metadata to generate description from
 * @param {*} detailsObject the open api specification node to edit
 * @param {*} resourceType the type to look endpoints for
 * @param {*} resourceTypes collection of types to look endpoints from
 */
function appendResourceTypeOperations(
  amfType,
  detailsObject,
  resourceType,
  resourceTypes,
  resourceTypePrefix
) {
  console.log("rt", resourceType);
  const selectedResourceType = resourceTypes[resourceType];
  // Omit optional endpoints (such as "put?")
  const keys = Object.keys(selectedResourceType);
  for (let i = 0; i < keys.length; i++) {
    const currentKey = keys[i];
    if (verbs.some((x) => x === currentKey)) {
      detailsObject[currentKey] = getOperationDescriptionObject(
        amfType[`${resourceTypePrefix}${resourceType}`],
        selectedResourceType[currentKey]
      );
    }
  }
}

/**
 * Constructs description from template and parameters
 * @param {*} amfTypeParameters available parameters for the description
 * @param {*} resourceTypeOperation the generic templated description
 * @returns Object with description
 */
function getOperationDescriptionObject(
  amfTypeParameters,
  resourceTypeOperation
) {
  let resourceTypeOperationDescription = resourceTypeOperation.description;

  // Check is the description has syntax that needs to be expanded - we do it in naive way
  const descriptionParameter = /<<(.*?)( |\>)/g.exec(
    resourceTypeOperation.description
  );
  if (descriptionParameter && descriptionParameter[1]) {
    let descriptionParameterValue =
      amfTypeParameters[descriptionParameter[1]] ?? "not-found";
    resourceTypeOperationDescription = resourceTypeOperationDescription.replace(
      /<<(.*)\>\>/g,
      descriptionParameterValue
    );
  }

  return {
    description: resourceTypeOperationDescription,
    responses: {},
  };
}
raml2Oas(args[0]);
