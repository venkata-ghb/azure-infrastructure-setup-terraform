# Generate proxy API for CLM 

This tool allows create and deploy Openapi spec and config files based on RAML files provided by Comarch. 

## Description

Purpose of this tool is to create openapi spec and config files based on RAML spec provided by Comarch. 

This project contains two deployment pipelines:
* "API proxy deploy" can deploy one selected proxy API.  
* "API proxy batch deploy" deploy all proxy API.

Config files and openapi are prepared and deployed with Azure DevOps toolkit https://github.com/Azure/azure-api-management-devops-resource-kit. 

## Getting Started

First we need to copy all RAML specs to clm_raml catalog. In clm_raml must be only catalogs which contains valid spec of RAML files. 
All other catalogs should be removed, bacuse scripts builds apis names based on catalogs names.

When the code is pushed we have to run pipeline. First we generate openapi spec then config file which is used by azure-api-management-devops-resource-kit to generate valid ARM templates.
ARM templates are copied to remote storage then deployed.

Below description of files in project:

* node_modules
* arm-templates <- catalog for generated ARM templates  
* clm_output <- place for generated openapi spec and config files
* azure-pipelines.yml <- pipeline for deployment API
* clm_raml <- catalogs ONLY with RAML files
* generate_oas.sh <- bash script which generates openapi spec and config files
* generator.js <- NodeJS script 
* package-lock.json
* package.json
* policy <- place for policy xml files
* templates <- place for api config templates
* azure-pipelines-all-apis.yml <- pipeline for deployment all APIs
### Dependencies

* Installed NodeJS with "webapi-parser": "^0.5.0

### Deploy

* Place all RAML files in clm_raml catalog and remove all catalogs which not contain any RAML spec. It reqired because scripts build api names based on catalog names. Push the code to repository and run pipline.

This project contains two deployment pipelines:
* "API proxy deploy" can deploy one selected proxy API.  
* "API proxy batch deploy" deploy all proxy API.

### Executing program

* How to run the program

```
./generate_oas.sh
```

## Version History

* 0.1
    * Initial Release

Inspiration, code snippets, etc.
* [Azure-devops-resource-kit](https://github.com/Azure/azure-api-management-devops-resource-kit)



