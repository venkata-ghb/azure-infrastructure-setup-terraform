﻿using System.Collections.Generic;
using Microsoft.Azure.Management.ApiManagement.ArmTemplates.Common;

namespace Microsoft.Azure.Management.ApiManagement.ArmTemplates.Create
{
    public class PropertyTemplateCreator : TemplateCreator
    {
        public Template CreatePropertiesTemplate(CreatorConfig creatorConfig)
        {
            // create empty template
            Template propertyTemplate = CreateEmptyTemplate();

            // add parameters
            Dictionary<string, TemplateParameterProperties> parameters = new Dictionary<string, TemplateParameterProperties>();
            
            TemplateParameterProperties apimServiceNameProperty = new TemplateParameterProperties()
            {
                metadata = new TemplateParameterMetadata()
                {
                    description = "Name of the API Management"
                },
                type = "string"
            };
            
            parameters.Add("ApimServiceName",apimServiceNameProperty);
            List<TemplateResource> resources = new List<TemplateResource>();
            foreach(PropertyConfig property in creatorConfig.properties)
            {
                
                TemplateParameterProperties namedProperty = new TemplateParameterProperties()
                {
                    type = property.type
                };
                
                string propertyName = (property != null && property.displayName != null) ? property.displayName : "property";
                parameters.Add(propertyName,namedProperty);
                PropertyTemplateResource propertyTemplateResource = new PropertyTemplateResource()
                {
                    name = $"[concat(parameters('ApimServiceName'), '/{propertyName}')]",
                    type = ResourceTypeConstants.Property,
                    apiVersion = GlobalConstants.APIVersion,
                    properties = new PropertyResourceProperties()
                    {
                        displayName = property.displayName,
                        secret = property.secret,
                        value = $"[parameters('{propertyName}')]"
                    }
                };
                resources.Add(propertyTemplateResource);
            }
            propertyTemplate.parameters = parameters;
            propertyTemplate.resources = resources.ToArray();
            return propertyTemplate;
        }
    }
}
