using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Azure.Management.ApiManagement.ArmTemplates.Common;

namespace Microsoft.Azure.Management.ApiManagement.ArmTemplates.Create
{
    public class ProductGroupsTemplateCreator: TemplateCreator
    {
        private FileReader fileReader;

        public ProductGroupsTemplateCreator(FileReader fileReader)
        {
            this.fileReader = fileReader;
        }

        public ProductGroupsTemplateResource CreateProductGroupsTemplateResource(ProductsTemplateProperties product, ProductGroupTemplateProperties productGroup, string[] dependsOn)
        {
            var productGroupId = $"[concat(parameters('ApimServiceName'), '/{product.name}/{productGroup.name}')]";
            ProductGroupsTemplateResource productGroupsTemplateResource = new ProductGroupsTemplateResource()
            {
                name = productGroupId,
                type = ResourceTypeConstants.ProductGroup,
                apiVersion = GlobalConstants.APIVersion,
                properties = new ProductGroupTemplateProperties()
                {
                    
                },
                dependsOn = dependsOn
            };

            return productGroupsTemplateResource;
        }
    }
}
