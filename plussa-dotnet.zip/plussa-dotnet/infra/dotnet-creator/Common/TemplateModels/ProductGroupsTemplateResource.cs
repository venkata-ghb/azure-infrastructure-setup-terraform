﻿using System.Collections.Generic;
namespace Microsoft.Azure.Management.ApiManagement.ArmTemplates.Common
{
    public class ProductGroupsTemplateResource: APITemplateSubResource
    {
        public ProductGroupTemplateProperties properties { get; set; }
    }

    public class ProductGroupsValue : TemplateResource
    {
        public ProductGroupTemplateProperties properties { get; set; }
    }

    public class ProductGroupTemplateProperties
    {
        public string name { get; set; }
    }
}