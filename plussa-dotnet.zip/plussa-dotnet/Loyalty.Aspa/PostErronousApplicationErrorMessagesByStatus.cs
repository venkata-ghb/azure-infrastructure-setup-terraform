using System;
using System.Net;
using System.Net.Http;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using FluentValidation;
using Loyalty.Common.Examples;
using Loyalty.Common.Functions;
using Loyalty.Common.Services;
using Loyalty.Domain.Contracts.Request;
using Loyalty.Domain.Enums;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;

namespace Loyalty.Aspa;

public class PostErronousApplicationErrorMessagesByStatus : HttpEndpointFunctionWithBody<PostErronousApplicationErrorMessagesByStatus, GetErrorneousApplicationsDetailRequest>
{
    private readonly IApplicationService _service;
    private readonly IValidator<GetErrorneousApplicationsDetailRequest> _validator;

    public PostErronousApplicationErrorMessagesByStatus(
        ILogger<PostErronousApplicationErrorMessagesByStatus> logger,
        IValidator<GetErrorneousApplicationsDetailRequest> validator,
        IApplicationService service
        ) : base(logger, validator)
    {
        _service = service;
        _validator = validator;
    }

    [OpenApiOperation(
        operationId: "get-erronous-application-error-messages-by-status",
        tags: new[] { "aspa" },
        Summary = "Get erronous application error messages by status",
        Description = "Get erronous application error messages by status",
        Visibility = OpenApiVisibilityType.Important
    )]
    [OpenApiRequestBody(
        MediaTypeNames.Application.Json,
        typeof(GetErrorneousApplicationsDetailRequest),
        Example = typeof(ErrorneousApplicationsDetailRequestExample))]
    [OpenApiResponseWithBody(
        statusCode: HttpStatusCode.OK,
        contentType: MediaTypeNames.Application.Json,
        bodyType: typeof(string[]),
        Summary = "Erronous application error messages",
        Description = "Erronous application error messages"
        )]
    [OpenApiResponseWithoutBody(HttpStatusCode.BadRequest, Description = "Bad request")]
    [OpenApiResponseWithoutBody(HttpStatusCode.BadGateway, Description = "Upstream did not respond")]
    [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error")]
    [FunctionName(nameof(PostErronousApplicationErrorMessagesByStatus))]
    public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "erronous-application-error-messages")]
        HttpRequestMessage request,
        CancellationToken token)
    {
        return await HandleHttpRequest(async () =>
        {
            var filters = await ValidateFromBodyAsync(request, token);

            var validationResult = await _validator.ValidateAsync(filters, token);

            if (!validationResult.IsValid)
            {
                return new BadRequestObjectResult(validationResult.ToString());
            }
            var result = await _service.GetErrorMessagesByStatus(
                new[] { filters.Status },
                filters.Types is not null ? filters.Types : Array.Empty<ApplicationTypes>(),
                true,
                token);
            return new OkObjectResult(result);
        });
    }
}