using System.Net;
using System.Net.Http;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using FluentValidation;
using Loyalty.Common.Examples;
using Loyalty.Common.Functions;
using Loyalty.Common.Services;
using Loyalty.Domain.Contracts.Request;
using Loyalty.Domain.Contracts.Responses;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;

namespace Loyalty.Aspa;

public class GetPersonalDetails : HttpEndpointFunctionWithBody<GetPersonalDetails, AspaSearchContract>
{
    private readonly IPersonDetailsService _personService;

    public GetPersonalDetails(
        ILogger<GetPersonalDetails> log,
        IValidator<AspaSearchContract> validator,
        IPersonDetailsService personService) : base(log, validator)
    {
        _personService = personService;
    }

    /// <summary>
    /// Implements fetching personal details based on contact information.
    /// </summary>
    /// <remarks>
    /// Authorization level is anonymous. Authentication needs to be handled by a gateway (API Management). Access from public internet should not be allowed.
    /// </remarks>
    /// <param name="request"></param>
    /// <param name="token"></param>
    /// <returns>Personal details contract constructed from upstream data sources.</returns>
    [OpenApiOperation(
        operationId: "post-get-person-details",
        tags: new[] { "aspa" },
        Summary = "Find person",
        Description = "Search for person based on their card number, phone number or email address or one of the ids.",
        Visibility = OpenApiVisibilityType.Important
    )]
    [OpenApiRequestBody(
        MediaTypeNames.Application.Json, 
        typeof(AspaSearchContract),
        Example = typeof(AspaSearchContractExample))]
    [OpenApiResponseWithBody(
        statusCode: HttpStatusCode.OK,
        contentType: MediaTypeNames.Application.Json,
        bodyType: typeof(PersonDetailsForAspa),
        Summary = "personal details, cards and other household members.",
        Description = "personal details, cards and other household members.",
        Example = typeof(PersonDetailsExample))]
    [OpenApiResponseWithoutBody(HttpStatusCode.BadRequest, Description = "Bad request")]
    [OpenApiResponseWithoutBody(HttpStatusCode.NotFound, Description = "Person details not found")]
    [OpenApiResponseWithoutBody(HttpStatusCode.BadGateway, Description = "Upstream did not respond")]
    [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error")]
    [FunctionName(nameof(GetPersonalDetails))]
    public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "person-details")]
        HttpRequestMessage request,
        CancellationToken token)
    {
        return await HandleHttpRequest(async () =>
        {
            var searchContract = await ValidateFromBodyAsync(request, token);
            var personDetails = await _personService.GetByContactInformation(searchContract, token);
            return new OkObjectResult(personDetails);
        });
    }
}