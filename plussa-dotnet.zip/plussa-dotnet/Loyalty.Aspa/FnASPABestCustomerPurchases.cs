using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using Azure.Core;
using FluentValidation;
using Loyalty.Common.Builders;
using Loyalty.Common.DTOs;
using Loyalty.Common.Examples;
using Loyalty.Common.Extensions;
using Loyalty.Common.Functions;
using Loyalty.Common.Models.Calculator.Calculator.Tranactions;
using Loyalty.Common.Services;
using Loyalty.Domain.Contracts.Request;
using Loyalty.Domain.Contracts.Responses;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using YamlDotNet.Core.Tokens;

namespace Loyalty.Aspa
{
    public class FnASPABestCustomerPurchases : HttpEndpointFunctionWithBody<FnASPABestCustomerPurchases, ASPABestCustomerPurchaseRequest>
    {
        private readonly ISummaryRepository _repository;

        public FnASPABestCustomerPurchases(ISummaryRepository repository,
            ILogger<FnASPABestCustomerPurchases> log,
            IValidator<ASPABestCustomerPurchaseRequest> validator) : base(log, validator)
        {
            _repository = repository;
        }

        [OpenApiOperation(
            operationId: "get-aspa-best-customer-purchases",
            tags: new[] { "loyalty", "aspa" },
            Summary = "ASPA Best Customer Purchases",
            Description = "Get Best Customer Purchases for ASPA")
        ]
        [FunctionName("FnASPABestCustomerPurchases")]
        [OpenApiRequestBody(MediaTypeNames.Application.Json,
            typeof(ASPABestCustomerPurchaseRequest),
            Example = typeof(ASPABestCustomerPurchaseRequest),
            Description = "ASPA Best Customer Request Body")]
        [OpenApiParameter(name: "startDate", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "starting date from which purchases are to be fetched. Pattern is yyyy-MM-dd")]
        [OpenApiParameter(name: "endDate", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "end date till which purchases are to be fetched. Pattern is yyyy-MM-dd")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(string), Description = "The OK response")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.BadRequest, contentType: "application/json", bodyType: typeof(string), Description = "Bad request")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.Unauthorized, contentType: "application/json", bodyType: typeof(string), Description = "Unauthorized")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.NotFound, contentType: "application/json", bodyType: typeof(string), Description = "Account not found")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.InternalServerError, contentType: "application/json", bodyType: typeof(string), Description = "Internal error occured")]
        public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "best-customer-purchases")] HttpRequestMessage request,
        CancellationToken cancellationToken)
        {
            var queryParams = HttpUtility.ParseQueryString(request.RequestUri.Query);
            string startDateString = queryParams["startDate"];
            if (!DateTime.TryParse(startDateString, out var startDate))
            {
                return new BadRequestObjectResult("Invalid startDate");
            }

            string endDateString = queryParams["endDate"];
            if (!DateTime.TryParse(endDateString, out var endDate))
            {
                return new BadRequestObjectResult("Invalid endDate");
            }

            var dto = await ValidateFromBodyAsync(request, cancellationToken);

            return await HandleHttpRequest(async () =>
            {
                var (summary, _, _, _) = await _repository.FetchSummary<TransactionSummary>(dto.HouseholdId, cancellationToken);
                if (summary == null) return new OkObjectResult(BestCustomerPurchasesResponse.Empty(startDate, endDate));

                var response = BestCustomerPurchasesResponseBuilder.Build(summary, startDate, endDate);
                return new OkObjectResult(response);
            });
        }
    }
}

