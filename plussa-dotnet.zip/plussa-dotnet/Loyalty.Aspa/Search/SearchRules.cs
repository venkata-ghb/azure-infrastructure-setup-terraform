﻿using System.Collections.Generic;

namespace Loyalty.Aspa.Search;

public class SearchRules<TRule>
{
    public List<TRule> Rules { get; private set; } = new List<TRule>();

    public SearchRules<TRule> AddRule(TRule rule, bool condition = true)
    {
        if (!condition) return this;
        
        Rules.Add(rule);
        return this;
    }
}