﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Loyalty.Aspa.Search;

public static class SearchExtensions {
    public static List<TFrom> SearchFromAsync<TFrom, TRule>(this SearchRules<TRule> rules, Func<TRule, Task<List<TFrom>>> searchByRule)
    {
        //If first rule returns the result, we dont want next rule to get executed. Therefore we are using task.result to block further executions. 
        return rules.Rules
            .Select(rule => searchByRule(rule))
            .Select(task => task.Result)
            .FirstOrDefault(matchingResult => matchingResult.Count > 0);
        
    }
    
    public static List<TFrom> SearchFrom<TFrom, TRule>(this SearchRules<TRule> rules, Func<TRule, List<TFrom>> searchByRule)
    {
        return rules.Rules
            .Select(rule => searchByRule(rule))
            .FirstOrDefault(matchingResult => matchingResult.Count > 0);
        
    }
}