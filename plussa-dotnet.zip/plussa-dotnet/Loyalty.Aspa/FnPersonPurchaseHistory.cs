using Loyalty.Common.Builders;
using Loyalty.Common.Extensions;
using Loyalty.Common.Factories;
using Loyalty.Common.Functions;
using Loyalty.Common.Services;
using Loyalty.Domain.Entities.Clm;
using Loyalty.Domain.Entities.CosmosCLM;
using Loyalty.Domain.Enums;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using System;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Loyalty.Aspa;

public class FnPersonPurchaseHistory : HttpEndpointFunctionWithoutBody<FnPersonPurchaseHistory>
{
    private readonly IReceiptRepository _repository;
    private readonly ICustomerService _customerDbService;

    public FnPersonPurchaseHistory(
        ILogger<FnPersonPurchaseHistory> logger,
        IReceiptRepository repository,
        IServiceDependencyResolverFactory dependencyResolverFactory) : base(logger)
    {
        _repository = repository;
        _customerDbService = (ICustomerService)dependencyResolverFactory.GetInstance(ServiceType.CustomerServiceDB);
    }

    [OpenApiOperation(
        operationId: "get-person-summary-aspa",
        Summary = "Get person summary",
        Description = "Get person summary")
    ]
    [FunctionName(nameof(FnPersonPurchaseHistory))]
    [OpenApiParameter(name: "personId", In = ParameterLocation.Path, Required = true, Type = typeof(int), Description = "Person Id")]
    [OpenApiParameter(name: "firstDate", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Start month (yyyy-mm-dd)")]
    [OpenApiParameter(name: "lastDate", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "End month (yyyy-mm-dd)")]
    [OpenApiResponseWithoutBody(HttpStatusCode.OK, Description = "Successfully fetched person point balance")]
    [OpenApiResponseWithoutBody(HttpStatusCode.BadGateway, Description = "Error communicating with upstream services.")]
    [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Application or configuration error in the API.")]
    public async Task<IActionResult> GetPoints(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "persons/{personId}/purchases")]
        HttpRequest request,
        int personId,
        CancellationToken cancellationToken)
    {
        if (!request.Query["firstDate"].ParseDate(DateTime.Today.AddMonths(-12), out var startDate))
        {
            return new BadRequestObjectResult("Invalid startDate");
        }
        if (!request.Query["lastDate"].ParseDate(DateTime.Now.AddDays(1), out var endDate))
        {
            return new BadRequestObjectResult("Invalid endDate");
        }

        return await HandleHttpRequest(async () =>
        {
            var customer = await _customerDbService.GetCustomer(personId, cancellationToken);
            var receipts = await _repository.FetchReceipts(customer.Id.ToString(), customer.AccountId.ToString(), startDate, endDate,
                cancellationToken);

            var response = PurchaseHistoryResponseBuilderForAspa.Build(receipts, startDate, endDate);
            return new OkObjectResult(response);
        });
    }
}