using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using FluentValidation;
using Loyalty.Common.Constants.Applications;
using Loyalty.Common.Examples;
using Loyalty.Common.Functions;
using Loyalty.Common.Services;
using Loyalty.Domain.Contracts.Request;
using Loyalty.Domain.Entities.Cosmos;
using Loyalty.Domain.Enums;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json.Linq;

namespace Loyalty.Aspa;

public class PutUpdateApplication : HttpEndpointFunctionWithBody<PutUpdateApplication, UpdateApplicationRequest>
{
    private readonly ILogger<PutUpdateApplication> _log;
    private readonly IApplicationService _applicationService;

    public PutUpdateApplication(
        ILogger<PutUpdateApplication> log,
        IValidator<UpdateApplicationRequest> validator,
        IApplicationService applicationService) : base(log, validator)
    {
        _log = log;
        _applicationService = applicationService;
    }

    /// <summary>
    /// Small errors can be fixed in application to help customer with enrollment process
    /// </summary>
    /// <remarks>
    /// Authorization level is anonymous. Authentication needs to be handled by a gateway (API Management). Access from public internet should not be allowed.
    /// </remarks>
    /// <param name="request"></param>
    /// <param name="applicationId"></param>
    /// <param name="token"></param>
    /// <returns>Personal details contract constructed from upstream data sources.</returns>
    [OpenApiOperation(
        operationId: "put-update-application",
        tags: new[] { "loyalty", "aspa" },
        Summary = "Update erroneous application",
        Description = "Small errors can be fixed in application to help customer with enrollment process",
        Visibility = OpenApiVisibilityType.Important
    )]

    [OpenApiRequestBody(
        MediaTypeNames.Application.Json, 
        typeof(UpdateApplicationRequest),
        Example = typeof(UpdateApplicationRequestExample))]
    [OpenApiParameter(name: "applicationId", In = ParameterLocation.Path, Required = true, Type = typeof(string), Description = "Application Id")]
    [OpenApiResponseWithoutBody(statusCode: HttpStatusCode.OK, Description = "Application updated successfully")]
    [OpenApiResponseWithoutBody(HttpStatusCode.BadRequest, Description = "Invalid update request")]
    [OpenApiResponseWithoutBody(HttpStatusCode.NotFound, Description = "Application not found")]
    [OpenApiResponseWithoutBody(HttpStatusCode.Conflict, Description = "Application not in ERROR state")]
    [OpenApiResponseWithoutBody(HttpStatusCode.BadGateway, Description = "Upstream did not respond")]
    [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error")]
    [FunctionName(nameof(PutUpdateApplication))]
    public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "put", Route = "applications/{applicationId}")]
        HttpRequestMessage request,
        string applicationId,
        CancellationToken token)
    {
        return await HandleHttpRequest(async () =>
        {
            var updates = await ValidateFromBodyAsync(request, token);
            JObject originalApplication = await _applicationService.GetApplicationByIdAsync<dynamic>(applicationId, token);
            var applicationStatus = originalApplication[ApplicationFields.ApplicationStatus]?.ToObject<ApplicationStatuses>();
            if (applicationStatus != ApplicationStatuses.ERROR)
            {
                return new ConflictObjectResult("Application not in ERROR state");
            }
            var originalValues = originalApplication.ToObject<UpdateApplicationRequest>();
            var changeLogging = originalApplication[ApplicationFields.ChangeLogging]?.ToObject<List<ApplicationChangeLogging>>() 
                                ?? new List<ApplicationChangeLogging>();
            await _applicationService.PartialUpdateApplication(applicationId, 
                updates, 
                originalValues, 
                changeLogging, 
                updates.UserName,
                excludeFields: new [] { ApplicationFields.Username },
                token);
            _log.LogInformation("Application partially updated (application id: {applicationId}", applicationId);
            return new NoContentResult();
        });
    }
    
}
