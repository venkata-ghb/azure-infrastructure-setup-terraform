﻿using System.IO;
using FluentValidation;
using Loyalty.Common.Configuration;
using Loyalty.Common.Extensions;
using Loyalty.Common.Extensions.Telemetry;
using Loyalty.Common.Factories;
using Loyalty.Common.Helpers;
using Loyalty.Common.Models;
using Loyalty.Common.Services;
using Loyalty.Common.Validators;
using Loyalty.Domain.Enums;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

[assembly: FunctionsStartup(typeof(Loyalty.Aspa.Startup))]
namespace Loyalty.Aspa;

public class Startup : FunctionsStartup
{
    public override void Configure(IFunctionsHostBuilder builder)
    {
        builder.Services.AddCosmos();
        builder.Services.ConfigureSerialization();
        builder.Services.AddClmCoreServices();
        builder.Services.ConfigureTelemetryProcessor();
        builder.Services.AddApplicationServices();
        builder.Services.AddEmail();
        builder.Services.AddTierLevels();
        MapsterExtension.RegisterMapsterConfiguration();
        builder.Services.AddEmail();

        builder.Services.AddValidatorsFromAssemblyContaining<AspaSearchContractValidator>();
        builder.Services.AddValidatorsFromAssemblyContaining<AspaBestCustomerRequestValidator>();
        builder.Services.AddCardServices();
        builder.Services.AddScoped<IPersonDetailsService, PersonDetailsService>();
        builder.Services.AddScoped<ISearchService, SearchService>();
        builder.Services.AddScoped<ICustomerService, CustomerService>();
        builder.Services.AddScoped<IApplicationService, ApplicationService>();
        builder.Services.AddScoped<IApplicationEnrollmentService, ApplicationEnrollmentService>();
        builder.Services.AddScoped<ISendEmailService, SendEmailService>();
        builder.Services.AddScoped<IBarcodeGeneratorService, BarcodeGeneratorService>();
        builder.Services.AddScoped<ApplicationEnrollmentFactory>();
        builder.Services.AddScoped<ISponsorshipService, SponsorshipService>();
        builder.Services.AddScoped<IIdentityService, IdentityService>();
        builder.Services.AddScoped<IAccountService, AccountService>();
        builder.Services.AddScoped<ILoyaltyPointsRepository, LoyaltyPointsRepository>();
        builder.Services.AddScoped<ISummaryRepository, SummaryRepository>();
        builder.Services.AddScoped<IReceiptRepository, ReceiptRepository>();
        builder.Services.AddScoped<ProgressivePointsManager>();
        builder.Services.AddScoped<IPersonPropertiesService, PersonPropertiesService>();
        builder.Services.AddScoped<ILoyaltyCardComparer, LoyaltyCardComparer>();
        builder.Services.AddScoped<ILoggingService, LoggingService>();
        builder.Services.AddScoped<ICustomerAttributeService, CustomerAttributeService>();
        builder.Services.AddMultiSourceServices(new ServiceType[] { ServiceType.CustomerService, ServiceType.CustomerServiceDB,
            ServiceType.AssignmentService, ServiceType.AssignmentServiceDB,
            ServiceType.SearchService, ServiceType.SearchServiceDB,
            ServiceType.CardService, ServiceType.CardServiceDB
        });

        builder.Services.AddScoped<ICustomerAttributeService, CustomerAttributeService>();
        builder.Services.AddOptions<PurchaseHistoryConfiguration>()
            .Configure<IConfiguration>((settings, configuration) =>
            {
                configuration.Bind(settings);
            });

        MapsterExtension.RegisterMapsterConfiguration();

    }

    public override void ConfigureAppConfiguration(IFunctionsConfigurationBuilder builder)
    {
        var context = builder.GetContext();
        builder.ConfigurationBuilder
            .AddJsonFile(Path.Combine(context.ApplicationRootPath, "local.settings.json"), optional: true, reloadOnChange: false)
            .AddEnvironmentVariables();
    }
}
