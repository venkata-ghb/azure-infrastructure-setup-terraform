using FluentValidation;
using Loyalty.Common.Examples;
using Loyalty.Common.Functions;
using Loyalty.Common.Services;
using Loyalty.Domain.Contracts.Request;
using Loyalty.Domain.Entities.Cosmos;
using Loyalty.Domain.Enums;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;
using System;
using System.Net;
using System.Net.Http;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;

namespace Loyalty.Aspa;

public class GetErrorneousApplicationsCount : HttpEndpointFunctionWithBody<GetErrorneousApplicationsCount, GetErrorneousApplicationsDetailRequest>
{
    private readonly IValidator<GetErrorneousApplicationsDetailRequest> _validator;
    private readonly IApplicationService _service;

    public GetErrorneousApplicationsCount(
        ILogger<GetErrorneousApplicationsCount> log,
        IValidator<GetErrorneousApplicationsDetailRequest> validator,
        IApplicationService service) : base(log, validator)
    {
        _validator = validator;
        _service = service;
    }

    /// <summary>
    /// Customer service rep can search for errorneous applications so end users can be helped with enrollment problems
    /// </summary>
    /// <param name="request"></param>
    /// <param name="token"></param>
    /// <returns></returns>
    [OpenApiOperation(
        operationId: "get-erroneous-applications-count",
        tags: new[] { "loyalty", "aspa" },
        Summary = "Search erroneous applications count by status",
        Description = "Customer service rep can search for erroneous applications count by status whether pending/errors",
        Visibility = OpenApiVisibilityType.Important
    )]
    [OpenApiRequestBody(
        MediaTypeNames.Application.Json,
        typeof(GetErrorneousApplicationsDetailRequest),
        Example = typeof(ErrorneousApplicationsDetailRequestExample))]
    [OpenApiResponseWithBody(
        statusCode: HttpStatusCode.OK,
        contentType: MediaTypeNames.Application.Json,
        bodyType: typeof(ErrorneousApplicationsCount),
        Summary = "The response",
        Description = "This returns the response",
        Example = typeof(ErrorneousApplicationsCount)
    )]
    [OpenApiResponseWithoutBody(HttpStatusCode.BadRequest, Description = "Bad request")]
    [OpenApiResponseWithoutBody(HttpStatusCode.BadGateway, Description = "Upstream did not respond")]
    [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error")]
    [FunctionName(nameof(GetErrorneousApplicationsCount))]
    public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "erroneous-applications-count")]
        HttpRequestMessage request,
        CancellationToken token)
    {
        return await HandleHttpRequest(async () =>
        {
            var filters = await ValidateFromBodyAsync(request, token);

            var validationResult = await _validator.ValidateAsync(filters, token);

            if (!validationResult.IsValid)
            {
                return new BadRequestObjectResult(validationResult.ToString());
            }

            var result = await _service.GetErroneousApplicationsCount(new[] { filters.Status },
                filters.Types is not null ? filters.Types : Array.Empty<ApplicationTypes>(),
                true,
                token);

            return new OkObjectResult(result);
        });
    }
}


