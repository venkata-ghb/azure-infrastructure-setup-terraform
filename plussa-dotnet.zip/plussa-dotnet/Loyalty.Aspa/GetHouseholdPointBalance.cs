using Loyalty.Common.Builders;
using Loyalty.Common.Functions;
using Loyalty.Common.Models;
using Loyalty.Common.Models.Calculator.Calculator.Points;
using Loyalty.Common.Models.Calculator.Calculator.Tranactions;
using Loyalty.Common.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using System;
using System.Globalization;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Loyalty.Aspa;

public class GetHouseholdPointBalance : HttpEndpointFunctionWithoutBody<GetHouseholdPointBalance>
{
    private readonly ILoyaltyPointsRepository _loyaltyPointsService;
    private readonly ISummaryRepository _summaryRepository;
    private readonly ProgressivePointsManager _progressivePointsManager;
    private readonly IAccountService _accountService;

    public GetHouseholdPointBalance(
        ILogger<GetHouseholdPointBalance> logger,
        ILoyaltyPointsRepository loyaltyPointsService,
        ISummaryRepository summaryRepository,
        ProgressivePointsManager progressivePointsManager,
        IAccountService accountService) : base(logger)
    {
        _loyaltyPointsService = loyaltyPointsService;
        _summaryRepository = summaryRepository;
        _progressivePointsManager = progressivePointsManager;
        _accountService = accountService;
    }

    [OpenApiOperation(
        operationId: "get-household-loyalty-pointbalance-aspa",
        Summary = "Get household point balance",
        Description = "Get household point balance.")
    ]
    [FunctionName(nameof(GetHouseholdPointBalance))]
    [OpenApiParameter(name: "accountId", In = ParameterLocation.Path, Required = true, Type = typeof(int), Description = "AccountId")]
    [OpenApiParameter(name: "firstDate", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Start month (yyyy-mm-dd)")]
    [OpenApiParameter(name: "lastDate", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "End month (yyyy-mm-dd)")]
    [OpenApiResponseWithoutBody(HttpStatusCode.OK, Description = "Successfully fetched household point balance")]
    [OpenApiResponseWithoutBody(HttpStatusCode.BadGateway, Description = "Error communicating with upstream services.")]
    [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Application or configuration error in the API.")]
    public async Task<IActionResult> GetPoints(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "households/{accountId}/point-balance")]
        HttpRequest req,
        int accountId,
        CancellationToken ct)
    {
        return await HandleHttpRequest(async () =>
        {
            DateTime.TryParseExact(req.Query["firstDate"], "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var firstDate);
            DateTime.TryParseExact(req.Query["lastDate"], "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var lastDate);
            var pointsTask = _loyaltyPointsService.GetHouseholdPoints(PointSummary.CreateId(accountId.ToString()), accountId.ToString(), ct);
            var currentMonthPointsTask = _accountService.GetHouseholdPointsBalance(accountId, ct);
            var transactionTask = _summaryRepository.FetchSummary<TransactionSummary>(accountId.ToString(), ct);
            var progressivePointsTask = _loyaltyPointsService.GetHouseholdProgressivePoints(accountId.ToString(), ct);
            var progressivePointTable = _progressivePointsManager.GetPoints();
            await Task.WhenAll(pointsTask, transactionTask, progressivePointsTask, currentMonthPointsTask);
            // we are not returning loyaltymoneybalance for ASPA UI, so skipping last parameter to below method
            var response = HouseholdLoyaltyPointsBuilder.Build(
                accountId.ToString(),
                pointsTask.Result,
                transactionTask.Result.summary,
                progressivePointTable.Result,
                progressivePointsTask.Result,
                currentMonthPointsTask.Result,
                firstDate,
                lastDate);
            return new OkObjectResult(response);
        });
    }
}