using System.Net;
using System.Net.Http;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using FluentValidation;
using Loyalty.Common.Functions;
using Loyalty.Common.Services;
using Loyalty.Domain.Contracts.Request;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;

namespace Loyalty.Aspa;

public class PutAddApplicationNote : HttpEndpointFunctionWithBody<PutAddApplicationNote, PutAddApplicationNoteRequest>
{
    private readonly ILogger<PutAddApplicationNote> _log;
    private readonly IApplicationService _applicationService;

    public PutAddApplicationNote(
        ILogger<PutAddApplicationNote> log,
        IValidator<PutAddApplicationNoteRequest> validator,
        IApplicationService service) : base(log, validator)
    {
        _log = log;
        _applicationService = service;
    }

    /// <summary>
    /// Notes can be added to an applications so that customer service reps can collaborate with other customer service reps
    /// </summary>
    /// <remarks>
    /// Authorization level is anonymous. Authentication needs to be handled by a gateway (API Management). Access from public internet should not be allowed.
    /// </remarks>
    /// <param name="request"></param>
    /// <param name="id"></param>
    /// <param name="token"></param>
    [OpenApiOperation(
        operationId: "put-add-application-note",
        tags: new[] { "loyalty", "aspa" },
        Summary = "Add an application note",
        Description = "Customer service reps can collaborate with other customer service reps by adding a notes to application",
        Visibility = OpenApiVisibilityType.Important
    )]
    [OpenApiParameter(name: "id", In = ParameterLocation.Path, Required = true, Type = typeof(string), Description = "Application Id")]
    [OpenApiRequestBody(MediaTypeNames.Application.Json, typeof(PutAddApplicationNoteRequest))]
    [OpenApiResponseWithoutBody(HttpStatusCode.NoContent, Description = "Application note added successfully")]
    [OpenApiResponseWithoutBody(HttpStatusCode.BadRequest, Description = "Invalid application note request")]
    [OpenApiResponseWithoutBody(HttpStatusCode.NotFound, Description = "Application not found")]
    [OpenApiResponseWithoutBody(HttpStatusCode.BadGateway, Description = "Upstream did not respond")]
    [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error")]
    [FunctionName(nameof(PutAddApplicationNote))]
    public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "Put", Route = "applications/{id}/note")]
        HttpRequestMessage request,
        string id,
        CancellationToken token)
    {
        return await HandleHttpRequest(async () =>
        {
            var dto = await ValidateFromBodyAsync(request, token);
            await _applicationService.UpdateApplicationNotes(id, dto.Note, token);
            _log.LogInformation("Application note updated (application id: {ApplicationId}", id);
            
            return new NoContentResult();
        });
    }
}
