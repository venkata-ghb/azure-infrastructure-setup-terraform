using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using FluentValidation;
using Loyalty.Common.Configuration;
using Loyalty.Common.Constants.Applications;
using Loyalty.Common.Functions;
using Loyalty.Common.Services;
using Loyalty.Domain.Contracts.Request;
using Loyalty.Domain.Entities.Cosmos;
using Loyalty.Domain.Enums;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Models;

namespace Loyalty.Aspa;

public class PutApplicationStatus : HttpEndpointFunctionWithBody<PutApplicationStatus, PutSetApplicationState>
{
    private readonly ILogger<PutApplicationStatus> _log;
    private readonly IApplicationService _applicationService;
    private readonly ApplicationConfiguration _options;

    public PutApplicationStatus(
        ILogger<PutApplicationStatus> log,
        IValidator<PutSetApplicationState> validator,
        IApplicationService service,
        IOptions<ApplicationConfiguration> options) : base(log, validator)
    {
        _log = log;
        _applicationService = service;
        _options = options.Value;
    }

    /// <summary>
    /// Customer service rep can set application status to pending
    /// </summary>
    /// <remarks>
    /// Authorization level is anonymous. Authentication needs to be handled by a gateway (API Management). Access from public internet should not be allowed.
    /// </remarks>
    /// <param name="request"></param>
    /// <param name="applicationId"></param>
    /// <param name="token"></param>
    [OpenApiOperation(
        operationId: "put-application-status",
        tags: new[] { "loyalty", "aspa" },
        Summary = "Set application status",
        Description = "Customer service can set application status to success/pending",
        Visibility = OpenApiVisibilityType.Important
    )]
    [OpenApiParameter(name: "applicationId", In = ParameterLocation.Path, Required = true, Type = typeof(string), Description = "Application Id")]
    [OpenApiRequestBody(MediaTypeNames.Application.Json, typeof(PutSetApplicationState))]
    [OpenApiResponseWithoutBody(HttpStatusCode.NoContent, Description = "Application set to application status successfully")]
    [OpenApiResponseWithoutBody(HttpStatusCode.NotFound, Description = "Application not found")]
    [OpenApiResponseWithoutBody(HttpStatusCode.Conflict, Description = "Application not in error state")]
    [OpenApiResponseWithoutBody(HttpStatusCode.BadGateway, Description = "Upstream did not respond")]
    [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error")]
    [FunctionName(nameof(PutApplicationStatus))]
    public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "put", Route = "applications/{applicationId}/applicationStatus")]
        HttpRequestMessage request,
        string applicationId,
        CancellationToken token)
    {
        return await HandleHttpRequest(async () =>
        {
            var dto = await ValidateFromBodyAsync(request, token);
            var application = await _applicationService.GetApplicationByIdAsync<GenericApplication>(applicationId, token);

            if (application.ApplicationStatus == ApplicationStatuses.PENDING && dto.ApplicationStatus == AspaApplicationStatuses.Pending)
            {
                return new NoContentResult();
            }
            else if (application.ApplicationStatus == ApplicationStatuses.SUCCESS && dto.ApplicationStatus == AspaApplicationStatuses.Success)
            {
                return new NoContentResult();
            }
            else if (application.ApplicationStatus != ApplicationStatuses.ERROR && application.ApplicationStatus != ApplicationStatuses.PENDING)
            {
                return new ConflictResult();
            }

            var updatedApplication = application with
            {
                ApplicationStatus = dto.ApplicationStatus == AspaApplicationStatuses.Pending ? ApplicationStatuses.PENDING : ApplicationStatuses.SUCCESS,
                Ttl = (int)TimeSpan.FromDays(dto.ApplicationStatus == AspaApplicationStatuses.Pending ? _options.RemovePendingAfterDays : _options.RemoveSuccessAfterDays).TotalSeconds
            };

            var changeLogging = application.ChangeLogging.ToList();
            await _applicationService.PartialUpdateApplication(applicationId,
                updatedApplication,
                application,
                changeLogging,
                dto.UserName,
                excludeFields: new[] { ApplicationFields.Username, ApplicationFields.Notes, ApplicationFields.ChangeLogging },
                token);

            _log.LogInformation("Application status set to {status} (application id: {ApplicationId}", dto.ApplicationStatus, applicationId);
            return new NoContentResult();
        });
    }
}
