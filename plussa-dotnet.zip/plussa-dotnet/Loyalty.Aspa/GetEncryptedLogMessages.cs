using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using FluentValidation;
using Loyalty.Common.Converters;
using Loyalty.Common.Examples;
using Loyalty.Common.Extensions;
using Loyalty.Common.Functions;
using Loyalty.Common.Services;
using Loyalty.Domain.Contracts.Request;
using Loyalty.Domain.Contracts.Responses;
using Mapster;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;

namespace Loyalty.Aspa;

public class GetEncryptedLogMessages : HttpEndpointFunctionWithoutBody<GetEncryptedLogMessages>
{
    private readonly ILoggingService _loggingService;

    public GetEncryptedLogMessages(
        ILogger<GetEncryptedLogMessages> log,
        ILoggingService loggingService) : base(log)
    {
        _loggingService = loggingService;
    }

    /// <summary>
    /// Get logging API response for identifiers-loyalty-check operations
    /// </summary>
    /// <remarks>
    /// </remarks>
    /// <param name="request"></param>
    /// <returns>Get logging API response for identifiers-loyalty-check operations</returns>
    [OpenApiOperation(
        operationId: "get-encrypted-logged-messages",
        tags: new[] { "aspa" },
        Summary = "Get logging API response for identifiers-loyalty-check operations",
        Description = "Get logging API response for identifiers-loyalty-check operations",
        Visibility = OpenApiVisibilityType.Important
    )]
    [OpenApiResponseWithBody(
        statusCode: HttpStatusCode.OK,
        contentType: MediaTypeNames.Application.Json,
        bodyType: typeof(List<EncryptedLoggingResponse>),
        Summary = "Encrypted logging information.",
        Description = "Encrypted logging information.",
        Example = typeof(EncryptedLoggingResponseExample))]
    [OpenApiParameter(name: "startDate", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "From date (yyyy-MM-dd)")]
    [OpenApiParameter(name: "endDate", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Till date (yyyy-MM-dd)")]
    [OpenApiParameter(name: "kid", In = ParameterLocation.Path, Required = true, Type = typeof(string), Description = "User K-ID")]
    [OpenApiParameter(name: "operationName", In = ParameterLocation.Path, Required = true, Type = typeof(string), Description = "Name of operation")]
    [OpenApiResponseWithoutBody(HttpStatusCode.BadRequest, Description = "Bad request")]
    [OpenApiResponseWithoutBody(HttpStatusCode.BadGateway, Description = "Upstream did not respond")]
    [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error")]
    [FunctionName(nameof(GetEncryptedLogMessages))]
    public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "log-information/{kid}/{operationName}")]
        HttpRequest request,
        string kid,
        string operationName,
        CancellationToken token)
    {
        return await HandleHttpRequest(async () =>
        {
            var defaultStartDate = DateTime.Today.AddDays(-540);
            defaultStartDate = new DateTime(defaultStartDate.Year, defaultStartDate.Month, 1);

            if (!request.Query["startDate"].ParseDate(defaultStartDate, out var startDate))
            {
                return new BadRequestObjectResult("Invalid startDate");
            }
            if (!request.Query["endDate"].ParseDate(DateTime.Now.AddDays(1), out var endDate))
            {
                return new BadRequestObjectResult("Invalid endDate");
            }
            var loggedMessages = await _loggingService.GetLoggedMessages(kid, operationName, startDate, endDate, token);
            var response = loggedMessages
                .Select(item => item.Adapt<EncryptedLoggingResponse>() with
                {
                    EncryptedRequest = item.Request,
                    EncryptedResponse = item.Response,
                    Id = item.Id.ToString(),
                    TimeStamp = UTCToEETDateTimeConverter.ConvertToEET($"{item.OperationDateUTC}T{item.OperationTimeUTC}").ToString("yyyy-MM-ddTHH:mm:ss")
                })
                .OrderByDescending(item => DateTime.Parse(item.TimeStamp))
                .ToList();

            return new OkObjectResult(response);
        });
    }
}