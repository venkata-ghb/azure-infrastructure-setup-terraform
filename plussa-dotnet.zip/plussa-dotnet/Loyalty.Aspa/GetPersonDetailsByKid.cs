using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using Loyalty.Common.Examples;
using Loyalty.Common.Functions;
using Loyalty.Common.Helpers;
using Loyalty.Common.Services;
using Loyalty.Domain.Contracts.Request;
using Loyalty.Domain.Contracts.Responses;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;

namespace Loyalty.Aspa;

public class GetPersonDetailsByKid : HttpEndpointFunctionWithoutBody<GetPersonDetailsByKid>
{
    private readonly IPersonDetailsService _personService;
    private readonly IIdentityService _identityService;
    private readonly ILoyaltyCardComparer _loyaltyCardComparer;

    /// <summary>
    /// Implements fetching personal details based on kid user id.
    /// </summary>
    public GetPersonDetailsByKid(
        ILogger<GetPersonDetailsByKid> logger,
        IPersonDetailsService personService,
        IIdentityService identityService,
        ILoyaltyCardComparer loyaltyCardComparer) : base(logger)
    {
        _personService = personService;
        _identityService = identityService;
        _loyaltyCardComparer = loyaltyCardComparer;
    }

    [OpenApiOperation(
        operationId: "get-person-details-by-kid",
        tags: new[] { "aspa" },
        Summary = "Get person by kid",
        Description = "Fetch person based on their kid user id.",
        Visibility = OpenApiVisibilityType.Important
    )]
    [OpenApiResponseWithBody(
        statusCode: HttpStatusCode.OK,
        contentType: MediaTypeNames.Application.Json,
        bodyType: typeof(PersonDetailsForAspa),
        Summary = "personal details, cards and other household members.",
        Description = "personal details, cards and other household members.",
        Example = typeof(PersonDetailsExample))]
    [OpenApiParameter(name: "kid", In = ParameterLocation.Path, Required = true, Type = typeof(string), Description = "Kid user id")]
    [OpenApiResponseWithoutBody(HttpStatusCode.BadRequest, Description = "Bad request")]
    [OpenApiResponseWithoutBody(HttpStatusCode.NotFound, Description = "Person details not found")]
    [OpenApiResponseWithoutBody(HttpStatusCode.BadGateway, Description = "Upstream did not respond")]
    [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error")]
    [FunctionName(nameof(GetPersonDetailsByKid))]
    public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "person-details/{kid}")]
        HttpRequestMessage request,
        string kid,
        CancellationToken token)
    {
        return await HandleHttpRequest(async () =>
        {
            var kidIdentity = await _identityService.GetIdentity(kid, token);

            var searchContract = new AspaSearchContract
            {
                PersonId = kidIdentity.PersonId
            };

            var personDetails = await _personService.GetByContactInformation(searchContract, token);
            Array.Sort(personDetails.LoyaltyCards, _loyaltyCardComparer);
            return new OkObjectResult(personDetails);
        });
    }
}