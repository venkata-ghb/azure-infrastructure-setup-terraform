using Loyalty.Common.Builders;
using Loyalty.Common.Configuration;
using Loyalty.Common.Enrichers;
using Loyalty.Common.Extensions;
using Loyalty.Common.Functions;
using Loyalty.Common.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Models;
using System;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Loyalty.Aspa;

public class FnHouseholdPurchaseHistory : HttpEndpointFunctionWithoutBody<FnHouseholdPurchaseHistory>
{
    private readonly IReceiptRepository _repository;
    private readonly string[] _kruokaChains;
    public FnHouseholdPurchaseHistory(
        ILogger<FnHouseholdPurchaseHistory> logger,
        IReceiptRepository repository,
        IOptions<PurchaseHistoryConfiguration> configurations) : base(logger)
    {
        _repository = repository;
        _kruokaChains = new ChainConfigurationManager(configurations.Value?.PurchaseHistory == null ?
            new PurchaseHistoryConfiguration.Configurations().KRuokaChains : configurations.Value?.PurchaseHistory?.KRuokaChains).Chains;
    }

    [OpenApiOperation(
        operationId: "get-household-summary-aspa",
        Summary = "Get household summary",
        Description = "Get household summary")
    ]
    [FunctionName(nameof(FnHouseholdPurchaseHistory))]
    [OpenApiParameter(name: "householdId", In = ParameterLocation.Path, Required = true, Type = typeof(int), Description = "Household Id")]
    [OpenApiParameter(name: "chainId", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Chain Id")]
    [OpenApiParameter(name: "firstDate", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "Start month (yyyy-mm-dd)")]
    [OpenApiParameter(name: "lastDate", In = ParameterLocation.Query, Required = false, Type = typeof(string), Description = "End month (yyyy-mm-dd)")]
    [OpenApiResponseWithoutBody(HttpStatusCode.OK, Description = "Successfully fetched household point balance")]
    [OpenApiResponseWithoutBody(HttpStatusCode.BadGateway, Description = "Error communicating with upstream services.")]
    [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Application or configuration error in the API.")]
    public async Task<IActionResult> GetPoints(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "households/{householdId}/purchases")]
        HttpRequest request,
        string householdId,
        CancellationToken cancellationToken)
    {
        var defaultStartDate = DateTime.Today.AddMonths(-11);
        defaultStartDate = new DateTime(defaultStartDate.Year, defaultStartDate.Month, 1);

        if (!request.Query["firstDate"].ParseDate(defaultStartDate, out var startDate))
        {
            return new BadRequestObjectResult("Invalid startDate");
        }
        if (!request.Query["lastDate"].ParseDate(DateTime.Now.AddDays(1), out var endDate))
        {
            return new BadRequestObjectResult("Invalid endDate");
        }

        string chainId = request.Query["chainId"];
        return await HandleHttpRequest(async () =>
        {
            var receipts = string.IsNullOrWhiteSpace(chainId)
                ? await _repository.FetchReceipts(householdId, startDate, endDate, cancellationToken)
                : await _repository.FetchHouseholdReceiptsByChain(householdId, new[] { chainId }, startDate, endDate, cancellationToken);

            var response = PurchaseHistoryResponseBuilderForAspa.Build(receipts, startDate, endDate, _kruokaChains);
            return new OkObjectResult(response);
        });
    }
}