using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using FluentValidation;
using Loyalty.Aspa.Search;
using Loyalty.Common.Examples;
using Loyalty.Common.Extensions.Clm;
using Loyalty.Common.Functions;
using Loyalty.Common.Services;
using Loyalty.Domain.Contracts.Request;
using Loyalty.Domain.Contracts.Request.Clm;
using Loyalty.Domain.Contracts.Responses;
using Loyalty.Domain.Entities.Clm;
using Loyalty.Domain.Entities.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;

namespace Loyalty.Aspa
{
    public class PostSearchCustomerByBankApplication : HttpEndpointFunctionWithBody<PostSearchCustomerByBankApplication, PostSearchCustomerByBankApplicationRequest>
    {
        private readonly ILogger<PostSearchCustomerByBankApplication> _logger;
        private readonly ISearchService _searchService;

        public PostSearchCustomerByBankApplication(ILogger<PostSearchCustomerByBankApplication> log,
            ISearchService searchService,
            IValidator<PostSearchCustomerByBankApplicationRequest> validator) : base(log, validator)
        {
            _logger = log;
            _searchService = searchService;
        }

        [FunctionName(nameof(PostSearchCustomerByBankApplication))]
        [OpenApiOperation(operationId: "post-search-customer-by-bank-application",
            tags: new[] { "loyalty", "aspa" },
            Summary = "Search Customer By Bank Application Details",
            Description = "Search Customer By Bank Application Details",
            Visibility = OpenApiVisibilityType.Important
        )]
        [OpenApiRequestBody(
        MediaTypeNames.Application.Json,
        typeof(PostSearchCustomerByBankApplicationRequest),
        Example = typeof(PostSearchCustomerByBankApplicationExample)
        )]
        [OpenApiResponseWithBody(HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(List<PostSearchCustomerByBankApplicationResponse>), Description = "The OK response", Summary = "The Response")]
        [OpenApiResponseWithoutBody(HttpStatusCode.Forbidden, Description = "Given token is invalid")]
        [OpenApiResponseWithoutBody(HttpStatusCode.NotFound, Description = "Matching customer not found")]
        [OpenApiResponseWithoutBody(HttpStatusCode.BadRequest, Description = "Bad request")]
        [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "search-bank-application-customer")] HttpRequestMessage request, CancellationToken token)
        {
            return await HandleHttpRequest(async () =>
            {
                var dto = await ValidateFromBodyAsync(request, token);

                if (!string.IsNullOrEmpty(dto.NationalIdentificationNumber))
                {
                    var searchRequest = ClmQueryExtensions.NationalIdentificationSearchContract(
                        dto.NationalIdentificationNumber,
                        dto.FirstName,
                        dto.LastName);
                    var searchResultsSSN = await _searchService.Search(searchRequest, token);
                    var matchingCustomersSSN = GetCustomers(searchResultsSSN, customerSummaryExt => customerSummaryExt.Ssn == dto.NationalIdentificationNumber);
                    if (matchingCustomersSSN.Count > 0)
                    {
                        return new OkObjectResult(matchingCustomersSSN);
                    }
                }

                var searchResults = await _searchService.Search(dto.StreetAddressSearchBody(), token);
                var matchingCustomers = GetCustomerSearchRules(dto)
                    .SearchFrom(rule => GetCustomers(searchResults, rule.predicate));
                matchingCustomers ??= GetEmailPhoneSearchRules(dto)
                    .SearchFromAsync(async rule => await GetMatchingCustomers(rule.search, rule.predicate, token));

                return matchingCustomers != null
                    ? new OkObjectResult(matchingCustomers)
                    : new NotFoundResult();
            });
        }

        private static SearchRules<CustomerSearchRule> GetCustomerSearchRules(PostSearchCustomerByBankApplicationRequest dto)
            => new SearchRules<CustomerSearchRule>()
                .AddRule(new CustomerSearchRule(customerSummaryExt => customerSummaryExt.FirstName == dto.FirstName && customerSummaryExt.LastName == dto.LastName))
                .AddRule(new CustomerSearchRule(customerSummaryExt => customerSummaryExt.FirstName == dto.FirstName))
                .AddRule(new(customerSummaryExt => customerSummaryExt.LastName == dto.LastName));

        private static SearchRules<PhoneEmailSearchRule> GetEmailPhoneSearchRules(PostSearchCustomerByBankApplicationRequest dto)
            => new SearchRules<PhoneEmailSearchRule>()
                .AddRule(
                    rule: new PhoneEmailSearchRule(ClmQueryExtensions.EmailAddressSearchContract(dto.EmailAddress), customer => customer.Address.Email == dto.EmailAddress),
                    condition: !string.IsNullOrEmpty(dto.EmailAddress))
                .AddRule(
                    rule: new PhoneEmailSearchRule(ClmQueryExtensions.PhoneNoSearchContract(dto.PhoneNo), customer => customer.Address.Phone == dto.PhoneNo),
                    condition: !string.IsNullOrEmpty(dto.PhoneNo));

        private List<PostSearchCustomerByBankApplicationResponse> GetCustomers(IAccountSummaryExt[] accountSummaryExts, Func<CustomerSummaryExt, bool> predicate)
        {
            return accountSummaryExts.Length > 0 ? MapCustomerToResponse(accountSummaryExts, accountSummaryExts.SelectMany(x => x.Customers).Where(predicate)) : new List<PostSearchCustomerByBankApplicationResponse>();
        }

        public async Task<List<PostSearchCustomerByBankApplicationResponse>> GetMatchingCustomers(SearchRequestExt search, Func<CustomerSummaryExt, bool> predicate, CancellationToken token)
        {
            var searchResults = await _searchService.Search(search, token);
            return GetCustomers(searchResults, predicate);
        }

        private List<PostSearchCustomerByBankApplicationResponse> MapCustomerToResponse(IAccountSummaryExt[] accountSummaryExts, IEnumerable<CustomerSummaryExt> customerSummaryExts)
        {
            List<PostSearchCustomerByBankApplicationResponse> postSearchCustomerByBankApplicationResponses = new List<PostSearchCustomerByBankApplicationResponse>();
            foreach (var customerSummaryExt in customerSummaryExts)
            {
                postSearchCustomerByBankApplicationResponses.Add(new PostSearchCustomerByBankApplicationResponse()
                {
                    FirstName = customerSummaryExt.FirstName,
                    LastName = customerSummaryExt.LastName,
                    BirthDate = customerSummaryExt.BirthDate,
                    AccountId = customerSummaryExt.AccountId,
                    Address = customerSummaryExt.Address,
                    Ssn = customerSummaryExt.Ssn,
                    Id = customerSummaryExt.Id,
                    CompanyName = accountSummaryExts.FirstOrDefault().CompanyName,
                    BusinessId = accountSummaryExts.FirstOrDefault().BusinessId,
                    IsMainHousehold = accountSummaryExts.FirstOrDefault(acc => acc.OwnerCustomerId == customerSummaryExt.Id) != null,
                });
            }
            return postSearchCustomerByBankApplicationResponses;
        }

    }

    internal record PhoneEmailSearchRule(SearchRequestExt search, Func<CustomerSummaryExt, bool> predicate) { }
    internal record CustomerSearchRule(Func<CustomerSummaryExt, bool> predicate) { }
}