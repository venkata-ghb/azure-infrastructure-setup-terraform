using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Loyalty.Common.Constants.Applications;
using Loyalty.Common.Factories;
using Loyalty.Common.Functions;
using Loyalty.Common.Services;
using Loyalty.Domain.Enums;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json.Linq;

namespace Loyalty.Aspa;

public class PostResendCorrectedApplication : HttpEndpointFunctionWithoutBody<PostResendCorrectedApplication>
{
    private readonly IApplicationService _applicationService;
    private readonly ApplicationEnrollmentFactory _applicationEnrollmentFactory;

    public PostResendCorrectedApplication(
        ILogger<PostResendCorrectedApplication> log,
        IApplicationService applicationService,
        ApplicationEnrollmentFactory applicationEnrollmentFactory) : base(log)
    {
        _applicationService = applicationService;
        _applicationEnrollmentFactory = applicationEnrollmentFactory;
    }

    [FunctionName(nameof(PostResendCorrectedApplication))]
    [OpenApiOperation(operationId: "post-corrected-application-pushed-to-clm",
        Summary = "Corrected application is pushed to CLM",
        Description = "Corrected application is pushed to CLM",
        Visibility = OpenApiVisibilityType.Important
    )]
    [OpenApiParameter(name: "applicationId", In = ParameterLocation.Path, Required = true, Type = typeof(string), Description = "Application Id")]
    [OpenApiResponseWithoutBody(HttpStatusCode.OK, Description = "The OK response")]
    [OpenApiResponseWithoutBody(HttpStatusCode.Forbidden, Description = "Given token is invalid")]
    [OpenApiResponseWithoutBody(HttpStatusCode.NotFound, Description = "Erroneous application not found")]
    [OpenApiResponseWithoutBody(HttpStatusCode.BadRequest, Description = "Bad request")]
    [OpenApiResponseWithoutBody(HttpStatusCode.Conflict, Description = "Request conflicts with current application state")]
    [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error or application type not supported")]
    public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "applications/{applicationId}/resend")]
        HttpRequestMessage request,
        string applicationId,
        CancellationToken ct)
    {
        return await HandleHttpRequest(async () =>
        {
            JObject application = await _applicationService.GetApplicationByIdAsync<dynamic>(applicationId, ct);
            if (application[ApplicationFields.ApplicationStatus]?.ToObject<ApplicationStatuses>() != ApplicationStatuses.ERROR)
            {
                return new NotFoundResult();
            }

            var applicationType = application[ApplicationFields.ApplicationType]?.ToString();
            var handler = _applicationEnrollmentFactory.CreateHandler(applicationType);
            var result = await handler.EnrollApplication(application, ct);
            return new OkObjectResult(result);
        });
    }
}
