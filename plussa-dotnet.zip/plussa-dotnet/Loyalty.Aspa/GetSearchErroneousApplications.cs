using FluentValidation;
using Loyalty.Common.Examples;
using Loyalty.Common.Functions;
using Loyalty.Common.Services;
using Loyalty.Domain.Contracts.Request;
using Loyalty.Domain.Entities.Cosmos;
using Loyalty.Domain.Enums;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using Loyalty.Domain.Contracts.Responses;
using Mapster;

namespace Loyalty.Aspa;

public class GetSearchErroneousApplications : HttpEndpointFunctionWithBody<GetSearchErroneousApplications, GetSearchErroneousApplicationsRequest>
{
    private readonly IValidator<GetSearchErroneousApplicationsRequest> _validator;
    private readonly IApplicationService _service;

    public GetSearchErroneousApplications(
        ILogger<GetSearchErroneousApplications> log,
        IValidator<GetSearchErroneousApplicationsRequest> validator,
        IApplicationService service) : base(log, validator)
    {
        _validator = validator;
        _service = service;
    }

    /// <summary>
    /// Customer service rep can search for errorneous applications so end users can be helped with enrollment problems
    /// </summary>
    /// <param name="request"></param>
    /// <param name="token"></param>
    /// <returns></returns>
    [OpenApiOperation(
        operationId: "get-search-erroneous-applications",
        tags: new[] { "loyalty", "aspa" },
        Summary = "Search erroneous applications",
        Description = "Customer service rep can search for erroneous applications so that end users can be helped with enrollment problems",
        Visibility = OpenApiVisibilityType.Important
    )]
    [OpenApiRequestBody(
        MediaTypeNames.Application.Json,
        typeof(GetSearchErroneousApplicationsRequest),
        Example = typeof(SearchErroneousApplicationsRequestExample))]
    [OpenApiResponseWithBody(
        statusCode: HttpStatusCode.OK,
        contentType: MediaTypeNames.Application.Json,
        bodyType: typeof(ErroneousApplication),
        Summary = "The response",
        Description = "This returns the response",
        Example = typeof(SearchErroneousApplicationsExample)
    )]
    [OpenApiResponseWithoutBody(HttpStatusCode.BadRequest, Description = "Bad request")]
    [OpenApiResponseWithoutBody(HttpStatusCode.BadGateway, Description = "Upstream did not respond")]
    [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error")]
    [FunctionName(nameof(GetSearchErroneousApplications))]
    public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "erroneous-applications")]
        HttpRequestMessage request,
        CancellationToken token)
    {
        return await HandleHttpRequest(async () =>
        {
            var filters = await ValidateFromBodyAsync(request, token);
            var validationResult = await _validator.ValidateAsync(filters, token);
            if (!validationResult.IsValid)
            {
                return new BadRequestObjectResult(validationResult.ToString());
            }

            var result = await _service.GetErroneousApplications(
                filters.Status is not null ? new[] { filters.Status.Value } : Array.Empty<ApplicationStatuses>(),
                filters.Types is not null ? filters.Types : Array.Empty<ApplicationTypes>(),
                filters.FirstName,
                filters.LastName,
                filters.DateOfBirth,
                filters.ErrorMessage,
                filters.AccountType,
                true,
                token);

            var response = result
                .Select(item => item.Adapt<ErroneousApplicationResponse>() with
                {
                    CardNumberByCustomer = _cardNumbers
                        .Select(getCardNumber => getCardNumber(item))
                        .FirstOrDefault(item => !string.IsNullOrWhiteSpace(item)), 
                    CardNumberByBank = !string.IsNullOrWhiteSpace(item.IdentifierNo) ? item.IdentifierNo : item.CardNumberToBeAdded,
                    CardTypeCode = !string.IsNullOrWhiteSpace(item.CardTypeCode) ? item.CardTypeCode : item.ApplicationTypeCode
                })
                .ToList();
            
            return new OkObjectResult(response);
        });
    }

    private readonly List<Func<ErroneousApplication, string>> _cardNumbers = new()
    {
        item => item.ExistingIdentifierNo,
        item => item.CardNumberToBeDeleted,
        item => item.CardNumber,
    };
}