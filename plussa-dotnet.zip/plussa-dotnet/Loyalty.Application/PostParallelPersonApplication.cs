using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using FluentValidation;
using Loyalty.Common.Configuration;
using Loyalty.Common.Examples;
using Loyalty.Common.Functions;
using Loyalty.Common.Services;
using Loyalty.Domain.Contracts.Request;
using Loyalty.Domain.Entities;
using Loyalty.Domain.Entities.Cosmos;
using Loyalty.Domain.Enums;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Loyalty.Application
{
    public class PostParallelPersonApplication : HttpEndpointFunctionWithBody<PostParallelPersonApplication, PostParallelPersonApplicationInfo>
    {
        private readonly ICustomerMatchingService _service;
        private readonly ISendEmailService _sendEmailService;
        private readonly ITokenVerificationService _tokenVerificationService;
        private readonly IApplicationService _applicationService;
        private readonly ApplicationConfiguration _options;

        public PostParallelPersonApplication(
            ILogger<PostParallelPersonApplication> log,
            IValidator<PostParallelPersonApplicationInfo> validator,
            ICustomerMatchingService service,
            ISendEmailService sendEmailService,
            ITokenVerificationService tokenVerificationService,
            IApplicationService applicationService,
            IOptions<ApplicationConfiguration> options) : base(log, validator)
        {
            _service = service;
            _sendEmailService = sendEmailService;
            _tokenVerificationService = tokenVerificationService;
            _applicationService = applicationService;
            _options = options.Value;
        }

        [FunctionName("PostParallelPersonApplication")]
        [OpenApiOperation(operationId: "post-person-application",
            tags: new[] { "loyalty" },
            Summary = "New Adult Parallel Card Holder Application",
            Description = "Application to create a new adult person",
            Visibility = OpenApiVisibilityType.Important
            )]
        [OpenApiRequestBody(
            MediaTypeNames.Application.Json,
            typeof(PostParallelPersonApplicationInfo),
            Example = typeof(PostParallelPersonApplicationInfoExample))]
        [OpenApiResponseWithoutBody(HttpStatusCode.Accepted, Description = "The OK response")]
        [OpenApiResponseWithoutBody(HttpStatusCode.BadRequest, Description = "Bad request")]
        [OpenApiResponseWithoutBody(HttpStatusCode.Conflict, Description = "Customer already exist.")]
        [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "enroll-parallel-person")]
            HttpRequestMessage request,
            CancellationToken ct)
        {

            return await HandleHttpRequest(async () =>
            {
                var dto = await ValidateFromBodyAsync(request, ct);

                var uniqueCustomerValidatorData = new PersonExistsSearchEntity
                {
                    FirstName = dto.FirstName,
                    LastName = dto.LastName,
                    StreetAddress = dto.StreetAddress,
                    PostCode = dto.PostCode,
                    BirthYear = GetBirthYear(dto.DateOfBirth),
                    EmailAddress = dto.EmailAddress,
                    NationalIdentificationNumber = dto.NationalIdentificationNumber
                };

                var customers = await _service.CustomerExistsWithCustomersInfo(uniqueCustomerValidatorData, ct);

                if (customers.Any())
                {
                    if (customers.Any(x => x.Address.Email.Equals(dto.EmailAddress, StringComparison.OrdinalIgnoreCase)))
                    {
                        await _sendEmailService.SendErrorEmail(dto.Language, dto.EmailAddress, ct);
                    }
                    return new ConflictResult();
                }

                var verifiedToken = await _tokenVerificationService.VerifyToken(
                    new VerifyEmail { Token = dto.InvitationEmailToken, Id = dto.TokenId },
                    ct);

                var invite = await _applicationService.GetApplicationByTokenAsync<InviteAdultApplication>(verifiedToken, ct);
                var applicationId = await _applicationService.CreateApplicationAsync(ParallelAdultApplication.FromDto(dto, invite), ct);

                await _sendEmailService.SendConfirmationEmail(
                    dto.Language, dto.EmailAddress, ApplicationTypes.PA, applicationId, dto.CreateKId, ct);

                var applicationToUpdate = invite with
                {
                    ApplicationStatus = ApplicationStatuses.SUCCESS,
                    Ttl = (int)TimeSpan.FromDays(_options.RemoveSuccessAfterDays).TotalSeconds
                };

                await _applicationService.UpsertApplicationAsync(applicationToUpdate, ct);
                await _tokenVerificationService.DeleteVerifiedToken(verifiedToken, ct);

                return new AcceptedResult();
            });
        }

        public static int GetBirthYear(string dateOfBirth)
        {
            var dt = Convert.ToDateTime(dateOfBirth);

            return dt.Year;
        }
    }
}

