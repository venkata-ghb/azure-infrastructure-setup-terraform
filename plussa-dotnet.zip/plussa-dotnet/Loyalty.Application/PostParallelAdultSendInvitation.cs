using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using FluentValidation;
using Loyalty.Common.Configuration;
using Loyalty.Common.Examples;
using Loyalty.Common.Functions;
using Loyalty.Common.Services;
using Loyalty.Common.Services.Authorization;
using Loyalty.Domain.Contracts.Request;
using Loyalty.Domain.Contracts.Request.Clm;
using Loyalty.Domain.Entities.Clm;
using Loyalty.Domain.Entities.Cosmos;
using Loyalty.Domain.Entities.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Models;

namespace Loyalty.Application
{
    public class PostParallelAdultSendInvitation : HttpEndpointFunctionWithBody<PostParallelAdultSendInvitation, PostParallelAdultSendInvitationInfo>
    {
        private readonly ISearchService _searchService;
        private readonly IAuthenticationValidator _authenticationValidator;
        private readonly ISendEmailService _sendEmailService;
        private readonly IApplicationService _applicationService;
        private readonly ApplicationConfiguration _options;

        public PostParallelAdultSendInvitation(
            ILogger<PostParallelAdultSendInvitation> log,
            IValidator<PostParallelAdultSendInvitationInfo> validator,
            ISearchService searchService,
            IAuthenticationValidator authenticationValidator,
            ISendEmailService sendEmailService,
            IApplicationService applicationService,
            IOptions<ApplicationConfiguration> options) : base(log, validator)
        {
            _searchService = searchService;
            _authenticationValidator = authenticationValidator;
            _sendEmailService = sendEmailService;
            _applicationService = applicationService;
            _options = options.Value;
        }

        [FunctionName(nameof(PostParallelAdultSendInvitation))]
        [OpenApiOperation(operationId: "post-parallel-adult-send-invitation-email",
            tags: new[] { "loyalty" },
            Summary = "API to send email invitation for parallel card",
            Description = "API to send email invitation for parallel card",
            Visibility = OpenApiVisibilityType.Important
            )]
        [OpenApiSecurity("Authorization",
            SecuritySchemeType.ApiKey,
            Name = "Authorization",
            In = OpenApiSecurityLocationType.Header)]
        [OpenApiRequestBody(
            MediaTypeNames.Application.Json,
            typeof(PostParallelAdultSendInvitationInfo),
            Example = typeof(PostParallelAdultSendInvitationInfoExample))]
        [OpenApiResponseWithoutBody(HttpStatusCode.Accepted, Description = "The OK response")]
        [OpenApiResponseWithoutBody(HttpStatusCode.Unauthorized, Description = "Access denied due to invalid subscription key. Make sure to provide a valid key for an active subscription.")]
        [OpenApiResponseWithoutBody(HttpStatusCode.BadRequest, Description = "Bad request")]
        [OpenApiResponseWithoutBody(HttpStatusCode.Forbidden, Description = "User is not authorized to invite")]
        [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "invite-parallel-adult")]
            HttpRequestMessage request,
            CancellationToken ct)
        {
            return await HandleHttpRequest(async () =>
            {

                var dto = await ValidateFromBodyAsync(request, ct);
                var (customerId, householdId) = await _authenticationValidator.ValidateProfileScopesFullIdentityAsync(request.Headers, ct, true);

                var searchQuery = GenerateSearchQuery(customerId.ToString());
                var accountSummaryData = await _searchService.Search(searchQuery, ct);

                var isMainCardHolder = IsMainCardHolder(accountSummaryData, customerId.ToString(), householdId.ToString());

                if (!isMainCardHolder)
                {
                    return new StatusCodeResult(StatusCodes.Status403Forbidden);
                }

                var applicationId = await _applicationService.CreateApplicationAsync(new InviteAdultApplication
                {
                    PersonId = customerId.ToString(),
                    HouseholdId = householdId.ToString(),
                    CanUsePlussaMoney = dto.CanUsePlussaMoney,
                    Ttl = (int)TimeSpan.FromDays(_options.RemoveDraftsAfterDays).TotalSeconds,
                }, ct);
                await _sendEmailService.SendParallelAdultInvitationEmail(dto, applicationId, ct);

                return new AcceptedResult();
            });
        }

        private static SearchRequestExt GenerateSearchQuery(string customerId) =>
            new SearchRequestExt
            {
                Customer = new()
                {
                    CustomerId = int.Parse(customerId),
                    Status = Statuses.Active
                }
            };

        private static bool IsMainCardHolder(IAccountSummaryExt[] accountSummaryData, string customerId, string householdId)
        {
            return accountSummaryData.Any(accountSummary => householdId == accountSummary.Id.ToString() && customerId == accountSummary.OwnerCustomerId.ToString());
        }
    }
}

