using System.Net;
using System.Net.Http;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using FluentValidation;
using Loyalty.Common.Examples;
using Loyalty.Common.Factories;
using Loyalty.Common.Functions;
using Loyalty.Common.Services;
using Loyalty.Domain.Contracts.Request;
using Loyalty.Domain.Contracts.Responses;
using Loyalty.Domain.Entities.Cosmos;
using Loyalty.Domain.Enums;
using Mapster;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;

namespace Loyalty.Application
{
    public class PostApplicationVerifyEmail : HttpEndpointFunctionWithBody<PostApplicationVerifyEmail, VerifyEmail>
    {
        private readonly ITokenVerificationService _tokenVerificationService;
        private readonly ApplicationEnrollmentFactory _applicationEnrollmentFactory;

        public PostApplicationVerifyEmail(
            ILogger<PostApplicationVerifyEmail> log,
            IValidator<VerifyEmail> validator,
            ITokenVerificationService tokenVerificationService,
            ApplicationEnrollmentFactory applicationEnrollmentFactory) : base(log, validator)
        {
            _tokenVerificationService = tokenVerificationService;
            _applicationEnrollmentFactory = applicationEnrollmentFactory;
        }
        [FunctionName(nameof(PostApplicationVerifyEmail))]
        [OpenApiOperation(operationId: "post-household-application-verify-email",
            tags: new[] { "loyalty" },
            Summary = "Household application process to verify email",
            Description = "Api to verify email address and create a new household",
            Visibility = OpenApiVisibilityType.Important
            )]
        [OpenApiRequestBody(
            MediaTypeNames.Application.Json,
            typeof(VerifyEmail),
            Example = typeof(VerifyEmailExample))]
        [OpenApiResponseWithBody(HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(ApplicationEnrollmentResponseWithEmail), Summary = "The Response", Description = "This returns the response")]
        [OpenApiResponseWithoutBody(HttpStatusCode.Unauthorized, Description = "Access denied due to invalid subscription key. Make sure to provide a valid key for an active subscription.")]
        [OpenApiResponseWithoutBody(HttpStatusCode.Forbidden, Description = "Given token is invalid")]
        [OpenApiResponseWithoutBody(HttpStatusCode.BadRequest, Description = "Bad request")]
        [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "verify-enrollment-email")]
            HttpRequestMessage request,
            CancellationToken token)
        {
            return await HandleHttpRequest(async () =>
            {
                var dto = await ValidateFromBodyAsync(request, token);
                var verifiedToken = await _tokenVerificationService.VerifyToken(dto, token, ApplicationTypes.NH, ApplicationTypes.SH, ApplicationTypes.PA);
                await _tokenVerificationService.DeleteVerifiedToken(verifiedToken, token);

                var application = _applicationEnrollmentFactory.CreateHandler(verifiedToken.ApplicationType);
                var result = await application.EnrollApplication(verifiedToken.ApplicationId, token);

                return new OkObjectResult(result.Adapt<ApplicationEnrollmentResponseWithEmail>() with
                {
                    CreateKId = verifiedToken.CreateKId,
                    EmailId = verifiedToken.Email
                });
            });
        }
    }
}