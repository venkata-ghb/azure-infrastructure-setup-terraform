using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using FluentValidation;
using Loyalty.Common.Functions;
using Loyalty.Common.Services;
using Loyalty.Domain.Contracts.Request;
using Loyalty.Domain.Entities.Cosmos;
using Mapster;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;

namespace Loyalty.Application
{
    public class PostKBusinessCompanyCardApplication : HttpEndpointFunctionWithBody<PostKBusinessCompanyCardApplication, PostKBusinessCompanyCardCreation>
    {
        private readonly IApplicationService _saveApplication;
        private readonly ISendEmailService _sendEmailService;
        private readonly IConfigurationService _configurationService;

        public PostKBusinessCompanyCardApplication(
            ILogger<PostKBusinessCompanyCardApplication> log,
            IValidator<PostKBusinessCompanyCardCreation> validator,
            IApplicationService saveApplication,
            ISendEmailService sendEmailService,
            IConfigurationService configurationService) : base(log, validator)
        {
            _saveApplication = saveApplication;
            _sendEmailService = sendEmailService;
            _configurationService = configurationService;
        }

        [FunctionName("PostKBusinessCompanyCardApplication")]
        [OpenApiOperation(operationId: "post-k-business-application",
            tags: new[] { "loyalty" },
            Summary = "K Business Company Card Application",
            Description = "Application to create a new company card for K Business",
            Visibility = OpenApiVisibilityType.Important
            )]
        [OpenApiRequestBody(
            MediaTypeNames.Application.Json,
            typeof(PostKBusinessCompanyCardCreation))]
        [OpenApiResponseWithoutBody(HttpStatusCode.Accepted, Description = "The OK response")]
        [OpenApiResponseWithoutBody(HttpStatusCode.BadRequest, Description = "Bad request")]
        [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "application/k-business-application")]
            HttpRequestMessage request,
            CancellationToken token)
        {
            return await HandleHttpRequest(async () =>
            {
                var dto = await ValidateFromBodyAsync(request, token);

                await _saveApplication.CreateApplicationAsync(dto.Adapt<KBusinessCompanyCardApplicaion>(), token);
                var emailRecipientList = await _configurationService.GetKBusinessLeadEmailRecipients(token);
                if (emailRecipientList != null && emailRecipientList.Length > 0)
                {
                    await _sendEmailService.SendKBusinessCompanyCardEmail(emailRecipientList, dto, token);
                }

                return new AcceptedResult();
            });
        }
    }
}

