using FluentValidation;
using Loyalty.Common.Examples;
using Loyalty.Common.Functions;
using Loyalty.Common.Services;
using Loyalty.Domain.Contracts.Request;
using Loyalty.Domain.Contracts.Responses;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using System.Collections.Generic;
using System.Net;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;

namespace Loyalty.Application
{
    public class PostPlussaCardDeleteNLbyPartner : HttpEndpointFunctionWithBody<PostPlussaCardDeleteNLbyPartner, List<PostPlussaCardDeleteNLbyPartnerRequest>>
    {
        private readonly ICardService _cardService;
        private readonly IValidator<List<PostPlussaCardDeleteNLbyPartnerRequest>> _validator;

        public PostPlussaCardDeleteNLbyPartner(
            ILogger<PostPlussaCardDeleteNLbyPartner> log,
            IValidator<List<PostPlussaCardDeleteNLbyPartnerRequest>> validator,
            ICardService cardService) : base(log, validator)
        {
            _cardService = cardService;
            _validator = validator;

        }

        [FunctionName(nameof(PostPlussaCardDeleteNLbyPartner))]
        [OpenApiOperation(operationId: "delete-plussa-card-nl-partner",
            tags: new[] { "loyalty", "NL" },
            Summary = "Deletes plussa card applications for NL by partner",
            Description = "Application to delete an existing plussa cards for NL by partners",
            Visibility = OpenApiVisibilityType.Important
        )]
        [OpenApiRequestBody(
            MediaTypeNames.Application.Json,
            typeof(List<PostPlussaCardDeleteNLbyPartnerRequest>),
            Example = typeof(PostPlussaCardDeleteNLbyPartnerRequestExample))]
        [OpenApiResponseWithBody(
            HttpStatusCode.OK,
            bodyType: typeof(DeletePlussaCardResponse),
            contentType: MediaTypeNames.Application.Json,
            Description = "Delete request accepted. Cards will be deleted.")]
        [OpenApiResponseWithBody(
            HttpStatusCode.BadRequest,
            bodyType: typeof(string),
            contentType: MediaTypeNames.Text.Plain,
            Description = "Malformed request. Error details in response body.")]
        [OpenApiResponseWithoutBody(HttpStatusCode.Forbidden,
        Description = "Forbidden error")]
        [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "application/plussacardbypartner/delete")]
            List<PostPlussaCardDeleteNLbyPartnerRequest> postPlussaCardDeleteNLbyPartnerRequests,
            CancellationToken ct)
        {
            return await HandleHttpRequest(async () =>
            {
                var requestValidationResult = await _validator.ValidateAsync(postPlussaCardDeleteNLbyPartnerRequests, ct);

                if (!requestValidationResult.IsValid)
                {
                    return new BadRequestObjectResult(requestValidationResult.ToString());
                }

                await _cardService.CloseCardByCardNumberPartner(postPlussaCardDeleteNLbyPartnerRequests, ct);

                return new OkObjectResult(new DeletePlussaCardResponse("true"));
            });
        }
    }
}

