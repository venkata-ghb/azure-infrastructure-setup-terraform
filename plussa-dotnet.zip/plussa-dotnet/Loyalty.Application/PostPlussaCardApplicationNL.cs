using FluentValidation;
using Loyalty.Common.Constants.CLM;
using Loyalty.Common.Exceptions;
using Loyalty.Common.Extensions;
using Loyalty.Common.Extensions.Clm;
using Loyalty.Common.Functions;
using Loyalty.Common.Services;
using Loyalty.Domain.Enums;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using System.Linq;
using System.Net;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using Loyalty.Common.Examples;
using Loyalty.Domain.Contracts.Request;
using Loyalty.Domain.Contracts.Responses;

namespace Loyalty.Application
{
    public class PostPlussaCardApplicationNL : HttpEndpointFunctionWithBody<PostPlussaCardApplicationNL, PostPlussaCardApplicationNLRequest>
    {
        private readonly ISearchService _searchService;
        private readonly ICardService _cardService;
        private readonly IValidator<PostPlussaCardApplicationNLRequest> _validator;
        private const int MaxAllowedMobileCards = 5;
        private const string IdentifierTypeCode = IdentifierTypes.NLCard;

        public PostPlussaCardApplicationNL(ILogger<PostPlussaCardApplicationNL> log,
            IValidator<PostPlussaCardApplicationNLRequest> validator,
            ISearchService searchService,
            ICardService cardService) : base(log, validator)
        {
            _searchService = searchService;
            _validator = validator;
            _cardService = cardService;
        }

        [FunctionName("PostPlussaCardApplicationNL")]
        [OpenApiOperation(operationId: "post-plussa-card-application-nl",
            tags: new[] { "loyalty", "NL" },
            Summary = "New plussa card application for NL",
            Description = "Application to create a new plussa card depending on application type for NL",
            Visibility = OpenApiVisibilityType.Important)]
        [OpenApiRequestBody(
            MediaTypeNames.Application.Json,
            typeof(PostPlussaCardApplicationNLRequest),
            Example = typeof(PostPlussaCardApplicationNLRequestExample))]
        [OpenApiResponseWithBody(
        statusCode: HttpStatusCode.OK,
        contentType: MediaTypeNames.Application.Json,
        bodyType: typeof(PostPlussaCardApplicationNLResponse),
        Description = "Newly generated loyalty plussa card number")]
        [OpenApiResponseWithoutBody(HttpStatusCode.BadRequest, Description = "Bad request")]
        [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error")]
        public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "application/plussacard")]
        PostPlussaCardApplicationNLRequest postPlussaCardApplicationNLRequest,
        CancellationToken token)
        {
            return await HandleHttpRequest(async () =>
            {
                var requestValidationResult = await _validator.ValidateAsync(postPlussaCardApplicationNLRequest, token);
                if (!requestValidationResult.IsValid)
                {
                    return new BadRequestObjectResult(requestValidationResult.ToString());
                }

                var searchQuery = ClmQueryExtensions.LoyaltyCardSearchRequest(postPlussaCardApplicationNLRequest.CardNumber);
                var accountSummaryData = await _searchService.Search(searchQuery, token);
                var firstname = postPlussaCardApplicationNLRequest.FirstName.ToLowerInvariant().Split(' ');
                var lastName = postPlussaCardApplicationNLRequest.LastName.ToLowerInvariant();
                var cardValidationResult = accountSummaryData.ValidateCard(postPlussaCardApplicationNLRequest.CardNumber, firstname, lastName);

                if (cardValidationResult == CardValidationStatus.UserNotFound)
                {
                    return new BadRequestObjectResult("User with given details was not found.");
                }
                else if (cardValidationResult == CardValidationStatus.CardNotFound)
                {
                    return new BadRequestObjectResult("Card with given number was not found.");
                }

                var account = accountSummaryData.FirstOrDefault(x => x.Identifiers.Any(y => y.IdentifierNo.Equals(postPlussaCardApplicationNLRequest.CardNumber)))
                    ?? throw new NotFoundException("CLM did not return such account.");

                var customer = account.Customers.FirstOrDefault(x => x.Identifiers.Any(y => y.IdentifierNo.Equals(postPlussaCardApplicationNLRequest.CardNumber) && y.Status == CardStatus.Active));

                var existingMobilePayCards = customer.Identifiers.Count(identifier => identifier.IdentifierTypeCode == IdentifierTypeCode && identifier.Status == CardStatus.Active);

                if (existingMobilePayCards >= MaxAllowedMobileCards)
                {
                    return new BadRequestObjectResult($"User cannot apply for more than {MaxAllowedMobileCards} mobile cards");
                }

                var newCardNo = await _cardService.RequestNewCardForCustomer(customer.Id, IdentifierTypeCode, token);

                return new OkObjectResult(new PostPlussaCardApplicationNLResponse(newCardNo));
            });
        }
    }
}