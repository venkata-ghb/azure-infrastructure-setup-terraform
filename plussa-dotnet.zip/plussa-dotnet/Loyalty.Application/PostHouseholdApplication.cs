using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Logging;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using System.Net.Mime;
using Loyalty.Domain.Contracts.Request;
using Loyalty.Common.Examples;
using System.Threading;
using FluentValidation;
using Loyalty.Common.Services;
using Loyalty.Domain.Enums;
using Loyalty.Common.Functions;
using System.Net.Http;
using System;
using Loyalty.Common.Configuration;
using Loyalty.Common.Constants;
using Loyalty.Domain.Entities.Cosmos;
using Microsoft.Extensions.Options;
using Loyalty.Domain.Entities;

namespace Loyalty.Application
{
    public class PostHouseholdApplication : HttpEndpointFunctionWithBody<PostHouseholdApplication,PostHouseholdApplicationCreation>
    {
        private readonly ICustomerMatchingService _service;
        private readonly IApplicationService _saveApplication;
        private readonly IMetadataService _metaDataService;
        private readonly ISendEmailService _sendEmailService;
        private readonly ApplicationConfiguration _options;

        public PostHouseholdApplication(
            ILogger<PostHouseholdApplication> log,
            IValidator<PostHouseholdApplicationCreation> validator,
            ICustomerMatchingService service,
            IApplicationService saveApplication,
            IMetadataService metaDataService,
            ISendEmailService sendEmailService,
            IOptions<ApplicationConfiguration> options) : base(log, validator)
        {
            _service = service;
            _saveApplication = saveApplication;
            _metaDataService = metaDataService;
            _sendEmailService = sendEmailService;
            _options = options.Value;
        }

        [FunctionName("PostHouseholdApplication")]
        [OpenApiOperation(operationId: "post-household-application",
            tags: new[] { "loyalty" },
            Summary = "Household creation application",
            Description = "Application to create a new household",
            Visibility = OpenApiVisibilityType.Important
            )]
        [OpenApiRequestBody(
            MediaTypeNames.Application.Json,
            typeof(PostHouseholdApplicationCreation),
            Example = typeof(PostHouseholdApplicationCreationExample))]
        [OpenApiResponseWithoutBody(HttpStatusCode.Accepted, Description = "The OK response")]
        [OpenApiResponseWithoutBody(HttpStatusCode.BadRequest, Description = "Bad request")]
        [OpenApiResponseWithoutBody(HttpStatusCode.Conflict, Description = "Customer already exist.")]
        [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "enroll-household")]
            HttpRequestMessage request,
            CancellationToken token)
        {

            return await HandleHttpRequest(async () =>
            {
                var dto = await ValidateFromBodyAsync(request, token);

                if (dto.ApplicationType == ApplicationTypes.SH)
                {
                    var isStudentDomainValid = await _metaDataService.IsStudentDomain(dto.EmailAddress, token);
                    if (!isStudentDomainValid)
                    {
                        return new BadRequestObjectResult(ErrorMessages.EmailIsNotStudentDomain);
                    }
                }

                var uniqueCustomerValidatorData = new PersonExistsSearchEntity
                {
                    FirstName = dto.FirstName,
                    LastName = dto.LastName,
                    StreetAddress = dto.StreetAddress,
                    PostCode = dto.PostCode,
                    BirthYear = GetBirthYear(dto.DateOfBirth),
                    EmailAddress = dto.EmailAddress,
                    NationalIdentificationNumber = dto.NationalIdentificationNumber
                };

                var customers = await _service.CustomerExistsWithCustomersInfo(uniqueCustomerValidatorData, token);

                if(customers.Any())
                {
                    if(customers.Any(x => x.Address.Email.Equals(dto.EmailAddress, StringComparison.OrdinalIgnoreCase)))
                    {
                        await _sendEmailService.SendErrorEmail(dto.Language, dto.EmailAddress, token);
                    }
                    return new ConflictResult();
                }

                var applicationId = await _saveApplication.CreateApplicationAsync(
                    HouseholdEnrollmentApplication.FromDto(dto, _options.RemoveDraftsAfterDays),
                    token);
                
                await _sendEmailService.SendConfirmationEmail(
                    dto.Language, 
                    dto.EmailAddress,
                    dto.ApplicationType,
                    applicationId,
                    dto.CreateKId,
                    token);

                return new AcceptedResult();
            });
        }

        public static int GetBirthYear(string dateOfBirth)
        {
            var dt = Convert.ToDateTime(dateOfBirth);
            return dt.Year;
        }
    }
}

