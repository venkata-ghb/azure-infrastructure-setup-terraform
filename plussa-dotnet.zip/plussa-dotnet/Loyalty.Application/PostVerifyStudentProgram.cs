using System.Net;
using System.Net.Http;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using FluentValidation;
using Loyalty.Common.Examples;
using Loyalty.Common.Factories;
using Loyalty.Common.Functions;
using Loyalty.Common.Services;
using Loyalty.Domain.Contracts.Request;
using Loyalty.Domain.Entities.Cosmos;
using Loyalty.Domain.Enums;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;

namespace Loyalty.Application;

public class PostVerifyStudentProgram : HttpEndpointFunctionWithBody<PostVerifyStudentProgram, VerifyEmail>
{
    private readonly ITokenVerificationService _tokenVerificationService;
    private readonly IApplicationService _applicationService;
    private readonly ApplicationEnrollmentFactory _applicationEnrollmentFactory;

    public PostVerifyStudentProgram(
        ILogger<PostVerifyStudentProgram> log,
        IValidator<VerifyEmail> validator,
        ITokenVerificationService tokenVerificationService,
        IApplicationService applicationService,
        ApplicationEnrollmentFactory applicationEnrollmentFactory) : base(log, validator)
    {
        _tokenVerificationService = tokenVerificationService;
        _applicationService = applicationService;
        _applicationEnrollmentFactory = applicationEnrollmentFactory;
    }

    [FunctionName(nameof(PostVerifyStudentProgram))]
    [OpenApiOperation(operationId: "post-verify-student-program",
        Summary = "Verify student email",
        Description = "API to verify student email address. User has been sent secrets that should be posted here to verify the address.",
        Visibility = OpenApiVisibilityType.Important
    )]
    [OpenApiRequestBody(
        MediaTypeNames.Application.Json,
        typeof(VerifyEmail),
        Example = typeof(VerifyEmailExample))]
    [OpenApiResponseWithoutBody(HttpStatusCode.Accepted, Description = "The OK response")]
    [OpenApiResponseWithoutBody(HttpStatusCode.Forbidden, Description = "Given token is invalid")]
    [OpenApiResponseWithoutBody(HttpStatusCode.BadRequest, Description = "Bad request")]
    [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error")]
    public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "verify-student-program")]
        HttpRequestMessage request,
        CancellationToken ct)
    {
        return await HandleHttpRequest(async () =>
        {
            var dto = await ValidateFromBodyAsync(request, ct);

            var verifiedToken = await _tokenVerificationService.VerifyToken(dto, ct, ApplicationTypes.SP);
            var application = await _applicationService.GetApplicationByTokenAsync<StudentBenefitJoinApplication>(
                verifiedToken, ct);

            await _applicationEnrollmentFactory.CreateVerifyStudentProgram()
                .HandleApplication(application, ct);

            await _tokenVerificationService.DeleteVerifiedToken(verifiedToken, ct);
            return new AcceptedResult();
        });
    }
}
