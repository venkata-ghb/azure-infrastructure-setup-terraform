﻿using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Configurations;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.OpenApi.Models;

namespace Loyalty.Aspa;

public class OpenApiConfigurationOptions : DefaultOpenApiConfigurationOptions
{
    /// <summary>
    /// Defines openapi/swagger document misc information.
    /// </summary>
    public override OpenApiInfo Info { get; set; } = new OpenApiInfo
    {
        Version = "v1",
        Title = "Loyalty Application service API CLM",
        Description = "Implements API's for enrollment. Backed by the new CLM",
        Contact = new OpenApiContact()
        {
            Name = "Petteri Eranen",
            Email = "petteri.eranen@kesko.fi",
        },
    };

    public override OpenApiVersionType OpenApiVersion { get; set; } = OpenApiVersionType.V3;
}