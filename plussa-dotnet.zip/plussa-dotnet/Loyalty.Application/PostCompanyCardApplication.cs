using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Logging;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using System.Net.Mime;
using Loyalty.Domain.Contracts.Request;
using System.Threading;
using FluentValidation;
using Loyalty.Common.Services;
using Loyalty.Common.Functions;
using System.Net.Http;

using Loyalty.Domain.Entities.Cosmos;
using Mapster;

namespace Loyalty.Application
{
    public class PostCompanyCardApplication : HttpEndpointFunctionWithBody<PostCompanyCardApplication, PostCompanyCardApplicationCreation>
    {
        
        private readonly IApplicationService _saveApplication;
        private readonly ISendEmailService _sendEmailService;
        private readonly IConfigurationService _configurationService;

        public PostCompanyCardApplication(
            ILogger<PostCompanyCardApplication> log,
            IValidator<PostCompanyCardApplicationCreation> validator,
            IApplicationService saveApplication,
            ISendEmailService sendEmailService,
            IConfigurationService configurationService) : base(log, validator)
        {
            _saveApplication = saveApplication;
            _sendEmailService = sendEmailService;
            _configurationService = configurationService;
        }

        [FunctionName("PostCompanyCardApplication")]
        [OpenApiOperation(operationId: "post-company-card-appliation",
            tags: new[] { "loyalty" },
            Summary = "Company Card Application",
            Description = "Application to create a new company card",
            Visibility = OpenApiVisibilityType.Important
            )]
        [OpenApiRequestBody(
            MediaTypeNames.Application.Json,
            typeof(PostCompanyCardApplicationCreation))]
        [OpenApiResponseWithoutBody(HttpStatusCode.Accepted, Description = "The OK response")]
        [OpenApiResponseWithoutBody(HttpStatusCode.BadRequest, Description = "Bad request")]
        [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "application/company-card")]
            HttpRequestMessage request,
            CancellationToken token)
        {

            return await HandleHttpRequest(async () =>
            {
                var dto = await ValidateFromBodyAsync(request, token);

                await _saveApplication.CreateApplicationAsync(dto.Adapt<CompanyCardApplication>(),token);
                var emailRecipientList = await _configurationService.GetCompanyCardEmailRecipients(token);
                if(emailRecipientList != null && emailRecipientList.Length > 0)
                {
                    await _sendEmailService.SendCompanyCardEmail(emailRecipientList, dto, token);
                }
                
                return new AcceptedResult();
            });
        }

    }
}

