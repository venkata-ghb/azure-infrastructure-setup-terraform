using FluentValidation;
using Loyalty.Common.Constants.CLM;
using Loyalty.Common.Exceptions;
using Loyalty.Common.Extensions;
using Loyalty.Common.Extensions.Clm;
using Loyalty.Common.Functions;
using Loyalty.Common.Services;
using Loyalty.Common.Services.Authorization;
using Loyalty.Domain.Contracts.Request;
using Loyalty.Domain.Contracts.Request.Clm;
using Loyalty.Domain.Contracts.Responses;
using Loyalty.Domain.Entities.Clm;
using Loyalty.Domain.Enums;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;

namespace Loyalty.Application
{
    public class PostPlussaCardApplicationApplePay : HttpEndpointFunctionWithoutBody<PostPlussaCardApplicationApplePay>
    {
        private readonly ISearchService _searchService;
        private readonly ICardService _cardService;
        private readonly ICustomerService _customerService;
        private readonly IIdentityService _identityService;
        private const string Kid1_Prefix = "auth0|kid1";
        private const string IdentifierTypeCode = IdentifierTypes.ApplePay;

        public PostPlussaCardApplicationApplePay(ILogger<PostPlussaCardApplicationApplePay> log,
            ISearchService searchService,
            IIdentityService identityService,
            ICustomerService customerService,
            ICardService cardService) : base(log)
        {
            _searchService = searchService;
            _cardService = cardService;
            _customerService = customerService;
            _identityService = identityService;
        }

        [FunctionName("PostPlussaCardApplicationApplePay")]
        [OpenApiOperation(operationId: "post-plussa-card-apple-pay-application",
            tags: new[] { "loyalty", "AP" },
            Summary = "New plussa card apple pay application",
            Description = "Application to create a new plussa card for apple pay",
            Visibility = OpenApiVisibilityType.Important)]
        [OpenApiParameter(name: "kid", In = ParameterLocation.Path, Required = true, Type = typeof(string), Description = "KID user id")]
        [OpenApiResponseWithBody(
        statusCode: HttpStatusCode.OK,
        contentType: MediaTypeNames.Application.Json,
        bodyType: typeof(PostPlussaCardApplicationApplePayResponse),
        Description = "Newly generated loyalty plussa card number")]
        [OpenApiResponseWithoutBody(HttpStatusCode.Unauthorized, Description = "Access denied due to invalid subscription key. Make sure to provide a valid key for an active subscription.")]
        [OpenApiResponseWithoutBody(HttpStatusCode.BadRequest, Description = "Bad request")]
        [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error")]
        public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "application/plussa-card-apple-pay/{kid}")]
        HttpRequestMessage request,
        string kid,
        CancellationToken token)
        {
            return await HandleHttpRequest(async () =>
            {
                
                //k-id1 check
                kid = kid.StartsWith(Kid1_Prefix) ? kid.Split("|").Last() : kid;

                var kidIdentity = await _identityService.GetIdentity(kid, token);
                var personId = kidIdentity.PersonId;

                var searchQuery = GenerateSearchQuery(personId.ToString());

                var accountSummaryData = await _searchService.Search(searchQuery, token);

                var customerSummary = accountSummaryData.Select(x => x.Customers.FirstOrDefault(y => y.Id == personId));
                var customer = customerSummary.FirstOrDefault(x => x.Id == personId);

                var tierData = await _customerService.GetCustomerBestTiers(personId, token);

                var customerStatus = tierData.Length == 0 ? "NORMAL" : tierData[0].SchemaCode.ToString();

                var existingMobilePayCards = customer.Identifiers.FirstOrDefault(identifier => identifier.IdentifierTypeCode == IdentifierTypeCode && identifier.Status == CardStatus.Active);

                if (existingMobilePayCards != null)
                {
                    return new OkObjectResult(new PostPlussaCardApplicationApplePayResponse(existingMobilePayCards.IdentifierNo, customer.FirstName, customer.LastName, customerStatus, message: "Existing Apple Pay Card"));
                }

                var newCardNo = await _cardService.RequestNewCardForCustomer(customer.Id, IdentifierTypeCode, token);

                return new OkObjectResult(new PostPlussaCardApplicationApplePayResponse(newCardNo, customer.FirstName, customer.LastName, customerStatus));
            });
        }

        private static SearchRequestExt GenerateSearchQuery(string customerId) =>
            new SearchRequestExt
            {
                Customer = new()
                {
                    CustomerId = int.Parse(customerId),
                    Status = Statuses.Active
                }
            };
    }
}