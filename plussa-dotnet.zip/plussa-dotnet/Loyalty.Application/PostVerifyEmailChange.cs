using System.Net;
using System.Net.Http;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using FluentValidation;
using Loyalty.Common.Examples;
using Loyalty.Common.Extensions.Clm;
using Loyalty.Common.Factories;
using Loyalty.Common.Functions;
using Loyalty.Common.Services;
using Loyalty.Domain.Contracts.Request;
using Loyalty.Domain.Entities.Cosmos;
using Loyalty.Domain.Enums;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;
using System.Linq;

namespace Loyalty.Application;

public class PostVerifyEmailChange : HttpEndpointFunctionWithBody<PostVerifyEmailChange, VerifyEmail>
{
    private readonly ITokenVerificationService _tokenVerificationService;
    private readonly IApplicationService _applicationService;
    private readonly ApplicationEnrollmentFactory _applicationEnrollmentFactory;
    private readonly ISearchService _searchService;

    public PostVerifyEmailChange(
        ILogger<PostVerifyEmailChange> log,
        IValidator<VerifyEmail> validator,
        ITokenVerificationService tokenVerificationService,
        IApplicationService applicationService,
        ISearchService searchService,
        ApplicationEnrollmentFactory applicationEnrollmentFactory) : base(log, validator)
    {
        _tokenVerificationService = tokenVerificationService;
        _applicationService = applicationService;
        _applicationEnrollmentFactory = applicationEnrollmentFactory;
        _searchService = searchService;
    }

    [FunctionName(nameof(PostVerifyEmailChange))]
    [OpenApiOperation(operationId: "post-verify-email-change",
        Summary = "Verify email change",
        Description = "Api to verify email address change for existing user",
        Visibility = OpenApiVisibilityType.Important
    )]
    [OpenApiRequestBody(
        MediaTypeNames.Application.Json,
        typeof(VerifyEmail),
        Example = typeof(VerifyEmailExample))]
    [OpenApiResponseWithoutBody(HttpStatusCode.Accepted, Description = "The OK response")]
    [OpenApiResponseWithoutBody(HttpStatusCode.Forbidden, Description = "Given token is invalid")]
    [OpenApiResponseWithoutBody(HttpStatusCode.BadRequest, Description = "Bad request")]
    [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error")]
    public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "verify-email-change")]
        HttpRequestMessage request,
        CancellationToken ct)
    {
        return await HandleHttpRequest(async () =>
        {
            var dto = await ValidateFromBodyAsync(request, ct);

            var verifiedToken = await _tokenVerificationService.VerifyToken(dto, ct, ApplicationTypes.NE);
            var application = await _applicationService.GetApplicationByTokenAsync<EmailChangeApplication>(
                verifiedToken, ct);

            var searchRequest = ClmQueryExtensions.CustomerIdSearchContract(application.CustomerId);
            var customer = await _searchService.Search(searchRequest, ct);

            if (customer.FirstOrDefault().Customers.Where(cust => cust.Id == application.CustomerId).FirstOrDefault().Address.Email.ToLower() == application.EmailAddress.ToLower())
            {
                await _tokenVerificationService.DeleteVerifiedToken(verifiedToken, ct);
            }
            else
            {
                await _applicationEnrollmentFactory
                .CreateVerifyEmailChange()
                .HandleApplication(application, ct);
                await _tokenVerificationService.DeleteVerifiedToken(verifiedToken, ct);
            }

            return new AcceptedResult();
        });
    }
}
