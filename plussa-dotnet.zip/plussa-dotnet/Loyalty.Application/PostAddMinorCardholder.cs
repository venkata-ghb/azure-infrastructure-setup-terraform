using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using FluentValidation;
using Loyalty.Common.Configuration;
using Loyalty.Common.Constants.CLM;
using Loyalty.Common.Examples;
using Loyalty.Common.Extensions;
using Loyalty.Common.Extensions.Clm;
using Loyalty.Common.Factories;
using Loyalty.Common.Functions;
using Loyalty.Common.Services;
using Loyalty.Common.Services.Authorization;
using Loyalty.Domain.Contracts.Request;
using Loyalty.Domain.Contracts.Request.Clm;
using Loyalty.Domain.Entities;
using Loyalty.Domain.Entities.Clm;
using Loyalty.Domain.Entities.Cosmos;
using Loyalty.Domain.Enums;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Models;

namespace Loyalty.Application;

public class PostAddMinorCardholder : HttpEndpointFunctionWithBody<PostAddMinorCardholder, PostAddMinorCardholderRequest>
{
    private readonly ILogger<PostAddMinorCardholder> _log;
    private readonly ICustomerService _customerService;
    private readonly IAccountService _accountService;
    private readonly ISendEmailService _sendEmailService;
    private readonly ApplicationEnrollmentFactory _applicationEnrollmentFactory;
    private readonly ICustomerMatchingService _customerMatchingService;
    private readonly IAuthenticationValidator _authenticationValidator;
    private readonly IBarcodeGeneratorService _barcodeGenerator;
    private readonly ServiceConfiguration _configuration;

    public PostAddMinorCardholder(
        ILogger<PostAddMinorCardholder> log,
        IAuthenticationValidator authenticationValidator,
        IValidator<PostAddMinorCardholderRequest> validator,
        ICustomerService customerService,
        IAccountService accountService,
    IServiceDependencyResolverFactory resolver,
        ISendEmailService sendEmailService,
        ApplicationEnrollmentFactory applicationEnrollmentFactory,
        ICustomerMatchingService customerMatchingService,
        IBarcodeGeneratorService barcodeGenerator,
        IOptions<ServiceConfiguration> configuration
        ) : base(log, validator)
    {
        _log = log;
        _customerService = customerService;
        _accountService = accountService;
        _sendEmailService = sendEmailService;
        _applicationEnrollmentFactory = applicationEnrollmentFactory;
        _customerMatchingService = customerMatchingService;
        _authenticationValidator = authenticationValidator;
        _barcodeGenerator = barcodeGenerator;
        _configuration = configuration.Value;
    }

    [FunctionName(nameof(PostAddMinorCardholder))]
    [OpenApiOperation(operationId: "post-add-minor-cardholder",
        tags: new[] { "loyalty" },
        Summary = "Head of a household adds minor parallel cardholder",
        Description = "Head of a household adds minor parallel cardholder",
        Visibility = OpenApiVisibilityType.Important
    )]
    [OpenApiRequestBody(
        MediaTypeNames.Application.Json,
        typeof(PostAddMinorCardholderRequest),
        Example = typeof(PostAddMinorCardholderRequestExample))]
    [OpenApiSecurity("Authorization",
        SecuritySchemeType.ApiKey,
        Name = "Authorization",
        In = OpenApiSecurityLocationType.Header)]
    [OpenApiResponseWithoutBody(HttpStatusCode.Accepted, Description = "Successfully added minor parallel cardholder")]
    [OpenApiResponseWithoutBody(HttpStatusCode.Unauthorized,
        Description =
            "Access denied due to invalid subscription key. Make sure to provide a valid key for an active subscription.")]
    [OpenApiResponseWithoutBody(HttpStatusCode.Forbidden,
        Description = "Given token is invalid or customer is not head of a household")]
    [OpenApiResponseWithoutBody(HttpStatusCode.Conflict, Description = "Customer already exists")]
    [OpenApiResponseWithoutBody(HttpStatusCode.BadRequest, Description = "Bad request or email address belongs to the main cardholder")]
    [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error")]
    public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "minor-cardholder")]
        HttpRequestMessage request,
        CancellationToken token)
    {
        return await HandleHttpRequest(async () =>
        {
            var userId = await _authenticationValidator.ValidateProfileScopesAsync(request.Headers, token, true);
            var dto = await ValidateFromBodyAsync(request, token);
            var customer = await _customerService.GetCustomer(userId, token);
            var account = await _accountService.GetAccountDetails(customer.AccountId, token);
            if (account.OwnerCustomerId != customer.Id)
            {
                return new StatusCodeResult(StatusCodes.Status403Forbidden);
            }

            if (!string.IsNullOrWhiteSpace(dto.EmailAddress) && dto.EmailAddress.Equals(customer.Address.Email, StringComparison.OrdinalIgnoreCase))
            {
                return new BadRequestObjectResult("The email address belongs to the main cardholder.");
            }

            var searchParams = new PersonExistsSearchEntity
            {
                FirstName = dto.FirstName.Trim(),
                LastName = dto.LastName.Trim(),
                EmailAddress = dto.EmailAddress,
                NationalIdentificationNumber = dto.Ssn,
                BirthDate = dto.DateOfBirth.ToString("yyyy-MM-dd"),
                StreetAddress = customer.Address.Street,
                PostCode = customer.Address.PostalCode
            };
            var searchQueries = new List<Func<PersonExistsSearchEntity, SearchRequestExt>>
            {
                ClmQueryExtensions.NameAddressBirthDateSearchContract
            };
            if (!string.IsNullOrEmpty(dto.EmailAddress))
            {
                searchQueries.Add(ClmQueryExtensions.EmailAddressSearchContract);
            }
            if (!string.IsNullOrWhiteSpace(dto.Ssn)
                && !string.IsNullOrWhiteSpace(dto.FirstName.Trim())
                && !string.IsNullOrWhiteSpace(dto.LastName.Trim()))
            {
                searchQueries.Add(ClmQueryExtensions.NationalIdentificationSearchContract);
            }
            var searchQueryGroup = new ClmQueryList(searchQueries.ToArray());
            var customerExists = await _customerMatchingService.CustomerExists(searchParams, searchQueryGroup, token);
            if (customerExists)
            {
                return new ConflictObjectResult("Customer already exists");
            }

            var permissions = ApplicationExtensions.CreatePermissions(false);
            var customerAttributes = new List<AttributeExt>();
            if (dto.PurchaseRecordingLevel != null)
            {
                customerAttributes.Add(new AttributeExt
                {
                    Code = CustomerAttributes.PurchaseRecordingLevel,
                    Value = dto.PurchaseRecordingLevel.GetEnumMember().Value
                });
            }
            var application = ChildApplicationEnrollment.FromDto(dto, dto.DigitalCardOnly ? IdentifierTypes.PlussaDigi : IdentifierTypes.Webkateis, customer, permissions, customerAttributes.ToArray());
            var resp = await _applicationEnrollmentFactory.CreateParallelChildApplication()
                .HandleApplication(application, token);

            var cardType = application.IdentifierType.ToLower() == "plussadigi" ? "plussadigi" : "webkaties";
            var barcode = _barcodeGenerator.BarcodeGenerator(resp.CardNumber, token);
            await _sendEmailService.SendMinonrEmailWithBarcode(application.Language, dto.EmailAddress, barcode, cardType, application.ApplicationType.ToString(), customer.FirstName, customer.LastName, resp.CardNumber, token);

            _log.LogInformation("Child application was enrolled to customer id {CustomerId}", customer.Id);
            return new AcceptedResult();
        });
    }
}