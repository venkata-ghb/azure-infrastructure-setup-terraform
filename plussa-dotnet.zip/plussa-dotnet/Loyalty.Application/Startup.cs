﻿using FluentValidation;
using Loyalty.Common.Extensions;
using Loyalty.Common.Extensions.Telemetry;
using Loyalty.Common.Factories;
using Loyalty.Common.Services;
using Loyalty.Common.Services.Authorization;
using Loyalty.Common.Validators;
using Loyalty.Domain.Enums;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.IO;

[assembly: FunctionsStartup(typeof(Loyalty.Application.Startup))]
namespace Loyalty.Application
{
    public class Startup : FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)
        {
            builder.Services.AddCosmos();
            builder.Services.AddEmail();
            builder.Services.AddKIdCoreServices();
            builder.Services.ConfigureTelemetryProcessor();
            builder.Services.ConfigureSerialization();
            builder.Services.AddClmCoreServices();
            builder.Services.AddMemoryCache();
            builder.Services.AddKIdCoreServices();
            builder.Services.AddCardServices();
            builder.Services.AddValidatorsFromAssemblyContaining<PostPersonExistsWithContactInfoValidator>();
            builder.Services.AddServiceConfiguration();

            builder.Services.AddCardServiceHttpClientCertificate();

            builder.Services.AddScoped<ISearchService, SearchService>();
            builder.Services.AddScoped<ICustomerMatchingService, CustomerMatchingService>();
            builder.Services.AddScoped<ICustomerService, CustomerService>();
            builder.Services.AddScoped<IApplicationService, ApplicationService>();
            builder.Services.AddScoped<IMetadataService, MetadataService>();
            builder.Services.AddScoped<ISendEmailService, SendEmailService>();
            builder.Services.AddScoped<ITokenVerificationService, TokenVerificationService>();
            builder.Services.AddScoped<IApplicationEnrollmentService, ApplicationEnrollmentService>();
            builder.Services.AddScoped<IBarcodeGeneratorService, BarcodeGeneratorService>();
            builder.Services.AddScoped<IAccountService, AccountService>();
            builder.Services.AddScoped<ICustomerService, CustomerService>();
            builder.Services.AddScoped<IIdentityService, IdentityService>();
            builder.Services.AddScoped<IAuthenticationValidator, AuthenticationValidator>();
            builder.Services.AddScoped<IServiceDependencyResolverFactory, ServiceDependencyResolverFactory>();
            builder.Services.AddScoped<ApplicationEnrollmentFactory>();
            builder.Services.AddScoped<ICardService, CardService>();
            builder.Services.AddScoped<IConfigurationService, ConfigurationService>();
            builder.Services.AddMultiSourceServices(new ServiceType[] { ServiceType.CustomerService, ServiceType.CustomerServiceDB, ServiceType.AssignmentService, ServiceType.AssignmentServiceDB, ServiceType.CardService, ServiceType.CardServiceDB, ServiceType.SearchService, ServiceType.SearchServiceDB, ServiceType.AccountService, ServiceType.AccountServiceDB });
            MapsterExtension.RegisterMapsterConfiguration();
        }




        public override void ConfigureAppConfiguration(IFunctionsConfigurationBuilder builder)
        {
            var context = builder.GetContext();
            builder.ConfigurationBuilder
                .AddJsonFile(Path.Combine(context.ApplicationRootPath, "local.settings.json"), optional: true, reloadOnChange: false)
                .AddEnvironmentVariables();
        }
    }
}
