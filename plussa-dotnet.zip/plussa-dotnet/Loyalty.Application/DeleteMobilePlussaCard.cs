using Loyalty.Common.Functions;
using Loyalty.Common.Services;
using Loyalty.Domain.Contracts.Responses;
using Loyalty.Domain.Enums;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using System.Net;
using System.Net.Http;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;

namespace Loyalty.Application
{
    public class DeleteMobilePlussaCard : HttpEndpointFunctionWithoutBody<DeleteMobilePlussaCard>
    {
        private const string CloseCardReason = "Close card requested by MobilePlussaCard";
        private readonly ICardService _cardService;

        public DeleteMobilePlussaCard(
            ILogger<DeleteMobilePlussaCard> log,
            ICardService cardService) : base(log)
        {
            _cardService = cardService;
        }

        [FunctionName(nameof(DeleteMobilePlussaCard))]
        [OpenApiOperation(operationId: "delete-mobile-plussa-card-application",
            tags: new[] { "loyalty" },
            Summary = "Delete mobile plussa card application",
            Description = "Application to delete an existing mobile plussa card.",
            Visibility = OpenApiVisibilityType.Important
        )]
        [OpenApiParameter("cardNumber", Required = true, Type = typeof(string), In = ParameterLocation.Path)]
        [OpenApiResponseWithBody(
            HttpStatusCode.OK,
            bodyType: typeof(DeletePlussaCardResponse),
            contentType: MediaTypeNames.Application.Json,
            Description = "Delete request accepted. Card will be deleted.")]
        [OpenApiResponseWithBody(
            HttpStatusCode.BadRequest,
            bodyType: typeof(string),
            contentType: MediaTypeNames.Text.Plain,
            Description = "Malformed request. Error details in response body.")]
        [OpenApiResponseWithoutBody(HttpStatusCode.Forbidden,
        Description = "Calling principal not authorized to delete given card: either they are not acting on behalf of the owner or the card type cannot be managed by self-service API. Caller must own the card. 'profile' scope required.")]
        [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "delete", Route = "mobile-plussa-card/{cardNumber}")] HttpRequestMessage request, string cardNumber, CancellationToken ct)
        {

            return await HandleHttpRequest(async () =>
            {
                if (string.IsNullOrWhiteSpace(cardNumber))
                {
                    return new BadRequestObjectResult(nameof(cardNumber));
                }

                var cardToClose = await _cardService.GetIdentifierByCardNumber(cardNumber, ct);

                if (cardToClose.IdentifierNo != cardNumber)
                {
                    return new StatusCodeResult(StatusCodes.Status403Forbidden);
                }

                if (!_cardService.IsModifyMobilePlussaCardTypeAllowed(cardToClose.IdentifierTypeCode))
                {
                    return new StatusCodeResult(StatusCodes.Status403Forbidden);
                }

                // Make the function idempotent -- do not attempt to close a closed card; this would result
                // CLM responding with internal server error
                if (cardToClose.Status == CardStatus.Closed) return new OkObjectResult(new DeletePlussaCardResponse("false"));

                // Close the card
                await _cardService.CloseCardByCardNumber(cardNumber, CloseCardReason, ct);

                Logger.LogDebug("Mobile plussa closed card {0} citing '{1}'", cardNumber, "");

                return new OkObjectResult(new DeletePlussaCardResponse("true"));
            });
        }
    }
}

