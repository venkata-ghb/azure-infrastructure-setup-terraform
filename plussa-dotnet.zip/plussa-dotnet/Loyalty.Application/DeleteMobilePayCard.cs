using Loyalty.Common.Functions;
using Loyalty.Common.Services;
using Loyalty.Domain.Contracts.Responses;
using Loyalty.Domain.Enums;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using System.Net;
using System.Net.Http;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;

namespace Loyalty.Application
{
    public class DeleteMobilePayCard : HttpEndpointFunctionWithoutBody<DeleteMobilePayCard>
    {
        private const string CloseCardReason = "Close card requested by MobilePay";
        private readonly ICardService _cardService;

        public DeleteMobilePayCard(
            ILogger<DeleteMobilePayCard> log,
            ICardService cardService) : base(log)
        {
            _cardService = cardService;
        }

        [FunctionName(nameof(DeleteMobilePayCard))]
        [OpenApiOperation(operationId: "delete-mobile-pay-card-application",
            tags: new[] { "loyalty" },
            Summary = "Delete mobile pay card application",
            Description = "Application to delete an existing mobile pay card.",
            Visibility = OpenApiVisibilityType.Important
        )]
        [OpenApiParameter("cardNumber", Required = true, Type = typeof(string), In = ParameterLocation.Path)]
        [OpenApiResponseWithBody(
            HttpStatusCode.OK,
            bodyType: typeof(DeletePlussaCardResponse),
            contentType: MediaTypeNames.Application.Json,
            Description = "Delete request accepted. Card will be deleted.")]
        [OpenApiResponseWithBody(
            HttpStatusCode.BadRequest,
            bodyType: typeof(string),
            contentType: MediaTypeNames.Text.Plain,
            Description = "Malformed request. Error details in response body.")]
        [OpenApiResponseWithoutBody(HttpStatusCode.Forbidden,
        Description = "Calling principal not authorized to delete given card: either they are not acting on behalf of the owner or the card type cannot be managed by self-service API. Caller must own the card. 'profile' scope required.")]
        [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "application/partner-mobile-card-delete/{cardNumber}")] HttpRequestMessage request, string cardNumber, CancellationToken ct)
        {

            return await HandleHttpRequest(async () =>
            {
                if (string.IsNullOrWhiteSpace(cardNumber))
                {
                    return new BadRequestObjectResult(nameof(cardNumber));
                }

                var cardToClose = await _cardService.GetIdentifierByCardNumber(cardNumber, ct);

                if (cardToClose.IdentifierNo != cardNumber)
                {
                    return new StatusCodeResult(StatusCodes.Status403Forbidden);
                }

                if (!_cardService.IsModifyMobilePayCardTypeAllowed(cardToClose.IdentifierTypeCode))
                {
                    return new StatusCodeResult(StatusCodes.Status403Forbidden);
                }

                // Make the function idempotent -- do not attempt to close a closed card; this would result
                // CLM responding with internal server error
                if (cardToClose.Status == CardStatus.Closed) return new OkObjectResult(new DeletePlussaCardResponse("false"));

                // Close the card
                await _cardService.CloseCardByCardNumber(cardNumber, CloseCardReason, ct);

                Logger.LogDebug("Mobile Pay closed card {0} citing '{1}'", cardNumber, "");

                return new OkObjectResult(new DeletePlussaCardResponse("true"));
            });
        }
    }
}

