using FluentValidation;
using Loyalty.Common.Examples;
using Loyalty.Common.Functions;
using Loyalty.Common.Services;
using Loyalty.Domain.Contracts.Request;
using Loyalty.Domain.Contracts.Responses;
using Loyalty.Domain.Enums;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using System.Net;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;

namespace Loyalty.Application
{
    public class PostPlussaCardDeleteNL : HttpEndpointFunctionWithBody<PostPlussaCardDeleteNL, PostPlussaCardDeleteNLRequest>
    {
        private const string CloseCardReason = "Close card requested by NL PlussaCard application";
        private readonly ICardService _cardService;
        private readonly IValidator<PostPlussaCardDeleteNLRequest> _validator;

        public PostPlussaCardDeleteNL(
            ILogger<PostPlussaCardDeleteNL> log,
            IValidator<PostPlussaCardDeleteNLRequest> validator,
            ICardService cardService) : base(log, validator)
        {
            _cardService = cardService;
            _validator = validator;

        }

        [FunctionName(nameof(PostPlussaCardDeleteNL))]
        [OpenApiOperation(operationId: "delete-plussa-card-application-nl",
            tags: new[] { "loyalty", "NL" },
            Summary = "Delete plussa card application for NL",
            Description = "Application to delete an existing plussa card for NL.",
            Visibility = OpenApiVisibilityType.Important
        )]
        [OpenApiRequestBody(
            MediaTypeNames.Application.Json,
            typeof(PostPlussaCardDeleteNLRequest),
            Example = typeof(PostPlussaCardDeleteNLRequestExample))]
        [OpenApiResponseWithBody(
            HttpStatusCode.OK,
            bodyType: typeof(DeletePlussaCardResponse),
            contentType: MediaTypeNames.Application.Json,
            Description = "Delete request accepted. Card will be deleted.")]
        [OpenApiResponseWithBody(
            HttpStatusCode.BadRequest,
            bodyType: typeof(string),
            contentType: MediaTypeNames.Text.Plain,
            Description = "Malformed request. Error details in response body.")]
        [OpenApiResponseWithoutBody(HttpStatusCode.Forbidden,
        Description = "Calling principal not authorized to delete given card: either they are not acting on behalf of the owner or the card type cannot be managed by self-service API. Caller must own the card.")]
        [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "application/plussacard/delete")]
            PostPlussaCardDeleteNLRequest postPlussaCardDeleteNLRequest,
            CancellationToken ct)
        {

            return await HandleHttpRequest(async () =>
            {
                var requestValidationResult = await _validator.ValidateAsync(postPlussaCardDeleteNLRequest, ct);
                if (!requestValidationResult.IsValid)
                {
                    return new BadRequestObjectResult(requestValidationResult.ToString());
                }

                var cardNumber = postPlussaCardDeleteNLRequest.CardNumber;

                if (string.IsNullOrWhiteSpace(cardNumber) || !_cardService.IsValidNLPlussaCardSeries(cardNumber))
                {
                    return new BadRequestObjectResult(nameof(cardNumber));
                }

                var cardToClose = await _cardService.GetIdentifierByCardNumber(cardNumber, ct);

                if (cardToClose.IdentifierNo != cardNumber)
                {
                    return new StatusCodeResult(StatusCodes.Status403Forbidden);
                }

                if (!_cardService.IsModifyNLPlussaCardTypeAllowed(cardToClose.IdentifierTypeCode))
                {
                    return new StatusCodeResult(StatusCodes.Status403Forbidden);
                }

                // Make the function idempotent -- do not attempt to close a closed card; this would result
                // CLM responding with internal server error
                if (cardToClose.Status == CardStatus.Closed) return new OkObjectResult(new DeletePlussaCardResponse("false"));

                // Close the card
                await _cardService.CloseCardByCardNumber(cardNumber, CloseCardReason, ct);

                Logger.LogDebug("NL plussa closed card {0} citing '{1}'", cardNumber, "");

                return new OkObjectResult(new DeletePlussaCardResponse("true"));
            });
        }
    }
}

