using FluentValidation;
using Loyalty.Common.Constants.CLM;
using Loyalty.Common.Exceptions;
using Loyalty.Common.Extensions;
using Loyalty.Common.Extensions.Clm;
using Loyalty.Common.Functions;
using Loyalty.Common.Services;
using Loyalty.Domain.Contracts.Request;
using Loyalty.Domain.Contracts.Responses;
using Loyalty.Domain.Enums;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using System.Linq;
using System.Net;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;

namespace Loyalty.Application
{
    public class GetMobileCardApplicationMobilePay : HttpEndpointFunctionWithoutBody<GetMobileCardApplicationMobilePay>
    {
        private readonly ISearchService _searchService;
        private readonly ICardService _cardService;
        private readonly IValidator<GetMobileCardApplicationMobilePayRequest> _validator;
        private const int MaxAllowedMobileCards = 5;
        private const string IdentifierTypeCode = IdentifierTypes.MobilePlussaCard;

        public GetMobileCardApplicationMobilePay(ILogger<GetMobileCardApplicationMobilePay> log,
            IValidator<GetMobileCardApplicationMobilePayRequest> validator,
            ISearchService searchService,
            ICardService cardService) : base(log)
        {
            _searchService = searchService;
            _validator = validator;
            _cardService = cardService;
        }

        [FunctionName("GetMobileCardApplicationMobilePay")]
        [OpenApiOperation(operationId: "get-mobile-card-application",
            tags: new[] { "loyalty" },
            Summary = "New plussa card application",
            Description = "Application to create a new plussa card depending on application type",
            Visibility = OpenApiVisibilityType.Important)]
        [OpenApiParameter(name: nameof(GetMobileCardApplicationMobilePayRequest.FirstName), In = ParameterLocation.Query, Description = "First name on card.", Required = true, Type = typeof(string))]
        [OpenApiParameter(name: nameof(GetMobileCardApplicationMobilePayRequest.LastName), In = ParameterLocation.Query, Description = "Last name on card.", Required = true, Type = typeof(string))]
        [OpenApiParameter(name: nameof(GetMobileCardApplicationMobilePayRequest.AppId), In = ParameterLocation.Query, Description = "Card application Id", Required = true, Type = typeof(string))]
        [OpenApiParameter(name: "cardNumber", In = ParameterLocation.Path, Required = true, Type = typeof(string), Description = "Loyalty card number")]
        [OpenApiResponseWithBody(
        statusCode: HttpStatusCode.OK,
        contentType: MediaTypeNames.Application.Json,
        bodyType: typeof(GetMobileCardApplicationMobilePayResponse),
        Description = "Newly generated loyalty mobile card number")]
        [OpenApiResponseWithoutBody(HttpStatusCode.BadRequest, Description = "Bad request")]
        [OpenApiResponseWithoutBody(HttpStatusCode.InternalServerError, Description = "Internal server error")]
        public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "application/mobile-card/{cardNumber}")]
        GetMobileCardApplicationMobilePayRequest getMobileCardApplicationMobilePayRequest,
        CancellationToken token)
        {
            return await HandleHttpRequest(async () =>
            {
                var requestValidationResult = await _validator.ValidateAsync(getMobileCardApplicationMobilePayRequest, token);
                if (!requestValidationResult.IsValid)
                {
                    return new BadRequestObjectResult(requestValidationResult.ToString());
                }
                var searchQuery = ClmQueryExtensions.LoyaltyCardSearchRequest(getMobileCardApplicationMobilePayRequest.CardNumber);
                var accountSummaryData = await _searchService.Search(searchQuery, token);
                var firstname = getMobileCardApplicationMobilePayRequest.FirstName.ToLowerInvariant().Split(' ');
                var lastName = getMobileCardApplicationMobilePayRequest.LastName.ToLowerInvariant();
                var cardValidationResult = accountSummaryData.ValidateCard(getMobileCardApplicationMobilePayRequest.CardNumber, firstname, lastName);

                if (cardValidationResult == CardValidationStatus.UserNotFound)
                {
                    return new BadRequestObjectResult("User with given details was not found.");
                }
                else if (cardValidationResult == CardValidationStatus.CardNotFound)
                {
                    return new BadRequestObjectResult("Card with given number was not found.");
                }

                var account = accountSummaryData.FirstOrDefault(x => x.Identifiers.Any(y => y.IdentifierNo.Equals(getMobileCardApplicationMobilePayRequest.CardNumber)))
                    ?? throw new NotFoundException("CLM did not return such account.");

                var customer = account.Customers.FirstOrDefault(x => x.Identifiers.Any(y => y.IdentifierNo.Equals(getMobileCardApplicationMobilePayRequest.CardNumber) && y.Status == CardStatus.Active));

                // commented kept for time being
                // Here we are checking if type is PlussaMob2 then assign accordingly
                //var identifierTypeCode = IdentifierTypes.MobilePlussaCard;
                //if (getMobileCardApplicationMobilePayRequest.AppId.Equals(IdentifierTypes.MobilePlussaCard, StringComparison.OrdinalIgnoreCase))
                //{
                //    identifierTypeCode = IdentifierTypes.MobilePlussaCard;
                //}

                var existingMobilePayCards = customer.Identifiers.Count(identifier => identifier.IdentifierTypeCode == IdentifierTypeCode && identifier.Status == CardStatus.Active);

                if (existingMobilePayCards >= MaxAllowedMobileCards)
                {
                    return new BadRequestObjectResult($"User cannot apply for more than {MaxAllowedMobileCards} mobile cards");
                }

                var newCardNo = await _cardService.RequestNewCardForCustomer(customer.Id, IdentifierTypeCode, token);

                return new OkObjectResult(new GetMobileCardApplicationMobilePayResponse(newCardNo));
            });
        }
    }
}