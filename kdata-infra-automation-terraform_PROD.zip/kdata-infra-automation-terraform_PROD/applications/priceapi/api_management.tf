data "azurerm_api_management" "apimanagement" {
  provider            = azurerm.apim
  name                = "K-apim-${var.env}"
  resource_group_name = "KESKO_WE_RG_APIM_${upper(var.env)}001"
}


resource "azurerm_api_management_api" "price" {
  provider            = azurerm.apim
  name                = "kdata-price-input-api"
  resource_group_name = data.azurerm_api_management.apimanagement.resource_group_name
  api_management_name = data.azurerm_api_management.apimanagement.name
  revision            = "1"
  display_name        = "K-data price Input API"
  path                = "kdata/price-input-api"
  protocols           = ["https"]

  import {
    content_format = "openapi+json"
    content_value  = file("${path.module}/resources/openapi.json")
  }
}


resource "azurerm_api_management_api_policy" "price" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.price.name
  api_management_name = azurerm_api_management_api.price.api_management_name
  resource_group_name = azurerm_api_management_api.price.resource_group_name
  xml_content         = <<XML
  <policies>
      <inbound>
        <base />
        <authentication-managed-identity resource="https://${data.terraform_remote_state.integrations.outputs.ehns_priceapi.name}.servicebus.windows.net" />
    </inbound>
     <backend>
        <base />
    </backend>
    </policies>
XML
}

resource "azurerm_api_management_api_operation_policy" "price-putrecords" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.price.name
  api_management_name = azurerm_api_management_api.price.api_management_name
  resource_group_name = azurerm_api_management_api.price.resource_group_name
  operation_id        = "post-putrecords"

  xml_content = <<XML
<policies>
                <inbound>
                        <base />
                        <set-backend-service base-url="https://${data.terraform_remote_state.integrations.outputs.ehns_priceapi.name}.servicebus.windows.net/priceapi-input/messages" />
                        <rewrite-uri template="/" />
                </inbound>
                <backend>
                        <base />
                </backend>
                <outbound>
                        <base />
                </outbound>
                <on-error>
                        <base />
                </on-error>
</policies>
XML
}

resource "azurerm_api_management_api_operation_policy" "prices-store_prices" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.price.name
  api_management_name = azurerm_api_management_api.price.api_management_name
  resource_group_name = azurerm_api_management_api.price.resource_group_name
  operation_id        = "post-store-prices"

  xml_content = <<XML
<policies>
  <inbound>
    <base />
    <set-backend-service base-url="https://${data.terraform_remote_state.integrations.outputs.ehns_priceapi.name}.servicebus.windows.net/priceapi-store-prices/messages" />
    <rewrite-uri template="/" />
  </inbound>
  <backend>
    <base />
  </backend>
  <outbound>
    <base />
  </outbound>
  <on-error>
    <base />
  </on-error>
</policies>
XML
}

resource "azurerm_api_management_api_operation_policy" "prices-store_prices_v2" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.price.name
  api_management_name = azurerm_api_management_api.price.api_management_name
  resource_group_name = azurerm_api_management_api.price.resource_group_name
  operation_id        = "post-store-prices-v2"

  xml_content = <<XML
<policies>
  <inbound>
    <base />
    <set-backend-service base-url="https://${data.terraform_remote_state.integrations.outputs.ehns_priceapi.name}.servicebus.windows.net/priceapi-store-prices-v2/messages" />
    <rewrite-uri template="/" />
  </inbound>
  <backend>
    <base />
  </backend>
  <outbound>
    <base />
  </outbound>
  <on-error>
    <base />
  </on-error>
</policies>
XML
}

# Add subscription for sender ----> managed by integration team

resource "azurerm_api_management_api_tag" "price" {
  provider = azurerm.apim
  api_id   = azurerm_api_management_api.price.id
  name     = "k-data"
}
