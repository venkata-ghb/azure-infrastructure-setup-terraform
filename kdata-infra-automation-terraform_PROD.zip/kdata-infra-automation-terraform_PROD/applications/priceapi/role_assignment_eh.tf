# ============================================================================================================
# priceApi
# ============================================================================================================
resource "azurerm_role_assignment" "eh_priceapi-event_hub_data_sender-central_apim" {
  scope                = data.terraform_remote_state.integrations.outputs.eh_priceapi_id
  role_definition_name = "Azure Event Hubs Data sender"
  principal_id         = data.azurerm_api_management.apimanagement.identity[0].principal_id
}