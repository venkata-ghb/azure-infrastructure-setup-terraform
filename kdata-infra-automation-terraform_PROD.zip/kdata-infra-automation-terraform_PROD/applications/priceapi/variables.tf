
variable "env" {
  type        = string
  description = "Environment short"
  default     = "prod"
}

variable "resource_tags" {
  type        = map(string)
  description = "Tags to be applied for all resources"
  default = {
    Application     = "Cloud Data Platform"
    "Business Unit" = "Shared"
    Sub-Service     = "C1231"
    environment     = "Production"
    IT-owner        = "sankalp.ahuja@kesko.fi"
    ManagedResource = "Yes"
    MgmtVendor      = "Tieto"
    created_by      = "Terraform"
    Description     = "Infrastructure for Kesko Data Platform"
    SubApplication  = "PriceAPI"
  }
}
