resource "azurerm_monitor_action_group" "storageapi" {
  name                = "${var.prefix}-storageapi-integration-errors-action-group"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_integration.name
  short_name          = "Storapi-err"

  tags = local.resource_tags

  email_receiver {
    name          = "DL_KESKOAMS_TCS_KDATA"
    email_address = "DL_KESKOAMS_TCS_KDATA@kesko.fi"
  }
  email_receiver {
    name          = "NicoMiettinen"
    email_address = "nico.miettinen@kesko.fi"
  }
}

resource "azurerm_monitor_metric_alert" "insights_storageapi-exception" {
  name                = "${var.prefix}-appsinght-storageapi-exception-alert"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_integration.name
  scopes              = [azurerm_application_insights.storageapi.id]
  description         = "Storageapi Function app Exception"
  auto_mitigate       = false
  frequency           = "PT15M"
  window_size         = "PT15M"
  severity            = 0

  criteria {
    metric_namespace = "Microsoft.Insights/Components"
    metric_name      = "exceptions/count"
    aggregation      = "Count"
    operator         = "GreaterThan"
    threshold        = 0
  }

  action {
    action_group_id = azurerm_monitor_action_group.storageapi.id
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_metric_alert" "insights_storageapi-failedrequest" {
  name                = "${var.prefix}-appsinght-storageapi-failerreq-alert"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_integration.name
  scopes              = [azurerm_application_insights.storageapi.id]
  description         = "Storageapi Function app Failed Request"
  auto_mitigate       = false
  frequency           = "PT15M"
  window_size         = "PT15M"
  severity            = 0

  criteria {
    metric_namespace = "Microsoft.Insights/Components"
    metric_name      = "exceptions/count"
    aggregation      = "Count"
    operator         = "GreaterThan"
    threshold        = 0
  }

  action {
    action_group_id = azurerm_monitor_action_group.storageapi.id
  }

  tags = local.resource_tags
}
