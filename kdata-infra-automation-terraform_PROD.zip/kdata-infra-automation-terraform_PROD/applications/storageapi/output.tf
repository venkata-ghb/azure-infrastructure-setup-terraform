output funcapp_storageapi {
  value = {
    id               = azurerm_linux_function_app.storageapi.id
    name             = azurerm_linux_function_app.storageapi.name
    default_hostname = azurerm_linux_function_app.storageapi.default_hostname
  }
}