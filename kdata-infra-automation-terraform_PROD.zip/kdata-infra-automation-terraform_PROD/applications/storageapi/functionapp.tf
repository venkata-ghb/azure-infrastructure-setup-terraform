resource "azurerm_linux_function_app" "storageapi" {
  name                        = "${var.prefix}-${var.loc}-storageapi-funcapp"
  location                    = var.location
  resource_group_name         = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  service_plan_id             = replace(data.terraform_remote_state.integrations.outputs.service_plan_int_premium.id, "serverFarm", "serverfarm")
  storage_account_name        = data.terraform_remote_state.integrations.outputs.sa_functionapp.name
  storage_account_access_key  = data.terraform_remote_state.integrations.outputs.sa_functionapp.primary_access_key
  https_only                  = true
  functions_extension_version = "~4"
  builtin_logging_enabled     = false
  virtual_network_subnet_id   = data.terraform_remote_state.vnets.outputs.subnet_funcapp_int.id

  identity {
    type = "SystemAssigned"
  }

  site_config {
    ftps_state                             = "Disabled"
    application_insights_connection_string = azurerm_application_insights.storageapi.connection_string
    application_stack {
      python_version = "3.11"
    }
  }

  app_settings = {
    WEBSITE_ENABLE_SYNC_UPDATE_SITE          = false
    STORAGE_ACCOUNT_NAME                     = data.terraform_remote_state.integrations.outputs.sa_adls.name
    MICROSOFT_PROVIDER_AUTHENTICATION_SECRET = data.terraform_remote_state.ad.outputs.sp_apim_authentication_password
  }

  auth_settings_v2 {
    auth_enabled           = true
    runtime_version        = "~1"
    require_authentication = true
    unauthenticated_action = "Return401"
    active_directory_v2 {
      client_id                  = data.terraform_remote_state.ad.outputs.sp_apim_authentication.application_id
      client_secret_setting_name = "MICROSOFT_PROVIDER_AUTHENTICATION_SECRET"
      tenant_auth_endpoint       = "https://sts.windows.net/${data.azurerm_subscription.current.tenant_id}/"
    }
    login {}
  }

  tags = local.resource_tags

  lifecycle {
    ignore_changes = [
      app_settings["WEBSITE_ENABLE_SYNC_UPDATE_SITE"],
      app_settings["WEBSITE_RUN_FROM_PACKAGE"],
    ]
  }
}

resource "azurerm_application_insights" "storageapi" {
  name                = "${var.prefix}-${var.loc}-storageapi-funcapp"
  location            = var.location
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  application_type    = "web"
  retention_in_days   = 90
  sampling_percentage = 0
  tags                = local.resource_tags

  lifecycle {
    ignore_changes = [ workspace_id ]
  }
}
