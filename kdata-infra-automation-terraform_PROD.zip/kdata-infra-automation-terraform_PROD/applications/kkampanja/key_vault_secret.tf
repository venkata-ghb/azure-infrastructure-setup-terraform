resource "azurerm_key_vault_secret" "kkampanja-eh_kkampanja_kksap_natural_k8s_read" {
  key_vault_id = azurerm_key_vault.kkampanja.id
  name         = "kksap-natural-k8s-read"
  value        = azurerm_eventhub_authorization_rule.kkampanja-kksap_natural-k8s_read.primary_connection_string
  content_type = "K-kampanja SAP Natural EvenhHub's endpoint read access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "kkampanja-eh_kkampanja_kksap_natural_k8s_write" {
  key_vault_id = azurerm_key_vault.kkampanja.id
  name         = "eh-kksap-natural-k8s-write"
  value        = azurerm_eventhub_authorization_rule.kkampanja-kksap_natural-k8s_write.primary_connection_string
  content_type = "K-kampanja SAP Natural EvenhHub's endpoint write access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "kkampanja-eh_kkampanja_consumer" {
  key_vault_id = azurerm_key_vault.kkampanja.id
  name         = "eh-kksap-natural-consumer"
  value        = azurerm_eventhub_authorization_rule.kkampanja-kksap_natural-consumer.primary_connection_string
  content_type = "K-kampanja SAP Natural EvenhHub's endpoint write access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "kkampanja-eh_app_usagebehavior_natural_adb_read" {
  key_vault_id = azurerm_key_vault.kkampanja.id
  name         = azurerm_eventhub_authorization_rule.campaign_app-usagebehavior_natural-adb_read.name
  value        = azurerm_eventhub_authorization_rule.campaign_app-usagebehavior_natural-adb_read.primary_connection_string
  content_type = "K-campaign App UsageBehavior Natural EvenhHub's endpoint read access for Databricks"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "kkampanja-sp_campaign_deltalake_secret" {
  key_vault_id = azurerm_key_vault.kkampanja.id
  name         = data.terraform_remote_state.ad.outputs.sp_campaign_deltalake.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_campaign_deltalake_password
  content_type = "${data.terraform_remote_state.ad.outputs.sp_campaign_deltalake.display_name} SP's Password by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "kkampanja-sp_campaign_eventhub_secret" {
  key_vault_id = azurerm_key_vault.kkampanja.id
  name         = data.terraform_remote_state.ad.outputs.sp_campaign_eventhub.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_campaign_eventhub_password
  content_type = "${data.terraform_remote_state.ad.outputs.sp_campaign_eventhub.display_name} SP's Password by Terraform"
  tags         = local.resource_tags
}
