resource "azurerm_api_management_api_diagnostic" "campaign_app_input" {
  provider                 = azurerm.apim
  identifier               = "applicationinsights"
  resource_group_name      = data.azurerm_api_management.apimanagement.resource_group_name
  api_management_name      = data.azurerm_api_management.apimanagement.name
  api_name                 = azurerm_api_management_api.campaign_app.name
  api_management_logger_id = data.terraform_remote_state.apim.outputs.apim_logger.id
  always_log_errors        = true
  }

resource "azurerm_api_management_api_diagnostic" "kkampanja_sap_input" {
  provider                 = azurerm.apim
  identifier               = "applicationinsights"
  resource_group_name      = data.azurerm_api_management.apimanagement.resource_group_name
  api_management_name      = data.azurerm_api_management.apimanagement.name
  api_name                 = azurerm_api_management_api.kkampanja_sap.name
  api_management_logger_id = data.terraform_remote_state.apim.outputs.apim_logger.id
  always_log_errors        = true
  }
