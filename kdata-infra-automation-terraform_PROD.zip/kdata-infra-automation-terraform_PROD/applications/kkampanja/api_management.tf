data "azurerm_api_management" "apimanagement" {
  provider            = azurerm.apim
  name                = "K-apim-${local.env.short}"
  resource_group_name = "KESKO_WE_RG_APIM_${upper(local.env.short)}001"
}

resource "azurerm_api_management_api" "campaign_app" {
  provider            = azurerm.apim
  name                = "kdata-campaign-app-input-api"
  resource_group_name = data.azurerm_api_management.apimanagement.resource_group_name
  api_management_name = data.azurerm_api_management.apimanagement.name
  revision            = "1"
  display_name        = "K-Data K-Campaign APP Input API"
  path                = "kdata/campaign-app-input-api"
  protocols           = ["https"]

  import {
    content_format = "openapi+json"
    content_value  = file("${path.module}/resources/openapi.campaign-app-input-api.json")
  }
}

resource "azurerm_api_management_named_value" "campaign_app" {
  provider            = azurerm.apim
  name                = "${azurerm_api_management_api.campaign_app.name}-secret"
  resource_group_name = azurerm_api_management_api.campaign_app.resource_group_name
  api_management_name = azurerm_api_management_api.campaign_app.api_management_name
  display_name        = "${azurerm_api_management_api.campaign_app.name}-secret"
  value               = data.terraform_remote_state.ad.outputs.sp_campaign_eventhub_password
  secret              = true
}

resource "azurerm_api_management_api_policy" "campaign_app" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.campaign_app.name
  api_management_name = azurerm_api_management_api.campaign_app.api_management_name
  resource_group_name = azurerm_api_management_api.campaign_app.resource_group_name

  xml_content = <<XML
<policies>
    <inbound>
        <base />
        <!--Look for userprofile for this user in the cache -->
        <cache-lookup-value key="${azurerm_api_management_api.campaign_app.name}-eh-access-token" variable-name="access-token" />
        <!-- If API Management doesn’t find it in the cache, make a request for it and store it -->
        <choose>
            <when condition="@(!context.Variables.ContainsKey("access-token"))">
                <!-- Make HTTP request to get user profile -->
                <send-request ignore-error="true" timeout="20" response-variable-name="bearerToken" mode="new">
                    <set-url>https://login.microsoftonline.com/${data.azurerm_client_config.current.tenant_id}/oauth2/token</set-url>
                    <set-method>POST</set-method>
                    <set-header name="Content-Type" exists-action="override">
                        <value>application/x-www-form-urlencoded</value>
                    </set-header>
                    <set-body>@{
                        return "client_id=${data.terraform_remote_state.ad.outputs.sp_campaign_eventhub.application_id}&resource=https://eventhubs.azure.net&client_secret={{${azurerm_api_management_named_value.campaign_app.name}}}&grant_type=client_credentials";
                    }</set-body>
                </send-request>
                <!-- Store response body in context variable -->
                <set-variable name="access-token" value="@((String)((IResponse)context.Variables["bearerToken"]).Body.As<JObject>()["access_token"])" />
                <!-- Store result in cache -->
                <cache-store-value key="${azurerm_api_management_api.campaign_app.name}-eh-access-token" value="@((string)context.Variables["access-token"])" duration="3300" />
            </when>
        </choose>
        <set-header name="Authorization" exists-action="override">
            <value>@("Bearer " + (String)context.Variables["access-token"])</value>
        </set-header>
        <validate-content unspecified-content-type-action="prevent" max-size="102400" size-exceeded-action="ignore" errors-variable-name="requestBodyValidation">
          <content type="application/json" validate-as="json" action="prevent" />
        </validate-content>
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <set-header name="Content-Type" exists-action="override">
          <value>application/json</value>
        </set-header>
        <choose>
          <when condition="@(context.Response.StatusCode >= 401)">
            <set-status code="500" reason="Internal Server Error" />
          </when>
        </choose>
        <set-body template="liquid">
        {
          "statusCode": {{context.Response.StatusCode}},
          "message": {% case context.Response.StatusCode %}
            {% when 201 %}"ok"
            {% else %}
              {% if body.message %}"{{body.message}}"
              {% else %}"Internal Error"
              {% endif %}
          {% endcase %}}
        </set-body>
        <base />
    </outbound>
    <on-error>
        <set-header name="Content-Type" exists-action="override">
          <value>application/json</value>
        </set-header>
        <set-body template="liquid">
        {
          "statusCode": {{context.Response.StatusCode}},
          "message": {% case context.Response.StatusCode %}
            {% when 400 %}"Invalid payload"
            {% else %}
              {% if body.message %}"{{body.message}}"
              {% else %}"Internal Error"
              {% endif %}
          {% endcase %}}
        </set-body>
        <base />
    </on-error>
</policies>
  XML
}

resource "azurerm_api_management_api_operation_policy" "campaign_app-event" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.campaign_app.name
  api_management_name = azurerm_api_management_api.campaign_app.api_management_name
  resource_group_name = azurerm_api_management_api.campaign_app.resource_group_name
  operation_id        = "post-event"

  xml_content = <<XML
<policies>
    <inbound>
        <base />
        <set-backend-service base-url="https://${data.terraform_remote_state.integrations.outputs.ehns_campaign_app.name}.servicebus.windows.net/usagebehavior-natural/messages" />
        <rewrite-uri template="/" />
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>
XML
}

resource "azurerm_api_management_product" "campaign_app" {
  provider              = azurerm.apim
  product_id            = "${azurerm_api_management_api.campaign_app.name}-product"
  api_management_name   = azurerm_api_management_api.campaign_app.api_management_name
  resource_group_name   = azurerm_api_management_api.campaign_app.resource_group_name
  display_name          = azurerm_api_management_api.campaign_app.display_name
  subscriptions_limit   = 0
  subscription_required = true
  approval_required     = false
  published             = true
}

resource "azurerm_api_management_product_api" "campaign_app" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.campaign_app.name
  product_id          = azurerm_api_management_product.campaign_app.product_id
  api_management_name = azurerm_api_management_api.campaign_app.api_management_name
  resource_group_name = azurerm_api_management_api.campaign_app.resource_group_name
}

resource "azurerm_api_management_product_group" "campaign_app" {
  provider            = azurerm.apim
  product_id          = azurerm_api_management_product.campaign_app.product_id
  api_management_name = azurerm_api_management_api.campaign_app.api_management_name
  resource_group_name = azurerm_api_management_api.campaign_app.resource_group_name
  group_name          = "60c32456242cce8ac0cfe7d2"
}

resource "azurerm_api_management_api_tag" "campaign_app" {
  provider = azurerm.apim
  api_id   = azurerm_api_management_api.campaign_app.id
  name     = "k-data"
}

# ============================================================================================

resource "azurerm_api_management_api" "kkampanja_sap" {
  provider            = azurerm.apim
  name                = "${local.prefix}-kkampanja-sap-input-api"
  resource_group_name = data.azurerm_api_management.apimanagement.resource_group_name
  api_management_name = data.azurerm_api_management.apimanagement.name
  revision            = "1"
  display_name        = "K-data K-Kampanja SAP Input API"
  path                = "kdata/kkampanja-sap-input-api"
  protocols           = ["https"]

  import {
    content_format = "openapi+json"
    content_value  = file("${path.module}/resources/openapi.campaign-sap-input-api.json")
  }
}

resource "azurerm_api_management_api_policy" "kkampanja_sap" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.kkampanja_sap.name
  api_management_name = azurerm_api_management_api.kkampanja_sap.api_management_name
  resource_group_name = azurerm_api_management_api.kkampanja_sap.resource_group_name

  xml_content = <<XML
<policies>
    <inbound>
        <base />
        <authentication-managed-identity resource="https://${data.terraform_remote_state.integrations.outputs.ehns_kkampanja.name}.servicebus.windows.net"/>
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <set-header name="Content-Type" exists-action="override">
          <value>application/json</value>
        </set-header>
        <choose>
          <when condition="@(context.Response.StatusCode == 201)">
            <set-status code="200" reason="ok"/>
          </when>
          <when condition="@(context.Response.StatusCode >= 401)">
            <set-status code="500" reason="Internal Server Error" />
          </when>
        </choose>
        <set-body template="liquid">
        {
          "statusCode": {{context.Response.StatusCode}},
          "message": {% case context.Response.StatusCode %}
            {% when 200 %}"ok"
            {% else %}
              {% if body.message %}"{{body.message}}"
              {% else %}"Internal Error"
              {% endif %}
          {% endcase %}}
        </set-body>
        <base />
    </outbound>
    <on-error>
        <set-header name="Content-Type" exists-action="override">
          <value>application/json</value>
        </set-header>
        <set-body template="liquid">
        {
          "statusCode": {{context.Response.StatusCode}},
          "message":
            {% if body.message %}"{{body.message}}"
            {% else %}"Internal Error"
            {% endif %}}
        </set-body>
        <base />
    </on-error>
</policies>
  XML
}

resource "azurerm_api_management_api_operation_policy" "kkampanja_sap-campaign_message" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.kkampanja_sap.name
  api_management_name = azurerm_api_management_api.kkampanja_sap.api_management_name
  resource_group_name = azurerm_api_management_api.kkampanja_sap.resource_group_name
  operation_id        = "post-campaign-message"

  xml_content = <<XML
<policies>
    <inbound>
        <base />
        <set-backend-service base-url="https://${data.terraform_remote_state.integrations.outputs.ehns_kkampanja.name}.servicebus.windows.net/kksap-natural/messages" />
        <rewrite-uri template="/" />
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>
XML
}


resource "azurerm_api_management_product" "kkampanja_sap" {
  provider              = azurerm.apim
  product_id            = "${azurerm_api_management_api.kkampanja_sap.name}-product"
  api_management_name   = azurerm_api_management_api.kkampanja_sap.api_management_name
  resource_group_name   = azurerm_api_management_api.kkampanja_sap.resource_group_name
  display_name          = azurerm_api_management_api.kkampanja_sap.display_name
  subscriptions_limit   = 0
  subscription_required = true
  approval_required     = false
  published             = true
}

resource "azurerm_api_management_product_api" "kkampanja_sap" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.kkampanja_sap.name
  product_id          = azurerm_api_management_product.kkampanja_sap.product_id
  api_management_name = azurerm_api_management_api.kkampanja_sap.api_management_name
  resource_group_name = azurerm_api_management_api.kkampanja_sap.resource_group_name
}

resource "azurerm_api_management_product_group" "kkampanja_sap" {
  provider            = azurerm.apim
  product_id          = azurerm_api_management_product.kkampanja_sap.product_id
  group_name          = "6094c400b9d53eec26c4921c"
  api_management_name = azurerm_api_management_api.kkampanja_sap.api_management_name
  resource_group_name = azurerm_api_management_api.kkampanja_sap.resource_group_name
}

resource "azurerm_api_management_api_tag" "kkampanja_sap" {
  provider = azurerm.apim
  api_id   = azurerm_api_management_api.kkampanja_sap.id
  name     = "k-data"
}
