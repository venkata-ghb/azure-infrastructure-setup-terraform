resource "azurerm_monitor_action_group" "kkampanja" {
  name                = "${local.prefix}-kkampanja-integration-errors-action-group"
  resource_group_name = azurerm_resource_group.kkampanja.name
  short_name          = "kk-int-err"

  tags = local.resource_tags

  email_receiver {
    name          = "DL_KESKOAMS_TCS_KDATA"
    email_address = "DL_KESKOAMS_TCS_KDATA@kesko.fi"
  }
  email_receiver {
    name          = "NicoMiettinen"
    email_address = "nico.miettinen@kesko.fi"
  }
}

resource "azurerm_monitor_activity_log_alert" "ehns_kkampanja-health" {
  name                = "${local.prefix}-kkampanja-eventhub-health-alert"
  resource_group_name = azurerm_resource_group.kkampanja.name
  scopes              = [data.terraform_remote_state.integrations.outputs.ehns_kkampanja.id]
  description         = "Alert to monitor K-campaign Event Hub namespace health status."

  tags = local.resource_tags

  criteria {
    resource_id = data.terraform_remote_state.integrations.outputs.ehns_kkampanja.id
    category    = "ResourceHealth"
  }

  action {
    action_group_id = azurerm_monitor_action_group.kkampanja.id
  }

}

resource "azurerm_monitor_activity_log_alert" "ehns_campaign_app-health" {
  name                = "${local.prefix}-campaign-app-eventhub-health-alert"
  resource_group_name = azurerm_resource_group.kkampanja.name
  scopes              = [data.terraform_remote_state.integrations.outputs.ehns_campaign_app.id]
  description         = "Alert to monitor K-Campaign App Event Hub namespace health status."

  tags = local.resource_tags

  criteria {
    resource_id = data.terraform_remote_state.integrations.outputs.ehns_campaign_app.id
    category    = "ResourceHealth"
  }

  action {
    action_group_id = azurerm_monitor_action_group.kkampanja.id
  }

}

resource "azurerm_monitor_metric_alert" "ehns_campaign_app-server_error" {
  name                = "${local.prefix}-campaign-app-eventhub-server-error-alert"
  resource_group_name = azurerm_resource_group.kkampanja.name
  scopes              = [data.terraform_remote_state.integrations.outputs.ehns_campaign_app.id]
  description         = "Alert to monitor K-Campaign App Event Hub namespace Server Errors"

  tags = local.resource_tags

  criteria {
    metric_namespace = "Microsoft.EventHub/namespaces"
    metric_name      = "ServerErrors"
    aggregation      = "Total"
    operator         = "GreaterThan"
    threshold        = 0
  }

  action {
    action_group_id = azurerm_monitor_action_group.kkampanja.id
  }
}

resource "azurerm_monitor_metric_alert" "ehns_campaign_app-user_error" {
  name                = "${local.prefix}-campaign-app-eventhub-user-error-alert"
  resource_group_name = azurerm_resource_group.kkampanja.name
  scopes              = [data.terraform_remote_state.integrations.outputs.ehns_campaign_app.id]
  description         = "Alert to monitor K-Campaign App Event Hub namespace User Errors"

  tags = local.resource_tags

  criteria {
    metric_namespace = "Microsoft.EventHub/namespaces"
    metric_name      = "UserErrors"
    aggregation      = "Total"
    operator         = "GreaterThan"
    threshold        = 0
  }

  action {
    action_group_id = azurerm_monitor_action_group.kkampanja.id
  }
}
