resource "azurerm_eventhub_authorization_rule" "kkampanja-kksap_natural-k8s_read" {
  name                = "kksap-natural-k8s-read"
  eventhub_name       = "kksap-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_kkampanja.name #azurerm_eventhub.kkampanja_sap_natural.namespace_name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_kkampanja.resource_group_name
  listen              = true
  send                = false
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "kkampanja-kksap_natural-k8s_write" {
  name                = "kksap-natural-k8s-write"
  eventhub_name       = "kksap-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_kkampanja.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_kkampanja.resource_group_name
  listen              = false
  send                = true
  manage              = false
}

/*
resource "azurerm_eventhub_authorization_rule" "kkampanja-kksap_natural-producer" {
  name                = "producer"
  eventhub_name       = "kksap-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_kkampanja.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_kkampanja.resource_group_name
  listen              = false
  send                = true
  manage              = false
}
*/
resource "azurerm_eventhub_authorization_rule" "kkampanja-kksap_natural-consumer" {
  name                = "consumer"
  eventhub_name       = "kksap-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_kkampanja.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_kkampanja.resource_group_name
  listen              = true
  send                = false
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "campaign_app-usagebehavior_natural-adb_read" {
  name                = "app-usagebehavior-natural-adb-read"
  eventhub_name       = "usagebehavior-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_campaign_app.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_campaign_app.resource_group_name
  listen              = true
  send                = false
  manage              = false
}
