resource "azurerm_resource_group" "kkampanja" {
  name     = "${local.prefix_rg}_KAMPANJA_Main_RG"
  location = local.location.long
  tags     = merge(local.resource_tags, {
    ApplicationVendor = "Futurice"
    IT-owner          = "anna.luneva@kesko.fi"
    Sub-Service       = "C1245"
    Vendor            = "Futurice"
    Application       = "K Kampanja"
  })
}
