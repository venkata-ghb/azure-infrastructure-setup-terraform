resource "random_password" "sqlserver_public_app-admin_password" {
  length  = 20
  special = true
}

resource "azurerm_mssql_server" "public_app" {
  name                         = "${local.prefix}-public-app-db"
  resource_group_name          = azurerm_resource_group.or.name
  location                     = azurerm_resource_group.or.location
  version                      = "12.0"
  administrator_login          = "dbadmin"
  administrator_login_password = random_password.sqlserver_public_app-admin_password.result

  azuread_administrator {
    login_username = data.terraform_remote_state.ad.outputs.group_or_sql_admin.display_name
    object_id      = data.terraform_remote_state.ad.outputs.group_or_sql_admin.id
  }

  identity {
    type = "SystemAssigned"
  }

  tags = local.resource_tags
}

resource "azurerm_mssql_firewall_rule" "public_app-kesko_workspace" {
  name             = "Kesko Workspace IP range"
  start_ip_address = "157.144.201.0"
  end_ip_address   = "157.144.201.255"
  server_id        = azurerm_mssql_server.public_app.id
}

resource "azurerm_mssql_firewall_rule" "public_app-kesko_vpn" {
  name             = "Kesko VPN IP range"
  start_ip_address = "157.144.241.0"
  end_ip_address   = "157.144.241.255"
  server_id        = azurerm_mssql_server.public_app.id
}

resource "azurerm_mssql_firewall_rule" "public_app-citrix1" {
  name             = "Citrix Public IP 1"
  start_ip_address = "40.119.145.170"
  end_ip_address   = "40.119.145.170"
  server_id        = azurerm_mssql_server.public_app.id
}

resource "azurerm_mssql_firewall_rule" "public_app-citrix2" {
  name             = "Citrix Public IP 2"
  start_ip_address = "52.137.57.167"
  end_ip_address   = "52.137.57.167"
  server_id        = azurerm_mssql_server.public_app.id
}

resource "azurerm_mssql_firewall_rule" "public_app-konvehti" {
  count            = length(azurerm_windows_function_app.konvehtibe.outbound_ip_address_list)
  name             = "Konvehti${count.index}"
  start_ip_address = azurerm_windows_function_app.konvehtibe.outbound_ip_address_list[count.index]
  end_ip_address   = azurerm_windows_function_app.konvehtibe.outbound_ip_address_list[count.index]
  server_id        = azurerm_mssql_server.public_app.id
}

resource "azurerm_mssql_virtual_network_rule" "public_app-integrations_aks" {
  name      = "IntegrationsAKS"
  subnet_id = data.terraform_remote_state.vnets.outputs.subnet_integration.id
  server_id = azurerm_mssql_server.public_app.id
}

resource "azurerm_mssql_virtual_network_rule" "public_app-databricks_pub_subnet_access" {
  name      = "DatabricksPubSubnetAccess"
  subnet_id = data.terraform_remote_state.vnets.outputs.subnet_databricks_int_pub.id
  server_id = azurerm_mssql_server.public_app.id
}

resource "azurerm_mssql_virtual_network_rule" "public_app-robot_vm" {
  name      = "RobotVM"
  subnet_id = data.terraform_remote_state.vnets.outputs.subnet_robot.id
  server_id = azurerm_mssql_server.public_app.id
}
