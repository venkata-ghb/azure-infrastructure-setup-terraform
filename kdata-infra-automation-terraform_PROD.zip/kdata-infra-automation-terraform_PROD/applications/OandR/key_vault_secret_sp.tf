# or
resource "azurerm_key_vault_secret" "or-sp_or_terraform_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_or_terraform.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_or_terraform_password
  key_vault_id = azurerm_key_vault.or.id
  content_type = "SP's Password by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-sp_or_azdevops_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_or_azdevops.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_or_azdevops_password
  key_vault_id = azurerm_key_vault.or.id
  content_type = "SP's Password by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-sp_or_bookkeeping_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_or_bookkeeping.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_or_bookkeeping_password
  key_vault_id = azurerm_key_vault.or.id
  content_type = "SP's Password by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-sp_or_etl_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_or_etl.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_or_etl_password
  key_vault_id = azurerm_key_vault.or.id
  content_type = "SP's Password by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-sp_or_robot_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_or_robot.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_or_robot_password
  key_vault_id = azurerm_key_vault.or.id
  content_type = "SP's Password by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-sp_or_edw_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_or_edw.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_or_edw_password
  key_vault_id = azurerm_key_vault.or.id
  content_type = "SP's Password by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-sp_or_lastdaysales_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_or_lastdaysales.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_or_lastdaysales_password
  key_vault_id = azurerm_key_vault.or.id
  content_type = "SP's Password by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-sp_or_plussa_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_or_plussa.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_or_plussa_password
  key_vault_id = azurerm_key_vault.or.id
  content_type = "SP's Password by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-sp_or_selfsupervision_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_or_selfsupervision.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_or_selfsupervision_password
  key_vault_id = azurerm_key_vault.or.id
  content_type = "SP's Password by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-sp_or_kai_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_or_kai.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_or_kai_password
  key_vault_id = azurerm_key_vault.or.id
  content_type = "SP's Password by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-sp_or_nestedayend_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_or_nestedayend.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_or_nestedayend_password
  key_vault_id = azurerm_key_vault.or.id
  content_type = "SP's Password by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-sp_or_b2bdr_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_or_b2bdr.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_or_b2bdr_password
  key_vault_id = azurerm_key_vault.or.id
  content_type = "SP's Password by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-sp_or_match_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_or_match.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_or_match_password
  key_vault_id = azurerm_key_vault.or.id
  content_type = "SP's Password by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-sp_or_dbmaintenance_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_or_dbmaintenance.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_or_dbmaintenance_password
  key_vault_id = azurerm_key_vault.or.id
  content_type = "SP's Password by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-sp_or_deltalake_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_or_deltalake.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_or_deltalake_password
  key_vault_id = azurerm_key_vault.or.id
  content_type = "SP's Password by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-sp_or_companyinfo_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_or_companyinfo.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_or_companyinfo_password
  key_vault_id = azurerm_key_vault.or.id
  content_type = "SP's Password by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-sp_or_konvehti_fe_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_or_konvehti_fe.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_or_konvehti_fe_password
  key_vault_id = azurerm_key_vault.or.id
  content_type = "SP's Password by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-sp_or_flyway_sql_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_or_flyway_sql.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_or_flyway_sql_password
  key_vault_id = azurerm_key_vault.or.id
  content_type = "${data.terraform_remote_state.ad.outputs.sp_or_flyway_sql.display_name} SP's Password by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-sp_adb_secret" {
  name         = "kdata-prod-adb-sp-key"
  value        = data.terraform_remote_state.ad.outputs.sp_catman_adb_password
  key_vault_id = azurerm_key_vault.or.id
  content_type = "${data.terraform_remote_state.ad.outputs.sp_catman_adb.display_name} SP's Password by Terraform"
  tags         = local.resource_tags
}

# dp
resource "azurerm_key_vault_secret" "or_dp-sp_or_datapower_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_or_datapower.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_or_datapower_password
  key_vault_id = azurerm_key_vault.or_dp.id
  content_type = "SP's Password by Terraform"
  tags         = local.resource_tags
}

# tbtrk
resource "azurerm_key_vault_secret" "or_tbtrk-sp_or_tobtrack_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_or_tobtrack.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_or_tobtrack_password
  key_vault_id = azurerm_key_vault.or_tbtrk.id
  content_type = "SP's Password by Terraform"
  tags         = local.resource_tags
}
