variable blob_soft_delete_retention_days {
  type    = number
  default = 60
}

variable delete_blobs_after_days {
  type    = number
  default = 365
}
