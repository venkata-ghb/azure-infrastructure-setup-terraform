data "azurerm_key_vault_secret" "or-konvehtiapp" {
  name         = "konvehtiapp"
  key_vault_id = azurerm_key_vault.or.id
}

data "azurerm_key_vault_secret" "or-konvehti_functions_key" {
  name         = "${local.prefix}-konvehti-functions-key"
  key_vault_id = azurerm_key_vault.or.id
}

resource "azurerm_key_vault_secret" "or-sqlserver_public_app_admin_password" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "public-dbadmin"
  value        = random_password.sqlserver_public_app-admin_password.result
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-sa_rawdlq_connectionstring" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "raw-events-dlq-storage-endpoint"
  value        = azurerm_storage_account.rawdlq.primary_connection_string
  content_type = "Raw events DLQ storage endpoint"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-loganalytics_id" {
  name         = "${local.prefix}-loganalytics-id"
  value        = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.workspace_id
  key_vault_id = azurerm_key_vault.or.id
  content_type = "${local.prefix}-loganalytics Workspace ID by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-loganalytics_key" {
  name         = "${local.prefix}-loganalytics-key"
  value        = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace_key
  key_vault_id = azurerm_key_vault.or.id
  content_type = "${local.prefix}-loganalytics Primary Key by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-vm_robotserver_admin_password" {
  # Change robot-server-admin to robot-admin in final version.(Temp created to avoid overwrite)
  name         = "robot-server-admin"
  value        = random_password.vm_robotserver-admin_password.result
  key_vault_id = azurerm_key_vault.or.id
  tags         = local.resource_tags
}


resource "azurerm_key_vault_secret" "or-sa_eph_connection_string" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "eventhub-ns-storage-endpoint"
  value        = azurerm_storage_account.eph.primary_connection_string
  content_type = "Eventhub Namespace's storage endpoint"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-sa_eph_access_key" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "eventhub-ns-storage-access-key"
  value        = azurerm_storage_account.eph.primary_access_key
  content_type = "Eventhub Namespace's storage access key"
  tags         = local.resource_tags
}

data "azurerm_key_vault_secret" "or-confluent_com_harmoniser_client_key" {
  name         = "confluent-com-harmoniser-client-key"
  key_vault_id = azurerm_key_vault.or.id
}

data "azurerm_key_vault_secret" "or-confluent_com_harmoniser_client_secret" {
  name         = "confluent-com-harmoniser-client-secret"
  key_vault_id = azurerm_key_vault.or.id
}

data "azurerm_key_vault_secret" "or-confluent_schema_api_key" {
  name         = "confluent-schema-api-key"
  key_vault_id = azurerm_key_vault.or.id
}

data "azurerm_key_vault_secret" "or-confluent_schema_api_secret" {
  name         = "confluent-schema-api-secret"
  key_vault_id = azurerm_key_vault.or.id
}
