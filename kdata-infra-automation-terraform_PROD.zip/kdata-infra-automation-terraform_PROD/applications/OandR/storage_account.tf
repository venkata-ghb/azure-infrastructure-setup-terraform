resource "azurerm_storage_account" "harmonizers" {
  name                            = "${local.prefix_sa}harmonizers"
  resource_group_name             = azurerm_resource_group.or.name
  location                        = azurerm_resource_group.or.location
  account_tier                    = "Standard"
  account_replication_type        = "LRS"
  https_traffic_only_enabled       = true
  account_kind                    = "StorageV2"
  allow_nested_items_to_be_public = false
  cross_tenant_replication_enabled = true
  network_rules {
    default_action = "Deny"
    ip_rules = [
      "157.144.241.0/24", # Kesko Internal
      "157.144.201.0/24", # Kesko Internal        
      "131.207.242.5",    # Tieto network 
      "131.207.242.128",  # Tieto GlobalProtect fixed IP
      "52.137.57.167",    # CITRIX Fixed IP1 
      "40.119.145.170",   # CITRIX Fixed IP2
    ]
    virtual_network_subnet_ids = [
      data.terraform_remote_state.vnets.outputs.subnet_integration.id,
      data.terraform_remote_state.vnets.outputs.subnet_robot.id,
      "/subscriptions/0ee45dee-812a-4353-9f8d-d01030378b13/resourceGroups/Kesko_WE_RG_Citrix_VNET1/providers/Microsoft.Network/virtualNetworks/CITRIX_VNET1_WE/subnets/CITRIX_SUBNET",
      "/subscriptions/0a2d289e-76dd-4b1f-b9b2-dba15a872e92/resourceGroups/rg-platform-avd-prod-weu-001/providers/Microsoft.Network/virtualNetworks/vnet-avd-prod-weu-001/subnets/Subnet-AVDTCS-AMS-prod-weu"
    ]
  }
  blob_properties {
    delete_retention_policy {
      days = 60
    }
  }
  tags = merge(local.resource_tags, {
    Purpose = "Stores messages which failed to get harmonized"
  })
}

resource "azurerm_storage_container" "harmonizers-gtpos_failed_events" {
  name                  = "gtpos-harmonizer-failed-events"
  storage_account_name  = azurerm_storage_account.harmonizers.name
  container_access_type = "private"
}

resource "azurerm_storage_container" "harmonizers-rer_failed_events" {
  name                  = "rer-harmonizer-failed-events"
  storage_account_name  = azurerm_storage_account.harmonizers.name
  container_access_type = "private"
}

resource "azurerm_storage_container" "harmonizers-rpo_failed_events" {
  name                  = "rpo-harmonizer-failed-events"
  storage_account_name  = azurerm_storage_account.harmonizers.name
  container_access_type = "private"
}

resource "azurerm_storage_container" "harmonizers-ctchr_failed_events" {
  name                  = "ctchr-harmonizer-failed-events"
  storage_account_name  = azurerm_storage_account.harmonizers.name
  container_access_type = "private"
}

resource "azurerm_storage_container" "harmonizers-ecmse_failed_events" {
  name                  = "ecmse-harmonizer-failed-events"
  storage_account_name  = azurerm_storage_account.harmonizers.name
  container_access_type = "private"
}

resource "azurerm_storage_container" "harmonizers-gtpos_etl_failed_events" {
  name                  = "gtpos-etl-failed-events"
  storage_account_name  = azurerm_storage_account.harmonizers.name
  container_access_type = "private"
}

resource "azurerm_storage_container" "harmonizers-openpos_failed_events" {
  name                  = "openpos-harmonizer-failed-events"
  storage_account_name  = azurerm_storage_account.harmonizers.name
  container_access_type = "private"
}

# ===========================================================================
resource "azurerm_storage_account" "bookkeeping" {
  name                      = "${local.prefix_sa}orbookkeeping"
  resource_group_name       = azurerm_resource_group.or.name
  location                  = azurerm_resource_group.or.location
  account_tier              = "Standard"
  account_kind              = "StorageV2"
  account_replication_type  = "LRS"
  https_traffic_only_enabled = true
  cross_tenant_replication_enabled = true
  network_rules {
    default_action = "Deny"
    ip_rules = [
      "157.144.241.0/24", # Kesko Internal
      "157.144.201.0/24", # Kesko Internal    
      "131.207.242.5",    # Tieto network
      "131.207.242.128",  # Tieto GlobalProtect fixed IP    
      "52.137.57.167",    # CITRIX Fixed IP1 
      "40.119.145.170",   # CITRIX Fixed IP2    
    ]

    virtual_network_subnet_ids = [
      data.terraform_remote_state.vnets.outputs.subnet_databricks_int_pub.id,
      data.terraform_remote_state.vnets.outputs.subnet_robot.id,
      data.terraform_remote_state.vnets.outputs.subnet_integration.id,
      "/subscriptions/0ee45dee-812a-4353-9f8d-d01030378b13/resourceGroups/Kesko_WE_RG_Citrix_VNET1/providers/Microsoft.Network/virtualNetworks/CITRIX_VNET1_WE/subnets/CITRIX_SUBNET",
      "/subscriptions/0a2d289e-76dd-4b1f-b9b2-dba15a872e92/resourceGroups/rg-platform-avd-prod-weu-001/providers/Microsoft.Network/virtualNetworks/vnet-avd-prod-weu-001/subnets/Subnet-AVDTCS-AMS-prod-weu"
    ]
  }
  blob_properties {
    delete_retention_policy {
      days = var.blob_soft_delete_retention_days
    }
  }
  tags = merge(local.resource_tags, {
    Purpose = "Stores work orders for parallel bookkeeping jobs"
  })
}

resource "azurerm_storage_container" "bookkeeping-jars" {
  name                 = "jars"
  storage_account_name = azurerm_storage_account.bookkeeping.name
}

resource "azurerm_storage_queue" "bookkeeping-work_order_queue" {
  name                 = "work-order-queue"
  storage_account_name = azurerm_storage_account.bookkeeping.name
}

resource "azurerm_storage_queue" "bookkeeping-snowflake_work_order_queue" {
  name                 = "snowflake-work-order-queue"
  storage_account_name = azurerm_storage_account.bookkeeping.name
}

resource "azurerm_storage_table" "bookkeeping-watermark" {
  name                 = "watermark"
  storage_account_name = azurerm_storage_account.bookkeeping.name
}

resource "azurerm_storage_table" "bookkeeping-watermark_snowflake" {
  name                 = "watermarkSnowflake"
  storage_account_name = azurerm_storage_account.bookkeeping.name
}

# ===========================================================================
resource "azurerm_storage_account" "rawdlq" {
  name                            = "${local.prefix_sa}orrawdlq"
  resource_group_name             = azurerm_resource_group.or.name
  location                        = azurerm_resource_group.or.location
  account_tier                    = "Standard"
  account_kind                    = "StorageV2"
  account_replication_type        = "LRS"
  https_traffic_only_enabled      = "true"
  allow_nested_items_to_be_public = false
  cross_tenant_replication_enabled = true
  network_rules {
    default_action = "Deny"
    ip_rules = [
      "157.144.241.0/24", # Kesko Internal
      "157.144.201.0/24", # Kesko Internal    
      "157.144.14.37",    # Datapower On-prem PROD 1
      "157.144.14.38",    # Datapower On-prem PROD 1
      "52.50.44.41",      # Datapower AWS PROD 1
      "52.210.72.238",    # Datapower AWS PROD 2
      "34.240.198.168",   # Datapower AWS PROD 1 new
      "52.209.237.101",   # Datapower AWS PROD 2 new
      "131.207.242.5",    # Tieto network
      "131.207.242.128",  # Tieto GlobalProtect fixed IP  
      "52.137.57.167",    # CITRIX Fixed IP1 
      "40.119.145.170",   # CITRIX Fixed IP2    
    ]
    virtual_network_subnet_ids = [
      data.terraform_remote_state.vnets.outputs.subnet_integration.id,
      data.terraform_remote_state.vnets.outputs.subnet_robot.id,
      "/subscriptions/0ee45dee-812a-4353-9f8d-d01030378b13/resourceGroups/Kesko_WE_RG_Citrix_VNET1/providers/Microsoft.Network/virtualNetworks/CITRIX_VNET1_WE/subnets/CITRIX_SUBNET",
      "/subscriptions/0a2d289e-76dd-4b1f-b9b2-dba15a872e92/resourceGroups/rg-platform-avd-prod-weu-001/providers/Microsoft.Network/virtualNetworks/vnet-avd-prod-weu-001/subnets/Subnet-AVDTCS-AMS-prod-weu"
    ]
  }
  blob_properties {
    delete_retention_policy {
      days = 60
    }
  }
  tags = merge(local.resource_tags, {
    Purpose = "Location for Datapower to store oversized GT messages"
  })
}

resource "azurerm_storage_container" "rawdlq-gtpos" {
  name                  = "gtpos-raw-dlq"
  storage_account_name  = azurerm_storage_account.rawdlq.name
  container_access_type = "private"
}

# ===========================================================================
resource "azurerm_storage_account" "push" {
  name                            = "${local.prefix_sa}${local.location.short}orpush"
  resource_group_name             = azurerm_resource_group.or.name
  location                        = azurerm_resource_group.or.location
  account_tier                    = "Standard"
  account_replication_type        = "LRS"
  https_traffic_only_enabled      = true
  account_kind                    = "StorageV2"
  allow_nested_items_to_be_public = false
  cross_tenant_replication_enabled = true
  network_rules {
    default_action = "Deny"
    ip_rules = [
      "157.144.241.0/24", # Kesko Internal
      "157.144.201.0/24", # Kesko Internal    
      "131.207.242.5",    # Tieto network
      "131.207.242.128",  # Tieto GlobalProtect fixed IP
      "52.137.57.167",    # CITRIX Fixed IP1 
      "40.119.145.170",   # CITRIX Fixed IP2  
    ]
    virtual_network_subnet_ids = [
      data.terraform_remote_state.vnets.outputs.subnet_integration.id,
      data.terraform_remote_state.vnets.outputs.subnet_robot.id,
      "/subscriptions/0ee45dee-812a-4353-9f8d-d01030378b13/resourceGroups/Kesko_WE_RG_Citrix_VNET1/providers/Microsoft.Network/virtualNetworks/CITRIX_VNET1_WE/subnets/CITRIX_SUBNET",
      "/subscriptions/0a2d289e-76dd-4b1f-b9b2-dba15a872e92/resourceGroups/rg-platform-avd-prod-weu-001/providers/Microsoft.Network/virtualNetworks/vnet-avd-prod-weu-001/subnets/Subnet-AVDTCS-AMS-prod-weu"
    ]
  }
  blob_properties {
    delete_retention_policy {
      days = 60
    }
  }
  tags = merge(local.resource_tags, {
    Purpose = "Stores failed erecipts and push messages"
  })
}

resource "azurerm_storage_container" "push-failed_receipts" {
  name                  = "push-service-failed-receipts"
  storage_account_name  = azurerm_storage_account.push.name
  container_access_type = "private"
}

resource "azurerm_storage_container" "push-ereceipt_failed_receipts" {
  name                  = "ereceipt-push-service-failed-receipts"
  storage_account_name  = azurerm_storage_account.push.name
  container_access_type = "private"
}

# ===========================================================================
resource "azurerm_storage_account" "b2bdr" {
  name                            = "${local.prefix_sa}b2bdr"
  resource_group_name             = azurerm_resource_group.or.name
  location                        = azurerm_resource_group.or.location
  account_tier                    = "Standard"
  account_kind                    = "StorageV2"
  account_replication_type        = "LRS"
  https_traffic_only_enabled       = "true"
  allow_nested_items_to_be_public = false
  cross_tenant_replication_enabled = true
  network_rules {
    default_action = "Deny"
    ip_rules = [
      "157.144.241.0/24", # Kesko Internal
      "157.144.201.0/24", # Kesko Internal    
      "131.207.242.5",    # Tieto network
      "131.207.242.128",  # Tieto GlobalProtect fixed IP
      "52.137.57.167",    # CITRIX Fixed IP1 
      "40.119.145.170",   # CITRIX Fixed IP2
    ]
    virtual_network_subnet_ids = [
      data.terraform_remote_state.vnets.outputs.subnet_integration.id,
      data.terraform_remote_state.vnets.outputs.subnet_robot.id,
      "/subscriptions/0ee45dee-812a-4353-9f8d-d01030378b13/resourceGroups/Kesko_WE_RG_Citrix_VNET1/providers/Microsoft.Network/virtualNetworks/CITRIX_VNET1_WE/subnets/CITRIX_SUBNET",
      "/subscriptions/0a2d289e-76dd-4b1f-b9b2-dba15a872e92/resourceGroups/rg-platform-avd-prod-weu-001/providers/Microsoft.Network/virtualNetworks/vnet-avd-prod-weu-001/subnets/Subnet-AVDTCS-AMS-prod-weu"
    ]
  }
  blob_properties {
    delete_retention_policy {
      days = var.blob_soft_delete_retention_days
    }
  }
  tags = merge(local.resource_tags, {
    Purpose = "Store Lehto BUID configurations and DB checkpoint timestamp"
  })
}
resource "azurerm_storage_table" "b2bdr-table" {
  name                 = "${local.prefix_sa}b2bdrtable"
  storage_account_name = azurerm_storage_account.b2bdr.name
}

resource "azurerm_storage_table_entity" "b2bdr-table-row1" {
  storage_table_id           = azurerm_storage_table.b2bdr-table.id
  partition_key        = "B2BDR"
  row_key              = "B2BDRRow1"

  entity = {
    BusinessUnitIds       = "F500,F515,F517,F527,F533,F537,F539,F540,F544,F545,F553,F556,F573,F582,F585,F588,F590,F597,F605,F636,F638,F639"
    CustomerIds           = "638227,927211,1075416,1229426,1904273,1907367,2039305,2040368,2040534,2047075,2050636,2050638,2131264,2133814,2138406,2138468,2189274,2202622,2204284,2207288,2260947,2280133,2314602,2373330"
    DeliverToDatapower    = "true"
    Query                 = "$.meta.eventtype=salesorder;$.data.BusinessUnitId=F541;$.data.CustomerId=207051;$.data.RecipientAgreementId=2207245"
    RecipientAgreementIds = ""
    RecipientName         = "lehto"
    RecipientOVT          = "003720340416"
    StageFolder           = "datapower_stage_to_lehto"
  }
}

# ===========================================================================

resource "azurerm_storage_account" "audit" {
  name                      = "${local.prefix_sa}${local.location.short}oraudit"
  resource_group_name       = azurerm_resource_group.or.name
  location                  = azurerm_resource_group.or.location
  account_tier              = "Standard"
  account_replication_type  = "LRS"
  https_traffic_only_enabled = true
  account_kind              = "StorageV2"
  cross_tenant_replication_enabled = true
  network_rules {
    default_action = "Allow"
    virtual_network_subnet_ids = [
      "/subscriptions/0a2d289e-76dd-4b1f-b9b2-dba15a872e92/resourceGroups/rg-platform-avd-prod-weu-001/providers/Microsoft.Network/virtualNetworks/vnet-avd-prod-weu-001/subnets/Subnet-AVDTCS-AMS-prod-weu",
      "/subscriptions/02147589-2a7d-4483-b5da-af70a38cea3f/resourceGroups/K-DATA_PROD_VNET1_WE/providers/Microsoft.Network/virtualNetworks/K-DATA_PROD_VNET1_WE/subnets/K-DATA_PROD_WE_Integration_RG-sn",
      "/subscriptions/02147589-2a7d-4483-b5da-af70a38cea3f/resourceGroups/K-DATA_PROD_VNET1_WE/providers/Microsoft.Network/virtualNetworks/K-DATA_PROD_VNET1_WE/subnets/K-DATA_PROD_WE_dbricks-pub-sn"
    ]
  }

  blob_properties {
    delete_retention_policy {
      days = 7
    }
  }

  tags = merge(local.resource_tags, {
    Purpose = "Stores dignostic logs and vulnerability assessment logs"
  })
}

# ===========================================================================
resource "azurerm_storage_account" "eph" {
  name                      = "${local.prefix_sa}eph"
  resource_group_name       = azurerm_resource_group.or.name
  location                  = azurerm_resource_group.or.location
  account_replication_type  = "LRS"
  account_kind              = "StorageV2"
  account_tier              = "Standard"
  https_traffic_only_enabled = "true"
  cross_tenant_replication_enabled = true
  network_rules {
    bypass = [
      "AzureServices",
      "Metrics",
    ]
    default_action = "Deny"
    ip_rules = [
      "157.144.241.0/24", # Kesko Internal
      "157.144.201.0/24", # Kesko Internal    
      "131.207.242.5",    # Tieto network 
      "131.207.242.128",  # Tieto GlobalProtect fixed IP
      "52.137.57.167",    # CITRIX Fixed IP1 
      "40.119.145.170",   # CITRIX Fixed IP2
      "34.240.198.168",   # Datapower AWS PROD 1 new
      "52.209.237.101",   # Datapower AWS PROD 2 new
      "49.36.56.64",      # ?????
    ]

    virtual_network_subnet_ids = [
      data.terraform_remote_state.vnets.outputs.subnet_integration.id,
      data.terraform_remote_state.vnets.outputs.subnet_databricks_int_pub.id,
      data.terraform_remote_state.vnets.outputs.subnet_robot.id,
      "/subscriptions/0ee45dee-812a-4353-9f8d-d01030378b13/resourceGroups/Kesko_WE_RG_Citrix_VNET1/providers/Microsoft.Network/virtualNetworks/CITRIX_VNET1_WE/subnets/CITRIX_SUBNET",
      "/subscriptions/0a2d289e-76dd-4b1f-b9b2-dba15a872e92/resourceGroups/rg-platform-avd-prod-weu-001/providers/Microsoft.Network/virtualNetworks/vnet-avd-prod-weu-001/subnets/Subnet-AVDTCS-AMS-prod-weu"
    ]
  }

  blob_properties {
    delete_retention_policy {
      days = 60
    }
  }

  tags = merge(local.resource_tags, {
    Purpose                  = "Store Eventhub Lease"
    AzDefenderPlanAutoEnable = "off"
  })
}

resource "azurerm_storage_container" "eph-gtpos_natural_lease" {
  name                 = "gtpos-natural-lease"
  storage_account_name = azurerm_storage_account.eph.name
}

resource "azurerm_storage_container" "eph-gtpos_harmonizer_lease" {
  name                 = "gtpos-harmonizer-lease"
  storage_account_name = azurerm_storage_account.eph.name
}

resource "azurerm_storage_container" "eph-ctchr_natural_lease" {
  name                 = "ctchr-natural-lease"
  storage_account_name = azurerm_storage_account.eph.name
}

resource "azurerm_storage_container" "eph-ctchr_harmonizer_lease" {
  name                 = "ctchr-harmonizer-lease"
  storage_account_name = azurerm_storage_account.eph.name
}

resource "azurerm_storage_container" "eph-rer_natural_lease" {
  name                 = "rer-natural-lease"
  storage_account_name = azurerm_storage_account.eph.name
}

resource "azurerm_storage_container" "eph-rer_harmonizer_lease" {
  name                 = "rer-harmonizer-lease"
  storage_account_name = azurerm_storage_account.eph.name
}

resource "azurerm_storage_container" "eph-rpo_natural_lease" {
  storage_account_name = azurerm_storage_account.eph.name
  name                 = "rpo-natural-lease"
}

resource "azurerm_storage_container" "eph-rpo_harmonizer_lease" {
  name                 = "rpo-harmonizer-lease"
  storage_account_name = azurerm_storage_account.eph.name
}

resource "azurerm_storage_container" "eph-ecmse_natural_lease" {
  name                 = "ecmse-natural-lease"
  storage_account_name = azurerm_storage_account.eph.name
}

resource "azurerm_storage_container" "eph-ecmse_harmonizer_lease" {
  name                 = "ecmse-harmonizer-lease"
  storage_account_name = azurerm_storage_account.eph.name
}

resource "azurerm_storage_container" "eph-openpos_natural_lease" {
  name                 = "openpos-natural-lease"
  storage_account_name = azurerm_storage_account.eph.name
}

resource "azurerm_storage_container" "eph-gtpos_deltalake" {
  name                 = "gtpos-deltalake"
  storage_account_name = azurerm_storage_account.eph.name
}

# ===========================================================================
resource "azurerm_storage_account" "konvehtife" {
  name                      = "kd${local.env.short}${local.location.short}konvehtife"
  resource_group_name       = azurerm_resource_group.or.name
  location                  = azurerm_resource_group.or.location
  account_tier              = "Standard"
  account_replication_type  = "LRS"
  https_traffic_only_enabled = true
  account_kind              = "StorageV2"
  cross_tenant_replication_enabled = true
  network_rules {
    default_action = "Allow"
    virtual_network_subnet_ids = [ "/subscriptions/0a2d289e-76dd-4b1f-b9b2-dba15a872e92/resourceGroups/rg-platform-avd-prod-weu-001/providers/Microsoft.Network/virtualNetworks/vnet-avd-prod-weu-001/subnets/Subnet-AVDTCS-AMS-prod-weu" ]
  }
  blob_properties {
    delete_retention_policy {
      days = 60
    }
  }

  tags = merge(local.resource_tags, {
    Purpose = "Stores Konvehti Frontend webpage files for publishing"
  })
}

resource "azurerm_storage_container" "konvehtife-release" {
  name                  = "release"
  storage_account_name  = azurerm_storage_account.konvehtife.name
  container_access_type = "container"
}

# ===========================================================================
resource "azurerm_storage_account" "konvehtibe" {
  name                            = "kd${local.env.short}${local.location.short}konvehtibe"
  resource_group_name             = azurerm_resource_group.or.name
  location                        = azurerm_resource_group.or.location
  account_tier                    = "Standard"
  account_replication_type        = "LRS"
  https_traffic_only_enabled      = true
  account_kind                    = "StorageV2"
  allow_nested_items_to_be_public = false
  cross_tenant_replication_enabled = true
  network_rules {
    default_action = "Allow"
    virtual_network_subnet_ids = [ "/subscriptions/0a2d289e-76dd-4b1f-b9b2-dba15a872e92/resourceGroups/rg-platform-avd-prod-weu-001/providers/Microsoft.Network/virtualNetworks/vnet-avd-prod-weu-001/subnets/Subnet-AVDTCS-AMS-prod-weu" ]
  }
  blob_properties {
    delete_retention_policy {
      days = 60
    }
  }

  tags = merge(local.resource_tags, {
    Purpose = "Stores Konvehti backend files and logs"
  })
}

# ===========================================================================
resource "azurerm_storage_account" "nordea" {
  name                            = "${local.prefix_sa}${local.location.short}ornordea"
  resource_group_name             = azurerm_resource_group.or.name
  location                        = azurerm_resource_group.or.location
  account_tier                    = "Standard"
  account_replication_type        = "LRS"
  allow_nested_items_to_be_public = false
  min_tls_version                 = "TLS1_2"
  tags                            = local.resource_tags
  cross_tenant_replication_enabled = true
  network_rules {
    default_action = "Allow"
    virtual_network_subnet_ids = [ "/subscriptions/0a2d289e-76dd-4b1f-b9b2-dba15a872e92/resourceGroups/rg-platform-avd-prod-weu-001/providers/Microsoft.Network/virtualNetworks/vnet-avd-prod-weu-001/subnets/Subnet-AVDTCS-AMS-prod-weu" ]
  }
}
