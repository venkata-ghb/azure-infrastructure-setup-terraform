resource "azurerm_application_insights" "konvehti" {
  name                = "${local.prefix}-${local.location.short}-konvehti-funcapp"
  resource_group_name = azurerm_resource_group.or.name
  location            = azurerm_resource_group.or.location
  application_type    = "web"
  retention_in_days   = 90
  sampling_percentage = 0
  tags = merge(local.resource_tags, {
    "hidden-link:${azurerm_resource_group.or.id}/providers/Microsoft.Web/sites/KDATA-${upper(local.env.short)}-${upper(local.location.short)}-OR-Konvehti-BE-FNC" = "Resource"
  })

  lifecycle {
    ignore_changes = [workspace_id] # Ignore changes to workspace until explicitly set
  }
}

resource "azurerm_windows_function_app" "konvehtibe" {
  name                        = "KDATA-${upper(local.env.short)}-${upper(local.location.short)}-OR-Konvehti-BE-FNC"
  resource_group_name         = azurerm_resource_group.or.name
  location                    = azurerm_resource_group.or.location
  service_plan_id             = azurerm_service_plan.konvehtibe.id
  storage_account_name        = azurerm_storage_account.konvehtibe.name
  storage_account_access_key  = azurerm_storage_account.konvehtibe.primary_access_key
  https_only                  = true
  tags                        = local.resource_tags
  client_certificate_mode     = "Required"
  functions_extension_version = "~4"

  identity {
    type = "SystemAssigned"
  }

  site_config {
    ftps_state                             = "Disabled"
    use_32_bit_worker                      = true
    application_insights_key               = azurerm_application_insights.konvehti.instrumentation_key
    application_insights_connection_string = azurerm_application_insights.konvehti.connection_string

    application_stack {
      node_version = "~20"
    }

    cors {
      allowed_origins = [
        "https://functions-next.azure.com",
        "https://functions-staging.azure.com",
        "https://functions.azure.com",
      ]
    }
  }

  app_settings = {
    NODE_ENV                 = local.env.short != "prod" ? "development" : "production"
    DB_SERVER                = azurerm_mssql_server.public_app.fully_qualified_domain_name
    DB_DATABASE              = azurerm_mssql_database.public_app-or_konvehti.name
    DB_PASSWORD              = "@Microsoft.KeyVault(SecretUri=${data.azurerm_key_vault_secret.or-konvehtiapp.id})"
    WEBSITE_RUN_FROM_PACKAGE = "1"
  }
}

# ---------------------------------------------------------------------------#
# Nordea harmoniser
# ---------------------------------------------------------------------------#
resource "azurerm_linux_function_app" "nordea" {
  name                          = "${local.prefix}-${local.location.short}-or-nordea-funcapp"
  location                      = local.location.long
  resource_group_name           = azurerm_resource_group.or.name
  service_plan_id               = data.terraform_remote_state.integrations.outputs.service_plan_app_premium.id
  storage_account_name          = azurerm_storage_account.nordea.name
  storage_uses_managed_identity = true
  https_only                    = true
  functions_extension_version   = "~4"
  builtin_logging_enabled       = false
  client_certificate_mode       = "Required"
  virtual_network_subnet_id     = data.terraform_remote_state.vnets.outputs.subnet_funcapp_app.id

  identity {
    type = "SystemAssigned"
  }

  site_config {
    always_on                              = true
    ftps_state                             = "Disabled"
    application_insights_key               = azurerm_application_insights.nordea.instrumentation_key
    application_insights_connection_string = azurerm_application_insights.nordea.connection_string
    vnet_route_all_enabled                 = true

    application_stack {
      python_version = "3.13"
    }
  }

  app_settings = {
    AzureWebJobsFeatureFlags         = "EnableWorkerIndexing"
    WEBSITE_ENABLE_SYNC_UPDATE_SITE  = false
    PoisonStorage__serviceUri        = azurerm_storage_account.nordea.primary_blob_endpoint
    ConfluentBroker                  = "lkc-do28gz-6w9n9g.westeurope.azure.glb.confluent.cloud:9092"
    ConfluentSourceTopic             = "com.kesko.com.nordea.life"
    ConfluentTargetTopic             = "com.kesko.com.harmonised.nordea.sales"
    ConfluentConsumer                = "kdata-com-harmoniser"
    ConfluentApiKey                  = "@Microsoft.KeyVault(SecretUri=${data.azurerm_key_vault_secret.or-confluent_com_harmoniser_client_key.id})"
    ConfluentApiSecret               = "@Microsoft.KeyVault(SecretUri=${data.azurerm_key_vault_secret.or-confluent_com_harmoniser_client_secret.id})"
    CONFLUENT_SCHEMA_REGISTRY_URL    = "https://psrc-d88yz.westeurope.azure.confluent.cloud"
    CONFLUENT_SCHEMA_REGISTRY_KEY    = "@Microsoft.KeyVault(SecretUri=${data.azurerm_key_vault_secret.or-confluent_schema_api_key.id})"
    CONFLUENT_SCHEMA_REGISTRY_SECRET = "@Microsoft.KeyVault(SecretUri=${data.azurerm_key_vault_secret.or-confluent_schema_api_secret.id})"
    LD_LIBRARY_PATH                  = "/home/site/wwwroot/bin/runtimes/linux-x64/native"
  }

  tags = local.resource_tags

  lifecycle {
    ignore_changes = [
      app_settings["WEBSITE_ENABLE_SYNC_UPDATE_SITE"],
      app_settings["WEBSITE_RUN_FROM_PACKAGE"],
      tags["hidden-link: /app-insights-conn-string"],
      tags["hidden-link: /app-insights-instrumentation-key"],
      tags["hidden-link: /app-insights-resource-id"],
    ]
  }
}

resource "azurerm_application_insights" "nordea" {
  name                = "${local.prefix}-${local.location.short}-or-nordea-funcapp"
  location            = local.location.long
  resource_group_name = azurerm_resource_group.or.name
  application_type    = "web"
  retention_in_days   = 90
  sampling_percentage = 0
  tags                = local.resource_tags

  lifecycle {
    ignore_changes = [workspace_id] # Ignore changes to workspace until explicitly set
  }
}
