# or
resource "azurerm_key_vault_secret" "or-gtpos_natural_read" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "gtpos-natural-evh-endpoint-read"
  value        = azurerm_eventhub_authorization_rule.gtpos-natural-k8s_read.primary_connection_string
  content_type = "GT POS Natural EvenhHub's endpoint read access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-gtpos_natural_write" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "gtpos-natural-evh-endpoint-write"
  value        = azurerm_eventhub_authorization_rule.gtpos-natural-k8s_write.primary_connection_string
  content_type = "GT POS Natural EvenhHub's endpoint write access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-gtpos_harmonised_json_read" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "gtpos-harmonised-json-evh-endpoint-read"
  value        = azurerm_eventhub_authorization_rule.gtpos-harmonised-k8s_read.primary_connection_string
  content_type = "GT POS Harmonised JSON EvenhHub's endpoint read access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-gtpos_harmonised_json_write" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "gtpos-harmonised-json-evh-endpoint-write"
  value        = azurerm_eventhub_authorization_rule.gtpos-harmonised-k8s_write.primary_connection_string
  content_type = "GT POS Harmonised JSON EvenhHub's endpoint write access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-ctchr_natural_read" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "ctchr-natural-evh-endpoint-read"
  value        = azurerm_eventhub_authorization_rule.ctchr-natural-k8s_read.primary_connection_string
  content_type = "K-charge Natural EvenhHub's endpoint read access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-ctchr_natural_write" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "ctchr-natural-evh-endpoint-write"
  value        = azurerm_eventhub_authorization_rule.ctchr-natural-k8s_write.primary_connection_string
  content_type = "K-charge Natural EvenhHub's endpoint write access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-ctchr_harmonised_json_read" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "ctchr-harmonised-json-evh-endpoint-read"
  value        = azurerm_eventhub_authorization_rule.ctchr-harmonised-k8s_read.primary_connection_string
  content_type = "K-charge Harmonised JSON EvenhHub's endpoint read access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-ctchr_harmonised_json_write" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "ctchr-harmonised-json-evh-endpoint-write"
  value        = azurerm_eventhub_authorization_rule.ctchr-harmonised-k8s_write.primary_connection_string
  content_type = "K-charge Harmonised JSON EvenhHub's endpoint write access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-rer_natural_read" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "rer-natural-evh-endpoint-read"
  value        = azurerm_eventhub_authorization_rule.rer-natural-k8s_read.primary_connection_string
  content_type = "Raksa ERP Natural EvenhHub's endpoint read access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-rer_natural_write" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "rer-natural-evh-endpoint-write"
  value        = azurerm_eventhub_authorization_rule.rer-natural-k8s_write.primary_connection_string
  content_type = "Raksa ERP Natural EvenhHub's endpoint write access"
  tags         = local.resource_tags
}


resource "azurerm_key_vault_secret" "or-rer_harmonised_json_read" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "rer-harmonised-json-evh-endpoint-read"
  value        = azurerm_eventhub_authorization_rule.rer-harmonised-k8s_read.primary_connection_string
  content_type = "Raksa ERP Harmonised JSON EvenhHub's endpoint read access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-rer_harmonised_json_write" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "rer-harmonised-json-evh-endpoint-write"
  value        = azurerm_eventhub_authorization_rule.rer-harmonised-k8s_write.primary_connection_string
  content_type = "Raksa ERP Harmonised JSON EvenhHub's endpoint write access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-rpo_natural_read" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "rpo-natural-evh-endpoint-read"
  value        = azurerm_eventhub_authorization_rule.rpo-natural-k8s_read.primary_connection_string
  content_type = "Raksa POS Natural EvenhHub's endpoint read access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-rpo_natural_write" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "rpo-natural-evh-endpoint-write"
  value        = azurerm_eventhub_authorization_rule.rpo-natural-k8s_write.primary_connection_string
  content_type = "Raksa POS Natural EvenhHub's endpoint write access"
  tags         = local.resource_tags
}


resource "azurerm_key_vault_secret" "or-rpo_harmonised_json_read" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "rpo-harmonised-json-evh-endpoint-read"
  value        = azurerm_eventhub_authorization_rule.rpo-harmonised-k8s_read.primary_connection_string
  content_type = "Raksa POS Harmonised JSON EvenhHub's endpoint read access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-rpo_harmonised_json_write" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "rpo-harmonised-json-evh-endpoint-write"
  value        = azurerm_eventhub_authorization_rule.rpo-harmonised-k8s_write.primary_connection_string
  content_type = "Raksa POS Harmonised JSON EvenhHub's endpoint write access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-ecmse_natural_read" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "ecmse-natural-evh-endpoint-read"
  value        = azurerm_eventhub_authorization_rule.ecmse-natural-k8s_read.primary_connection_string
  content_type = "K-rauta.fi Natural EvenhHub's endpoint read access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-ecmse_natural_write" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "ecmse-natural-evh-endpoint-write"
  value        = azurerm_eventhub_authorization_rule.ecmse-natural-k8s_write.primary_connection_string
  content_type = "K-rauta.fi Natural EvenhHub's endpoint write access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-ecmse_harmonised_json_read" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "ecmse-harmonised-json-evh-endpoint-read"
  value        = azurerm_eventhub_authorization_rule.ecmse-harmonised-k8s_read.primary_connection_string
  content_type = "K-rauta.fi Harmonised JSON EvenhHub's endpoint read access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-ecmse_harmonised_json_write" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "ecmse-harmonised-json-evh-endpoint-write"
  value        = azurerm_eventhub_authorization_rule.ecmse-harmonised-k8s_write.primary_connection_string
  content_type = "K-rauta.fi Harmonised JSON EvenhHub's endpoint write access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-btt_receipt_archive_transaction_harmonised_or_k8s_read" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "btt-receipt-archive-harmonised-json-evh-endpoint-read"
  value        = azurerm_eventhub_authorization_rule.btt_receipt_archive-transaction_harmonised-or_k8s_read.primary_connection_string
  content_type = "K-rauta receipt archive Harmonised JSON EvenhHub's endpoint read access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-btt_receipt_archive_transaction_harmonised_or_k8s_write" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "btt-receipt-archive-harmonised-json-evh-endpoint-write"
  value        = azurerm_eventhub_authorization_rule.btt_receipt_archive-transaction_harmonised-or_k8s_write.primary_connection_string
  content_type = "K-rauta receipt archive Harmonised JSON EvenhHub's endpoint write access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-marketpay_standalone_transaction_harmonised_or_k8s_read" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "marketpay-standalone-harmonised-json-evh-endpoint-read"
  value        = azurerm_eventhub_authorization_rule.marketpay-standalone_transaction_harmonised-or_k8s_read.primary_connection_string
  content_type = "Marketpay Standalone Harmonised JSON EvenhHub's endpoint read access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or-marketpay_standalone_transaction_harmonised_or_k8s_write" {
  key_vault_id = azurerm_key_vault.or.id
  name         = "marketpay-standalone-harmonised-json-evh-endpoint-write"
  value        = azurerm_eventhub_authorization_rule.marketpay-standalone_transaction_harmonised-or_k8s_write.primary_connection_string
  content_type = "Marketpay Standalone Harmonised JSON EvenhHub's endpoint write access"
  tags         = local.resource_tags
}

# datapower
resource "azurerm_key_vault_secret" "or_dp-gtpos_datapower" {
  key_vault_id = azurerm_key_vault.or_dp.id
  name         = "gtpos-natural-evh-endpoint-datapower"
  value        = azurerm_eventhub_authorization_rule.gtpos-natural-datapower.primary_connection_string
  content_type = "GT POS Natural EvenhHub's endpoint datapower access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or_dp-ctchr_datapower" {
  key_vault_id = azurerm_key_vault.or_dp.id
  name         = "ctchr-natural-evh-endpoint-datapower"
  value        = azurerm_eventhub_authorization_rule.ctchr-natural-datapower.primary_connection_string
  content_type = "K-charge Natural EvenhHub's endpoint datapower access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or_dp-rer_datapower" {
  key_vault_id = azurerm_key_vault.or_dp.id
  name         = "rer-natural-evh-endpoint-datapower"
  value        = azurerm_eventhub_authorization_rule.rer-natural-datapower.primary_connection_string
  content_type = "Raksa ERP Natural EvenhHub's endpoint datapower access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or_dp-rpo_datapower" {
  key_vault_id = azurerm_key_vault.or_dp.id
  name         = "rpo-natural-evh-endpoint-datapower"
  value        = azurerm_eventhub_authorization_rule.rpo-natural-datapower.primary_connection_string
  content_type = "Raksa POS Natural EvenhHub's endpoint datapower access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "or_dp-ecmse_datapower" {
  key_vault_id = azurerm_key_vault.or_dp.id
  name         = "ecmse-natural-evh-endpoint-datapower"
  value        = azurerm_eventhub_authorization_rule.ecmse-natural-datapower.primary_connection_string
  content_type = "ECOM Sweden Natural EvenhHub's endpoint datapower access"
  tags         = local.resource_tags
}
