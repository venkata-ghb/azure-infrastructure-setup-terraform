resource "azurerm_service_plan" "konvehtibe" {
  name                = "KDATA-${upper(local.env.short)}-${upper(local.location.short)}-OR-Konvehti-be-plan"
  resource_group_name = azurerm_resource_group.or.name
  location            = azurerm_resource_group.or.location
  os_type             = "Windows"
  sku_name            = "Y1"
  tags                = local.resource_tags
}
