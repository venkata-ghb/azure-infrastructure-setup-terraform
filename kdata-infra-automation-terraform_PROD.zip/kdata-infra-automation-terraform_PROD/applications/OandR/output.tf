output "kv_or" {
  value = {
    id        = azurerm_key_vault.or.id
    name      = azurerm_key_vault.or.name
    vault_uri = azurerm_key_vault.or.vault_uri
  }
}

output "sa_harmonizers" {
  value = {
    id   = azurerm_storage_account.harmonizers.id
    name = azurerm_storage_account.harmonizers.name
  }
}

output "sa_harmonizers_secrets" {
  value = {
    access_key        = azurerm_storage_account.harmonizers.primary_access_key
    connection_string = azurerm_storage_account.harmonizers.primary_connection_string
  }
  sensitive = true
}

output "sa_b2bdr" {
  value = {
    id   = azurerm_storage_account.b2bdr.id
    name = azurerm_storage_account.b2bdr.name
  }
}

output "sa_b2bdr_secrets" {
  value = {
    access_key        = azurerm_storage_account.b2bdr.primary_access_key
    connection_string = azurerm_storage_account.b2bdr.primary_connection_string
  }
  sensitive = true
}

output "sa_push" {
  value = {
    id   = azurerm_storage_account.push.id
    name = azurerm_storage_account.push.name
  }
}

output "sa_push_secrets" {
  value = {
    access_key        = azurerm_storage_account.push.primary_access_key
    connection_string = azurerm_storage_account.push.primary_connection_string
  }
  sensitive = true
}

output "sa_rawdlq" {
  value = {
    id   = azurerm_storage_account.rawdlq.id
    name = azurerm_storage_account.rawdlq.name
  }
}

output "sa_eph" {
  value = {
    id   = azurerm_storage_account.eph.id
    name = azurerm_storage_account.eph.name
  }
}

output "mssql_server_public_app" {
  value = {
    id                          = azurerm_mssql_server.public_app.id
    name                        = azurerm_mssql_server.public_app.name
    fully_qualified_domain_name = azurerm_mssql_server.public_app.fully_qualified_domain_name
  }
}
output "table_b2bdr_table" {
  value = {
    id   = azurerm_storage_table.b2bdr-table.id
    name = azurerm_storage_table.b2bdr-table.name
  }
}

