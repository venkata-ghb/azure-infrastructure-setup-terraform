data "azurerm_client_config" "current" {}

resource "azurerm_key_vault" "or" {
  name                        = "k-data-${local.env.short}-${local.location.short}-or-vault"
  location                    = azurerm_resource_group.or.location
  resource_group_name         = azurerm_resource_group.or.name
  tenant_id                   = data.azurerm_client_config.current.tenant_id
  sku_name                    = "standard"
  enabled_for_disk_encryption = true
  purge_protection_enabled    = true
  tags                        = local.resource_tags

  access_policy = [local.msi_infra_key_vault_access]

  lifecycle { ignore_changes = [access_policy] }
}

resource "azurerm_key_vault_access_policy" "or-msi_infra" {
  key_vault_id            = azurerm_key_vault.or.id
  tenant_id               = local.msi_infra_key_vault_access.tenant_id
  object_id               = local.msi_infra_key_vault_access.object_id
  certificate_permissions = local.msi_infra_key_vault_access.certificate_permissions
  key_permissions         = local.msi_infra_key_vault_access.key_permissions
  secret_permissions      = local.msi_infra_key_vault_access.secret_permissions
  storage_permissions     = local.msi_infra_key_vault_access.storage_permissions
}

resource "azurerm_key_vault_access_policy" "or-group_admins_platform" {
  key_vault_id            = azurerm_key_vault.or.id
  tenant_id               = data.azurerm_client_config.current.tenant_id
  object_id               = data.terraform_remote_state.ad.outputs.group_admins_platform.id
  certificate_permissions = ["Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"]
  key_permissions         = ["Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"]
  secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
  storage_permissions     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"]
}

resource "azurerm_key_vault_access_policy" "or-group_devops_or" {
  key_vault_id = azurerm_key_vault.or.id
  tenant_id    = azurerm_windows_function_app.konvehtibe.identity.0.tenant_id
  object_id    = data.terraform_remote_state.ad.outputs.group_devops_or.id

  secret_permissions = [
    "Set",
    "Get",
    "List",
    "Delete",
  ]
}

resource "azurerm_key_vault_access_policy" "or-sp_or_azdevops" {
  key_vault_id = azurerm_key_vault.or.id
  tenant_id    = data.azurerm_client_config.current.tenant_id
  object_id    = data.terraform_remote_state.ad.outputs.sp_or_azdevops.id

  secret_permissions = [
    "Get",
    "List",
  ]
}

resource "azurerm_key_vault_access_policy" "or-sp_platform_devops" {
  key_vault_id = azurerm_key_vault.or.id
  tenant_id    = data.azurerm_client_config.current.tenant_id
  object_id    = data.terraform_remote_state.ad.outputs.sp_platform_devops.id

  secret_permissions = [
    "Get",
    "List",
  ]
}

resource "azurerm_key_vault_access_policy" "or-msi_konvehtibe" {
  key_vault_id       = azurerm_key_vault.or.id
  tenant_id          = data.azurerm_client_config.current.tenant_id
  object_id          = azurerm_windows_function_app.konvehtibe.identity.0.principal_id
  key_permissions    = ["Get", ]
  secret_permissions = ["Set", "Get", "Delete", ]
}

resource "azurerm_key_vault_access_policy" "or-msi_adf_int" {
  key_vault_id       = azurerm_key_vault.or.id
  tenant_id          = data.azurerm_client_config.current.tenant_id
  object_id          = data.terraform_remote_state.integrations.outputs.adf_int.msi
  secret_permissions = ["Get", ]
}

resource "azurerm_key_vault_access_policy" "or-msi_nordea_funcapp" {
  key_vault_id       = azurerm_key_vault.or.id
  tenant_id          = azurerm_linux_function_app.nordea.identity[0].tenant_id
  object_id          = azurerm_linux_function_app.nordea.identity[0].principal_id
  secret_permissions = ["Get", ]
}

# =================================================================================
resource "azurerm_key_vault" "or_dp" {
  name                        = "${local.prefix}-or-dp-kv"
  location                    = local.location.long
  resource_group_name         = azurerm_resource_group.or.name
  tenant_id                   = data.azurerm_client_config.current.tenant_id
  sku_name                    = "standard"
  enabled_for_disk_encryption = false
  purge_protection_enabled    = true
  tags                        = local.resource_tags

  access_policy = [
    local.msi_infra_key_vault_access,
    {
      tenant_id               = data.azurerm_client_config.current.tenant_id
      object_id               = data.terraform_remote_state.ad.outputs.group_admins_platform.id
      application_id          = ""
      certificate_permissions = ["Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"]
      key_permissions         = ["Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"]
      secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
      storage_permissions     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"]
    },
    {
      tenant_id               = data.azurerm_client_config.current.tenant_id
      object_id               = data.terraform_remote_state.ad.outputs.group_devops_platform.id
      application_id          = ""
      certificate_permissions = []
      key_permissions         = []
      secret_permissions      = ["Get", "List", ]
      storage_permissions     = []
    },
    {
      tenant_id               = data.azurerm_client_config.current.tenant_id
      object_id               = data.terraform_remote_state.ad.outputs.sp_or_terraform.id
      application_id          = ""
      certificate_permissions = []
      key_permissions         = ["Get", ]
      secret_permissions      = ["Get", "List", "Delete", ]
      storage_permissions     = []
    },
  ]
}

resource "azurerm_key_vault" "or_tbtrk" {
  name                        = "${local.prefix}-or-tbtrk-kv"
  location                    = local.location.long
  resource_group_name         = azurerm_resource_group.or.name
  tenant_id                   = data.azurerm_client_config.current.tenant_id
  sku_name                    = "standard"
  enabled_for_disk_encryption = false
  purge_protection_enabled    = true
  tags                        = local.resource_tags

  access_policy = [
    local.msi_infra_key_vault_access,
    {
      tenant_id               = data.azurerm_client_config.current.tenant_id
      object_id               = data.terraform_remote_state.ad.outputs.group_admins_platform.id
      application_id          = ""
      certificate_permissions = ["Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"]
      key_permissions         = ["Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"]
      secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
      storage_permissions     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"]
    },
    {
      tenant_id               = data.azurerm_client_config.current.tenant_id
      object_id               = data.terraform_remote_state.ad.outputs.group_devops_platform.id
      application_id          = ""
      certificate_permissions = []
      key_permissions         = []
      secret_permissions      = ["Set", "Get", "List", "Delete", ]
      storage_permissions     = []
    },
  ]
}
