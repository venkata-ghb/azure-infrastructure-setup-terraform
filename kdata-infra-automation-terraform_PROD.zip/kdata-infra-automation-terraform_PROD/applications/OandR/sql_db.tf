resource "azurerm_mssql_database" "public_app-or" {
  name        = "or-${lower(local.env.short)}"
  server_id   = azurerm_mssql_server.public_app.id
  collation   = "Latin1_General_100_BIN2_UTF8"
  sku_name    = "S7"
  max_size_gb = 1024
  tags        = local.resource_tags
}

resource "azurerm_mssql_database" "public_app-or_konvehti" {
  name        = "or-${lower(local.env.short)}-konvehti"
  server_id   = azurerm_mssql_server.public_app.id
  sku_name    = "Basic"
  max_size_gb = 2
  tags        = local.resource_tags
}

