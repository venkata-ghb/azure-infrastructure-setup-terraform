resource "azurerm_api_management_api_diagnostic" "konvehti" {
  provider                 = azurerm.apim
  identifier               = "applicationinsights"
  resource_group_name      = data.azurerm_api_management.apimanagement.resource_group_name
  api_management_name      = data.azurerm_api_management.apimanagement.name
  api_name                 = azurerm_api_management_api.konvehti.name
  api_management_logger_id = data.terraform_remote_state.apim.outputs.apim_logger.id
  always_log_errors        = true
  }
