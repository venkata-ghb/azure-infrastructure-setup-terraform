resource "azurerm_resource_group" "or" {
  name     = "${local.prefix_rg}_OR_Main_RG"
  location = local.location.long
  tags     = local.resource_tags
}

resource "azurerm_resource_group" "robot" {
  name     = "${local.prefix_rg}_Robot_RG"
  location = local.location.long
  tags     = local.resource_tags
}
