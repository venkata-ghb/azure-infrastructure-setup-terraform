data "azurerm_subscription" "current" {}

locals {
  common_eph_filters    = "LogEntry !contains \"TimeoutError\" and LogEntry !contains \"failed to persist checkpoint\" and LogEntry !contains \"offset/sequenceNumber invalid\" and LogEntry !contains \"The service was unable to process the request please retry the operation\" and LogEntry !contains \"Unable to open authentication session on connection\" and LogEntry !contains \"The lease ID specified did not match the lease ID for the blob\" and LogEntry !contains \"New receiver 'nil' with higher epoch of '0' is created hence current receiver 'nil' with epoch '0' is getting disconnected\""
  common_eph_filters_v2 = join(" and ", [
    "LogMessage !has \"TimeoutError\"",
    "LogMessage !has \"failed to persist checkpoint\"",
    "LogMessage !has \"offset/sequenceNumber invalid\"",
    "LogMessage !has \"The service was unable to process the request please retry the operation\"",
    "LogMessage !has \"Unable to open authentication session on connection\"",
    "LogMessage !has \"The lease ID specified did not match the lease ID for the blob\"",
    "LogMessage !has \"New receiver 'nil' with higher epoch of '0' is created hence current receiver 'nil' with epoch '0' is getting disconnected\"",
    "LogMessage !has \"Connection was already closed\"",
    "LogMessage !has \"The connection was closed by container\""
  ])
}

resource "azurerm_monitor_action_group" "technical" {
  name                = "${local.prefix}-technical-errors-action-group"
  resource_group_name = azurerm_resource_group.or.name
  short_name          = "app-errors"
  tags                = local.resource_tags

  email_receiver {
    name          = "DL_KESKOAMS_TCS_KDATA"
    email_address = "DL_KESKOAMS_TCS_KDATA@kesko.fi"
  }
  email_receiver {
    name          = "NicoMiettinen"
    email_address = "nico.miettinen@kesko.fi"
  }
}

resource "azurerm_monitor_action_group" "integration" {
  name                = "${local.prefix}-integration-errors-action-group"
  resource_group_name = azurerm_resource_group.or.name
  short_name          = "intg-errors"
  tags                = local.resource_tags

  email_receiver {
    name          = "DL_KESKOAMS_TCS_KDATA"
    email_address = "DL_KESKOAMS_TCS_KDATA@kesko.fi"
  }
  email_receiver {
    name          = "NicoMiettinen"
    email_address = "nico.miettinen@kesko.fi"
  }
}

resource "azurerm_monitor_action_group" "igniointegration" {
  name                = "igniointegration"
  resource_group_name = azurerm_resource_group.or.name
  short_name          = "IgnioIntegra"
  tags                = local.resource_tags

  email_receiver {
    name          = "DL_KESKOAMS_TCS_KDATA"
    email_address = "DL_KESKOAMS_TCS_KDATA@kesko.fi"
  }
  email_receiver {
    name          = "NicoMiettinen"
    email_address = "nico.miettinen@kesko.fi"
  }
  email_receiver {
    name          = "Ignioauto_UAT"
    email_address = "Ignio_UAT@kesko.fi"
  }
  email_receiver {
    name          = "Ignioauto_PROD"
    email_address = "Ignio_PROD@kesko.fi"
  }
  email_receiver {
    name          = "BalajeeRajavelu"
    email_address = "ext.balajee.rajavelu@kesko.fi"
  }
  email_receiver {
    name          = "VenkatasubbaiahKuruva"
    email_address = "venkatasubbaiah.kuruva@tcs.com"
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-etl_log_errors" {
  name                    = "${local.prefix}-etl-log-errors-alert"
  location                = azurerm_resource_group.or.location
  resource_group_name     = azurerm_resource_group.or.name
  authorized_resource_ids = [data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id]
  tags                    = local.resource_tags

  action {
    action_group  = [lower(azurerm_monitor_action_group.technical.id)]
    email_subject = "Azure: K-Data ETL log alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "Errors were found from ETL logs."
  enabled        = true

  query       = <<QUERY
ContainerLogV2
| where _ResourceId endswith "${data.terraform_remote_state.container.outputs.aks_platform.name}"
| where PodNamespace == 'receipts' and ContainerName == 'or-etl-app-pod'
| where (LogMessage contains "ERROR:EventProcessor" or LogMessage contains "ERROR:SimpleSQLClient")
  QUERY
  severity    = 1
  frequency   = 5
  time_window = 5
  throttling  = 720
  trigger {
    operator  = "GreaterThan"
    threshold = 0
  }

}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-etl_rejected_events" {
  name                    = "${local.prefix}-etl-rejected-events-alert"
  location                = azurerm_resource_group.or.location
  resource_group_name     = azurerm_resource_group.or.name
  authorized_resource_ids = [data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id]
  tags                    = local.resource_tags

  action {
    action_group  = [lower(azurerm_monitor_action_group.technical.id)]
    email_subject = "Azure: K-Data ETL rejected events alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "Rejected events were found from ETL logs."
  enabled        = true

  query       = <<QUERY
ContainerLogV2
| where _ResourceId endswith "${data.terraform_remote_state.container.outputs.aks_platform.name}"
| where PodNamespace == 'receipts' and ContainerName == 'or-etl-app-pod'
| where LogMessage contains "ERROR:StorageHandler:Putting event to rejected events table"
QUERY
  severity    = 2
  frequency   = 5
  time_window = 5
  throttling  = 720
  trigger {
    operator  = "GreaterThan"
    threshold = 10
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-ctchr_harmonizer_errors" {
  name                    = "${local.prefix}-ctchr-harmonizer-log-errors-alert"
  location                = azurerm_resource_group.or.location
  resource_group_name     = azurerm_resource_group.or.name
  authorized_resource_ids = [data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id]
  tags                    = local.resource_tags

  action {
    action_group  = [lower(azurerm_monitor_action_group.technical.id)]
    email_subject = "Azure: K-Data CTCHR-harmonizer log alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "Errors were found from ctchr harmonizer logs."
  enabled        = true

  query       = <<QUERY
ContainerLogV2
| where _ResourceId endswith "${data.terraform_remote_state.container.outputs.aks_platform.name}"
| where PodNamespace == "receipts" and ContainerName == "ctchr-json-harmoniser-app-pod"
| where LogMessage contains "ERROR:main" or LogMessage contains "ERROR:HarmonizingEventProcessor"
| where ${local.common_eph_filters_v2}
QUERY
  severity    = 0
  frequency   = 5
  time_window = 5
  throttling  = 720
  trigger {
    operator  = "GreaterThan"
    threshold = 0
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-push_service_errors" {
  name                    = "${local.prefix}-push-service-log-errors-alert"
  location                = azurerm_resource_group.or.location
  resource_group_name     = azurerm_resource_group.or.name
  authorized_resource_ids = [data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id]
  tags                    = local.resource_tags

  action {
    action_group  = [
      lower(azurerm_monitor_action_group.technical.id),
      lower(azurerm_monitor_action_group.igniointegration.id),
    ]
    email_subject = "Azure: K-Data push service log alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "Errors were found from push service logs."
  enabled        = true

  query       = <<QUERY
ContainerLogV2
| where _ResourceId endswith "${data.terraform_remote_state.container.outputs.aks_platform.name}"
| where PodNamespace == "receipts" and (ContainerName == "or-push-service-app-pod" or ContainerName == "or-push-service-to-ereceipt-app-pod")
| where LogMessage contains "ERROR:PushService"
| where ${local.common_eph_filters_v2}
QUERY
  severity    = 0
  frequency   = 5
  time_window = 30
  throttling  = 60
  trigger {
    operator  = "GreaterThan"
    threshold = 0
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-rer_harmonizer_errors" {
  name                    = "${local.prefix}-rer-harmonizer-log-errors-alert"
  location                = azurerm_resource_group.or.location
  resource_group_name     = azurerm_resource_group.or.name
  authorized_resource_ids = [data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id]
  tags                    = local.resource_tags

  action {
    action_group  = [lower(azurerm_monitor_action_group.technical.id)]
    email_subject = "Azure: K-Data RER harmoniser log alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "Errors were found from rer harmoniser logs."
  enabled        = true

  query       = <<QUERY
ContainerLogV2
| where _ResourceId endswith "${data.terraform_remote_state.container.outputs.aks_platform.name}"
| where PodNamespace == "receipts" and ContainerName == "raksa-erp-harmonizer-app-pod"
| where LogMessage contains "ERROR:main" or LogMessage contains "ERROR:HarmonizingEventProcessor"
| where ${local.common_eph_filters_v2}
QUERY
  severity    = 0
  frequency   = 5
  time_window = 5
  throttling  = 60
  trigger {
    operator  = "GreaterThan"
    threshold = 0
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-rpo_harmonizer_errors" {
  name                    = "${local.prefix}-rpo-harmonizer-log-errors-alert"
  location                = azurerm_resource_group.or.location
  resource_group_name     = azurerm_resource_group.or.name
  authorized_resource_ids = [data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id]
  tags                    = local.resource_tags

  action {
    action_group  = [lower(azurerm_monitor_action_group.technical.id)]
    email_subject = "Azure: K-Data RPO harmoniser log alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "Errors were found from rpo harmoniser logs."
  enabled        = true

  query       = <<QUERY
ContainerLogV2
| where _ResourceId endswith "${data.terraform_remote_state.container.outputs.aks_platform.name}"
| where PodNamespace == "receipts" and ContainerName == "raksa-pos-harmonizer-app-pod"
| where LogMessage contains "ERROR:main" or LogMessage contains "ERROR:HarmonizingEventProcessor"
| where ${local.common_eph_filters_v2}
QUERY
  severity    = 0
  frequency   = 5
  time_window = 5
  throttling  = 60
  trigger {
    operator  = "GreaterThan"
    threshold = 0
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-ecmse_harmonizer_errors" {
  name                    = "${local.prefix}-ecmse-harmonizer-log-errors-alert"
  location                = azurerm_resource_group.or.location
  resource_group_name     = azurerm_resource_group.or.name
  authorized_resource_ids = [data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id]
  tags                    = local.resource_tags

  action {
    action_group  = [lower(azurerm_monitor_action_group.technical.id)]
    email_subject = "Azure: K-Data ECOM Sweden harmoniser log alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "Errors were found from ecmse harmoniser logs."
  enabled        = true

  query       = <<QUERY
ContainerLogV2
| where _ResourceId endswith "${data.terraform_remote_state.container.outputs.aks_platform.name}"
| where PodNamespace == "receipts" and ContainerName == "ecomse-adapter-app-pod"
| where LogMessage contains "ERROR:main" or LogMessage contains "ERROR:HarmonizingEventProcessor"
| where ${local.common_eph_filters_v2}
QUERY
  severity    = 0
  frequency   = 5
  time_window = 5
  throttling  = 60
  trigger {
    operator  = "GreaterThan"
    threshold = 0
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-b2bdr_errors" {
  name                    = "${local.prefix}-b2bdr-log-errors-alert"
  location                = azurerm_resource_group.or.location
  resource_group_name     = azurerm_resource_group.or.name
  authorized_resource_ids = [data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id]
  tags                    = local.resource_tags

  action {
    action_group  = [lower(azurerm_monitor_action_group.technical.id)]
    email_subject = "Azure: K-Data B2BDR log alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "Errors were found from b2bdr logs."
  enabled        = true

  query       = <<QUERY
ContainerLogV2
| where _ResourceId endswith "${data.terraform_remote_state.container.outputs.aks_platform.name}"
| where PodNamespace == "receipts" and ContainerName == "or-b2bdr-app-pod"
| where LogMessage contains "ERROR"
QUERY
  severity    = 0
  frequency   = 5
  time_window = 5
  throttling  = 60
  trigger {
    operator  = "GreaterThan"
    threshold = 0
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-push_service_failed_receipts" {
  name                    = "${local.prefix}-push-service-failed-receipts-alert"
  location                = azurerm_resource_group.or.location
  resource_group_name     = azurerm_resource_group.or.name
  authorized_resource_ids = [data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id]
  tags                    = local.resource_tags

  action {
    action_group  = [lower(azurerm_monitor_action_group.technical.id)]
    email_subject = "Azure: K-Data Push Service failed receipts alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "Failed receipts were found from Push Service Blob Storage. Needs manual recovery."
  enabled        = true

  query       = <<QUERY
ContainerLogV2
| where _ResourceId endswith "${data.terraform_remote_state.container.outputs.aks_platform.name}"
| where PodNamespace == "receipts" and (ContainerName == "or-push-service-app-pod" or ContainerName == "or-push-service-to-ereceipt-app-pod")
| where LogMessage contains "Sent failed receipt to Blob Storage"
QUERY
  severity    = 0
  frequency   = 5
  time_window = 5
  throttling  = 30
  trigger {
    operator  = "GreaterThan"
    threshold = 0
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-rer_harmoniser_failed_events" {
  name                    = "${local.prefix}-rer-harmoniser-failed-events-alert"
  location                = azurerm_resource_group.or.location
  resource_group_name     = azurerm_resource_group.or.name
  authorized_resource_ids = [data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id]
  tags                    = local.resource_tags

  action {
    action_group  = [
      lower(azurerm_monitor_action_group.technical.id),
      lower(azurerm_monitor_action_group.igniointegration.id),
    ]
    email_subject = "Azure: K-Data Raksa ERP failed events alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "Failed receipts were found from Raksa ERP harmoniser Blob Storage. Needs manual recovery."
  enabled        = true

  query       = <<QUERY
ContainerLogV2
| where _ResourceId endswith "${data.terraform_remote_state.container.outputs.aks_platform.name}"
| where PodNamespace == "receipts" and ContainerName == "raksa-erp-harmonizer-app-pod"
| where LogMessage contains "Sent failed receipt to Blob Storage"
QUERY
  severity    = 0
  frequency   = 5
  time_window = 5
  throttling  = 30
  trigger {
    operator  = "GreaterThan"
    threshold = 0
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-rpo_harmoniser_failed_events" {
  name                    = "${local.prefix}-rpo-harmoniser-failed-events-alert"
  location                = azurerm_resource_group.or.location
  resource_group_name     = azurerm_resource_group.or.name
  authorized_resource_ids = [data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id]
  tags                    = local.resource_tags

  action {
    action_group  = [lower(azurerm_monitor_action_group.technical.id)]
    email_subject = "Azure: K-Data Raksa POS failed events alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "Failed receipts were found from Raksa POS harmoniser Blob Storage. Needs manual recovery."
  enabled        = true

  query       = <<QUERY
ContainerLogV2
| where _ResourceId endswith "${data.terraform_remote_state.container.outputs.aks_platform.name}"
| where PodNamespace == "receipts" and ContainerName == "raksa-pos-harmonizer-app-pod"
| where LogMessage contains "Sent failed receipt to Blob Storage"
QUERY
  severity    = 0
  frequency   = 5
  time_window = 5
  throttling  = 30
  trigger {
    operator  = "GreaterThan"
    threshold = 0
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-ecmse_harmoniser_failed_events" {
  name                    = "${local.prefix}-ecmse-harmoniser-failed-events-alert"
  location                = azurerm_resource_group.or.location
  resource_group_name     = azurerm_resource_group.or.name
  authorized_resource_ids = [data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id]
  tags                    = local.resource_tags

  action {
    action_group  = [lower(azurerm_monitor_action_group.technical.id)]
    email_subject = "Azure: K-Data ECOM Sweden failed events alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "Failed receipts were found from ECOM Sweden harmoniser Blob Storage. Needs manual recovery."
  enabled        = true

  query       = <<QUERY
ContainerLogV2
| where _ResourceId endswith "${data.terraform_remote_state.container.outputs.aks_platform.name}"
| where PodNamespace == "receipts" and ContainerName == "ecomse-adapter-app-pod"
| where LogMessage contains "Sent failed receipt to Blob Storage"
QUERY
  severity    = 0
  frequency   = 5
  time_window = 5
  throttling  = 30
  trigger {
    operator  = "GreaterThan"
    threshold = 0
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-ctchr_harmoniser_failed_events" {
  name                    = "${local.prefix}-ctchr-harmoniser-failed-events-alert"
  location                = azurerm_resource_group.or.location
  resource_group_name     = azurerm_resource_group.or.name
  authorized_resource_ids = [data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id]
  tags                    = local.resource_tags

  action {
    action_group  = [lower(azurerm_monitor_action_group.technical.id)]
    email_subject = "Azure: K-Data CTCHR failed events alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "Failed events were found from CTCHR harmoniser Blob Storage. Needs manual recovery."
  enabled        = true

  query       = <<QUERY
ContainerLogV2
| where _ResourceId endswith "${data.terraform_remote_state.container.outputs.aks_platform.name}"
| where PodNamespace == "receipts" and ContainerName == "ctchr-json-harmoniser-app-pod"
| where LogMessage contains "Sent failed receipt to Blob Storage"
QUERY
  severity    = 0
  frequency   = 5
  time_window = 5
  throttling  = 30
  trigger {
    operator  = "GreaterThan"
    threshold = 0
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-push_service_ereceipt_partition_no_flow" {
  name                    = "${local.prefix}-push-service-ereceipt-partition-no-flow-alert"
  location                = azurerm_resource_group.or.location
  resource_group_name     = azurerm_resource_group.or.name
  authorized_resource_ids = [data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id]
  tags                    = local.resource_tags

  action {
    action_group  = [lower(azurerm_monitor_action_group.technical.id)]
    email_subject = "Azure: K-Data Push Service (eReceipt) partition no flow alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "One or more partitions are not progressing in Push Service (eReceipt). Verify and possibly restart the pods."
  enabled        = true

  query       = <<QUERY
ContainerLogV2
| where _ResourceId endswith "${data.terraform_remote_state.container.outputs.aks_platform.name}"
| where PodNamespace == "receipts" and ContainerName == "or-push-service-to-ereceipt-app-pod"
| summarize Delay = avg((TimeGenerated - todatetime(extract("'enqueued_time'\\: '([\\d\\-\\.\\+\\:T]*)'", 1, tostring(LogMessage)))) / 1m) by Partition = extract("'partition_id': '([0-9]*)'", 1, tostring(LogMessage))
QUERY
  severity    = 0
  frequency   = 30
  time_window = 30
  throttling  = 30
  trigger {
    operator  = "LessThan"
    threshold = 12
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-push_service_sc2_partition_no_flow" {
  name                    = "${local.prefix}-push-service-sc2-partition-no-flow-alert"
  location                = azurerm_resource_group.or.location
  resource_group_name     = azurerm_resource_group.or.name
  authorized_resource_ids = [data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id]
  tags                    = local.resource_tags

  action {
    action_group  = [lower(azurerm_monitor_action_group.technical.id)]
    email_subject = "Azure: K-Data Push Service (Stamp Collecting 2.0) partition no flow alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "One or more partitions are not progressing in Push Service (Stamp Collecting 2.0). Verify and possibly restart the pods."
  enabled        = true

  query       = <<QUERY
ContainerLogV2
| where _ResourceId endswith "${data.terraform_remote_state.container.outputs.aks_platform.name}"
| where PodNamespace == "receipts" and ContainerName == "or-push-service-app-pod"
| summarize Delay = avg((TimeGenerated - todatetime(extract("'enqueued_time'\\: '([\\d\\-\\.\\+\\:T]*)'", 1, tostring(LogMessage)))) / 1m) by Partition = extract("'partition_id': '([0-9]*)'", 1, tostring(LogMessage))
QUERY
  severity    = 0
  frequency   = 30
  time_window = 30
  throttling  = 30
  trigger {
    operator  = "LessThan"
    threshold = 11
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-rer_harmoniser_partition_no_flow" {
  name                    = "${local.prefix}-rer-harmoniser-partition-no-flow-alert"
  location                = azurerm_resource_group.or.location
  resource_group_name     = azurerm_resource_group.or.name
  authorized_resource_ids = [data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id]
  tags                    = local.resource_tags

  action {
    action_group  = [lower(azurerm_monitor_action_group.technical.id)]
    email_subject = "Azure: K-Data RER harmoniser partition no flow alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "One or more partitions are not progressing in RER harmoniser. Verify and possibly restart the pods."
  enabled        = true

  query       = <<QUERY
ContainerLogV2
| where _ResourceId endswith "${data.terraform_remote_state.container.outputs.aks_platform.name}"
| where PodNamespace == "receipts" and ContainerName == "raksa-erp-harmonizer-app-pod"
| summarize Delay = avg((TimeGenerated - todatetime(extract("'enqueued_time'\\: '([\\d\\-\\.\\+\\:T]*)'", 1, tostring(LogMessage)))) / 1m) by Partition = extract("'partition_id': '([0-9]*)'", 1, tostring(LogMessage))
QUERY
  severity    = 0
  frequency   = 1440
  time_window = 1440
  throttling  = 30
  trigger {
    operator  = "LessThan"
    threshold = 12
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-rpo_harmoniser_partition_no_flow" {
  name                    = "${local.prefix}-rpo-harmoniser-partition-no-flow-alert"
  location                = azurerm_resource_group.or.location
  resource_group_name     = azurerm_resource_group.or.name
  authorized_resource_ids = [data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id]
  tags                    = local.resource_tags

  action {
    action_group  = [
      lower(azurerm_monitor_action_group.technical.id),
      lower(azurerm_monitor_action_group.igniointegration.id),
    ]
    email_subject = "Azure: K-Data RPO harmoniser partition no flow alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "One or more partitions are not progressing in RPO harmoniser. Verify and possibly restart the pods."
  enabled        = true

  query       = <<QUERY
ContainerLogV2
| where _ResourceId endswith "${data.terraform_remote_state.container.outputs.aks_platform.name}"
| where PodNamespace == "receipts" and ContainerName == "raksa-pos-harmonizer-app-pod"
| summarize Delay = avg((TimeGenerated - todatetime(extract("'enqueued_time'\\: '([\\d\\-\\.\\+\\:T]*)'", 1, tostring(LogMessage)))) / 1m) by Partition = extract("'partition_id': '([0-9]*)'", 1, tostring(LogMessage))
QUERY
  severity    = 0
  frequency   = 1440
  time_window = 1440
  throttling  = 30
  trigger {
    operator  = "LessThan"
    threshold = 12
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-ecmse_harmoniser_partition_no_flow" {
  name                    = "${local.prefix}-ecmse-harmoniser-partition-no-flow-alert"
  location                = azurerm_resource_group.or.location
  resource_group_name     = azurerm_resource_group.or.name
  authorized_resource_ids = [data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id]
  tags                    = local.resource_tags

  action {
    action_group  = [
      lower(azurerm_monitor_action_group.technical.id),
      lower(azurerm_monitor_action_group.igniointegration.id),
    ]
    email_subject = "Azure: K-Data ECOM Sweden harmoniser partition no flow alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "One or more partitions are not progressing in ECOM Sweden harmoniser. Verify and possibly restart the pods."
  enabled        = false

  query       = <<QUERY
ContainerLogV2
| where _ResourceId endswith "${data.terraform_remote_state.container.outputs.aks_platform.name}"
| where PodNamespace == "receipts" and ContainerName == "ecomse-adapter-app-pod"
| summarize Delay = avg((TimeGenerated - todatetime(extract("'enqueued_time'\\: '([\\d\\-\\.\\+\\:T]*)'", 1, tostring(LogMessage)))) / 1m) by Partition = extract("'partition_id': '([0-9]*)'", 1, tostring(LogMessage))
QUERY
  severity    = 0
  frequency   = 1440
  time_window = 1440
  throttling  = 30
  trigger {
    operator  = "LessThan"
    threshold = 12
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-retry_sender_failure" {
  name                    = "${local.prefix}-retry-sender-failed-to-resend-alert"
  location                = azurerm_resource_group.or.location
  resource_group_name     = azurerm_resource_group.or.name
  authorized_resource_ids = [data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id]
  tags                    = local.resource_tags

  action {
    action_group  = [lower(azurerm_monitor_action_group.technical.id)]
    email_subject = "Azure: K-Data Retry Event Sender failed resending alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "Retry event sender failed to resend some events, manual processing is required"
  enabled        = true

  query       = <<QUERY
ContainerLogV2
| where _ResourceId endswith "${data.terraform_remote_state.container.outputs.aks_platform.name}"
| where PodNamespace == "receipts" and ContainerName startswith "or-retry-event-sender"
| where LogLevel == "ERROR"
QUERY
  severity    = 0
  frequency   = 15
  time_window = 15
  throttling  = 30
  trigger {
    operator  = "GreaterThan"
    threshold = 0
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_int-etl_gtpos_delay" {
  name                    = "${local.prefix}-etl-gtpos-delay-alert"
  location                = azurerm_resource_group.or.location
  resource_group_name     = azurerm_resource_group.or.name
  authorized_resource_ids = [data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id]
  tags                    = local.resource_tags

  action {
    action_group  = [lower(azurerm_monitor_action_group.technical.id)]
    email_subject = "Azure: Messages in ETL seems to be delayed in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "ETL Pods seems to be delayed."
  enabled        = false

  query       = <<QUERY
let containerId = () { ContainerInventory | where Image contains "oandr-etl" | where ContainerHostname contains "or-etl-app"| summarize by ContainerID }; ContainerLog | where ContainerID in (containerId()) | summarize Delay = percentile(((TimeGenerated - todatetime(substring(extract("enqueued_time': '[0-9\\-T\\:]*", 0, LogEntry), 17))) / 1m), 85) by Partition = substring(extract("partition_id': '[0-9]*", 0, LogEntry), 16) | where Delay > 3600 
QUERY
  severity    = 0
  frequency   = 15
  time_window = 15
  throttling  = 30
  trigger {
    operator  = "GreaterThan"
    threshold = 0
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_int-etl_gtpos_stuck" {
  name                    = "${local.prefix}-etl-gtpos-stuck-alert"
  location                = azurerm_resource_group.or.location
  resource_group_name     = azurerm_resource_group.or.name
  authorized_resource_ids = [data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id]
  tags                    = local.resource_tags

  action {
    action_group  = [lower(azurerm_monitor_action_group.technical.id)]
    email_subject = "Azure: ETL Pods seem to be stuck in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "ETL Pods seems to be stuck."
  enabled        = false

  query       = <<QUERY
let containerId = () { ContainerInventory | where Image contains "oandr-etl" | where ContainerHostname contains "or-etl-app"| summarize by ContainerID }; ContainerLog | where ContainerID in (containerId()) | order by TimeGenerated | limit 1 | project TimeGenerated , CurrentTime = now(), Delay = now() - TimeGenerated | where Delay > totimespan("00:15:00.00000") 
QUERY
  severity    = 0
  frequency   = 15
  time_window = 15
  throttling  = 30
  trigger {
    operator  = "GreaterThan"
    threshold = 0
  }
}

resource "azurerm_monitor_metric_alert" "ehns_gtpos-quota_exceeded" {
  name                = "${local.prefix}-gtpos-eventhub-quota-exceeded-errors-alert"
  resource_group_name = azurerm_resource_group.or.name
  scopes              = [data.terraform_remote_state.integrations.outputs.ehns_gtpos.id]
  description         = "Quota exceeded errors were found from gtpos Event Hub in ${upper(local.env.short)}."
  auto_mitigate       = false
  frequency           = "PT5M"
  window_size         = "PT5M"
  severity            = 0

  criteria {
    metric_namespace = "Microsoft.EventHub/namespaces"
    metric_name      = "QuotaExceededErrors"
    aggregation      = "Total"
    operator         = "GreaterThan"
    threshold        = 0
  }

  action {
    action_group_id = lower(azurerm_monitor_action_group.technical.id)
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_metric_alert" "ehns_rer-quota_exceeded" {
  name                = "${local.prefix}-rer-eventhub-quota-exceeded-errors-alert"
  resource_group_name = azurerm_resource_group.or.name
  scopes              = [data.terraform_remote_state.integrations.outputs.ehns_rer.id]
  description         = "Quota exceeded errors were found from rer Event Hub in ${upper(local.env.short)}."
  auto_mitigate       = false
  frequency           = "PT5M"
  window_size         = "PT5M"
  severity            = 0

  criteria {
    metric_namespace = "Microsoft.EventHub/namespaces"
    metric_name      = "QuotaExceededErrors"
    aggregation      = "Total"
    operator         = "GreaterThan"
    threshold        = 0
  }

  action {
    action_group_id = lower(azurerm_monitor_action_group.technical.id)
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_metric_alert" "ehns_rpo-quota_exceeded" {
  name                = "${local.prefix}-rpo-eventhub-quota-exceeded-errors-alert"
  resource_group_name = azurerm_resource_group.or.name
  scopes              = [data.terraform_remote_state.integrations.outputs.ehns_rpo.id]
  description         = "Quota exceeded errors were found from rpo Event Hub in ${upper(local.env.short)}."
  auto_mitigate       = false
  frequency           = "PT5M"
  window_size         = "PT5M"
  severity            = 0

  criteria {
    metric_namespace = "Microsoft.EventHub/namespaces"
    metric_name      = "QuotaExceededErrors"
    aggregation      = "Total"
    operator         = "GreaterThan"
    threshold        = 0
  }

  action {
    action_group_id = lower(azurerm_monitor_action_group.technical.id)
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_metric_alert" "ehns_ctchr-quota_exceeded" {
  name                = "${local.prefix}-ctchr-eventhub-quota-exceeded-errors-alert"
  resource_group_name = azurerm_resource_group.or.name
  scopes              = [data.terraform_remote_state.integrations.outputs.ehns_ctchr.id]
  description         = "Quota exceeded errors were found from ctchr Event Hub in ${upper(local.env.short)}."
  auto_mitigate       = false
  frequency           = "PT5M"
  window_size         = "PT5M"
  severity            = 0

  criteria {
    metric_namespace = "Microsoft.EventHub/namespaces"
    metric_name      = "QuotaExceededErrors"
    aggregation      = "Total"
    operator         = "GreaterThan"
    threshold        = 0
  }

  action {
    action_group_id = lower(azurerm_monitor_action_group.technical.id)
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_metric_alert" "ehns_ecmse-quota_exceeded" {
  name                = "${local.prefix}-ecmse-eventhub-quota-exceeded-errors-alert"
  resource_group_name = azurerm_resource_group.or.name
  scopes              = [data.terraform_remote_state.integrations.outputs.ehns_ecmse.id]
  description         = "Quota exceeded errors were found from ecmse Event Hub in ${upper(local.env.short)}."
  auto_mitigate       = false
  frequency           = "PT5M"
  window_size         = "PT5M"
  severity            = 0

  criteria {
    metric_namespace = "Microsoft.EventHub/namespaces"
    metric_name      = "QuotaExceededErrors"
    aggregation      = "Total"
    operator         = "GreaterThan"
    threshold        = 0
  }

  action {
    action_group_id = lower(azurerm_monitor_action_group.technical.id)
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_metric_alert" "insights_konvehti-exception" {
  name                = "${local.prefix}-appsinght-konvehti-exception-alert"
  resource_group_name = azurerm_resource_group.or.name
  scopes              = [azurerm_application_insights.konvehti.id]
  description         = "Konvehti Function app Exception"
  auto_mitigate       = false
  frequency           = "PT15M"
  window_size         = "PT15M"
  severity            = 0

  criteria {
    metric_namespace = "Microsoft.Insights/Components"
    metric_name      = "exceptions/count"
    aggregation      = "Count"
    operator         = "GreaterThan"
    threshold        = 0

  }

  action {
    action_group_id = lower(azurerm_monitor_action_group.technical.id)
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_metric_alert" "insights_konvehti-failedrreq" {
  name                = "${local.prefix}-appsinght-konvehti-failerreq-alert"
  resource_group_name = azurerm_resource_group.or.name
  scopes              = [azurerm_application_insights.konvehti.id]
  description         = "Konvehti Function app Failed Request"
  auto_mitigate       = false
  frequency           = "PT15M"
  window_size         = "PT15M"
  severity            = 0

  criteria {
    metric_namespace = "Microsoft.Insights/Components"
    metric_name      = "exceptions/count"
    aggregation      = "Count"
    operator         = "GreaterThan"
    threshold        = 0

  }

  action {
    action_group_id = lower(azurerm_monitor_action_group.technical.id)
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_int-vm_agent_unreachable" {
  name                = "${local.prefix}-vm-agent-unreachable-alert"
  location            = azurerm_resource_group.or.location
  resource_group_name = azurerm_resource_group.or.name

  action {
    action_group  = [lower(azurerm_monitor_action_group.technical.id)]
    email_subject = "Azure: Azure VM - Agent Unreachable in ${upper(local.env.short)}"
  }

  data_source_id          = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description             = "Azure VM - Agent Unreachable"
  enabled                 = true
  authorized_resource_ids = [data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id]
  query                   = <<QUERY
Heartbeat | where ResourceGroup !contains "databricks" and ResourceType != "managedClusters" | summarize LastCall = max(TimeGenerated) by Computer | where LastCall < ago(20m) and Computer !contains "robot-server" 
  QUERY
  severity                = 0
  frequency               = 5
  time_window             = 60
  throttling              = 30
  trigger {
    operator  = "GreaterThan"
    threshold = 0
  }
  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-gtpos_confluent_harmonizer_pod_error" {
  name                = "${local.prefix}-gtpos-confluent-harmonizer-log-errors-alert"
  location            = azurerm_resource_group.or.location
  resource_group_name = azurerm_resource_group.or.name
  tags                = local.resource_tags

  action {
    action_group  = [lower(azurerm_monitor_action_group.technical.id)]
    email_subject = "Azure: K-Data GTPOS confluent harmonizer log alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id          = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description             = "Errors were found from gtpos confluent harmonizer logs."
  enabled                 = true
  authorized_resource_ids = [data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id]
  query                   = <<-QUERY
ContainerLogV2
| where _ResourceId endswith "${data.terraform_remote_state.container.outputs.aks_platform.name}"
| where PodNamespace == "receipts" and ContainerName == "gtpos-harmoniser-app-pod"
| where LogMessage contains "ERROR:main" or LogMessage contains "ERROR:kafka_client"
  QUERY
  severity                = 0
  frequency               = 5
  time_window             = 5
  throttling              = 60
  trigger {
    operator  = "GreaterThan"
    threshold = 0
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-gtpos_confluent_harmonizer_pod_delay" {
  name                = "${local.prefix}-gtpos-confluent-harmonizer-log-delay-alert"
  location            = azurerm_resource_group.or.location
  resource_group_name = azurerm_resource_group.or.name
  tags                = local.resource_tags

  action {
    action_group  = [lower(azurerm_monitor_action_group.technical.id)]
    email_subject = "Azure: K-Data GTPOS confluent harmonizer delay was triggered in ${upper(local.env.short)}"
  }

  data_source_id          = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description             = "Messages in gtpos confluent harmonizer seem to be delayed."
  enabled                 = true
  authorized_resource_ids = [data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id]
  query                   = <<-QUERY
ContainerLogV2
| where _ResourceId endswith "${data.terraform_remote_state.container.outputs.aks_platform.name}"
| where PodNamespace == "receipts" and ContainerName == "gtpos-harmoniser-app-pod"
| summarize Delay = avg((TimeGenerated - todatetime(extract("'enqueued_time'\\: '([\\d\\-\\.\\+\\:T]*)'", 1, tostring(LogMessage)))) / 1m) by Partition = extract("'partition_id': '([0-9]*)'", 1, tostring(LogMessage))
QUERY
  severity                = 0
  frequency               = 5
  time_window             = 5
  throttling              = 60
  trigger {
    operator  = "GreaterThan"
    threshold = 30
  }
}


resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-btt_receipt_archive_harmonizer_pod_error" {
  name                = "${local.prefix}-btt-receipt-archive-harmonizer-log-errors-alert"
  location            = azurerm_resource_group.or.location
  resource_group_name = azurerm_resource_group.or.name
  tags                = local.resource_tags

  action {
    action_group  = [lower(azurerm_monitor_action_group.technical.id)]
    email_subject = "Azure: K-Data BTT receipt archive harmonizer log alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id          = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description             = "Errors were found from btt receipt archive harmonizer logs."
  enabled                 = true
  authorized_resource_ids = [data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id]
  query                   = <<-QUERY
  ContainerLogV2
  | where PodNamespace == 'receipts' and (ContainerName == 'btt-receipt-archive-harmoniser-app-pod' or ContainerName == 'btt-receipt-archive-transaction-dls-storage-app-pod')
  | where _ResourceId contains '${lower(local.env.short)}'
  | where LogMessage startswith 'ERROR:'
  QUERY
  severity                = 0
  frequency               = 5
  time_window             = 5
  throttling              = 60
  trigger {
    operator  = "GreaterThan"
    threshold = 0
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-btt_receipt_archive_harmonizer_pod_delay" {
  name                = "${local.prefix}-btt-receipt-archive-harmonizer-log-delay-alert"
  location            = azurerm_resource_group.or.location
  resource_group_name = azurerm_resource_group.or.name
  tags                = local.resource_tags

  action {
    action_group  = [lower(azurerm_monitor_action_group.technical.id)]
    email_subject = "Azure: K-Data BTT receipt archive harmonizer delay was triggered in ${upper(local.env.short)}"
  }

  data_source_id          = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description             = "Messages in btt receipt archive harmonizer seem to be delayed."
  enabled                 = true
  authorized_resource_ids = [data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id]
  query                   = <<-QUERY
  ContainerLogV2
  | where PodNamespace == 'receipts' and ContainerName == 'btt-receipt-archive-harmoniser-app-pod'
  | where LogMessage startswith 'INFO:harmoniser:TransactionId: '
  | extend Partition = extract('\'partition_id\': \'([0-9]*)\'', 1 , tostring(LogMessage))
  | extend EnqueuedTime = extract('\'enqueued_time\': \'([0-9T\\-\\:\\.\\+]*)\'', 1 , tostring(LogMessage))
  | summarize Delay = avg((TimeGenerated - todatetime(EnqueuedTime)) / 1m) by bin(TimeGenerated, 5m), ContainerName, Partition
  QUERY
  severity                = 0
  frequency               = 5
  time_window             = 5
  throttling              = 60
  trigger {
    operator  = "GreaterThan"
    threshold = 30
  }
}
