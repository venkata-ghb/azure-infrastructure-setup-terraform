resource "azurerm_storage_management_policy" "rawdlq" {
  storage_account_id = azurerm_storage_account.rawdlq.id
  rule {
    name    = "DeleteAfterSpecifiedPeriod"
    enabled = true
    filters {
      blob_types = ["blockBlob"]
    }
    actions {
      base_blob {
        delete_after_days_since_modification_greater_than = 1095
      }
    }
  }
}

resource "azurerm_storage_management_policy" "push" {
  storage_account_id = azurerm_storage_account.push.id
  rule {
    name    = "DeleteAfterSpecifiedPeriod"
    enabled = true
    filters {
      blob_types = ["blockBlob"]
    }
    actions {
      base_blob {
        delete_after_days_since_modification_greater_than = 1095
      }
    }
  }
}

resource "azurerm_storage_management_policy" "audit" {
  storage_account_id = azurerm_storage_account.audit.id

  rule {
    name    = "AuditLogBlockBlobTireRotationPolicy"
    enabled = true
    filters {
      blob_types = ["blockBlob"]
    }
    actions {
      base_blob {
        tier_to_cool_after_days_since_modification_greater_than    = 60
        tier_to_archive_after_days_since_modification_greater_than = 180
        delete_after_days_since_modification_greater_than          = var.delete_blobs_after_days
      }
    }
  }

  rule {
    name    = "AuditLogAppendBlobDeletePolicy"
    enabled = true
    filters {
      blob_types = ["appendBlob"]
    }
    actions {
      base_blob {
        delete_after_days_since_modification_greater_than = var.delete_blobs_after_days
      }
    }
  }
}

resource "azurerm_storage_management_policy" "harmonizers" {
  storage_account_id = azurerm_storage_account.harmonizers.id
  rule {
    name    = "DeleteAfterSpecifiedPeriod"
    enabled = true
    filters {
      blob_types = ["blockBlob"]
    }
    actions {
      base_blob {
        delete_after_days_since_modification_greater_than = 1095
      }
    }
  }
}
