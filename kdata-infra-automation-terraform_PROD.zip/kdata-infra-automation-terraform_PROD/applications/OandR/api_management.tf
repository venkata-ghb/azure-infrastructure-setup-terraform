
######################################################################################################
# CENTRALISED APIM FOR KONVEHTI #
#######################################################################################################

###### CENTRALISED APIM ######
data "azurerm_api_management" "apimanagement" {
  provider            = azurerm.apim
  name                = "K-apim-prod"
  resource_group_name = "KESKO_WE_RG_APIM_PROD001"
}

############# API ##############

resource "azurerm_api_management_api" "konvehti" {
  provider            = azurerm.apim
  name                = "kdata-konvehti-api"
  resource_group_name = data.azurerm_api_management.apimanagement.resource_group_name
  api_management_name = data.azurerm_api_management.apimanagement.name
  revision            = "1"
  display_name        = "K-Data Konvehti API"
  path                = "kdata/konvehti"
  protocols           = ["https"]

  import {
    content_format = "swagger-json"
    content_value  = file("${path.module}/swagger.konvehti-api.json")
  }
}

resource "azurerm_api_management_named_value" "konvehti" {
  provider            = azurerm.apim
  resource_group_name = azurerm_api_management_api.konvehti.resource_group_name
  api_management_name = azurerm_api_management_api.konvehti.api_management_name
  name                = "${azurerm_api_management_api.konvehti.name}-secret"
  display_name        = "${azurerm_api_management_api.konvehti.name}-secret"
  value               = data.azurerm_key_vault_secret.or-konvehti_functions_key.value
  secret              = true
}

resource "azurerm_api_management_api_policy" "konvehti" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.konvehti.name
  resource_group_name = azurerm_api_management_api.konvehti.resource_group_name
  api_management_name = azurerm_api_management_api.konvehti.api_management_name

  xml_content = <<XML
<policies>
    <inbound>
        <base />
        <validate-jwt header-name="Authorization" failed-validation-httpcode="401" failed-validation-error-message="Unauthorized. Access token is missing or invalid.">
            <openid-config url="https://login.microsoftonline.com/ae6e7baa-e1bf-4ef0-92a1-4eb28ec805c0/.well-known/openid-configuration" />
            <issuers>
                <issuer>ae6e7baa-e1bf-4ef0-92a1-4eb28ec805c0</issuer>
            </issuers>
            <required-claims>
                <claim name="appid">
                    <value>${data.terraform_remote_state.ad.outputs.sp_or_konvehti_fe.application_id}</value>
                </claim>
                <claim name="iss">
                    <value>https://sts.windows.net/ae6e7baa-e1bf-4ef0-92a1-4eb28ec805c0/</value>
                </claim>
            </required-claims>
        </validate-jwt>
        <cors>
            <allowed-origins>
                <origin>http://localhost:4200</origin>
                <origin>https://${azurerm_cdn_frontdoor_endpoint.konvehtife-konvehtife.host_name}</origin>
            </allowed-origins>
            <allowed-methods>
                <method>*</method>
            </allowed-methods>
            <allowed-headers>
                <header>*</header>
            </allowed-headers>
            <expose-headers>
                <header>*</header>
            </expose-headers>
        </cors>
        <set-header name="x-functions-key" exists-action="override">
            <value>{{${azurerm_api_management_named_value.konvehti.name}}}</value>
        </set-header>
        <set-backend-service base-url="https://${azurerm_windows_function_app.konvehtibe.default_hostname}/api" />
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>
XML
}

resource "azurerm_api_management_authorization_server" "konvehti" {
  provider                     = azurerm.apim
  name                         = "${local.prefix}-auth-server"
  resource_group_name          = data.azurerm_api_management.apimanagement.resource_group_name
  api_management_name          = data.azurerm_api_management.apimanagement.name
  display_name                 = "Kesko AD"
  authorization_endpoint       = "https://login.microsoftonline.com/ae6e7baa-e1bf-4ef0-92a1-4eb28ec805c0/oauth2/v2.0/authorize"
  token_endpoint               = "https://login.microsoftonline.com/ae6e7baa-e1bf-4ef0-92a1-4eb28ec805c0/oauth2/v2.0/token"
  client_id                    = azurerm_api_management_api.konvehti.id
  client_secret                = data.terraform_remote_state.ad.outputs.sp_or_konvehti_fe_password
  client_registration_endpoint = "http://localhost"
  bearer_token_sending_methods = [
    "authorizationHeader"
  ]
  support_state = false
  grant_types = [
    "authorizationCode",
    "implicit"
  ]
  client_authentication_method = ["Body"]
  authorization_methods        = ["GET"]

  lifecycle {
    ignore_changes = all
  }
}

resource "azurerm_api_management_product" "konvehti" {
  provider              = azurerm.apim
  product_id            = "${azurerm_api_management_api.konvehti.name}-product"
  resource_group_name   = azurerm_api_management_api.konvehti.resource_group_name
  api_management_name   = data.azurerm_api_management.apimanagement.name
  display_name          = azurerm_api_management_api.konvehti.display_name
  subscription_required = false
  approval_required     = false
  published             = true
}

resource "azurerm_api_management_product_api" "konvehti" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.konvehti.name
  product_id          = azurerm_api_management_product.konvehti.product_id
  resource_group_name = azurerm_api_management_api.konvehti.resource_group_name
  api_management_name = data.azurerm_api_management.apimanagement.name
}

resource "azurerm_api_management_product_group" "konvehti" {
  provider            = azurerm.apim
  product_id          = azurerm_api_management_product.konvehti.product_id
  group_name          = "637f1ed90004a19aca6e9411"
  resource_group_name = azurerm_api_management_api.konvehti.resource_group_name
  api_management_name = data.azurerm_api_management.apimanagement.name
}
