resource "azurerm_cdn_frontdoor_profile" "konvehtife" {
  name                = "${local.prefix}-${local.location.short}-or-konvehti-afd"
  resource_group_name = azurerm_resource_group.or.name
  sku_name            = "Standard_AzureFrontDoor"
  tags                = local.resource_tags
}

resource "azurerm_cdn_frontdoor_endpoint" "konvehtife-konvehtife" {
  name                     = azurerm_storage_account.konvehtife.name
  cdn_frontdoor_profile_id = replace(azurerm_cdn_frontdoor_profile.konvehtife.id, "resourcegroup", "resourceGroup")
  tags                     = local.resource_tags
}

resource "azurerm_cdn_frontdoor_origin_group" "konvehtife-konvehtife" {
  name                     = "konvehtife"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.konvehtife.id
  session_affinity_enabled = false

  restore_traffic_time_to_healed_or_new_endpoint_in_minutes = 0

  load_balancing {
    additional_latency_in_milliseconds = 50
    sample_size                        = 4
    successful_samples_required        = 3
  }
}

resource "azurerm_cdn_frontdoor_origin" "konvehtife-konvehtife-konvehtife_blob" {
  name                          = "${azurerm_storage_account.konvehtife.name}-blob"
  cdn_frontdoor_origin_group_id = azurerm_cdn_frontdoor_origin_group.konvehtife-konvehtife.id
  enabled                       = true

  certificate_name_check_enabled = false

  host_name          = azurerm_storage_account.konvehtife.primary_blob_host
  http_port          = 80
  https_port         = 443
  origin_host_header = azurerm_storage_account.konvehtife.primary_blob_host
  priority           = 1
  weight             = 1
}

resource "azurerm_cdn_frontdoor_route" "konvehtife-default" {
  name                          = "default"
  cdn_frontdoor_endpoint_id     = azurerm_cdn_frontdoor_endpoint.konvehtife-konvehtife.id
  cdn_frontdoor_origin_group_id = azurerm_cdn_frontdoor_origin_group.konvehtife-konvehtife.id
  cdn_frontdoor_origin_ids      = [azurerm_cdn_frontdoor_origin.konvehtife-konvehtife-konvehtife_blob.id]
  cdn_frontdoor_rule_set_ids    = [azurerm_cdn_frontdoor_rule_set.konvehtife-default.id]
  enabled                       = true

  forwarding_protocol       = "MatchRequest"
  https_redirect_enabled    = true
  patterns_to_match         = ["/*"]
  cdn_frontdoor_origin_path = "/release"
  supported_protocols       = ["Http", "Https"]
}

resource "azurerm_cdn_frontdoor_rule_set" "konvehtife-default" {
  name                     = "default"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.konvehtife.id
}

resource "azurerm_cdn_frontdoor_rule" "konvehtife-default-index" {
  depends_on = [azurerm_cdn_frontdoor_origin_group.konvehtife-konvehtife, azurerm_cdn_frontdoor_origin.konvehtife-konvehtife-konvehtife_blob]

  name                      = "index"
  cdn_frontdoor_rule_set_id = azurerm_cdn_frontdoor_rule_set.konvehtife-default.id
  order                     = 1
  behavior_on_match         = "Continue"

  actions {
        url_rewrite_action {
            destination             = "/index.html"
            preserve_unmatched_path = false
            source_pattern          = "/"
        }
      }

    conditions {
        url_path_condition {
            match_values     = ["/"]
            negate_condition = false
            operator         = "Equal"
            transforms       = []
        }
      }
  }
