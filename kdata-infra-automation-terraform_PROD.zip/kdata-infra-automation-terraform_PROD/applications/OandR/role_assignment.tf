resource "azurerm_role_assignment" "rg_or-contributor-group_admins_platform" {
  principal_id         = data.terraform_remote_state.ad.outputs.group_admins_platform.id
  role_definition_name = "Contributor"
  scope                = azurerm_resource_group.or.id
}

resource "azurerm_role_assignment" "rg_or-contributor-sp_platform_devops" {
  principal_id         = data.terraform_remote_state.ad.outputs.sp_platform_devops.id
  role_definition_name = "Contributor"
  scope                = azurerm_resource_group.or.id
}

resource "azurerm_role_assignment" "rg_or-reader-group_devops_platform" {
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
  role_definition_name = "Reader"
  scope                = azurerm_resource_group.or.id
}

resource "azurerm_role_assignment" "rg_or-reader-group_devops_or" {
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_or.id
  role_definition_name = "Reader"
  scope                = azurerm_resource_group.or.id
}

resource "azurerm_role_assignment" "rg_or-website_contributor-group_devops_platform" {
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
  role_definition_name = "Website Contributor"
  scope                = azurerm_resource_group.or.id
}

# Storage account
resource "azurerm_role_assignment" "sa_bookkeeping-blob_contributor-sp_platform_devops" {
  scope                = azurerm_storage_account.bookkeeping.id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.sp_platform_devops.id
}

resource "azurerm_role_assignment" "sa_bookkeeping-blob_reader-sp_or_bookkeeping" {
  scope                = azurerm_storage_account.bookkeeping.id
  role_definition_name = "Storage Blob Data Reader"
  principal_id         = data.terraform_remote_state.ad.outputs.sp_or_bookkeeping.id
}

resource "azurerm_role_assignment" "sa_bookkeeping-queue_contributor-sp_or_bookkeeping" {
  scope                = azurerm_storage_account.bookkeeping.id
  role_definition_name = "Storage Queue Data Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.sp_or_bookkeeping.id
}

resource "azurerm_role_assignment" "sa_bookkeeping-table_contributor-sp_or_bookkeeping" {
  scope                = azurerm_storage_account.bookkeeping.id
  role_definition_name = "Storage Table Data Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.sp_or_bookkeeping.id
}

resource "azurerm_role_assignment" "sa_rawdlq_gtpos-blob_contributor-sp_or_datapower" {
  scope                = "${azurerm_storage_account.rawdlq.id}/blobServices/default/containers/${azurerm_storage_container.rawdlq-gtpos.name}"
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.sp_or_datapower.id
}

resource "azurerm_role_assignment" "sa_audit-blob_contributor-msi_sqlserver_public_app" {
  scope                = azurerm_storage_account.audit.id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azurerm_mssql_server.public_app.identity.0.principal_id
}

resource "azurerm_role_assignment" "sa_nordea-blob_owner-msi_nordea_funcapp" {
  role_definition_name = "Storage Blob Data Owner"
  scope                = azurerm_storage_account.nordea.id
  principal_id         = azurerm_linux_function_app.nordea.identity[0].principal_id
}

resource "azurerm_role_assignment" "sa_b2bdr-table_contributor-msi_infra" {
  scope                = azurerm_storage_account.b2bdr.id
  role_definition_name = "Storage Table Data Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.msi_infra.id
}

resource "azurerm_role_assignment" "sa_harmonizers-blob_contributor-msi_or" {
  scope                = azurerm_storage_account.harmonizers.id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.msi_or.id
}

resource "azurerm_role_assignment" "sa_eph-blob_contributor-msi_or" {
  scope                = azurerm_storage_account.eph.id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.msi_or.id
}
