resource "azurerm_monitor_diagnostic_setting" "kv_or-audit" {
  name               = "${azurerm_key_vault.or.name}-audit"
  target_resource_id = azurerm_key_vault.or.id
  storage_account_id = azurerm_storage_account.audit.id

  enabled_log {
    category = "AuditEvent"

    retention_policy {
      days    = 90
      enabled = false
    }
  }

  metric {
    category = "AllMetrics"
    enabled  = false

    retention_policy {
      days    = 0
      enabled = false
    }
  }
}


resource "azurerm_monitor_diagnostic_setting" "mssqldb_public_app_or-monitoring" {
  name                       = "Monitoring"
  target_resource_id         = azurerm_mssql_database.public_app-or.id
  log_analytics_workspace_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id

  metric {
    category = "Basic"
    enabled  = true

    retention_policy {
      days    = 0
      enabled = false
    }
  }

  metric {
    category = "InstanceAndAppAdvanced"
    enabled  = false

    retention_policy {
      days    = 0
      enabled = false
    }
  }

  metric {
    category = "WorkloadManagement"
    enabled  = false

    retention_policy {
      days    = 0
      enabled = false
    }
  }
}

resource "azurerm_monitor_diagnostic_setting" "mssqlsb_public_app_or_konvehti-monitoring" {
  name                       = "Monitoring"
  target_resource_id         = azurerm_mssql_database.public_app-or_konvehti.id
  log_analytics_workspace_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id

  metric {
    category = "Basic"

    retention_policy {
      days    = 0
      enabled = false
    }
  }

  metric {
    category = "InstanceAndAppAdvanced"
    enabled  = false

    retention_policy {
      days    = 0
      enabled = false
    }
  }

  metric {
    category = "WorkloadManagement"
    enabled  = false

    retention_policy {
      days    = 0
      enabled = false
    }
  }
}
