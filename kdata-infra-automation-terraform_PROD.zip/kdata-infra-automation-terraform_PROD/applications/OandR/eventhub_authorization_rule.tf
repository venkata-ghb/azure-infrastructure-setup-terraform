resource "azurerm_eventhub_authorization_rule" "gtpos-natural-k8s_read" {
  name                = "gtpos-natural-k8s-read"
  eventhub_name       = "gtpos-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_gtpos.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_gtpos.resource_group_name
  listen              = true
  send                = false
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "gtpos-natural-k8s_write" {
  name                = "gtpos-natural-k8s-write"
  eventhub_name       = "gtpos-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_gtpos.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_gtpos.resource_group_name
  listen              = false
  send                = true
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "gtpos-natural-datapower" {
  name                = "DataPower"
  eventhub_name       = "gtpos-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_gtpos.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_gtpos.resource_group_name
  listen              = false
  send                = true
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "gtpos-harmonised-k8s_read" {
  name                = "gtpos-harmonised-k8s-read"
  eventhub_name       = "gtpos-harmonised"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_gtpos.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_gtpos.resource_group_name
  listen              = true
  send                = false
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "gtpos-harmonised-k8s_write" {
  name                = "gtpos-harmonised-k8s-write"
  eventhub_name       = "gtpos-harmonised"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_gtpos.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_gtpos.resource_group_name
  listen              = false
  send                = true
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "ctchr-natural-k8s_read" {
  name                = "ctchr-natural-k8s-read"
  eventhub_name       = "ctchr-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_ctchr.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_ctchr.resource_group_name
  listen              = true
  send                = false
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "ctchr-natural-k8s_write" {
  name                = "ctchr-natural-k8s-write"
  eventhub_name       = "ctchr-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_ctchr.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_ctchr.resource_group_name
  listen              = false
  send                = true
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "ctchr-natural-datapower" {
  name                = "DataPower"
  eventhub_name       = "ctchr-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_ctchr.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_ctchr.resource_group_name
  listen              = false
  send                = true
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "ctchr-harmonised-k8s_read" {
  name                = "ctchr-harmonised-k8s-read"
  eventhub_name       = "ctchr-harmonised"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_ctchr.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_ctchr.resource_group_name
  listen              = true
  send                = false
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "ctchr-harmonised-k8s_write" {
  name                = "ctchr-harmonised-k8s-write"
  eventhub_name       = "ctchr-harmonised"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_ctchr.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_ctchr.resource_group_name
  listen              = false
  send                = true
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "rer-natural-k8s_read" {
  name                = "rer-natural-k8s-read"
  eventhub_name       = "rer-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_rer.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_rer.resource_group_name
  listen              = true
  send                = false
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "rer-natural-k8s_write" {
  name                = "rer-natural-k8s-write"
  eventhub_name       = "rer-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_rer.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_rer.resource_group_name
  listen              = false
  send                = true
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "rer-natural-datapower" {
  name                = "DataPower"
  eventhub_name       = "rer-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_rer.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_rer.resource_group_name
  listen              = false
  send                = true
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "rer-harmonised-k8s_read" {
  name                = "rer-harmonised-k8s-read"
  eventhub_name       = "rer-harmonised"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_rer.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_rer.resource_group_name
  listen              = true
  send                = false
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "rer-harmonised-k8s_write" {
  name                = "rer-harmonised-k8s-write"
  eventhub_name       = "rer-harmonised"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_rer.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_rer.resource_group_name
  listen              = false
  send                = true
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "rpo-natural-k8s_read" {
  name                = "rpo-natural-k8s-read"
  eventhub_name       = "rpo-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_rpo.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_rpo.resource_group_name
  listen              = true
  send                = false
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "rpo-natural-k8s_write" {
  name                = "rpo-natural-k8s-write"
  eventhub_name       = "rpo-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_rpo.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_rpo.resource_group_name
  listen              = false
  send                = true
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "rpo-natural-datapower" {
  name                = "DataPower"
  eventhub_name       = "rpo-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_rpo.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_rpo.resource_group_name
  listen              = false
  send                = true
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "rpo-harmonised-k8s_read" {
  name                = "rpo-harmonised-k8s-read"
  eventhub_name       = "rpo-harmonised"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_rpo.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_rpo.resource_group_name
  listen              = true
  send                = false
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "rpo-harmonised-k8s_write" {
  name                = "rpo-harmonised-k8s-write"
  eventhub_name       = "rpo-harmonised"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_rpo.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_rpo.resource_group_name
  listen              = false
  send                = true
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "ecmse-natural-k8s_read" {
  name                = "ecmse-natural-k8s-read"
  eventhub_name       = "ecmse-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_ecmse.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_ecmse.resource_group_name
  listen              = true
  send                = false
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "ecmse-natural-k8s_write" {
  name                = "ecmse-natural-k8s-write"
  eventhub_name       = "ecmse-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_ecmse.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_ecmse.resource_group_name
  listen              = false
  send                = true
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "ecmse-natural-datapower" {
  name                = "DataPower"
  eventhub_name       = "ecmse-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_ecmse.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_ecmse.resource_group_name
  listen              = false
  send                = true
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "ecmse-harmonised-k8s_read" {
  name                = "ecmse-harmonised-k8s-read"
  eventhub_name       = "ecmse-harmonised"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_ecmse.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_ecmse.resource_group_name
  listen              = true
  send                = false
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "ecmse-harmonised-k8s_write" {
  name                = "ecmse-harmonised-k8s-write"
  eventhub_name       = "ecmse-harmonised"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_ecmse.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_ecmse.resource_group_name
  listen              = false
  send                = true
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "btt_receipt_archive-transaction_harmonised-or_k8s_write" {
  name                = "or-k8s-write"
  eventhub_name       = "transaction-harmonised"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_btt_receipt_archive.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_btt_receipt_archive.resource_group_name

  listen = false
  send   = true
  manage = false
}

resource "azurerm_eventhub_authorization_rule" "btt_receipt_archive-transaction_harmonised-or_k8s_read" {
  name                = "or-k8s-read"
  eventhub_name       = "transaction-harmonised"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_btt_receipt_archive.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_btt_receipt_archive.resource_group_name

  listen = true
  send   = false
  manage = false
}

resource "azurerm_eventhub_authorization_rule" "marketpay-standalone_transaction_harmonised-or_k8s_write" {
  name                = "or-k8s-write"
  eventhub_name       = "standalone-transaction-harmonised"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_marketpay.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_marketpay.resource_group_name

  listen = false
  send   = true
  manage = false
}

resource "azurerm_eventhub_authorization_rule" "marketpay-standalone_transaction_harmonised-or_k8s_read" {
  name                = "or-k8s-read"
  eventhub_name       = "standalone-transaction-harmonised"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_marketpay.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_marketpay.resource_group_name

  listen = false
  send   = true
  manage = false
}
