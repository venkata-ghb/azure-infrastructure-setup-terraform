resource "azurerm_network_interface" "robotserver" {
  name                = "${local.prefix}-robot-server-nic"
  location            = azurerm_resource_group.robot.location
  resource_group_name = azurerm_resource_group.robot.name
  ip_configuration {
    name                          = "ipconfig1"
    subnet_id                     = data.terraform_remote_state.vnets.outputs.subnet_robot.id
    private_ip_address_allocation = "Dynamic"
  }

  tags = local.resource_tags
}

resource "random_password" "vm_robotserver-admin_password" {
  length  = 21
  special = true
  #override_special = "#_@"
}

resource "azurerm_virtual_machine" "robotserver" {
  name                             = "${local.prefix}-robot-server"
  location                         = azurerm_resource_group.robot.location
  resource_group_name              = azurerm_resource_group.robot.name
  network_interface_ids            = [azurerm_network_interface.robotserver.id]
  vm_size                          = "Standard_DS1_v2"
  delete_os_disk_on_termination    = true
  delete_data_disks_on_termination = true
  identity {
    type = "SystemAssigned"
  }
  os_profile {
    computer_name  = "${local.prefix}-robot-server"
    admin_username = "robot-admin"
    admin_password = random_password.vm_robotserver-admin_password.result
  }

  os_profile_linux_config {
    disable_password_authentication = false
  }

  storage_image_reference {
    publisher = "OpenLogic"
    offer     = "CentOS"
    sku       = "7.3"
    version   = "latest"
  }

  storage_os_disk {
    name              = "${local.prefix}-robot-server-disk"
    caching           = "ReadWrite"
    create_option     = "FromImage"
    managed_disk_type = "Standard_LRS"
  }

  tags = local.resource_tags
} 
