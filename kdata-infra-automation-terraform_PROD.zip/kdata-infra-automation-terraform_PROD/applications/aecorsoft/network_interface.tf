resource "azurerm_network_interface" "aecorsoft_nic_01" {
  name                = "${var.vm_name}_nic_01"
  location            = azurerm_resource_group.aecorsoft.location
  resource_group_name = azurerm_resource_group.aecorsoft.name
  tags                = local.resource_tags

  ip_configuration {
    name                          = "internal"
    subnet_id                     = data.terraform_remote_state.vnets.outputs.subnet_connectors_001.id
    private_ip_address_allocation = "Dynamic"
  }
}
