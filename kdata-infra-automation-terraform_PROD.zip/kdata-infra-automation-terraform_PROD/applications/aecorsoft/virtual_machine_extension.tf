# automatic_upgrade_enabled is not available in current azurerm provider ( viz 2.80.0)
# when azurerm provider is upgraded to higher version then add that option
# Currently only minor versions will get updated. Frequency of major version upgrade is low.


# TIP1: Details about extension can be found using portal. The cli gives wrong type_handler_version
# Click on extension + application -> Add -> Search the extension -> Next -> Review + create -> Download a template for automation 
# use values from the template
resource "azurerm_virtual_machine_extension" "aecorsoft-network_watcher" {
  name                       = "AzureNetworkWatcherAgentWindows"
  virtual_machine_id         = azurerm_windows_virtual_machine.aecorsoft.id
  publisher                  = "Microsoft.Azure.NetworkWatcher"
  type                       = "NetworkWatcherAgentWindows"
  type_handler_version       = "1.4"
  auto_upgrade_minor_version = true
  tags                       = local.resource_tags
}


resource "azurerm_virtual_machine_extension" "aecorsoft-iaas_antimalware" {
  name                       = "MicrosoftAntiMalwareExtension"
  virtual_machine_id         = azurerm_windows_virtual_machine.aecorsoft.id
  publisher                  = "Microsoft.Azure.Security"
  type                       = "IaaSAntimalware"
  type_handler_version       = "1.3"
  auto_upgrade_minor_version = true
  tags                       = local.resource_tags
  settings                   = <<SETTINGS
    {
    	"AntimalwareEnabled": "true",
	    "RealtimeProtectionEnabled": "true",
	    "ScheduledScanSettings": {
		      "isEnabled": "true",
		      "day": "7",
		      "time": "180",
		      "scanType": "Quick"
	    }
    }
  SETTINGS
}

resource "azurerm_virtual_machine_extension" "aecorsoft-dependency_agent" {
  name                       = "MicrosoftDependencyAgentExtension"
  virtual_machine_id         = azurerm_windows_virtual_machine.aecorsoft.id
  publisher                  = "Microsoft.Azure.Monitoring.DependencyAgent"
  type                       = "DependencyAgentWindows"
  type_handler_version       = "9.10"
  auto_upgrade_minor_version = true
  automatic_upgrade_enabled  = true
  tags                       = local.resource_tags
}

resource "azurerm_virtual_machine_extension" "aecorsoft-monitoring_agent" {
  name                       = "MicrosoftMonitoringAgent"
  virtual_machine_id         = azurerm_windows_virtual_machine.aecorsoft.id
  publisher                  = "Microsoft.EnterpriseCloud.Monitoring"
  type                       = "MicrosoftMonitoringAgent"
  type_handler_version       = "1.0"
  auto_upgrade_minor_version = true
  tags                       = local.resource_tags
  settings                   = <<SETTINGS
    {
    	"workspaceId": "${data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.workspace_id}"
    }
  SETTINGS
  protected_settings         = <<PROTECTED_SETTINGS
    {
      "workspacekey" : "${data.terraform_remote_state.monitoring.outputs.loganalytics_workspace_key}"
    }
  PROTECTED_SETTINGS
}