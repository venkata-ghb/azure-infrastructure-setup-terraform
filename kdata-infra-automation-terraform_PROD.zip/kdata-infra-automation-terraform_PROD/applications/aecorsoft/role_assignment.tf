resource "azurerm_role_assignment" "rg_aecorsoft-contributor-group_admins_platform" {
  principal_id         = data.terraform_remote_state.ad.outputs.group_admins_platform.id
  role_definition_name = "Contributor"
  scope                = azurerm_resource_group.aecorsoft.id
}

resource "azurerm_role_assignment" "rg_aecorsoft-reader-group_devops_platform" {
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
  role_definition_name = "Reader"
  scope                = azurerm_resource_group.aecorsoft.id
}

resource "azurerm_role_assignment" "rg_aecorsoft-reader-group_devops_edw_temp" {
  principal_id         = "7f6774be-3403-406e-bbae-6a8a7e02b9ce" #Temporary access for edw devops team
  role_definition_name = "Reader"
  scope                = azurerm_resource_group.aecorsoft.id
}
