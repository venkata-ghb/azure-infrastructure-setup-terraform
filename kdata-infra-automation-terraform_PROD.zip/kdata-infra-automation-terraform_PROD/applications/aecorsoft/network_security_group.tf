resource "azurerm_network_security_group" "aecorsoft_nic_nsg" {
  name                = "aecorsoft_nic_nsg"
  location            = azurerm_resource_group.aecorsoft.location
  resource_group_name = azurerm_resource_group.aecorsoft.name
  tags                = local.resource_tags

  security_rule {
    name                       = "AllowAnySMTPOutbound"
    description                = ""
    priority                   = 2011
    direction                  = "Outbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    destination_address_prefix = "*"
    destination_port_range     = "25"
    source_address_prefix      = "*"
    source_port_range          = "*"
  }

  security_rule {
    name                       = "AllowAecorSoftInbuiltUserInbound"
    description                = "Allow AecorSoft client using AecorSoft authentication"
    priority                   = 1001
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_address_prefix      = ""
    source_address_prefixes    = var.aecorsoft_client_inbuilt_user_allowed_address_list
    source_port_range          = "*"
    destination_port_range     = "8522"
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "AllowAecorSoftADInbound"
    description                = "Allow AecorSoft client using SSO"
    priority                   = 1002
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_address_prefix      = ""
    source_address_prefixes    = var.aecorsoft_client_sso_allowed_address_list
    source_port_range          = "*"
    destination_address_prefix = "*"
    destination_port_range     = "8523"
  }

  security_rule {
    name                         = "AllowAecorSoftSapuskaOutbound"
    description                  = "Allow AecorSoft communication to Sapuska SAP TDL"
    priority                     = 1003
    direction                    = "Outbound"
    access                       = "Allow"
    protocol                     = "Tcp"
    source_address_prefix        = "*"
    source_port_range            = "*"
    destination_address_prefixes = var.sapuska_address_list
    destination_port_range       = ""
    destination_port_ranges      = var.sapuska_port_ranges
  }

  security_rule {
    name                       = "AllowAecorSoftToAzureStorage"
    description                = "Allow AecorSoft to communicate to ADLS"
    priority                   = 2001
    direction                  = "Outbound"
    access                     = "Allow"
    protocol                   = "*"
    source_address_prefix      = "VirtualNetwork"
    source_port_range          = "*"
    destination_address_prefix = "Storage"
    destination_port_range     = "445"
  }

  security_rule {
    name                       = "AllowRDPInbound"
    description                = "Allow RDP connections for AecorSoft machine"
    priority                   = 400
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_address_prefix      = ""
    source_address_prefixes    = var.rdp_allowed_address_list
    source_port_range          = "*"
    destination_address_prefix = "*"
    destination_port_range     = "3389"
  }

  security_rule {
    name                       = "AllowHTTPSOutbound"
    description                = "Allow https traffic. Used by databricks connection"
    priority                   = 300
    direction                  = "Outbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_address_prefix      = "*"
    source_port_range          = "*"
    destination_address_prefix = "*"
    destination_port_range     = "443"
  }
}

resource "azurerm_network_interface_security_group_association" "aecorsoft_nsg_association" {
  network_interface_id      = azurerm_network_interface.aecorsoft_nic_01.id
  network_security_group_id = azurerm_network_security_group.aecorsoft_nic_nsg.id
}
