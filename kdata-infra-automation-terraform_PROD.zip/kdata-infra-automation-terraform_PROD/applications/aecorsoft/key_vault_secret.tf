resource "azurerm_key_vault_secret" "main-aecorsoft_admin_password" {
  key_vault_id = data.terraform_remote_state.integrations.outputs.kv_main.id
  name         = "kdata-aecorsoft-admin-password"
  value        = random_password.vm_aecorsoft_admin_password.result
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "sp_aecorsoft_sink_secret" {
  name         = "kdata-prod-aecorsoft-sink-sp-latest"
  value        = data.terraform_remote_state.ad.outputs.sp_aecorsoft_sink_password
  key_vault_id = data.terraform_remote_state.integrations.outputs.kv_main.id
  content_type = "${data.terraform_remote_state.ad.outputs.sp_aecorsoft_sink.display_name} SP's Password by Terraform"
}

resource "azurerm_key_vault_secret" "sp_apim_authentication_secret" {
  name         = "kdata-prod-apim-authentication-sp-latest"
  value        = data.terraform_remote_state.ad.outputs.sp_apim_authentication_password
  key_vault_id = data.terraform_remote_state.integrations.outputs.kv_main.id
  content_type = "${data.terraform_remote_state.ad.outputs.sp_apim_authentication.display_name} SP's Password by Terraform"
}