resource "azurerm_recovery_services_vault" "aecorsoft" {
  name                = "K-DATA-${upper(local.env.short)}-${upper(local.location.short)}-aecorsoft-recovery-vault"
  resource_group_name = azurerm_resource_group.aecorsoft.name
  location            = azurerm_resource_group.aecorsoft.location
  tags                = local.resource_tags
  sku                 = "Standard"
  soft_delete_enabled = true
}

resource "azurerm_backup_policy_vm" "aecorsoft" {
  name                = "K-DATA_${upper(local.env.short)}_${upper(local.location.short)}_aecorsoft_backup_policy"
  resource_group_name = azurerm_resource_group.aecorsoft.name
  recovery_vault_name = azurerm_recovery_services_vault.aecorsoft.name
  timezone            = "FLE Standard Time"

  backup {
    frequency = "Daily"
    time      = "02:00"
  }
  retention_daily {
    count = 30
  }
}

resource "azurerm_backup_protected_vm" "aecorsoft" {
  resource_group_name = azurerm_resource_group.aecorsoft.name
  recovery_vault_name = azurerm_recovery_services_vault.aecorsoft.name
  source_vm_id        = azurerm_windows_virtual_machine.aecorsoft.id
  backup_policy_id    = azurerm_backup_policy_vm.aecorsoft.id
}
