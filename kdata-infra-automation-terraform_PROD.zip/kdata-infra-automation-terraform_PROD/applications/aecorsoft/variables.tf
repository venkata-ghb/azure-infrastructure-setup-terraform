variable "vm_name" {
  type        = string
  default     = "cmnkdatapacr01"
  description = "Name of the Aecorsoft virtual machine"
}

variable "rdp_allowed_address_list" {
  type        = list(string)
  default     = ["157.144.201.0/24", "157.144.241.0/24"]
  description = ""
}
variable "aecorsoft_client_inbuilt_user_allowed_address_list" {
  type        = list(string)
  default     = ["157.144.201.0/24", "157.144.241.0/24"]
  description = ""
}
variable "aecorsoft_client_sso_allowed_address_list" {
  type        = list(string)
  default     = ["157.144.201.0/24", "157.144.241.0/24"]
  description = ""
}
variable "sapuska_port_ranges" {
  type        = list(string)
  default     = ["3200-3299", "3300-3399", "3600-3699"]
  description = ""
}
variable "sapuska_address_list" {
  type        = list(string)
  default     = ["10.221.46.0/23"]
  description = ""
}
variable "controlm_allowed_address_list" {
  type        = list(string)
  default     = ["157.144.241.0/24", "157.144.201.0/24", "157.144.40.45/32"]
  description = ""
}
