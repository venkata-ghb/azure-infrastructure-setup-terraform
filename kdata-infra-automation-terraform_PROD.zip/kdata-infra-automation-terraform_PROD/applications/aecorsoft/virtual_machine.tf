resource "random_password" "vm_aecorsoft_admin_password" {
  length      = 20
  min_numeric = 0
  min_special = 0
  min_upper   = 0
  special     = true
  #override_special = "@#$"
}

resource "azurerm_windows_virtual_machine" "aecorsoft" {
  name                  = var.vm_name
  resource_group_name   = azurerm_resource_group.aecorsoft.name
  location              = azurerm_resource_group.aecorsoft.location
  tags                  = local.resource_tags
  size                  = "Standard_DS5_v2"
  admin_username        = "aecorsoft_admin"
  admin_password        = random_password.vm_aecorsoft_admin_password.result
  network_interface_ids = [azurerm_network_interface.aecorsoft_nic_01.id]
  patch_assessment_mode = "ImageDefault"
  license_type          = "Windows_Server"


  os_disk {
    caching              = "ReadWrite"
    storage_account_type = "Premium_LRS"
    disk_size_gb         = 512
  }

  source_image_reference {
    publisher = "MicrosoftWindowsServer"
    offer     = "WindowsServer"
    sku       = "2016-Datacenter"
    version   = "latest"
  }
}
