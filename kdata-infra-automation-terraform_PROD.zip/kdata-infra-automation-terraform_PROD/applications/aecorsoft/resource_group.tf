resource "azurerm_resource_group" "aecorsoft" {
  name     = "${local.prefix_rg}_Aecorsoft_RG"
  location = local.location.long
  tags     = local.resource_tags
}
