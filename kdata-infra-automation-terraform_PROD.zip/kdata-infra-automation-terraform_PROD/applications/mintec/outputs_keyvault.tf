output "kv_mintec" {
  value = {
    id        = azurerm_key_vault.mintec.id
    name      = azurerm_key_vault.mintec.name
    vault_uri = azurerm_key_vault.mintec.vault_uri
  }
}
