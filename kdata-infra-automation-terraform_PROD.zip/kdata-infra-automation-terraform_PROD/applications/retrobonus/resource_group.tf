resource "azurerm_resource_group" "retrobonus" {
  name     = "${var.prefix_rg}_RETROBONUS_Main_RG"
  location = var.location
  tags     = local.resource_tags
}
