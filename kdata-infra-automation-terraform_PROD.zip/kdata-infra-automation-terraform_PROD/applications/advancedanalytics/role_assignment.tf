# ================================================================================================================================
# Resource Group
# ================================================================================================================================
resource "azurerm_role_assignment" "rg_advancedanalytics-contributor-group_admins_platform" {
  scope                = azurerm_resource_group.advancedanalytics.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.group_admins_platform.id
}

resource "azurerm_role_assignment" "rg_advancedanalytics-reader-group_devops_platform" {
  scope                = azurerm_resource_group.advancedanalytics.id
  role_definition_name = "Reader"
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
}
