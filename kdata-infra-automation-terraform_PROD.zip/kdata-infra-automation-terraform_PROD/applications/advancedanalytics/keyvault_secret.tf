# ================================================================================================================================
# APIM
# ================================================================================================================================
resource "azurerm_key_vault_secret" "advanalyt-sp_advancedanalytics_adb_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_advancedanalytics_adb.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_advancedanalytics_adb_password
  key_vault_id = azurerm_key_vault.advanalyt.id
  content_type = "${data.terraform_remote_state.ad.outputs.sp_advancedanalytics_adb.display_name} SP's Password by Terraform"
  tags         = local.resource_tags
}
