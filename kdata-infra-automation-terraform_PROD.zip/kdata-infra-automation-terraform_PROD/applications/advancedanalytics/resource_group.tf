resource "azurerm_resource_group" "advancedanalytics" {
  name     = "${var.prefix_rg}_ADVANCEDANALYTICS_MAIN_RG"
  location = var.location
  tags     = local.resource_tags
}
