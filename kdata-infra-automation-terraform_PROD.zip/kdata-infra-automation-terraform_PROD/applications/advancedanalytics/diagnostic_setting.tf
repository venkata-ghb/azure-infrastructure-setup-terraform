# =======================================================
# Key Vault
# =======================================================

# advanalyt
resource "azurerm_monitor_diagnostic_setting" "kv_advanalyt" {
  name               = "${azurerm_key_vault.advanalyt.name}-audit"
  target_resource_id = azurerm_key_vault.advanalyt.id
  storage_account_id = data.terraform_remote_state.monitoring.outputs.sa_auditlogs.id

  log {
    category = "AuditEvent"
    enabled  = true

    retention_policy {
      days    = 365
      enabled = true
    }
  }

  log {
    category = "AzurePolicyEvaluationDetails"
    enabled  = false

    retention_policy {
      days    = 0
      enabled = false
    }
  }

  metric {
    category = "AllMetrics"
    enabled  = true

    retention_policy {
      days    = 365
      enabled = true
    }
  }
}
