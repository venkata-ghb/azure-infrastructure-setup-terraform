resource "azurerm_resource_group" "imageapi" {
  name     = "${var.prefix_rg}_IMAGEAPI_RG"
  location = var.location
  tags     = local.resource_tags
}
