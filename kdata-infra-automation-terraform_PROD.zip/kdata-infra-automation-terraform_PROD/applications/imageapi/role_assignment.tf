resource "azurerm_role_assignment" "rg_imageapi-contributor-group_admins_platform" {
  principal_id         = data.terraform_remote_state.ad.outputs.group_admins_platform.id
  role_definition_name = "Contributor"
  scope                = azurerm_resource_group.imageapi.id
}

resource "azurerm_role_assignment" "rg_imageapi-reader-group_devops_platform" {
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
  role_definition_name = "Reader"
  scope                = azurerm_resource_group.imageapi.id
}

resource "azurerm_role_assignment" "sa_imageapi-blob_reader-group_devops_platform" {
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
  role_definition_name = "Storage Blob Data Reader"
  scope                = azurerm_storage_account.imageapi.id
}

resource "azurerm_role_assignment" "sa_imageapi_decoded_images-blob_contributor-msi_imageapi_funcapp" {
  principal_id         = azurerm_linux_function_app.imageapi.identity[0].principal_id
  role_definition_name = "Storage Blob Data Contributor"
  scope                = "${azurerm_storage_account.imageapi.id}/blobServices/default/containers/${azurerm_storage_container.imageapi-decoded_images.name}"
}

resource "azurerm_role_assignment" "sa_imageapi_encoded_images-blob_contributor-msi_imageapi_funcapp" {
  principal_id         = azurerm_linux_function_app.imageapi.identity[0].principal_id
  role_definition_name = "Storage Blob Data Contributor"
  scope                = "${azurerm_storage_account.imageapi.id}/blobServices/default/containers/${azurerm_storage_container.imageapi-encoded_images.name}"
}

resource "azurerm_role_assignment" "sa_imageapi_encoded_images-blob_reader-msi_adf_int" {
  principal_id         = data.terraform_remote_state.integrations.outputs.adf_int.msi
  role_definition_name = "Storage Blob Data Reader"
  scope                = "${azurerm_storage_account.imageapi.id}/blobServices/default/containers/${azurerm_storage_container.imageapi-encoded_images.name}"
}
