data "azurerm_client_config" "current" {}

locals {
  msi_kv_access_policy = {
    object_id               = data.terraform_remote_state.ad.outputs.msi_infra.id
    tenant_id               = data.azurerm_subscription.current.tenant_id
    application_id          = ""
    certificate_permissions = ["Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"]
    key_permissions         = ["Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"]
    secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
    storage_permissions     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"]
  }
}

resource "azurerm_key_vault" "imageapi" {
  name                        = "${var.prefix}-imageapi-kv"
  location                    = var.location
  resource_group_name         = azurerm_resource_group.imageapi.name
  enabled_for_disk_encryption = true
  tenant_id                   = data.azurerm_client_config.current.tenant_id
  purge_protection_enabled    = false
  sku_name                    = "standard"
  tags                        = local.resource_tags

  access_policy = [local.msi_kv_access_policy]
  
  lifecycle {
    ignore_changes = [access_policy]
  }
}

resource "azurerm_key_vault_access_policy" "imageapi-msi_infra" {
  key_vault_id = azurerm_key_vault.imageapi.id
  tenant_id    = data.azurerm_subscription.current.tenant_id
  object_id    = local.msi_kv_access_policy.object_id

  certificate_permissions = local.msi_kv_access_policy.certificate_permissions
  key_permissions         = local.msi_kv_access_policy.key_permissions
  secret_permissions      = local.msi_kv_access_policy.secret_permissions
  storage_permissions     = local.msi_kv_access_policy.storage_permissions
}

resource "azurerm_key_vault_access_policy" "imageapi-group_admins_platform" {
  key_vault_id = azurerm_key_vault.imageapi.id
  tenant_id    = data.azurerm_client_config.current.tenant_id
  object_id    = data.terraform_remote_state.ad.outputs.group_admins_platform.id

  secret_permissions = [
    "Get",
    "Set",
    "List",
    "Delete"
  ]
  key_permissions = [
    "Create",
    "Get",
    "List",
    "Delete"
  ]
  certificate_permissions = [
    "Create",
    "Update",
    "Get",
    "List",
    "Delete"
  ]
}

resource "azurerm_key_vault_access_policy" "imageapi-msi_imageapi_funcapp" {
  key_vault_id = azurerm_key_vault.imageapi.id
  tenant_id    = data.azurerm_client_config.current.tenant_id
  object_id    = azurerm_linux_function_app.imageapi.identity[0].principal_id

  secret_permissions = ["Get",]
}
