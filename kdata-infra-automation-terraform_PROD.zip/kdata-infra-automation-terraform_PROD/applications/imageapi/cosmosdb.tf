resource "azurerm_cosmosdb_sql_database" "imageapi_db" {
  name                = "imageapi-db"
  resource_group_name = data.terraform_remote_state.integrations.outputs.cosmosdb_main.resource_group_name
  account_name        = data.terraform_remote_state.integrations.outputs.cosmosdb_main.name
}

resource "azurerm_cosmosdb_sql_container" "gtsap_reclamation" {
  name                = "gtsap-reclamation"
  resource_group_name = data.terraform_remote_state.integrations.outputs.cosmosdb_main.resource_group_name
  account_name        = data.terraform_remote_state.integrations.outputs.cosmosdb_main.name
  database_name       = azurerm_cosmosdb_sql_database.imageapi_db.name
  partition_key_path  = "/VBELN"
}
