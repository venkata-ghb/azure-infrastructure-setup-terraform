resource "azurerm_storage_account" "imageapi" {
  name                            = "${var.prefix_sa}${var.loc}imageapi"
  resource_group_name             = azurerm_resource_group.imageapi.name
  location                        = var.location
  account_tier                    = "Standard"
  account_replication_type        = "LRS"
  allow_nested_items_to_be_public = false
  tags                            = local.resource_tags
  network_rules {
    default_action = "Allow"
    virtual_network_subnet_ids = [ "/subscriptions/0a2d289e-76dd-4b1f-b9b2-dba15a872e92/resourceGroups/rg-platform-avd-prod-weu-001/providers/Microsoft.Network/virtualNetworks/vnet-avd-prod-weu-001/subnets/Subnet-AVDTCS-AMS-prod-weu" ]
  }
}

resource "azurerm_storage_container" "imageapi-encoded_images" {
  name                 = "encoded-images"
  storage_account_name = azurerm_storage_account.imageapi.name
}

resource "azurerm_storage_container" "imageapi-decoded_images" {
  name                 = "decoded-images"
  storage_account_name = azurerm_storage_account.imageapi.name
}

data "azurerm_storage_account_sas" "imageapi" {
  connection_string = azurerm_storage_account.imageapi.primary_connection_string
  https_only        = true

  resource_types {
    service   = false
    container = true
    object    = true
  }

  services {
    blob  = true
    queue = false
    table = false
    file  = false
  }

  start  = "2026-01-01"
  expiry = "2028-01-31"

  permissions {
    read    = true
    write   = false
    delete  = false
    list    = true
    add     = false
    create  = false
    update  = false
    process = false
    filter  = false
    tag     = false
  }
}
