resource "azurerm_monitor_action_group" "imageapi" {
  name                = "${var.prefix}-imageapi-integration-errors-action-group"
  resource_group_name = azurerm_resource_group.imageapi.name
  short_name          = "Imageapi-err"

  tags = local.resource_tags

  email_receiver {
    name          = "Nico Miettinen"
    email_address = "nico.miettinen@kesko.fi"
  }

  email_receiver {
    name          = "DL_KESKOAMS_TCS_KDATA"
    email_address = "DL_KESKOAMS_TCS_KDATA@kesko.fi"
  }

}

resource "azurerm_monitor_metric_alert" "insights_imageapi-exception" {
  name                = "${var.prefix}-appsinght-imageapi-exception-alert"
  resource_group_name = azurerm_resource_group.imageapi.name
  scopes              = [azurerm_application_insights.imageapi.id]
  description         = "Imageapi Function app Exception"
  auto_mitigate       = false
  frequency           = "PT15M"
  window_size         = "PT15M"
  severity            = 0

  criteria {
    metric_namespace = "Microsoft.Insights/Components"
    metric_name      = "exceptions/count"
    aggregation      = "Count"
    operator         = "GreaterThan"
    threshold        = 0

  }

  action {
    action_group_id = azurerm_monitor_action_group.imageapi.id
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_metric_alert" "insights_imageapi-failed_req" {
  name                = "${var.prefix}-appsinght-imageapi-failerreq-alert"
  resource_group_name = azurerm_resource_group.imageapi.name
  scopes              = [azurerm_application_insights.imageapi.id]
  description         = "Imageapi Function app Failed Request"
  auto_mitigate       = false
  frequency           = "PT15M"
  window_size         = "PT15M"
  severity            = 0

  criteria {
    metric_namespace = "Microsoft.Insights/Components"
    metric_name      = "exceptions/count"
    aggregation      = "Count"
    operator         = "GreaterThan"
    threshold        = 0

  }

  action {
    action_group_id = azurerm_monitor_action_group.imageapi.id
  }

  tags = local.resource_tags
}
