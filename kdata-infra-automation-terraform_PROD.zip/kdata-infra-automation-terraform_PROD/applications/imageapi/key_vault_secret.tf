resource "azurerm_key_vault_secret" "imageapi-storage_sas" {
  key_vault_id = azurerm_key_vault.imageapi.id
  name         = "storage-account-imageapi-sas"
  value        = data.azurerm_storage_account_sas.imageapi.sas
  content_type = "Storage Account imageapi SAS token"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "imageapi-cosmosdb_main_connection_string" {
  key_vault_id = azurerm_key_vault.imageapi.id
  name         = "cosmosdb-main-connection-string"
  value        = data.terraform_remote_state.integrations.outputs.cosmosdb_main.primary_sql_connection_string
  content_type = "CosmosDB main connection string"
  tags         = local.resource_tags
}