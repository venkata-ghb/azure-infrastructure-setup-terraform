resource "azurerm_linux_function_app" "encodeconvert" {
  name                        = "${local.prefix}-${local.location.short}-encode-convert-funcapp"
  location                    = local.location.long
  resource_group_name         = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  service_plan_id             = data.terraform_remote_state.integrations.outputs.service_plan_int_premium.id
  storage_account_name        = azurerm_storage_account.encodeconvert.name
  storage_account_access_key  = azurerm_storage_account.encodeconvert.primary_access_key
  https_only                  = true
  functions_extension_version = "~4"
  builtin_logging_enabled     = false
  client_certificate_mode     = "Required"
  virtual_network_subnet_id   = data.terraform_remote_state.vnets.outputs.subnet_funcapp_int.id

  identity {
    type = "SystemAssigned"
  }

  site_config {
    ftps_state = "Disabled"
    application_insights_connection_string = azurerm_application_insights.encodeconvert.connection_string
    vnet_route_all_enabled                 = true
    always_on                              = true

    application_stack {
      python_version = "3.11"
    }
  }

  app_settings = {
    AzureWebJobsFeatureFlags            = "EnableWorkerIndexing"
    WEBSITES_ENABLE_APP_SERVICE_STORAGE = "true"
    WEBSITE_ENABLE_SYNC_UPDATE_SITE     = "true"
    WEBSITE_RUN_FROM_PACKAGE            = "0"
    SINK_DATALAKE_NAME                  = data.terraform_remote_state.integrations.outputs.sa_adls.name
  }

  tags = local.resource_tags

  lifecycle {
    ignore_changes = [
      app_settings["WEBSITE_ENABLE_SYNC_UPDATE_SITE"],
      app_settings["WEBSITES_ENABLE_APP_SERVICE_STORAGE"],
      app_settings["WEBSITE_RUN_FROM_PACKAGE"],
      tags["hidden-link: /app-insights-conn-string"],
      tags["hidden-link: /app-insights-instrumentation-key"],
      tags["hidden-link: /app-insights-resource-id"],
    ]
  }
}

resource "azurerm_application_insights" "encodeconvert" {
  name                = "${local.prefix}-${local.location.short}-encode-convert-funcapp"
  location            = local.location.long
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  application_type    = "web"
  retention_in_days   = 90
  sampling_percentage = 0
  workspace_id        = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  tags                = local.resource_tags
}
