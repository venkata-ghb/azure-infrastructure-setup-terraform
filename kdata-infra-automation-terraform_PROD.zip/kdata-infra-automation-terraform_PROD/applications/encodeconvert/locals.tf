locals {
  prefix                     = data.terraform_remote_state.common.outputs.prefix
  prefix_sa                  = data.terraform_remote_state.common.outputs.prefix_sa
  location                   = data.terraform_remote_state.common.outputs.location
  resource_tags              = data.terraform_remote_state.common.outputs.resource_tags
}
