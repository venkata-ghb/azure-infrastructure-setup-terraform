resource "azurerm_role_assignment" "sa_encodeconvert-queue_sender-msi_eg_adls" {
  scope                = azurerm_storage_account.encodeconvert.id
  role_definition_name = "Storage Queue Data Message Sender"
  principal_id         = data.terraform_remote_state.integrations.outputs.sa_eg_system_topic.identity[0].principal_id
}

resource "azurerm_role_assignment" "sa_adls_adf_staging-blob_data_contributor-msi_encodeconvert_funcapp" {
  scope                = "${data.terraform_remote_state.integrations.outputs.sa_adls.id}/blobServices/default/containers/adf-staging"
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azurerm_linux_function_app.encodeconvert.identity[0].principal_id
}

