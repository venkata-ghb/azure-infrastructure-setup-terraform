resource "azurerm_eventgrid_system_topic_event_subscription" "sa_adls" {
  name                = "kdata-encode-convert"
  system_topic        = data.terraform_remote_state.integrations.outputs.sa_eg_system_topic.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.sa_eg_system_topic.resource_group_name

  subject_filter {
    subject_begins_with = "/blobServices/default/containers/adf-staging/blobs/encode-convert/"
  }

  advanced_filter {
    number_greater_than {
      key   = "data.contentLength"
      value = 0
    }
  }

  storage_queue_endpoint {
    storage_account_id = azurerm_storage_account.encodeconvert.id
    queue_name         = azurerm_storage_queue.encodeconvert-queue.name
  }

  delivery_identity {
    type = "SystemAssigned"
  }

  # Role assignment needs to be applied before subscription
  depends_on = [azurerm_role_assignment.sa_encodeconvert-queue_sender-msi_eg_adls]
}
