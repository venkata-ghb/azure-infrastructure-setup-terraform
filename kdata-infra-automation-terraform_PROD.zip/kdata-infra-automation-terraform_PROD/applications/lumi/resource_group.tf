resource "azurerm_resource_group" "lumi" {
  name     = "${local.prefix_rg}_LUMI_Main_RG"
  location = local.location.long
  tags     = local.resource_tags
}
