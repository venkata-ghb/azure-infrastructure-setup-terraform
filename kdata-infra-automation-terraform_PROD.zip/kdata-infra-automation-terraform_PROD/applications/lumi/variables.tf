variable "location" {
  type        = string
  description = "Location"
  default     = "westeurope"
}

variable "loc" {
  type        = string
  description = "Location short"
  default     = "we"
}

variable "env" {
  type        = string
  description = "Environment short"
  default     = "prod"
}

variable "environment" {
  type        = string
  description = "Environment name"
  default     = "Production"
}

variable "prefix" {
  type        = string
  description = "Prefix to be applied to all resource names"
  default     = "kdata-prod"
}

variable "prefix_sa" {
  type        = string
  description = "Prefix to be applied to all resource names in storage account"
  default     = "kdataprod"
}

variable "prefix_rg" {
  type        = string
  description = "Prefix to be applied to all resource names in resource group"
  default     = "K-DATA_PROD_WE"
}

variable "resource_tags" {
  type        = map(string)
  description = "Tags to be applied for all resources"
  default = {
    Application     = "Cloud Data Platform"
    "Business Unit" = "Shared"
    Sub-Service     = "C1231"
    environment     = "Production"
    IT-owner        = "sankalp.ahuja@kesko.fi"
    ManagedResource = "Yes"
    MgmtVendor      = "Tieto"
    created_by      = "Terraform"
    Description     = "Infrastructure for Kesko Data Platform"
    SubApplication  = "LUMI"
  }
}
