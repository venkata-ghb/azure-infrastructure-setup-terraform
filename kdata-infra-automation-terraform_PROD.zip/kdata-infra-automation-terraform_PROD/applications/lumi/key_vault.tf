data "azurerm_client_config" "current" {}

resource "azurerm_key_vault" "lumi" {
  name                            = "${local.prefix}-lumi-kv"
  location                        = azurerm_resource_group.lumi.location
  resource_group_name             = azurerm_resource_group.lumi.name
  tenant_id                       = data.azurerm_subscription.current.tenant_id
  enabled_for_disk_encryption     = false
  enabled_for_template_deployment = true
  purge_protection_enabled        = true
  sku_name                        = "standard"
  tags                            = local.resource_tags

  access_policy = [local.msi_infra_key_vault_access]

  network_acls {
    bypass         = "AzureServices"
    default_action = "Deny"
    ip_rules = [
      "157.144.201.0/24", # Kesko Workspace
      "157.144.241.0/24", # Kesko Workspace
      "185.18.77.12",     # SOLITA IP 1
      "194.157.227.124",  # SOLITA IP 2
      "213.219.110.42",   # SOLITA IP 3
      "85.194.237.84",    # SOLITA IP 4
      "85.194.237.85",    # SOLITA IP 5
      "87.236.156.218",   # SOLITA IP 7
      "89.41.48.226",     # SOLITA IP 8
      "89.41.48.227",     # SOLITA IP 9
      "89.41.48.228",     # SOLITA IP 10
      "95.175.96.152",    # SOLITA IP 11
      "13.81.240.206",    # SOLITA IP 12
      "92.33.9.13",       # SOLITA IP 13
      "40.119.145.170",   # CITRIX 1
      "52.137.57.167",    # CITRIX 2
      "20.126.245.27",    # AVD
    ]
    virtual_network_subnet_ids = [
      data.terraform_remote_state.vnet.outputs.subnet_robot.id,
      data.terraform_remote_state.vnet.outputs.subnet_funcapp_int.id,
      data.terraform_remote_state.vnet.outputs.subnet_funcapp_app.id,
      "/subscriptions/02147589-2a7d-4483-b5da-af70a38cea3f/resourceGroups/k-data_prod_we_lumi_main_rg/providers/Microsoft.Network/virtualNetworks/kdata-prod-lumi-vnet/subnets/functionapp",      # LUMI functionapp
      "/subscriptions/02147589-2a7d-4483-b5da-af70a38cea3f/resourceGroups/k-data_prod_we_lumi_main_rg/providers/Microsoft.Network/virtualNetworks/kdata-prod-lumi-vnet/subnets/functionapplinux", # LUMI functionapp 
    ]
  }

  lifecycle { ignore_changes = [access_policy] } # Lumi team is adding access policies so we cannot manage full state of accesses
}

resource "azurerm_key_vault_access_policy" "lumi-sp_terraforminfra" {
  key_vault_id = azurerm_key_vault.lumi.id
  tenant_id    = data.azurerm_subscription.current.tenant_id
  object_id    = local.msi_infra_key_vault_access.object_id

  certificate_permissions = local.msi_infra_key_vault_access.certificate_permissions
  key_permissions         = local.msi_infra_key_vault_access.key_permissions
  secret_permissions      = local.msi_infra_key_vault_access.secret_permissions
  storage_permissions     = local.msi_infra_key_vault_access.storage_permissions
}

resource "azurerm_key_vault_access_policy" "lumi-group_admins_platform" {
  key_vault_id = azurerm_key_vault.lumi.id
  tenant_id    = data.azurerm_subscription.current.tenant_id
  object_id    = data.terraform_remote_state.ad.outputs.group_admins_platform.id

  certificate_permissions = ["Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"]
  key_permissions         = ["Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"]
  secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
  storage_permissions     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"]
}

resource "azurerm_key_vault_access_policy" "lumi-group_devops_solitadev" {
  key_vault_id = azurerm_key_vault.lumi.id
  tenant_id    = data.azurerm_subscription.current.tenant_id
  object_id    = data.terraform_remote_state.ad.outputs.group_devops_solitadev.id

  certificate_permissions = ["Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"]
  key_permissions         = ["Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"]
  secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
  storage_permissions     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"]
}

resource "azurerm_key_vault_access_policy" "lumi-databricks" {
  key_vault_id = azurerm_key_vault.lumi.id
  tenant_id    = data.azurerm_subscription.current.tenant_id
  object_id    = "0b76c138-ab01-423f-b0db-775b3bf5d63b" # AzureDatabricks

  certificate_permissions = []
  key_permissions         = []
  secret_permissions      = ["Get", "List", ]
  storage_permissions     = []
}

resource "azurerm_key_vault_access_policy" "lumi-adf_int" {
  key_vault_id = azurerm_key_vault.lumi.id
  tenant_id    = data.azurerm_subscription.current.tenant_id
  object_id    = data.terraform_remote_state.integrations.outputs.adf_int.msi

  certificate_permissions = []
  key_permissions         = []
  secret_permissions      = ["Get", ]
  storage_permissions     = []
}

resource "azurerm_key_vault_access_policy" "lumi-sp_lumi_devops" {
  key_vault_id = azurerm_key_vault.lumi.id
  tenant_id    = data.azurerm_subscription.current.tenant_id
  object_id    = data.terraform_remote_state.ad.outputs.sp_lumi_devops.id

  certificate_permissions = []
  key_permissions         = []
  secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
  storage_permissions     = []
}
