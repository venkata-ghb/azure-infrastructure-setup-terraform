
resource "azurerm_key_vault_secret" "lumi-sp_lumi_adb_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_lumi_adb.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_lumi_adb_password
  key_vault_id = azurerm_key_vault.lumi.id
  content_type = "${data.terraform_remote_state.ad.outputs.sp_lumi_adb.display_name} SP's Password by Terraform"
  tags         = local.resource_tags
}
