resource "azurerm_role_assignment" "rg_lumi-contributor-group_admins_platform" {
  scope                = azurerm_resource_group.lumi.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.group_admins_platform.id
}

resource "azurerm_role_assignment" "rg_lumi-contributor-group_devops_solitadev" {
  scope                = azurerm_resource_group.lumi.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_solitadev.id
}

resource "azurerm_role_assignment" "rg_lumi-contributor-group_devops_keskodev" {
  scope                = azurerm_resource_group.lumi.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_keskodev.id
}

resource "azurerm_role_assignment" "rg_lumi-contributor-sp_lumi_devops" {
  scope                = azurerm_resource_group.lumi.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.sp_lumi_devops.id
}

resource "azurerm_role_assignment" "rg_lumi-user_access_admin-sp_lumi_devops" {
  scope                = azurerm_resource_group.lumi.id
  role_definition_name = "User Access Administrator"
  principal_id         = data.terraform_remote_state.ad.outputs.sp_lumi_devops.id
}

resource "azurerm_role_assignment" "rg_lumi-reader-group_devops_platform" {
  scope                = azurerm_resource_group.lumi.id
  role_definition_name = "Reader"
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
}
