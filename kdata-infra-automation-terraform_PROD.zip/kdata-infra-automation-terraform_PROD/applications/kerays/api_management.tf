# API management stuff
data "azurerm_api_management" "apimanagement" {
  provider            = azurerm.apim
  name                = "K-apim-${var.env}"
  resource_group_name = "KESKO_WE_RG_APIM_${upper(var.env)}001"
}

resource "azurerm_api_management_api" "kerays" {
  provider            = azurerm.apim
  name                = "kdata-kerays-input-api"
  resource_group_name = data.azurerm_api_management.apimanagement.resource_group_name
  api_management_name = data.azurerm_api_management.apimanagement.name
  revision            = "1"
  display_name        = "K-Data Kerays Input API"
  path                = "kdata/kerays-input-api"
  protocols           = ["https"]

  import {
    content_format = "openapi+json"
    content_value  = file("${path.module}/resources/openapi.json")
  }
}

resource "azurerm_api_management_api_operation_policy" "kerays-login" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.kerays.name
  api_management_name = azurerm_api_management_api.kerays.api_management_name
  resource_group_name = azurerm_api_management_api.kerays.resource_group_name
  operation_id        = "post-login"

  xml_content = templatefile(
    "${path.module}/resources/eventhub-policy.xml", {
      eventhub_namespace = data.terraform_remote_state.integrations.outputs.ehns_kerays.name
      eventhub_topic     = "login-natural"
  })
}

resource "azurerm_api_management_api_operation_policy" "kerays-logout" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.kerays.name
  api_management_name = azurerm_api_management_api.kerays.api_management_name
  resource_group_name = azurerm_api_management_api.kerays.resource_group_name
  operation_id        = "post-logout"

  xml_content = templatefile(
    "${path.module}/resources/eventhub-policy.xml", {
      eventhub_namespace = data.terraform_remote_state.integrations.outputs.ehns_kerays.name
      eventhub_topic     = "logout-natural"
  })
}

resource "azurerm_api_management_api_operation_policy" "kerays-pickerupdate" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.kerays.name
  api_management_name = azurerm_api_management_api.kerays.api_management_name
  resource_group_name = azurerm_api_management_api.kerays.resource_group_name
  operation_id        = "post-pickerupdate"

  xml_content = templatefile(
    "${path.module}/resources/eventhub-policy.xml", {
      eventhub_namespace = data.terraform_remote_state.integrations.outputs.ehns_kerays.name
      eventhub_topic     = "pickerupdate-natural"
  })
}

resource "azurerm_api_management_api_operation_policy" "kerays-startpickinground" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.kerays.name
  api_management_name = azurerm_api_management_api.kerays.api_management_name
  resource_group_name = azurerm_api_management_api.kerays.resource_group_name
  operation_id        = "post-startpickinground"

  xml_content = templatefile(
    "${path.module}/resources/eventhub-policy.xml", {
      eventhub_namespace = data.terraform_remote_state.integrations.outputs.ehns_kerays.name
      eventhub_topic     = "startpickinground-natural"
  })
}

resource "azurerm_api_management_api_operation_policy" "kerays-cancelpickinground" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.kerays.name
  api_management_name = azurerm_api_management_api.kerays.api_management_name
  resource_group_name = azurerm_api_management_api.kerays.resource_group_name
  operation_id        = "post-cancelpickinground"

  xml_content = templatefile(
    "${path.module}/resources/eventhub-policy.xml", {
      eventhub_namespace = data.terraform_remote_state.integrations.outputs.ehns_kerays.name
      eventhub_topic     = "cancelpickinground-natural"
  })
}

resource "azurerm_api_management_api_operation_policy" "kerays-finishpickinground" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.kerays.name
  api_management_name = azurerm_api_management_api.kerays.api_management_name
  resource_group_name = azurerm_api_management_api.kerays.resource_group_name
  operation_id        = "post-finishpickinground"

  xml_content = templatefile(
    "${path.module}/resources/eventhub-policy.xml", {
      eventhub_namespace = data.terraform_remote_state.integrations.outputs.ehns_kerays.name
      eventhub_topic     = "finishpickinground-natural"
  })
}

resource "azurerm_api_management_api_operation_policy" "kerays-orderfullypicked" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.kerays.name
  api_management_name = azurerm_api_management_api.kerays.api_management_name
  resource_group_name = azurerm_api_management_api.kerays.resource_group_name
  operation_id        = "post-orderfullypicked"

  xml_content = templatefile(
    "${path.module}/resources/eventhub-policy.xml", {
      eventhub_namespace = data.terraform_remote_state.integrations.outputs.ehns_kerays.name
      eventhub_topic     = "orderfullypicked-natural"
  })
}

resource "azurerm_api_management_product" "kerays" {
  provider              = azurerm.apim
  display_name          = azurerm_api_management_api.kerays.display_name
  product_id            = "${azurerm_api_management_api.kerays.name}-product"
  api_management_name   = azurerm_api_management_api.kerays.api_management_name
  resource_group_name   = azurerm_api_management_api.kerays.resource_group_name
  subscriptions_limit   = 0
  subscription_required = true
  approval_required     = false
  published             = true
}

resource "azurerm_api_management_product_api" "kerays" {
  provider            = azurerm.apim
  product_id          = azurerm_api_management_product.kerays.product_id
  api_name            = azurerm_api_management_api.kerays.name
  api_management_name = azurerm_api_management_api.kerays.api_management_name
  resource_group_name = azurerm_api_management_api.kerays.resource_group_name
}

resource "azurerm_api_management_product_group" "kerays" {
  provider            = azurerm.apim
  product_id          = azurerm_api_management_product.kerays.product_id
  api_management_name = azurerm_api_management_api.kerays.api_management_name
  resource_group_name = azurerm_api_management_api.kerays.resource_group_name
  group_name          = "624599fd0978d4f9f6fe1dbb"
}

resource "azurerm_api_management_api_tag" "kerays" {
  provider = azurerm.apim
  api_id   = azurerm_api_management_api.kerays.id
  name     = "k-data"
}
