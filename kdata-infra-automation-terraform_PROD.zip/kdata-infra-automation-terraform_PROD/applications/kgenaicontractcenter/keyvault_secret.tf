# This secret is from the service principal genai-contractcenter-app-dev
resource "azurerm_key_vault_secret" "kgenaicontractcenter-kgenaicontractcenter_sp_password" {
  name         = "kdata-contractcenter-sp-password"
  value        = data.terraform_remote_state.ad.outputs.sp_kgenaicontractcenter_password
  key_vault_id = azurerm_key_vault.kgenaicontractcenter.id
}

# CRUD management via logic app , to be shared with APIM
resource "azurerm_key_vault_secret" "kgenaicontractcenter-kgenaicontractcenter_crud_sp_password" {
  name         = "kdata-contractcenter-crud-sp-password"
  value        = data.terraform_remote_state.ad.outputs.sp_kgenaicontractcenter_crud_password
  key_vault_id = azurerm_key_vault.kgenaicontractcenter.id
}

# Sharepoint sp for Grpah API access
resource "azurerm_key_vault_secret" "kgenaicontractcenter-kgenaicontractcenter_sharepoint_sp_password" {
  name         = "kdata-contractcenter-sharepoint-sp-password"
  value        = data.terraform_remote_state.ad.outputs.sp_kgenaicontractcenter_sharepoint_password
  key_vault_id = azurerm_key_vault.kgenaicontractcenter.id
}


# Hashing key 
resource "random_password" "kgenaicontractcenter_fe-nextjs_auth_hash" {
  length  = 64
  special = true
}

resource "azurerm_key_vault_secret" "kgenaicontractcenter-nextjs_auth_hash" {
  name         = "kgenaicontractcenter-fe-nextjs-auth-hash"
  value        = random_password.kgenaicontractcenter_fe-nextjs_auth_hash.result
  key_vault_id = azurerm_key_vault.kgenaicontractcenter.id
}
