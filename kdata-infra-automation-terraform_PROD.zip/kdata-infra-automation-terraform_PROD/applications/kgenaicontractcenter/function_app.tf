resource "azurerm_linux_function_app" "kgenaicontractcenter" {
  name                        = "${local.prefix}-${local.location.short}-kgenaicontractcenter-fn-app"
  resource_group_name         = azurerm_resource_group.kgenaicontractcenter.name
  location                    = local.location.long
  service_plan_id             = replace(data.terraform_remote_state.azureai.outputs.service_plan_kgenai_001.id, "serverfarms", "serverFarms")
  storage_account_name        = azurerm_storage_account.kgenaicontractcenter.name
  storage_account_access_key  = azurerm_storage_account.kgenaicontractcenter.primary_access_key
  https_only                  = true
  functions_extension_version = "~4"
  builtin_logging_enabled     = false
  #client_certificate_mode     = "Required"
  virtual_network_subnet_id = data.terraform_remote_state.vnets.outputs.subnet_funcapp_int.id

  identity {
    type = "SystemAssigned"
  }

  site_config {
    always_on                              = true
    ftps_state                             = "FtpsOnly"
    application_insights_key               = azurerm_application_insights.kgenaicontractcenter.instrumentation_key
    application_insights_connection_string = azurerm_application_insights.kgenaicontractcenter.connection_string
    #vnet_route_all_enabled                 = true

    application_stack {
      python_version = "3.12"
    }
  }
  app_settings = {
    "AzureWebJobs.webhook_renewal.Disabled" = "1"
    "BUILD_FLAGS"                           = "UseExpressBuild"
    "ENABLE_ORYX_BUILD"                     = "true"
    "ENDPOINT_URL"                          = "https://kdata-prod-we-kgenaicontractcenter-be-app.azurewebsites.net/api/v1/webhooks/manage_webhook"
    "SCM_DO_BUILD_DURING_DEPLOYMENT"        = "1"
    "STORAGE_CONTAINER_NAME"                = "webhook-details"
    "STORAGE_FILE_NAME"                     = "webhook-operations.csv"
    "STORAGE_FOLDER_NAME"                   = "webhook-entry"
    "WEBHOOK_RENEWAL_SCHEDULE"              = "0 0 * * * *"
    WEBSITE_ENABLE_SYNC_UPDATE_SITE         = false

    "XDG_CACHE_HOME" = "/tmp/.cache"
  }

  tags = local.resource_tags

  lifecycle {
    ignore_changes = [
      app_settings["WEBSITE_ENABLE_SYNC_UPDATE_SITE"],
      app_settings["WEBSITE_RUN_FROM_PACKAGE"],
      app_settings["WEBHOOK_RENEWAL_SCHEDULE"],
      tags
    ]
  }
}

