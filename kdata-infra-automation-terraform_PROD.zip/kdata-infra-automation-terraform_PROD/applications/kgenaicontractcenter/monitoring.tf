# Logs send to Eventhub from BE APP
resource "azurerm_monitor_diagnostic_setting" "eventhub_dynatrace-kgenaicontractcenter_be_app" {
  name                       = "kgenaicontractcenter-be-diagnostic-logs"
  target_resource_id         = azurerm_linux_web_app.kgenaicontractcenter_be.id
  eventhub_authorization_rule_id = data.terraform_remote_state.azureai.outputs.eventhub_namespace_rule_dynatrace_kgenai_write.id
  eventhub_name              = data.terraform_remote_state.azureai.outputs.eventhub_dynatrace_kgenaicontractcenter_be_app.name

  enabled_log {
    category = "AppServiceAppLogs"
  }

  metric {
    category = "AllMetrics"
    enabled  = true
  }
}

# Logs send to Eventhub from FE APP
resource "azurerm_monitor_diagnostic_setting" "eventhub_dynatrace-kgenaicontractcenter_fe_app" {
  name                       = "kgenaicontractcenter-fe-diagnostic-logs"
  target_resource_id         = azurerm_linux_web_app.kgenaicontractcenter_fe.id
  eventhub_authorization_rule_id = data.terraform_remote_state.azureai.outputs.eventhub_namespace_rule_dynatrace_kgenai_write.id
  eventhub_name              = data.terraform_remote_state.azureai.outputs.eventhub_dynatrace_kgenaicontractcenter_fe_app.name

  enabled_log {
    category = "AppServiceAppLogs"
  }

  metric {
    category = "AllMetrics"
    enabled  = true
  }
}