locals {
  prefix                     = data.terraform_remote_state.common.outputs.prefix
  prefix_sa                  = data.terraform_remote_state.common.outputs.prefix_sa
  prefix_rg                  = data.terraform_remote_state.common.outputs.prefix_rg
  env                        = data.terraform_remote_state.common.outputs.environment
  location                   = data.terraform_remote_state.common.outputs.location
  msi_infra_key_vault_access = data.terraform_remote_state.common.outputs.msi_infra_key_vault_access
  resource_tags = merge(data.terraform_remote_state.common.outputs.resource_tags, {
    SubApplication = "KGENAIMARKETING"
  })
}