resource "azurerm_role_assignment" "rg_kgenaicontractcenter-contributor-group_devops_platform" {
  scope                = azurerm_resource_group.kgenaicontractcenter.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
}

resource "azurerm_role_assignment" "rg_kgenaicontractcenter-contributor-sp_platform_devops" {
  scope                = azurerm_resource_group.kgenaicontractcenter.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.sp_platform_devops.id
}

resource "azurerm_role_assignment" "rg_kgenaicontractcenter-contributor-group_admins_platform" {
  scope                = azurerm_resource_group.kgenaicontractcenter.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.group_admins_platform.id
}

resource "azurerm_role_assignment" "rg_kgenaicontractcenter-contributor-group_admins_openai" {
  scope                = azurerm_resource_group.kgenaicontractcenter.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad_dev.outputs.group_admins_openai.id
}

resource "azurerm_role_assignment" "rg_kgenaicontractcenter-contributor-group_devops_openai" {
  scope                = azurerm_resource_group.kgenaicontractcenter.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad_dev.outputs.group_devops_openai.id
}

resource "azurerm_role_assignment" "rg_kgenaicontractcenter-reader-sp_platform_dynatrace" {
  scope                = azurerm_resource_group.kgenaicontractcenter.id
  role_definition_name = "Reader"
  principal_id         = data.terraform_remote_state.ad.outputs.sp_platform_dynatrace.id
}

resource "azurerm_role_assignment" "rg_kgenaicontractcenter-monitoring_reader-sp_platform_dynatrace" {
  scope                = azurerm_resource_group.kgenaicontractcenter.id
  role_definition_name = "Monitoring Reader"
  principal_id         = data.terraform_remote_state.ad.outputs.sp_platform_dynatrace.id
}