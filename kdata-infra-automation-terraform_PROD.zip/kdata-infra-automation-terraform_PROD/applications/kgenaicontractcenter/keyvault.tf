data "azurerm_client_config" "current" {}

resource "azurerm_key_vault" "kgenaicontractcenter" {
  name                        = "${local.prefix}-kgenaicc-kv" // // length must be between 3 and 24 characters long
  location                    = local.location.long
  resource_group_name         = azurerm_resource_group.kgenaicontractcenter.name
  enabled_for_disk_encryption = true
  tenant_id                   = data.azurerm_client_config.current.tenant_id
  purge_protection_enabled    = false
  sku_name                    = "standard"
  tags                        = local.resource_tags

  access_policy = [
    local.msi_infra_key_vault_access,
    ]
  lifecycle { ignore_changes = [access_policy] }
}


