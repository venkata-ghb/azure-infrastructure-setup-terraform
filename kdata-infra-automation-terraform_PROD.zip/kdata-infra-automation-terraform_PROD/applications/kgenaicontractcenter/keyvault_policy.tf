# Front end app to have access policy
resource "azurerm_key_vault_access_policy" "kgenaicontractcenter-msi_kgenaicontractcenter_fe" {
  key_vault_id       = azurerm_key_vault.kgenaicontractcenter.id
  tenant_id          = var.TENANT_ID
  object_id          = azurerm_linux_web_app.kgenaicontractcenter_fe.identity[0].principal_id
  secret_permissions = ["Get", ]
}

# Backend app access policy
resource "azurerm_key_vault_access_policy" "kgenaicontractcenter-msi_kgenaicontractcenter" {
  key_vault_id       = azurerm_key_vault.kgenaicontractcenter.id
  tenant_id          = var.TENANT_ID
  object_id          = azurerm_linux_web_app.kgenaicontractcenter_be.identity[0].principal_id
  secret_permissions = ["Get", ]
}

# Platform Admins access policy
resource "azurerm_key_vault_access_policy" "kgenaicontractcenter-group_admins_platform" {
  key_vault_id            = azurerm_key_vault.kgenaicontractcenter.id
  tenant_id               = var.TENANT_ID
  object_id               = data.terraform_remote_state.ad.outputs.group_admins_platform.id
  certificate_permissions = ["Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"]
  key_permissions         = ["Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"]
  secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
  storage_permissions     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"]
}

# OpenAI DEV Admins group access policy
resource "azurerm_key_vault_access_policy" "kgenaicontractcenter-group_admins_openai" {
  key_vault_id            = azurerm_key_vault.kgenaicontractcenter.id
  tenant_id               = var.TENANT_ID
  object_id               = data.terraform_remote_state.ad_dev.outputs.group_admins_openai.id
  certificate_permissions = ["Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"]
  key_permissions         = ["Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"]
  secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
  storage_permissions     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"]
}

# OpenAI DEV Devops group access policy
resource "azurerm_key_vault_access_policy" "kgenaicontractcenter-group_devops_openai" {
  key_vault_id            = azurerm_key_vault.kgenaicontractcenter.id
  tenant_id               = var.TENANT_ID
  object_id               = data.terraform_remote_state.ad_dev.outputs.group_devops_openai.id
  certificate_permissions = ["Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"]
  key_permissions         = ["Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"]
  secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
  storage_permissions     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"]
}

# Logic app GetFilePrinciaplIds to have access policy
resource "azurerm_key_vault_access_policy" "kgenaicontractcenter-msi_get_file_principle_ids" {
  key_vault_id       = azurerm_key_vault.kgenaicontractcenter.id
  tenant_id          = var.TENANT_ID
  object_id          = data.azurerm_logic_app_workflow.get_file_principle_ids.identity[0].principal_id
  secret_permissions = ["Get", ]
}

# Logic app CompVisionGenericCreateFlow to have access policy
resource "azurerm_key_vault_access_policy" "kgenaicontractcenter-msi_generic_create_flow" {
  key_vault_id       = azurerm_key_vault.kgenaicontractcenter.id
  tenant_id          = var.TENANT_ID
  object_id          = data.azurerm_logic_app_workflow.generic_create_flow.identity[0].principal_id
  secret_permissions = ["Get", ]
}

# Logic app CompVisionGenericDeleteFlow to have access policy
resource "azurerm_key_vault_access_policy" "kgenaicontractcenter-msi_generic_delete_flow" {
  key_vault_id       = azurerm_key_vault.kgenaicontractcenter.id
  tenant_id          = var.TENANT_ID
  object_id          = data.azurerm_logic_app_workflow.generic_delete_flow.identity[0].principal_id
  secret_permissions = ["Get", ]
}

# Logic app CompVisionGenericUpdateFlow to have access policy
resource "azurerm_key_vault_access_policy" "kgenaicontractcenter-msi_generic_update_flow" {
  key_vault_id       = azurerm_key_vault.kgenaicontractcenter.id
  tenant_id          = var.TENANT_ID
  object_id          = data.azurerm_logic_app_workflow.generic_update_flow.identity[0].principal_id
  secret_permissions = ["Get", ]
}

# Devops service principal access 
resource "azurerm_key_vault_access_policy" "kgenaicontractcenter-sp_platform_devops" {
  key_vault_id       = azurerm_key_vault.kgenaicontractcenter.id
  tenant_id          = var.TENANT_ID
  object_id          = data.terraform_remote_state.ad.outputs.sp_platform_devops.id
  secret_permissions = ["Get", ]
}
