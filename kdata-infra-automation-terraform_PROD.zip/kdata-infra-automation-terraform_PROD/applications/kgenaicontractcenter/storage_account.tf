# KGENAIcontractcenter STORAGE ACCOUNT FOR FUNCTION APP
resource "azurerm_storage_account" "kgenaicontractcenter" {
  name                     = "${local.prefix_sa}kgenaicc" // length must be between 3 and 24 characters long
  resource_group_name      = azurerm_resource_group.kgenaicontractcenter.name
  location                 = local.location.long
  account_tier             = "Standard"
  account_replication_type = "LRS"
  tags                     = local.resource_tags

  network_rules {
    bypass = [
      "AzureServices"
    ]
    default_action = "Allow"
    ip_rules = [
      "157.144.241.0/24", # Kesko Internal
      "157.144.201.0/24", # Kesko Internal    
      "131.207.242.5",    # Tieto network 
      "131.207.242.128",  # Tieto GlobalProtect fixed IP
      "52.137.57.167",    # CITRIX Fixed IP1 
      "40.119.145.170",   # CITRIX Fixed IP2
    ]
    
  }

}

data "azurerm_storage_account_sas" "kgenaicontractcenter-sas" {
  connection_string = azurerm_storage_account.kgenaicontractcenter.primary_connection_string
  https_only        = true

  resource_types {
    service   = false
    container = true
    object    = true
  }

  services {
    blob  = true
    queue = false
    table = false
    file  = false
  }

  start  = "2024-01-01"
  expiry = "2029-01-01"

  permissions {
    read    = true
    write   = true
    delete  = false
    list    = true
    add     = false
    create  = true
    update  = true
    process = false
    tag     = false
    filter  = false
  }
}

resource "azurerm_storage_container" "raw" {
  name                  = "raw"
  storage_account_name  = azurerm_storage_account.kgenaicontractcenter.name
  container_access_type = "private"
}