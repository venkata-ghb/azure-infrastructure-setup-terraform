resource "azurerm_cosmosdb_sql_database" "main-kgenaicontractcenter" {
  name                = "kgenaicontractcenter"
  resource_group_name = data.terraform_remote_state.integrations.outputs.main_cosmosdb.resource_group_name
  account_name        = data.terraform_remote_state.integrations.outputs.main_cosmosdb.name
}

resource "azurerm_cosmosdb_sql_container" "cc_contracts" {
   name                = "cc-contracts"
   resource_group_name = data.terraform_remote_state.integrations.outputs.main_cosmosdb.resource_group_name
   account_name        = data.terraform_remote_state.integrations.outputs.main_cosmosdb.name
   database_name       = azurerm_cosmosdb_sql_database.main-kgenaicontractcenter.name
   partition_key_paths  = ["/contract_id"]
}

resource "azurerm_cosmosdb_sql_container" "cc_contracts_metadata" {
   name                = "cc-contracts-metadata"
   resource_group_name = data.terraform_remote_state.integrations.outputs.main_cosmosdb.resource_group_name
   account_name        = data.terraform_remote_state.integrations.outputs.main_cosmosdb.name
   database_name       = azurerm_cosmosdb_sql_database.main-kgenaicontractcenter.name
   partition_key_paths  = ["/knro"]
}

# v2 configurations 
resource "azurerm_cosmosdb_sql_container" "cc_contracts_v2" {
   name                = "cc-contracts-v2"
   resource_group_name = data.terraform_remote_state.integrations.outputs.main_cosmosdb.resource_group_name
   account_name        = data.terraform_remote_state.integrations.outputs.main_cosmosdb.name
   database_name       = azurerm_cosmosdb_sql_database.main-kgenaicontractcenter.name
   partition_key_paths  = ["/document_key"]
}

resource "azurerm_cosmosdb_sql_container" "cc_contracts_metadata_v2" {
   name                = "cc-contracts-metadata-v2"
   resource_group_name = data.terraform_remote_state.integrations.outputs.main_cosmosdb.resource_group_name
   account_name        = data.terraform_remote_state.integrations.outputs.main_cosmosdb.name
   database_name       = azurerm_cosmosdb_sql_database.main-kgenaicontractcenter.name
   partition_key_paths  = ["/document_key"]
}
