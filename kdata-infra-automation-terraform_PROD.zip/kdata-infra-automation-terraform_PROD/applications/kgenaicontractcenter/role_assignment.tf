# Assign Storage Blob Data Contributor role to the Managed Identity of the Web App
resource "azurerm_role_assignment" "sa_kgenaicontractcenter-blob_data_contributor-kgenaicontractcenter_webapp" {
  principal_id         = azurerm_linux_web_app.kgenaicontractcenter_be.identity.0.principal_id
  role_definition_name = "Storage Blob Data Contributor"
  scope                = azurerm_storage_account.kgenaicontractcenter.id
}

# OpenAI Admins group access to blob storage
resource "azurerm_role_assignment" "sa_kgenaicontractcenter-blob_data_contributor-group_admins_openai" {
  principal_id         = data.terraform_remote_state.ad_dev.outputs.group_admins_openai.id
  role_definition_name = "Storage Blob Data Contributor"
  scope                = azurerm_storage_account.kgenaicontractcenter.id
}

# OpenAI Devops group access to blob storage
resource "azurerm_role_assignment" "sa_kgenaicontractcenter-blob_data_contributor-group_devops_openai" {
  principal_id         = data.terraform_remote_state.ad_dev.outputs.group_devops_openai.id
  role_definition_name = "Storage Blob Data Contributor"
  scope                = azurerm_storage_account.kgenaicontractcenter.id
}


# Cosmos DB role for backend app
resource "azurerm_cosmosdb_sql_role_assignment" "cosmosdb_main_kgenaicontractcenter_db-write-kgenaicontractcenter_be" {
  resource_group_name = data.terraform_remote_state.integrations.outputs.main_cosmosdb.resource_group_name
  account_name        = data.terraform_remote_state.integrations.outputs.main_cosmosdb.name
  role_definition_id  = data.terraform_remote_state.integrations.outputs.cosmosdb_role_main_writer.id
  principal_id        = azurerm_linux_web_app.kgenaicontractcenter_be.identity[0].principal_id
  scope               = data.terraform_remote_state.integrations.outputs.main_cosmosdb_id
}

resource "azurerm_cosmosdb_sql_role_assignment" "cosmosdb_main_kgenaicontractcenter_db-data-contributor-kgenaicontractcenter_be" {
  resource_group_name = data.terraform_remote_state.integrations.outputs.main_cosmosdb.resource_group_name
  account_name        = data.terraform_remote_state.integrations.outputs.main_cosmosdb.name
  role_definition_id  = data.terraform_remote_state.integrations.outputs.cosmosdb_main_data_contributor.id
  principal_id        = azurerm_linux_web_app.kgenaicontractcenter_be.identity[0].principal_id
  scope               = data.terraform_remote_state.integrations.outputs.main_cosmosdb_id
}

# Role assignment for AI Search for auto indexer. Todo: ensure to use remote reference
resource "azurerm_cosmosdb_sql_role_assignment" "cosmosdb_main_kgenaicontractcenter_db-data-contributor-main_ai_search" {
  resource_group_name = data.terraform_remote_state.integrations.outputs.main_cosmosdb.resource_group_name
  account_name        = data.terraform_remote_state.integrations.outputs.main_cosmosdb.name
  role_definition_id  = data.terraform_remote_state.integrations.outputs.cosmosdb_main_data_contributor.id
  principal_id        = data.terraform_remote_state.azureai.outputs.search_service_main_sc.object_id
  scope               = data.terraform_remote_state.integrations.outputs.main_cosmosdb_id
}
