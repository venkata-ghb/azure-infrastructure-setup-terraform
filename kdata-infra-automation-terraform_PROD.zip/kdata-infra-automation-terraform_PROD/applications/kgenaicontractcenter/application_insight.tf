resource "azurerm_application_insights" "kgenaicontractcenter" {
  name                = "${local.prefix}-${local.location.short}-kgenaicontractcenter-app"
  resource_group_name = azurerm_resource_group.kgenaicontractcenter.name
  location            = local.location.long
  application_type    = "web"
  retention_in_days   = 90
  sampling_percentage = 0
  tags                = local.resource_tags

  lifecycle {
    ignore_changes = [ workspace_id ]
  }
}
