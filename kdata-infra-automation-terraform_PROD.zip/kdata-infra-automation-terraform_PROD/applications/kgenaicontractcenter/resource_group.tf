resource "azurerm_resource_group" "kgenaicontractcenter" {
  name     = "${local.prefix_rg}_KGENAICONTRACTCENTER_RG"
  location = local.location.long
  tags     = local.resource_tags
}