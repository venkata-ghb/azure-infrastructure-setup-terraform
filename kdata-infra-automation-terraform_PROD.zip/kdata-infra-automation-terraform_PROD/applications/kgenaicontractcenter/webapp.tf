# Web App :  Contract Center
# Backend
# 
resource "azurerm_linux_web_app" "kgenaicontractcenter_be" {
  name                = "${local.prefix}-${local.location.short}-kgenaicontractcenter-be-app"
  resource_group_name = azurerm_resource_group.kgenaicontractcenter.name
  location            = local.location.long
  service_plan_id               = replace(data.terraform_remote_state.azureai.outputs.service_plan_kgenai_001.id, "serverfarms", "serverFarms")
  https_only                    = true
  public_network_access_enabled = false

  identity {
    type = "SystemAssigned"
  }
  tags = local.resource_tags
  app_settings = {
    #"WEBSITE_CONTENTOVERVNET"                         = "1"
  }

  site_config {
    ftps_state       = "FtpsOnly"
    app_command_line = "bash startup.sh"
    application_stack {
      python_version = "3.12"
    }
    cors {
      allowed_origins     = ["*"]
      support_credentials = false
    }
  }
lifecycle { ignore_changes = [app_settings, logs, site_config, sticky_settings, tags]}
}

# Front End app on App service (Next JS used server side rendering)
resource "azurerm_linux_web_app" "kgenaicontractcenter_fe" {
  name                          = "${local.prefix}-${local.location.short}-kgenaicontractcenter-fe-app"
  resource_group_name           = azurerm_resource_group.kgenaicontractcenter.name
  location                      = local.location.long
  service_plan_id               = replace(data.terraform_remote_state.azureai.outputs.service_plan_kgenai_001.id, "serverfarms", "serverFarms")
  https_only                    = true
  public_network_access_enabled = true

  identity {
    type = "SystemAssigned"
  }
  tags = local.resource_tags
  app_settings = {
    API_BASE_URL             = "https://k-api.kesko.fi/gt-contractcenter-genai-api"
    AZURE_AD_CLIENT_ID       = data.terraform_remote_state.ad.outputs.sp_kgenaicontractcenter.application_id
    AZURE_AD_CLIENT_SECRET   = data.terraform_remote_state.ad.outputs.sp_kgenaicontractcenter_password
    AZURE_AD_TENANT_ID       = var.TENANT_ID
    NEXTAUTH_SECRET          = "@Microsoft.KeyVault(SecretUri=${azurerm_key_vault_secret.kgenaicontractcenter-nextjs_auth_hash.id})"
    NEXTAUTH_URL             = "https://${local.prefix}-${local.location.short}-kgenaicontractcenter-fe-app.azurewebsites.net/"
    NEXTAUTH_URL_INTERNAL    = "https://${local.prefix}-${local.location.short}-kgenaicontractcenter-fe-app.azurewebsites.net/"
    NEXT_PUBLIC_API_BASE_URL = "https://k-api.kesko.fi/gt-contractcenter-genai-api"
    NODE_ENV                 = "production"
  }

  site_config {
    ftps_state       = "FtpsOnly"
    app_command_line = "npm run start"
    application_stack {
      node_version = "24-lts"
    }
  }
  lifecycle { ignore_changes = [app_settings,]}
}