# Create a PostgreSQL Database for Contract Center
resource "azurerm_postgresql_flexible_server_database" "main-kgenaicontractcenter" {
  name                      = "kgenaicontractcenter"
  server_id                 = data.terraform_remote_state.integrations.outputs.postgresql_main.id
  charset                   = "utf8"
  collation                 = "en_US.utf8"
}

# Create a PostgreSQL Database for Contract Center v2
resource "azurerm_postgresql_flexible_server_database" "main-kgenaicontractcenter_v2" {
  name                      = "kgenaicontractcenter_v2"
  server_id                 = data.terraform_remote_state.integrations.outputs.postgresql_main.id
  charset                   = "utf8"
  collation                 = "en_US.utf8"
}