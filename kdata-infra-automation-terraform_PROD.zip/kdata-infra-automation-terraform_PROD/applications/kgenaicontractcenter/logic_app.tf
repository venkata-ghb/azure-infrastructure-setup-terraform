# These logic apps are manually created by Tieto Dev Team

data "azurerm_logic_app_workflow" "get_file_principle_ids" {
  name                = "GetFilePrincipleIds_PROD"
  resource_group_name = azurerm_resource_group.kgenaicontractcenter.name
}

data "azurerm_logic_app_workflow" "generic_create_flow" {
  name                = "KGenAICompVisionGenericCreateFlow_PROD"
  resource_group_name = azurerm_resource_group.kgenaicontractcenter.name
}

data "azurerm_logic_app_workflow" "generic_delete_flow" {
  name                = "KGenAICompVisionGenericDeleteFlow_PROD"
  resource_group_name = azurerm_resource_group.kgenaicontractcenter.name
}

data "azurerm_logic_app_workflow" "generic_update_flow" {
  name                = "KGenAICompVisionGenericUpdateFlow_PROD"
  resource_group_name = azurerm_resource_group.kgenaicontractcenter.name  
}

