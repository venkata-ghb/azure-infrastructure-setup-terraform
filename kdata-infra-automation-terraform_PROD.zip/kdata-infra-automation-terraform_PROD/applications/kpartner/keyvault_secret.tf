resource "azurerm_key_vault_secret" "kpartner-sp_kpartner_dynamics_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_kpartner_dynamics.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_kpartner_dynamics_password
  key_vault_id = azurerm_key_vault.kpartner.id
  content_type = "${data.terraform_remote_state.ad.outputs.sp_kpartner_dynamics.display_name} SP's Password by Terraform"
  tags         = local.resource_tags
}
