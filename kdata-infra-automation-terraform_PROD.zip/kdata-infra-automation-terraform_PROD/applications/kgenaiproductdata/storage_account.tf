# resource "azurerm_storage_account" "kgenaiproductdata" {
#   name                     = "${local.prefix_sa}kgenaipd" # Keeping it same as test env
#   resource_group_name      = azurerm_resource_group.kgenaiproductdata.name
#   location                 = local.location.long
#   account_tier             = "Standard"
#   account_replication_type = "ZRS"
#   tags                     = local.resource_tags

#   network_rules {
#     bypass = [
#       "AzureServices"
#     ]
#     default_action = "Allow"
#     ip_rules = [
#       "157.144.241.0/24", # Kesko Internal
#       "157.144.201.0/24", # Kesko Internal    
#       "131.207.242.5",    # Tieto network 
#       "131.207.242.128",  # Tieto GlobalProtect fixed IP
#       "52.137.57.167",    # CITRIX Fixed IP1 
#       "40.119.145.170",   # CITRIX Fixed IP2
#     ]

#   }
# }


# data "azurerm_storage_account_sas" "kgenaiproductdata-sas" {
#   connection_string = azurerm_storage_account.kgenaiproductdata.primary_connection_string
#   https_only        = true

#   resource_types {
#     service   = false
#     container = true
#     object    = true
#   }

#   services {
#     blob  = true
#     queue = false
#     table = false
#     file  = false
#   }

#   start  = "2024-01-01"
#   expiry = "2029-01-01"

#   permissions {
#     read    = true
#     write   = true
#     delete  = false
#     list    = true
#     add     = false
#     create  = true
#     update  = true
#     process = false
#     tag     = false
#     filter  = false
#   }
# }

# resource "azurerm_key_vault_secret" "kgenaiproductdata-sas_key" {
#   key_vault_id = azurerm_key_vault.kgenaiproductdata.id
#   name         = "kgenaiproductdata-sas"
#   value        = data.azurerm_storage_account_sas.kgenaiproductdata-sas.sas
#   content_type = "Storage Account kgenaiproductdata SAS token"

#   tags = local.resource_tags
# }

# resource "azurerm_storage_container" "raw" {
#   name                  = "raw"
#   storage_account_name  = azurerm_storage_account.kgenaiproductdata.name
#   container_access_type = "private"
# }
