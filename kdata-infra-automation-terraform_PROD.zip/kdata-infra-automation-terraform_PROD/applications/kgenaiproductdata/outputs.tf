output "kgenaiproductdata_be" {
  value = {
    object_id         = azurerm_linux_web_app.kgenaiproductdata_be.identity[0].principal_id
  }
}
