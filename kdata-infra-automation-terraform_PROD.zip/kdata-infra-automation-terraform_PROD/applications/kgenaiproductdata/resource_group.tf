resource "azurerm_resource_group" "kgenaiproductdata" {
  name     = "${local.prefix_rg}_KGENAIPRODUCTDATA_RG"
  location = local.location.long
  tags     = local.resource_tags
}