# # Assign Storage Blob Data Contributor role to the Managed Identity of the Web App
# resource "azurerm_role_assignment" "sa_kgenaiproductdata-contributor-kgenaiproductdata_webapp" {
#   principal_id         = azurerm_linux_web_app.kgenaiproductdata_be.identity.0.principal_id
#   role_definition_name = "Contributor"
#   scope                = azurerm_storage_account.kgenaiproductdata.id
# }

# resource "azurerm_role_assignment" "postgresql_main_kgenaiproductdata_db-contributor-kgenaiproductdata_webapp" {
#   principal_id         = azurerm_linux_web_app.kgenaiproductdata_be.identity[0].principal_id
#   scope                = azurerm_postgresql_flexible_server_database.main-kgenaiproductdata.id
#   role_definition_name = "Contributor"
# }

# resource "azurerm_cosmosdb_sql_role_assignment" "cosmosdb_main_kgenaiproductdata_db-write-kgenaiproductdata_webapp" {
#   resource_group_name = data.terraform_remote_state.integrations.outputs.main_cosmosdb.resource_group_name
#   account_name        = data.terraform_remote_state.integrations.outputs.main_cosmosdb.name
#   role_definition_id  = data.terraform_remote_state.integrations.outputs.cosmosdb_role_main_writer.id
#   principal_id        = azurerm_linux_web_app.kgenaiproductdata_be.identity[0].principal_id
#   scope               = data.terraform_remote_state.integrations.outputs.main_cosmosdb_id
# }

# resource "azurerm_role_assignment" "sa_kgenaiproductdata-contributor-kgenaiproductdata_functionapp" {
#   principal_id         = azurerm_linux_function_app.kgenaiproductdata.identity.0.principal_id
#   role_definition_name = "Storage Blob Data Contributor"
#   scope                = azurerm_storage_account.kgenaiproductdata.id
# }

# resource "azurerm_role_assignment" "sa_kgenaiproductdata-contributor-group_admins_platform" {
#   principal_id         = data.terraform_remote_state.ad.outputs.group_admins_platform.id
#   role_definition_name = "Contributor"
#   scope                = azurerm_storage_account.kgenaiproductdata.id
# }

# resource "azurerm_role_assignment" "sa_kgenaiproductdata-storage_blob_contributor-group_admins_platform" {
#   principal_id         = data.terraform_remote_state.ad.outputs.group_admins_platform.id
#   role_definition_name = "Storage Blob Data Contributor"
#   scope                = azurerm_storage_account.kgenaiproductdata.id
# }

# resource "azurerm_cosmosdb_sql_role_assignment" "cosmosdb_main_kgenaiproductdata_db-write-kgenaiproductdata_functionapp" {
#   resource_group_name = data.terraform_remote_state.integrations.outputs.main_cosmosdb.resource_group_name
#   account_name        = data.terraform_remote_state.integrations.outputs.main_cosmosdb.name
#   role_definition_id  = data.terraform_remote_state.integrations.outputs.cosmosdb_role_main_writer.id
#   principal_id        = azurerm_linux_function_app.kgenaiproductdata.identity[0].principal_id
#   scope               = data.terraform_remote_state.integrations.outputs.main_cosmosdb_id
# }

# resource "azurerm_cosmosdb_sql_role_assignment" "cosmosdb_main_kgenaiproductdata_db-data-contributor-kgenaiproductdata_functionapp" {
#   resource_group_name = data.terraform_remote_state.integrations.outputs.main_cosmosdb.resource_group_name
#   account_name        = data.terraform_remote_state.integrations.outputs.main_cosmosdb.name
#   role_definition_id  = data.terraform_remote_state.integrations.outputs.cosmosdb_main_data_contributor.id
#   principal_id        = azurerm_linux_function_app.kgenaiproductdata.identity[0].principal_id
#   scope               = data.terraform_remote_state.integrations.outputs.main_cosmosdb_id
# }

# resource "azurerm_cosmosdb_sql_role_assignment" "cosmosdb_main_kgenaiproductdata_db-data-contributor-group_admins_platform" {
#   resource_group_name = data.terraform_remote_state.integrations.outputs.main_cosmosdb.resource_group_name
#   account_name        = data.terraform_remote_state.integrations.outputs.main_cosmosdb.name
#   role_definition_id  = data.terraform_remote_state.integrations.outputs.cosmosdb_main_data_contributor.id
#   principal_id        = data.terraform_remote_state.ad.outputs.group_admins_platform.id
#   scope               = data.terraform_remote_state.integrations.outputs.main_cosmosdb_id
# }

# # Access to OpenAI Admin developer group
# resource "azurerm_cosmosdb_sql_role_assignment" "cosmosdb_main_kgenaiproductdata_db-data-contributor-group_admins_openai" {
#   resource_group_name = data.terraform_remote_state.integrations.outputs.main_cosmosdb.resource_group_name
#   account_name        = data.terraform_remote_state.integrations.outputs.main_cosmosdb.name
#   role_definition_id  = data.terraform_remote_state.integrations.outputs.cosmosdb_main_data_contributor.id
#   principal_id        = data.terraform_remote_state.ad_dev.outputs.group_admins_openai.id
#   scope               = data.terraform_remote_state.integrations.outputs.main_cosmosdb_id
# }