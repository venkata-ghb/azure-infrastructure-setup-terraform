# Web App : Product Data
# Backend
resource "azurerm_linux_web_app" "kgenaiproductdata_be" {
  name                      = "${local.prefix}-${local.location.short}-kgenaiproductdata-be-app"
  resource_group_name       = azurerm_resource_group.kgenaiproductdata.name
  location                  = local.location.long
  service_plan_id           = replace(data.terraform_remote_state.integrations.outputs.service_plan_app_premium.id, "serverfarms", "serverFarms")

  identity {
    type = "SystemAssigned"
  }

  site_config {
    app_command_line = "export deployEnv=prod && pip install -r requirements.txt && python3 app.py"

    application_stack {
      python_version = "3.10"
    }

    cors {
      allowed_origins     = ["*"]
      support_credentials = false
    }

  }

  app_settings = {
    COSMOS_CREDENTIAL = data.terraform_remote_state.integrations.outputs.cosmosdb_main.primary_key
    COSMOS_ENDPOINT   = data.terraform_remote_state.integrations.outputs.cosmosdb_main.endpoint
    deployEnv         = "prod"
    AZURE_OPENAI_ENDPOINT = data.terraform_remote_state.azureai.outputs.openai_sc_api_endpoint
    AZURE_OPENAI_API_KEY  = data.terraform_remote_state.azureai.outputs.openai_sc_api_key
  }

}

# resource "azurerm_static_web_app" "kgenaiproductdata_fe" {
#   name                = "${local.prefix}-${local.location.short}-kgenaiproductdata-fe-app"
#   resource_group_name = azurerm_resource_group.kgenaiproductdata.name
#   location            = local.location.long
#   configuration_file_changes_enabled = true
#   preview_environments_enabled       = true
#   sku_size                           = "Standard"
#   sku_tier                           = "Standard"

#   identity {
#     type = "SystemAssigned"
#   }

#   #env vars are set through CICD
#   app_settings = {
#   }

#   tags = local.resource_tags
# }
