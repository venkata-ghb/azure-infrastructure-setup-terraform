# # Create a PostgreSQL Database for productdata
# resource "azurerm_postgresql_flexible_server_database" "main-kgenaiproductdata" {
#   name                      = "kgenaiproductdata"
#   server_id                 = data.terraform_remote_state.integrations.outputs.postgresql_main.id
#   charset                   = "utf8"
#   collation                 = "en_US.utf8"
# }