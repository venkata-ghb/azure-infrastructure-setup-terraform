# resource "azurerm_cosmosdb_sql_database" "main-kgenaiproductdata" {
#   name                = "kgenaiproductdata"
#   resource_group_name = data.terraform_remote_state.integrations.outputs.main_cosmosdb.resource_group_name
#   account_name        = data.terraform_remote_state.integrations.outputs.main_cosmosdb.name
# }