# # LABVANTAGE FUNCTION APP
# resource "azurerm_linux_function_app" "kgenaiproductdata" {
#   name                        = "${local.prefix}-${local.location.short}-kgenaiproductdata-funcapp"
#   location                    = local.location.long
#   resource_group_name         = azurerm_resource_group.kgenaiproductdata.name
#   service_plan_id             = replace(data.terraform_remote_state.integrations.outputs.service_plan_int_premium.id, "serverfarms", "serverFarms")
#   storage_account_name        = azurerm_storage_account.kgenaiproductdata.name
#   storage_account_access_key  = azurerm_storage_account.kgenaiproductdata.primary_access_key
#   https_only                  = true
#   functions_extension_version = "~4"

#   identity {
#     type = "SystemAssigned"
#   }

#   site_config {
#     ftps_state               = "Disabled"
#     application_insights_key = azurerm_application_insights.kgenaiproductdata.instrumentation_key

#     application_stack {
#       python_version = "3.9"
#     }
#   }

#   app_settings = {
#     WEBSITE_ENABLE_SYNC_UPDATE_SITE       = false
#     "AzureWebJobs.http_trigger.Disabled"  = 1
#   }

#   tags = local.resource_tags

#   lifecycle {
#     ignore_changes = [
#       app_settings["WEBSITE_ENABLE_SYNC_UPDATE_SITE"],
#       app_settings["WEBSITE_RUN_FROM_PACKAGE"],
#     ]
#   }
# }

# #LABVANTAGE APPLICATION INSIGHTS
# resource "azurerm_application_insights" "kgenaiproductdata" {
#   name                = "${local.prefix}-${local.location.short}-kgenaiproductdata-funcapp"
#   location            = local.location.long
#   resource_group_name = azurerm_resource_group.kgenaiproductdata.name
#   application_type    = "web"
#   retention_in_days   = 90
#   sampling_percentage = 0
#   tags                = local.resource_tags

#   lifecycle {
#     ignore_changes = [ workspace_id ]
#   }
# }
