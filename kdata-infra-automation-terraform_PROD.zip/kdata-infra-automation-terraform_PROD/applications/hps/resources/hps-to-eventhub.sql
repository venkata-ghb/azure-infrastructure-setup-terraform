SELECT
  named_struct( 
    'eventtype', 'salesreceipt',
    'retailtype', 'CT-HPS',
    'timestamp', named_struct(
      'human', date_format(invoice.createdon, 'yyyy-MM-dd HH:mm:ss'),
      'unix', unix_timestamp(date_format(invoice.createdon, 'yyyy-MM-dd HH:mm:ss'))
    )
  ) as meta,
  named_struct(
    'TransactionId', concat('hps', invoice.tiev_customerinvoicenumber),
    'OriginalTransactionId', invoice.tiev_customerinvoicenumber,
    'BusinessUnitId', '9987205',
    'TransactionDate', to_date(invoice.createdon),
    'TransactionTime', date_format(invoice.createdon, 'HH:mm:ss'),
    'BusinessDate', to_date(invoice.createdon),
    'SourceSystemCode', 'hps',
    'RegisterNum', '99',
    'TransactionTypeCode', 1,
    'LoyaltyTokenId',  account.tiev_kplusnumber,
    'TransactionLines', array(named_struct(
      'SequenceNumber', '1',
      'BusinessUnitId', '9987205',
      'GrandAmount', invoice.tiev_customerinvoicetotalamount,
      'Description', 'K-Auto_HPS-veloitus',
      'LoyaltyEligibilityInd', 1,
      'CurrencyCode', 'EUR'
    )),
    'TransactionTenderLines', array(named_struct(
      'SequenceNumber', '1',
      'TenderTypeCode', 7,
      'CurrencyCode', 'EUR',
      'TenderAmount', invoice.tiev_customerinvoicetotalamount
    ))
  ) as data
FROM
  bronze_{env}.huolenpitosopimus.invoice AS invoice
LEFT JOIN
  silver_{env}.huolenpitosopimus.silver_hps_account AS account
  ON invoice.customerid = account.accountid
WHERE
  invoice.tiev_customerinvoicetotalamount != 0
  AND NOT(CONTAINS(TRIM(LOWER(invoice.description)), 'sopimushyvitys'))
;
