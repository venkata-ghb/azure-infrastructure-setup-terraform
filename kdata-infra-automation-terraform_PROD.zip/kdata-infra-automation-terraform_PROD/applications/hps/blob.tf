resource "azurerm_storage_blob" "confmappings-streaming_queries-hps_to_eventhub" {
  name                   = "hps/hps-to-eventhub.sql"
  storage_account_name   = data.terraform_remote_state.integrations.outputs.sa_confmappings.name
  storage_container_name = "streaming-queries"
  type                   = "Block"
  source                 = "${path.module}/resources/hps-to-eventhub.sql"
  content_md5            = filemd5("${path.module}/resources/hps-to-eventhub.sql")
}