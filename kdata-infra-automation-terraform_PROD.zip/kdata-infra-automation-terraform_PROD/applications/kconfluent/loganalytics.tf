resource "azurerm_log_analytics_workspace" "kconfluent-loganalytics" {
  name                = "kdata-${var.env}-kconfluent-loganalytics"
  location            = var.location
  resource_group_name = var.rg_name
  sku                 = "PerGB2018"
  retention_in_days   = 30
  tags                = local.resource_tags
}

