resource "azurerm_storage_account" "kconfluent-logicapp" {
  name                     = "kdata${var.env}kconfluent"
  resource_group_name      = var.rg_name
  location                 = var.location
  account_tier             = "Standard"
  account_replication_type = "LRS"
  tags                     = local.resource_tags
}

resource "azurerm_app_service_plan" "kconfluent-logicapp" {
  name                = "kdata-${var.env}-kconfluent-logicapp-service-plan"
  location            = var.location
  resource_group_name = var.rg_name
  kind                = "elastic"
  tags                = local.resource_tags

  sku {
    tier = "WorkflowStandard"  #ElasticPremium #WorkflowStandard
    size = "WS1"               #EP1 #WS1
  }
}

resource "azurerm_application_insights" "kconfluent_logic_app_insights" {
  name                = "kdata-${var.env}-kconfluent-logicapp"
  location            = var.location
  resource_group_name = var.rg_name
  workspace_id        = azurerm_log_analytics_workspace.kconfluent-loganalytics.id
  application_type    = "web"
  tags                = local.resource_tags
}

resource "azurerm_logic_app_standard" "kconfluent-logicapp" {
  name                       = "kdata-${var.env}-kconfluent-logicapp"
  location                   = var.location
  resource_group_name        = var.rg_name
  app_service_plan_id        = azurerm_app_service_plan.kconfluent-logicapp.id
  storage_account_name       = azurerm_storage_account.kconfluent-logicapp.name
  storage_account_access_key = azurerm_storage_account.kconfluent-logicapp.primary_access_key
  version                    = "4.14.0.19631"

  identity {
    type = "SystemAssigned"
  }
  app_settings = {
    "APPINSIGHTS_INSTRUMENTATIONKEY"        = azurerm_application_insights.kconfluent_logic_app_insights.instrumentation_key
    "APPLICATIONINSIGHTS_CONNECTION_STRING" = azurerm_application_insights.kconfluent_logic_app_insights.connection_string
    "FUNCTIONS_WORKER_RUNTIME"              = "dotnet"
    "WEBSITE_NODE_DEFAULT_VERSION"          = "~14"
  }

  tags = local.resource_tags
}
