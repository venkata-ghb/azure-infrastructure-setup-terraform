resource "random_password" "confluent_replicator_vm_admin_password" {
  length           = 32
  override_special = "_-=()<>:"
}

resource "azurerm_key_vault_secret" "confluent_replicator_username" {
  name         = "confluent-replicator-vm-admin-username"
  value        = "confluent-replicator-vm-user"
  key_vault_id = azurerm_key_vault.kconfluent.id
}

resource "azurerm_key_vault_secret" "confluent_replicator_password" {
  name         = "confluent-replicator-vm-admin-password"
  value        = random_password.confluent_replicator_vm_admin_password.result
  key_vault_id = azurerm_key_vault.kconfluent.id
}

resource "azurerm_linux_virtual_machine" "confluent_replicator" {
  name                            = "${var.prefix}-confluent-replicator"
  location                        = var.location
  resource_group_name             = azurerm_resource_group.kconfluent_main.name
  network_interface_ids           = [azurerm_network_interface.confluent_replicator_01.id]
  size                            = "Standard_D4s_v5"
  admin_username                  = azurerm_key_vault_secret.confluent_replicator_username.value
  admin_password                  = azurerm_key_vault_secret.confluent_replicator_password.value
  disable_password_authentication = false

  source_image_reference {
    publisher = "canonical"
    offer     = "0001-com-ubuntu-server-focal"
    sku       = "20_04-lts-gen2"
    version   = "latest"
  }

  os_disk {
    name                 = "${var.prefix}-confluent-replicator-vm-os-disk"
    caching              = "ReadWrite"
    storage_account_type = "Standard_LRS"
    disk_size_gb         = 150
  }

  tags = local.resource_tags
}
