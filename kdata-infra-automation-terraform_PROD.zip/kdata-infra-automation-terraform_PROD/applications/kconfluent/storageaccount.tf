resource "azurerm_storage_account" "kconfluenttf" {
  name                     = "${var.prefix_sa}kconfluenttf"
  resource_group_name      = azurerm_resource_group.kconfluent_tf.name
  location                 = var.location
  account_tier             = "Standard"
  account_replication_type = "LRS"
  tags                     = local.resource_tags
}

resource "azurerm_storage_container" "kconfluenttf-tfstate" {
  name                 = "tfstate"
  storage_account_name = azurerm_storage_account.kconfluenttf.name
}

data "azurerm_storage_account_sas" "kconfluenttf-sas" {
  connection_string = azurerm_storage_account.kconfluenttf.primary_connection_string
  https_only        = true

  resource_types {
    service   = false
    container = true
    object    = true
  }

  services {
    blob  = true
    queue = false
    table = false
    file  = false
  }

  start  = "2022-01-01"
  expiry = "2027-01-01"

  permissions {
    read    = true
    write   = true
    delete  = false
    list    = true
    add     = false
    create  = true
    update  = true
    process = false
    tag     = false
    filter  = false
  }
}

resource "azurerm_key_vault_secret" "kconfluenttf-sas_key" {
  key_vault_id = azurerm_key_vault.kconfluent.id
  name         = "kconfluenttf-sas"
  value        = data.azurerm_storage_account_sas.kconfluenttf-sas.sas
  content_type = "Storage Account kconfluentadls SAS token"

  tags = local.resource_tags
}