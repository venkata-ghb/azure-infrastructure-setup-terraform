resource "azurerm_role_assignment" "rg_kconfluent_main-contributor-sp_kconfluent_devops" {
  scope                = azurerm_resource_group.kconfluent_main.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.sp_kconfluent_devops.id
}

resource "azurerm_role_assignment" "rg_kconfluent_main-reader-group_devops_platform" {
  scope                = azurerm_resource_group.kconfluent_main.id
  role_definition_name = "Reader"
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
}

resource "azurerm_role_assignment" "rg_kconfluent_main-contributor-sp_platform_devops" {
  scope                = azurerm_resource_group.kconfluent_main.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.sp_platform_devops.id
}

resource "azurerm_role_assignment" "rg_kconfluent_main-contributor-group_admins_platform" {
  scope                = azurerm_resource_group.kconfluent_main.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.group_admins_platform.id
}

resource "azurerm_role_assignment" "rg_kconfluent_main-contributor-group_admins_confluent" {
  scope                = azurerm_resource_group.kconfluent_main.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.group_confluent_prod_admin.id
}

# ---------------------------------------------------------------------------------------------

resource "azurerm_role_assignment" "rg_kconfluent_tf-contributor-group_admins_platform" {
  scope                = azurerm_resource_group.kconfluent_tf.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.group_admins_platform.id
}

resource "azurerm_role_assignment" "rg_kconfluent_tf-reader-group_devops_platform" {
  scope                = azurerm_resource_group.kconfluent_tf.id
  role_definition_name = "Reader"
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
}

# ---------------------------------------------------------------------------------------------

resource "azurerm_role_assignment" "rg_kconfluent_cloud-contributor-group_admins_platform" {
  scope                = azurerm_resource_group.kconfluent_cloud.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.group_admins_platform.id
}

resource "azurerm_role_assignment" "rg_kconfluent_cloud-reader-group_devops_platform" {
  scope                = azurerm_resource_group.kconfluent_cloud.id
  role_definition_name = "Reader"
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
}

resource "azurerm_role_assignment" "rg_kconfluent_cloud-contributor-user_jaakko_virtanen" {
  scope                = azurerm_resource_group.kconfluent_cloud.id
  role_definition_name = "Contributor"
  principal_id         = "2c2f85ba-a54f-4e21-afaf-37cbe11e6aea" # jaakko.virtanen@kesko.fi
}
