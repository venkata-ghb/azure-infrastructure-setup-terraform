resource "azurerm_network_security_group" "confluent_replicator" {
  name                = "confluent-replicator-nic-nsg"
  location            = var.location
  resource_group_name = azurerm_resource_group.kconfluent_main.name
  tags                = local.resource_tags

  security_rule {
    name                       = "AllowSSHInbound"
    description                = "Allow SSH connections for confluent replicator machine"
    priority                   = 401
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_address_prefix      = ""
    source_address_prefixes    = var.ssh_allowed_address_list
    source_port_range          = "*"
    destination_address_prefix = "*"
    destination_port_range     = "22"
  }

  security_rule {
    name                       = "AllowRDPInbound"
    description                = "Allow RDP connections for confluent replicator machine"
    priority                   = 400
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_address_prefix      = ""
    source_address_prefixes    = var.rdp_allowed_address_list
    source_port_range          = "*"
    destination_address_prefix = "*"
    destination_port_range     = "3389"
  }
}

resource "azurerm_network_interface_security_group_association" "confluent_replicator-confluent_replicator_01" {
  network_interface_id      = azurerm_network_interface.confluent_replicator_01.id
  network_security_group_id = azurerm_network_security_group.confluent_replicator.id
}
