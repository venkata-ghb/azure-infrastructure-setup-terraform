locals {
  location      = data.terraform_remote_state.common.outputs.location
  prefix_rg     = data.terraform_remote_state.common.outputs.prefix_rg
  resource_tags = merge(data.terraform_remote_state.common.outputs.resource_tags, {
    SubApplication  = "KCONFLUENT"
  })
}
