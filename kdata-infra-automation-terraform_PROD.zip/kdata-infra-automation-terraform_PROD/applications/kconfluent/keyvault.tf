data "azurerm_client_config" "current" {}

locals {
  msi_kv_access_policy = {
    object_id               = data.terraform_remote_state.tfinfra.outputs.msi.principal_id
    tenant_id               = data.azurerm_client_config.current.tenant_id
    application_id          = ""
    certificate_permissions = ["Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"]
    key_permissions         = ["Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"]
    secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
    storage_permissions     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"]
  }
}

resource "azurerm_key_vault" "kconfluent" {
  name                        = "${var.prefix}-kconfluent-kv"
  location                    = var.location
  resource_group_name         = azurerm_resource_group.kconfluent_main.name
  enabled_for_disk_encryption = true
  tenant_id                   = data.azurerm_client_config.current.tenant_id
  purge_protection_enabled    = false
  sku_name                    = "standard"
  tags                        = local.resource_tags

  access_policy = [
    local.msi_kv_access_policy,
    {
      tenant_id               = data.azurerm_client_config.current.tenant_id
      object_id               = data.terraform_remote_state.ad.outputs.sp_kconfluent_devops.id
      application_id          = ""
      certificate_permissions = []
      key_permissions         = []
      secret_permissions = [
        "Get",
        "Set",
        "List",
        "Delete",
        "Recover",
      ]
      storage_permissions = []

    },
    {
      tenant_id               = data.azurerm_client_config.current.tenant_id
      object_id               = data.terraform_remote_state.ad.outputs.group_devops_platform.id
      application_id          = ""
      certificate_permissions = []
      key_permissions         = []
      secret_permissions      = ["Get", "List", ]
      storage_permissions     = []
    },
    {
      tenant_id               = data.azurerm_client_config.current.tenant_id
      object_id               = data.terraform_remote_state.ad.outputs.group_admins_platform.id
      application_id          = ""
      certificate_permissions = ["Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"]
      key_permissions         = ["Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"]
      secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
      storage_permissions     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"]
    },
    {
      tenant_id               = data.azurerm_client_config.current.tenant_id
      object_id               = azurerm_logic_app_standard.kconfluent-logicapp.identity.0.principal_id #"7b64c4be-a261-4d32-a008-fa2534011440"
      application_id          = ""
      certificate_permissions = []
      key_permissions         = []
      secret_permissions = [
        "Get",
      ]
      storage_permissions = []
    }
  ]
}

resource "azurerm_key_vault_secret" "kconfluent-sp_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_kconfluent_devops.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_kconfluent_devops_password
  key_vault_id = azurerm_key_vault.kconfluent.id
  content_type = "${data.terraform_remote_state.ad.outputs.sp_kconfluent_devops.display_name} SP's Password by Terraform"
}

resource "azurerm_key_vault_secret" "kconfluent-externaldatalake_sp_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_kconfluent_externaldatalake.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_kconfluent_externaldatalake_password
  key_vault_id = azurerm_key_vault.kconfluent.id
  content_type = "${data.terraform_remote_state.ad.outputs.sp_kconfluent_externaldatalake.display_name} SP's Password by Terraform"
}
