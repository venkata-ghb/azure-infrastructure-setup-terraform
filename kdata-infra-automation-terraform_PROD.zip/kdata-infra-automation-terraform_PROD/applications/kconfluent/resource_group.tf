resource "azurerm_resource_group" "kconfluent_main" {
  name     = var.rg_name
  location = var.location
  tags     = local.resource_tags
}

resource "azurerm_resource_group" "kconfluent_tf" {
  name     = var.tf_rg_name
  location = var.location
  tags     = local.resource_tags
}
resource "azurerm_resource_group" "kconfluent_cloud" {
  name     = "${local.prefix_rg}_KCONFLUENT_CLOUD_RG"
  location = local.location.long
  tags     = local.resource_tags
}
