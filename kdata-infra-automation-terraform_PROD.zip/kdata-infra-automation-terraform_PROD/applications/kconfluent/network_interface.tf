resource "azurerm_network_interface" "confluent_replicator_01" {
  name                = "${var.prefix}-confluent-replicator-nic-01"
  location            = var.location
  resource_group_name = azurerm_resource_group.kconfluent_main.name
  tags                = local.resource_tags

  ip_configuration {
    name                          = "internal"
    subnet_id                     = data.terraform_remote_state.vnets.outputs.subnet_connectors_001.id
    private_ip_address_allocation = "Dynamic"
  }
}
