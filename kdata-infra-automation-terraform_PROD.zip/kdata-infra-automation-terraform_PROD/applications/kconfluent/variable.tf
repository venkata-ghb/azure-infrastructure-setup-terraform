variable "location" {
  type        = string
  description = "Location"
  default     = "westeurope"
}

variable "loc" {
  type        = string
  description = "Location short"
  default     = "we"
}

variable "env" {
  type        = string
  description = "Environment short"
  default     = "prod"
}

variable "environment" {
  type        = string
  description = "Environment name"
  default     = "Prod"
}

variable "rg_name" {
  type        = string
  description = "Resource Group Name for Kconfluent resources"
  default     = "K-DATA_PROD_WE_Main_KCONFLUENT_RG"
}

variable "tf_rg_name" {
  type        = string
  description = "Resource Group Name for storage account to store state file of Kconfluent."
  default     = "K-DATA_PROD_WE_Main_KCONFLUENT_TF_RG"
}

variable "prefix" {
  type        = string
  description = "Prefix to be applied to all resource names"
  default     = "kdata-prod"
}

variable "prefix_sa" {
  type        = string
  description = "Prefix to be applied to all resource names in storage account"
  default     = "kdataprod"
}

variable "rdp_allowed_address_list" {
  type        = list(string)
  default     = ["157.144.201.0/24", "157.144.241.0/24"]
  description = ""
}

variable "ssh_allowed_address_list" {
  type        = list(string)
  default     = ["157.144.201.0/24", "157.144.241.0/24"]
  description = ""
}

variable "resource_tags" {
  type        = map(string)
  description = "Tags to be applied for all resources"
  default = {
    Application     = "Cloud Data Platform"
    "Business Unit" = "Shared"
    Sub-Service     = "C1231"
    environment     = "Production"
    IT-owner        = "sankalp.ahuja@kesko.fi"
    ManagedResource = "Yes"
    MgmtVendor      = "Tieto"
    created_by      = "Terraform"
    Description     = "Infrastructure for Kesko Data Platform"
    SubApplication  = "KCONFLUENT"
  }
}
