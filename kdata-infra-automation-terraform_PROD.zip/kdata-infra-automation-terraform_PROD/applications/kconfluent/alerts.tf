resource "azurerm_monitor_action_group" "kconfluent-errors-action-group" {
  name                = "${var.prefix}-kconfluent-errors-action-group"
  resource_group_name = var.rg_name
  short_name          = "confluentErr"
  tags                = local.resource_tags

  email_receiver {
    name          = "Ignioauto_UAT"
    email_address = "Ignio_UAT@kesko.fi"
	use_common_alert_schema = true
  }

  email_receiver {
    name          = "Ignioauto_PROD"
    email_address = "Ignio_PROD@kesko.fi"
	use_common_alert_schema = true
  }

  email_receiver {
    name          = "DL_KESKOAMS_TCS_Confluent"
    email_address = "DL_KESKOAMS_TCS_Confluent@kesko.fi"
	use_common_alert_schema = true
  }

}

# Confluent Monitoring Testing Action Group
resource "azurerm_monitor_action_group" "kconfluent-monitoring-testing-action-group" {
  name                = "${var.prefix}-kconfluent-monitoring-testing-action-group"
  resource_group_name = var.rg_name
  short_name          = "confluentTcs"
  tags                = local.resource_tags

  email_receiver {
    name          = "DL_KESKOAMS_TCS_Confluent"
    email_address = "DL_KESKOAMS_TCS_Confluent@kesko.fi"
	use_common_alert_schema = true
  }
}

##########  Confluent silent monitoring alert ##########
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_silent_monitoring_alert" {
  name                = "kdata-${lower(var.env)}-silent-monitoring-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT15M"
  window_duration      = "PT15M"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      receiptsoffsettable_CL
        | order by TimeGenerated asc
        | extend Increased = LATEST_OFFSET_d > prev(LATEST_OFFSET_d), cnt = LATEST_OFFSET_d - prev(LATEST_OFFSET_d)
        | where TimeGenerated > ago(15m) and APP_NAME_s == "POS-GT-RECEIPTS"
        | summarize DataNotArrived = iff(hourofday(now()) between (07 .. 18), iff(countif(Increased == true) == 0, 3, iff(sum(cnt) <= 7000,3, 2)),2)
      QUERY
    time_aggregation_method = "Total"
    threshold               = 2
    operator                = "GreaterThan"
    metric_measure_column   = "DataNotArrived"
  }
  enabled                          = true
  query_time_range_override        = "P2D"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_silent_monitoring_alert_30Min" {
  name                = "kdata-${lower(var.env)}-silent-monitoring-alert-30Minutes"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      receiptsoffsettable_CL
        | order by TimeGenerated asc
        | extend Increased = LATEST_OFFSET_d > prev(LATEST_OFFSET_d)
        | where TimeGenerated > ago(30m) and APP_NAME_s == "POS-GT-RECEIPTS"
        | summarize DataNotArrived = iff(countif(Increased == true) == 0, iff(hourofday(now()) between (19 .. 22), 2, 1),1)
      QUERY
    time_aggregation_method = "Total"
    threshold               = 1
    operator                = "GreaterThan"
    metric_measure_column   = "DataNotArrived"
  }
  enabled                          = true
  query_time_range_override        = "PT30M"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_silent_monitoring_alert_01Hour" {
  name                = "kdata-${lower(var.env)}-silent-monitoring-alert-01Hour"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT1H"
  window_duration      = "PT1H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      receiptsoffsettable_CL
        | order by TimeGenerated asc
        | extend Increased = LATEST_OFFSET_d > prev(LATEST_OFFSET_d)
        | where TimeGenerated > ago(1h) and APP_NAME_s == "POS-GT-RECEIPTS"
        | summarize DataNotArrived = iff(countif(Increased == true) == 0, iff(hourofday(now()) between (23 .. 01), 2, 1),1)
      QUERY
    time_aggregation_method = "Total"
    threshold               = 1
    operator                = "GreaterThan"
    metric_measure_column   = "DataNotArrived"
  }
  enabled                          = true
  query_time_range_override        = "PT1H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}


########## Silent Monitoring End ################
########## Confluent monitoring alerts ##########
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_consumer_lag_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-consumer-lag-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      ConfluentConsumerLag_CL
        | where TimeGenerated >= ago(30m) and value_d > 1000000
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT1H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

### KSQLDB : ksqldb-gt-pos (lksqlc-ymp61p) ###
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_gt-pos_processing_errors_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-gt-pos-processing-errors-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      ConfluentProcessingErrors_CL
        | where TimeGenerated >= ago(30m) and value_d != 0 and cluster_id_s == 'lksqlc-ymp61p'
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT1H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_gt-pos_query_restarts_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-gt-pos-query-restarts-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      ConfluentQueryRestarts_CL
        | where TimeGenerated >= ago(30m) and value_d >= 10 and cluster_id_s == 'lksqlc-ymp61p'
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT1H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_gt-pos_storage_utilization_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-gt-pos-storage-utilization-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      ConfluentStorageUtilization_CL
        | where TimeGenerated >= ago(30m) and value_d >= 0.5 and cluster_id_s == 'lksqlc-ymp61p'
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT1H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_gt-pos_query_saturation_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-gt-pos-query-saturation-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      ConfluentQuerySaturation_CL
        | where TimeGenerated >= ago(30m) and value_d >= 0.7 and cluster_id_s == 'lksqlc-ymp61p'
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = false
  query_time_range_override        = "PT1H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

##########  Confluent state store monitoring alert ##########
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_gt-pos_taskstoredbytes_info_monitoring_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent_gt-pos_taskstoredbytes_info_monitoring_alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT4H"
  window_duration      = "PT4H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 3
  criteria {
    query                   = <<-QUERY
      ConfluentTaskstoredbytes_CL
        | where cluster_id_s == 'lksqlc-ymp61p'   
		| summarize arg_max(timestamp_t, *) by metric_query_id_s
        | summarize sum(value_d) by timestamp_t
        | extend total_gb = round((((sum_value_d)/1024)/1024)/1024) 
        | order by timestamp_t desc 
        | limit 1
      QUERY
    time_aggregation_method = "Total"
    threshold               = 450
    operator                = "GreaterThan"
    metric_measure_column   = "total_gb"
  }
  enabled                          = true
  query_time_range_override        = "PT4H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_gt-pos_taskstoredbytes_error_monitoring_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent_gt-pos_taskstoredbytes_error_monitoring_alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT4H"
  window_duration      = "PT4H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      ConfluentTaskstoredbytes_CL
        | where cluster_id_s == 'lksqlc-ymp61p'   
		| summarize arg_max(timestamp_t, *) by metric_query_id_s
        | summarize sum(value_d) by timestamp_t
        | extend total_gb = round((((sum_value_d)/1024)/1024)/1024) 
        | order by timestamp_t desc 
        | limit 1
      QUERY
    time_aggregation_method = "Total"
    threshold               = 525
    operator                = "GreaterThan"
    metric_measure_column   = "total_gb"
  }
  enabled                          = true
  query_time_range_override        = "PT4H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

### KSQLDB : ksqldb-gt-scm-delivery-check (lksqlc-7nggv2) ###
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_gt-scm-delivery-check_processing_errors_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-gt-scm-delivery-check-processing-errors-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      ConfluentProcessingErrors_CL
        | where TimeGenerated >= ago(30m) and value_d != 0 and cluster_id_s == 'lksqlc-7nggv2'
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT1H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_gt-scm-delivery-check_query_restarts_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-gt-scm-delivery-check-query-restarts-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      ConfluentQueryRestarts_CL
        | where TimeGenerated >= ago(30m) and value_d >= 10 and cluster_id_s == 'lksqlc-7nggv2'
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT1H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_gt-scm-delivery-check_storage_utilization_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-gt-scm-delivery-check-storage-utilization-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      ConfluentStorageUtilization_CL
        | where TimeGenerated >= ago(30m) and value_d >= 0.5 and cluster_id_s == 'lksqlc-7nggv2'
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT1H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_gt-scm-delivery-check_query_saturation_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-gt-scm-delivery-check-query-saturation-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      ConfluentQuerySaturation_CL
        | where TimeGenerated >= ago(30m) and value_d >= 0.7 and cluster_id_s == 'lksqlc-7nggv2'
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = false
  query_time_range_override        = "PT1H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}
# Common Query saturation
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_query_saturation80p_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-query-saturation80p-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 2
  criteria {
    query                   = <<-QUERY
      ConfluentQuerySaturation_CL
        | where TimeGenerated >= ago(30m) and value_d >= 0.7 and value_d < 0.9 
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT1H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_query_saturation90p_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-query-saturation90p-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      ConfluentQuerySaturation_CL
        | where TimeGenerated >= ago(30m) and value_d >= 0.990
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT1H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

##########  Confluent state store monitoring alert ##########
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_gt-scm-delivery-check_taskstoredbytes_info_monitoring_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent_gt-scm-delivery-check_taskstoredbytes_info_monitoring_alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT4H"
  window_duration      = "PT4H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 3
  criteria {
    query                   = <<-QUERY
      ConfluentTaskstoredbytes_CL
        | where cluster_id_s == 'lksqlc-7nggv2' 
		| summarize arg_max(timestamp_t, *) by metric_query_id_s
        | summarize sum(value_d) by timestamp_t
        | extend total_gb = round((((sum_value_d)/1024)/1024)/1024)  
        | order by timestamp_t desc 
        | limit 1
      QUERY
    time_aggregation_method = "Total"
    threshold               = 300
    operator                = "GreaterThan"
    metric_measure_column   = "total_gb"
  }
  enabled                          = true
  query_time_range_override        = "PT4H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_gt-scm-delivery-check_taskstoredbytes_error_monitoring_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent_gt-scm-delivery-check_taskstoredbytes_error_monitoring_alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT4H"
  window_duration      = "PT4H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      ConfluentTaskstoredbytes_CL
        | where cluster_id_s == 'lksqlc-7nggv2' 
		| summarize arg_max(timestamp_t, *) by metric_query_id_s
        | summarize sum(value_d) by timestamp_t
        | extend total_gb = round((((sum_value_d)/1024)/1024)/1024)  
        | order by timestamp_t desc 
        | limit 1
      QUERY
    time_aggregation_method = "Total"
    threshold               = 350
    operator                = "GreaterThan"
    metric_measure_column   = "total_gb"
  }
  enabled                          = true
  query_time_range_override        = "PT4H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

### KSQLDB : ksqldb-gt-pos-fnr (lksqlc-1k2xn5) ###
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_gt-pos-fnr_processing_errors_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-gt-pos-fnr-processing-errors-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      ConfluentProcessingErrors_CL
        | where TimeGenerated >= ago(30m) and value_d != 0 and cluster_id_s == 'lksqlc-1k2xn5'
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT1H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_gt-pos-fnr_query_restarts_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-gt-pos-fnr-query-restarts-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      ConfluentQueryRestarts_CL
        | where TimeGenerated >= ago(30m) and value_d >= 10 and cluster_id_s == 'lksqlc-1k2xn5'
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT1H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_gt-pos-fnr_storage_utilization_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-gt-pos-fnr-storage-utilization-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      ConfluentStorageUtilization_CL
        | where TimeGenerated >= ago(30m) and value_d >= 0.5 and cluster_id_s == 'lksqlc-1k2xn5'
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT1H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_gt-pos-fnr_query_saturation_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-gt-pos-fnr-query-saturation-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      ConfluentQuerySaturation_CL
        | where TimeGenerated >= ago(30m) and value_d >= 0.7 and cluster_id_s == 'lksqlc-1k2xn5'
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = false
  query_time_range_override        = "PT1H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

##########  Confluent state store monitoring alert ##########
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_gt-pos-fnr_taskstoredbytes_info_monitoring_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent_gt-pos-fnr_taskstoredbytes_info_monitoring_alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT4H"
  window_duration      = "PT4H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 3
  criteria {
    query                   = <<-QUERY
      ConfluentTaskstoredbytes_CL
        | where cluster_id_s == 'lksqlc-1k2xn5' 
		| summarize arg_max(timestamp_t, *) by metric_query_id_s
        | summarize sum(value_d) by timestamp_t
        | extend total_gb = round((((sum_value_d)/1024)/1024)/1024)  
        | order by timestamp_t desc 
        | limit 1
      QUERY
    time_aggregation_method = "Total"
    threshold               = 300
    operator                = "GreaterThan"
    metric_measure_column   = "total_gb"
  }
  enabled                          = true
  query_time_range_override        = "PT4H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_gt-pos-fnr_taskstoredbytes_error_monitoring_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent_gt-pos-fnr_taskstoredbytes_error_monitoring_alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT4H"
  window_duration      = "PT4H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      ConfluentTaskstoredbytes_CL
        | where cluster_id_s == 'lksqlc-1k2xn5' 
		| summarize arg_max(timestamp_t, *) by metric_query_id_s
        | summarize sum(value_d) by timestamp_t
        | extend total_gb = round((((sum_value_d)/1024)/1024)/1024)  
        | order by timestamp_t desc 
        | limit 1
      QUERY
    time_aggregation_method = "Total"
    threshold               = 350
    operator                = "GreaterThan"
    metric_measure_column   = "total_gb"
  }
  enabled                          = true
  query_time_range_override        = "PT4H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}


########## Logic app alerts ##########

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_logicapp_processingerrors_workflow_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-logicapp-processingerrors-workflow-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_application_insights.kconfluent_logic_app_insights.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      requests
        | where timestamp >= ago(30m) and success == false and operation_Name contains "processingerrors"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT30M"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_logicapp_queryrestarts_workflow_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-logicapp-queryrestarts-workflow-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_application_insights.kconfluent_logic_app_insights.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      requests
        | where timestamp >= ago(30m) and success == false and operation_Name contains "queryrestarts"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT30M"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_logicapp_storageutilization_workflow_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-logicapp-storageutilization-workflow-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_application_insights.kconfluent_logic_app_insights.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      requests
        | where timestamp >= ago(30m) and success == false and operation_Name contains "storageutilization"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT30M"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_logicapp_consumerlag_workflow_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-logicapp-consumerlag-workflow-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_application_insights.kconfluent_logic_app_insights.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      requests
        | where timestamp >= ago(30m) and success == false and operation_Name contains "consumerlag"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT30M"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_logicapp_querysaturation_workflow_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-logicapp-querysaturation-workflow-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_application_insights.kconfluent_logic_app_insights.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      requests
        | where timestamp >= ago(30m) and success == false and operation_Name contains "querysaturation"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT30M"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_logicapp_webhook_workflow_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-logicapp-webhook-workflow-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT1H"
  window_duration      = "PT1H"
  scopes               = [azurerm_application_insights.kconfluent_logic_app_insights.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      requests
        | where timestamp >= ago(1h) and success == false and operation_Name contains "kdata-confluent-webhook-alert"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT1H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_logicapp_requestcount_workflow_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-logicapp-requestcount-workflow-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_application_insights.kconfluent_logic_app_insights.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      requests
        | where timestamp >= ago(30m) and success == false and operation_Name contains "requestcount"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT30M"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_logicapp_connectordlq_workflow_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-logicapp-connectordlq-workflow-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_application_insights.kconfluent_logic_app_insights.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      requests
        | where timestamp >= ago(30m) and success == false and operation_Name contains "connectordlq"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT30M"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_logicapp_clusterload_workflow_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-logicapp-clusterload-workflow-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_application_insights.kconfluent_logic_app_insights.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      requests
        | where timestamp >= ago(30m) and success == false and operation_Name contains "clusterload"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT30M"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

########## Confluent Audit-Logs monitoring alerts ##########
# Confluent-Audit-Log-Alert- When Topic is deleted
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_auditlog_deletetopic_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-auditlog-deletetopic-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT2H"
  window_duration      = "PT2H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 2
  criteria {
    query                   = <<-QUERY
      ConfluentAuditLog_CL
        | where TimeGenerated >= ago(2h) and METHODNAME_s contains "kafka.DeleteTopics" and STATUS_s contains "SUCCESS" and ENVIRONMENT_s == "PROD"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT2H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# Confluent-Audit-Log-Alert- API key is deleted
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_auditlog_deleteapikey_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-auditlog-deleteapikey-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT2H"
  window_duration      = "PT2H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 2
  criteria {
    query                   = <<-QUERY
      ConfluentAuditLog_CL
        | where TimeGenerated >= ago(2h) and METHODNAME_s contains "DeleteAPIKey" and STATUS_s contains "SUCCESS" and ENVIRONMENT_s == "PROD"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT2H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# Confluent-Audit-Log-Alert- KSQL DB is deleted
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_auditlog_deletecluster_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-auditlog-deletecluster-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT2H"
  window_duration      = "PT2H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      ConfluentAuditLog_CL
        | where TimeGenerated >= ago(2h) and METHODNAME_s contains "DeleteKSQLCluster" and STATUS_s contains "SUCCESS" and ENVIRONMENT_s == "PROD"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT2H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# Confluent-Audit-Log-Alert- User is deleted
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_auditlog_deleteuser_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-auditlog-deleteuser-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT2H"
  window_duration      = "PT2H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 2
  criteria {
    query                   = <<-QUERY
      ConfluentAuditLog_CL
        | where TimeGenerated >= ago(2h) and METHODNAME_s contains "DeleteUser" and STATUS_s contains "SUCCESS" and ENVIRONMENT_s == "PROD"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT2H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# Confluent-Audit-Log-Alert- Service Account is deleted
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_auditlog_delserviceacnt_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-auditlog-delserviceacnt-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT2H"
  window_duration      = "PT2H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 0
  criteria {
    query                   = <<-QUERY
      ConfluentAuditLog_CL
        | where TimeGenerated >= ago(2h) and METHODNAME_s contains "DeleteServiceAccount" and STATUS_s contains "SUCCESS" and ENVIRONMENT_s == "PROD"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT2H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# Confluent-Audit-Log-Alert- ACL's are deleted or owner permission add/changed
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_auditlog_deleteacls_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-auditlog-deleteacls-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT2H"
  window_duration      = "PT2H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 2
  criteria {
    query                   = <<-QUERY
      ConfluentAuditLog_CL
        | where TimeGenerated >= ago(2h) and METHODNAME_s contains "kafka.DeleteAcls" and STATUS_s contains "SUCCESS" and ENVIRONMENT_s == "PROD"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT2H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# Confluent-Audit-Log-Alert- Environment is deleted
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_auditlog_deleteenv_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-auditlog-deleteenv-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT2H"
  window_duration      = "PT2H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 0
  criteria {
    query                   = <<-QUERY
      ConfluentAuditLog_CL
        | where TimeGenerated >= ago(2h) and METHODNAME_s contains "DeleteEnvironment" and STATUS_s contains "SUCCESS" and ENVIRONMENT_s == "PROD"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT2H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# Confluent-Audit-Log-Alert-Kafka Cluster is deleted
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_auditlog_deletekafcluster_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-auditlog-deletekafcluster-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT2H"
  window_duration      = "PT2H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 0
  criteria {
    query                   = <<-QUERY
      ConfluentAuditLog_CL
        | where TimeGenerated >= ago(2h) and METHODNAME_s contains "DeleteKafkaCluster" and STATUS_s contains "SUCCESS" and ENVIRONMENT_s == "PROD"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT2H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# Confluent-Audit-Log-Alert- schema-registry.DeleteSchemaVersion, schema-registry.DeleteSubject
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_auditlog_deleteschema_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-auditlog-deleteschemasubj-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT2H"
  window_duration      = "PT2H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 2
  criteria {
    query                   = <<-QUERY
      ConfluentAuditLog_CL
        | where TimeGenerated >= ago(2h) and STATUS_s contains "SUCCESS" and ENVIRONMENT_s == "PROD" and (METHODNAME_s contains "DeleteSubject" or METHODNAME_s contains "DeleteSchemaVersion")
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT2H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# Confluent-Audit-Log-Alert-Schema registry cluster is deleted
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_auditlog_deleteschemareg_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-auditlog-deleteschemaregcluster-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT2H"
  window_duration      = "PT2H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 2
  criteria {
    query                   = <<-QUERY
      ConfluentAuditLog_CL
        | where TimeGenerated >= ago(2h) and METHODNAME_s contains "DeleteSchemaRegistryCluster" and STATUS_s contains "SUCCESS" and ENVIRONMENT_s == "PROD"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT2H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# Confluent-Audit-Log-Alert-Deleted Connector
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_auditlog_deleteconnector_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-auditlog-deleteconnector-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT2H"
  window_duration      = "PT2H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      ConfluentAuditLog_CL
        | where TimeGenerated >= ago(2h) and METHODNAME_s contains "DeleteConnector" and STATUS_s contains "SUCCESS" and ENVIRONMENT_s == "PROD"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT2H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

########## Confluent Metric Monitoring Alerts ##########
# Confluent-Metric-Alert-RequestCount
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_metric_requestcount_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-metric-requestcount-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT1H"
  window_duration      = "PT1H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
      ConfluentRequestCount_CL
        | where TimeGenerated >= ago(1h) and value_d >= 2000000
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = false
  query_time_range_override        = "PT1H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# Confluent-Metric-ReceiptDLQ
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_metric_connectordlq_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-metric-connectordlq-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT1H"
  window_duration      = "PT1H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 0
  criteria {
    query                   = <<-QUERY
      ConfluentConnectorDLQ_CL
        | where TimeGenerated >= ago(1h) and value_d > 0
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT1H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# Confluent-Metric-ClusterLoad
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_metric_clusterload_80per_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-metric-clusterload-80per-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 2
  criteria {
    query                   = <<-QUERY
      ConfluentClusterLoadPercent_CL
        | where TimeGenerated >= ago(1h) and value_d >= 0.8
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT1H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_metric_clusterload_90per_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-metric-clusterload-90per-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 0
  criteria {
    query                   = <<-QUERY
      ConfluentClusterLoadPercent_CL
        | where TimeGenerated >= ago(1h) and value_d >= 0.9
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT1H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

########## Confluent Webhook Monitoring Alerts ##########
# Kconfluent-Webhook-Alert-Cluster Expansion Failure
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_webhook_clusterexpanfail_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-webhook-clusterexpanfail-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT1H"
  window_duration      = "PT1H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 0
  criteria {
    query                   = <<-QUERY
      ConfluentWebhookAlert_CL
        | where notifywhen_s contains "KafkaClusterExpansionFailure"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT1H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# Kconfluent-Webhook-Alert-Connector In Failed State
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_webhook_connectorfailed_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-webhook-connectorfailed-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT1H"
  window_duration      = "PT1H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 0
  criteria {
    query                   = <<-QUERY
      ConfluentWebhookAlert_CL
        | where notifywhen_s contains "ConnectorInFailedState"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT1H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# Kconfluent-Webhook-Alert-Cloud Service Quota Surpassed 100 Per
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_webhook_servicequota100_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-webhook-servicequota100-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT1H"
  window_duration      = "PT1H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 0
  criteria {
    query                   = <<-QUERY
      ConfluentWebhookAlert_CL
        | where notifywhen_s contains "CloudServiceQuotaReached100pUsage"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT1H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# Kconfluent-Webhook-Alert-Cloud Service Quota Surpassed 50 Per
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_webhook_servicequota50_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-webhook-servicequota50-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT1H"
  window_duration      = "PT1H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 3
  criteria {
    query                   = <<-QUERY
      ConfluentWebhookAlert_CL
        | where notifywhen_s contains "CloudServiceQuotaSurpassed50pUsage"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT1H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# Kconfluent-Webhook-Alert-Cloud Service Quota Surpassed 90 Per
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_webhook_servicequota90_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-webhook-servicequota90-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT1H"
  window_duration      = "PT1H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 0
  criteria {
    query                   = <<-QUERY
      ConfluentWebhookAlert_CL
        | where notifywhen_s contains "CloudServiceQuotaSurpassed90pUsage"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT1H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

########## Confluent Audit-Failed-Logs monitoring alerts ##########
# Confluent-Audit-Log-Alert- When Topic deletion failed
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_auditlog_deletetopic_failed_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-auditlog-deletetopic-failed-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT2H"
  window_duration      = "PT2H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 2
  criteria {
    query                   = <<-QUERY
      ConfluentAuditLog_CL
        | where TimeGenerated >= ago(2h) and STATUS_s contains "FAILURE" and ENVIRONMENT_s == "PROD" and METHODNAME_s contains "kafka.DeleteTopics"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT2H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# Confluent-Audit-Log-Alert- API key deletiton failed
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_auditlog_deleteapikey_failed_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-auditlog-deleteapikey-failed-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT2H"
  window_duration      = "PT2H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 2
  criteria {
    query                   = <<-QUERY
      ConfluentAuditLog_CL
        | where TimeGenerated >= ago(2h) and STATUS_s contains "FAILURE" and ENVIRONMENT_s == "PROD" and METHODNAME_s contains "DeleteAPIKey"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT2H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# Confluent-Audit-Log-Alert- User deletion failed
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_auditlog_deleteuser_failed_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-auditlog-deleteuser-failed-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT2H"
  window_duration      = "PT2H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 2
  criteria {
    query                   = <<-QUERY
      ConfluentAuditLog_CL
        | where TimeGenerated >= ago(2h) and STATUS_s contains "FAILURE" and ENVIRONMENT_s == "PROD" and METHODNAME_s contains "DeleteUser"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT2H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# Confluent-Audit-Log-Alert- Service Account deletion failed
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_auditlog_delserviceacnt_failed_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-auditlog-delserviceacnt-failed-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT2H"
  window_duration      = "PT2H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 2
  criteria {
    query                   = <<-QUERY
      ConfluentAuditLog_CL
        | where TimeGenerated >= ago(2h) and STATUS_s contains "FAILURE" and ENVIRONMENT_s == "PROD" and METHODNAME_s contains "DeleteServiceAccount"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT2H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# Confluent-Audit-Log-Alert- ACL's deletion or owner permission add/changed failed
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_auditlog_deleteacls_failed_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-auditlog-deleteacls-failed-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT2H"
  window_duration      = "PT2H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 2
  criteria {
    query                   = <<-QUERY
      ConfluentAuditLog_CL
        | where TimeGenerated >= ago(2h) and STATUS_s contains "FAILURE" and ENVIRONMENT_s == "PROD" and METHODNAME_s contains "kafka.DeleteAcls"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT2H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# Confluent-Audit-Log-Alert- Environment deletion failed
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_auditlog_deleteenv_failed_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-auditlog-deleteenv-failed-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT2H"
  window_duration      = "PT2H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 2
  criteria {
    query                   = <<-QUERY
      ConfluentAuditLog_CL
        | where TimeGenerated >= ago(2h) and STATUS_s contains "FAILURE" and ENVIRONMENT_s == "PROD" and METHODNAME_s contains "DeleteEnvironment"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT2H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# Confluent-Audit-Log-Alert-Kafka Cluster deletion failed
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_auditlog_deletekafcluster_failed_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-auditlog-deletekafcluster-failed-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT2H"
  window_duration      = "PT2H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 2
  criteria {
    query                   = <<-QUERY
      ConfluentAuditLog_CL
        | where TimeGenerated >= ago(2h) and STATUS_s contains "FAILURE" and ENVIRONMENT_s == "PROD" and METHODNAME_s contains "DeleteKafkaCluster"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT2H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# Confluent-Audit-Log-Alert- schema-registry.DeleteSchemaVersion, schema-registry.DeleteSubject failed
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_auditlog_deleteschema_failed_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-auditlog-deleteschemasubj-failed-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT2H"
  window_duration      = "PT2H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 2
  criteria {
    query                   = <<-QUERY
      ConfluentAuditLog_CL
        | where TimeGenerated >= ago(2h) and STATUS_s contains "FAILURE" and ENVIRONMENT_s == "PROD" and (METHODNAME_s contains "DeleteSubject" or METHODNAME_s contains "DeleteSchemaVersion")
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT2H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# Confluent-Audit-Log-Alert-Schema registry cluster deletion failed
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_auditlog_deleteschemareg_failed_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-auditlog-deleteschemaregcluster-failed-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT2H"
  window_duration      = "PT2H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 2
  criteria {
    query                   = <<-QUERY
      ConfluentAuditLog_CL
        | where TimeGenerated >= ago(2h) and STATUS_s contains "FAILURE" and ENVIRONMENT_s == "PROD" and METHODNAME_s contains "DeleteSchemaRegistryCluster"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT2H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# Confluent-Audit-Log-Alert-Deletion Connector failed
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_auditlog_deleteconnector_failed_alert" {
  name                = "kdata-${lower(var.env)}-kconfluent-auditlog-deleteconnector-failed-alert"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT2H"
  window_duration      = "PT2H"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 2
  criteria {
    query                   = <<-QUERY
      ConfluentAuditLog_CL
        | where TimeGenerated >= ago(2h) and STATUS_s contains "FAILURE" and ENVIRONMENT_s == "PROD" and METHODNAME_s contains "DeleteConnector"
      QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "PT2H"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# ORDER05DLQ	-- alert for orders05dlqoffsettable_CL
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_silent_monitoring_alert_orders05dlq_message_Arrival_prod" {
  name                = "kdata-${lower(var.env)}-silent-monitoring-prod-alert-orders05dlq-message-Arrival"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT45M"
  window_duration      = "PT45M"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
	orders05dlqoffsettable_CL
        | where TimeGenerated > ago(45m)
        | where APP_NAME_s == "POS-ORDER05-DLQAVROCONVERTER"
    QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "P2D"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

#POS-CONNECTOR-ERROR-ALERTS

# BWERROR	-- alert for POS-BW-CONNECTOR-ERROR
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_silent_monitoring_alert_bw_connector_error_message_Arrival_prod" {
  name                = "kdata-${lower(var.env)}-silent-monitoring-alert-bw-connector-error-message-Arrival"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
	bwconnectorerroroffsettable_CL
        | where TimeGenerated > ago(30m)
        | where APP_NAME_s == "POS-BW-CONNECTOR-ERROR"
    QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "P2D"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# FNRERROR	-- alert for POS-FnR-CONNECTOR-ERROR
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_silent_monitoring_alert_fnr_connector_error_message_Arrival_prod" {
  name                = "kdata-${lower(var.env)}-silent-monitoring-alert-fnr-connector-error-message-Arrival"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
	fnrconnectorerroroffsettable_CL
        | where TimeGenerated > ago(30m)
        | where APP_NAME_s == "POS-FnR-CONNECTOR-ERROR"
    QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "P2D"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}

# WPUUMSERROR	-- alert for POS-WPUUMS-CONNECTOR-ERROR
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kconfluent_silent_monitoring_alert_wpuums_connector_error_message_Arrival_prod" {
  name                = "kdata-${lower(var.env)}-silent-monitoring-alert-wpuums-connector-error-message-Arrival"
  display_name        = "kdata-${lower(var.env)}-silent-monitoring-alert-wpuums-connector-error-message-Arrival"
  resource_group_name = var.rg_name
  location            = var.location
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_log_analytics_workspace.kconfluent-loganalytics.id]
  severity             = 1
  criteria {
    query                   = <<-QUERY
	wpuumsconnectorerroroffsettable_CL
        | where TimeGenerated > ago(30m)
        | where APP_NAME_s == "POS-WPUUMS-CONNECTOR-ERROR"
    QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
  }
  enabled                          = true
  query_time_range_override        = "P2D"
  action {
    action_groups = [azurerm_monitor_action_group.kconfluent-errors-action-group.id]
  }

  tags = local.resource_tags
}
