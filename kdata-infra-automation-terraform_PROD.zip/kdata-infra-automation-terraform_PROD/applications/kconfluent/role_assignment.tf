resource "azurerm_role_assignment" "log_analytics_workspace_kconfluent-log_analytics_contributor-logicapp" {
  scope                = azurerm_log_analytics_workspace.kconfluent-loganalytics.id
  role_definition_name = "Log Analytics Contributor"
  principal_id         =  azurerm_logic_app_standard.kconfluent-logicapp.identity.0.principal_id  #"7b64c4be-a261-4d32-a008-fa2534011440"
}

resource "azurerm_role_assignment" "logicapp_kconfluent-contributor-sp_platform_devops" {
  scope                = azurerm_logic_app_standard.kconfluent-logicapp.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.sp_platform_devops.id
}