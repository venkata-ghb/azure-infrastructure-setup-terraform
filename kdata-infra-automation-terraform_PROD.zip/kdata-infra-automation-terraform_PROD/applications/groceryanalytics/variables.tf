variable "location" {
  type        = string
  description = "Location"
  default     = "westeurope"
}

variable "loc" {
  type        = string
  description = "Location short"
  default     = "we"
}

variable "prefix" {
  type        = string
  description = "Prefix to be applied to all resource names"
  default     = "kdata-prod"
}

variable "prefix_sa" {
  type        = string
  description = "Prefix to be applied to all resource names in storage account"
  default     = "kdataprod"
}

variable "prefix_rg" {
  type        = string
  description = "Prefix to be applied to all resource names in resourcegroups"
  default     = "K-DATA_PROD_WE"
}

variable "resource_tags" {
  type        = map(string)
  description = "Tags to be applied for all resources"
  default = {
    Application     = "Cloud Data Platform"
    "Business Unit" = "Shared"
    environment     = "Production"
    IT-Owner        = "sankalp.ahuja@kesko.fi"
    ManagedResource = "Yes"
    MgmtVendor      = "Tieto"
    created_by      = "Terraform"
    SubApplication  = "GroceryAnalytics"
  }
}

