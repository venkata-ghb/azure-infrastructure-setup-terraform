resource "azurerm_resource_group" "gtanalytics" {
  name     = "${var.prefix_rg}_GROCERYANALYTICS_Main_RG"
  location = var.location
  tags     = local.resource_tags
}

