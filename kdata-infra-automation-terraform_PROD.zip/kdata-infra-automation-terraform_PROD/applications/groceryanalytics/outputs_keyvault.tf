output "kv_gtanalytics" {
  value = {
    id        = azurerm_key_vault.gtanalytics.id
    name      = azurerm_key_vault.gtanalytics.name
    vault_uri = azurerm_key_vault.gtanalytics.vault_uri
  }
}
