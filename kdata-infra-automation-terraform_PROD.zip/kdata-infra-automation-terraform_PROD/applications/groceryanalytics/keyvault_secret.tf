resource "azurerm_key_vault_secret" "gtanalytics-sp_gtanalytics_adb_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_gtanalytics_adb.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_gtanalytics_adb_password
  key_vault_id = azurerm_key_vault.gtanalytics.id
  content_type = "${data.terraform_remote_state.ad.outputs.sp_gtanalytics_adb.display_name} SP's Password by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "gtanalytics-user_bri_snowflake" {
  name         = "${var.prefix}-bri-user"
  value        = "U_GT_BRI_PROD"
  key_vault_id = azurerm_key_vault.gtanalytics.id
  content_type = "BRI Snowflake User by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "gtanalytics-user_gt_databricks_snowflake" {
  name         = "kdata-gt-databricks-user"
  value        = "U_KDATA_BRI_PROD"
  key_vault_id = azurerm_key_vault.gtanalytics.id
  content_type = "Databricks Technical Snowflake User by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "gtanalytics-sp_powerbi_kdig_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_powerbi_kdig.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_powerbi_kdig_password
  key_vault_id = azurerm_key_vault.gtanalytics.id
  content_type = "${data.terraform_remote_state.ad.outputs.sp_powerbi_kdig.display_name} SP's Password by Terraform"
  tags         = local.resource_tags
}
