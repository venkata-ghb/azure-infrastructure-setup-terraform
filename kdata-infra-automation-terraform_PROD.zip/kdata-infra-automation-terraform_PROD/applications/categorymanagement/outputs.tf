output "kv_catman" {
  value = {
    id        = azurerm_key_vault.catman.id
    name      = azurerm_key_vault.catman.name
    vault_uri = azurerm_key_vault.catman.vault_uri
  }
}
