resource "azurerm_api_management_api" "onninen_sap_inbound" {
  provider            = azurerm.apim
  name                = "kdata-onninen-sap-inbound-api"
  resource_group_name = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.resource_group
  api_management_name = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.name
  revision            = "1"
  display_name        = "KDATA Onninen SAP Inbound API"
  path                = "kdata/onninen-sap-inbound-api"
  protocols           = ["https"]

  import {
    content_format = "openapi+json"
    content_value  = file("${path.module}/resources/openapi.osap.json")
  }
}

resource "azurerm_api_management_api_operation_policy" "onninen_sap_inbound-accounts" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.onninen_sap_inbound.name
  api_management_name = azurerm_api_management_api.onninen_sap_inbound.api_management_name
  resource_group_name = azurerm_api_management_api.onninen_sap_inbound.resource_group_name
  operation_id        = "post-accounts"

  xml_content = templatefile(
    "${path.module}/resources/adls-policy.xml", {
      storage  = data.terraform_remote_state.integrations.outputs.sa_adls.name
      source   = "OSAP"
      dataset  = "accounts"
      filetype = "json"
  })
}

resource "azurerm_api_management_product" "onninen_sap_inbound-onninen_sap" {
  provider              = azurerm.apim
  display_name          = azurerm_api_management_api.onninen_sap_inbound.display_name
  product_id            = "${azurerm_api_management_api.onninen_sap_inbound.name}-onninen_sap-product"
  api_management_name   = azurerm_api_management_api.onninen_sap_inbound.api_management_name
  resource_group_name   = azurerm_api_management_api.onninen_sap_inbound.resource_group_name
  subscriptions_limit   = 0
  subscription_required = true
  approval_required     = false
  published             = true
}

resource "azurerm_api_management_product_api" "onninen_sap_inbound-onninen_sap" {
  provider            = azurerm.apim
  product_id          = azurerm_api_management_product.onninen_sap_inbound-onninen_sap.product_id
  api_name            = azurerm_api_management_api.onninen_sap_inbound.name
  api_management_name = azurerm_api_management_api.onninen_sap_inbound.api_management_name
  resource_group_name = azurerm_api_management_api.onninen_sap_inbound.resource_group_name
}

resource "azurerm_api_management_subscription" "onninen_sap_inbound-onninen_sap" {
  provider            = azurerm.apim
  api_management_name = azurerm_api_management_product.onninen_sap_inbound-onninen_sap.api_management_name
  resource_group_name = azurerm_api_management_product.onninen_sap_inbound-onninen_sap.resource_group_name
  product_id          = azurerm_api_management_product.onninen_sap_inbound-onninen_sap.id
  display_name        = "onninen_sap-${azurerm_api_management_product.onninen_sap_inbound-onninen_sap.product_id}"
  state               = "active"
}

resource "azurerm_api_management_api_diagnostic" "onninen_sap_inbound" {
  provider                 = azurerm.apim
  identifier               = "applicationinsights"
  resource_group_name      = azurerm_api_management_api.onninen_sap_inbound.resource_group_name
  api_management_name      = azurerm_api_management_api.onninen_sap_inbound.api_management_name
  api_name                 = azurerm_api_management_api.onninen_sap_inbound.name
  api_management_logger_id = data.terraform_remote_state.apimanagement.outputs.apim_logger_kgroup_kdata_apis.id
  always_log_errors        = true
}

