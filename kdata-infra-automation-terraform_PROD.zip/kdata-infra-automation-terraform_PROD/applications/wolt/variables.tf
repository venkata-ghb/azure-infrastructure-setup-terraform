variable "location" {
  type        = string
  description = "Location"
  default     = "westeurope"
}

variable "loc" {
  type        = string
  description = "Location short"
  default     = "we"
}

variable "env" {
  type        = string
  description = "Environment short"
  default     = "prod"
}

variable "environment" {
  type        = string
  description = "Environment name"
  default     = "Prod"
}

variable "kv_rg_name" {
  type        = string
  description = "Resource Group Name for Main Keyvault"
  default     = "K-DATA_PROD_WE_Vault_RG"
}

variable "prefix" {
  type        = string
  description = "Prefix to be applied to all resource names"
  default     = "kdata-prod"
}

variable "resource_tags" {
  type        = map(string)
  description = "Tags to be applied for all resources"
  default = {
    Application     = "Cloud Data Platform"
    "Business Unit" = "Shared"
    Environment     = "Production"
    IT-Owner        = "sankalp.ahuja@kesko.fi"
    ManagedResource = "Yes"
    MgmtVendor      = "Tieto"
    created_by      = "Terraform"
    SubApplication  = "Wolt"
  }
}

