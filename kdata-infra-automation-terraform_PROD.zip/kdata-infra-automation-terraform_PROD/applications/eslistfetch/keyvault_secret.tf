resource "azurerm_key_vault_secret" "eslistfetch-cosmos_eslist_connection_string" {
  key_vault_id = azurerm_key_vault.eslistfetch.id
  name         = "cosmos-eslist-proddb-connection-string"
  value        = azurerm_cosmosdb_account.cosmosdb_acc.primary_key

  lifecycle {
    prevent_destroy = true
  }
}

resource "azurerm_key_vault_secret" "eslistfetch-cosmos_enrich_eslist_endpoint" {
  key_vault_id = azurerm_key_vault.eslistfetch.id
  name         = "cosmos-enrich-eslist-proddb-endpoint"
  value        = azurerm_cosmosdb_account.cosmosdb_acc.connection_strings.0
}
