output "cosmosdb_name" {
  value = azurerm_cosmosdb_account.cosmosdb_acc.name
}

output "cosmosdb_rg_name" {
  value = azurerm_cosmosdb_account.cosmosdb_acc.resource_group_name
}

output "cosmosdb_id" {
  value = azurerm_cosmosdb_account.cosmosdb_acc.id
}