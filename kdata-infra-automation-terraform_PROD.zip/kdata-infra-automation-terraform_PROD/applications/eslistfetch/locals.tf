locals {
  resource_tags = merge(data.terraform_remote_state.common.outputs.resource_tags, {
    SubApplication = "ESLISTFETCH"
  })
}