resource "azurerm_linux_function_app" "eslistfetch" {
  name                        = "${var.prefix}-${var.loc}-eslistfetch-funcapp"
  location                    = var.location
  resource_group_name         = data.terraform_remote_state.integrations.outputs.rg_functionapp_app.name
  service_plan_id             = replace(data.terraform_remote_state.integrations.outputs.service_plan_app_premium.id, "serverFarm", "serverfarm")
  storage_account_name        = azurerm_storage_account.eslistfetch.name
  storage_account_access_key  = azurerm_storage_account.eslistfetch.primary_access_key
  https_only                  = true
  functions_extension_version = "~4"
  virtual_network_subnet_id   = data.terraform_remote_state.vnets.outputs.subnet_funcapp_app.id

  identity {
    type = "SystemAssigned"
  }

  site_config {
    ftps_state               = "Disabled"
    always_on                = true
    application_insights_key = azurerm_application_insights.eslistfetch.instrumentation_key

    application_stack {
      python_version = "3.11"
    }
  }

  app_settings = {
    DB_CONNECTION_SECRET                = "eslistdb-prod-api-secret"
    WEBSITE_ENABLE_SYNC_UPDATE_SITE     = false
    WEBSITES_ENABLE_APP_SERVICE_STORAGE = true
    KEY_VAULT_NAME                      = azurerm_key_vault.eslistfetch.name
  }

  tags = merge(local.resource_tags, {
    "hidden-link: /app-insights-resource-id"         = azurerm_application_insights.eslistfetch.id
    "hidden-link: /app-insights-instrumentation-key" = azurerm_application_insights.eslistfetch.instrumentation_key
    "hidden-link: /app-insights-conn-string"         = azurerm_application_insights.eslistfetch.connection_string
  })

  lifecycle {
    ignore_changes = [
      app_settings["WEBSITE_ENABLE_SYNC_UPDATE_SITE"],
      app_settings["WEBSITE_RUN_FROM_PACKAGE"],
    ]
  }
}

resource "azurerm_application_insights" "eslistfetch" {
  name                = "${var.prefix}-${var.loc}-eslistfetch-funcapp"
  location            = var.location
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_app.name
  application_type    = "web"
  retention_in_days   = 90
  sampling_percentage = 0
  tags                = local.resource_tags

  lifecycle {
    ignore_changes = [ workspace_id ]
  }
}

# ==================================================================================================

resource "azurerm_application_insights" "eslist" {
  name                = "${var.prefix}-we-eslist-application-insights"
  location            = var.location
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  application_type    = "web"
  sampling_percentage = 0
  tags                = local.resource_tags

  lifecycle {
    ignore_changes = [ workspace_id ]
  }
}

resource "azurerm_linux_function_app" "eslist" {
  name                        = "${var.prefix}-we-eslist-function-app"
  location                    = var.location
  resource_group_name         = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  service_plan_id             = replace(data.terraform_remote_state.integrations.outputs.service_plan_int_premium.id, "serverFarm", "serverfarm")
  storage_account_name        = azurerm_storage_account.eslistfasa.name
  storage_account_access_key  = azurerm_storage_account.eslistfasa.primary_access_key
  functions_extension_version = "~4"
  virtual_network_subnet_id   = data.terraform_remote_state.vnets.outputs.subnet_funcapp_int.id


  tags = merge(local.resource_tags, {
    "hidden-link: /app-insights-resource-id"         = azurerm_application_insights.eslist.id
    "hidden-link: /app-insights-instrumentation-key" = azurerm_application_insights.eslist.instrumentation_key
  })

  identity {
    type = "SystemAssigned"
  }

  site_config {
    application_insights_key = azurerm_application_insights.eslist.instrumentation_key
    always_on                = true

    application_stack {
      python_version = "3.11"
    }
  }

  app_settings = {
    queuestorage_connectionstring       = azurerm_storage_account.eslistfasa.primary_connection_string
    WEBSITE_ENABLE_SYNC_UPDATE_SITE     = false
    WEBSITES_ENABLE_APP_SERVICE_STORAGE = true
    DB_CONNECTION_SECRET                = azurerm_key_vault_secret.eslistfetch-cosmos_eslist_connection_string.name
    KEY_VAULT_NAME                      = azurerm_key_vault.eslistfetch.name
    container_id                        = azurerm_cosmosdb_sql_container.cosmosdb_acc-eslist_db-eslist_prides.name
    database_id                         = azurerm_cosmosdb_sql_database.cosmosdb_acc-eslist_db.name
    account_url                         = data.terraform_remote_state.integrations.outputs.sa_adls.primary_blob_endpoint
    host                                = azurerm_cosmosdb_account.cosmosdb_acc.endpoint
  }

  lifecycle {
    ignore_changes = [
      app_settings["WEBSITE_ENABLE_SYNC_UPDATE_SITE"],
      app_settings["WEBSITE_RUN_FROM_PACKAGE"]
      ]
  }

}

# ==================================================================================================

# ESList Enrich Function App
resource "azurerm_application_insights" "enrich_eslist" {
  name                = "${var.prefix}-we-enrich-eslist-application-insights"
  location            = var.location
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  application_type    = "Node.JS"
  tags                = local.resource_tags

  lifecycle {
    ignore_changes = [ workspace_id ]
  }
}

resource "azurerm_linux_function_app" "enrich_eslist" {
  name                        = "${var.prefix}-we-enrich-eslist-function-app"
  location                    = var.location
  resource_group_name         = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  service_plan_id             = replace(data.terraform_remote_state.integrations.outputs.service_plan_int_premium.id, "serverFarm", "serverfarm")
  storage_account_name        = azurerm_storage_account.enricheslistfasa.name
  storage_account_access_key  = azurerm_storage_account.enricheslistfasa.primary_access_key
  functions_extension_version = "~4"
  virtual_network_subnet_id   = data.terraform_remote_state.vnets.outputs.subnet_funcapp_int.id
  tags                        = local.resource_tags

  identity {
    type = "SystemAssigned"
  }
  site_config {
    application_insights_key = azurerm_application_insights.enrich_eslist.instrumentation_key
    always_on                = true

    application_stack {
      python_version = "3.11"
    }
  }

  app_settings = {
    WEBSITE_ENABLE_SYNC_UPDATE_SITE     = true
    WEBSITES_ENABLE_APP_SERVICE_STORAGE = true
    cosmostestserver_DOCUMENTDB         = "@Microsoft.KeyVault(SecretUri=${azurerm_key_vault_secret.eslistfetch-cosmos_enrich_eslist_endpoint.id})"
    db_connection_secret                = azurerm_key_vault_secret.eslistfetch-cosmos_eslist_connection_string.name
    keyVaultName                        = azurerm_key_vault.eslistfetch.name
    container_id                        = azurerm_cosmosdb_sql_container.cosmosdb_acc-eslist_db-k_data_product.name
    product_container_id                = azurerm_cosmosdb_sql_container.cosmosdb_acc-eslist_db-enrich_esList.name
    database_id                         = azurerm_cosmosdb_sql_database.cosmosdb_acc-eslist_db.name
    host                                = azurerm_cosmosdb_account.cosmosdb_acc.endpoint
  }
}



