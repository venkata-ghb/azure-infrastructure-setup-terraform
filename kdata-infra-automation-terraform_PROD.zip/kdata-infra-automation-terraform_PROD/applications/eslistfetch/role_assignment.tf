# ================================================================================================================================
# Cosmos DB
# ================================================================================================================================
resource "azurerm_role_assignment" "cosmosdb_acc-cosmosdb_account_reader-group_devops_gtesl" {
  scope                = azurerm_cosmosdb_account.cosmosdb_acc.id
  role_definition_name = "Cosmos DB Account Reader Role"
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_gtesl.id
}


resource "azurerm_role_assignment" "cosmosdb_acc-cosmosdb_account_reader-group_devops_platform" {
  scope                = azurerm_cosmosdb_account.cosmosdb_acc.id
  role_definition_name = "Cosmos DB Account Reader Role"
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
}

# ================================================================================================================================
# Function app
# ================================================================================================================================

resource "azurerm_role_assignment" "funcapp_eslist-contributor-group_devops_platform" {
  scope                = azurerm_linux_function_app.eslist.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
}

resource "azurerm_role_assignment" "funcapp_enrich_eslist-contributor-group_devops_platform" {
  scope                = azurerm_linux_function_app.enrich_eslist.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
}

resource "azurerm_role_assignment" "funcapp_eslist_fetch-contributor-group_devops_platform" {
  scope                = azurerm_linux_function_app.eslistfetch.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
}

