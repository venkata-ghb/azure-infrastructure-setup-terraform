resource "azurerm_storage_account" "eslistfetch" {
  name                     = "${var.prefix_sa}${var.loc}eslistfetch"
  resource_group_name      = data.terraform_remote_state.integrations.outputs.rg_functionapp_app.name
  location                 = var.location
  account_tier             = "Standard"
  account_replication_type = "LRS"
  tags                     = local.resource_tags
  network_rules {
    default_action = "Allow"
    virtual_network_subnet_ids = [ "/subscriptions/0a2d289e-76dd-4b1f-b9b2-dba15a872e92/resourceGroups/rg-platform-avd-prod-weu-001/providers/Microsoft.Network/virtualNetworks/vnet-avd-prod-weu-001/subnets/Subnet-AVDTCS-AMS-prod-weu" ]
  }
  blob_properties {
    delete_retention_policy {
      days = 60
    }
  }
}

resource "azurerm_storage_account" "eslistfasa" {
  name                     = "${var.prefix_sa}eslistfasa"
  resource_group_name      = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  location                 = var.location
  account_tier             = "Standard"
  account_replication_type = "LRS"
  is_hns_enabled           = true

  network_rules {
    bypass = [
      "AzureServices"
    ]
    default_action = "Allow"
    virtual_network_subnet_ids = [ "/subscriptions/0a2d289e-76dd-4b1f-b9b2-dba15a872e92/resourceGroups/rg-platform-avd-prod-weu-001/providers/Microsoft.Network/virtualNetworks/vnet-avd-prod-weu-001/subnets/Subnet-AVDTCS-AMS-prod-weu" ]
  }

  tags                      = merge(local.resource_tags, {
    AzDefenderPlanAutoEnable = "off"
  })
}

resource "azurerm_storage_account" "enricheslistfasa" {
  name                     = "${var.prefix_sa}enricheslstfasa"
  resource_group_name      = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  location                 = var.location
  account_tier             = "Standard"
  account_replication_type = "LRS"

  network_rules {
    bypass = [
      "AzureServices"
    ]
    default_action = "Allow"
    virtual_network_subnet_ids = [ "/subscriptions/0a2d289e-76dd-4b1f-b9b2-dba15a872e92/resourceGroups/rg-platform-avd-prod-weu-001/providers/Microsoft.Network/virtualNetworks/vnet-avd-prod-weu-001/subnets/Subnet-AVDTCS-AMS-prod-weu" ]
  }

  tags = local.resource_tags
}

resource "azurerm_storage_queue" "eslistfasa-eslistqueue" {
  name                 = "eslistqueue"
  storage_account_name = azurerm_storage_account.eslistfasa.name
}
