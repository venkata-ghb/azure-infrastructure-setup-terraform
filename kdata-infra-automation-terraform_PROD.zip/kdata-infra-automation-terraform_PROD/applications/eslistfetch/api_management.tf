data "azurerm_api_management" "apimanagement" {
  provider            = azurerm.apim
  name                = "K-apim-prod"
  resource_group_name = "KESKO_WE_RG_APIM_PROD001"
}

resource "azurerm_api_management_api" "eslist_input" {
  provider            = azurerm.apim
  name                = "kdata-eslist-app-input-api"
  resource_group_name = data.azurerm_api_management.apimanagement.resource_group_name
  api_management_name = data.azurerm_api_management.apimanagement.name
  revision            = "1"
  display_name        = "K-Data EsList APP Input API"
  path                = "kdata/eslist-app-input-api"
  protocols           = ["https"]

  import {
    content_format = "openapi+json"
    content_value  = file("${path.module}/resources/openapi.eslist-app-input-api.json")
  }
}

resource "azurerm_api_management_api_policy" "eslist_input" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.eslist_input.name
  api_management_name = azurerm_api_management_api.eslist_input.api_management_name
  resource_group_name = azurerm_api_management_api.eslist_input.resource_group_name

  xml_content = <<XML
<policies>
    <inbound>
        <base />
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>
XML
}

resource "azurerm_api_management_api_operation_policy" "eslist_input-event" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.eslist_input.name
  api_management_name = azurerm_api_management_api.eslist_input.api_management_name
  resource_group_name = azurerm_api_management_api.eslist_input.resource_group_name
  operation_id        = "post-event"

  xml_content = templatefile(
    "${path.module}/resources/adls-policy.xml", {
      storage  = "kdata${var.env}adls"
      dataset  = "Prides"
      filetype = "json"
  })
}

resource "azurerm_api_management_product" "eslist_input" {
  provider              = azurerm.apim
  product_id            = "${azurerm_api_management_api.eslist_input.name}-product"
  api_management_name   = azurerm_api_management_api.eslist_input.api_management_name
  resource_group_name   = azurerm_api_management_api.eslist_input.resource_group_name
  display_name          = azurerm_api_management_api.eslist_input.display_name
  subscriptions_limit   = 0
  subscription_required = true
  approval_required     = false
  published             = true
}

resource "azurerm_api_management_product_api" "eslist_input" {
  provider            = azurerm.apim
  resource_group_name = azurerm_api_management_api.eslist_input.resource_group_name
  api_management_name = azurerm_api_management_api.eslist_input.api_management_name
  api_name            = azurerm_api_management_api.eslist_input.name
  product_id          = azurerm_api_management_product.eslist_input.product_id
}

resource "azurerm_api_management_product_group" "eslist_input" {
  provider            = azurerm.apim
  resource_group_name = azurerm_api_management_api.eslist_input.resource_group_name
  api_management_name = azurerm_api_management_api.eslist_input.api_management_name
  product_id          = azurerm_api_management_product.eslist_input.product_id
  group_name          = "61f7b4deb31633299a23e334"
}

resource "azurerm_api_management_api_tag" "eslist_input" {
  provider = azurerm.apim
  api_id   = azurerm_api_management_api.eslist_input.id
  name     = "k-data"
}

# ========================================OUTPUT API======================================================

# Secret for fetchESlist Function
data "azurerm_key_vault_secret" "eslistoutputapi_func_key" {
  name         = "apim-eslistoutputapi-func-key"
  key_vault_id = data.terraform_remote_state.apim.outputs.kv_apim.id
}

# Secret for fetchArchivedESlist Funtion
data "azurerm_key_vault_secret" "eslistarchivedapi_func_key" {
  name         = "apim-eslistarchivedapi-func-key"
  key_vault_id = data.terraform_remote_state.apim.outputs.kv_apim.id
}

resource "azurerm_api_management_api" "eslist_output" {
  provider            = azurerm.apim
  name                = "kdata-eslist-app-output-api"
  resource_group_name = data.azurerm_api_management.apimanagement.resource_group_name
  api_management_name = data.azurerm_api_management.apimanagement.name
  revision            = "1"
  display_name        = "K-Data EsList APP Output API"
  path                = "kdata/eslist-app-output-api"
  protocols           = ["https"]

  import {
    content_format = "openapi+json"
    content_value  = file("${path.module}/resources/openapi.eslist-app-output-api.json")
  }
}

resource "azurerm_api_management_named_value" "eslist_output-prides" {
  provider            = azurerm.apim
  resource_group_name = azurerm_api_management_api.eslist_output.resource_group_name
  api_management_name = azurerm_api_management_api.eslist_output.api_management_name
  name                = "${azurerm_api_management_api.eslist_output.name}-secret"
  display_name        = "${azurerm_api_management_api.eslist_output.name}-secret"
  value               = data.azurerm_key_vault_secret.eslistoutputapi_func_key.value
  secret              = true
}

resource "azurerm_api_management_named_value" "eslist_output-archived" {
  provider            = azurerm.apim
  resource_group_name = azurerm_api_management_api.eslist_output.resource_group_name
  api_management_name = azurerm_api_management_api.eslist_output.api_management_name
  name                = "${azurerm_api_management_api.eslist_output.name}archived-secret"
  display_name        = "${azurerm_api_management_api.eslist_output.name}archived-secret"
  value               = data.azurerm_key_vault_secret.eslistarchivedapi_func_key.value
  secret              = true
}

resource "azurerm_api_management_api_policy" "eslist_output" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.eslist_output.name
  api_management_name = azurerm_api_management_api.eslist_output.api_management_name
  resource_group_name = azurerm_api_management_api.eslist_output.resource_group_name

  xml_content = <<XML
<policies>
    <inbound>
        <base />
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>
  XML
}

resource "azurerm_api_management_api_operation_policy" "eslist_output-prides" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.eslist_output.name
  api_management_name = azurerm_api_management_api.eslist_output.api_management_name
  resource_group_name = azurerm_api_management_api.eslist_output.resource_group_name
  operation_id        = "get-prides"

  xml_content = <<XML
<policies>
    <inbound>
        <base />
        <authentication-managed-identity resource="${data.terraform_remote_state.ad.outputs.sp_apim_authentication.application_id}" />
        <set-header name="x-functions-key" exists-action="override">
            <value>{{${azurerm_api_management_named_value.eslist_output-prides.name}}}</value>
        </set-header>
        <set-backend-service base-url="https://${azurerm_linux_function_app.eslistfetch.default_hostname}/api/fetchESlist" />
        <rewrite-uri template="/" />
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>
XML
}

resource "azurerm_api_management_api_operation_policy" "eslist_output-archiveddata" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.eslist_output.name
  api_management_name = azurerm_api_management_api.eslist_output.api_management_name
  resource_group_name = azurerm_api_management_api.eslist_output.resource_group_name
  operation_id        = "get-archiveddata"

  xml_content = <<XML
<policies>
    <inbound>
        <base />
        <authentication-managed-identity resource="${data.terraform_remote_state.ad.outputs.sp_apim_authentication.application_id}" />
        <set-header name="x-functions-key" exists-action="override">
            <value>{{${azurerm_api_management_named_value.eslist_output-archived.name}}}</value>
        </set-header>
        <set-backend-service base-url="https://${azurerm_linux_function_app.eslistfetch.default_hostname}/api/fetchArchivedESlist" />
        <rewrite-uri template="/" />
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>
XML
}


resource "azurerm_api_management_product" "eslist_output" {
  provider              = azurerm.apim
  product_id            = "${azurerm_api_management_api.eslist_output.name}-product"
  api_management_name   = azurerm_api_management_api.eslist_output.api_management_name
  resource_group_name   = azurerm_api_management_api.eslist_output.resource_group_name
  display_name          = azurerm_api_management_api.eslist_output.display_name
  subscriptions_limit   = 0
  subscription_required = true
  approval_required     = false
  published             = true
}

resource "azurerm_api_management_product_api" "eslist_output" {
  provider            = azurerm.apim
  api_management_name = azurerm_api_management_api.eslist_output.api_management_name
  resource_group_name = azurerm_api_management_api.eslist_output.resource_group_name
  api_name            = azurerm_api_management_api.eslist_output.name
  product_id          = azurerm_api_management_product.eslist_output.product_id
}

resource "azurerm_api_management_product_group" "eslist_output" {
  provider            = azurerm.apim
  api_management_name = azurerm_api_management_api.eslist_output.api_management_name
  resource_group_name = azurerm_api_management_api.eslist_output.resource_group_name
  product_id          = azurerm_api_management_product.eslist_output.product_id
  group_name          = "620f8774b135c7106b3f8689"
}

resource "azurerm_api_management_api_tag" "eslist_output" {
  provider = azurerm.apim
  api_id   = azurerm_api_management_api.eslist_output.id
  name     = "k-data"
}
