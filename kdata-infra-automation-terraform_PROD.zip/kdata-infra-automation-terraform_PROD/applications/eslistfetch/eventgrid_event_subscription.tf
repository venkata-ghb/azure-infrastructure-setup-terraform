resource "azurerm_eventgrid_event_subscription" "sa_adls-eslistqueueevent" {
  name  = "eslistqueueevent"
  scope = data.terraform_remote_state.integrations.outputs.sa_adls.id

  storage_queue_endpoint {
    storage_account_id = azurerm_storage_account.eslistfasa.id
    queue_name         = azurerm_storage_queue.eslistfasa-eslistqueue.name
  }
  subject_filter {
    subject_begins_with = "/blobServices/default/containers/raw/blobs/natural/PRIDES/Prides/"
    subject_ends_with   = ".json"
  }
}
