resource "azurerm_cosmosdb_account" "cosmosdb_acc" {
  name                      = "${var.prefix}-cosmosdb-acc"
  location                  = var.location
  resource_group_name       = data.terraform_remote_state.integrations.outputs.rg_cosmos.name
  offer_type                = "Standard"
  kind                      = "GlobalDocumentDB"
  enable_automatic_failover = false

  consistency_policy {
    consistency_level = "Eventual"
  }

  capabilities {
    name = "EnableServerless"
  }

  geo_location {
    failover_priority = 0
    location          = "westeurope"
    zone_redundant    = false
  }

  virtual_network_rule {
    id                                   = data.terraform_remote_state.vnets.outputs.subnet_funcapp_int.id
    ignore_missing_vnet_service_endpoint = true
  }

  /*  TERRAFORM CANNOT MANAGE THIS DUE TO NO ACCESS TO THE SUBNET 
   virtual_network_rule {
     id                                   = "/subscriptions/44ee698c-13cb-4e38-8a00-5a2cb8abb6d0/resourceGroups/Kesko_WE_RG_INTEGRATION_SERVICES_VNET-001/providers/Microsoft.Network/virtualNetworks/INTEGRATION_SERVICES_VNET1_WE/subnets/Kesko_WE_SN_integration_services_test001"
     ignore_missing_vnet_service_endpoint = true
   }
   */

  ip_range_filter = join(",", [
    "131.207.242.128",
    "115.110.104.174",
    "104.42.195.92",
    "40.76.54.131",
    "52.176.6.30",
    "52.169.50.45",
    "52.187.184.26",
    "52.178.79.163",
    "51.136.23.153",
    "40.68.112.57",
    "40.68.116.140",
    "13.95.22.106",
    "51.144.3.140",
    "51.145.152.217",
    "52.178.92.96",
    "51.144.224.93",
    "52.232.70.142",
    "52.232.4.132",
    "52.232.64.246",
    "51.145.159.13",
    "52.136.236.15",
    "40.74.27.172",
    "40.74.24.233",
    "40.74.27.38",
    "40.74.27.161",
    "13.69.67.192/28",
    "13.69.107.112/28",
    "13.69.112.128/28",
    "20.105.215.28/30",
    "40.74.24.192/26",
    "40.74.26.0/23",
    "40.113.176.232/29",
    "52.236.187.112/28",
    "20.126.245.27/32"
  ])
  is_virtual_network_filter_enabled = true

  tags = local.resource_tags
}

resource "azurerm_cosmosdb_sql_database" "cosmosdb_acc-eslist_db" {
  name                = "eslist-db"
  resource_group_name = azurerm_cosmosdb_account.cosmosdb_acc.resource_group_name
  account_name        = azurerm_cosmosdb_account.cosmosdb_acc.name
}

resource "azurerm_cosmosdb_sql_container" "cosmosdb_acc-eslist_db-eslist_prides" {
  name                = "eslist-prides"
  resource_group_name = azurerm_cosmosdb_account.cosmosdb_acc.resource_group_name
  account_name        = azurerm_cosmosdb_account.cosmosdb_acc.name
  database_name       = azurerm_cosmosdb_sql_database.cosmosdb_acc-eslist_db.name
  partition_key_path  = "/delivery_date_store"

  indexing_policy {
    indexing_mode = "consistent"

    included_path {
      path = "/*"
    }

    composite_index {
      index {
        path  = "/consignor_name"
        order = "Ascending"
      }
      index {
        path  = "/document_id"
        order = "Ascending"
      }
      index {
        path  = "/vendor_establishment_id"
        order = "Ascending"
      }
      index {
        path  = "/delivery_date_store"
        order = "Ascending"
      }
      index {
        path  = "/document_date"
        order = "Ascending"
      }
      index {
        path  = "/items/batch_number"
        order = "Ascending"
      }
    }
  }
}

resource "azurerm_cosmosdb_sql_container" "cosmosdb_acc-eslist_db-k_data_product" {
  name                = "K-Data-Product"
  resource_group_name = azurerm_cosmosdb_account.cosmosdb_acc.resource_group_name
  account_name        = azurerm_cosmosdb_account.cosmosdb_acc.name
  database_name       = azurerm_cosmosdb_sql_database.cosmosdb_acc-eslist_db.name
  partition_key_path  = "/TransportUnitEANCD"

  indexing_policy {
    indexing_mode = "consistent"

    included_path {
      path = "/*"
    }

    composite_index {
      index {
        path  = "/delivery_pty_id"
        order = "Ascending"
      }
      index {
        path  = "/delivery_date_store"
        order = "Ascending"
      }
      index {
        path  = "/document_id"
        order = "Ascending"
      }
    }
  }
}

resource "azurerm_cosmosdb_sql_container" "cosmosdb_acc-eslist_db-enrich_esList" {
  name                = "Enrich-ESList"
  resource_group_name = azurerm_cosmosdb_account.cosmosdb_acc.resource_group_name
  account_name        = azurerm_cosmosdb_account.cosmosdb_acc.name
  database_name       = azurerm_cosmosdb_sql_database.cosmosdb_acc-eslist_db.name
  partition_key_path  = "/document_id"

  indexing_policy {
    indexing_mode = "consistent"

    included_path {
      path = "/*"
    }

    composite_index {
      index {
        path  = "/delivery_pty_id"
        order = "Ascending"
      }
      index {
        path  = "/delivery_date_store"
        order = "Ascending"
      }
      index {
        path  = "/document_id"
        order = "Ascending"
      }
    }
    composite_index {
      index {
        path  = "/delivery_date_store"
        order = "Ascending"
      }
      index {
        path  = "/sender_name"
        order = "Ascending"
      }
    }
  }
}

resource "azurerm_cosmosdb_sql_container" "cosmosdb_acc-eslist_db-leases" {
  name                = "leases"
  resource_group_name = azurerm_cosmosdb_account.cosmosdb_acc.resource_group_name
  account_name        = azurerm_cosmosdb_account.cosmosdb_acc.name
  database_name       = azurerm_cosmosdb_sql_database.cosmosdb_acc-eslist_db.name
  partition_key_path  = "/id"

  indexing_policy {
    indexing_mode = "consistent"

    included_path {
      path = "/*"
    }
  }
}

resource "azurerm_cosmosdb_sql_role_definition" "cosmosdb_acc-data_contributor" {
  name                = "Cosmos DB Data Contributor"
  resource_group_name = azurerm_cosmosdb_account.cosmosdb_acc.resource_group_name
  account_name        = azurerm_cosmosdb_account.cosmosdb_acc.name
  type                = "CustomRole"
  assignable_scopes   = [azurerm_cosmosdb_account.cosmosdb_acc.id]
  permissions {
    data_actions = [
      "Microsoft.DocumentDB/databaseAccounts/sqlDatabases/containers/items/*",
      "Microsoft.DocumentDB/databaseAccounts/sqlDatabases/containers/*",
      "Microsoft.DocumentDB/databaseAccounts/readMetadata"
    ]
  }
}

resource "azurerm_cosmosdb_sql_role_assignment" "cosmosdb_acc-data_contributor-adf_int" {
  resource_group_name = azurerm_cosmosdb_account.cosmosdb_acc.resource_group_name
  account_name        = azurerm_cosmosdb_account.cosmosdb_acc.name
  role_definition_id  = azurerm_cosmosdb_sql_role_definition.cosmosdb_acc-data_contributor.id
  principal_id        = data.terraform_remote_state.integrations.outputs.adf_int.msi
  scope               = azurerm_cosmosdb_account.cosmosdb_acc.id
}
