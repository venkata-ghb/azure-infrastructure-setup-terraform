resource "azurerm_monitor_action_group" "eslist" {
  name                = "${var.prefix}-eslist-integration-errors-action-group"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_app.name
  short_name          = "Eslist-err"

  tags = local.resource_tags

  email_receiver {
    name          = "DL_KESKOAMS_TCS_KDATA"
    email_address = "DL_KESKOAMS_TCS_KDATA@kesko.fi"
  }
  email_receiver {
    name          = "NicoMiettinen"
    email_address = "nico.miettinen@kesko.fi"
  }
}

resource "azurerm_monitor_metric_alert" "insights_eslistfetch-exception" {
  name                = "${var.prefix}-appsinght-eslistfetch-exception-alert"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_app.name
  scopes              = [azurerm_application_insights.eslistfetch.id]
  description         = "Eslistfetch Function app Exception"
  auto_mitigate       = false
  frequency           = "PT15M"
  window_size         = "PT15M"
  severity            = 0

  criteria {
    metric_namespace = "Microsoft.Insights/Components"
    metric_name      = "exceptions/count"
    aggregation      = "Count"
    operator         = "GreaterThan"
    threshold        = 0
  }

  action {
    action_group_id = azurerm_monitor_action_group.eslist.id
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_metric_alert" "insights_eslistfetch-failed_req" {
  name                = "${var.prefix}-appsinght-eslistfetch-failerreq-alert"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_app.name
  scopes              = [azurerm_application_insights.eslistfetch.id]
  description         = "Eslistfetch Function app Failed Request"
  auto_mitigate       = false
  frequency           = "PT15M"
  window_size         = "PT15M"
  severity            = 0

  criteria {
    metric_namespace = "Microsoft.Insights/Components"
    metric_name      = "exceptions/count"
    aggregation      = "Count"
    operator         = "GreaterThan"
    threshold        = 0
  }

  action {
    action_group_id = azurerm_monitor_action_group.eslist.id
  }

  tags = local.resource_tags
}

# ------------
#TO-DO : Rename alerts to kdata-prod-* instead of kdata-dev-*. Currently unable to rename as Terraform doesn't have destroy resource permissions

## SETUP ACTION GROUP

resource "azurerm_monitor_action_group" "eslistapp" {
  name                = "${var.prefix}-eslistapp-integration-errors-action-group"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  short_name          = "Eslst-err"

  tags = local.resource_tags

  email_receiver {
    name          = "DL_KESKOAMS_TCS_KDATA"
    email_address = "DL_KESKOAMS_TCS_KDATA@kesko.fi"
  }
  email_receiver {
    name          = "NicoMiettinen"
    email_address = "nico.miettinen@kesko.fi"
  }
}

## ALERTS FOR ESLIST FUNC APP

resource "azurerm_monitor_metric_alert" "insights_eslist-exception" {
  name                = "${var.prefix}-appsinght-eslist-exception-alert"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  scopes              = [azurerm_application_insights.eslist.id]
  description         = "Eslist Production Function app Exception"
  auto_mitigate       = false
  frequency           = "PT15M"
  window_size         = "PT15M"
  severity            = 0

  criteria {
    metric_namespace = "Microsoft.Insights/Components"
    metric_name      = "exceptions/count"
    aggregation      = "Count"
    operator         = "GreaterThan"
    threshold        = 0

  }

  action {
    action_group_id = azurerm_monitor_action_group.eslistapp.id
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_metric_alert" "insights_eslist-failed_req" {
  name                = "${var.prefix}-appsinght-eslist-failerreq-alert"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  scopes              = [azurerm_application_insights.eslist.id]
  description         = "Eslist Production Function app Failed Request"
  auto_mitigate       = false
  frequency           = "PT15M"
  window_size         = "PT15M"
  severity            = 0

  criteria {
    metric_namespace = "Microsoft.Insights/Components"
    metric_name      = "exceptions/count"
    aggregation      = "Count"
    operator         = "GreaterThan"
    threshold        = 0

  }

  action {
    action_group_id = azurerm_monitor_action_group.eslistapp.id
  }

  tags = local.resource_tags


}

resource "azurerm_monitor_metric_alert" "insights_eslist-no_flow" {
  name                = "${var.prefix}-appsinght-eslist-no-flow-alert"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  scopes              = [azurerm_application_insights.eslist.id]
  description         = "Eslist No-flow message alert"
  auto_mitigate       = false
  frequency           = "PT30M"
  window_size         = "PT30M"
  severity            = 0

  criteria {
    metric_namespace = "Microsoft.Insights/Components"
    metric_name      = "traces/count"
    aggregation      = "Count"
    operator         = "LessThan"
    threshold        = 1
  }

  action {
    action_group_id = azurerm_monitor_action_group.eslist.id
  }
  tags = local.resource_tags
}


## ALERTS FOR ESLIST enrich FUNC APP

resource "azurerm_monitor_metric_alert" "insights_eslistenrich-exception" {
  name                = "${var.prefix}-appsinght-eslistenrich-exception-alert"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  scopes              = [azurerm_application_insights.enrich_eslist.id]
  description         = "Eslist Production Enrich Function app Exception"
  auto_mitigate       = false
  frequency           = "PT15M"
  window_size         = "PT15M"
  severity            = 0

  criteria {
    metric_namespace = "Microsoft.Insights/Components"
    metric_name      = "exceptions/count"
    aggregation      = "Count"
    operator         = "GreaterThan"
    threshold        = 0

  }

  action {
    action_group_id = azurerm_monitor_action_group.eslistapp.id
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_metric_alert" "insights_eslistenrich-failed_req" {
  name                = "${var.prefix}-appsinght-eslistenrich-failerreq-alert"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  scopes              = [azurerm_application_insights.enrich_eslist.id]
  description         = "Eslist Production Enrich Function app Failed Request"
  auto_mitigate       = false
  frequency           = "PT15M"
  window_size         = "PT15M"
  severity            = 0

  criteria {
    metric_namespace = "Microsoft.Insights/Components"
    metric_name      = "exceptions/count"
    aggregation      = "Count"
    operator         = "GreaterThan"
    threshold        = 0

  }

  action {
    action_group_id = azurerm_monitor_action_group.eslistapp.id
  }

  tags = local.resource_tags
}

## SUPPRESSING ESLIST NO FLOW ALERTS ON WEEKENDS

resource "azurerm_monitor_alert_processing_rule_suppression" "insights_eslist-no_flow_suppression" {
  name                = "${var.prefix}-appsinght-eslist-no-flow-alert_suppression"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  scopes              = [azurerm_application_insights.eslist.id]
  tags                = local.resource_tags
  
  condition {
    alert_rule_name {
      operator = "Equals"
      values   = [azurerm_monitor_metric_alert.insights_eslist-no_flow.name]
    }
  }

  schedule {
    effective_from  = "2023-04-28T00:00:00"
    time_zone       = "E. Europe Standard Time"
    recurrence {
      weekly {
        days_of_week = ["Saturday", "Sunday"]
      }
    }
  }
  
}
