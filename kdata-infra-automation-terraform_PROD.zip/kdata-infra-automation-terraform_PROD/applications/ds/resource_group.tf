resource "azurerm_resource_group" "ds" {
  name     = "${local.prefix_rg}_DIGITALSIGN_Main_RG"
  location = local.location.long
  tags     = local.resource_tags
}
