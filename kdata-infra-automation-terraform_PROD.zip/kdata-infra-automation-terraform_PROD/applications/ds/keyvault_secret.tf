resource "azurerm_key_vault_secret" "ds-sp_ds_deltalake_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_ds_deltalake.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_ds_deltalake_password
  key_vault_id = azurerm_key_vault.ds.id
  content_type = "${data.terraform_remote_state.ad.outputs.sp_ds_deltalake.display_name} SP's Password by Terraform"
  tags         = local.resource_tags
}
