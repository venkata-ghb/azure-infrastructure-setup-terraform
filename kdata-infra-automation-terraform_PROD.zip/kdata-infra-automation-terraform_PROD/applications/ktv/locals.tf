locals {
  resource_tags = merge(data.terraform_remote_state.common.outputs.resource_tags, {
    SubApplication = "KTV"
  })
  msi_infra_key_vault_access = data.terraform_remote_state.common.outputs.msi_infra_key_vault_access
}