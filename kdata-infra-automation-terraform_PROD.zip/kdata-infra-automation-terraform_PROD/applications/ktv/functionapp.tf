#----------------------------------------------------Application Insights--------------------------------------------

resource "azurerm_application_insights" "ktv" {
  name                = "${data.terraform_remote_state.common.outputs.prefix}-${data.terraform_remote_state.common.outputs.location.short}-ktv-funcapp"
  location            = data.terraform_remote_state.common.outputs.location.long
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  application_type    = "web"
  retention_in_days   = 90
  sampling_percentage = 0
  tags                = local.resource_tags

  lifecycle {
    ignore_changes = [ workspace_id ]
  }
}


#--------------------------------------------------Function App-------------------------------------------------
resource "azurerm_function_app" "ktv" {
  name                       = "${data.terraform_remote_state.common.outputs.prefix}-${data.terraform_remote_state.common.outputs.location.short}-ktv-funcapp"
  location                   = data.terraform_remote_state.common.outputs.location.long
  resource_group_name        = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  app_service_plan_id        = replace(data.terraform_remote_state.integrations.outputs.service_plan_int_premium.id, "serverFarm", "serverfarm")
  storage_account_name       = azurerm_storage_account.ktvfuncapp.name
  storage_account_access_key = azurerm_storage_account.ktvfuncapp.primary_access_key
  os_type                    = "linux"
  https_only                 = true
  version                    = "~4"
  tags                       = local.resource_tags

  identity {
    type = "SystemAssigned"
  }

  site_config {
    linux_fx_version          = "python|3.11"
    use_32_bit_worker_process = false
    ftps_state                = "Disabled"
    always_on                 = true
  }

  app_settings = {
    ADLS_CONTAINER                                     = "raw"
    ADLS_NAME                                          = "${data.terraform_remote_state.common.outputs.prefix_sa}adls"
    ADLS_PATH                                          = "natural/KRUOKAKAUPPA/stage/ProductGroups/"
    CONNECTION_STRING                                  = "@Microsoft.KeyVault(SecretUri=https://kdata-${data.terraform_remote_state.common.outputs.environment.short}-ktv-kv.vault.azure.net/secrets/kruokakauppa-sb-product-groups-primary-kdata-conn-string)"
    CONNECTION_STRING_NIELSENCOMMITMENT                = "@Microsoft.KeyVault(SecretUri=https://kdata-${data.terraform_remote_state.common.outputs.environment.short}-ktv-kv.vault.azure.net/secrets/kruokakauppa-sb-nielsen-commitment-primary-kdata-conn-string)"
    CONNECTION_STRING_MAINCOMPETITOR                   = "@Microsoft.KeyVault(SecretUri=https://kdata-${data.terraform_remote_state.common.outputs.environment.short}-ktv-kv.vault.azure.net/secrets/kruokakauppa-sb-main-competitor-kdata-conn-string)"
    CONNECTION_STRING_IMPORTANTCOMPETITORS             = "@Microsoft.KeyVault(SecretUri=https://kdata-${data.terraform_remote_state.common.outputs.environment.short}-ktv-kv.vault.azure.net/secrets/kruokakauppa-sb-important-competitors-kdata-conn-string)"
    CONNECTION_STRING_COMPETITORASSESSMENTSTATUS       = "@Microsoft.KeyVault(SecretUri=https://kdata-${data.terraform_remote_state.common.outputs.environment.short}-ktv-kv.vault.azure.net/secrets/kruokakauppa-sb-competitor-assessment-status-kdata-conn-string)"
    CONNECTION_STRING_LOCATION_AND_CUSTOMER_BASE       = "@Microsoft.KeyVault(SecretUri=https://kdata-${data.terraform_remote_state.common.outputs.environment.short}-ktv-kv.vault.azure.net/secrets/kruokakauppa-sb-location-and-customer-base-kdata-conn-string)"
    CONNECTION_STRING_SALES_DEVELOPMENT_LANSEY_GROUPS  = "@Microsoft.KeyVault(SecretUri=https://kdata-${data.terraform_remote_state.common.outputs.environment.short}-ktv-kv.vault.azure.net/secrets/kruokakauppa-sb-sales-development-lansey-groups-kdata-conn-string)"
    CONNECTION_STRING_SALES_DEVELOPMENT_CLUSTER_GROUPS = "@Microsoft.KeyVault(SecretUri=https://kdata-${data.terraform_remote_state.common.outputs.environment.short}-ktv-kv.vault.azure.net/secrets/kruokakauppa-sb-sales-development-cluster-groups-kdata-conn-string)"
    #
    CONNECTION_STRING_APPPROGRESS                    = "@Microsoft.KeyVault(SecretUri=https://kdata-${data.terraform_remote_state.common.outputs.environment.short}-ktv-kv.vault.azure.net/secrets/kruokakauppa-sb-app-progress-kdata-conn-string)"
    CONNECTION_STRING_CAMPAIGNOBJECTIVES             = "@Microsoft.KeyVault(SecretUri=https://kdata-${data.terraform_remote_state.common.outputs.environment.short}-ktv-kv.vault.azure.net/secrets/kruokakauppa-sb-campaign-objectives-kdata-conn-string)"
    CONNECTION_STRING_DIFFERENTIATORS                = "@Microsoft.KeyVault(SecretUri=https://kdata-${data.terraform_remote_state.common.outputs.environment.short}-ktv-kv.vault.azure.net/secrets/kruokakauppa-sb-differentiators-kdata-conn-string)"
    CONNECTION_STRING_PRICEPROFILEPROPOSAL           = "@Microsoft.KeyVault(SecretUri=https://kdata-${data.terraform_remote_state.common.outputs.environment.short}-ktv-kv.vault.azure.net/secrets/kruokakauppa-sb-price-profile-proposal-kdata-conn-string)"
    CONNECTION_STRING_PRODUCTGROUPCAMPAIGNOBJECTIVES = "@Microsoft.KeyVault(SecretUri=https://kdata-${data.terraform_remote_state.common.outputs.environment.short}-ktv-kv.vault.azure.net/secrets/kruokakauppa-sb-product-group-campaign-objectives-kdata-conn-string)"
    CONNECTION_STRING_PRODUCTGROUPDIFFERENTIATORS    = "@Microsoft.KeyVault(SecretUri=https://kdata-${data.terraform_remote_state.common.outputs.environment.short}-ktv-kv.vault.azure.net/secrets/kruokakauppa-sb-product-group-differentiators-kdata-conn-string)"
    FUNCTIONS_WORKER_RUNTIME                         = "python"
    APPINSIGHTS_INSTRUMENTATIONKEY                   = azurerm_application_insights.ktv.instrumentation_key
    APPLICATIONINSIGHTS_CONNECTION_STRING            = azurerm_application_insights.ktv.connection_string
    FUNCTIONS_EXTENSION_VERSION                      = "~4"
    WEBSITE_ENABLE_SYNC_UPDATE_SITE                  = false
    WEBSITE_RUN_FROM_PACKAGE                         = "1"
    STORAGE_ACCOUNT_NAME                             = azurerm_storage_account.ktvfuncapp.name
  }

  lifecycle {
    ignore_changes = [
      app_settings["WEBSITE_ENABLE_SYNC_UPDATE_SITE"],
      app_settings["WEBSITE_RUN_FROM_PACKAGE"],
    ]
  }
}

resource "azurerm_app_service_virtual_network_swift_connection" "ktv-functionapp_int" {
  app_service_id = azurerm_function_app.ktv.id
  subnet_id      = data.terraform_remote_state.vnets.outputs.subnet_funcapp_int.id
}
