resource "azurerm_storage_account" "clm" {
  name                     = "${var.prefix_sa}clm"
  resource_group_name      = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  location                 = var.location
  account_tier             = "Standard"
  account_replication_type = "LRS"
  tags                     = local.resource_tags
  network_rules {
    default_action = "Allow"
    virtual_network_subnet_ids = [ "/subscriptions/0a2d289e-76dd-4b1f-b9b2-dba15a872e92/resourceGroups/rg-platform-avd-prod-weu-001/providers/Microsoft.Network/virtualNetworks/vnet-avd-prod-weu-001/subnets/Subnet-AVDTCS-AMS-prod-weu" ]
  }
}

resource "azurerm_storage_queue" "clm-trigger_queue" {
  name                 = "trigger-queue"
  storage_account_name = azurerm_storage_account.clm.name
}

resource "azurerm_storage_queue" "clm-trigger_queue_poison" {
  name                 = "trigger-queue-poison"
  storage_account_name = azurerm_storage_account.clm.name
}

resource "azurerm_storage_container" "clm-poison_container" {
  name                  = "poison-messages"
  storage_account_name  = azurerm_storage_account.clm.name
  container_access_type = "private"
}