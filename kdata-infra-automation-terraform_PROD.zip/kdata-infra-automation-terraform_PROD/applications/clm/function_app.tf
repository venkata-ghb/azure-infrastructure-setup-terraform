data "azurerm_app_service_plan" "kdata-prod-we-int_premium-func_plan" {
  name                = "${var.prefix}-we-int_premium-func_plan"
  resource_group_name = var.rg_fa
}


resource "azurerm_function_app" "clm" {
  name                       = "${var.prefix}-we-clm-funcapp"
  location                   = var.location
  resource_group_name        = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  app_service_plan_id        = data.azurerm_app_service_plan.kdata-prod-we-int_premium-func_plan.id
  storage_account_name       = azurerm_storage_account.clm.name
  storage_account_access_key = azurerm_storage_account.clm.primary_access_key
  os_type                    = "linux"
  https_only                 = true
  version                    = "~4"
  tags                       = local.resource_tags

  identity {
    type = "SystemAssigned"
  }

  site_config {
    linux_fx_version          = "PYTHON|3.11"
    use_32_bit_worker_process = false
    ftps_state                = "Disabled"
    always_on                 = true
  }

  app_settings = {
    FUNCTIONS_WORKER_RUNTIME                      = "python"
    APPINSIGHTS_INSTRUMENTATIONKEY                = azurerm_application_insights.clm.instrumentation_key
    APPLICATIONINSIGHTS_CONNECTION_STRING         = azurerm_application_insights.clm.connection_string
    FUNCTIONS_EXTENSION_VERSION                   = "~4"
    WEBSITE_ENABLE_SYNC_UPDATE_SITE               = false
    WEBSITE_RUN_FROM_PACKAGE                      = "ThisWillBeSetToAnURLByAzureDevOpsDeploy", // managed by Azure DevOps (must be not null)
    ADLS_PATH                                     = "raw/natural/CLM/stage/LoyaltyTransaction",
    ADLS_NAME                                     = "kdataprodadls"
    DEVIATION_FROM_UTC_IN_MINUTES                 = -120
    QUEUE_NAME                                    = azurerm_storage_queue.clm-trigger_queue.name
    QUEUE_ACCOUNT_NAME                            = azurerm_storage_account.clm.name
    POISON_STORAGE_CONTAINER                      = azurerm_storage_container.clm-poison_container.name
    POISON_STORAGE_NAME                           = azurerm_storage_account.clm.name
    MESSAGE_BATCH_SIZE                            = 100
    MESSAGE_VISIBILITY_TIMEOUT                    = 300
    MAX_BATCH_SIZE                                = 50
    SLEEP_TIME_SECONDS                            = 60
    eventhubName                                  = "evh-leh-transaction-prod"
    ehconsumerGroup                               = "evhcg-leh-kdatatransaction-prod"
    EventHubConnection__fullyQualifiedNamespace   = "evhns-leh-ClmEvents-prod.servicebus.windows.net"
  }


  lifecycle {
    ignore_changes = [
      app_settings["WEBSITE_ENABLE_SYNC_UPDATE_SITE"],
      app_settings["WEBSITE_RUN_FROM_PACKAGE"],
    ]
  }
}

resource "azurerm_application_insights" "clm" {
  name                = "${var.prefix}-we-clm-funcapp"
  location            = var.location
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  application_type    = "web"
  retention_in_days   = 90
  sampling_percentage = 0
  tags                = local.resource_tags

  lifecycle {
    ignore_changes = [ workspace_id ]
  }
}

resource "azurerm_app_service_virtual_network_swift_connection" "clm-functionapp_int" {
  app_service_id      = azurerm_function_app.clm.id
  subnet_id           = data.terraform_remote_state.core.outputs.subnet_funcapp_int.id
}
