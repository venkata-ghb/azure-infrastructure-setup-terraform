resource "azurerm_role_assignment" "sa_clm_trigger_queue-queue_data_sender-sp_eg_sa" {
  scope                = azurerm_storage_account.clm.id
  role_definition_name = "Storage Queue Data Message Sender"
  principal_id         = data.terraform_remote_state.integrations.outputs.sa_eg_system_topic.identity[0].principal_id
}

# CLM Function app will need this when using SDK to process the queue with RBAC Authentication
resource "azurerm_role_assignment" "sa_clm-queue_data_processor-sp_funcapp_clm" {
  scope                = azurerm_storage_account.clm.id
  role_definition_name = "Storage Queue Data Message Processor"
  principal_id         = azurerm_function_app.clm.identity[0].principal_id
}

# CLM Function app will need this when using SDK to process the poison messages
resource "azurerm_role_assignment" "sa_clm_poison_messages-blob_data_contributor-sp_funcapp_clm" {
  scope                = azurerm_storage_account.clm.id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azurerm_function_app.clm.identity[0].principal_id
}

resource "azurerm_role_assignment" "sa_clm-blob_data_contributor-group_devops_platform" {
  scope                = azurerm_storage_account.clm.id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
}

resource "azurerm_role_assignment" "sa_clm-queue_data_contributor-group_devops_platform" {
  scope                = azurerm_storage_account.clm.id
  role_definition_name = "Storage Queue Data Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
}
