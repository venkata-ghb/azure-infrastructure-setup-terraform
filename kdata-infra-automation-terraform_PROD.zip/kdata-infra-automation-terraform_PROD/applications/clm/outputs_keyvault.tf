output "kv_clm" {
  value = {
    id        = azurerm_key_vault.clm.id
    name      = azurerm_key_vault.clm.name
    vault_uri = azurerm_key_vault.clm.vault_uri
  }
}
