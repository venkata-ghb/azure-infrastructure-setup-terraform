terraform {
  backend "azurerm" {}
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "=3.20.0"
    }
  }
  required_version = "= 1.12.0"
}

provider "azurerm" {
  skip_provider_registration = true
  storage_use_azuread        = true
  features {}
}

provider "azurerm" {
  alias                      = "apim"
  subscription_id            = "44ee698c-13cb-4e38-8a00-5a2cb8abb6d0"
  storage_use_azuread        = true
  skip_provider_registration = true
  features {}
}

# Making datasource to remote state to be able to access resource from integrations module.
data "terraform_remote_state" "integrations" {
  backend = "azurerm"
  config = {
    subscription_id      = var.SUBSCRIPTION_ID
    resource_group_name  = var.TF_RG_NAME
    storage_account_name = var.TF_SA_NAME
    container_name       = var.TF_CONTAINER_NAME
    key                  = "integrations/common.terraform_PROD.tfstate"
  }
}

# Making datasource to remote state to be able to access resource from core module.
data "terraform_remote_state" "common" {
  backend = "azurerm"
  config = {
    subscription_id      = var.SUBSCRIPTION_ID
    resource_group_name  = var.TF_RG_NAME
    storage_account_name = var.TF_SA_NAME
    container_name       = var.TF_CONTAINER_NAME
    key                  = "core/common.terraform_PROD.tfstate"
  }
}

data "terraform_remote_state" "core" {
  backend = "azurerm"
  config = {
    subscription_id      = var.SUBSCRIPTION_ID
    resource_group_name  = var.TF_RG_NAME
    storage_account_name = var.TF_SA_NAME
    container_name       = var.TF_CONTAINER_NAME
    key                  = "core/vnets.terraform_PROD.tfstate"
  }
}

data "terraform_remote_state" "tfinfra" {
  backend = "azurerm"
  config = {
    subscription_id      = var.SUBSCRIPTION_ID
    resource_group_name  = var.TF_RG_NAME
    storage_account_name = var.TF_SA_NAME
    container_name       = var.TF_CONTAINER_NAME
    key                  = "core/tfinfra.terraform_PROD.tfstate"
  }
}

# List state for Ad groups
data "terraform_remote_state" "ad" {
  backend = "azurerm"
  config = {
    subscription_id      = var.SUBSCRIPTION_ID
    resource_group_name  = var.TF_RG_NAME
    storage_account_name = var.TF_SA_NAME
    container_name       = var.TF_CONTAINER_NAME
    key                  = "core/ad.terraform_PROD.tfstate"
  }
}


# List of variables passed in via pipelines

variable "SUBSCRIPTION_ID" {
  type = string
}

variable "TENANT_ID" {
  type = string
}

variable "MSI_ID" {
  type = string
}

variable "TF_SUBNET_ID" {
  type = string
}

variable "TF_RG_NAME" {
  type = string
}

variable "TF_SA_NAME" {
  type = string
}

variable "TF_CONTAINER_NAME" {
  type = string
}
