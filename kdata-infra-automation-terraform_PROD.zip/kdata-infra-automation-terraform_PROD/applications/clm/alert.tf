resource "azurerm_monitor_action_group" "clm" {
  name                = "${var.prefix}-clm-integration-errors-action-group"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  short_name          = "clm-err"

  tags = local.resource_tags

  email_receiver {
    name          = "Nico Miettinen"
    email_address = "nico.miettinen@kesko.fi"
  }

  email_receiver {
    name          = "DL_KESKOAMS_TCS_KDATA"
    email_address = "DL_KESKOAMS_TCS_KDATA@kesko.fi"
  }

}

resource "azurerm_monitor_metric_alert" "insights_clm-exception" {
  name                = "${var.prefix}-appsinght-clm-exception-alert"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  scopes              = [azurerm_application_insights.clm.id]
  description         = "clm Function app Exceptions"
  auto_mitigate       = false
  frequency           = "PT15M"
  window_size         = "PT15M"
  severity            = 0

  criteria {
    metric_namespace = "Microsoft.Insights/Components"
    metric_name      = "exceptions/count"
    aggregation      = "Count"
    operator         = "GreaterThan"
    threshold        = 0
  }

  action {
    action_group_id = azurerm_monitor_action_group.clm.id
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_metric_alert" "insights_clm-failed_req" {
  name                = "${var.prefix}-appsinght-clm-failerreq-alert"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  scopes              = [azurerm_application_insights.clm.id]
  description         = "clm Function app Failed Requests"
  auto_mitigate       = false
  frequency           = "PT15M"
  window_size         = "PT15M"
  severity            = 0

  criteria {
    metric_namespace = "Microsoft.Insights/Components"
    metric_name      = "requests/failed"
    aggregation      = "Count"
    operator         = "GreaterThan"
    threshold        = 0
  }

  action {
    action_group_id = azurerm_monitor_action_group.clm.id
  }

  tags = local.resource_tags
}


resource "azurerm_monitor_scheduled_query_rules_alert_v2" "insights_clm-poison_messages" {
  name                = "${var.prefix}-clm-poison-messages-alert"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  location            = var.location

  evaluation_frequency = "PT15M"
  window_duration      = "PT15M"
  scopes               = [azurerm_application_insights.clm.id]
  severity             = 0
  criteria {
    query                   = "traces | where message matches regex ('Uploaded ([0-9]+) poison documents for manual processing') and operation_Name =~ 'TimerTrigger' | extend poisonMessages = toint(extract('[0-9]+', 0, message)) | project timestamp, poisonMessages"
    time_aggregation_method = "Total"
    threshold               = 0
    operator                = "GreaterThan"
    metric_measure_column   = "poisonMessages"

  }

  auto_mitigation_enabled = false
  description             = "CLM poison message alert"
  enabled                 = true
  action {
    action_groups = [azurerm_monitor_action_group.clm.id]
    custom_properties = {
      email_subject = "Azure: K-Data CLM poison message alert was triggered in ${upper(var.env)}"
    }
  }
  tags = local.resource_tags
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "insights_clm-no_flow" {
  name                = "${var.prefix}-clm-no-flow-alert"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  location            = var.location

  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_application_insights.clm.id]
  severity             = 0
  criteria {
    query                   = "traces | where operation_Name == 'EventHubTrigger'"
    time_aggregation_method = "Count"
    threshold               = 1
    operator                = "LessThan"

  }

  auto_mitigation_enabled = false
  description             = "CLM No-flow message alert"
  enabled                 = true
  action {
    action_groups = [azurerm_monitor_action_group.clm.id]
    custom_properties = {
      email_subject = "Azure: K-Data CLM No flow alert was triggered in ${upper(var.env)}"
    }
  }
  tags = local.resource_tags
}
