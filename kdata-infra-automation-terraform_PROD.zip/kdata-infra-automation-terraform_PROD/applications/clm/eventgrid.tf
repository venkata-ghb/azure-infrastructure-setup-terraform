resource "azurerm_eventgrid_system_topic_event_subscription" "loyaltytransaction" {
  name                = "clm-loyaltytransaction"
  system_topic        = data.terraform_remote_state.integrations.outputs.sa_eg_system_topic.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.sa_eg_system_topic.resource_group_name

  storage_queue_endpoint {
    storage_account_id = azurerm_storage_account.clm.id
    queue_name         = azurerm_storage_queue.clm-trigger_queue.name
  }

  delivery_identity {
    type = "SystemAssigned"
  }

  subject_filter {
    subject_begins_with = "/blobServices/default/containers/raw/blobs/natural/CLM/stage/LoyaltyTransaction/"
    subject_ends_with   = ".json"
  }
    included_event_types = ["Microsoft.Storage.BlobCreated"]

  depends_on = [azurerm_role_assignment.sa_clm_trigger_queue-queue_data_sender-sp_eg_sa]
}
