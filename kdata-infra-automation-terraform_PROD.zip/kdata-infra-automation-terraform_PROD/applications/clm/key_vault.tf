locals {
  msi_kv_access_policy = {
    object_id               = data.terraform_remote_state.tfinfra.outputs.msi.principal_id
    tenant_id               = data.azurerm_client_config.current.tenant_id
    application_id          = ""
    certificate_permissions = ["Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"]
    key_permissions         = ["Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"]
    secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
    storage_permissions     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"]
  }
}

data "azurerm_client_config" "current" {}

resource "azurerm_key_vault" "clm" {
  name                        = "${var.prefix}-clm-kv"
  location                    = var.location
  resource_group_name         = data.terraform_remote_state.integrations.outputs.rg_vault.name
  enabled_for_disk_encryption = true
  tenant_id                   = data.azurerm_client_config.current.tenant_id
  purge_protection_enabled    = false
  sku_name                    = "standard"
  tags                        = local.resource_tags
  access_policy = [
    local.msi_kv_access_policy,
    {
      object_id               = data.terraform_remote_state.ad.outputs.group_admins_platform.id
      tenant_id               = "ae6e7baa-e1bf-4ef0-92a1-4eb28ec805c0"
      application_id          = ""
      certificate_permissions = ["Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"]
      key_permissions         = ["Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"]
      secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
      storage_permissions     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"]
    },
    {
      object_id               = data.terraform_remote_state.ad.outputs.group_devops_platform.id
      tenant_id               = "ae6e7baa-e1bf-4ef0-92a1-4eb28ec805c0"
      application_id          = ""
      certificate_permissions = []
      key_permissions         = []
      secret_permissions      = ["Get", "List", ]
      storage_permissions     = []
    },
    {
      object_id               = "0b76c138-ab01-423f-b0db-775b3bf5d63b" # AzureDatabricks
      tenant_id               = "ae6e7baa-e1bf-4ef0-92a1-4eb28ec805c0"
      application_id          = ""
      certificate_permissions = []
      key_permissions         = ["Get", "List", "Update", "Create", "Import", "Delete", "Recover", "Backup", "Restore", "Decrypt", "Encrypt", "UnwrapKey", "WrapKey", "Verify", "Sign", ]
      secret_permissions      = ["Get", "List", ]
      storage_permissions     = []
    }
  ]
}

resource "azurerm_key_vault_secret" "clm-sp_clm_adb_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_clm_adb.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_clm_adb_password
  key_vault_id = azurerm_key_vault.clm.id
  content_type = "${data.terraform_remote_state.ad.outputs.sp_clm_adb.display_name} SP's Password by Terraform"
}

