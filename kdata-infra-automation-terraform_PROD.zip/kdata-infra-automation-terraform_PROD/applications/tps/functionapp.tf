#----------------------------------------------------Service Plan--------------------------------------------
data "azurerm_app_service_plan" "plan" {
  name                = "kdata-prod-we-int_premium-func_plan"
  resource_group_name = var.rg_name
}

#----------------------------------------------------Application Insights--------------------------------------------

resource "azurerm_application_insights" "tps" {
  name                = "${var.prefix}-${var.loc}-tps-funcapp"
  location            = var.location
  resource_group_name = var.rg_name
  application_type    = "web"
  retention_in_days   = 90
  sampling_percentage = 0
  tags                = local.resource_tags

  lifecycle {
    ignore_changes = [ workspace_id ]
  }
}


#--------------------------------------------------Function App-------------------------------------------------
resource "azurerm_function_app" "tps" {
  name                       = "${var.prefix}-${var.loc}-tps-funcapp"
  location                   = var.location
  resource_group_name        = var.rg_name
  app_service_plan_id        = data.azurerm_app_service_plan.plan.id
  storage_account_name       = azurerm_storage_account.tpsfuncapp.name
  storage_account_access_key = azurerm_storage_account.tpsfuncapp.primary_access_key
  os_type                    = "linux"
  https_only                 = true
  version                    = "~4"
  tags                       = local.resource_tags

  identity {
    type = "SystemAssigned"
  }

  site_config {
    always_on                 = true
    linux_fx_version          = "PYTHON|3.11"
    use_32_bit_worker_process = false
    ftps_state                = "Disabled"
  }

  app_settings = {
    ADLS_CONTAINER                        = "raw"
    ADLS_NAME                             = "kdataprodadls"
    ADLS_PATH                             = "natural/TPS/stage/Products/"
    ADLS_PATH_V2                          = "natural/TPS/stage/Products_V2/"
    FUNCTIONS_WORKER_RUNTIME              = "python"
    APPINSIGHTS_INSTRUMENTATIONKEY        = azurerm_application_insights.tps.instrumentation_key
    APPLICATIONINSIGHTS_CONNECTION_STRING = azurerm_application_insights.tps.connection_string
    FUNCTIONS_EXTENSION_VERSION           = "~4"
    WEBSITE_ENABLE_SYNC_UPDATE_SITE       = false
    WEBSITES_ENABLE_APP_SERVICE_STORAGE   = true
    WEBSITE_RUN_FROM_PACKAGE              = "ThisWillBeSetToAnURLByAzureDevOpsDeploy", // managed by Azure DevOps (must be not null)
    STORAGE_ACCOUNT_NAME                  = azurerm_storage_account.tpsfuncapp.name
  }
  connection_string {
    name  = "CONNECTION_STRING"
    type  = "Custom"
    value = "@Microsoft.KeyVault(SecretUri=https://kdata-prod-tps-kv.vault.azure.net/secrets/tps-kdata-sb-connection-string)"
  }

  connection_string {
    name  = "CONNECTION_STRING_V2"
    type  = "Custom"
    value = "@Microsoft.KeyVault(SecretUri=https://kdata-prod-tps-kv.vault.azure.net/secrets/tps-kdata-sb-connection-string-v2)"
  }
  lifecycle {
    ignore_changes = [
      app_settings["WEBSITE_ENABLE_SYNC_UPDATE_SITE"],
      app_settings["WEBSITE_RUN_FROM_PACKAGE"],
    ]
  }
}
#--------------------------------------------------------------------------------------------------------

resource "azurerm_app_service_virtual_network_swift_connection" "tps_vn_connection" {
  app_service_id = azurerm_function_app.tps.id
  subnet_id      = data.terraform_remote_state.vnets.outputs.subnet_funcapp_int.id
}
