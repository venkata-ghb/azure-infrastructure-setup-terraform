# This file is maintained automatically by "terraform init".
# Manual edits may be lost in future updates.

provider "registry.terraform.io/hashicorp/azuread" {
  version     = "2.8.0"
  constraints = "2.8.0"
  hashes = [
    "h1:vMiqeU7MfI7CS1I1MylX0nywyekOKFDwPjd5j96Syb0=",
    "zh:0022ed9641444dfbbc6321f8f1837bd8b2c9be1ef962f90af8f65c5394640fd8",
    "zh:027f62f1b32e25ba5c16a0d21374b4ffd11c494d611f22df08644b4e0f365d64",
    "zh:1691f34a919f93d293cd696254bca8bc14f0de5722d57f478f7ee4e58d229171",
    "zh:5f5892f972fcae5b5ae11a74c5559c89e5d81d76be78c32702df2d1340444918",
    "zh:7d2db8708f68fc9bc164755594a94c048d5d94adc7f45204565bf218f88b40bc",
    "zh:ab36b5ce930da75c0af2d62dbf37595bf06277dea6404faf545197032445bead",
    "zh:c653ec87a167e3667ca802469e37352a8390ef30caac8851026f5bd54f467d23",
    "zh:d1d0f2a34897d9e17de732d49ced86c9ec5d7a18b6ddc8024c5a1f490f6aeffc",
    "zh:deebf7d60862bade37799f3876feae642ff7ae3672643b51bcd02b9e0c0a7105",
    "zh:e283476382c266d4885910d43f0944ae63aa8e5c0d74634a8065b60b4d269825",
    "zh:e98f7454c3bdd6d02b6110fcc9063c303ac650679a120a9c36f748d94c4d78b1",
  ]
}

provider "registry.terraform.io/hashicorp/azurerm" {
  version     = "2.77.0"
  constraints = "2.77.0"
  hashes = [
    "h1:uJe0A48URJK1csyr32Wn3iBw9YT/dJEPCxLSx5qAYtE=",
    "zh:1d28e78fbd7846c081f2665bc45ec88d1be9de1253d2f6b78e60c3cb4bf1d066",
    "zh:1d792786118129b398a6ca7645e5b0bc77175e4056b92025e5d49aabb07b850e",
    "zh:34532bf0b48abc598a3137981daad3bc5a2c7aecb4c85d11ffa244188eb34eb7",
    "zh:34b67825a340f3d14036b69e2a9d78770f6a03ee1c984662f3d2e94440bba652",
    "zh:42de9e3f84960c951f4cda335920b63ce2fd1f9d1492ddea9ea2fa1756bb4cc0",
    "zh:763d65377957401cdf711ed29a43ec703a88155be06c147663e018589f91915c",
    "zh:89a18f26998c2794fc26dfdfb5467b1a4c652030af912d61dba8673ee4bb81e8",
    "zh:bd41a582a606cfaa6ea916be4a3a8fa7b0c291393605a534fcc612401aed30a1",
    "zh:c126ef57a507f5407b71aaa7bb2c5baab573ee05ec286c9d9acb3601b35e634c",
    "zh:de2856f03635a743d7e4ebd39eac52bd0ff357d0ae2398841332ea6e2b9a6754",
    "zh:ee7727ccadb4acb377d5a6a5cbfa56eda484ceaa91b4e54830044ffaeb638c06",
  ]
}

provider "registry.terraform.io/hashicorp/random" {
  version     = "2.2.0"
  constraints = "2.2.0"
  hashes = [
    "h1:ercaHmYLPJpkQmoth2lAxKYsHaaClBb7ZSyweGRaA4Q=",
    "zh:06d3dfa5f79dd6040a4d3a047ed0b28bde3595bac95613066eb041f76b658147",
    "zh:0ba963716e97856c6cd554441dbac38d8f3da023bb419257e628680d4ef6399b",
    "zh:137edbb5548be47742dda03350eb33e5589b4de998d4710b48752edd6d11fd7e",
    "zh:1640cd1f4fde01ce47d2f866849b540f07fb190de8e3412c27eadedbc94b25b0",
    "zh:19e380b1d62bcdfc2627baeba8f908ddd7c9523a19a540ce11685e4bf9648f78",
    "zh:24cb3cba92601c9100f1916e49709b75fb637f480a155af67c37b35f85169c02",
    "zh:43dab180be2ce64304a8dd37cb035eef9982f26c30f38cd21bc57929354d7dba",
    "zh:64dd912666ca91c365efb3b581a8f57fe8256bab413581eacd5017a9d0cce052",
    "zh:9f19c6070eebc089563d12f3b3e93f720669e60830c4e45eeb37d342a6ed78ad",
    "zh:ab31c1ca6a3b00efceac8330b3b893706175cacde1595379acf16b7ef3b258f9",
    "zh:d7fc4b241d40e520d11b1fd9a352a16dce91289f9c80309bf03bff11b4e31734",
    "zh:f5e87aaee01e3d4d990611c7a3e1170dbccbb48346d2267e9b13360d1293c19d",
  ]
}
