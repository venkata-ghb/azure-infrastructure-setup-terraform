# ==============================================================================
# Function app
# ==============================================================================
resource "azurerm_role_assignment" "funcapp_labvantage-contributor-group_devops_platform" {
  scope                = azurerm_linux_function_app.labvantage.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
}

# ==============================================================================
# Application insight
# ==============================================================================
resource "azurerm_role_assignment" "appinsights_labvantage-reader-group_devops_platform" {
  scope                = azurerm_application_insights.labvantage.id
  role_definition_name = "Reader"
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
}


# ==============================================================================
# Storage account
# ==============================================================================
resource "azurerm_role_assignment" "sa_labvantage-contributor-group_devops_platform" {
  scope                = azurerm_storage_account.labvantage.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
}
