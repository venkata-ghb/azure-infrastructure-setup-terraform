resource "azurerm_monitor_action_group" "labvantage" {
  name                = "${local.prefix}-labvantage-integration-errors-action-group"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_app.name
  short_name          = "Labv-err"

  tags = local.resource_tags

  lifecycle {
    ignore_changes = [email_receiver]
  }
}

resource "azurerm_monitor_metric_alert" "insights_labvantage-failed_req" {
  name                = "${local.prefix}-appsinght-labvantage-failerreq-alert"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_app.name
  scopes              = [azurerm_application_insights.labvantage.id]
  description         = "Labvantage Function app Failed Request"
  auto_mitigate       = false
  frequency           = "PT15M"
  window_size         = "PT15M"
  severity            = 0

  criteria {
    metric_namespace = "Microsoft.Insights/Components"
    metric_name      = "exceptions/count"
    aggregation      = "Count"
    operator         = "GreaterThan"
    threshold        = 0
  }

  action {
    action_group_id = azurerm_monitor_action_group.labvantage.id
  }

  tags = local.resource_tags
}

