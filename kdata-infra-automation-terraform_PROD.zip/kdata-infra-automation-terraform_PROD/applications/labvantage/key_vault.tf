data "azurerm_client_config" "current" {}

locals {
  msi_kv_access_policy = {
    object_id               = data.terraform_remote_state.tfinfra.outputs.msi.principal_id
    tenant_id               = data.azurerm_client_config.current.tenant_id
    application_id          = ""
    certificate_permissions = ["Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"]
    key_permissions         = ["Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"]
    secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
    storage_permissions     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"]
  }
}

resource "azurerm_key_vault" "labvantage" {
  name                        = "${local.prefix}-labvantage-kv"
  location                    = local.location.long
  resource_group_name         = data.terraform_remote_state.integrations.outputs.rg_vault.name
  tenant_id                   = data.azurerm_client_config.current.tenant_id
  sku_name                    = "standard"
  enabled_for_disk_encryption = true
  purge_protection_enabled    = false
  tags                        = local.resource_tags

  access_policy = [local.msi_kv_access_policy]

  lifecycle {
    ignore_changes = [access_policy]
  }
}

resource "azurerm_key_vault_access_policy" "labvantage-sp_terraforminfra" {
  key_vault_id = azurerm_key_vault.labvantage.id
  tenant_id    = local.msi_kv_access_policy.tenant_id
  object_id    = local.msi_kv_access_policy.object_id

  certificate_permissions = local.msi_kv_access_policy.certificate_permissions
  key_permissions         = local.msi_kv_access_policy.key_permissions
  secret_permissions      = local.msi_kv_access_policy.secret_permissions
  storage_permissions     = local.msi_kv_access_policy.storage_permissions
}

resource "azurerm_key_vault_access_policy" "labvantage-group_admins_platform" {
  key_vault_id = azurerm_key_vault.labvantage.id
  tenant_id    = data.azurerm_client_config.current.tenant_id
  object_id    = data.terraform_remote_state.ad.outputs.group_admins_platform.id

  certificate_permissions = ["Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"]
  key_permissions         = ["Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"]
  secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
  storage_permissions     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"]
}

resource "azurerm_key_vault_access_policy" "labvantage-funcapp_labvantage" {
  key_vault_id = azurerm_key_vault.labvantage.id
  tenant_id    = data.azurerm_client_config.current.tenant_id
  object_id    = azurerm_linux_function_app.labvantage.identity.0.principal_id

  certificate_permissions = []
  key_permissions         = []
  secret_permissions      = ["Get", ]
  storage_permissions     = []
}
