resource "azurerm_linux_function_app" "labvantage" {
  name                        = "${local.prefix}-${local.location.short}-labvantage-funcapp"
  location                    = local.location.long
  resource_group_name         = data.terraform_remote_state.integrations.outputs.rg_functionapp_app.name
  service_plan_id             = replace(data.terraform_remote_state.integrations.outputs.service_plan_app_premium.id, "serverFarm", "serverfarm")
  storage_account_name        = azurerm_storage_account.labvantage.name
  storage_account_access_key  = azurerm_storage_account.labvantage.primary_access_key
  https_only                  = true
  functions_extension_version = "~4"
  virtual_network_subnet_id   = data.terraform_remote_state.vnets.outputs.subnet_funcapp_app.id

  identity {
    type = "SystemAssigned"
  }

  site_config {
    ftps_state               = "Disabled"
    always_on                = true
    application_insights_key = azurerm_application_insights.labvantage.instrumentation_key
    vnet_route_all_enabled   = true

    application_stack {
      python_version = "3.11"
    }
  }

  app_settings = {
    WEBSITE_ENABLE_SYNC_UPDATE_SITE      = false
    WEBSITES_ENABLE_APP_SERVICE_STORAGE  = true
    "AzureWebJobs.http_trigger.Disabled" = 1
    KEYVAULT_NAME                        = azurerm_key_vault.labvantage.name
    SECRET_NAME                          = "labvantage-snowflake-password"
    SECRET_NAME_PRIVATEKEY               = "labvantage-snowflake-private"
    ENV                                  = "PROD"
  }

  tags = merge(local.resource_tags, {
    "hidden-link: /app-insights-resource-id"         = azurerm_application_insights.labvantage.id
    "hidden-link: /app-insights-instrumentation-key" = azurerm_application_insights.labvantage.instrumentation_key
    "hidden-link: /app-insights-conn-string"         = azurerm_application_insights.labvantage.connection_string
  })

  lifecycle {
    ignore_changes = [
      app_settings["WEBSITE_ENABLE_SYNC_UPDATE_SITE"],
      app_settings["WEBSITE_RUN_FROM_PACKAGE"],
    ]
  }
}

resource "azurerm_application_insights" "labvantage" {
  name                = "${local.prefix}-${local.location.short}-labvantage-funcapp"
  location            = local.location.long
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_app.name
  application_type    = "web"
  retention_in_days   = 90
  sampling_percentage = 0
  tags                = local.resource_tags

  lifecycle {
    ignore_changes = [ workspace_id ]
  }
}
