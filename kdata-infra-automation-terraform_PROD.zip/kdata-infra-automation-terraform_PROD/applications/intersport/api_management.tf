resource "azurerm_api_management_api" "intersport_inbound" {
  provider            = azurerm.apim
  name                = "kdata-intersport-inbound-api"
  resource_group_name = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.resource_group
  api_management_name = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.name
  revision            = "1"
  display_name        = "KDATA Intersport Inbound API"
  path                = "kdata/intersport-inbound-api"
  protocols           = ["https"]

  import {
    content_format = "openapi+json"
    content_value  = file("${path.module}/resources/openapi.intersport.json")
  }
}

resource "azurerm_api_management_api_operation_policy" "intersport_inbound-sales" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.intersport_inbound.name
  api_management_name = azurerm_api_management_api.intersport_inbound.api_management_name
  resource_group_name = azurerm_api_management_api.intersport_inbound.resource_group_name
  operation_id        = "post-sales"

  xml_content = templatefile(
    "${path.module}/resources/adls-policy.xml", {
      storage  = data.terraform_remote_state.integrations.outputs.sa_adls.name
      source   = "INTERSPORT"
      dataset  = "sales"
      filetype = "json"
  })
}

resource "azurerm_api_management_api_operation_policy" "intersport_inbound-products" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.intersport_inbound.name
  api_management_name = azurerm_api_management_api.intersport_inbound.api_management_name
  resource_group_name = azurerm_api_management_api.intersport_inbound.resource_group_name
  operation_id        = "post-products"

  xml_content = templatefile(
    "${path.module}/resources/adls-policy.xml", {
      storage  = data.terraform_remote_state.integrations.outputs.sa_adls.name
      source   = "INTERSPORT"
      dataset  = "products"
      filetype = "json"
  })
}

resource "azurerm_api_management_product" "intersport_inbound-intersport" {
  provider              = azurerm.apim
  display_name          = azurerm_api_management_api.intersport_inbound.display_name
  product_id            = "${azurerm_api_management_api.intersport_inbound.name}-intersport-product"
  api_management_name   = azurerm_api_management_api.intersport_inbound.api_management_name
  resource_group_name   = azurerm_api_management_api.intersport_inbound.resource_group_name
  subscriptions_limit   = 0
  subscription_required = true
  approval_required     = false
  published             = true
}

resource "azurerm_api_management_product_api" "intersport_inbound-intersport" {
  provider            = azurerm.apim
  product_id          = azurerm_api_management_product.intersport_inbound-intersport.product_id
  api_name            = azurerm_api_management_api.intersport_inbound.name
  api_management_name = azurerm_api_management_api.intersport_inbound.api_management_name
  resource_group_name = azurerm_api_management_api.intersport_inbound.resource_group_name
}

resource "azurerm_api_management_subscription" "intersport_inbound-intersport" {
  provider            = azurerm.apim
  api_management_name = azurerm_api_management_product.intersport_inbound-intersport.api_management_name
  resource_group_name = azurerm_api_management_product.intersport_inbound-intersport.resource_group_name
  product_id          = azurerm_api_management_product.intersport_inbound-intersport.id
  display_name        = "intersport-${azurerm_api_management_product.intersport_inbound-intersport.product_id}"
  state               = "active"
}

resource "azurerm_api_management_api_diagnostic" "intersport_inbound" {
  provider                 = azurerm.apim
  identifier               = "applicationinsights"
  api_name                 = azurerm_api_management_api.intersport_inbound.name
  api_management_name      = azurerm_api_management_product.intersport_inbound-intersport.api_management_name
  resource_group_name      = azurerm_api_management_product.intersport_inbound-intersport.resource_group_name
  api_management_logger_id = data.terraform_remote_state.apimanagement.outputs.apim_logger_kgroup_kdata_apis.id
  always_log_errors        = true
}

# ================================================================================================================
resource "azurerm_api_management_api" "intersport_tekso_inbound" {
  provider            = azurerm.apim
  name                = "kdata-intersport-tekso-inbound-api"
  resource_group_name = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.resource_group
  api_management_name = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.name
  revision            = "1"
  display_name        = "KDATA Intersport Tekso Inbound API"
  path                = "kdata/intersport/tekso-inbound-api"
  protocols           = ["https"]

  import {
    content_format = "openapi+json"
    content_value  = file("${path.module}/resources/openapi.tekso.json")
  }
}

resource "azurerm_api_management_api_operation_policy" "intersport_tekso_inbound-sales" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.intersport_tekso_inbound.name
  api_management_name = azurerm_api_management_api.intersport_tekso_inbound.api_management_name
  resource_group_name = azurerm_api_management_api.intersport_tekso_inbound.resource_group_name
  operation_id        = "post-sales"

  xml_content = templatefile(
    "${path.module}/resources/adls-policy.xml", {
      storage  = data.terraform_remote_state.integrations.outputs.sa_adls.name
      source   = "TEKSO"
      dataset  = "sales"
      filetype = "json"
  })
}

resource "azurerm_api_management_product" "intersport_tekso_inbound-intersport_tekso" {
  provider              = azurerm.apim
  display_name          = azurerm_api_management_api.intersport_tekso_inbound.display_name
  product_id            = "${azurerm_api_management_api.intersport_tekso_inbound.name}-intersport-tekso-product"
  api_management_name   = azurerm_api_management_api.intersport_tekso_inbound.api_management_name
  resource_group_name   = azurerm_api_management_api.intersport_tekso_inbound.resource_group_name
  subscriptions_limit   = 0
  subscription_required = true
  approval_required     = false
  published             = true
}

resource "azurerm_api_management_product_api" "intersport_tekso_inbound-intersport_tekso" {
  provider            = azurerm.apim
  product_id          = azurerm_api_management_product.intersport_tekso_inbound-intersport_tekso.product_id
  api_name            = azurerm_api_management_api.intersport_tekso_inbound.name
  api_management_name = azurerm_api_management_api.intersport_tekso_inbound.api_management_name
  resource_group_name = azurerm_api_management_api.intersport_tekso_inbound.resource_group_name
}

resource "azurerm_api_management_subscription" "intersport_tekso_inbound-intersport_tekso" {
  provider            = azurerm.apim
  api_management_name = azurerm_api_management_product.intersport_tekso_inbound-intersport_tekso.api_management_name
  resource_group_name = azurerm_api_management_product.intersport_tekso_inbound-intersport_tekso.resource_group_name
  product_id          = azurerm_api_management_product.intersport_tekso_inbound-intersport_tekso.id
  display_name        = "intersport_tekso-${azurerm_api_management_product.intersport_tekso_inbound-intersport_tekso.product_id}"
  state               = "active"
}

resource "azurerm_api_management_api_diagnostic" "intersport_tekso_inbound" {
  provider                 = azurerm.apim
  identifier               = "applicationinsights"
  api_name                 = azurerm_api_management_api.intersport_tekso_inbound.name
  api_management_name      = azurerm_api_management_product.intersport_tekso_inbound-intersport_tekso.api_management_name
  resource_group_name      = azurerm_api_management_product.intersport_tekso_inbound-intersport_tekso.resource_group_name
  api_management_logger_id = data.terraform_remote_state.apimanagement.outputs.apim_logger_kgroup_kdata_apis.id
  always_log_errors        = true
}

# ================================================================================================================
resource "azurerm_api_management_api" "intersport_msax_inbound" {
  provider            = azurerm.apim
  name                = "kdata-intersport-msax-inbound-api"
  resource_group_name = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.resource_group
  api_management_name = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.name
  revision            = "1"
  display_name        = "KDATA Intersport MS AX Inbound API"
  path                = "kdata/intersport/msax-inbound-api"
  protocols           = ["https"]

  import {
    content_format = "openapi+json"
    content_value  = file("${path.module}/resources/openapi.msax.json")
  }
}

resource "azurerm_api_management_api_operation_policy" "intersport_msax_inbound-sales" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.intersport_msax_inbound.name
  api_management_name = azurerm_api_management_api.intersport_msax_inbound.api_management_name
  resource_group_name = azurerm_api_management_api.intersport_msax_inbound.resource_group_name
  operation_id        = "post-sales"

  xml_content = templatefile(
    "${path.module}/resources/adls-policy.xml", {
      storage  = data.terraform_remote_state.integrations.outputs.sa_adls.name
      source   = "MSAX"
      dataset  = "sales"
      filetype = "csv"
  })
}

resource "azurerm_api_management_product" "intersport_msax_inbound-intersport_msax" {
  provider              = azurerm.apim
  display_name          = azurerm_api_management_api.intersport_msax_inbound.display_name
  product_id            = "${azurerm_api_management_api.intersport_msax_inbound.name}-intersport-msax-product"
  api_management_name   = azurerm_api_management_api.intersport_msax_inbound.api_management_name
  resource_group_name   = azurerm_api_management_api.intersport_msax_inbound.resource_group_name
  subscriptions_limit   = 0
  subscription_required = true
  approval_required     = false
  published             = true
}

resource "azurerm_api_management_product_api" "intersport_msax_inbound-intersport_msax" {
  provider            = azurerm.apim
  product_id          = azurerm_api_management_product.intersport_msax_inbound-intersport_msax.product_id
  api_name            = azurerm_api_management_api.intersport_msax_inbound.name
  api_management_name = azurerm_api_management_api.intersport_msax_inbound.api_management_name
  resource_group_name = azurerm_api_management_api.intersport_msax_inbound.resource_group_name
}

resource "azurerm_api_management_subscription" "intersport_msax_inbound-intersport_msax" {
  provider            = azurerm.apim
  api_management_name = azurerm_api_management_product.intersport_msax_inbound-intersport_msax.api_management_name
  resource_group_name = azurerm_api_management_product.intersport_msax_inbound-intersport_msax.resource_group_name
  product_id          = azurerm_api_management_product.intersport_msax_inbound-intersport_msax.id
  display_name        = "intersport_msax-${azurerm_api_management_product.intersport_msax_inbound-intersport_msax.product_id}"
  state               = "active"
}

resource "azurerm_api_management_api_diagnostic" "intersport_msax_inbound" {
  provider                 = azurerm.apim
  identifier               = "applicationinsights"
  api_name                 = azurerm_api_management_api.intersport_msax_inbound.name
  api_management_name      = azurerm_api_management_product.intersport_msax_inbound-intersport_msax.api_management_name
  resource_group_name      = azurerm_api_management_product.intersport_msax_inbound-intersport_msax.resource_group_name
  api_management_logger_id = data.terraform_remote_state.apimanagement.outputs.apim_logger_kgroup_kdata_apis.id
  always_log_errors        = true
}
