resource "azurerm_api_management_api" "onniaws_inbound" {
  provider            = azurerm.apim
  name                = "kdata-onninen-aws-inbound-api"
  resource_group_name = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.resource_group
  api_management_name = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.name
  revision            = "1"
  display_name        = "KDATA Onninen AWS Inbound API"
  path                = "kdata/onninen-aws-inbound-api"
  protocols           = ["https"]

  import {
    content_format = "openapi+json"
    content_value  = file("${path.module}/resources/openapi.onniaws.json")
  }
}

resource "azurerm_api_management_api_policy" "onniaws_inbound" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.onniaws_inbound.name
  api_management_name = azurerm_api_management_api.onniaws_inbound.api_management_name
  resource_group_name = azurerm_api_management_api.onniaws_inbound.resource_group_name

  xml_content = <<XML
<policies>
    <inbound>
        <authentication-managed-identity resource="https://${data.terraform_remote_state.integrations.outputs.sa_adls.name}.blob.core.windows.net/" />
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>
  XML
}

resource "azurerm_api_management_api_operation_policy" "onniaws_inbound" {
  for_each = toset([
    "ecomid",
  ])

  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.onniaws_inbound.name
  api_management_name = azurerm_api_management_api.onniaws_inbound.api_management_name
  resource_group_name = azurerm_api_management_api.onniaws_inbound.resource_group_name
  operation_id        = "post-${each.value}"

  xml_content = templatefile(
    "${path.module}/resources/adls-policy.xml", {
      storage  = data.terraform_remote_state.integrations.outputs.sa_adls.name
      source   = "ONNIAWS"
      dataset  = "${replace(each.value, "-", "_")}"
      filetype = "json"
  })
}

resource "azurerm_api_management_product" "onniaws_inbound-onniaws" {
  provider              = azurerm.apim
  display_name          = azurerm_api_management_api.onniaws_inbound.display_name
  product_id            = "${azurerm_api_management_api.onniaws_inbound.name}-onniaws-product"
  api_management_name   = azurerm_api_management_api.onniaws_inbound.api_management_name
  resource_group_name   = azurerm_api_management_api.onniaws_inbound.resource_group_name
  subscriptions_limit   = 0
  subscription_required = true
  approval_required     = false
  published             = true
}

resource "azurerm_api_management_product_api" "onniaws_inbound-onniaws" {
  provider            = azurerm.apim
  product_id          = azurerm_api_management_product.onniaws_inbound-onniaws.product_id
  api_name            = azurerm_api_management_api.onniaws_inbound.name
  api_management_name = azurerm_api_management_api.onniaws_inbound.api_management_name
  resource_group_name = azurerm_api_management_api.onniaws_inbound.resource_group_name
}

resource "azurerm_api_management_subscription" "onniaws_inbound-onniaws" {
  provider            = azurerm.apim
  api_management_name = azurerm_api_management_product.onniaws_inbound-onniaws.api_management_name
  resource_group_name = azurerm_api_management_product.onniaws_inbound-onniaws.resource_group_name
  product_id          = azurerm_api_management_product.onniaws_inbound-onniaws.id
  display_name        = "onniaws-${azurerm_api_management_product.onniaws_inbound-onniaws.product_id}"
  subscription_id     = "onniaws-${azurerm_api_management_product.onniaws_inbound-onniaws.product_id}"
  state               = "active"
  allow_tracing       = false
}

resource "azurerm_api_management_api_diagnostic" "onniaws_inbound" {
  provider                 = azurerm.apim
  identifier               = "applicationinsights"
  api_name                 = azurerm_api_management_api.onniaws_inbound.name
  api_management_name      = azurerm_api_management_api.onniaws_inbound.api_management_name
  resource_group_name      = azurerm_api_management_api.onniaws_inbound.resource_group_name
  api_management_logger_id = data.terraform_remote_state.apimanagement.outputs.apim_logger_kgroup_kdata_apis.id
  always_log_errors        = true
}
