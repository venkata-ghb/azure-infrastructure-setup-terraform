resource "azurerm_key_vault" "feedbuilder" {
  name                        = "${local.prefix}-feedbuildr-kv"
  location                    = azurerm_resource_group.feedbuilder.location
  resource_group_name         = azurerm_resource_group.feedbuilder.name
  tenant_id                   = data.azurerm_subscription.current.tenant_id
  enabled_for_disk_encryption = true
  purge_protection_enabled    = false
  sku_name                    = "standard"
  tags                        = local.resource_tags

  access_policy = [
    local.msi_infra_key_vault_access,
    {
      tenant_id               = data.azurerm_subscription.current.tenant_id
      object_id               = data.terraform_remote_state.ad.outputs.group_admins_platform.id
      application_id          = ""
      certificate_permissions = ["Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"]
      key_permissions         = ["Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"]
      secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
      storage_permissions     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"]
    },
    {
      tenant_id               = data.azurerm_subscription.current.tenant_id
      object_id               = "ac2f0416-8bad-48be-b70f-5e777e0f672b" # FEEDBUILDER_AZ_PROD_CONTRIBUTOR
      application_id          = ""
      certificate_permissions = []
      key_permissions         = []
      secret_permissions      = ["Get", "List", "Set", ]
      storage_permissions     = []
    },
    {
      tenant_id               = data.azurerm_subscription.current.tenant_id
      object_id               = "c4d3189a-e2b6-4208-b5f9-b0cd14ea41cf" # FEEDBUILDER_AZ_PROD_READER
      application_id          = ""
      certificate_permissions = []
      key_permissions         = []
      secret_permissions      = ["Get", "List", ]
      storage_permissions     = []
    },
  ]
}
