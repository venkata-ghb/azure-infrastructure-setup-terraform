resource "azurerm_resource_group" "feedbuilder" {
  name     = "${local.prefix_rg}_FEEDBUILDER_Main_RG"
  location = local.location.long
  tags     = local.resource_tags
}

resource "azurerm_role_assignment" "rg_feedbuilder-contributor-group_admins_platform" {
  principal_id         = data.terraform_remote_state.ad.outputs.group_admins_platform.id
  role_definition_name = "Contributor"
  scope                = azurerm_resource_group.feedbuilder.id
}

resource "azurerm_role_assignment" "rg_feedbuilder-reader-group_devops_platform" {
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
  role_definition_name = "Reader"
  scope                = azurerm_resource_group.feedbuilder.id
}

resource "azurerm_role_assignment" "rg_feedbuilder-contributor-group_feedbuilder_contributor" {
  principal_id         = "ac2f0416-8bad-48be-b70f-5e777e0f672b"
  role_definition_name = "Contributor"
  scope                = azurerm_resource_group.feedbuilder.id
}

resource "azurerm_role_assignment" "rg_feedbuilder-reader-group_feedbuilder_reader" {
  principal_id         = "c4d3189a-e2b6-4208-b5f9-b0cd14ea41cf"
  role_definition_name = "Reader"
  scope                = azurerm_resource_group.feedbuilder.id
}
