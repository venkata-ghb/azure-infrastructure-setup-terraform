resource "azurerm_key_vault_secret" "feedbuilder-sp_feedbuilder_qlik_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_feedbuilder_qlik.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_feedbuilder_qlik_password
  key_vault_id = azurerm_key_vault.feedbuilder.id
  content_type = "${data.terraform_remote_state.ad.outputs.sp_feedbuilder_qlik.display_name} SP's Password by Terraform"
  tags         = local.resource_tags
}
