data "azurerm_client_config" "current" {}

resource "azurerm_key_vault" "streamlit" {
  name                        = "${local.prefix}-streamlit-kv"
  location                    = azurerm_resource_group.streamlitapp.location
  resource_group_name         = azurerm_resource_group.streamlitapp.name
  tenant_id                   = data.azurerm_client_config.current.tenant_id
  sku_name                    = "standard"
  enabled_for_disk_encryption = true
  purge_protection_enabled    = true
  tags                        = local.resource_tags

  lifecycle { ignore_changes = [access_policy] }
}

resource "azurerm_key_vault_access_policy" "streamlit-msi_infra" {
  key_vault_id            = azurerm_key_vault.streamlit.id
  tenant_id               = local.msi_infra_key_vault_access.tenant_id
  object_id               = local.msi_infra_key_vault_access.object_id
  certificate_permissions = local.msi_infra_key_vault_access.certificate_permissions
  key_permissions         = local.msi_infra_key_vault_access.key_permissions
  secret_permissions      = local.msi_infra_key_vault_access.secret_permissions
  storage_permissions     = local.msi_infra_key_vault_access.storage_permissions
}

resource "azurerm_key_vault_access_policy" "streamlit-group_admins_platform" {
  key_vault_id            = azurerm_key_vault.streamlit.id
  tenant_id               = data.azurerm_client_config.current.tenant_id
  object_id               = data.terraform_remote_state.ad.outputs.group_admins_platform.id
  certificate_permissions = ["Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"]
  key_permissions         = ["Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"]
  secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
  storage_permissions     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"]
}

resource "azurerm_key_vault_access_policy" "streamlit-msi_streamlitapp" {
  key_vault_id            = azurerm_key_vault.streamlit.id
  tenant_id               = azurerm_user_assigned_identity.streamlitapp.tenant_id
  object_id               = azurerm_user_assigned_identity.streamlitapp.principal_id
  certificate_permissions = []
  key_permissions         = []
  secret_permissions      = ["Get", ]
  storage_permissions     = []
}

resource "azurerm_key_vault_access_policy" "streamlit-group_streamlitapp_contributor" {
  key_vault_id            = azurerm_key_vault.streamlit.id
  tenant_id               = data.azurerm_client_config.current.tenant_id
  object_id               = data.terraform_remote_state.ad.outputs.group_streamlitapp_contributor.id
  certificate_permissions = ["Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"]
  key_permissions         = ["Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"]
  secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
  storage_permissions     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"]
}
