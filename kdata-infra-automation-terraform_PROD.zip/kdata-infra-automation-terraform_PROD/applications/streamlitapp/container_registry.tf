# Container registry exists in dev resource group for now
# To be moved to production resource group

data "azurerm_container_registry" "streamlitapp" {
  provider            = azurerm.acr
  name                = "kdatastrealmitappacr"
  resource_group_name = replace(azurerm_resource_group.streamlitapp.name, upper(local.env.short), "DEV")
}
