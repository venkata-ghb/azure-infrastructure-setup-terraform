resource "azurerm_role_assignment" "rg_streamlitapp-contributor-group_admins_platform" {
  scope                = azurerm_resource_group.streamlitapp.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.group_admins_platform.id
}

resource "azurerm_role_assignment" "rg_streamlitapp-contributor-group_streamlitapp_contributor" {
  scope                = azurerm_resource_group.streamlitapp.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.group_streamlitapp_contributor.id
}

resource "azurerm_role_assignment" "rg_streamlitapp-reader-group_devops_platform" {
  scope                = azurerm_resource_group.streamlitapp.id
  role_definition_name = "Reader"
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
}

resource "azurerm_role_assignment" "rg_streamlitapp-reader-msi_infra_devtest" {
  scope                = azurerm_resource_group.streamlitapp.id
  role_definition_name = "Reader"
  principal_id         = data.terraform_remote_state.ad_test.outputs.msi_infra.id
}

resource "azurerm_role_assignment" "rg_streamlitapp-reader-group_streamlitapp_reader" {
  scope                = azurerm_resource_group.streamlitapp.id
  role_definition_name = "Reader"
  principal_id         = data.terraform_remote_state.ad.outputs.group_streamlitapp_reader.id
}

resource "azurerm_role_assignment" "acr_streamlitapp-acrpull-msi_streamlitapp" {
  scope                = data.azurerm_container_registry.streamlitapp.id
  role_definition_name = "AcrPull"
  principal_id         = azurerm_user_assigned_identity.streamlitapp.principal_id
}

resource "azurerm_role_assignment" "acr_streamlitapp-user_access_administrator-msi_infra_devtest" {
  scope                = data.azurerm_container_registry.streamlitapp.id
  role_definition_name = "User Access Administrator"
  principal_id         = data.terraform_remote_state.ad_test.outputs.msi_infra.id
}
