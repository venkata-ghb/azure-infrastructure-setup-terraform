resource "azurerm_user_assigned_identity" "streamlitapp" {
  location            = azurerm_resource_group.streamlitapp.location
  resource_group_name = azurerm_resource_group.streamlitapp.name
  name                = "${local.prefix}-streamlitapp-msi"
  tags                = local.resource_tags
}
