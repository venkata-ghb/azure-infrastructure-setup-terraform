terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "=3.103.0"
    }
  }
  backend "azurerm" {}
  required_version = "= 1.12.0"
}

provider "azurerm" {
  tenant_id                  = var.TENANT_ID
  subscription_id            = var.SUBSCRIPTION_ID
  storage_use_azuread        = true
  skip_provider_registration = true
  features {}
}

provider "azurerm" {
  alias                      = "acr"
  tenant_id                  = var.TENANT_ID
  subscription_id            = "f11ae7de-3b87-49e7-8a17-55041f3739c4"
  storage_use_azuread        = true
  skip_provider_registration = true
  features {}
}

data "terraform_remote_state" "common" {
  backend = "azurerm"
  config = {
    subscription_id      = var.SUBSCRIPTION_ID
    resource_group_name  = var.TF_RG_NAME
    storage_account_name = var.TF_SA_NAME
    container_name       = var.TF_CONTAINER_NAME
    key                  = "core/common.terraform_PROD.tfstate"
  }
}

data "terraform_remote_state" "ad" {
  backend = "azurerm"
  config = {
    subscription_id      = var.SUBSCRIPTION_ID
    resource_group_name  = var.TF_RG_NAME
    storage_account_name = var.TF_SA_NAME
    container_name       = var.TF_CONTAINER_NAME
    key                  = "core/ad.terraform_PROD.tfstate"
  }
}

data "terraform_remote_state" "ad_test" {
  backend = "azurerm"
  config = {
    subscription_id      = "f11ae7de-3b87-49e7-8a17-55041f3739c4"
    resource_group_name  = "K-DATA_TEST_WE_Terraform_RG"
    storage_account_name = "kdatadevtestinfrasa"
    container_name       = "tf-state"
    key                  = "TEST/core/ad.terraform_TEST.tfstate"
  }
}

# List of variables passed in via pipelines

variable "SUBSCRIPTION_ID" {
  type = string
}

variable "TENANT_ID" {
  type = string
}

variable "MSI_ID" {
  type = string
}

variable "TF_SUBNET_ID" {
  type = string
}

variable "TF_RG_NAME" {
  type = string
}

variable "TF_SA_NAME" {
  type = string
}

variable "TF_CONTAINER_NAME" {
  type = string
}
