resource "azurerm_service_plan" "streamlit_001" {
  name                = "${local.prefix}-we-streamlit-plan-001"
  location            = azurerm_resource_group.streamlitapp.location
  resource_group_name = azurerm_resource_group.streamlitapp.name

  os_type  = "Linux"
  sku_name = "P3mv3"

  tags = local.resource_tags
}
