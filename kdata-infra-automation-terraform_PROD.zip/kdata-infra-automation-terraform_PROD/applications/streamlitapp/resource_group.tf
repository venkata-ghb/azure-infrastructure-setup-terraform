resource "azurerm_resource_group" "streamlitapp" {
  name     = "${local.prefix_rg}_StreamlitApp_RG"
  location = local.location.long
  tags     = local.resource_tags
}
