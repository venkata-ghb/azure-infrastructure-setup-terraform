# Web App : Marketing
# Backend
resource "azurerm_linux_web_app" "kgenaimarketing_be" {
  name                = "${local.prefix}-${local.location.short}-kgenaimarketing-be-app"
  resource_group_name = azurerm_resource_group.kgenaimarketing.name
  location            = local.location.long
  #service_plan_id                 = replace(data.terraform_remote_state.integrations.outputs.service_plan_app_premium.id, "serverfarms", "serverFarms")
  service_plan_id               = "/subscriptions/02147589-2a7d-4483-b5da-af70a38cea3f/resourceGroups/K-DATA_PROD_WE_KGENAI_COMMON_RG/providers/Microsoft.Web/serverFarms/kdata-prod-we-kgenai-plan-001"
  tags                          = local.resource_tags
  public_network_access_enabled = false

  identity {
    type = "SystemAssigned"
  }

  site_config {
    app_command_line = "export deployEnv=prod && pip install -r requirements.txt && uvicorn --host 0.0.0.0 --port 8000 main:app --reload"

    application_stack {
      python_version = "3.10"
    }

    cors {
      allowed_origins     = ["https://${data.azurerm_static_web_app.kgenaimarketing_fe.default_host_name}"]
      support_credentials = false
    }

  }

  app_settings = {
    AZURE_OPENAI_ENDPOINT            = data.terraform_remote_state.azureai.outputs.openai_sc_api_endpoint
    AZURE_OPENAI_API_KEY             = data.terraform_remote_state.azureai.outputs.openai_sc_api_key
    AZURE_CHAT_MODEL_DEPLOYMENT_NAME = "gpt-4o-common" #"gpt-4o-dev"
    POSTGRE_DB_PASSWORD              = data.terraform_remote_state.integrations.outputs.postgresql_main_admin_password
  }

}

resource "azurerm_static_web_app" "kgenaimarketing_fe" {
  name                = "${local.prefix}-${local.location.short}-kgenaimarketing-fe-app"
  resource_group_name = azurerm_resource_group.kgenaimarketing.name
  location            = local.location.long

  configuration_file_changes_enabled = true
  preview_environments_enabled       = true
  sku_size                           = "Standard"
  sku_tier                           = "Standard"

  identity {
    type = "SystemAssigned"
  }

  app_settings = {
    VITE_MSAL_CLIENT_ID     = data.terraform_remote_state.ad.outputs.sp_kgenaimarketing.application_id
    VITE_MSAL_AUTHORITY_URL = "https://login.microsoftonline.com/${data.azurerm_client_config.current.tenant_id}"
    VITE_API_BASE_URL       = "https://${azurerm_linux_web_app.kgenaimarketing_be.default_hostname}"
    VITE_API_WEBSOCKET_URL  = "wss://${azurerm_linux_web_app.kgenaimarketing_be.default_hostname}"
    VITE_MSAL_REDIRECT_URL  = "https://${data.azurerm_static_web_app.kgenaimarketing_fe.default_host_name}"
  }

  tags = local.resource_tags
}

# This datablock is only added later so we can do self referencing for the default host name as 
# redirect url env variable in the static web app
data "azurerm_static_web_app" "kgenaimarketing_fe" {
  name                = "${local.prefix}-${local.location.short}-kgenaimarketing-fe-app"
  resource_group_name = azurerm_resource_group.kgenaimarketing.name
}

## Streamlit app 
resource "azurerm_linux_web_app" "kgenaimarketing_streamlit" {
  name                          = "${local.prefix}-${local.location.short}-kgenaimarketing-streamlit-app"
  resource_group_name           = azurerm_resource_group.kgenaimarketing.name
  location                      = local.location.long
  service_plan_id               = "/subscriptions/02147589-2a7d-4483-b5da-af70a38cea3f/resourceGroups/K-DATA_PROD_WE_KGENAI_COMMON_RG/providers/Microsoft.Web/serverFarms/kdata-prod-we-kgenai-plan-001"
  tags                          = local.resource_tags
  public_network_access_enabled = true

  identity {
    type = "SystemAssigned"
  }

  site_config {
    app_command_line = "pip install -r requirements.txt && streamlit run app.py  --server.port 8000 --server.address 0.0.0.0"

    application_stack {
      python_version = "3.10"
    }

  }

  app_settings = {
    AZURE_AI_STABLE_DIFFUSION_API_KEY    = "@Microsoft.KeyVault(SecretUri=${data.azurerm_key_vault_secret.kgenaimarketing-azureai_eus_sd35_key.id})"
    AZURE_AI_STABLE_DIFFUSION_ENDPOINT   = "https://Stable-Diffusion-3-5-Large-xvdqj.eastus.models.ai.azure.com/images/generations"
    AZURE_AI_STABLE_IMAGE_ULTRA_ENDPOINT = "https://Stable-Image-Ultra-xzmez.eastus.models.ai.azure.com/images/generations"
    AZURE_AI_STABLE_IMAGE_ULTRA_API_KEY  = "@Microsoft.KeyVault(SecretUri=${data.azurerm_key_vault_secret.kgenaimarketing-azureai_eus_siu_key.id})" // "Sv2HWqValp7UWHwPzyIH8WMNMvEu1wdO"
    AZURE_AI_STABLE_IMAGE_CORE_ENDPOINT  = "https://Stable-Image-Core-nuxnc.eastus.models.ai.azure.com/images/generations"
    AZURE_AI_STABLE_IMAGE_CORE_API_KEY   = "@Microsoft.KeyVault(SecretUri=${data.azurerm_key_vault_secret.kgenaimarketing-azureai_eus_sic_key.id})" // "A8Lxngwmcf8P972f4OPxnxDHplT3ngPf"
    AZURE_STORAGE_ACCOUNT_NAME           = azurerm_storage_account.kgenaimarketing.name
    AZURE_STORAGE_CONTAINER_NAME         = azurerm_storage_container.raw_streamlit.name
    AZURE_STORAGE_ACCOUNT_ACCESS_KEY     = "@Microsoft.KeyVault(SecretUri=${azurerm_key_vault_secret.kgenaimarketing-sa_kgenaimarketing_key.id})"
    AZURE_OPENAI_ENDPOINT                = "https://kdata-dev-sc-openai2.openai.azure.com/"
    AZURE_OPENAI_API_KEY                 = "@Microsoft.KeyVault(SecretUri=${data.azurerm_key_vault_secret.kgenaimarketing-openai_sc2_key_dev.id})" // "0de396fc7ca6499f85ac1cb0183098d8"
    AZURE_CHAT_MODEL_DEPLOYMENT_NAME     = "gpt-4o-dev"

  }
  #lifecycle { ignore_changes = [auth_settings_v2, sticky_settings] }
}
