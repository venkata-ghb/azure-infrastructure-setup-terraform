output "kgenaimarketing_fe" {
  value = {
    name              = azurerm_static_web_app.kgenaimarketing_fe.name
    default_host_name = azurerm_static_web_app.kgenaimarketing_fe.default_host_name
  }
}

output "kgenaimarketing_be" {
  value = {
    object_id         = azurerm_linux_web_app.kgenaimarketing_be.identity[0].principal_id
  }
}

# output "kgenaimarketing_be" {
#   value = {
#     name              = azurerm_linux_web_app.kgenaimarketing_be.name
#     default_host_name = azurerm_linux_web_app.kgenaimarketing_be.default_host_name
#   }
# }
