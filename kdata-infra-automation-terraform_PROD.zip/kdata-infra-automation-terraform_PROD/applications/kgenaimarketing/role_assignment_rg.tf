resource "azurerm_role_assignment" "rg_kgenaimarketing-contributor-group_devops_platform" {
  scope                = azurerm_resource_group.kgenaimarketing.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
}

resource "azurerm_role_assignment" "rg_kgenaimarketing-contributor-sp_platform_devops" {
  scope                = azurerm_resource_group.kgenaimarketing.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.sp_platform_devops.id
}

resource "azurerm_role_assignment" "rg_kgenaimarketing-contributor-group_admins_platform" {
  scope                = azurerm_resource_group.kgenaimarketing.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.group_admins_platform.id
}

resource "azurerm_role_assignment" "rg_kgenaimarketing-contributor-group_admins_openai" {
  scope                = azurerm_resource_group.kgenaimarketing.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad_dev.outputs.group_admins_openai.id
}

