# Service principal secret 
resource "azurerm_key_vault_secret" "kgenaimarketing-sp_kgenaimarketing_secret" {
  key_vault_id = azurerm_key_vault.kgenaimarketing.id
  name         = data.terraform_remote_state.ad.outputs.sp_kgenaimarketing.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_kgenaimarketing_password
  content_type = "${data.terraform_remote_state.ad.outputs.sp_kgenaimarketing.display_name} SP's Password by Terraform"
  tags         = local.resource_tags
}


# Stable Diffusion 3.5 Large api key for eus project
data "azurerm_key_vault_secret" "kgenaimarketing-azureai_eus_sd35_key" {
  name         = "azure-ai-eus-sd35-api-key"
  key_vault_id = azurerm_key_vault.kgenaimarketing.id
}

# Stable Image Ultra api key for eus project
data "azurerm_key_vault_secret" "kgenaimarketing-azureai_eus_siu_key" {
  name         = "azure-ai-eus-siu-api-key"
  key_vault_id = azurerm_key_vault.kgenaimarketing.id
}

# Stable Image Core api key for eus project
data "azurerm_key_vault_secret" "kgenaimarketing-azureai_eus_sic_key" {
  name         = "azure-ai-eus-sic-api-key"
  key_vault_id = azurerm_key_vault.kgenaimarketing.id
}

# OpenAI Sweden Central 2 DEV api key
data "azurerm_key_vault_secret" "kgenaimarketing-openai_sc2_key_dev" {
  name         = "azure-ai-openai-api-key"
  key_vault_id = azurerm_key_vault.kgenaimarketing.id
}

# App reistration secret for auth2 flow 
data "azurerm_key_vault_secret" "kgenaimarketing-sp_streamlit_app_password" {
  name         = "kdata-streamlit-app-poc2-secret"
  key_vault_id = azurerm_key_vault.kgenaimarketing.id
}

resource "azurerm_key_vault_secret" "kgenaimarketing-sa_kgenaimarketing_key" {
  key_vault_id = azurerm_key_vault.kgenaimarketing.id
  name         = "sa-kgenaimarketing-access-key"
  value        = azurerm_storage_account.kgenaimarketing.primary_connection_string
  content_type = "Storage Account kgenaimarketing Access key images"

  tags = local.resource_tags
}