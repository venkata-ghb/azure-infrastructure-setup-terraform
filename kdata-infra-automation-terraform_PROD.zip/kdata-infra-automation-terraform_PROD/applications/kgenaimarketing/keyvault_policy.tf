# Marketing Backend app access policy
resource "azurerm_key_vault_access_policy" "kgenaimarketing-msi_kgenaimarketing_be" {
  key_vault_id       = azurerm_key_vault.kgenaimarketing.id
  tenant_id          = var.TENANT_ID
  object_id          = azurerm_linux_web_app.kgenaimarketing_be.identity[0].principal_id
  secret_permissions = ["Get", ]
}

# Marketing Frontend app access policy
resource "azurerm_key_vault_access_policy" "kgenaimarketing-msi_kgenaimarketing_fe" {
  key_vault_id       = azurerm_key_vault.kgenaimarketing.id
  tenant_id          = var.TENANT_ID
  object_id          = azurerm_static_web_app.kgenaimarketing_fe.identity[0].principal_id
  secret_permissions = ["Get", ]
}

# Marketing Steamlit sample app access policy
resource "azurerm_key_vault_access_policy" "kgenaimarketing-msi_kgenaimarketing_streamlit" {
  key_vault_id       = azurerm_key_vault.kgenaimarketing.id
  tenant_id          = var.TENANT_ID
  object_id          = azurerm_linux_web_app.kgenaimarketing_streamlit.identity[0].principal_id
  secret_permissions = ["Get", ]
}

# Platform Admins access policy
resource "azurerm_key_vault_access_policy" "kgenaimarketing-group_admins_platform" {
  key_vault_id            = azurerm_key_vault.kgenaimarketing.id
  tenant_id               = var.TENANT_ID
  object_id               = data.terraform_remote_state.ad.outputs.group_admins_platform.id
  certificate_permissions = ["Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"]
  key_permissions         = ["Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"]
  secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
  storage_permissions     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"]
}

# OpenAI DEV Admins group access policy
resource "azurerm_key_vault_access_policy" "kgenaimarketing-group_admins_openai" {
  key_vault_id            = azurerm_key_vault.kgenaimarketing.id
  tenant_id               = var.TENANT_ID
  object_id               = data.terraform_remote_state.ad_dev.outputs.group_admins_openai.id
  certificate_permissions = ["Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"]
  key_permissions         = ["Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"]
  secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
  storage_permissions     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"]
}
