resource "azurerm_resource_group" "kgenaimarketing" {
  name     = "${local.prefix_rg}_KGENAIMARKETING_RG"
  location = local.location.long
  tags     = local.resource_tags
}