resource "azurerm_private_endpoint" "kgenaimarketing_be" {
  name                = "${azurerm_linux_web_app.kgenaimarketing_be.name}-pvtendpt"
  location            = local.location.long
  resource_group_name = data.terraform_remote_state.vnets.outputs.subnet_genai_private_endpoint.resource_group_name
  tags                = local.resource_tags
  subnet_id           = data.terraform_remote_state.vnets.outputs.subnet_genai_private_endpoint.id

  private_service_connection {
    name                           = "${azurerm_linux_web_app.kgenaimarketing_be.name}-pvtendpt"
    private_connection_resource_id = azurerm_linux_web_app.kgenaimarketing_be.id
    subresource_names              = ["sites"]
    is_manual_connection           = false

  }
}