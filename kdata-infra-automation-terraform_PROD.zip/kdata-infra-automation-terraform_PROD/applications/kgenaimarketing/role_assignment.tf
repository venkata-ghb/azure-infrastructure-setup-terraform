# Assign Storage Blob Data Contributor role to the Managed Identity of the Web App
resource "azurerm_role_assignment" "sa_kgenaimarketing_images-blob_data_contributor-kgenaimarketing_webapp" {
  principal_id         = azurerm_linux_web_app.kgenaimarketing_be.identity.0.principal_id
  role_definition_name = "Storage Blob Data Contributor"
  scope                = azurerm_storage_account.kgenaimarketing.id
}

resource "azurerm_role_assignment" "postgresql_main_kgenaimarketing_db-contributor-kgenaimarketing_webapp" {
  principal_id         = azurerm_linux_web_app.kgenaimarketing_be.identity[0].principal_id
  scope                = azurerm_postgresql_flexible_server_database.main-kgenaimarketing.id
  role_definition_name = "Contributor"
}

# OpenAI Admins group access to blob storage
# resource "azurerm_role_assignment" "sa_kgenaimarketing_images-blob_data_contributor-group_admins_openai" {
#   principal_id         = data.terraform_remote_state.ad_dev.outputs.group_admins_openai.id
#   role_definition_name = "Storage Blob Data Contributor"
#   scope                = azurerm_storage_account.kgenaimarketing.id
# }
