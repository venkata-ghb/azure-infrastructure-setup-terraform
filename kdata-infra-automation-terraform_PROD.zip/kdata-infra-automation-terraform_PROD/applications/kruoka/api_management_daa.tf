resource "azurerm_api_management_api" "kruoka_daa_inbound" {
  provider            = azurerm.kgroup-apim
  name                = "kdata-kruoka-delivery-availablility-api-inbound-api"
  resource_group_name = data.terraform_remote_state.apim.outputs.apim_kgroup.resource_group
  api_management_name = data.terraform_remote_state.apim.outputs.apim_kgroup.name
  revision            = "1"
  display_name        = "KDATA K-Ruoka Delivery Availability API Inbound API"
  path                = "kdata/kruoka/delivery-availability-api-inbound-api"
  protocols           = ["https"]

  import {
    content_format = "openapi+json"
    content_value  = file("${path.module}/resources/openapi.kruoka-daa.json")
  }
}

resource "azurerm_api_management_api_policy" "kruoka_daa_inbound" {
  provider            = azurerm.kgroup-apim
  api_name            = azurerm_api_management_api.kruoka_daa_inbound.name
  api_management_name = azurerm_api_management_api.kruoka_daa_inbound.api_management_name
  resource_group_name = azurerm_api_management_api.kruoka_daa_inbound.resource_group_name

  xml_content = <<XML
<policies>
    <inbound>
        <authentication-managed-identity resource="https://${data.terraform_remote_state.integrations.outputs.sa_adls.name}.blob.core.windows.net/" />
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>
  XML
}

resource "azurerm_api_management_api_operation_policy" "kruoka_daa_inbound" {
  for_each = toset([
    "delivery-area",
  ])

  provider            = azurerm.kgroup-apim
  api_name            = azurerm_api_management_api.kruoka_daa_inbound.name
  api_management_name = azurerm_api_management_api.kruoka_daa_inbound.api_management_name
  resource_group_name = azurerm_api_management_api.kruoka_daa_inbound.resource_group_name
  operation_id        = "post-${each.value}"

  xml_content = templatefile(
    "${path.module}/resources/adls-policy.xml", {
      storage  = data.terraform_remote_state.integrations.outputs.sa_adls.name
      source   = "KRUOKA"
      dataset  = replace(each.value, "-", "_")
      filetype = "json"
  })
}

resource "azurerm_api_management_product" "kruoka_daa_inbound-kruoka" {
  provider              = azurerm.kgroup-apim
  display_name          = azurerm_api_management_api.kruoka_daa_inbound.display_name
  product_id            = "${azurerm_api_management_api.kruoka_daa_inbound.name}-kruoka-product"
  api_management_name   = azurerm_api_management_api.kruoka_daa_inbound.api_management_name
  resource_group_name   = azurerm_api_management_api.kruoka_daa_inbound.resource_group_name
  subscriptions_limit   = 0
  subscription_required = true
  approval_required     = false
  published             = true
}

resource "azurerm_api_management_product_api" "kruoka_daa_inbound-kruoka" {
  provider            = azurerm.kgroup-apim
  product_id          = azurerm_api_management_product.kruoka_daa_inbound-kruoka.product_id
  api_name            = azurerm_api_management_api.kruoka_daa_inbound.name
  api_management_name = azurerm_api_management_api.kruoka_daa_inbound.api_management_name
  resource_group_name = azurerm_api_management_api.kruoka_daa_inbound.resource_group_name
}

resource "azurerm_api_management_subscription" "kruoka_daa_inbound-kruoka" {
  provider            = azurerm.kgroup-apim
  api_management_name = azurerm_api_management_product.kruoka_daa_inbound-kruoka.api_management_name
  resource_group_name = azurerm_api_management_product.kruoka_daa_inbound-kruoka.resource_group_name
  product_id          = azurerm_api_management_product.kruoka_daa_inbound-kruoka.id
  display_name        = "kruoka-${azurerm_api_management_product.kruoka_daa_inbound-kruoka.product_id}"
  subscription_id     = "kruoka-${azurerm_api_management_product.kruoka_daa_inbound-kruoka.product_id}"
  state               = "active"
}
