# API management stuff
data "azurerm_api_management" "apimanagement" {
  provider            = azurerm.apim
  name                = "K-apim-prod"
  resource_group_name = "KESKO_WE_RG_APIM_PROD001"
}

resource "azurerm_api_management_api" "kruoka" {
  provider            = azurerm.apim
  name                = "kdata-kruoka-input-api"
  resource_group_name = data.azurerm_api_management.apimanagement.resource_group_name
  api_management_name = data.azurerm_api_management.apimanagement.name
  revision            = "1"
  display_name        = "K-Data kruoka Input API"
  path                = "kdata/kruoka-input-api"
  protocols           = ["https"]

  import {
    content_format = "openapi+json"
    content_value  = file("${path.module}/resources/openapi.json")
  }
}


resource "azurerm_api_management_named_value" "kruoka" {
  provider            = azurerm.apim
  name                = "${azurerm_api_management_api.kruoka.name}-secret"
  display_name        = "${azurerm_api_management_api.kruoka.name}-secret"
  resource_group_name = azurerm_api_management_api.kruoka.resource_group_name
  api_management_name = azurerm_api_management_api.kruoka.api_management_name
  value               = data.terraform_remote_state.ad.outputs.sp_kruoka_eventhub_password
  secret              = true
}


resource "azurerm_api_management_api_policy" "kruoka" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.kruoka.name
  api_management_name = azurerm_api_management_api.kruoka.api_management_name
  resource_group_name = azurerm_api_management_api.kruoka.resource_group_name

  xml_content = <<XML
<policies>
    <inbound>
        <base />
        <!--Look for userprofile for this user in the cache -->
        <cache-lookup-value key="kruoka-eh-access-token" variable-name="access-token" />
        <!-- If API Management doesn’t find it in the cache, make a request for it and store it -->
        <choose>
            <when condition="@(!context.Variables.ContainsKey("access-token"))">
                <!-- Make HTTP request to get user profile -->
                <send-request ignore-error="true" timeout="20" response-variable-name="bearerToken" mode="new">
                    <set-url>https://login.microsoftonline.com/${data.azurerm_client_config.current.tenant_id}/oauth2/token</set-url>
                    <set-method>POST</set-method>
                    <set-header name="Content-Type" exists-action="override">
                        <value>application/x-www-form-urlencoded</value>
                    </set-header>
                    <set-body>@{
                        return "client_id=${data.terraform_remote_state.ad.outputs.sp_kruoka_eventhub.application_id}&resource=https://eventhubs.azure.net&client_secret={{${azurerm_api_management_named_value.kruoka.name}}}&grant_type=client_credentials";
                    }</set-body>
                </send-request>
                <!-- Store response body in context variable -->
                <set-variable name="access-token" value="@((String)((IResponse)context.Variables["bearerToken"]).Body.As<JObject>()["access_token"])" />
                <!-- Store result in cache -->
                <!-- Duration of cache should be less than lifetime of access token. -->
                <!-- Otherwise we will get authorization error as non-active access token will be used -->                
                <cache-store-value key="kruoka-eh-access-token" value="@((string)context.Variables["access-token"])" duration="3300" />
            </when>
        </choose>
        <set-header name="Authorization" exists-action="override">
            <value>@("Bearer " + (String)context.Variables["access-token"])</value>
        </set-header>
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <set-header name="Content-Type" exists-action="override">
            <value>application/json</value>
        </set-header>
        <set-body template="liquid">
        {
          "statusCode": {{context.Response.StatusCode}},
          "message": {% case context.Response.StatusCode %}
            {% when 201 %}"ok"
            {% else %}
              {% if body %}"{{body}}"
              {% else %}"Configuration error(Eventhub User Error) occured"
              {% endif %}
          {% endcase %}}
        </set-body>
        <base />
    </outbound>
    <on-error>
        <set-header name="Content-Type" exists-action="override">
            <value>application/json</value>
        </set-header>
        <set-body template="liquid">
        {
          "statusCode": {{context.Response.StatusCode}},
          "message": {% case context.Response.StatusCode %}
            {% when 400 %}"Invalid JSON document"
            {% else %}
              {% if body.message %}"{{body.message}}"
              {% elsif body %}"{{body}}"
              {% else %}"Internal Error"
              {% endif %}
          {% endcase %}}
        </set-body>
        <base />
    </on-error>
</policies>
  XML
}
resource "azurerm_api_management_api_operation_policy" "kruoka-order_data" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.kruoka.name
  api_management_name = azurerm_api_management_api.kruoka.api_management_name
  resource_group_name = azurerm_api_management_api.kruoka.resource_group_name
  operation_id        = "post-order-data"

  xml_content = <<XML
<policies>
    <inbound>
        <base />
        <set-backend-service base-url="https://${data.terraform_remote_state.integrations.outputs.ehns_kruoka.name}.servicebus.windows.net/orders-natural/messages" />
        <rewrite-uri template="/" />
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>
XML
}


resource "azurerm_api_management_product" "kruoka" {
  provider              = azurerm.apim
  product_id            = "${azurerm_api_management_api.kruoka.name}-product"
  api_management_name   = azurerm_api_management_api.kruoka.api_management_name
  resource_group_name   = azurerm_api_management_api.kruoka.resource_group_name
  display_name          = azurerm_api_management_api.kruoka.display_name
  subscriptions_limit   = 0
  subscription_required = true
  approval_required     = false
  published             = true
}

resource "azurerm_api_management_product_api" "kruoka" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.kruoka.name
  product_id          = azurerm_api_management_product.kruoka.product_id
  api_management_name = azurerm_api_management_api.kruoka.api_management_name
  resource_group_name = azurerm_api_management_api.kruoka.resource_group_name
}

resource "azurerm_api_management_product_group" "kruoka" {
  provider            = azurerm.apim
  product_id          = azurerm_api_management_product.kruoka.product_id
  api_management_name = azurerm_api_management_api.kruoka.api_management_name
  resource_group_name = azurerm_api_management_api.kruoka.resource_group_name
  group_name          = "az-apim-${var.env}-kdata-neste-input-api"
}

resource "azurerm_api_management_api_tag" "kruoka" {
  provider = azurerm.apim
  api_id   = azurerm_api_management_api.kruoka.id
  name     = "k-data"
}
