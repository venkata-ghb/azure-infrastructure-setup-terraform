resource "azurerm_monitor_action_group" "kruoka" {
  name                = "${var.prefix}-kruoka-integration-errors-action-group"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_integration.name
  short_name          = "kruoka-err"
  tags                = local.resource_tags

  email_receiver {
    name          = "Nico Miettinen"
    email_address = "nico.miettinen@kesko.fi"
  }

  email_receiver {
    name          = "DL_KESKOAMS_TCS_KDATA"
    email_address = "DL_KESKOAMS_TCS_KDATA@kesko.fi"
  }

}

resource "azurerm_monitor_activity_log_alert" "eh_kruoka-eventhub_health" {
  name                = "${var.prefix}-kruoka-eventhub-health-alert"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_integration.name
  scopes              = [data.terraform_remote_state.integrations.outputs.ehns_kruoka.id]
  description         = "Alert to monitor K-Valikoima Event Hub namespace health status."

  criteria {
    resource_id = data.terraform_remote_state.integrations.outputs.ehns_kruoka.id
    category    = "ResourceHealth"
  }

  action {
    action_group_id = azurerm_monitor_action_group.kruoka.id
  }

  tags = local.resource_tags

}

resource "azurerm_monitor_metric_alert" "eh_kruoka-eventhub_server_error" {
  name                = "${var.prefix}-kruoka-eventhub-server-error-alert"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_integration.name
  scopes              = [data.terraform_remote_state.integrations.outputs.ehns_kruoka.id]
  description         = "Action will be triggered when server errors count is greater than 5."

  criteria {
    metric_namespace = "Microsoft.EventHub/namespaces"
    metric_name      = "ServerErrors"
    aggregation      = "Total"
    operator         = "GreaterThan"
    threshold        = 0
  }

  action {
    action_group_id = azurerm_monitor_action_group.kruoka.id
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_metric_alert" "eh_kruoka-eventhub_user_error" {
  name                = "${var.prefix}-kruoka-eventhub-user-error-alert"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_integration.name
  scopes              = [data.terraform_remote_state.integrations.outputs.ehns_kruoka.id]
  description         = "Action will be triggered when user errors count is greater than 1."

  criteria {
    metric_namespace = "Microsoft.EventHub/namespaces"
    metric_name      = "UserErrors"
    aggregation      = "Total"
    operator         = "GreaterThan"
    threshold        = 0
  }

  action {
    action_group_id = azurerm_monitor_action_group.kruoka.id
  }

  tags = local.resource_tags
}

