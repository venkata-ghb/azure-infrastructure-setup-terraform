resource "azurerm_key_vault_secret" "kruoka-sp_kruoka_databricks_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_kruoka_databricks.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_kruoka_databricks_password
  key_vault_id = azurerm_key_vault.kruoka.id
  content_type = "${data.terraform_remote_state.ad.outputs.sp_kruoka_databricks.display_name} SP's Password by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "kruoka-sp_kruoka_eventhub_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_kruoka_eventhub.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_kruoka_eventhub_password
  key_vault_id = azurerm_key_vault.kruoka.id
  content_type = "${data.terraform_remote_state.ad.outputs.sp_kruoka_eventhub.display_name} SP's Password by Terraform"
  tags         = local.resource_tags
}
