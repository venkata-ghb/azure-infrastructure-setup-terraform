resource "azurerm_api_management_api_diagnostic" "kruoka_input" {
  provider                 = azurerm.apim
  identifier               = "applicationinsights"
  resource_group_name      = data.azurerm_api_management.apimanagement.resource_group_name
  api_management_name      = data.azurerm_api_management.apimanagement.name
  api_name                 = azurerm_api_management_api.kruoka.name
  api_management_logger_id = data.terraform_remote_state.apim.outputs.apim_logger.id
  always_log_errors        = true
}

resource "azurerm_api_management_api_diagnostic" "kruoka_daa_input" {
  provider                 = azurerm.kgroup-apim
  identifier               = "applicationinsights"
  api_name                 = azurerm_api_management_api.kruoka_daa_inbound.name
  api_management_name      = azurerm_api_management_api.kruoka_daa_inbound.api_management_name
  resource_group_name      = azurerm_api_management_api.kruoka_daa_inbound.resource_group_name
  api_management_logger_id = data.terraform_remote_state.apim.outputs.apim_logger_kgroup_kdata_apis.id
  always_log_errors        = true
}
