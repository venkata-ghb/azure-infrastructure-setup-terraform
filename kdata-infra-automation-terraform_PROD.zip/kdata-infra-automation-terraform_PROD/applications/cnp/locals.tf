locals {
  location                   = data.terraform_remote_state.common.outputs.location
  prefix                     = data.terraform_remote_state.common.outputs.prefix
  msi_infra_key_vault_access = data.terraform_remote_state.common.outputs.msi_infra_key_vault_access
  resource_tags              = data.terraform_remote_state.common.outputs.resource_tags
}
