resource "azurerm_api_management_api" "tos_inbound" {
  provider            = azurerm.apim
  name                = "kdata-tos-inbound-api"
  resource_group_name = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.resource_group
  api_management_name = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.name
  revision            = "1"
  display_name        = "KDATA TOS Inbound API"
  path                = "kdata/tos-inbound-api"
  protocols           = ["https"]

  import {
    content_format = "openapi+json"
    content_value  = file("${path.module}/resources/openapi.tos.json")
  }
}

resource "azurerm_api_management_api_policy" "tos_inbound" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.tos_inbound.name
  api_management_name = azurerm_api_management_api.tos_inbound.api_management_name
  resource_group_name = azurerm_api_management_api.tos_inbound.resource_group_name

  xml_content = <<XML
<policies>
    <inbound>
        <authentication-managed-identity resource="https://${data.terraform_remote_state.integrations.outputs.sa_adls.name}.blob.core.windows.net/" />
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>
  XML
}

resource "azurerm_api_management_api_operation_policy" "tos_inbound" {
  for_each = toset([
    "campaign",
    "offer",
    "proposition",
    "redemption",
    "proposition-activation"
  ])

  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.tos_inbound.name
  api_management_name = azurerm_api_management_api.tos_inbound.api_management_name
  resource_group_name = azurerm_api_management_api.tos_inbound.resource_group_name
  operation_id        = "post-${each.value}"

  xml_content = templatefile(
    "${path.module}/resources/adls-policy.xml", {
      storage  = data.terraform_remote_state.integrations.outputs.sa_adls.name
      source   = "TOS"
      dataset  = "${replace(each.value, "-", "_")}_v2"
      filetype = "json"
  })
}

resource "azurerm_api_management_product" "tos_inbound-tos" {
  provider              = azurerm.apim
  display_name          = azurerm_api_management_api.tos_inbound.display_name
  product_id            = "${azurerm_api_management_api.tos_inbound.name}-tos-product"
  api_management_name   = azurerm_api_management_api.tos_inbound.api_management_name
  resource_group_name   = azurerm_api_management_api.tos_inbound.resource_group_name
  subscriptions_limit   = 0
  subscription_required = true
  approval_required     = false
  published             = true
}

resource "azurerm_api_management_product_api" "tos_inbound-tos" {
  provider            = azurerm.apim
  product_id          = azurerm_api_management_product.tos_inbound-tos.product_id
  api_name            = azurerm_api_management_api.tos_inbound.name
  api_management_name = azurerm_api_management_api.tos_inbound.api_management_name
  resource_group_name = azurerm_api_management_api.tos_inbound.resource_group_name
}

resource "azurerm_api_management_subscription" "tos_inbound-tos" {
  provider            = azurerm.apim
  api_management_name = azurerm_api_management_product.tos_inbound-tos.api_management_name
  resource_group_name = azurerm_api_management_product.tos_inbound-tos.resource_group_name
  product_id          = azurerm_api_management_product.tos_inbound-tos.id
  display_name        = "tos-${azurerm_api_management_product.tos_inbound-tos.product_id}"
  subscription_id     = "tos-${azurerm_api_management_product.tos_inbound-tos.product_id}"
  state               = "active"
}

resource "azurerm_api_management_api_diagnostic" "tos_inbound" {
  provider                 = azurerm.apim
  identifier               = "applicationinsights"
  resource_group_name      = azurerm_api_management_api.tos_inbound.resource_group_name
  api_management_name      = azurerm_api_management_api.tos_inbound.api_management_name
  api_name                 = azurerm_api_management_api.tos_inbound.name
  api_management_logger_id = data.terraform_remote_state.apimanagement.outputs.apim_logger_kgroup_kdata_apis.id
  always_log_errors        = true
}
