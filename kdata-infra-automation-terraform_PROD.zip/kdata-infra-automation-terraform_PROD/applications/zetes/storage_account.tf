resource "azurerm_storage_account" "zetesapimeta" {
  name                     = "${var.prefix_sa}zetesapimeta"
  resource_group_name      = azurerm_resource_group.zetes.name
  location                 = var.location
  account_tier             = "Standard"
  account_replication_type = "LRS"
  account_kind             = "StorageV2"
  is_hns_enabled           = "true"
  tags                     = local.resource_tags
  network_rules {
    default_action = "Allow"
    virtual_network_subnet_ids = [ "/subscriptions/0a2d289e-76dd-4b1f-b9b2-dba15a872e92/resourceGroups/rg-platform-avd-prod-weu-001/providers/Microsoft.Network/virtualNetworks/vnet-avd-prod-weu-001/subnets/Subnet-AVDTCS-AMS-prod-weu" ]
  }
}
resource "azurerm_storage_table" "zetesapimeta-zetesapi" {
  name                 = "zetesapi"
  storage_account_name = azurerm_storage_account.zetesapimeta.name
}

##Function App Storage Account
resource "azurerm_storage_account" "zetesapifunc" {
  name                     = "${var.prefix_sa}zetesapifunc"
  resource_group_name      = azurerm_resource_group.zetes.name
  location                 = var.location
  account_tier             = "Standard"
  account_replication_type = "LRS"
  account_kind             = "StorageV2"
  is_hns_enabled           = "true"
  tags                     = local.resource_tags
  network_rules {
    default_action = "Allow"
    virtual_network_subnet_ids = [ "/subscriptions/0a2d289e-76dd-4b1f-b9b2-dba15a872e92/resourceGroups/rg-platform-avd-prod-weu-001/providers/Microsoft.Network/virtualNetworks/vnet-avd-prod-weu-001/subnets/Subnet-AVDTCS-AMS-prod-weu" ]
  }
}
