resource "azurerm_resource_group" "zetes" {
  name     = "${var.prefix_rg}_ZETES_Main_RG"
  location = var.location
  tags     = local.resource_tags
}
