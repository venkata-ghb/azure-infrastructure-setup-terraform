resource "azurerm_key_vault_secret" "zetes-zetes_api_storage_account_conn_str" {
  key_vault_id = azurerm_key_vault.zetes.id
  name         = "zetes-api-storage-account-conn-str"
  value        = azurerm_storage_account.zetesapimeta.primary_access_key
  content_type = "Zetes Image api meta storage account access key"
  tags         = local.resource_tags
}
