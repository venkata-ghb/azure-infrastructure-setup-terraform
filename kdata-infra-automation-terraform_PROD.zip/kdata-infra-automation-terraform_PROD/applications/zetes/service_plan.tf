resource "azurerm_app_service_plan" "zetes" {
  name                = "KDATA-${var.env}-zetes-plan"
  location            = azurerm_resource_group.zetes.location
  resource_group_name = azurerm_resource_group.zetes.name
  kind                = "FunctionApp"
  reserved            = true

  sku {
    tier = "Dynamic"
    size = "Y1"
  }

  tags = local.resource_tags
}