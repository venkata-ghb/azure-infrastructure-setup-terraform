##Function APP
resource "azurerm_function_app" "zetes" {
  name                = "${upper(var.prefix)}-${upper(var.loc)}-ZETES-FUNC"
  resource_group_name = azurerm_resource_group.zetes.name
  location            = azurerm_resource_group.zetes.location
  app_service_plan_id = azurerm_app_service_plan.zetes.id
  os_type             = "linux"
  version             = "~4"
  https_only          = true

  site_config {
    ftps_state                = "Disabled"
    linux_fx_version          = "python|3.11"
    use_32_bit_worker_process = false
  }

  identity {
    type = "SystemAssigned"
  }

  app_settings = {
    FUNCTIONS_WORKER_RUNTIME              = "python"
    FUNCTIONS_EXTENSION_VERSION           = "~4"
    APPINSIGHTS_INSTRUMENTATIONKEY        = azurerm_application_insights.zetesapi.instrumentation_key
    APPLICATIONINSIGHTS_CONNECTION_STRING = azurerm_application_insights.zetesapi.connection_string
    STORAGE_ACCOUNT_NAME                  = data.terraform_remote_state.integrations.outputs.sa_adlsexternal.name
    STORAGE_ACCOUNT_CONTAINER             = "raw"
    STORAGE_ACCOUNT_KEY                   = ""
    META_STORAGE_TABLE                    = azurerm_storage_table.zetesapimeta-zetesapi.name
    META_STORAGE_NAME                     = azurerm_storage_account.zetesapimeta.name
    META_STORAGE_KEY                      = "@Microsoft.KeyVault(SecretUri=${azurerm_key_vault_secret.zetes-zetes_api_storage_account_conn_str.id})"
    ROOT_PATH                             = "natural/ZETES"
    LOG_LEVEL                             = "INFO"
  }

  tags = local.resource_tags
}

resource "azurerm_application_insights" "zetesapi" {
  name                = "${var.prefix}-${lower(var.loc)}-zetesapi-func"
  location            = azurerm_resource_group.zetes.location
  resource_group_name = azurerm_resource_group.zetes.name
  application_type    = "web"
  retention_in_days   = 90
  sampling_percentage = 0

  lifecycle {
    ignore_changes = [ workspace_id ]
  }
}
