locals {
  msi_kv_access_policy = {
    object_id               = data.terraform_remote_state.ad.outputs.msi_infra.id
    tenant_id               = "ae6e7baa-e1bf-4ef0-92a1-4eb28ec805c0"
    application_id          = ""
    certificate_permissions = ["Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"]
    key_permissions         = ["Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"]
    secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
    storage_permissions     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"]
  }
}

data "azurerm_client_config" "current" {}

resource "azurerm_key_vault" "zetes" {
  name                        = "${var.prefix}-zetes-kv"
  location                    = azurerm_resource_group.zetes.location
  resource_group_name         = azurerm_resource_group.zetes.name
  enabled_for_disk_encryption = true
  tenant_id                   = data.azurerm_client_config.current.tenant_id
  purge_protection_enabled    = false
  sku_name                    = "standard"
  tags                        = local.resource_tags
}

resource "azurerm_key_vault_access_policy" "zetes-msi_infra" {
  key_vault_id            = azurerm_key_vault.zetes.id
  tenant_id               = local.msi_kv_access_policy.tenant_id
  object_id               = local.msi_kv_access_policy.object_id
  secret_permissions      = local.msi_kv_access_policy.secret_permissions
  key_permissions         = local.msi_kv_access_policy.key_permissions
  certificate_permissions = local.msi_kv_access_policy.certificate_permissions
  storage_permissions     = local.msi_kv_access_policy.storage_permissions
}

resource "azurerm_key_vault_access_policy" "zetes-group_admins_platform" {
  key_vault_id = azurerm_key_vault.zetes.id
  tenant_id    = data.azurerm_client_config.current.tenant_id
  object_id    = data.terraform_remote_state.ad.outputs.group_admins_platform.id

  secret_permissions = [
    "Get",
    "Set",
    "List",
    "Delete"

  ]
  key_permissions = [
    "Create",
    "Get",
    "List",
    "Delete"
  ]
  certificate_permissions = [
    "Create",
    "Update",
    "Get",
    "List",
    "Delete"
  ]
}

resource "azurerm_key_vault_access_policy" "zetes-funcapp_zetes" {
  key_vault_id       = azurerm_key_vault.zetes.id
  tenant_id          = data.azurerm_client_config.current.tenant_id
  object_id          = lookup(azurerm_function_app.zetes.identity[0], "principal_id")
  key_permissions    = ["get"]
  secret_permissions = ["get"]
}
