# Resource group
resource "azurerm_role_assignment" "rg_zetes-contributor-group_admins_platform" {
  principal_id         = data.terraform_remote_state.ad.outputs.group_admins_platform.id
  role_definition_name = "Contributor"
  scope                = azurerm_resource_group.zetes.id
}

resource "azurerm_role_assignment" "rg_zetes-contributor-sp_zetes_devops" {
  principal_id         = data.terraform_remote_state.ad.outputs.sp_zetes_devops.id
  role_definition_name = "Contributor"
  scope                = azurerm_resource_group.zetes.id
}

resource "azurerm_role_assignment" "rg_zetes-reader-group_devops_platform" {
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
  role_definition_name = "Reader"
  scope                = azurerm_resource_group.zetes.id
}

resource "azurerm_role_assignment" "rg_zetes-website_contributor-group_devops_platform" {
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
  role_definition_name = "Website Contributor"
  scope                = azurerm_resource_group.zetes.id
}

# Storage account
resource "azurerm_role_assignment" "sa_zetesapifunc-blob_contributor-group_devops_platform" {
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
  role_definition_name = "Storage Blob Data Contributor"
  scope                = azurerm_storage_account.zetesapifunc.id
}

resource "azurerm_role_assignment" "sa_zetesapifunc-table_contributor-group_devops_platform" {
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
  role_definition_name = "Storage Table Data Contributor"
  scope                = azurerm_storage_account.zetesapifunc.id
}

resource "azurerm_role_assignment" "sa_zetesapimeta-table_reader-group_devops_platform" {
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
  role_definition_name = "Storage Table Data Reader"
  scope                = azurerm_storage_account.zetesapimeta.id
}
