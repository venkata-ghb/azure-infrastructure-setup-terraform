resource "azurerm_key_vault_secret" "qlik-sp_qlik_gt_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_qlik_gt.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_qlik_gt_password
  key_vault_id = azurerm_key_vault.qlik.id
  content_type = "${data.terraform_remote_state.ad.outputs.sp_qlik_gt.display_name} SP's Password by Terraform"
  tags         = local.resource_tags
}
