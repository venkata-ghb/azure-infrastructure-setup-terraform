resource "azurerm_monitor_action_group" "qm" {
  name                = "${local.prefix}-qm-integration-errors-action-group"
  resource_group_name = azurerm_resource_group.gtsapqm.name
  short_name          = "sap-qm-err"
  tags                = local.resource_tags

  email_receiver {
    name          = "Nico Miettinen"
    email_address = "nico.miettinen@kesko.fi"
  }

  email_receiver {
    name          = "DL_KESKOAMS_TCS_KDATA"
    email_address = "DL_KESKOAMS_TCS_KDATA@kesko.fi"
  }

}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-image_api_pod_availability" {
  name                = "${local.prefix}-image-api-pod-availability-alert"
  location            = azurerm_resource_group.gtsapqm.location
  resource_group_name = azurerm_resource_group.gtsapqm.name
  tags                = local.resource_tags

  action {
    action_group  = [azurerm_monitor_action_group.qm.id]
    email_subject = "Azure: SAP Quality Management input API availability alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "Alert to monitor SAP-QM-input-api pod availability"
  enabled        = true

  query       = <<QUERY
  KubePodInventory
  | where ClusterName == '${data.terraform_remote_state.container.outputs.aks_platform.name}'
  | where Namespace == 'qm' and ServiceName == "gtsap-qm-image-api-service" and PodStatus == "Running"
  QUERY
  severity    = 1
  frequency   = 60
  time_window = 120
  throttling  = 300
  trigger {
    operator  = "Equal"
    threshold = 0
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-image_api_service_availability" {
  name                = "${local.prefix}-image-api-service-availability-alert"
  location            = azurerm_resource_group.gtsapqm.location
  resource_group_name = azurerm_resource_group.gtsapqm.name
  tags                = local.resource_tags

  action {
    action_group  = [azurerm_monitor_action_group.qm.id]
    email_subject = "Azure: SAP Quality Management Input API service availability alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "Alert to monitor SAP-QM-input-api service availability"
  enabled        = true

  query       = <<QUERY
  KubeServices
  | where ClusterName == '${data.terraform_remote_state.container.outputs.aks_platform.name}'
  | where Namespace == "qm" and ServiceName == "gtsap-qm-image-api-service" and SelectorLabels contains "gtsap-qm-image-api-app"
  QUERY
  severity    = 1
  frequency   = 60
  time_window = 120
  throttling  = 300
  trigger {
    operator  = "Equal"
    threshold = 0
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-image_api_error" {
  name                = "${local.prefix}-image-api-error-alert"
  location            = azurerm_resource_group.gtsapqm.location
  resource_group_name = azurerm_resource_group.gtsapqm.name
  tags                = local.resource_tags

  action {
    action_group  = [azurerm_monitor_action_group.qm.id]
    email_subject = "Azure: SAP Quality Management input API error alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "Alert to monitor SAP-QM-input-api errors"
  enabled        = true

  query       = <<QUERY
  ContainerLogV2
  | where _ResourceId endswith "${data.terraform_remote_state.container.outputs.aks_platform.name}"
  | where PodNamespace == "qm" and ContainerName == "gtsap-qm-image-api-app-pod"
  | where LogMessage startswith "ERROR"
  QUERY
  severity    = 1
  frequency   = 60
  time_window = 120
  throttling  = 300
  trigger {
    operator  = "GreaterThan"
    threshold = 0
  }
}
