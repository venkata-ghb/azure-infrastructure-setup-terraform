resource "azurerm_api_management_api" "gtsap_qm_image" {
  provider            = azurerm.apim
  name                = "kdata-gtsap-qm-image-api"
  resource_group_name = replace(data.terraform_remote_state.apimanagement.outputs.apim_centralised.resource_group, "KESKO", "Kesko") # For backwards compability
  api_management_name = data.terraform_remote_state.apimanagement.outputs.apim_centralised.name
  revision            = "1"
  display_name        = "K-Data GTSAP QM Image api"
  path                = "kdata/gtsap-qm-image-api"
  protocols           = ["https"]
  service_url         = "${data.terraform_remote_state.container.outputs.aks_platform.inbound_api_url}/qm/api"

  import {
    content_format = "openapi+json"
    content_value  = file("${path.module}/resources/openapi.gtsap-qm-image-api.json")
  }
}

resource "azurerm_api_management_named_value" "gtsap_qm_image-secret" {
  provider            = azurerm.apim
  name                = "${azurerm_api_management_api.gtsap_qm_image.name}-secret"
  display_name        = "${azurerm_api_management_api.gtsap_qm_image.name}-secret"
  resource_group_name = azurerm_api_management_api.gtsap_qm_image.resource_group_name
  api_management_name = azurerm_api_management_api.gtsap_qm_image.api_management_name
  value               = random_password.imageapi_password.result
  tags                = ["api-secret"]
  secret              = true
}

resource "azurerm_api_management_api_policy" "gtsap_qm_image" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.gtsap_qm_image.name
  api_management_name = azurerm_api_management_api.gtsap_qm_image.api_management_name
  resource_group_name = azurerm_api_management_api.gtsap_qm_image.resource_group_name

  xml_content = file("${path.module}/resources/policy.xml")
}

resource "azurerm_api_management_product" "gtsap_qm_image" {
  provider              = azurerm.apim
  display_name          = azurerm_api_management_api.gtsap_qm_image.display_name
  product_id            = "${azurerm_api_management_api.gtsap_qm_image.name}-product"
  api_management_name   = azurerm_api_management_api.gtsap_qm_image.api_management_name
  resource_group_name   = azurerm_api_management_api.gtsap_qm_image.resource_group_name
  subscriptions_limit   = 0
  subscription_required = true
  approval_required     = false
  published             = true
}

resource "azurerm_api_management_product_api" "gtsap_qm_image" {
  provider            = azurerm.apim
  product_id          = azurerm_api_management_product.gtsap_qm_image.product_id
  api_name            = azurerm_api_management_api.gtsap_qm_image.name
  api_management_name = azurerm_api_management_api.gtsap_qm_image.api_management_name
  resource_group_name = azurerm_api_management_api.gtsap_qm_image.resource_group_name
}

resource "azurerm_api_management_product_group" "gtsap_qm_image" {
  provider            = azurerm.apim
  product_id          = azurerm_api_management_product.gtsap_qm_image.product_id
  api_management_name = azurerm_api_management_api.gtsap_qm_image.api_management_name
  resource_group_name = azurerm_api_management_api.gtsap_qm_image.resource_group_name
  group_name          = "6094c42076ab28d671139383"
}

resource "azurerm_api_management_api_tag" "gtsap_qm_image" {
  provider = azurerm.apim
  api_id   = azurerm_api_management_api.gtsap_qm_image.id
  name     = "k-data"
}
