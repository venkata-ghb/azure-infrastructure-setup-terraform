resource "random_password" "imageapi_password" {
  length           = 32
  special          = true
  #override_special = "_@"
}

resource "azurerm_key_vault_secret" "gtsapqm-image_api_secret" {
  key_vault_id = azurerm_key_vault.gtsapqm.id
  name         = "gtsap-qm-image-api-key"
  value        = random_password.imageapi_password.result
  content_type = "GTSAP QM Image Api key"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "gtsapqm-sa_imageapimeta_conn_str" {
  key_vault_id = azurerm_key_vault.gtsapqm.id
  name         = "image-api-storage-account-conn-str"
  value        = azurerm_storage_account.imageapimeta.primary_connection_string
  content_type = "QM Image api meta storage account connection string"
  tags         = local.resource_tags
}
