resource "azurerm_storage_account" "imageapimeta" {
  name                     = "${local.prefix_sa}imageapimeta"
  resource_group_name      = azurerm_resource_group.gtsapqm.name
  location                 = azurerm_resource_group.gtsapqm.location
  account_tier             = "Standard"
  account_replication_type = "GRS"
  blob_properties {
	  delete_retention_policy {
  		days = 60
	  }
  }
  tags = merge(local.resource_tags, {
    Purpose = "Store SAPQM Image metadata in tables"
  })

  network_rules {
    bypass = [
      "AzureServices",
      "Metrics",
    ]
    default_action = "Deny"
    ip_rules = [
      "157.144.241.0/24", # Kesko Workspace Network
      "157.144.201.0/24"  # Kesko Workspace Network-ER MS
    ]
    virtual_network_subnet_ids = [
      data.terraform_remote_state.vnets.outputs.subnet_integration.id,
      data.terraform_remote_state.vnets.outputs.subnet_robot.id,
      "/subscriptions/0ee45dee-812a-4353-9f8d-d01030378b13/resourceGroups/Kesko_WE_RG_Citrix_VNET1/providers/Microsoft.Network/virtualNetworks/CITRIX_VNET1_WE/subnets/CITRIX_SUBNET",
      "/subscriptions/0a2d289e-76dd-4b1f-b9b2-dba15a872e92/resourceGroups/rg-platform-avd-prod-weu-001/providers/Microsoft.Network/virtualNetworks/vnet-avd-prod-weu-001/subnets/Subnet-AVDTCS-AMS-prod-weu"
    ]
  }
}

resource "azurerm_storage_table" "imageapimeta-gtsapqm" {
  name                 = "gtsapqm"
  storage_account_name = azurerm_storage_account.imageapimeta.name
}
