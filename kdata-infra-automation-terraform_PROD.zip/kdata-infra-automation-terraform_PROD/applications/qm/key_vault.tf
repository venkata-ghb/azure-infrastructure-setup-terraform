data "azurerm_client_config" "current" {}

resource "azurerm_key_vault" "gtsapqm" {
  name                        = "${local.prefix}-gtsapqm-kv"
  location                    = local.location.long
  resource_group_name         = azurerm_resource_group.gtsapqm.name
  tenant_id                   = data.azurerm_client_config.current.tenant_id
  sku_name                    = "standard"
  enabled_for_disk_encryption = true
  purge_protection_enabled    = false
  tags                        = local.resource_tags

  access_policy = [
    local.msi_infra_key_vault_access,
    {
      tenant_id               = data.azurerm_client_config.current.tenant_id
      object_id               = data.terraform_remote_state.ad.outputs.group_admins_platform.id
      application_id          = ""
      certificate_permissions = ["Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"]
      key_permissions         = ["Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"]
      secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
      storage_permissions     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"]
    },
  ]
}

