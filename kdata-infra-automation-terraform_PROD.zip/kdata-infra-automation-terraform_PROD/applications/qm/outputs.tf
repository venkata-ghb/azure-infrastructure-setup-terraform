output "kv_gtsapqm" {
  value = {
    id        = azurerm_key_vault.gtsapqm.id
    name      = azurerm_key_vault.gtsapqm.name
    vault_uri = azurerm_key_vault.gtsapqm.vault_uri
  }
}

output "sa_imageapimeta" {
  value = {
    id   = azurerm_storage_account.imageapimeta.id
    name = azurerm_storage_account.imageapimeta.name
  }
}

output "msi_qm_imageapi" {
  value = azurerm_user_assigned_identity.qm_imageapi
}
