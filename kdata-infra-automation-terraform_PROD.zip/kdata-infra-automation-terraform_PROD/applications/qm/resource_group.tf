resource "azurerm_resource_group" "gtsapqm" {
  name     = "${local.prefix_rg}_GTSAPQM_Main_RG"
  location = local.location.long
  tags     = local.resource_tags
}