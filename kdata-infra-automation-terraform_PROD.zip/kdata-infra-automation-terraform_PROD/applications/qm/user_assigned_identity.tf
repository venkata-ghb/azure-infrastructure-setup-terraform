resource "azurerm_user_assigned_identity" "qm_imageapi" {
  resource_group_name = azurerm_resource_group.gtsapqm.name
  location            = azurerm_resource_group.gtsapqm.location
  name                = "${local.prefix}-qm-imageapi-mi"
}
