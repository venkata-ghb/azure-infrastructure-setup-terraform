resource "azurerm_storage_account" "plussa" {
  name                            = "${local.prefix_sa}${local.location.short}plussa"
  resource_group_name             = data.terraform_remote_state.integrations.outputs.rg_functionapp_app.name
  location                        = local.location.long
  account_tier                    = "Standard"
  account_replication_type        = "LRS"
  allow_nested_items_to_be_public = false
  min_tls_version                 = "TLS1_2"
  tags                            = local.resource_tags
  cross_tenant_replication_enabled = true
  network_rules {
    default_action = "Allow"
    virtual_network_subnet_ids = [ "/subscriptions/0a2d289e-76dd-4b1f-b9b2-dba15a872e92/resourceGroups/rg-platform-avd-prod-weu-001/providers/Microsoft.Network/virtualNetworks/vnet-avd-prod-weu-001/subnets/Subnet-AVDTCS-AMS-prod-weu" ]
  }
}
