resource "azurerm_linux_function_app" "plussa_harmoniser" {
  name                          = "${local.prefix}-${local.location.short}-plussa-harmoniser-funcapp"
  location                      = local.location.long
  resource_group_name           = data.terraform_remote_state.integrations.outputs.rg_functionapp_app.name
  service_plan_id               = replace(data.terraform_remote_state.integrations.outputs.service_plan_app_premium.id, "serverfarms", "serverFarms")
  storage_account_name          = azurerm_storage_account.plussa.name
  storage_uses_managed_identity = true
  https_only                    = true
  functions_extension_version   = "~4"
  builtin_logging_enabled       = false
  client_certificate_mode       = "Required"
  virtual_network_subnet_id     = data.terraform_remote_state.vnets.outputs.subnet_funcapp_app.id

  identity {
    type = "SystemAssigned"
  }

  site_config {
    always_on                              = true
    ftps_state                             = "Disabled"
    application_insights_key               = azurerm_application_insights.plussa_harmoniser.instrumentation_key
    application_insights_connection_string = azurerm_application_insights.plussa_harmoniser.connection_string
    vnet_route_all_enabled                 = true

    application_stack {
      python_version = "3.13"
    }
  }

  app_settings = {
    AzureWebJobsFeatureFlags                           = "EnableWorkerIndexing"
    WEBSITE_ENABLE_SYNC_UPDATE_SITE                    = false
    PoisonStorage__serviceUri                          = azurerm_storage_account.plussa.primary_blob_endpoint
    ConfluentConsumer                                  = "kdata-plussa-harmoniser"
    ConfluentOutboundTopicName                         = "com.kesko.com.plussa",
    ConfluentBroker                                    = "lkc-do28gz-6w9n9g.westeurope.azure.glb.confluent.cloud:9092"
    ConfluentApiKey                                    = "@Microsoft.KeyVault(SecretUri=${data.azurerm_key_vault_secret.plussa-confluent_client_key.id})"
    ConfluentApiSecret                                 = "@Microsoft.KeyVault(SecretUri=${data.azurerm_key_vault_secret.plussa-confluent_client_secret.id})"
    MarketPayStandaloneSource__fullyQualifiedNamespace = "${data.terraform_remote_state.integrations.outputs.ehns_marketpay.name}.servicebus.windows.net"
    OpenPOSSource__fullyQualifiedNamespace             = "${data.terraform_remote_state.integrations.outputs.ehns_openpos.name}.servicebus.windows.net"
    CONFLUENT_SCHEMA_REGISTRY_URL                      = "https://psrc-d88yz.westeurope.azure.confluent.cloud"
    CONFLUENT_SCHEMA_REGISTRY_KEY                      = "@Microsoft.KeyVault(SecretUri=${data.azurerm_key_vault_secret.plussa-confluent_schema_registry_key.id})"
    CONFLUENT_SCHEMA_REGISTRY_SECRET                   = "@Microsoft.KeyVault(SecretUri=${data.azurerm_key_vault_secret.plussa-confluent_schema_registry_secret.id})"
    LD_LIBRARY_PATH                                    = "/home/site/wwwroot/bin/runtimes/linux-x64/native"
  }

  tags = local.resource_tags

  lifecycle {
    ignore_changes = [
      app_settings["WEBSITES_ENABLE_APP_SERVICE_STORAGE"],
      app_settings["WEBSITE_ENABLE_SYNC_UPDATE_SITE"],
      app_settings["WEBSITE_RUN_FROM_PACKAGE"],
      tags["hidden-link: /app-insights-conn-string"],
      tags["hidden-link: /app-insights-instrumentation-key"],
      tags["hidden-link: /app-insights-resource-id"],
    ]
  }
}

resource "azurerm_application_insights" "plussa_harmoniser" {
  name                = "${local.prefix}-${local.location.short}-plussa-harmoniser-funcapp"
  location            = local.location.long
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_app.name
  application_type    = "web"
  retention_in_days   = 90
  sampling_percentage = 0
  tags                = local.resource_tags

  lifecycle {
    ignore_changes = [workspace_id]
  }
}
