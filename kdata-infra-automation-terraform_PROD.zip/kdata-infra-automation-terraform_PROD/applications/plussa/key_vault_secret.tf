data "azurerm_key_vault_secret" "plussa-confluent_client_key" {
  name         = "confluent-client-key"
  key_vault_id = azurerm_key_vault.plussa.id
}

data "azurerm_key_vault_secret" "plussa-confluent_client_secret" {
  name         = "confluent-client-secret"
  key_vault_id = azurerm_key_vault.plussa.id
}

data "azurerm_key_vault_secret" "plussa-confluent_schema_registry_key" {
  name         = "confluent-schema-registry-key"
  key_vault_id = azurerm_key_vault.plussa.id
}

data "azurerm_key_vault_secret" "plussa-confluent_schema_registry_secret" {
  name         = "confluent-schema-registry-secret"
  key_vault_id = azurerm_key_vault.plussa.id
}
