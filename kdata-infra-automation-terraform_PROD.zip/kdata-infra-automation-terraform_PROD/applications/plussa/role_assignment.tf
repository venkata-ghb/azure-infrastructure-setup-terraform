resource "azurerm_role_assignment" "sa_plussa-blob_owner-msi_plussa_harmoniser" {
  role_definition_name = "Storage Blob Data Owner"
  scope                = azurerm_storage_account.plussa.id
  principal_id         = azurerm_linux_function_app.plussa_harmoniser.identity[0].principal_id
}

resource "azurerm_role_assignment" "ehns_marketpay-eh_receiver-msi_plussa_harmoniser" {
  role_definition_name = "Azure Event Hubs Data Receiver"
  scope                = data.terraform_remote_state.integrations.outputs.ehns_marketpay.id
  principal_id         = azurerm_linux_function_app.plussa_harmoniser.identity[0].principal_id
}

resource "azurerm_role_assignment" "ehns_openpos-eh_receiver-msi_plussa_harmoniser" {
  role_definition_name = "Azure Event Hubs Data Receiver"
  scope                = data.terraform_remote_state.integrations.outputs.ehns_openpos.id
  principal_id         = azurerm_linux_function_app.plussa_harmoniser.identity[0].principal_id
}
