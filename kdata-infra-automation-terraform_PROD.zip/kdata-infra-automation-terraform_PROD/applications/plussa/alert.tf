resource "azurerm_monitor_metric_alert" "insights_plussa-exception" {
  name                = "${local.prefix}-appsinght-plussa-exception-alert"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_app.name
  scopes              = [azurerm_application_insights.plussa_harmoniser.id]
  description         = "Plussa harmoniser Function app Exception"
  auto_mitigate       = false
  frequency           = "PT15M"
  window_size         = "PT15M"
  severity            = 1

  criteria {
    metric_namespace = "Microsoft.Insights/Components"
    metric_name      = "exceptions/count"
    aggregation      = "Count"
    operator         = "GreaterThan"
    threshold        = 0

  }

  action {
    action_group_id = data.terraform_remote_state.monitoring.outputs.action_group_kesko_developers.id
  }

  tags = local.resource_tags
}
