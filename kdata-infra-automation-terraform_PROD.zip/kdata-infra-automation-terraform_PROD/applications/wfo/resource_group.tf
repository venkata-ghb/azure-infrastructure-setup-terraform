resource "azurerm_resource_group" "wfo" {
  name     = "${var.prefix_rg}_WFO_Main_RG"
  location = var.location

  tags = merge(local.resource_tags, {
    service           = "P19037"
    "Project Manager" = "Irina.Lehmuslehti@kesko.fi"
  })
}
