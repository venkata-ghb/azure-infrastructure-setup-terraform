resource "azurerm_key_vault_secret" "wfo-sp_wfo_edw_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_wfo_edw.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_wfo_edw_password
  key_vault_id = azurerm_key_vault.wfo.id
  content_type = "${data.terraform_remote_state.ad.outputs.sp_wfo_edw.display_name} SP's Password by Terraform"
  tags         = local.resource_tags
}
