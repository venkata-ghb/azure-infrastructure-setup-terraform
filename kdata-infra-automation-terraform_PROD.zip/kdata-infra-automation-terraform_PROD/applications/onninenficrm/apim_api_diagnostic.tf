resource "azurerm_api_management_api_diagnostic" "onninen_fi_crm_inbound" {
  provider                 = azurerm.apim
  identifier               = "applicationinsights"
  api_name                 = azurerm_api_management_api.onninen_fi_crm_inbound.name
  api_management_name      = azurerm_api_management_api.onninen_fi_crm_inbound.api_management_name
  resource_group_name      = azurerm_api_management_api.onninen_fi_crm_inbound.resource_group_name
  api_management_logger_id = data.terraform_remote_state.apimanagement.outputs.apim_logger_kgroup_kdata_apis.id
  always_log_errors        = true
}
