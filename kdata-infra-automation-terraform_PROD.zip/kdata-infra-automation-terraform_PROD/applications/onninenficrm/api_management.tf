resource "azurerm_api_management_api" "onninen_fi_crm_inbound" {
  provider            = azurerm.apim
  name                = "kdata-onninen-fi-crm-inbound-api"
  resource_group_name = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.resource_group
  api_management_name = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.name
  revision            = "1"
  display_name        = "KDATA Onninen FI CRM Inbound API"
  path                = "kdata/onninen-fi-crm-inbound-api"
  protocols           = ["https"]

  import {
    content_format = "openapi+json"
    content_value  = file("${path.module}/resources/openapi.json")
  }
}

resource "azurerm_api_management_api_policy" "onninen_fi_crm_inbound" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.onninen_fi_crm_inbound.name
  api_management_name = azurerm_api_management_api.onninen_fi_crm_inbound.api_management_name
  resource_group_name = azurerm_api_management_api.onninen_fi_crm_inbound.resource_group_name

  xml_content = <<XML
<policies>
    <inbound>
        <authentication-managed-identity resource="https://${data.terraform_remote_state.integrations.outputs.sa_adls.name}.blob.core.windows.net/" />
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>
  XML
}

resource "azurerm_api_management_api_operation_policy" "onninen_fi_crm_inbound" {
  for_each = toset([
    "contact",
  ])

  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.onninen_fi_crm_inbound.name
  api_management_name = azurerm_api_management_api.onninen_fi_crm_inbound.api_management_name
  resource_group_name = azurerm_api_management_api.onninen_fi_crm_inbound.resource_group_name
  operation_id        = "post-${each.value}"

  xml_content = templatefile(
    "${path.module}/resources/adls-policy.xml", {
      storage  = data.terraform_remote_state.integrations.outputs.sa_adls.name
      source   = "ONFICRM"
      dataset  = replace(each.value, "-", "_")
      filetype = "json"
  })
}

resource "azurerm_api_management_product" "onninen_fi_crm_inbound-onninen" {
  provider              = azurerm.apim
  display_name          = azurerm_api_management_api.onninen_fi_crm_inbound.display_name
  product_id            = "${azurerm_api_management_api.onninen_fi_crm_inbound.name}-onninen-product"
  api_management_name   = azurerm_api_management_api.onninen_fi_crm_inbound.api_management_name
  resource_group_name   = azurerm_api_management_api.onninen_fi_crm_inbound.resource_group_name
  subscriptions_limit   = 0
  subscription_required = true
  approval_required     = false
  published             = true
}

resource "azurerm_api_management_product_api" "onninen_fi_crm_inbound-onninen" {
  provider            = azurerm.apim
  product_id          = azurerm_api_management_product.onninen_fi_crm_inbound-onninen.product_id
  api_name            = azurerm_api_management_api.onninen_fi_crm_inbound.name
  api_management_name = azurerm_api_management_api.onninen_fi_crm_inbound.api_management_name
  resource_group_name = azurerm_api_management_api.onninen_fi_crm_inbound.resource_group_name
}

resource "azurerm_api_management_subscription" "onninen_fi_crm_inbound-onninen" {
  provider            = azurerm.apim
  api_management_name = azurerm_api_management_product.onninen_fi_crm_inbound-onninen.api_management_name
  resource_group_name = azurerm_api_management_product.onninen_fi_crm_inbound-onninen.resource_group_name
  product_id          = azurerm_api_management_product.onninen_fi_crm_inbound-onninen.id
  display_name        = "onninen-${azurerm_api_management_product.onninen_fi_crm_inbound-onninen.product_id}"
  subscription_id     = "onninen-${azurerm_api_management_product.onninen_fi_crm_inbound-onninen.product_id}"
  state               = "active"
}
