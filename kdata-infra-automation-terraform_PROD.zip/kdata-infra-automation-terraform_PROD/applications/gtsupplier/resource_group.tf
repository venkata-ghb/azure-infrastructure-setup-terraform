resource "azurerm_resource_group" "gtsupplierportal" {
  name     = "${var.prefix_rg}_GTSUPPLIERPORTAL_Main_RG"
  location = var.location
  tags     = local.resource_tags
}
