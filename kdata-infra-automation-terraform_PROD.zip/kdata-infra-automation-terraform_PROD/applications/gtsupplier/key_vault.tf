data "azurerm_client_config" "current" {}

locals {
  msi_kv_access_policy = {
    object_id               = data.terraform_remote_state.ad.outputs.msi_infra.id
    tenant_id               = "ae6e7baa-e1bf-4ef0-92a1-4eb28ec805c0"
    application_id          = ""
    certificate_permissions = ["Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"]
    key_permissions         = ["Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"]
    secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
    storage_permissions     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"]
  }
}

resource "azurerm_key_vault" "gtkpartner" {
  name                        = "${var.prefix}-gtkpartner-kv"
  location                    = var.location
  resource_group_name         = azurerm_resource_group.gtsupplierportal.name
  enabled_for_disk_encryption = true
  tenant_id                   = data.azurerm_client_config.current.tenant_id
  purge_protection_enabled    = false
  sku_name                    = "standard"
  tags                        = local.resource_tags

  access_policy = [
    local.msi_kv_access_policy,
    {
      tenant_id               = data.azurerm_client_config.current.tenant_id
      object_id               = data.terraform_remote_state.ad.outputs.group_admins_platform.id
      application_id          = ""
      certificate_permissions = ["Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"]
      key_permissions         = ["Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"]
      secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
      storage_permissions     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"]
    },
    {
      tenant_id               = data.azurerm_subscription.current.tenant_id
      object_id               = "0b76c138-ab01-423f-b0db-775b3bf5d63b" # AzureDatabricks
      application_id          = ""
      certificate_permissions = []
      key_permissions         = []
      secret_permissions      = ["Get", "List", ]
      storage_permissions     = []
    },
  ]
}
