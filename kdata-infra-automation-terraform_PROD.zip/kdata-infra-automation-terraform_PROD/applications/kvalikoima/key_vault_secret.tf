resource "azurerm_key_vault_secret" "kvalikoima-eh_kvalikoima_navigation_natural_k8s_read" {
  key_vault_id = azurerm_key_vault.kvalikoima.id
  name         = "eh-kvalikoima-navigation-natural-k8s-read"
  value        = azurerm_eventhub_authorization_rule.kvalikoima-navigation_natural-k8s_read.primary_connection_string
  content_type = "K-Valikoima navigation Natural EvenhHub's endpoint read access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "kvalikoima-eh_kvalikoima_navigation_natural_k8s_write" {
  key_vault_id = azurerm_key_vault.kvalikoima.id
  name         = "eh-kvalikoima-navigation-natural-k8s-write"
  value        = azurerm_eventhub_authorization_rule.kvalikoima-navigation_natural-k8s_write.primary_connection_string
  content_type = "K-valikoima navigation Natural EvenhHub's endpoint write access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "kvalikoima-eh_kvalikoima_navigation_natural_consumer" {
  key_vault_id = azurerm_key_vault.kvalikoima.id
  name         = "eh-kvalikoima-navigation-natural-consumer"
  value        = azurerm_eventhub_authorization_rule.kvalikoima-navigation_natural-consumer.primary_connection_string
  content_type = "K-valikoima navigation Natural EvenhHub's endpoint write access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "kvalikoima-eh_kvalikoima_settings_natural_k8s_read" {
  key_vault_id = azurerm_key_vault.kvalikoima.id
  name         = "eh-kvalikoima-settings-natural-k8s-read"
  value        = azurerm_eventhub_authorization_rule.kvalikoima-settings_natural-k8s_read.primary_connection_string
  content_type = "K-Valikoima settings Natural EvenhHub's endpoint read access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "kvalikoima-eh_kvalikoima_settings_natural_k8s_write" {
  key_vault_id = azurerm_key_vault.kvalikoima.id
  name         = "eh-kvalikoima-settings-natural-k8s-write"
  value        = azurerm_eventhub_authorization_rule.kvalikoima-settings_natural-k8s_write.primary_connection_string
  content_type = "K-valikoima settings Natural EvenhHub's endpoint write access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "kvalikoima-eh_kvalikoima_settings_natural_consumer" {
  key_vault_id = azurerm_key_vault.kvalikoima.id
  name         = "eh-kvalikoima-settings-natural-consumer"
  value        = azurerm_eventhub_authorization_rule.kvalikoima-settings_natural-consumer.primary_connection_string
  content_type = "K-valikoima settings Natural EvenhHub's endpoint write access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "kvalikoima-eh_kvalikoima_mrp_natural_k8s_read" {
  key_vault_id = azurerm_key_vault.kvalikoima.id
  name         = "eh-kvalikoima-mrp-natural-k8s-read"
  value        = azurerm_eventhub_authorization_rule.kvalikoima-mrp_natural-k8s_read.primary_connection_string
  content_type = "K-Valikoima material requirements planning Natural EvenhHub's endpoint read access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "kvalikoima-eh_kvalikoima_mrp_natural_k8s_write" {
  key_vault_id = azurerm_key_vault.kvalikoima.id
  name         = "eh-kvalikoima-mrp-natural-k8s-write"
  value        = azurerm_eventhub_authorization_rule.kvalikoima-mrp_natural-k8s_write.primary_connection_string
  content_type = "K-valikoima material requirements planning Natural EvenhHub's endpoint write access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "kvalikoima-eh_kvalikoima_mrp_natural_consumer" {
  key_vault_id = azurerm_key_vault.kvalikoima.id
  name         = "eh-mrp-settings-natural-consumer"
  value        = azurerm_eventhub_authorization_rule.kvalikoima-mrp_natural-consumer.primary_connection_string
  content_type = "K-valikoima material requirements planning Natural EvenhHub's endpoint write access"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "kvalikoima-eh_kvalikoima_mrp_natural_inspis_read" {
  key_vault_id = azurerm_key_vault.kvalikoima.id
  name         = "eh-kvalikoima-mrp-natural-inspis-read"
  value        = azurerm_eventhub_authorization_rule.kvalikoima-mrp_natural-inspis_read.primary_connection_string
  content_type = "K-Valikoima material requirements planning Natural EvenhHub's endpoint read access for Inspis"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "kvalikoima-sp_kvalikoima_databricks_secret" {
  key_vault_id = azurerm_key_vault.kvalikoima.id
  name         = data.terraform_remote_state.ad.outputs.sp_kvalikoima_databricks.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_kvalikoima_databricks_password
  content_type = "${data.terraform_remote_state.ad.outputs.sp_kvalikoima_databricks.display_name} SP's Password by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "kvalikoima-sp_kvalikoima_dbwrite_secret" {
  key_vault_id = azurerm_key_vault.kvalikoima.id
  name         = data.terraform_remote_state.ad.outputs.sp_kvalikoima_dbwrite.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_kvalikoima_dbwrite_password
  content_type = "${data.terraform_remote_state.ad.outputs.sp_kvalikoima_dbwrite.display_name} SP's Password by Terraform"
  tags         = local.resource_tags
}
