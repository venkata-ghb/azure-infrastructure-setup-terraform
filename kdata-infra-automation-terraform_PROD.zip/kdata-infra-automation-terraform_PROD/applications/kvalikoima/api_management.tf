data "azurerm_api_management" "apimanagement" {
  provider            = azurerm.apim
  name                = "K-apim-${local.env.short}"
  resource_group_name = "KESKO_WE_RG_APIM_${upper(local.env.short)}001"
}

resource "azurerm_api_management_api" "kvalikoima_input" {
  provider            = azurerm.apim
  name                = "${local.prefix}-kvalikoima-input-api"
  resource_group_name = data.azurerm_api_management.apimanagement.resource_group_name
  api_management_name = data.azurerm_api_management.apimanagement.name
  revision            = "1"
  display_name        = "K-data K-valikoima Input API"
  path                = "kdata/kvalikoima-input-api"
  protocols           = ["https"]

  import {
    content_format = "swagger-json"
    content_value  = <<JSON
{
    "swagger": "2.0",
    "info": {
        "title": "K-data K-valikoima Input API",
        "version": "1.0"
    },
    "host": "${substr(data.azurerm_api_management.apimanagement.gateway_url, 8, -1)}",
    "basePath": "/kdata/kvalikoima-input-api",
    "schemes": [
        "https"
    ],
    "produces": [
        "application/json"
    ],
    "paths": {
        "/route-event": {
            "post": {
                "summary": "route-event",
                "description": "POST k-valikoima messages",
                "operationId": "post-route-event",
                "parameters": [
                    {
                        "$ref": "#/parameters/Body"
                    }
                ],
                "responses": {
                    "200": {
                        "$ref": "#/responses/OK"
                    },
                    "400": {
                        "$ref": "#/responses/FAILURE"
                    },
                    "500": {
                        "$ref": "#/responses/INTERNAL"
                    }
                }
            }
        }
    },
    "parameters": {
        "Body": {
            "in": "body",
            "name": "BatchPayload",
            "description": "Batch Payload",
            "schema": {
                "$ref": "#/definitions/Event"
            }
        }
    },
    "definitions": {
        "Event": {
            "type": "object",
            "required": ["type"],
            "properties": {
                "type": {
                    "type": "string"
                }
            }
        },
        "Response200": {
            "type": "object",
            "example": "{}"
        },
        "Response400": {
            "type": "object",
            "properties": {
                "statusCode": {
                    "type": "integer",
                    "example": 400
                },
                "message": {
                    "type": "string",
                    "example": "Invalid request payload input"
                },
                "error": {
                    "type": "string",
                    "example": "Bad Request"
                }
            }
        },
        "Response500": {
            "type": "object",
            "properties": {
                "statusCode": {
                    "type": "integer",
                    "example": 500
                },
                "message": {
                    "type": "string",
                    "example": "Internal error"
                }
            }
        }
    },
    "responses": {
        "OK": {
            "description": "OK",
            "schema": {
                "$ref": "#/definitions/Response200"
            }
        },
        "FAILURE": {
            "description": "Malformed input data",
            "schema": {
                "$ref": "#/definitions/Response400"
            }
        },
        "INTERNAL": {
            "description": "Internal error",
            "schema": {
                "$ref": "#/definitions/Response500"
            }
        }
    },
    "securityDefinitions": {
        "apiKeyHeader": {
            "type": "apiKey",
            "name": "Ocp-Apim-Subscription-Key",
            "in": "header"
        },
        "apiKeyQuery": {
            "type": "apiKey",
            "name": "subscription-key",
            "in": "query"
        }
    },
    "security": [
        {
            "apiKeyHeader": []
        },
        {
            "apiKeyQuery": []
        }
    ]
}
    JSON
  }
}

resource "azurerm_api_management_api_policy" "kvalikoima_input" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.kvalikoima_input.name
  api_management_name = azurerm_api_management_api.kvalikoima_input.api_management_name
  resource_group_name = azurerm_api_management_api.kvalikoima_input.resource_group_name

  xml_content = <<XML
<policies>
    <inbound>
        <base />
           <set-backend-service base-url="${data.terraform_remote_state.container.outputs.aks_platform.inbound_api_url}/kvalikoima/api" />
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>
XML
}

resource "azurerm_api_management_product" "kvalikoima_input" {
  provider              = azurerm.apim
  product_id            = "${azurerm_api_management_api.kvalikoima_input.name}-product"
  api_management_name   = azurerm_api_management_api.kvalikoima_input.api_management_name
  resource_group_name   = azurerm_api_management_api.kvalikoima_input.resource_group_name
  display_name          = azurerm_api_management_api.kvalikoima_input.display_name
  subscriptions_limit   = 0
  subscription_required = true
  approval_required     = false
  published             = true
}

resource "azurerm_api_management_product_api" "kvalikoima_input" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.kvalikoima_input.name
  product_id          = azurerm_api_management_product.kvalikoima_input.product_id
  api_management_name = azurerm_api_management_api.kvalikoima_input.api_management_name
  resource_group_name = azurerm_api_management_api.kvalikoima_input.resource_group_name
}

resource "azurerm_api_management_product_group" "kvalikoima_input" {
  provider            = azurerm.apim
  product_id          = azurerm_api_management_product.kvalikoima_input.product_id
  group_name          = "6094c40bd221166a7d9996a2"
  api_management_name = azurerm_api_management_api.kvalikoima_input.api_management_name
  resource_group_name = azurerm_api_management_api.kvalikoima_input.resource_group_name
}

resource "azurerm_api_management_api_tag" "kvalikoima_input" {
  provider = azurerm.apim
  api_id   = azurerm_api_management_api.kvalikoima_input.id
  name     = "k-data"
}
