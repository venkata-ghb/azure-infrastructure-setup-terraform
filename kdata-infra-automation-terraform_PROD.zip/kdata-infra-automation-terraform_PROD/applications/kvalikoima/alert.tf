resource "azurerm_monitor_action_group" "kvalikoima" {
  name                = "${local.prefix}-kvalikoima-integration-errors-action-group"
  resource_group_name = azurerm_resource_group.kvalikoima.name
  short_name          = "kval-int-err"
  tags                = local.resource_tags

  email_receiver {
    name          = "DL_KESKOAMS_TCS_KDATA"
    email_address = "DL_KESKOAMS_TCS_KDATA@kesko.fi"
  }
  email_receiver {
    name          = "NicoMiettinen"
    email_address = "nico.miettinen@kesko.fi"
  }
}

resource "azurerm_monitor_activity_log_alert" "ehns_kvalikoima-health" {
  name                = "${local.prefix}-kvalikoima-eventhub-health-alert"
  resource_group_name = azurerm_resource_group.kvalikoima.name
  scopes              = [data.terraform_remote_state.integrations.outputs.ehns_kvalikoima.id]
  description         = "Alert to monitor K-Valikoima Event Hub namespace health status."
  tags                = local.resource_tags

  criteria {
    resource_id = data.terraform_remote_state.integrations.outputs.ehns_kvalikoima.id
    category    = "ResourceHealth"
  }

  action {
    action_group_id = azurerm_monitor_action_group.kvalikoima.id
  }

}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-kvalikoima_inputapi_pod_availability" {
  name                = "${local.prefix}-kvalikoima-inputapi-pod-availability-alert"
  location            = azurerm_resource_group.kvalikoima.location
  resource_group_name = azurerm_resource_group.kvalikoima.name
  tags                = local.resource_tags

  action {
    action_group  = [azurerm_monitor_action_group.kvalikoima.id]
    email_subject = "Azure: K-Data K-Valikoima input API availability alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "Alert to monitor K-Valikoima-input-api pod availability"
  enabled        = true

  query       = <<QUERY
  KubePodInventory
  | where ClusterName == '${data.terraform_remote_state.container.outputs.aks_platform.name}' 
  | where Namespace == 'kvalikoima' and ServiceName == "k-valikoima-input-api-service" and PodStatus == "Running"
  QUERY
  severity    = 1
  frequency   = 60
  time_window = 120
  throttling  = 300
  trigger {
    operator  = "Equal"
    threshold = 0
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-kvalikoima_inputapi_service_availability" {
  name                = "${local.prefix}-kvalikoima-inputapi-service-availability-alert"
  location            = azurerm_resource_group.kvalikoima.location
  resource_group_name = azurerm_resource_group.kvalikoima.name
  tags                = local.resource_tags

  action {
    action_group  = [azurerm_monitor_action_group.kvalikoima.id]
    email_subject = "Azure: K-Data K-Valikoima input API service availability alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "Alert to monitor K-Valikoima-input-api service availability"
  enabled        = true

  query       = <<QUERY
  KubeServices
  | where ClusterName == '${data.terraform_remote_state.container.outputs.aks_platform.name}' 
  | where Namespace == "kvalikoima" and ServiceName == "k-valikoima-input-api-service"
    and SelectorLabels contains "k-valikoima-input-api-app"
  QUERY
  severity    = 1
  frequency   = 60
  time_window = 120
  throttling  = 300
  trigger {
    operator  = "Equal"
    threshold = 0
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert" "aks_platform-kvalikoima_inputapi_eventhub_failure" {
  name                = "${local.prefix}-kvalikoima-inputapi-eventhub-failure-alert"
  location            = azurerm_resource_group.kvalikoima.location
  resource_group_name = azurerm_resource_group.kvalikoima.name
  tags                = local.resource_tags

  action {
    action_group  = [azurerm_monitor_action_group.kvalikoima.id]
    email_subject = "Azure: K-Data K-Valikoima input API event hub failure alert was triggered in ${upper(local.env.short)}"
  }

  data_source_id = data.terraform_remote_state.monitoring.outputs.loganalytics_workspace.id
  description    = "Alert to monitor K-Valikoima-input-api event hub failures"
  enabled        = true

  query       = <<QUERY
  ContainerLogV2
  | where _ResourceId endswith "${data.terraform_remote_state.container.outputs.aks_platform.name}"
  | where PodNamespace == 'kvalikoima' and ContainerName == 'k-valikoima-input-api-app-pod'
  | where LogMessage contains "Reached retry cap with"
  QUERY
  severity    = 1
  frequency   = 60
  time_window = 120
  throttling  = 300
  trigger {
    operator  = "GreaterThan"
    threshold = 10
  }
}
