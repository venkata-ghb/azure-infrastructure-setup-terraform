output "kv_kvalikoima" {
  value = {
    id        = azurerm_key_vault.kvalikoima.id
    name      = azurerm_key_vault.kvalikoima.name
    vault_uri = azurerm_key_vault.kvalikoima.vault_uri
  }
}
