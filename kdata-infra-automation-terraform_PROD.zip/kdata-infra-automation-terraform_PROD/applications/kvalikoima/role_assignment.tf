resource "azurerm_role_assignment" "rg_kvalikoima-contributor-group_admins_platform" {
  principal_id         = data.terraform_remote_state.ad.outputs.group_admins_platform.id
  role_definition_name = "Contributor"
  scope                = azurerm_resource_group.kvalikoima.id
}

resource "azurerm_role_assignment" "rg_kvalikoima-reader-group_devops_platform" {
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
  role_definition_name = "Reader"
  scope                = azurerm_resource_group.kvalikoima.id
}
