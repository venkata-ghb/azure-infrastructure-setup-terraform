data "azurerm_client_config" "current" {}

resource "azurerm_key_vault" "kvalikoima" {
  name                        = "${local.prefix}-kvalikoima-kv"
  location                    = local.location.long
  resource_group_name         = azurerm_resource_group.kvalikoima.name
  tenant_id                   = data.azurerm_client_config.current.tenant_id
  sku_name                    = "standard"
  enabled_for_disk_encryption = true
  purge_protection_enabled    = false
  tags                        = local.resource_tags
}

resource "azurerm_key_vault_access_policy" "kvalikoima-msi_infra" {
  key_vault_id            = azurerm_key_vault.kvalikoima.id
  tenant_id               = data.azurerm_client_config.current.tenant_id
  object_id               = local.msi_infra_key_vault_access.object_id
  secret_permissions      = local.msi_infra_key_vault_access.secret_permissions
  key_permissions         = local.msi_infra_key_vault_access.key_permissions
  certificate_permissions = local.msi_infra_key_vault_access.certificate_permissions
}

resource "azurerm_key_vault_access_policy" "kvalikoima-group_admins_platform" {
  key_vault_id = azurerm_key_vault.kvalikoima.id
  tenant_id    = data.azurerm_client_config.current.tenant_id
  object_id    = data.terraform_remote_state.ad.outputs.group_admins_platform.id
  secret_permissions = [
    "Get",
    "Set",
    "List",
    "Delete"
  ]
  key_permissions = [
    "Create",
    "Get",
    "List",
    "Delete"
  ]
  certificate_permissions = [
    "Create",
    "Update",
    "Get",
    "List",
    "Delete"
  ]
}
