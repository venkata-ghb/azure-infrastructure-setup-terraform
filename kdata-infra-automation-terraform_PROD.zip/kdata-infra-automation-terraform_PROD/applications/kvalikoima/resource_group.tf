resource "azurerm_resource_group" "kvalikoima" {
  name     = "${local.prefix_rg}_KVALIKOIMA_Main_RG"
  location = local.location.long
  tags     = merge(local.resource_tags, {
    Application = "K-Valikoima"
    Sub-Service = "C1241"
  })
}