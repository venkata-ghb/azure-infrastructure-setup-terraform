# =======================================================
# Key Vault
# =======================================================

resource "azurerm_monitor_diagnostic_setting" "kv_kvalikoima" {
  name               = "${azurerm_key_vault.kvalikoima.name}-audit"
  target_resource_id = azurerm_key_vault.kvalikoima.id
  storage_account_id = data.terraform_remote_state.monitoring.outputs.sa_auditlogs.id

  enabled_log {
    category = "AuditEvent"

    retention_policy {
      days    = 365
      enabled = true
    }
  }

  metric {
    category = "AllMetrics"
    enabled  = true

    retention_policy {
      days    = 365
      enabled = true
    }
  }
}
