variable "load_balancer_ip" {
	type        = string
  default     = "10.248.72.124"
  description = "Load Balancer in kubernetes for K-valikoima API"
}
