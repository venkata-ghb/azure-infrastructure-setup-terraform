resource "azurerm_eventhub_authorization_rule" "kvalikoima-navigation_natural-k8s_read" {
  name                = "kvalikoima-navigation-natural-k8s-read"
  eventhub_name       = "kvalikoima-navigation-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_kvalikoima.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_kvalikoima.resource_group_name
  listen              = true
  send                = false
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "kvalikoima-navigation_natural-k8s_write" {
  name                = "kvalikoima-navigation-natural-k8s-write"
  eventhub_name       = "kvalikoima-navigation-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_kvalikoima.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_kvalikoima.resource_group_name
  listen              = false
  send                = true
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "kvalikoima-navigation_natural-consumer" {
  name                = "consumer"
  eventhub_name       = "kvalikoima-navigation-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_kvalikoima.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_kvalikoima.resource_group_name
  listen              = true
  send                = false
  manage              = false
}


resource "azurerm_eventhub_authorization_rule" "kvalikoima-settings_natural-k8s_read" {
  name                = "kvalikoima-settings-natural-k8s-read"
  eventhub_name       = "kvalikoima-settings-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_kvalikoima.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_kvalikoima.resource_group_name
  listen              = true
  send                = false
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "kvalikoima-settings_natural-k8s_write" {
  name                = "kvalikoima-settings-natural-k8s-write"
  eventhub_name       = "kvalikoima-settings-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_kvalikoima.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_kvalikoima.resource_group_name
  listen              = false
  send                = true
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "kvalikoima-settings_natural-consumer" {
  name                = "consumer"
  eventhub_name       = "kvalikoima-settings-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_kvalikoima.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_kvalikoima.resource_group_name
  listen              = true
  send                = false
  manage              = false
}


resource "azurerm_eventhub_authorization_rule" "kvalikoima-mrp_natural-k8s_read" {
  name                = "kvalikoima-mrp-natural-k8s-read"
  eventhub_name       = "kvalikoima-mrp-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_kvalikoima.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_kvalikoima.resource_group_name
  listen              = true
  send                = false
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "kvalikoima-mrp_natural-k8s_write" {
  name                = "kvalikoima-mrp-natural-k8s-write"
  eventhub_name       = "kvalikoima-mrp-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_kvalikoima.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_kvalikoima.resource_group_name
  listen              = false
  send                = true
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "kvalikoima-mrp_natural-consumer" {
  name                = "consumer"
  eventhub_name       = "kvalikoima-mrp-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_kvalikoima.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_kvalikoima.resource_group_name
  listen              = true
  send                = false
  manage              = false
}

resource "azurerm_eventhub_authorization_rule" "kvalikoima-mrp_natural-inspis_read" {
  name                = "inspis-read"
  eventhub_name       = "kvalikoima-mrp-natural"
  namespace_name      = data.terraform_remote_state.integrations.outputs.ehns_kvalikoima.name
  resource_group_name = data.terraform_remote_state.integrations.outputs.ehns_kvalikoima.resource_group_name
  listen              = true
  send                = false
  manage              = false
}
