resource "azurerm_linux_function_app" "kafkaproxy" {
  name                        = "${local.prefix}-${local.location.short}-kafkaproxy-funcapp"
  location                    = local.location.long
  resource_group_name         = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  service_plan_id             = replace(data.terraform_remote_state.integrations.outputs.service_plan_int_premium.id, "serverFarms", "serverfarms")
  storage_account_name        = azurerm_storage_account.kafkaproxy.name
  storage_account_access_key  = azurerm_storage_account.kafkaproxy.primary_access_key
  https_only                  = true
  functions_extension_version = "~4"
  builtin_logging_enabled     = false
  client_certificate_mode     = "Required"
  virtual_network_subnet_id   = data.terraform_remote_state.vnets.outputs.subnet_funcapp_int.id


  identity {
    type = "SystemAssigned"
  }

  site_config {
    always_on                              = true
    ftps_state                             = "Disabled"
    application_insights_key               = azurerm_application_insights.kafkaproxy.instrumentation_key
    application_insights_connection_string = azurerm_application_insights.kafkaproxy.connection_string
    vnet_route_all_enabled                 = true

    application_stack {
      python_version = "3.11"
    }
  }

  app_settings = {
    AzureWebJobsFeatureFlags         = "EnableWorkerIndexing"
    WEBSITE_ENABLE_SYNC_UPDATE_SITE  = false
    CONFLUENT_BOOTSTRAP_SERVER       = "lkc-do28gz-6w9n9g.westeurope.azure.glb.confluent.cloud:9092"
    CONFLUENT_CLIENT_KEY             = "@Microsoft.KeyVault(SecretUri=${data.azurerm_key_vault_secret.kafkaproxy-confluent_client_key.id})"
    CONFLUENT_CLIENT_SECRET          = "@Microsoft.KeyVault(SecretUri=${data.azurerm_key_vault_secret.kafkaproxy-confluent_client_secret.id})"
    CONFLUENT_SCHEMA_REGISTRY_URL    = "https://psrc-d88yz.westeurope.azure.confluent.cloud"
    CONFLUENT_SCHEMA_REGISTRY_KEY    = "@Microsoft.KeyVault(SecretUri=${data.azurerm_key_vault_secret.kafkaproxy-confluent_schema_registry_key.id})"
    CONFLUENT_SCHEMA_REGISTRY_SECRET = "@Microsoft.KeyVault(SecretUri=${data.azurerm_key_vault_secret.kafkaproxy-confluent_schema_registry_secret.id})"
    LD_LIBRARY_PATH                  = "/home/site/wwwroot/bin/runtimes/linux-x64/native"
  }

  tags = local.resource_tags

  lifecycle {
    ignore_changes = [
      app_settings["WEBSITE_ENABLE_SYNC_UPDATE_SITE"],
      app_settings["WEBSITE_RUN_FROM_PACKAGE"],
      tags["hidden-link: /app-insights-conn-string"],
      tags["hidden-link: /app-insights-instrumentation-key"],
      tags["hidden-link: /app-insights-resource-id"],
    ]
  }
}

resource "azurerm_application_insights" "kafkaproxy" {
  name                = "${local.prefix}-${local.location.short}-kafkaproxy-funcapp"
  location            = local.location.long
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  application_type    = "web"
  retention_in_days   = 90
  sampling_percentage = 0
  tags                = local.resource_tags

  lifecycle {
    ignore_changes = [ workspace_id ]
  }
}
