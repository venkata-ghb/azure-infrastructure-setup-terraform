# =======================================================
# Key Vault
# =======================================================

resource "azurerm_monitor_diagnostic_setting" "kv_kafkaproxy" {
  name               = "${azurerm_key_vault.kafkaproxy.name}-audit"
  target_resource_id = azurerm_key_vault.kafkaproxy.id
  storage_account_id = data.terraform_remote_state.monitoring.outputs.sa_auditlogs.id

  enabled_log {
    category = "AuditEvent"
  }

  metric {
    category = "AllMetrics"
    enabled  = true
  }
}
