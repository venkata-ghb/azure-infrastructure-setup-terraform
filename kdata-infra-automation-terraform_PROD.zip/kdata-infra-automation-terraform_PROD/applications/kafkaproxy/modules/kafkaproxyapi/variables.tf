variable api_name {
  type = string
}

variable api_display_name {
  type = string
}

variable api_path {
  type = string
}

variable confluent_topic_name {
  type = string
}

variable backend_url {
  type = string
}

variable product_api_bindings {
  type        = set(string)
  default     = []
  description = "List of products to bind the api to"
}

variable function_key_named_value {
  type = string
}

variable api_management_resource_group_name {
  type = string
}
variable api_management_name {
  type = string
}

variable api_management_logger_id {
  type = string
}
