resource "azurerm_api_management_api" "kafkaproxy" {
  name                = "kdata-kafkaproxy-${var.api_name}-inbound-api"
  resource_group_name = var.api_management_resource_group_name
  api_management_name = var.api_management_name
  revision            = "1"
  display_name        = "KDATA Kafkaproxy ${var.api_display_name} Inbound API"
  path                = "kdata/kafkaproxy/${var.api_path}"
  protocols           = ["https"]

  import {
    content_format = "openapi+json"
    content_value = templatefile(
      "${path.module}/openapi.kafkaproxy.template.json", {
        display_name = var.api_display_name
        endpoint     = var.api_name
    })
  }
}

resource "azurerm_api_management_api_policy" "kafkaproxy" {
  api_name            = azurerm_api_management_api.kafkaproxy.name
  resource_group_name = azurerm_api_management_api.kafkaproxy.resource_group_name
  api_management_name = azurerm_api_management_api.kafkaproxy.api_management_name

  xml_content = <<XML
<policies>
    <inbound>
        <base />
        <set-header name="x-functions-key" exists-action="override">
            <value>{{${var.function_key_named_value}}}</value>
        </set-header>
        <set-backend-service base-url="https://${var.backend_url}/api/confluent" />
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>
XML
}

resource "azurerm_api_management_api_operation_policy" "kafkaproxy-post_event" {
  api_name            = azurerm_api_management_api.kafkaproxy.name
  resource_group_name = azurerm_api_management_api.kafkaproxy.resource_group_name
  api_management_name = azurerm_api_management_api.kafkaproxy.api_management_name
  operation_id        = "post-event"

  xml_content = <<XML
<policies>
    <inbound>
        <base />
        <rewrite-uri template="/${var.confluent_topic_name}" />
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>
XML
}

resource "azurerm_api_management_product_api" "kafkaproxy-api" {
  for_each            = var.product_api_bindings
  product_id          = each.key
  api_name            = azurerm_api_management_api.kafkaproxy.name
  api_management_name = azurerm_api_management_api.kafkaproxy.api_management_name
  resource_group_name = azurerm_api_management_api.kafkaproxy.resource_group_name
}

resource "azurerm_api_management_api_diagnostic" "kafkaproxy-api" {
  identifier               = "applicationinsights"
  resource_group_name      = azurerm_api_management_api.kafkaproxy.resource_group_name
  api_management_name      = azurerm_api_management_api.kafkaproxy.api_management_name
  api_name                 = azurerm_api_management_api.kafkaproxy.name
  api_management_logger_id = var.api_management_logger_id
  always_log_errors        = true
}
