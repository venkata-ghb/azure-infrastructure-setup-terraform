resource "azurerm_monitor_action_group" "kafkaproxy" {
  name                = "${local.prefix}-kafkaproxy-integration-errors-action-group"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  short_name          = "kafkaproxy"

  tags = local.resource_tags

  email_receiver {
    name          = "DL_KESKOAMS_TCS_KDATA"
    email_address = "DL_KESKOAMS_TCS_KDATA@kesko.fi"
  }
  email_receiver {
    name          = "NicoMiettinen"
    email_address = "nico.miettinen@kesko.fi"
  }
}

resource "azurerm_monitor_metric_alert" "insights_kafkaproxy-exception" {
  name                = "${local.prefix}-appsinght-kafkaproxy-exception-alert"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  scopes              = [azurerm_application_insights.kafkaproxy.id]
  description         = "kafkaproxy Function app Exceptions"
  auto_mitigate       = true
  frequency           = "PT15M"
  window_size         = "PT15M"
  severity            = 1

  criteria {
    metric_namespace = "Microsoft.Insights/Components"
    metric_name      = "exceptions/count"
    aggregation      = "Count"
    operator         = "GreaterThan"
    threshold        = 0
  }

  action {
    action_group_id = azurerm_monitor_action_group.kafkaproxy.id
  }

  tags = local.resource_tags
}

resource "azurerm_monitor_metric_alert" "insights_kafkaproxy-response_500" {
  name                = "${local.prefix}-appsinght-kafkaproxy-response-500-alert"
  resource_group_name = data.terraform_remote_state.integrations.outputs.rg_functionapp_int.name
  scopes              = [azurerm_application_insights.kafkaproxy.id]
  description         = "kafkaproxy Function app response 500 (exceptions)"
  auto_mitigate       = true
  frequency           = "PT15M"
  window_size         = "PT15M"
  severity            = 1

  criteria {
    metric_namespace = "Microsoft.Insights/Components"
    metric_name      = "requests/count"
    aggregation      = "Count"
    operator         = "GreaterThan"
    threshold        = 0

    dimension {
      name     = "request/resultCode"
      operator = "Include"
      values   = ["500"]
    }
  }

  action {
    action_group_id = azurerm_monitor_action_group.kafkaproxy.id
  }

  tags = local.resource_tags
}
