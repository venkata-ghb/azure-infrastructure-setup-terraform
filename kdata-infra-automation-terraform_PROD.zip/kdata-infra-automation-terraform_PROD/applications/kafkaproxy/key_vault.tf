resource "azurerm_key_vault" "kafkaproxy" {
  name                        = "${local.prefix}-kafkaproxy-kv"
  location                    = local.location.long
  resource_group_name         = data.terraform_remote_state.integrations.outputs.rg_vault.name
  tenant_id                   = var.TENANT_ID
  sku_name                    = "standard"
  enabled_for_disk_encryption = true
  purge_protection_enabled    = true
  soft_delete_retention_days  = 90
  tags                        = local.resource_tags

  network_acls {
    default_action = "Deny"
    bypass         = "AzureServices"
    ip_rules = [
      "157.144.201.0/24", # Kesko Workspace Network-ER MS
      "157.144.241.0/24", # Kesko Workspace Network
    ]
    virtual_network_subnet_ids = [
      data.terraform_remote_state.vnets.outputs.subnet_funcapp_int.id,
      data.terraform_remote_state.vnets.outputs.subnet_robot.id,
    ]
  }

  access_policy = [local.msi_infra_key_vault_access]

  lifecycle { ignore_changes = [access_policy] }
}

resource "azurerm_key_vault_access_policy" "kafkaproxy-msi_infra" {
  key_vault_id            = azurerm_key_vault.kafkaproxy.id
  tenant_id               = local.msi_infra_key_vault_access.tenant_id
  object_id               = local.msi_infra_key_vault_access.object_id
  certificate_permissions = local.msi_infra_key_vault_access.certificate_permissions
  key_permissions         = local.msi_infra_key_vault_access.key_permissions
  secret_permissions      = local.msi_infra_key_vault_access.secret_permissions
  storage_permissions     = local.msi_infra_key_vault_access.storage_permissions
}

resource "azurerm_key_vault_access_policy" "kafkaproxy-group_admins_platform" {
  key_vault_id            = azurerm_key_vault.kafkaproxy.id
  tenant_id               = var.TENANT_ID
  object_id               = data.terraform_remote_state.ad.outputs.group_admins_platform.id
  certificate_permissions = ["Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"]
  key_permissions         = ["Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"]
  secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
  storage_permissions     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"]
}

resource "azurerm_key_vault_access_policy" "kafkaproxy-msi_kafkaproxy" {
  key_vault_id       = azurerm_key_vault.kafkaproxy.id
  tenant_id          = var.TENANT_ID
  object_id          = azurerm_linux_function_app.kafkaproxy.identity[0].principal_id
  secret_permissions = ["Get", ]
}
