locals {
  api_name         = "kdata-kafkaproxy-inbound-api"
  api_display_name = "KDATA Kafkaproxy Inbound API"
}

resource "azurerm_api_management_named_value" "kafkaproxy" {
  provider            = azurerm.apim
  name                = "${local.api_name}-secret"
  resource_group_name = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.resource_group
  api_management_name = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.name
  display_name        = "${local.api_name}-secret"
  secret              = true
  value_from_key_vault {
    secret_id = azurerm_key_vault_secret.apim-functionapp_kafkaproxy_api_management_key.id
  }
}

resource "azurerm_api_management_product" "kafkaproxy" {
  provider              = azurerm.apim
  product_id            = "${local.api_name}-product"
  resource_group_name   = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.resource_group
  api_management_name   = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.name
  display_name          = local.api_display_name
  subscription_required = true
  approval_required     = false
  published             = true
}

resource "azurerm_api_management_product_group" "kafkaproxy" {
  provider            = azurerm.apim
  product_id          = azurerm_api_management_product.kafkaproxy.product_id
  group_name          = azurerm_api_management_group.kafkaproxy.name
  resource_group_name = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.resource_group
  api_management_name = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.name
}

resource "azurerm_api_management_group" "kafkaproxy" {
  provider            = azurerm.apim
  name                = lower(replace(data.terraform_remote_state.ad.outputs.group_apim_kafkaproxy_inbound_api.display_name, "_", "-"))
  display_name        = data.terraform_remote_state.ad.outputs.group_apim_kafkaproxy_inbound_api.display_name
  type                = "external"
  external_id         = "aad://${var.TENANT_ID}/groups/${data.terraform_remote_state.ad.outputs.group_apim_kafkaproxy_inbound_api.id}"
  resource_group_name = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.resource_group
  api_management_name = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.name
}

resource "azurerm_api_management_subscription" "kafkaproxy" {
  provider            = azurerm.apim
  api_management_name = azurerm_api_management_product.kafkaproxy.api_management_name
  resource_group_name = azurerm_api_management_product.kafkaproxy.resource_group_name
  product_id          = azurerm_api_management_product.kafkaproxy.id
  display_name        = azurerm_api_management_product.kafkaproxy.product_id
  state               = "active"
}

# ------------------------------------------------------------------------------------------------

resource "azurerm_api_management_product" "kafkaproxy-kruoka_availability" {
  provider              = azurerm.apim
  product_id            = "${local.api_name}-kruoka-availability-product"
  resource_group_name   = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.resource_group
  api_management_name   = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.name
  display_name          = "${local.api_display_name} K-Ruoka Availability"
  subscription_required = true
  approval_required     = false
  published             = true
}

resource "azurerm_api_management_subscription" "kafkaproxy-kruoka_availability" {
  provider            = azurerm.apim
  api_management_name = azurerm_api_management_product.kafkaproxy-kruoka_availability.api_management_name
  resource_group_name = azurerm_api_management_product.kafkaproxy-kruoka_availability.resource_group_name
  product_id          = azurerm_api_management_product.kafkaproxy-kruoka_availability.id
  display_name        = "kruoka-availability-${azurerm_api_management_product.kafkaproxy-kruoka_availability.product_id}"
  state               = "active"
}

# ------------------------------------------------------------------------------------------------

resource "azurerm_api_management_product" "kafkaproxy-nordea" {
  provider              = azurerm.apim
  product_id            = "${local.api_name}-nordea-product"
  resource_group_name   = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.resource_group
  api_management_name   = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.name
  display_name          = "${local.api_display_name} Nordea"
  subscription_required = true
  approval_required     = false
  published             = true
}

resource "azurerm_api_management_subscription" "kafkaproxy-nordea" {
  provider            = azurerm.apim
  api_management_name = azurerm_api_management_product.kafkaproxy-nordea.api_management_name
  resource_group_name = azurerm_api_management_product.kafkaproxy-nordea.resource_group_name
  product_id          = azurerm_api_management_product.kafkaproxy-nordea.id
  display_name        = "nordea-${azurerm_api_management_product.kafkaproxy-nordea.product_id}"
  state               = "active"
}

# ------------------------------------------------------------------------------------------------

resource "azurerm_api_management_product" "kafkaproxy-market_pay" {
  provider              = azurerm.apim
  product_id            = "${local.api_name}-market-pay-product"
  resource_group_name   = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.resource_group
  api_management_name   = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.name
  display_name          = "${local.api_display_name} Market Pay"
  subscription_required = true
  approval_required     = false
  published             = true
}

resource "azurerm_api_management_subscription" "kafkaproxy-market_pay" {
  provider            = azurerm.apim
  api_management_name = azurerm_api_management_product.kafkaproxy-market_pay.api_management_name
  resource_group_name = azurerm_api_management_product.kafkaproxy-market_pay.resource_group_name
  product_id          = azurerm_api_management_product.kafkaproxy-market_pay.id
  display_name        = "market-pay-${azurerm_api_management_product.kafkaproxy-market_pay.product_id}"
  subscription_id     = "market-pay-${azurerm_api_management_product.kafkaproxy-market_pay.product_id}"
  state               = "active"
}
