module "kafkaproxyapi-gt_receipts" {
  source                             = "./modules/kafkaproxyapi"
  api_management_name                = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.name
  api_management_resource_group_name = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.resource_group
  api_management_logger_id           = data.terraform_remote_state.apimanagement.outputs.apim_logger_kgroup_kdata_apis.id
  api_name                           = "gt-receipts"
  api_display_name                   = "GT Receipts"
  api_path                           = "gt/receipts"
  confluent_topic_name               = "com.kesko.gt.receipts"
  function_key_named_value           = azurerm_api_management_named_value.kafkaproxy.name
  backend_url                        = azurerm_linux_function_app.kafkaproxy.default_hostname
  product_api_bindings = toset([
    azurerm_api_management_product.kafkaproxy.product_id,
    azurerm_api_management_product.kafkaproxy-kruoka_availability.product_id,
  ])

  providers = {
    azurerm = azurerm.apim
  }
}

module "kafkaproxyapi-com_nordea_life" {
  source                             = "./modules/kafkaproxyapi"
  api_management_name                = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.name
  api_management_resource_group_name = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.resource_group
  api_management_logger_id           = data.terraform_remote_state.apimanagement.outputs.apim_logger_kgroup_kdata_apis.id
  api_name                           = "com-nordea-life"
  api_display_name                   = "Common Nordea life"
  api_path                           = "com/nordea/life"
  confluent_topic_name               = "com.kesko.com.nordea.life"
  function_key_named_value           = azurerm_api_management_named_value.kafkaproxy.name
  backend_url                        = azurerm_linux_function_app.kafkaproxy.default_hostname
  product_api_bindings = toset([
    azurerm_api_management_product.kafkaproxy.product_id,
    azurerm_api_management_product.kafkaproxy-nordea.product_id,
  ])

  providers = {
    azurerm = azurerm.apim
  }
}

module "kafkaproxyapi-com_marketpay_loyaltytransaction" {
  source                             = "./modules/kafkaproxyapi"
  api_management_name                = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.name
  api_management_resource_group_name = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.resource_group
  api_management_logger_id           = data.terraform_remote_state.apimanagement.outputs.apim_logger_kgroup_kdata_apis.id
  api_name                           = "com-marketpay-loyaltytransaction"
  api_display_name                   = "Common Market Pay Loyalty Transaction"
  api_path                           = "com/marketpay/loyaltytransaction"
  confluent_topic_name               = "com.kesko.com.marketpay.loyaltytransaction"
  function_key_named_value           = azurerm_api_management_named_value.kafkaproxy.name
  backend_url                        = azurerm_linux_function_app.kafkaproxy.default_hostname
  product_api_bindings = toset([
    azurerm_api_management_product.kafkaproxy.product_id,
    azurerm_api_management_product.kafkaproxy-market_pay.product_id,
  ])

  providers = {
    azurerm = azurerm.apim
  }
}
