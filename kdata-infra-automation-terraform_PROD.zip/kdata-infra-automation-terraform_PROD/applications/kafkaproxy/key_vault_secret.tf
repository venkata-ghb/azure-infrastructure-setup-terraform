data "azurerm_key_vault_secret" "kafkaproxy-confluent_client_key" {
  name         = "confluent-client-key"
  key_vault_id = azurerm_key_vault.kafkaproxy.id
}

data "azurerm_key_vault_secret" "kafkaproxy-confluent_client_secret" {
  name         = "confluent-client-secret"
  key_vault_id = azurerm_key_vault.kafkaproxy.id
}

data "azurerm_key_vault_secret" "kafkaproxy-confluent_schema_registry_key" {
  name         = "confluent-schema-registry-key"
  key_vault_id = azurerm_key_vault.kafkaproxy.id
}

data "azurerm_key_vault_secret" "kafkaproxy-confluent_schema_registry_secret" {
  name         = "confluent-schema-registry-secret"
  key_vault_id = azurerm_key_vault.kafkaproxy.id
}

data "azurerm_key_vault_secret" "kafkaproxy-functionapp_kafkaproxy_api_management_key" {
  name         = "functionapp-kafkaproxy-api-management-key"
  key_vault_id = azurerm_key_vault.kafkaproxy.id
  depends_on   = [azurerm_linux_function_app.kafkaproxy]
}

resource "azurerm_key_vault_secret" "kafkaproxy-api_management_subscription" {
  name         = "api-management-subscription"
  value        = azurerm_api_management_subscription.kafkaproxy.primary_key
  key_vault_id = azurerm_key_vault.kafkaproxy.id
  tags         = local.resource_tags
}

# apim

resource "azurerm_key_vault_secret" "apim-functionapp_kafkaproxy_api_management_key" {
  name         = "functionapp-kafkaproxy-api-management-key"
  value        = data.azurerm_key_vault_secret.kafkaproxy-functionapp_kafkaproxy_api_management_key.value
  key_vault_id = data.terraform_remote_state.apimanagement.outputs.kv_apim.id
  tags         = local.resource_tags
}
