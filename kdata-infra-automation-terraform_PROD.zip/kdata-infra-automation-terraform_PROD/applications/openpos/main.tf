terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "=3.50.0"
    }
  }
  backend "azurerm" {}
  required_version = "= 1.12.0"
}

provider "azurerm" {
  tenant_id                  = var.TENANT_ID
  subscription_id            = var.SUBSCRIPTION_ID
  storage_use_azuread        = true
  skip_provider_registration = true
  features {}
}

provider "azurerm" {
  alias                      = "apim"
  subscription_id            = "b9c0350a-df03-431b-b55a-468a37bb43f6"
  tenant_id                  = var.TENANT_ID
  storage_use_azuread        = true
  skip_provider_registration = true
  features {}
}

data "terraform_remote_state" "integrations" {
  backend = "azurerm"
  config = {
    subscription_id      = var.SUBSCRIPTION_ID
    resource_group_name  = var.TF_RG_NAME
    storage_account_name = var.TF_SA_NAME
    container_name       = var.TF_CONTAINER_NAME
    key                  = "integrations/common.terraform_PROD.tfstate"
  }
}

data "terraform_remote_state" "apimanagement" {
  backend = "azurerm"
  config = {
    subscription_id      = var.SUBSCRIPTION_ID
    resource_group_name  = var.TF_RG_NAME
    storage_account_name = var.TF_SA_NAME
    container_name       = var.TF_CONTAINER_NAME
    key                  = "integrations/apimanagement.terraform_PROD.tfstate"
  }
}

# List of variables passed in via pipelines

variable "SUBSCRIPTION_ID" {
  type = string
}

variable "TENANT_ID" {
  type = string
}

variable "TF_RG_NAME" {
  type = string
}

variable "TF_SA_NAME" {
  type = string
}

variable "TF_CONTAINER_NAME" {
  type = string
}
