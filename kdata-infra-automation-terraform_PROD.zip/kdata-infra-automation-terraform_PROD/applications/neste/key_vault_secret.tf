data "azurerm_key_vault_secret" "neste-storageapi_func_key" {
  name         = "apim-storageapi-func-key"
  key_vault_id = data.terraform_remote_state.apim.outputs.kv_apim.id
}

resource "azurerm_key_vault_secret" "neste-sp_neste_databricks_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_neste_databricks.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_neste_databricks_password
  key_vault_id = azurerm_key_vault.neste.id
  content_type = "${data.terraform_remote_state.ad.outputs.sp_neste_databricks.display_name} SP's Password by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "neste-sp_neste_eventhub_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_neste_eventhub.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_neste_eventhub_password
  key_vault_id = azurerm_key_vault.neste.id
  content_type = "${data.terraform_remote_state.ad.outputs.sp_neste_eventhub.display_name} SP's Password by Terraform"
  tags         = local.resource_tags
}
