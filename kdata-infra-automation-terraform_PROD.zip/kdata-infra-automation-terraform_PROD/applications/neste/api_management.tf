# Centralised API management
data "azurerm_api_management" "apimanagement" {
  provider            = azurerm.apim
  name                = "K-apim-${var.env}"
  resource_group_name = "KESKO_WE_RG_APIM_${upper(var.env)}001"
}

resource "azurerm_api_management_api" "neste" {
  provider            = azurerm.apim
  name                = "kdata-neste-input-api"
  resource_group_name = data.azurerm_api_management.apimanagement.resource_group_name
  api_management_name = data.azurerm_api_management.apimanagement.name
  revision            = "1"
  display_name        = "K-Data Neste Input API"
  path                = "kdata/neste-input-api"
  protocols           = ["https"]

  import {
    content_format = "openapi+json"
    content_value  = file("${path.module}/resources/openapi.neste.json")
  }
}

resource "azurerm_api_management_named_value" "neste-storageapi_secret" {
  provider            = azurerm.apim
  name                = "${azurerm_api_management_api.neste.name}-secret"
  resource_group_name = azurerm_api_management_api.neste.resource_group_name
  api_management_name = azurerm_api_management_api.neste.api_management_name
  display_name        = "${azurerm_api_management_api.neste.name}-secret"
  value               = data.azurerm_key_vault_secret.neste-storageapi_func_key.value
  secret              = true
}

resource "azurerm_api_management_named_value" "neste-eh_secret" {
  provider            = azurerm.apim
  name                = "${azurerm_api_management_api.neste.name}-eh-secret"
  resource_group_name = azurerm_api_management_api.neste.resource_group_name
  api_management_name = azurerm_api_management_api.neste.api_management_name
  display_name        = "${azurerm_api_management_api.neste.name}-eh-secret"
  value               = data.terraform_remote_state.ad.outputs.sp_neste_eventhub_password
  secret              = true
}


resource "azurerm_api_management_api_policy" "neste" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.neste.name
  api_management_name = azurerm_api_management_api.neste.api_management_name
  resource_group_name = azurerm_api_management_api.neste.resource_group_name

  xml_content = <<XML
<policies>
    <inbound>
        <base />
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>
  XML
}

resource "azurerm_api_management_api_operation_policy" "neste-storedata" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.neste.name
  api_management_name = azurerm_api_management_api.neste.api_management_name
  resource_group_name = azurerm_api_management_api.neste.resource_group_name
  operation_id        = "post-store-data"

  xml_content = <<XML
<policies>
    <inbound>
        <base />
        <authentication-managed-identity resource="${data.terraform_remote_state.ad.outputs.sp_apim_authentication.application_id}" />
        <set-header name="x-functions-key" exists-action="override">
            <value>{{${azurerm_api_management_named_value.neste-storageapi_secret.name}}}</value>
        </set-header>
        <set-backend-service base-url="https://${data.terraform_remote_state.storageapi.outputs.funcapp_storageapi.default_hostname}/api/neste/StoreData" />
        <rewrite-uri template="/" />
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>
XML
}

resource "azurerm_api_management_api_operation_policy" "neste-products" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.neste.name
  api_management_name = azurerm_api_management_api.neste.api_management_name
  resource_group_name = azurerm_api_management_api.neste.resource_group_name
  operation_id        = "post-products"

  xml_content = <<XML
<policies>
    <inbound>
        <base />
        <authentication-managed-identity resource="${data.terraform_remote_state.ad.outputs.sp_apim_authentication.application_id}" />
        <set-header name="x-functions-key" exists-action="override">
            <value>{{${azurerm_api_management_named_value.neste-storageapi_secret.name}}}</value>
        </set-header>
        <set-backend-service base-url="https://${data.terraform_remote_state.storageapi.outputs.funcapp_storageapi.default_hostname}/api/neste/Products" />
        <rewrite-uri template="/" />
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>
XML
}

resource "azurerm_api_management_api_operation_policy" "neste-sales" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.neste.name
  api_management_name = azurerm_api_management_api.neste.api_management_name
  resource_group_name = azurerm_api_management_api.neste.resource_group_name
  operation_id        = "post-sales"

  xml_content = <<XML
            <policies>
                <inbound>
                        <base />
                        <!--Look for userprofile for this user in the cache -->
                        <cache-lookup-value key="nestesales-eh-access-token" variable-name="bearer-access-token" />
                        <!-- If API Management doesn’t find it in the cache, make a request for it and store it -->
                        <choose>
                                <when condition="@(!context.Variables.ContainsKey("bearer-access-token"))">
                                        <!-- Make HTTP request to get user profile -->
                                        <send-request ignore-error="true" timeout="20" response-variable-name="bearerToken" mode="new">
                                                <set-url>https://login.microsoftonline.com/ae6e7baa-e1bf-4ef0-92a1-4eb28ec805c0/oauth2/token</set-url>
                                                <set-method>POST</set-method>
                                                <set-header name="Content-Type" exists-action="override">
                                                        <value>application/x-www-form-urlencoded</value>
                                                </set-header>
                                                <set-body>@{
                                    return "client_id=${data.terraform_remote_state.ad.outputs.sp_neste_eventhub.application_id}&resource=https://eventhubs.azure.net&client_secret={{${azurerm_api_management_named_value.neste-eh_secret.name}}}&grant_type=client_credentials";
                                }</set-body>
                                        </send-request>
                                        <!-- Store response body in context variable -->
                                        <set-variable name="bearer-access-token" value="@((String)((IResponse)context.Variables["bearerToken"]).Body.As<JObject>()["access_token"])" />
                                        <!-- Store result in cache -->
                                        <!-- Duration of cache should be less than lifetime of access token. -->
                                        <!-- Otherwise we will get authorization error as non-active access token will be used -->
                                        <cache-store-value key="nestesales-eh-access-token" value="@((string)context.Variables["bearer-access-token"])" duration="3300" />
                                </when>
                        </choose>
                        <set-header name="Authorization" exists-action="override">
                                <value>@("Bearer " + (String)context.Variables["bearer-access-token"])</value>
                        </set-header>
                        <set-backend-service base-url="https://${data.terraform_remote_state.integrations.outputs.ehns_neste.name}.servicebus.windows.net/sales-natural/messages" />
                        <rewrite-uri template="/" />
                </inbound>
                <backend>
                        <base />
                </backend>
                <outbound>
                        <set-header name="Content-Type" exists-action="override">
                                <value>application/json</value>
                        </set-header>
                        <set-body template="liquid">
                    {
                      "statusCode": {{context.Response.StatusCode}},
                      "message": {% case context.Response.StatusCode %}
                        {% when 201 %}"ok"
                        {% else %}
                          {% if body %}"{{body}}"
                          {% else %}"Configuration error(Eventhub User Error) occured"
                          {% endif %}
                      {% endcase %}}
                    </set-body>
                        <base />
                </outbound>
                <on-error>
                        <set-header name="Content-Type" exists-action="override">
                                <value>application/json</value>
                        </set-header>
                        <set-body template="liquid">
                    {
                      "statusCode": {{context.Response.StatusCode}},
                      "message": {% case context.Response.StatusCode %}
                        {% when 400 %}"Invalid JSON document"
                        {% else %}
                          {% if body.message %}"{{body.message}}"
                          {% elsif body %}"{{body}}"
                          {% else %}"Internal Error"
                          {% endif %}
                      {% endcase %}}
                    </set-body>
                        <base />
                </on-error>
            </policies>

  XML
}

resource "azurerm_api_management_product" "neste" {
  provider              = azurerm.apim
  product_id            = "${azurerm_api_management_api.neste.name}-product"
  api_management_name   = azurerm_api_management_api.neste.api_management_name
  resource_group_name   = azurerm_api_management_api.neste.resource_group_name
  display_name          = azurerm_api_management_api.neste.display_name
  subscriptions_limit   = 0
  subscription_required = true
  approval_required     = false
  published             = true
}

resource "azurerm_api_management_product_api" "neste" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.neste.name
  product_id          = azurerm_api_management_product.neste.product_id
  api_management_name = azurerm_api_management_api.neste.api_management_name
  resource_group_name = azurerm_api_management_api.neste.resource_group_name
}

resource "azurerm_api_management_product_group" "neste" {
  provider            = azurerm.apim
  product_id          = azurerm_api_management_product.neste.product_id
  api_management_name = azurerm_api_management_api.neste.api_management_name
  resource_group_name = azurerm_api_management_api.neste.resource_group_name
  group_name          = "az-apim-${var.env}-kdata-neste-input-api"
}

resource "azurerm_api_management_api_tag" "neste" {
  provider = azurerm.apim
  api_id   = azurerm_api_management_api.neste.id
  name     = "k-data"
}

# ==========================================================

resource "azurerm_api_management_api" "neste_analytics" {
  provider            = azurerm.apim
  name                = "kdata-neste-analytics-input-api"
  resource_group_name = data.azurerm_api_management.apimanagement.resource_group_name
  api_management_name = data.azurerm_api_management.apimanagement.name
  revision            = "1"
  display_name        = "K-Data Neste Analytics Input API"
  path                = "kdata/neste-input-api/analytics"
  protocols           = ["https"]

  import {
    content_format = "openapi+json"
    content_value  = file("${path.module}/resources/openapi.neste-analytics.json")
  }
}

resource "azurerm_api_management_api_operation_policy" "neste_analytics-stationareamappings" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.neste_analytics.name
  api_management_name = azurerm_api_management_api.neste_analytics.api_management_name
  resource_group_name = azurerm_api_management_api.neste_analytics.resource_group_name
  operation_id        = "post-stationareamappings"

  xml_content = templatefile(
    "${path.module}/resources/adls-policy.xml", {
      storage  = "kdata${var.env}adls"
      dataset  = "StationAreaMappings"
      filetype = "csv"
  })
}

resource "azurerm_api_management_api_operation_policy" "neste_analytics-projectkpis" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.neste_analytics.name
  api_management_name = azurerm_api_management_api.neste_analytics.api_management_name
  resource_group_name = azurerm_api_management_api.neste_analytics.resource_group_name
  operation_id        = "post-projectkpis"

  xml_content = templatefile(
    "${path.module}/resources/adls-policy.xml", {
      storage  = "kdata${var.env}adls"
      dataset  = "ProjectKPIs"
      filetype = "csv"
  })
}

resource "azurerm_api_management_api_operation_policy" "neste_analytics-netpromoterscore" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.neste_analytics.name
  api_management_name = azurerm_api_management_api.neste_analytics.api_management_name
  resource_group_name = azurerm_api_management_api.neste_analytics.resource_group_name
  operation_id        = "post-netpromoterscore"

  xml_content = templatefile(
    "${path.module}/resources/adls-policy.xml", {
      storage  = "kdata${var.env}adls"
      dataset  = "NetPromoterScore"
      filetype = "csv"
  })
}

resource "azurerm_api_management_api_operation_policy" "neste_analytics-loyaltysales" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.neste_analytics.name
  api_management_name = azurerm_api_management_api.neste_analytics.api_management_name
  resource_group_name = azurerm_api_management_api.neste_analytics.resource_group_name
  operation_id        = "post-loyaltysales"

  xml_content = templatefile(
    "${path.module}/resources/adls-policy.xml", {
      storage  = "kdata${var.env}adls"
      dataset  = "LoyaltySales"
      filetype = "csv"
  })
}

resource "azurerm_api_management_product" "neste_analytics" {
  provider              = azurerm.apim
  product_id            = "${azurerm_api_management_api.neste_analytics.name}-product"
  api_management_name   = azurerm_api_management_api.neste_analytics.api_management_name
  resource_group_name   = azurerm_api_management_api.neste_analytics.resource_group_name
  display_name          = azurerm_api_management_api.neste_analytics.display_name
  subscriptions_limit   = 0
  subscription_required = true
  approval_required     = false
  published             = true
}

resource "azurerm_api_management_product_api" "neste_analytics" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.neste_analytics.name
  product_id          = azurerm_api_management_product.neste_analytics.product_id
  api_management_name = azurerm_api_management_api.neste_analytics.api_management_name
  resource_group_name = azurerm_api_management_api.neste_analytics.resource_group_name
}

resource "azurerm_api_management_product_group" "neste_analytics" {
  provider            = azurerm.apim
  product_id          = azurerm_api_management_product.neste_analytics.product_id
  api_management_name = azurerm_api_management_api.neste_analytics.api_management_name
  resource_group_name = azurerm_api_management_api.neste_analytics.resource_group_name
  group_name          = "az-apim-${var.env}-kdata-neste-input-api"
}

resource "azurerm_api_management_api_tag" "neste_analytics" {
  provider = azurerm.apim
  api_id   = azurerm_api_management_api.neste_analytics.id
  name     = "k-data"
}
