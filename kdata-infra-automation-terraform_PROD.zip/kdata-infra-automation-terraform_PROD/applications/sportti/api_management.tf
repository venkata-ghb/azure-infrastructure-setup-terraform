resource "azurerm_api_management_api" "sportti_inbound" {
  provider            = azurerm.apim
  name                = "kdata-sportti-inbound-api"
  resource_group_name = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.resource_group
  api_management_name = data.terraform_remote_state.apimanagement.outputs.apim_kgroup.name
  revision            = "1"
  display_name        = "K-data Sportti Inbound API"
  path                = "kdata/sportti-inbound-api"
  protocols           = ["https"]

  import {
    content_format = "openapi+json"
    content_value  = file("${path.module}/resources/openapi.sportti.json")
  }
}

resource "azurerm_api_management_api_policy" "sportti_inbound" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.sportti_inbound.name
  api_management_name = azurerm_api_management_api.sportti_inbound.api_management_name
  resource_group_name = azurerm_api_management_api.sportti_inbound.resource_group_name

  xml_content = <<XML
<policies>
    <inbound>
        <authentication-managed-identity resource="https://${data.terraform_remote_state.integrations.outputs.ehns_sportti.name}.servicebus.windows.net"/>
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <set-header name="Content-Type" exists-action="override">
          <value>application/json</value>
        </set-header>
        <choose>
          <when condition="@(context.Response.StatusCode == 201)">
            <set-status code="200" reason="ok"/>
          </when>
          <when condition="@(context.Response.StatusCode >= 401)">
            <set-status code="500" reason="Internal Server Error" />
          </when>
        </choose>
        <set-body template="liquid">
        {
          "statusCode": {{context.Response.StatusCode}},
          "message": {% case context.Response.StatusCode %}
            {% when 200 %}"ok"
            {% else %}
              {% if body.message %}"{{body.message}}"
              {% else %}"Internal Error"
              {% endif %}
          {% endcase %}}
        </set-body>
        <base />
    </outbound>
    <on-error>
        <set-header name="Content-Type" exists-action="override">
          <value>application/json</value>
        </set-header>
        <set-body template="liquid">
        {
          "statusCode": {{context.Response.StatusCode}},
          "message":
            {% if body.message %}"{{body.message}}"
            {% else %}"Internal Error"
            {% endif %}}
        </set-body>
        <base />
    </on-error>
</policies>
  XML
}

resource "azurerm_api_management_api_operation_policy" "sportti_inbound" {
  for_each = {
    sales = "sales-natural"
  }

  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.sportti_inbound.name
  api_management_name = azurerm_api_management_api.sportti_inbound.api_management_name
  resource_group_name = azurerm_api_management_api.sportti_inbound.resource_group_name
  operation_id        = "post-${each.key}"

  xml_content = templatefile(
    "${path.module}/resources/eh-policy.xml", {
      eventhub_namespace = data.terraform_remote_state.integrations.outputs.ehns_sportti.name
      eventhub_topic     = each.value
  })
}

resource "azurerm_api_management_product" "sportti_inbound-sportti" {
  provider              = azurerm.apim
  display_name          = azurerm_api_management_api.sportti_inbound.display_name
  product_id            = "${azurerm_api_management_api.sportti_inbound.name}-sportti-product"
  api_management_name   = azurerm_api_management_api.sportti_inbound.api_management_name
  resource_group_name   = azurerm_api_management_api.sportti_inbound.resource_group_name
  subscriptions_limit   = 1
  subscription_required = true
  approval_required     = false
  published             = true
}

resource "azurerm_api_management_product_api" "sportti_inbound-sportti" {
  provider            = azurerm.apim
  product_id          = azurerm_api_management_product.sportti_inbound-sportti.product_id
  api_name            = azurerm_api_management_api.sportti_inbound.name
  api_management_name = azurerm_api_management_api.sportti_inbound.api_management_name
  resource_group_name = azurerm_api_management_api.sportti_inbound.resource_group_name
}

resource "azurerm_api_management_subscription" "sportti_inbound-sportti" {
  provider            = azurerm.apim
  api_management_name = azurerm_api_management_product.sportti_inbound-sportti.api_management_name
  resource_group_name = azurerm_api_management_product.sportti_inbound-sportti.resource_group_name
  product_id          = azurerm_api_management_product.sportti_inbound-sportti.id
  display_name        = "sportti-${azurerm_api_management_product.sportti_inbound-sportti.product_id}"
  state               = "active"
  allow_tracing       = false
}

resource "azurerm_api_management_api_diagnostic" "sportti_inbound" {
  provider                 = azurerm.apim
  identifier               = "applicationinsights"
  resource_group_name      = azurerm_api_management_api.sportti_inbound.resource_group_name
  api_management_name      = azurerm_api_management_api.sportti_inbound.api_management_name
  api_name                 = azurerm_api_management_api.sportti_inbound.name
  api_management_logger_id = data.terraform_remote_state.apimanagement.outputs.apim_logger_kgroup_kdata_apis.id
  always_log_errors        = true
}
