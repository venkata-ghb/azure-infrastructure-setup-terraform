variable "location" {
  type        = string
  description = "Location"
  default     = "westeurope"
}

variable "loc" {
  type        = string
  description = "Location short"
  default     = "we"
}

variable "prefix_rg" {
  type        = string
  description = "Prefix to be applied to all resource names in resource group"
  default     = "K-DATA_PROD_WE"
}

variable "resource_tags" {
  type        = map(string)
  description = "Tags to be applied for all resources"
  default = {
    application       = "kespro data"
    applicationvendor = "futurice"
    created_by        = "Terraform"
    Environment       = "Production"
    "IT-owner"        = "aleksi.jarvinen@kesko.fi"
    MgmtVendor        = "fiuturice"
    "Project Manager" = "katja.linnakyla@kesko.fi"
    "Service manager" = "Aleksi.Järvinen@kesko.fi"
    "sub-service"     = "c1286"
  }
}
