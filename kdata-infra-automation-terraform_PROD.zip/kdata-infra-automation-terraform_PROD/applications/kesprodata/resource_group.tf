resource "azurerm_resource_group" "kesprodata" {
  name     = "${var.prefix_rg}_KESPRODATA_RG"
  location = var.location
  tags     = var.resource_tags
}
