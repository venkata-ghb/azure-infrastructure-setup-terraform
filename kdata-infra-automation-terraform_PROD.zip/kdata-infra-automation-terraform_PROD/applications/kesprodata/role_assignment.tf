resource "azurerm_role_assignment" "rg_kesprodata-contributor-group_admins_platform" {
  principal_id         = data.terraform_remote_state.ad.outputs.group_admins_platform.id
  role_definition_name = "Contributor"
  scope                = azurerm_resource_group.kesprodata.id
}

resource "azurerm_role_assignment" "rg_kesprodata-contributor-group_devops_gtkesprodata" {
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_gtkesprodata.id
  role_definition_name = "Contributor"
  scope                = azurerm_resource_group.kesprodata.id
}

resource "azurerm_role_assignment" "rg_kesprodata-reader-group_devops_platform" {
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
  role_definition_name = "Reader"
  scope                = azurerm_resource_group.kesprodata.id
}
