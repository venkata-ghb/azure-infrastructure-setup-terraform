terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "=2.77.0"
    }
  }
  backend "azurerm" {}
  required_version = "= 1.12.0"
}

provider "azurerm" {
  storage_use_azuread        = true
  skip_provider_registration = true
  subscription_id            = var.SUBSCRIPTION_ID
  tenant_id                  = var.TENANT_ID
  features {}
}

data "terraform_remote_state" "ad" {
  backend = "azurerm"
  config = {
    subscription_id      = var.SUBSCRIPTION_ID
    resource_group_name  = var.TF_RG_NAME
    storage_account_name = var.TF_SA_NAME
    container_name       = var.TF_CONTAINER_NAME
    key                  = "core/ad.terraform_PROD.tfstate"
  }
}

# List of variables passed in via pipelines

variable "SUBSCRIPTION_ID" {
  type = string
}

variable "TENANT_ID" {
  type = string
}

variable "MSI_ID" {
  type = string
}

variable "TF_SUBNET_ID" {
  type = string
}

variable "TF_RG_NAME" {
  type = string
}

variable "TF_SA_NAME" {
  type = string
}

variable "TF_CONTAINER_NAME" {
  type = string
}

