resource "azurerm_resource_group" "attrbmodeling" {
  name     = "${local.prefix_rg}_ATTRBMODELING_Main_RG"
  location = local.location.long
  tags     = local.resource_tags
}
