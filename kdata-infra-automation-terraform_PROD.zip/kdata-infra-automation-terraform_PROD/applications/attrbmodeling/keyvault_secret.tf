resource "azurerm_key_vault_secret" "attrmdlng-sp_attrbmodeling_adfrm_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_attrbmodeling_adfrm.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_attrbmodeling_adfrm_password
  key_vault_id = azurerm_key_vault.attrmdlng.id
  content_type = "${data.terraform_remote_state.ad.outputs.sp_attrbmodeling_adfrm.display_name} SP's Password by Terraform"
  tags         = local.resource_tags
}

resource "azurerm_key_vault_secret" "attrmdlng-sp_attrbmodeling_slfrc_secret" {
  name         = data.terraform_remote_state.ad.outputs.sp_attrbmodeling_slfrc.display_name
  value        = data.terraform_remote_state.ad.outputs.sp_attrbmodeling_slfrc_password
  key_vault_id = azurerm_key_vault.attrmdlng.id
  content_type = "${data.terraform_remote_state.ad.outputs.sp_attrbmodeling_slfrc.display_name} SP's Password by Terraform"
  tags         = local.resource_tags
}
