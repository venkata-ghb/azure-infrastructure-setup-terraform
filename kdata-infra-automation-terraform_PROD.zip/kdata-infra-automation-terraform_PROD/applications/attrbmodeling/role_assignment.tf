resource "azurerm_role_assignment" "rg_attrbmodeling-contributor-group_admins_platform" {
  scope                = azurerm_resource_group.attrbmodeling.id
  role_definition_name = "Contributor"
  principal_id         = data.terraform_remote_state.ad.outputs.group_admins_platform.id
}

resource "azurerm_role_assignment" "rg_attrbmodeling-reader-group_devops_platform" {
  scope                = azurerm_resource_group.attrbmodeling.id
  role_definition_name = "Reader"
  principal_id         = data.terraform_remote_state.ad.outputs.group_devops_platform.id
}
