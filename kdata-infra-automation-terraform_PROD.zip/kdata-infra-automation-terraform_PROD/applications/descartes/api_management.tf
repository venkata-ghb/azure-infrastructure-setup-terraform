# API management stuff
data "azurerm_api_management" "apimanagement" {
  provider            = azurerm.apim
  name                = "K-apim-prod"
  resource_group_name = "KESKO_WE_RG_APIM_PROD001"
}

resource "azurerm_api_management_api" "descartes" {
  provider            = azurerm.apim
  name                = "kdata-descartes-input-api"
  resource_group_name = data.azurerm_api_management.apimanagement.resource_group_name
  api_management_name = data.azurerm_api_management.apimanagement.name
  revision            = "1"
  display_name        = "K-Data Descartes Input API"
  path                = "kdata/descartes-input-api"
  protocols           = ["https"]

  import {
    content_format = "openapi+json"
    content_value  = file("${path.module}/resources/openapi.json")
  }
}

resource "azurerm_api_management_api_policy" "descartes" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.descartes.name
  api_management_name = azurerm_api_management_api.descartes.api_management_name
  resource_group_name = azurerm_api_management_api.descartes.resource_group_name

  xml_content = <<XML
<policies>
    <inbound>
        <base />
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>
  XML
}

resource "azurerm_api_management_api_operation_policy" "descartes-orderdeliverynotification" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.descartes.name
  api_management_name = azurerm_api_management_api.descartes.api_management_name
  resource_group_name = azurerm_api_management_api.descartes.resource_group_name
  operation_id        = "post-orderdeliverynotification"

  xml_content = templatefile(
    "${path.module}/resources/adls-policy.xml", {
      storage  = data.terraform_remote_state.integrations.outputs.sa_adls.name
      dataset  = "OrderDeliveryNotification"
      filetype = "xml"
  })
}

resource "azurerm_api_management_product" "descartes" {
  provider              = azurerm.apim
  product_id            = "${azurerm_api_management_api.descartes.name}-product"
  api_management_name   = azurerm_api_management_api.descartes.api_management_name
  resource_group_name   = azurerm_api_management_api.descartes.resource_group_name
  display_name          = azurerm_api_management_api.descartes.display_name
  subscriptions_limit   = 0
  subscription_required = true
  approval_required     = false
  published             = true
}

resource "azurerm_api_management_product_api" "descartes" {
  provider            = azurerm.apim
  api_name            = azurerm_api_management_api.descartes.name
  product_id          = azurerm_api_management_product.descartes.product_id
  api_management_name = azurerm_api_management_api.descartes.api_management_name
  resource_group_name = azurerm_api_management_api.descartes.resource_group_name
}

resource "azurerm_api_management_product_group" "descartes" {
  provider            = azurerm.apim
  product_id          = azurerm_api_management_product.descartes.product_id
  api_management_name = azurerm_api_management_api.descartes.api_management_name
  resource_group_name = azurerm_api_management_api.descartes.resource_group_name
  group_name          = "626126b768c83f64c16de5b1"
}

resource "azurerm_api_management_api_tag" "descartes" {
  provider = azurerm.apim
  api_id   = azurerm_api_management_api.descartes.id
  name     = "k-data"
}
