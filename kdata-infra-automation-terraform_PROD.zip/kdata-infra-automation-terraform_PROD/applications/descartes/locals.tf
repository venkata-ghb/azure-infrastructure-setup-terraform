locals {
  resource_tags = data.terraform_remote_state.common.outputs.resource_tags
}