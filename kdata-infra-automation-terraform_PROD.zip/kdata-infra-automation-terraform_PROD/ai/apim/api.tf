resource "azurerm_api_management_api" "openai_api" {
    api_management_name   = "apim-kgroup-prod"
    api_type              = "http"
    description           = "Azure OpenAI APIs for completions and search"
    display_name          = "KDATA Azure OpenAI Service API"
    name                  = "kdata-azure-openai-service-api"
    path                  = "kdata-azure-openai-service-api/openai"
    protocols             = [
        "https",
    ]
    resource_group_name   = "rg-apim-prod-weu-001"
    revision              = "1"
    revision_description  = null
    service_url           = null
    subscription_required = true
    terms_of_service_url  = null
    version               = null
    version_description   = null
    version_set_id        = null

    subscription_key_parameter_names {
        header = "Ocp-Apim-Subscription-Key"
        query  = "subscription-key"
    }
}

resource "azurerm_api_management_api_policy" "openai_api_policy" {
    api_management_name = "apim-kgroup-prod"
    api_name            = "kdata-azure-openai-service-api"
    resource_group_name = "rg-apim-prod-weu-001"
    xml_content         = file("${path.module}/api.policy.xml")
}

resource "azurerm_api_management_api_diagnostic" "openai_api_diagnostic" {
    always_log_errors         = true
    api_management_logger_id  = "/subscriptions/b9c0350a-df03-431b-b55a-468a37bb43f6/resourceGroups/rg-apim-prod-weu-001/providers/Microsoft.ApiManagement/service/apim-kgroup-prod/loggers/kdata-apis"
    api_management_name       = "apim-kgroup-prod"
    api_name                  = "kdata-azure-openai-service-api"
    http_correlation_protocol = "Legacy"
    identifier                = "applicationinsights"
    log_client_ip             = true
    operation_name_format     = "Name"
    resource_group_name       = "rg-apim-prod-weu-001"
    sampling_percentage       = 100
    verbosity                 = "information"

    backend_request {
        body_bytes     = 8192
        headers_to_log = [
            "Content-Type",
            "User-Agent",
        ]
    }

    backend_response {
        body_bytes     = 8192
        headers_to_log = [
            "Content-Type",
            "User-Agent",
        ]
    }

    frontend_request {
        body_bytes     = 8192
        headers_to_log = [
            "Content-Type",
            "User-Agent",
        ]
    }

    frontend_response {
        body_bytes     = 8192
        headers_to_log = [
            "Content-Type",
            "User-Agent",
        ]
    }
}
