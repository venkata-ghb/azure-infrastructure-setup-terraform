resource "azurerm_api_management_subscription" "openai_subscription" {
    allow_tracing       = false
    api_id              = null
    api_management_name = "apim-kgroup-prod"
    display_name        = "intelligent-application-kdata-azure-openai-service-api"
    product_id          = "/subscriptions/b9c0350a-df03-431b-b55a-468a37bb43f6/resourceGroups/rg-apim-prod-weu-001/providers/Microsoft.ApiManagement/service/apim-kgroup-prod/products/kdata-azure-openai-service-api"
    resource_group_name = "rg-apim-prod-weu-001"
    state               = "active"
    subscription_id     = "intelligent-application-kdata-azure-openai-service-api"
    user_id             = null

    depends_on = [
    azurerm_api_management_product.openai_product
  ]
}
