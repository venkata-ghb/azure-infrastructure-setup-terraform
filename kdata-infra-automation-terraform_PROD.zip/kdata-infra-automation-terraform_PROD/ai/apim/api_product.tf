resource "azurerm_api_management_product" "openai_product" {
    api_management_name   = "apim-kgroup-prod"
    approval_required     = true
    description           = "KDATA Azure OpenAI Service API product"
    display_name          = "KDATA Azure OpenAI Service API"
    product_id            = "kdata-azure-openai-service-api"
    published             = true
    resource_group_name   = "rg-apim-prod-weu-001"
    subscription_required = true
    subscriptions_limit   = 0
}

resource "azurerm_api_management_product_policy" "openai_product_policy" {
    api_management_name = "apim-kgroup-prod"
    product_id          = "kdata-azure-openai-service-api"
    resource_group_name = "rg-apim-prod-weu-001"
    xml_content         = file("${path.module}/product.policy.xml")
}

resource "azurerm_api_management_product_api" "openai_product_api" {
    api_management_name = "apim-kgroup-prod"
    api_name            = "kdata-azure-openai-service-api"
    product_id          = "kdata-azure-openai-service-api"
    resource_group_name = "rg-apim-prod-weu-001"
}
