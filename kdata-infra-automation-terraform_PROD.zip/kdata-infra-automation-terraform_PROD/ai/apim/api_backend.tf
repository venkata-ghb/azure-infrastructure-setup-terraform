# API Backend 
resource "azurerm_api_management_backend" "openai_backend_1" {
    api_management_name = "apim-kgroup-prod"
    description         = null
    name                = "kdata-azure-openai-service-api-1"
    protocol            = "http"
    resource_group_name = "rg-apim-prod-weu-001"
    resource_id         = null
    title               = null
    url                 = "https://kdata-prod-sc-openai2.openai.azure.com/"
}

resource "azurerm_api_management_backend" "openai_backend_2" {
    api_management_name = "apim-kgroup-prod"
    description         = null
    name                = "kdata-azure-openai-service-api-2"
    protocol            = "http"
    resource_group_name = "rg-apim-prod-weu-001"
    resource_id         = null
    title               = null
    url                 = "https://kdata-prod-fc-openai2.openai.azure.com/"
}

resource "azurerm_api_management_backend" "openai_backend_3" {
    api_management_name = "apim-kgroup-prod"
    description         = null
    name                = "kdata-azure-openai-service-api-3"
    protocol            = "http"
    resource_group_name = "rg-apim-prod-weu-001"
    resource_id         = null
    title               = null
    url                 = "https://kdata-prod-szn-openai.openai.azure.com/"
}


resource "azurerm_api_management_backend" "openai_backend_4" {
    api_management_name = "apim-kgroup-prod"
    description         = null
    name                = "kdata-azure-openai-service-api-4"
    protocol            = "http"
    resource_group_name = "rg-apim-prod-weu-001"
    resource_id         = null
    title               = null
    url                 = "https://kdata-prod-sc-openai2.openai.azure.com/"
}
