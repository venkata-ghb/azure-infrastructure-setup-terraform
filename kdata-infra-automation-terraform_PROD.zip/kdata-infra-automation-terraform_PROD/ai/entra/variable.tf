variable "prefix_sp" {
  type        = string
  description = "Prefix for Service Principals"
  default     = "kais-prod"
}