data "azuread_user" "kesko_nico_miettinen" {
  user_principal_name = "nico.miettinen@kesko.fi"
}

data "azuread_user" "kesko_nakul_bansal" {
  user_principal_name = "nakul.bansal@kesko.fi"
}

data "azuread_user" "kesko_mika_mauno" {
  user_principal_name = "mika.mauno@kesko.fi"
}

data "azuread_user" "kesko_eetu_huttunen" {
  user_principal_name = "eetu.huttunen@kesko.fi"
}

data "azuread_user" "kesko_mikke_bergstrom" {
  user_principal_name = "mikke.bergstrom@kesko.fi"
}

#
data "azuread_user" "kesko_krista_bar" {
  user_principal_name = "krista.bar@kesko.fi"
}

data "azuread_user" "kesko_visa_rautiainen" {
  user_principal_name = "visa.rautiainen@kesko.fi"
}

data "azuread_user" "kesko_swati_choudhary" {
  user_principal_name = "swati.choudhary@kesko.fi"
}

data "azuread_user" "kesko_heikki_pulli" {
  user_principal_name = "heikki.pulli@kesko.fi"
}

