# ---------------------------------------------------------------------------------------------
resource "azuread_application" "platform_devops" {
  display_name = "${var.prefix_sp}-platform-devops-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "platform_devops" {
  client_id                    = azuread_application.platform_devops.client_id
  owners                       = local.owners
  app_role_assignment_required = false
  tags                         = ["HideApp", "apiConsumer", "backgroundProcess", ]
}

# resource "azuread_application_federated_identity_credential" "platform_devops-github_actions" {
#   application_id = azuread_application.platform_devops.id
#   display_name   = "github-actions"
#   description    = "Deployments with github actions for kais specific repositories"
#   audiences      = ["api://AzureADTokenExchange"]
#   issuer         = "https://token.actions.githubusercontent.com"
#   subject        = "claims['sub'] matches 'repo:kesko-dev/kais-*:*'"

#   lifecycle {
#     ignore_changes = [ subject ] # Ignore changes on subject due to terraform not supporting claim matching expression
#   }
# }