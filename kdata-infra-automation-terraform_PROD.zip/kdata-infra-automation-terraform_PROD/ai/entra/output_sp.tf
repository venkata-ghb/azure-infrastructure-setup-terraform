output "sp_platform_devops" {
  value = {
    id           = azuread_service_principal.platform_devops.object_id
    display_name = azuread_service_principal.platform_devops.display_name
  }
}

output "sp_password_rotation" {
  value = {
    rotation_setting_id = time_rotating.rotation_setting.id
  }
}