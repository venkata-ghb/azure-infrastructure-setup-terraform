# AI Solution Team - This is created in core/ad/grgoup.tf in dev repo
data "azuread_group" "az_ais" {
  display_name = "AZ_KDATA_DEV_AIS"
}