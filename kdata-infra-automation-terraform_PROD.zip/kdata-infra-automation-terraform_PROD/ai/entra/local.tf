locals {
  owners = [
    data.azuread_user.kesko_nico_miettinen.object_id,
    "7e945af3-edab-49b7-9809-a7161c6858ff", # MSI
    data.azuread_user.kesko_nakul_bansal.object_id,
    data.azuread_user.kesko_heikki_pulli.object_id,
  ]
}

resource "time_rotating" "rotation_setting" {
  rotation_days = 720
}