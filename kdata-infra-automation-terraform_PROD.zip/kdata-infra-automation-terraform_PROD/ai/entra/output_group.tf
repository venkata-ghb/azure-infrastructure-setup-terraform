output "group_az_ais" {
  value = {
    id           = data.azuread_group.az_ais.object_id
    display_name = data.azuread_group.az_ais.display_name
  }
}