# Role Assignment Project level
resource "azurerm_role_assignment" "platform_projects" {
  for_each = {
    for ra in local.project_role_assignments :
    "${ra.project_name}-${ra.role_name}-${ra.type}-${ra.value}" => ra
  }

  scope                = azapi_resource.platform-project[each.value.project_name].id
  role_definition_name = each.value.role_name
  principal_id         = each.value.object_id
}

# Role Assignment at Foundry level
resource "azurerm_role_assignment" "platform_foundry" {
  for_each = {
    for ra in local.foundry_role_assignments :
    "${ra.role_name}-${ra.type}-${ra.value}" => ra
  }

  scope                = azurerm_cognitive_account.platform-foundry.id
  role_definition_name = each.value.role_name
  principal_id         = each.value.object_id
} 