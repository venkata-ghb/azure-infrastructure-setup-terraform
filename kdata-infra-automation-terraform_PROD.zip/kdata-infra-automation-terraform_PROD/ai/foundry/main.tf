provider "azapi" {
  subscription_id = var.SUBSCRIPTION_ID
}

terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "=4.54.0"
    }
    azapi = {
      source  = "azure/azapi"
      version = "~> 2.5"
    }
  }
  backend "azurerm" {}
  required_version = "= 1.13.3"
}

provider "azurerm" {
  subscription_id     = var.SUBSCRIPTION_ID
  tenant_id           = var.TENANT_ID
  storage_use_azuread = true
  features {}
}

data "azurerm_subscription" "current" {}

data "terraform_remote_state" "common" {
  backend = "azurerm"
  config = {
    subscription_id      = var.SUBSCRIPTION_ID
    resource_group_name  = var.TF_RG_NAME
    storage_account_name = var.TF_SA_NAME
    container_name       = var.TF_CONTAINER_NAME
    key                  = "core/common.terraform_PROD.tfstate"
  }
}

data "terraform_remote_state" "integrations" {
  backend = "azurerm"
  config = {
    subscription_id      = var.SUBSCRIPTION_ID
    resource_group_name  = var.TF_RG_NAME
    storage_account_name = var.TF_SA_NAME
    container_name       = var.TF_CONTAINER_NAME
    key                  = "integrations/common.terraform_PROD.tfstate"
  }
}

data "terraform_remote_state" "ad" {
  backend = "azurerm"
  config = {
    subscription_id      = var.SUBSCRIPTION_ID
    resource_group_name  = var.TF_RG_NAME
    storage_account_name = var.TF_SA_NAME
    container_name       = var.TF_CONTAINER_NAME
    key                  = "core/ad.terraform_PROD.tfstate"
  }
}

# Adding DEV ad references
data "terraform_remote_state" "ad_dev" {
  backend = "azurerm"
  config = {
    subscription_id      = "f11ae7de-3b87-49e7-8a17-55041f3739c4"
    resource_group_name  = "K-DATA_TEST_WE_Terraform_RG"
    storage_account_name = "kdatadevtestinfrasa"
    container_name       = "tf-state"
    key                  = "DEV/core/ad.terraform_DEV.tfstate"
  }
}


# List of variables passed in via pipelines

variable "SUBSCRIPTION_ID" {
  type = string
}

variable "TENANT_ID" {
  type = string
}

variable "MSI_ID" {
  type = string
}

variable "TF_SUBNET_ID" {
  type = string
}

variable "TF_RG_NAME" {
  type = string
}

variable "TF_SA_NAME" {
  type = string
}

variable "TF_CONTAINER_NAME" {
  type = string
}
