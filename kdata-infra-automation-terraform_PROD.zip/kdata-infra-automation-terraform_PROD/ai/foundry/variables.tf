variable "location" {
  type        = string
  description = "Location"
  default     = "westeurope"
}

variable "location_sc" {
  type        = string
  description = "Location"
  default     = "swedencentral"
}

variable "location_eus" {
  type        = string
  description = "Location"
  default     = "eastus"
}

variable "prefix_sa" {
  type        = string
  description = "Prefix to be applied to all resource names in storage account"
  default     = "kdataprod"
}

variable "prefix_rg" {
  type        = string
  description = "Prefix to be applied to all resource names in resource group"
  default     = "K-DATA_PROD"
}

variable "prefix_rg_eus" {
  type        = string
  description = "Prefix to be applied to all resource names in resource group"
  default     = "K-DATA_PROD_EUS"
}

variable "prefix" {
  type        = string
  description = "Prefix to be applied to all resource names in storage account"
  default     = "kdata-prod-we"
}

variable "prefix_eus" {
  type        = string
  description = "Prefix to be applied to all resource names in storage account"
  default     = "kdata-prod-eus"
}

variable "prefix_kv" {
  type        = string
  description = "Prefix to be applied to all resource names in storage account"
  default     = "kdata-prod"
}

variable "prefix_sc" {
  type        = string
  description = "Prefix to be applied to all resource names in storage account"
  default     = "kdata-prod-sc"
}

variable "prefix_fc" {
  type        = string
  description = "Prefix to be applied to all resource names in storage account"
  default     = "kdata-prod-fc"
}

variable "location_szn" {
  type        = string
  description = "Location"
  default     = "switzerlandnorth"
}

variable "location_fc" {
  type        = string
  description = "Location"
  default     = "francecentral"
}
