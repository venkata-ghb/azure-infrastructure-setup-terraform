# Project
resource "azapi_resource" "platform-project" {
  for_each                  = { for project in local.input.projects : project.name => project }
  type                      = "Microsoft.CognitiveServices/accounts/projects@2025-06-01"
  name                      = "${each.value.name}_${upper(local.input.environment)}"
  parent_id                 = azurerm_cognitive_account.platform-foundry.id
  location                  = local.input.location
  tags                      = local.resource_tags
  schema_validation_enabled = false

  body = {
    sku = {
      name = "S0"
    }
    identity = {
      type = "SystemAssigned"
    }

    properties = {
      displayName = "${each.value.displayName} ${upper(local.input.environment)}"
      description = each.value.description
    }
  }
}
