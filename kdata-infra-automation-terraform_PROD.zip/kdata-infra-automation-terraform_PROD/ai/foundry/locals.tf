locals {
  resource_tags = data.terraform_remote_state.common.outputs.resource_tags
  msi_infra_key_vault_access = data.terraform_remote_state.common.outputs.msi_infra_key_vault_access
  # Read config file
  input                      = yamldecode(file("config_platform.yaml"))

  # Extract all the object ids from upn (users accounts)
  project_upns = toset(flatten([
    for project in local.input.projects : [
      for role, principals in project.roleAssignment : [
        for p in principals : p.value if p.type == "upn"
      ]
    ]
  ]))
  # Collect all UPNs from foundry-level roleAssignment
  foundry_upns = toset(flatten([
    for role, principals in local.input.roleAssignment : [
      for p in principals : p.value if p.type == "upn"
    ]
  ]))
  # Merge both sets so data.azuread_user covers all
  all_upns = setunion(local.project_upns, local.foundry_upns)

  # project 
  project_role_assignments = flatten([
    for project in local.input.projects : [
      for role, principals in project.roleAssignment : [
        for p in principals : {
          project_name = project.name
          role_name    = role
          type         = p.type
          value        = p.value
          object_id = (
            p.type == "upn" ? data.azuread_user.users[p.value].object_id :
            #p.type == "groupname"? data.azuread_group.groups[p.value].object_id :
            #p.type == "sp"       ? data.azuread_service_principal.sps[p.value].object_id :
            #p.type == "msi"      ? data.azurerm_user_assigned_identity.msis[p.value].principal_id :
            p.type == "objectId"  ? p.value :
            null
          )
        }
      ]
    ]
  ])

  # Foundry role assignments
  foundry_role_assignments = flatten([
    for role, principals in local.input.roleAssignment : [
      for p in principals : {
        role_name = role
        type      = p.type
        value     = p.value
        object_id = (
          p.type == "upn" ? data.azuread_user.users[p.value].object_id :
          #p.type == "groupname" ? data.azuread_group.groups[p.value].object_id :
          p.type == "objectId" ? p.value :
          null
        )
      }
    ]
  ])
}
