# RG for Azure AI Foundry
resource "azurerm_resource_group" "platform" {
  name     = "${local.input.prefixRG}_${upper(local.input.environment)}_${upper(local.input.name)}_FOUNDRY_RG"
  location = "${upper(local.input.location)}"
  tags     = local.resource_tags
}


# Sweden Central
data "azurerm_resource_group" "openai_sc" {
  name     = "${var.prefix_rg}_SC_OpenAI_RG"
}

# France Central
data "azurerm_resource_group" "openai_fc" {
  name     = "${var.prefix_rg}_FC_OpenAI_RG"
}