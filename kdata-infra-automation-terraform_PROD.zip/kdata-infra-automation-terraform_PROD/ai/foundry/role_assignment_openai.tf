# APIM Role assignment to create load balancer
resource "azurerm_role_assignment" "ca_openai_sc-openai_contributor-apim_sp" {
  scope                = azurerm_cognitive_account.openai_sc.id
  role_definition_name = "Cognitive Services OpenAI Contributor"
  principal_id         = "a38294ec-dcdf-46a3-9d95-9efd1d8d0243"  # System Managed identity for apim-kgroup-prod
}

resource "azurerm_role_assignment" "ca_openai_fc-openai_contributor-apim_sp" {
  scope                = azurerm_cognitive_account.openai_fc.id
  role_definition_name = "Cognitive Services OpenAI Contributor"
  principal_id         = "a38294ec-dcdf-46a3-9d95-9efd1d8d0243"  # System Managed identity for apim-kgroup-prod
}