# Microsoft Foundry Platform resource
resource "azurerm_cognitive_account" "platform-foundry" {
  name                = "${local.input.platformPrefix}-${local.input.environment}-${local.input.name}-foundry"
  location            = local.input.location
  resource_group_name = azurerm_resource_group.platform.name
  kind                = "AIServices"
  local_auth_enabled  = "true"

  identity {
    type = "SystemAssigned"
  }

  sku_name = "S0"

  # required for stateful development in Foundry including agent service
  custom_subdomain_name      = "${local.input.platformPrefix}-${local.input.environment}-${local.input.name}-foundry"
  project_management_enabled = true

  tags = local.resource_tags
}