# OpenAI in Sweden Central
resource "azurerm_cognitive_account" "openai_sc" {
  name                  = "${var.prefix_sc}-openai2"
  custom_subdomain_name = "${var.prefix_sc}-openai2"
  location              = data.azurerm_resource_group.openai_sc.location
  resource_group_name   = data.azurerm_resource_group.openai_sc.name
  kind                  = "OpenAI"
  sku_name              = "S0"

  tags = local.resource_tags
}


# OpenAI in France Central
resource "azurerm_cognitive_account" "openai_fc" {
  name                  = "${var.prefix_fc}-openai2"
  custom_subdomain_name = "${var.prefix_fc}-openai2"
  location              = data.azurerm_resource_group.openai_fc.location
  resource_group_name   = data.azurerm_resource_group.openai_fc.name
  kind                  = "OpenAI"
  sku_name              = "S0"

  tags = local.resource_tags
}
