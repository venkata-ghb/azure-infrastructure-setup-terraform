 # Lookup each user individually
data "azuread_user" "users" {
  for_each = { for upn in local.all_upns : upn => upn }
  user_principal_name = each.value
}

