output resource_tags {
  value = {
    Application     = "K-Data"
    "Business Unit" = "Shared"
    Description     = "Infrastructure for Kesko Data Platform"
    Environment     = "Production"
    IT-owner        = "krista.bar@kesko.fi"
    ManagedResource = "Yes"
    MgmtVendor      = "Tieto"
    Sub-Service     = "C1231"
    created_by      = "Terraform"
  }
}

output environment {
  value = {
    short = "prod"
    long  = "Production"
  }
}

output location {
  value = {
    short = "we"
    long  = "westeurope"
  }
}

output prefix {
  description = "Prefix to be applied to all resource names"
  value       = "kais-prod"
}

output prefix_sa {
  description = "Prefix to be applied to all storage account resource names"
  value       = "kaisprod"
}

output prefix_rg {
  description = "Prefix to be applied to all resource group names"
  value       = "K-AIS_PROD"
}

output msi_infra_key_vault_access {
  value = {
    object_id               = "7e945af3-edab-49b7-9809-a7161c6858ff"
    tenant_id               = data.azurerm_subscription.current.tenant_id
    application_id          = ""
    certificate_permissions = ["Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"]
    key_permissions         = ["Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"]
    secret_permissions      = ["Get", "List", "Set", "Delete", "Recover", "Backup", "Restore", "Purge"]
    storage_permissions     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"]
  }
}

output ip_kesko_workspace {
  description = "List of Kesko workspace IPs"
  value = [
    "157.144.201.0/24",
    "157.144.241.0/24",
  ]
}
