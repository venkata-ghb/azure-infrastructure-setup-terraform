# provider "azapi" {
#   subscription_id = var.SUBSCRIPTION_ID
#}

terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "=4.71.0"
    }
    azuread = {
      source  = "hashicorp/azuread"
      version = "=3.8.0"
    }
    # azapi = {
    #   source  = "azure/azapi"
    #   version = "~> 2.5"
    # }
  }
  backend "azurerm" {}
  required_version = "= 1.13.3"
}

provider "azurerm" {
  subscription_id     = var.SUBSCRIPTION_ID
  tenant_id           = var.TENANT_ID
  storage_use_azuread = true
  features {}
}

data "azurerm_subscription" "current" {}

# List of variables passed in via pipelines

variable "SUBSCRIPTION_ID" {
  type = string
}

variable "TENANT_ID" {
  type = string
}

variable "MSI_ID" {
  type = string
}

variable "TF_SUBNET_ID" {
  type = string
}

variable "TF_RG_NAME" {
  type = string
}

variable "TF_SA_NAME" {
  type = string
}

variable "TF_CONTAINER_NAME" {
  type = string
}
