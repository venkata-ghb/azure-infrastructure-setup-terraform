resource "azurerm_monitor_action_group" "kesko_developers" {
  name                = "${local.prefix}-kesko-developers-action-group"
  short_name          = "kdatkeskodev"
  resource_group_name = azurerm_resource_group.monitoring.name

  email_receiver {
    name          = "NicoMiettinen"
    email_address = "nico.miettinen@kesko.fi"
  }

  tags = local.resource_tags
}
