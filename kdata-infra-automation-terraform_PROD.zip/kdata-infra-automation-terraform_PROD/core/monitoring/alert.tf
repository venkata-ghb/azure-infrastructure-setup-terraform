resource "azurerm_monitor_scheduled_query_rules_alert" "kdata_prod-vm_memory_used" {
  name                = "${var.prefix}-kdata-prod-vm-used-alert"
  location            = azurerm_resource_group.monitoring.location
  resource_group_name = azurerm_resource_group.monitoring.name
  tags                = local.resource_tags

  action {
    action_group = ["/subscriptions/02147589-2a7d-4483-b5da-af70a38cea3f/resourceGroups/K-DATA_PROD_WE_OR_Main_RG/providers/microsoft.insights/actionGroups/kdata-prod-technical-errors-action-group",
    "/subscriptions/02147589-2a7d-4483-b5da-af70a38cea3f/resourceGroups/K-DATA_PROD_WE_OR_Main_RG/providers/microsoft.insights/actionGroups/ayehuintegration"]
    email_subject = "Azure: Prod VM memory usage is greater than 90%"
  }

  data_source_id = azurerm_log_analytics_workspace.kdata-prod-loganalytics.id
  description    = "Prod VM memory usage is greater than 90%."
  enabled        = true
  severity       = 0
  frequency      = 5
  time_window    = 15
  throttling     = 480
  trigger {
    operator  = "GreaterThan"
    threshold = 90

    metric_trigger {
      metric_column       = "AggregatedValue"
      metric_trigger_type = "Consecutive"
      operator            = "GreaterThan"
      threshold           = 1
    }
  }

  query = <<QUERY
  Perf 
  | where ObjectName == 'Memory' and (CounterName == '% Committed Bytes In Use' or CounterName == '% Used Memory') 
  | summarize AggregatedValue = avg(CounterValue) by bin(TimeGenerated, 5m), Computer
  QUERY
}

resource "azurerm_monitor_scheduled_query_rules_alert" "kdata_prod-sql_dtu_alert" {
  name                = "${local.prefix}-sql-dtu-alert"
  location            = azurerm_resource_group.monitoring.location
  resource_group_name = lower(azurerm_resource_group.monitoring.name)
  tags                = local.resource_tags

  action {
    action_group = [
      "/subscriptions/02147589-2a7d-4483-b5da-af70a38cea3f/resourcegroups/k-data_prod_we_or_main_rg/providers/microsoft.insights/actiongroups/kdata-prod-integration-errors-action-group",
      "/subscriptions/02147589-2a7d-4483-b5da-af70a38cea3f/resourcegroups/k-data_prod_we_or_main_rg/providers/microsoft.insights/actiongroups/ayehuintegration",
    ]
    custom_webhook_payload = jsonencode(
      {
        AlertRuleName        = "#alertrulename"
        Description          = "Kesko Prod SQL DTU usage over 90%. Check Event in ServiceNow or link #linktosearchresults"
        Event_class          = "Azure_TDP"
        IncludeSearchResults = true
        Severity             = "Critical"
        SubscriptionId       = "Kesko Data Platform Production"
        WorkspaceId          = "DTU"
      }
    )
  }

  data_source_id = azurerm_log_analytics_workspace.kdata-prod-loganalytics.id

  enabled     = true
  severity    = 0
  frequency   = 5
  time_window = 30
  throttling  = 0
  trigger {
    operator  = "GreaterThan"
    threshold = 90

    metric_trigger {
      metric_column       = "AggregatedValue"
      metric_trigger_type = "Consecutive"
      operator            = "GreaterThan"
      threshold           = 5
    }
  }

  query = <<QUERY
AzureMetrics | where MetricName == 'dtu_consumption_percent' | summarize AggregatedValue = avg(Average) by bin(TimeGenerated, 5m), Resource
  QUERY
}

resource "azurerm_monitor_alert_processing_rule_suppression" "sql_dtu" {
  name                = "${local.prefix}-sql-dtu-alert-supression"
  resource_group_name = azurerm_resource_group.monitoring.name
  tags                = local.resource_tags
  scopes              = [azurerm_log_analytics_workspace.kdata-prod-loganalytics.id]
  description         = "Suppresses SQL DTU alert on night time to avoid unnecessary noise"

  condition {
    alert_rule_name {
      operator = "Equals"
      values   = [azurerm_monitor_scheduled_query_rules_alert.kdata_prod-sql_dtu_alert.name]
    }
  }

  schedule {
    time_zone = "FLE Standard Time"
    recurrence {
      daily {
        start_time = "22:00:00"
        end_time   = "08:00:00"
      }
    }
  }
}
