resource "azurerm_automation_account" "automation-prod" {
  name                = "Automation-prod"
  location            = azurerm_resource_group.monitoring.location
  resource_group_name = azurerm_resource_group.monitoring.name
  sku_name            = "Basic"
  tags                = local.resource_tags
}
