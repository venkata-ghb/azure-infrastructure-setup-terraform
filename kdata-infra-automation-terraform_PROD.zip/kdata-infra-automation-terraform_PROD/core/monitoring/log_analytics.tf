resource "azurerm_log_analytics_workspace" "kdata-prod-loganalytics" {
  name                = "kdata-prod-loganalytics"
  location            = azurerm_resource_group.monitoring.location
  resource_group_name = azurerm_resource_group.monitoring.name
  sku                 = "PerNode"
  retention_in_days   = 31
  tags                = local.resource_tags
}

resource "azurerm_log_analytics_linked_service" "kdata-prod-loganalytics-automation" {
  resource_group_name = azurerm_resource_group.monitoring.name
  workspace_id        = azurerm_log_analytics_workspace.kdata-prod-loganalytics.id
  read_access_id      = azurerm_automation_account.automation-prod.id
  //  tags = local.resource_tags
}

resource "azurerm_log_analytics_linked_service" "automation" {
  resource_group_name = azurerm_resource_group.monitoring.name
  workspace_id        = azurerm_log_analytics_workspace.kdata-prod-loganalytics.id
  read_access_id      = azurerm_automation_account.automation-prod.id
  //  tags = local.resource_tags
}

resource "azurerm_log_analytics_solution" "containerinsights-kdata-prod-loganalytics-" {
  solution_name         = "ContainerInsights"
  location              = azurerm_resource_group.monitoring.location
  resource_group_name   = azurerm_resource_group.monitoring.name
  workspace_resource_id = azurerm_log_analytics_workspace.kdata-prod-loganalytics.id
  workspace_name        = azurerm_log_analytics_workspace.kdata-prod-loganalytics.name
  //tags = local.resource_tags
  tags = local.resource_tags
  plan {
    publisher = "Microsoft"
    product   = "OMSGallery/ContainerInsights"
  }
}

resource "azurerm_log_analytics_solution" "containers-kdata-prod-loganalytics-" {
  solution_name         = "Containers"
  location              = azurerm_resource_group.monitoring.location
  resource_group_name   = azurerm_resource_group.monitoring.name
  workspace_resource_id = azurerm_log_analytics_workspace.kdata-prod-loganalytics.id
  workspace_name        = azurerm_log_analytics_workspace.kdata-prod-loganalytics.name
  tags                  = local.resource_tags
  plan {
    publisher = "Microsoft"
    product   = "OMSGallery/Containers"
  }
}

/*
resource "azurerm_log_analytics_solution" "azuredatafactoryanalytics-kdata-prod-loganalytics-" {
  solution_name = "AzureDataFactoryAnalytics"
  location = var.location
  resource_group_name = azurerm_resource_group.monitoring.name
  workspace_resource_id = azurerm_log_analytics_workspace.kdata-prod-loganalytics.id
  workspace_name = azurerm_log_analytics_workspace.kdata-prod-loganalytics.name
  
  plan {
    publisher = "Microsoft"
    product = "OMSGallery/AzureDataFactoryAnalytics"
  }
}

*/

/*

resource "azurerm_log_analytics_solution" "MicrosoftAzureSQLDatabase-SecurityInsightsandAccesstoSensitiveData-kdata-prod-loganalytics-" {
  solution_name = "Microsoft Azure SQL Database - Security Insights and Access to Sensitive Data"
  location = var.location
  resource_group_name = azurerm_resource_group.monitoring.name
  workspace_resource_id = azurerm_log_analytics_workspace.kdata-prod-loganalytics.id
  workspace_name = azurerm_log_analytics_workspace.kdata-prod-loganalytics.name
  
  plan {
    publisher = "Microsoft"
   product = "OMSGallery/Microsoft Azure SQL Database - Security Insights and Access to Sensitive Data"
  }
}

*/

resource "azurerm_log_analytics_solution" "servicemap-kdata-prod-loganalytics-" {
  solution_name         = "ServiceMap"
  location              = azurerm_resource_group.monitoring.location
  resource_group_name   = azurerm_resource_group.monitoring.name
  workspace_resource_id = azurerm_log_analytics_workspace.kdata-prod-loganalytics.id
  workspace_name        = azurerm_log_analytics_workspace.kdata-prod-loganalytics.name
  tags                  = local.resource_tags
  plan {
    publisher = "Microsoft"
    product   = "OMSGallery/ServiceMap"
  }
}

resource "azurerm_log_analytics_solution" "updates-kdata-prod-loganalytics-" {
  solution_name         = "Updates"
  location              = azurerm_resource_group.monitoring.location
  resource_group_name   = azurerm_resource_group.monitoring.name
  workspace_resource_id = azurerm_log_analytics_workspace.kdata-prod-loganalytics.id
  workspace_name        = azurerm_log_analytics_workspace.kdata-prod-loganalytics.name
  tags                  = local.resource_tags
  plan {
    publisher = "Microsoft"
    product   = "OMSGallery/Updates"
  }
}

# ============================================================================================================

resource "azurerm_log_analytics_workspace" "security" {
  name                = "${var.prefix}-sec-loganalytics"
  location            = var.location
  resource_group_name = lower(azurerm_resource_group.security.name)
  sku                 = "PerGB2018"
  retention_in_days   = 30
  tags                = local.resource_tags
}

resource "azurerm_log_analytics_solution" "security-security" {
  solution_name         = "Security"
  location              = var.location
  resource_group_name   = azurerm_resource_group.security.name
  workspace_resource_id = azurerm_log_analytics_workspace.security.id
  workspace_name        = azurerm_log_analytics_workspace.security.name
  tags                  = local.resource_tags

  plan {
    publisher = "Microsoft"
    product   = "OMSGallery/Security"
  }
}

resource "azurerm_log_analytics_solution" "security-securitycenterfree" {
  solution_name         = "SecurityCenterFree"
  location              = var.location
  resource_group_name   = azurerm_resource_group.security.name
  workspace_resource_id = azurerm_log_analytics_workspace.security.id
  workspace_name        = azurerm_log_analytics_workspace.security.name
  tags                  = local.resource_tags

  plan {
    publisher = "Microsoft"
    product   = "OMSGallery/SecurityCenterFree"
  }
}

/*
resource "azurerm_log_analytics_solution" "security-sqlauditing" {
  solution_name         = "SQLAuditing"
  location              = var.location
  resource_group_name   = azurerm_resource_group.security.name
  workspace_resource_id = azurerm_log_analytics_workspace.security.id
  workspace_name        = azurerm_log_analytics_workspace.security.name
  tags                  = local.resource_tags

  plan {
    publisher = "Microsoft"
    product = "OMSGallery/SQLAuditing"
  }
}
*/
