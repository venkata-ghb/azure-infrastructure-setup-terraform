output "loganalytics_workspace" {
  value = {
    id           = azurerm_log_analytics_workspace.kdata-prod-loganalytics.id
    name         = azurerm_log_analytics_workspace.kdata-prod-loganalytics.name
    workspace_id = azurerm_log_analytics_workspace.kdata-prod-loganalytics.workspace_id
  }
}

output "loganalytics_workspace_key" {
  value     = azurerm_log_analytics_workspace.kdata-prod-loganalytics.primary_shared_key
  sensitive = true
}

output "loganalytics_workspace_id" {
  value = azurerm_log_analytics_workspace.kdata-prod-loganalytics.id
}

output "loganalytics_workspace_security" {
  value = azurerm_log_analytics_workspace.security
}

output "sa_auditlogs" {
  value = azurerm_storage_account.auditlogs
}

output "sa_audit" {
  value = azurerm_storage_account.audit
}

output "sa_auditintdbricks" {
  value = azurerm_storage_account.auditintdbricks
}

output "sa_kdigdatabricks" {
  value = azurerm_storage_account.kdigdatabricks
}

output "action_group_kesko_developers" {
  value = {
    id                  = azurerm_monitor_action_group.kesko_developers.id
    name                = azurerm_monitor_action_group.kesko_developers.name
    short_name          = azurerm_monitor_action_group.kesko_developers.short_name
    resource_group_name = azurerm_monitor_action_group.kesko_developers.resource_group_name
  }
}
