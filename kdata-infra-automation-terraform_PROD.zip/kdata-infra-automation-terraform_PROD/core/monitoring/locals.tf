locals {
  location      = data.terraform_remote_state.common.outputs.location
  prefix        = data.terraform_remote_state.common.outputs.prefix
  resource_tags = data.terraform_remote_state.common.outputs.resource_tags
}
