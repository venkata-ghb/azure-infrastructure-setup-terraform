resource "azurerm_resource_group" "monitoring" {
  name     = "${var.prefix_rg}_WE_Monitoring_RG"
  location = var.location
  tags     = local.resource_tags
}

resource "azurerm_resource_group" "security" {
  name     = "${var.prefix_rg}_WE_Security_RG"
  location = var.location
  tags     = local.resource_tags
}
