terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "=2.87.0"
    }
  }
  backend "azurerm" {}
  required_version = "= 0.13.2"
}

provider "azurerm" {
  features {}
  storage_use_azuread = true
  subscription_id = var.SUBSCRIPTION_ID
  tenant_id       = var.TENANT_ID
}

data "azurerm_subscription" "current" {}

# List of variables passed in via pipelines

variable "SUBSCRIPTION_ID" {
  type = string
}

variable "TENANT_ID" {
  type = string
}

variable "MSI_ID" {
  type = string
}

variable "TF_SUBNET_ID" {
  type = string
}

variable "TF_RG_NAME" {
  type = string
}

variable "TF_SA_NAME" {
  type = string
}

variable "TF_CONTAINER_NAME" {
  type = string
}
