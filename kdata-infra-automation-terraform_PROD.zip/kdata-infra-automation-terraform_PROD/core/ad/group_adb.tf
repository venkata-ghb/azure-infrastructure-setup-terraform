resource "azuread_group" "adb_app_aecorsoft" {
  display_name            = "${var.prefix_ad_group}_ADB_APP_AECORSOFT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members                 = []
}

resource "azuread_group" "adb_app_bookkeeping" {
  display_name            = "${var.prefix_ad_group}_ADB_APP_BOOKKEEPING"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.or_bookkeeping.id,
  ]
}

resource "azuread_group" "adb_app_catman" {
  display_name            = "${var.prefix_ad_group}_ADB_APP_CATMAN"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.catman_adb.id,
  ]
}

resource "azuread_group" "adb_app_lumi" {
  display_name            = "${var.prefix_ad_group}_ADB_APP_LUMI"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.lumi_devops.id,
    data.azuread_service_principal.lumi_adf.id,
  ]
}

resource "azuread_group" "adb_app_powerbi" {
  display_name            = "${var.prefix_ad_group}_ADB_APP_POWERBI"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.powerbi_kdig.id,
  ]
}

resource "azuread_group" "adb_app_qlik" {
  display_name            = "${var.prefix_ad_group}_ADB_APP_QLIK"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.qlik_gt.id,
  ]
}

resource "azuread_group" "adb_app_sps" {
  display_name            = "${var.prefix_ad_group}_ADB_APP_SPS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.or_azdevops.id,
    azuread_service_principal.platform_devops.id,
  ]
}

resource "azuread_group" "adb_app_adima" {
  display_name            = "${var.prefix_ad_group}_ADB_APP_ADIMA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_user.kesko_anssi_salomaa.object_id,
    data.azuread_user.kesko_jari_vainio.object_id,
    data.azuread_user.kesko_jukka_kemppinen.object_id,
    data.azuread_user.kesko_joonas_heikela.object_id,
  ]
}

resource "azuread_group" "adb_app_attribution" {
  display_name            = "${var.prefix_ad_group}_ADB_APP_ATTRIBUTION"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "adb_app_digitalsignage" {
  display_name            = "${var.prefix_ad_group}_ADB_APP_DIGITALSIGNAGE"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_user.kesko_henri_dahlstrom.object_id,
    data.azuread_user.kesko_janne_jaalivaara.object_id,
    data.azuread_user.kesko_jarno_martikainen.object_id,
  ]
}

resource "azuread_group" "adb_app_dmp" {
  display_name            = "${var.prefix_ad_group}_ADB_APP_DMP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_user.kesko_jarno_martikainen.object_id,
  ]
}

resource "azuread_group" "adb_app_feedbuilder" {
  display_name            = "${var.prefix_ad_group}_ADB_APP_FEEDBUILDER"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.feedbuilder_qlik.id,
  ]
}

resource "azuread_group" "adb_app_gtbusinessanalysts" {
  display_name            = "${var.prefix_ad_group}_ADB_APP_GTBUSINESSANALYSTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true

  lifecycle {
    ignore_changes = [members]
  }
}

resource "azuread_group" "adb_app_kvalikoima" {
  display_name            = "${var.prefix_ad_group}_ADB_APP_KVALIKOIMA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_user.kesko_jari_vainio.object_id,
  ]
}

resource "azuread_group" "adb_app_kpartner" {
  display_name            = "${var.prefix_ad_group}_ADB_APP_KPARTNER"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_user.futurice_kaarel_korvemaa.object_id,
    data.azuread_user.kesko_jussi_forma.object_id,
    data.azuread_user.kesko_niilo_latva-pukkila.object_id,
    data.azuread_user.kesko_matias_tiainen.object_id,
    data.azuread_user.kesko_oskari_lehtonen.object_id,
    data.azuread_user.kesko_ville_tarvonen.object_id,
    data.azuread_user.kesko_henri_dahlstrom.object_id,
    data.azuread_user.kesko_pontus_lindroos.object_id,
    data.azuread_user.kesko_tiitus_kareno.object_id,
    data.azuread_user.kesko_harri_palomaa.object_id,
    data.azuread_user.kesko_sanna_vepsalainen.object_id,
    data.azuread_user.kesko_patrik_merla.object_id,
    data.azuread_user.kesko_kaj_giersberg.object_id,
    data.azuread_user.kesko_juho_tommila.object_id,
    data.azuread_user.kesko_tuomas_sauvola.object_id,
    data.azuread_user.kesko_shyamal_mondal.object_id,
  ]
}

resource "azuread_group" "adb_app_retrobonus" {
  display_name            = "${var.prefix_ad_group}_ADB_APP_RETROBONUS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_user.kesko_jari_vainio.object_id,
    data.azuread_user.kesko_joonas_heikela.object_id,
    data.azuread_user.kesko_markus_markkula.object_id,
    data.azuread_user.kesko_anssi_salomaa.object_id
  ]
}

resource "azuread_group" "adb_app_datareaders" {
  display_name            = "${var.prefix_ad_group}_ADB_APP_DATAREADERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_user.kesko_jarno_ritala.object_id,
    data.azuread_user.kesko_saija_somero.object_id,
    data.azuread_user.kesko_sari_hokka.object_id,
    data.azuread_user.kesko_susanna_sundberg.object_id,
    data.azuread_user.kesko_sanna_vepsalainen.object_id,
    data.azuread_user.kesko_janne_uutela.object_id,
  ]
}

resource "azuread_group" "adb_app_controlm" {
  display_name            = "${var.prefix_ad_group}_ADB_APP_CONTROLM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.controlm_adb.id,
  ]
}

resource "azuread_group" "adb_app_neste" {
  display_name            = "${var.prefix_ad_group}_ADB_APP_NESTE"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.int_adf.id,
  ]
}

resource "azuread_group" "adb_app_wolt" {
  display_name            = "${var.prefix_ad_group}_ADB_APP_WOLT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.wolt_adb.id,
  ]
}

resource "azuread_group" "adb_app_wolt_rpa" {
  display_name            = "${var.prefix_ad_group}_ADB_APP_WOLT_RPA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.wolt_rpa_adb.id,
  ]
}

resource "azuread_group" "adb_app_uc_admins" {
  display_name            = "${var.prefix_ad_group}_ADB_APP_UC_ADMINS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_user.kesko_nico_miettinen.id,
    data.azuread_service_principal.infra.id,
    data.azuread_user.kesko_nakul_bansal.id,
  ]
}

resource "azuread_group" "adb_app_ktavara" {
  display_name            = "${var.prefix_ad_group}_ADB_APP_KTAVARA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true

  lifecycle {
    ignore_changes = [members]
  }
}
