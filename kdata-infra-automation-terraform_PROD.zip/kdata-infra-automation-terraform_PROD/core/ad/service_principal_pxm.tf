# ---------------------------------------------------------------------------------------------
# pxm-devops
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "pxm_devops" {
  display_name = "${var.prefix_sp}-pxm-devops-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "pxm_devops" {
  application_id = azuread_application.pxm_devops.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}
/*
resource "azuread_service_principal_password" "pxm_devops" {
  service_principal_id = azuread_service_principal.pxm_devops.id
  end_date             = var.pwd_expr_date_crit
}
*/

# ---------------------------------------------------------------------------------------------
# pxm-eventhub
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "pxm_eventhub" {
  display_name = "${var.prefix_sp}-pxm-eventhub-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "pxm_eventhub" {
  application_id = azuread_application.pxm_eventhub.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "pxm_eventhub" {
  service_principal_id = azuread_service_principal.pxm_eventhub.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}
