# ---------------------------------------------------------------------------------------------
# gtanalytics-adb
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "gtanalytics_adb" {
  display_name = "${var.prefix_sp}-gtanalytics-adb-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "gtanalytics_adb" {
  application_id = azuread_application.gtanalytics_adb.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "gtanalytics_adb" {
  service_principal_id = azuread_service_principal.gtanalytics_adb.id
  end_date             = var.pwd_expr_date_crit2
  display_name         = "primary"
}
