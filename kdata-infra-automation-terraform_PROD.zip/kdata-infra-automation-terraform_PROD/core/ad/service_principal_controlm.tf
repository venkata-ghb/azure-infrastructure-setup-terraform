# ---------------------------------------------------------------------------------------------
# controlm-adf
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "controlm_adf" {
  display_name = "${var.prefix_sp}-controlmadf-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "controlm_adf" {
  application_id = azuread_application.controlm_adf.application_id
  owners         = local.owners
  tags           = ["DataFactoryJobUsingControlM", ]
}

resource "azuread_service_principal_password" "controlm_adf" {
  service_principal_id = azuread_service_principal.controlm_adf.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}


# ---------------------------------------------------------------------------------------------
# controlm-adb
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "controlm_adb" {
  display_name = "${var.prefix_sp}-controlm-adb-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "controlm_adb" {
  application_id = azuread_application.controlm_adb.application_id
  owners         = local.owners
  tags           = ["DatabricksForControlM", ]
}

resource "azuread_service_principal_password" "controlm_adb" {
  service_principal_id = azuread_service_principal.controlm_adb.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}
