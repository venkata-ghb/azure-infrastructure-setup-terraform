resource "azuread_group" "apim_eslist_app_input_api" {
  display_name            = "${var.prefix_apim_ad_group}_ESLIST_APP_INPUT_API"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_platform.id,
  ]
}

resource "azuread_group" "apim_gtsap_reclamation_image_api" {
  display_name            = "${var.prefix_apim_ad_group}_GTSAP_RECLAMATION_IMAGE_API"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_platform.id,
  ]
}

resource "azuread_group" "apim_kerays_input_api" {
  display_name            = "${var.prefix_apim_ad_group}_KERAYS_INPUT_API"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_platform.id,
  ]
}

/* GROUP FROM PPM
resource "azuread_group" "apim_kkampanja_sap_input_api" {
  display_name            = "${var.prefix_apim_ad_group}_KKAMPANJA_SAP_INPUT_API"
  description             = "AD group for API product related to chain campaign data from SAP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = false
  types                   = ["Unified"]
  mail_enabled            = true
  members                 = []
}
*/

resource "azuread_group" "apim_campaign_app_input_api" {
  display_name            = "${var.prefix_apim_ad_group}_CAMPAIGN_APP_INPUT_API"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_platform.id,
  ]
}

resource "azuread_group" "apim_kruoka_input_api" {
  display_name            = "${var.prefix_apim_ad_group}_KRUOKA_INPUT_API"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_platform.id,
  ]
}

/* GROUP FROM PPM
resource "azuread_group" "apim_kvalikoima_input_api" {
  display_name            = "${var.prefix_apim_ad_group}_KVALIKOIMA_INPUT_API"
  description             = "AD group for APIs related to inputs from K-Valikoima App"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = false
  types                   = ["Unified"]
  mail_enabled            = true
  members                 = []
}
*/

resource "azuread_group" "apim_neste_input_api" {
  display_name            = "${var.prefix_apim_ad_group}_NESTE_INPUT_API"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_platform.id,
  ]
}

/* GROUP FROM PPM
resource "azuread_group" "apim_pxm_gtpim_input_api" {
  display_name            = "${var.prefix_apim_ad_group}_PXM_GTPIM_INPUT_API"
  description             = "AD group for KDATA API products related to PxM inputs"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = false
  types                   = ["Unified"]
  mail_enabled            = true
  members                 = []
}
*/

resource "azuread_group" "apim_eslist_app_output_api" {
  display_name            = "${var.prefix_apim_ad_group}_ESLIST_APP_OUTPUT_API"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_platform.id,
    data.azuread_group.ppm_devops_or.id
  ]
}

/* GROUP FROM PPM
resource "azuread_group" "apim_gtsap_qm_image_api" {
  display_name            = "${var.prefix_apim_ad_group}_GTSAP_QM_IMAGE_API"
  description             = "AD group for API product related to QM data from SAP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = false
  types                   = ["Unified"]
  mail_enabled            = true
  members                 = []
}
*/

resource "azuread_group" "apim_zetes_image_api" {
  display_name            = "${var.prefix_apim_ad_group}_ZETES_IMAGE_API"
  description             = "This production group is for subscribing to KDATA API for Integrating with Medea."
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    "2750b6be-49f6-40c3-9b21-2a1ad4cd0b60",
    data.azuread_group.ppm_devops_platform.id,
  ]
}

resource "azuread_group" "apim_konvehti_api" {
  display_name            = "${var.prefix_apim_ad_group}_KONVEHTI_API"
  owners                  = local.owners
  prevent_duplicate_names = false
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_platform.id,
  ]
}

resource "azuread_group" "apim_valvira_api" {
  display_name            = "${var.prefix_apim_ad_group}_VALVIRA_API"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_platform.id,
  ]
}

resource "azuread_group" "apim_kafkaproxy_inbound_api" {
  display_name            = "${var.prefix_apim_ad_group}_KAFKAPROXY_INBOUND_API"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_platform.id,
  ]
}

resource "azuread_group" "apim_labvantage_api" {
  display_name            = "${var.prefix_apim_ad_group}_LABVANTAGE_API"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_platform.id,
  ]
}
