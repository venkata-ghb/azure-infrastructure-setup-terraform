resource "azuread_group" "sf_data_bus_gt_dagmar" {
  display_name            = "KDATA_KSNOW_PROD_DATA_BUS_GT_DAGMAR"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
}

# This group is to add memebers into snowflake dais sandbox for ekai app
resource "azuread_group" "sf_app_ekai_poc" {
  display_name            = "KDATA_KSNOW_PROD_APP_POC_EKAI"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
}

# This group is for members from AI Solutions accessing snowflake 
resource "azuread_group" "sf_app_ais" {
  display_name            = "KDATA_KSNOW_PROD_AIS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
}