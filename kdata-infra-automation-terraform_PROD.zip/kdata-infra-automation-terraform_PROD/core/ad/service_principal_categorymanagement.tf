# ---------------------------------------------------------------------------------------------
# catman-adb
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "catman_adb" {
  display_name = "${var.prefix_sp}-catman-adb-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "catman_adb" {
  application_id = azuread_application.catman_adb.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "catman_adb" {
  service_principal_id = azuread_service_principal.catman_adb.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}
