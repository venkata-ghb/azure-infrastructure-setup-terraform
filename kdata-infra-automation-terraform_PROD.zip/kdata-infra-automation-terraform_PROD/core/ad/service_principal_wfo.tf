# ---------------------------------------------------------------------------------------------
# wfo-edw
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "wfo_edw" {
  display_name = "${var.prefix_sp}-wfo-edw-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "wfo_edw" {
  application_id = azuread_application.wfo_edw.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "wfo_edw" {
  service_principal_id = azuread_service_principal.wfo_edw.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}
