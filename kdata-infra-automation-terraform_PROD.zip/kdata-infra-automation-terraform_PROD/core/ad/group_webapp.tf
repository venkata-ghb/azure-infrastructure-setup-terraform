resource "azuread_group" "genaiapp_gt_bus_marketing" {
  display_name            = "KDATA_PROD_GENAIAPP_GT_BUS_MARKETING"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true

  lifecycle {
    ignore_changes = [members]
  }
}

resource "azuread_group" "genaiapp_gt_bus_productdata" {
  display_name            = "KDATA_PROD_GENAIAPP_GT_BUS_PRODUCTDATA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true

  lifecycle {
    ignore_changes = [members]
  }
}

resource "azuread_group" "genaiapp_com_bus_contractcenter" {
  display_name            = "KDATA_PROD_GENAIAPP_COM_BUS_CONTRACTCENTER"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true

  lifecycle {
    ignore_changes = [members]
  }
}

