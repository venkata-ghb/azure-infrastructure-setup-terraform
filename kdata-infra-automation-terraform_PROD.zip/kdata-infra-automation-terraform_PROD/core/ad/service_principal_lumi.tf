# ---------------------------------------------------------------------------------------------
# lumi-devops
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "lumi_devops" {
  display_name = "${var.prefix_sp}-lumi-devops-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_application_federated_identity_credential" "lumi_devops-azdevops" {
  application_object_id = azuread_application.lumi_devops.id
  display_name          = "azdevops"
  description           = "Deployments from Azure DevOps"
  audiences             = ["api://AzureADTokenExchange"]
  issuer                = "https://vstoken.dev.azure.com/bd9fc972-b912-44b5-a119-4ef333236514"
  subject               = "sc://KeskoDevOps/LUMI/${azuread_application.lumi_devops.display_name}"
}

resource "azuread_service_principal" "lumi_devops" {
  application_id = azuread_application.lumi_devops.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}
/*
resource "azuread_service_principal_password" "lumi_devops" {
  service_principal_id = azuread_service_principal.lumi_devops.id
  end_date             = var.pwd_expr_date
}
*/

# ---------------------------------------------------------------------------------------------
# lumi-adb
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "lumi_adb" {
  display_name = "${var.prefix_sp}-lumi-adb-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "lumi_adb" {
  application_id = azuread_application.lumi_adb.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "lumi_adb" {
  service_principal_id = azuread_service_principal.lumi_adb.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}
