# Application for Com GenAI Contract Center application SSO
resource "azuread_application" "kgenaicontractcenter" {
    display_name            = "Kesko GenAI Contract Center"
    owners                  = local.owners
    prevent_duplicate_names = true

    lifecycle { ignore_changes = [api, web, optional_claims, group_membership_claims, 
    required_resource_access, identifier_uris, single_page_application, ] }

}

resource "azuread_service_principal" "kgenaicontractcenter" {
  application_id = azuread_application.kgenaicontractcenter.application_id
  owners         = local.owners
  tags           = ["WindowsAzureActiveDirectoryIntegratedApp"]
}

# Password for service principal
resource "azuread_service_principal_password" "kgenaicontractcenter" {
  service_principal_id = azuread_service_principal.kgenaicontractcenter.id
  end_date             = var.pwd_expr_date_crit2
  display_name         = "primary"
}

# Application for Com GenAI Contract Center CRUDs from APIM to BE app
resource "azuread_application" "kgenaicontractcenter_crud" {
    display_name            = "kdata-prod-kgenaicontractcenter-crud-sp"
    owners                  = local.owners
    prevent_duplicate_names = true

    api {
      known_client_applications      = []
      mapped_claims_enabled          = false
      requested_access_token_version = 2
    }
}

resource "azuread_service_principal" "kgenaicontractcenter_crud" {
  application_id = azuread_application.kgenaicontractcenter_crud.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

# Password for service principal
resource "azuread_service_principal_password" "kgenaicontractcenter_crud" {
  service_principal_id = azuread_service_principal.kgenaicontractcenter_crud.id
  end_date             = var.pwd_expr_date_crit2
  display_name         = "primary"
}

# Sharepoint Graph api access
resource "azuread_application" "kgenaicontractcenter_sharepoint" {
    display_name            = "kdata-prod-kgenaicontractcenter-sharepoint-sp"
    owners                  = local.owners
    prevent_duplicate_names = true

    lifecycle { ignore_changes = [api, web, required_resource_access, optional_claims, group_membership_claims, 
    identifier_uris, single_page_application, ] }

}

resource "azuread_service_principal" "kgenaicontractcenter_sharepoint" {
  application_id = azuread_application.kgenaicontractcenter_sharepoint.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "kgenaicontractcenter_sharepoint" {
  service_principal_id = azuread_service_principal.kgenaicontractcenter_sharepoint.id
  end_date             = var.pwd_expr_date_crit2
  display_name         = "primary"
}
