# ---------------------------------------------------------------------------------------------
# or-terraform
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "or_terraform" {
  display_name = "${var.prefix_sp}-terraform-sp"
  owners       = local.owners

  required_resource_access {
    resource_app_id = "00000002-0000-0000-c000-000000000000"
    resource_access {
      id   = "311a71cc-e848-46a1-bdf8-97ff7156d8e6"
      type = "Scope"
    }
    resource_access {
      id   = "a42657d6-7f20-40e3-b6f0-cee03008a62a"
      type = "Scope"
    }
  }

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "or_terraform" {
  application_id = azuread_application.or_terraform.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "or_terraform" {
  service_principal_id = azuread_service_principal.or_terraform.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}

# ---------------------------------------------------------------------------------------------
# or-azdevops
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "or_azdevops" {
  display_name = "${var.prefix_sp}-azdevops-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "or_azdevops" {
  application_id = azuread_application.or_azdevops.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "or_azdevops" {
  service_principal_id = azuread_service_principal.or_azdevops.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}

# ---------------------------------------------------------------------------------------------
# or-bookkeeping
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "or_bookkeeping" {
  display_name = "${var.prefix_sp}-bookkeeping-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "or_bookkeeping" {
  application_id = azuread_application.or_bookkeeping.application_id
  owners         = local.owners
  tags           = ["WindowsAzureActiveDirectoryIntegratedApp", "HideApp"]
}

resource "azuread_service_principal_password" "or_bookkeeping" {
  service_principal_id = azuread_service_principal.or_bookkeeping.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}

# ---------------------------------------------------------------------------------------------
# or-etl
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "or_etl" {
  display_name = "${var.prefix_sp}-etl-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "or_etl" {
  application_id = azuread_application.or_etl.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "or_etl" {
  service_principal_id = azuread_service_principal.or_etl.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}

# ---------------------------------------------------------------------------------------------
# or-tobtrack
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "or_tobtrack" {
  display_name = "${var.prefix_sp}-tobtrack-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "or_tobtrack" {
  application_id = azuread_application.or_tobtrack.application_id
  owners         = local.owners
  tags           = ["WindowsAzureActiveDirectoryIntegratedApp", "HideApp"]
}

resource "azuread_service_principal_password" "or_tobtrack" {
  service_principal_id = azuread_service_principal.or_tobtrack.id
  end_date             = var.pwd_expr_date_crit2
  display_name         = "primary"
}

# ---------------------------------------------------------------------------------------------
# or-datapower
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "or_datapower" {
  display_name = "${var.prefix_sp}-datapower-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "or_datapower" {
  application_id = azuread_application.or_datapower.application_id
  owners         = local.owners
  tags           = ["WindowsAzureActiveDirectoryIntegratedApp", "HideApp"]
}

resource "azuread_service_principal_password" "or_datapower" {
  service_principal_id = azuread_service_principal.or_datapower.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}

# ---------------------------------------------------------------------------------------------
# or-robot
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "or_robot" {
  display_name = "${var.prefix_sp}-robot-sp"
  owners       = local.owners

  required_resource_access {
    resource_app_id = "00000002-0000-0000-c000-000000000000"

    resource_access {
      id   = "311a71cc-e848-46a1-bdf8-97ff7156d8e6"
      type = "Scope"
    }
  }
  required_resource_access {
    resource_app_id = "797f4846-ba00-4fd7-ba43-dac1f8f63013"

    resource_access {
      id   = "41094075-9dad-400e-a0bd-54e686782033"
      type = "Scope"
    }
  }
  required_resource_access {
    resource_app_id = "e9f49c6b-5ce5-44c8-925d-015017e9f7ad"

    resource_access {
      id   = "9f15d22d-3cdf-430f-ba48-f75401c0408e"
      type = "Scope"
    }
  }

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "or_robot" {
  application_id = azuread_application.or_robot.application_id
  owners         = local.owners
  tags           = ["WindowsAzureActiveDirectoryIntegratedApp", "HideApp"]
}

resource "azuread_service_principal_password" "or_robot" {
  service_principal_id = azuread_service_principal.or_robot.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}

# ---------------------------------------------------------------------------------------------
# or-edw
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "or_edw" {
  display_name = "${var.prefix_sp}-edw-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "or_edw" {
  application_id = azuread_application.or_edw.application_id
  owners         = local.owners
  tags           = ["WindowsAzureActiveDirectoryIntegratedApp", "HideApp"]
}

resource "azuread_service_principal_password" "or_edw" {
  service_principal_id = azuread_service_principal.or_edw.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}

# ---------------------------------------------------------------------------------------------
# or-lastdaysales
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "or_lastdaysales" {
  display_name = "${var.prefix_sp}-lastdaysales-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "or_lastdaysales" {
  application_id = azuread_application.or_lastdaysales.application_id
  owners         = local.owners
  tags           = ["WindowsAzureActiveDirectoryIntegratedApp", "HideApp"]
}

resource "azuread_service_principal_password" "or_lastdaysales" {
  service_principal_id = azuread_service_principal.or_lastdaysales.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}

# ---------------------------------------------------------------------------------------------
# or-plussa
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "or_plussa" {
  display_name = "${var.prefix_sp}-plussa-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "or_plussa" {
  application_id = azuread_application.or_plussa.application_id
  owners         = local.owners
  tags           = ["WindowsAzureActiveDirectoryIntegratedApp", "HideApp"]
}

resource "azuread_service_principal_password" "or_plussa" {
  service_principal_id = azuread_service_principal.or_plussa.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}

# ---------------------------------------------------------------------------------------------
# or-selfsupervision
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "or_selfsupervision" {
  display_name = "${var.prefix_sp}-selfsupervision-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "or_selfsupervision" {
  application_id = azuread_application.or_selfsupervision.application_id
  owners         = local.owners
  tags           = ["WindowsAzureActiveDirectoryIntegratedApp", "HideApp"]
}

resource "azuread_service_principal_password" "or_selfsupervision" {
  service_principal_id = azuread_service_principal.or_selfsupervision.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}

# ---------------------------------------------------------------------------------------------
# or-kai
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "or_kai" {
  display_name = "${var.prefix_sp}-kai-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "or_kai" {
  application_id = azuread_application.or_kai.application_id
  owners         = local.owners
  tags           = ["WindowsAzureActiveDirectoryIntegratedApp", "HideApp"]
}

resource "azuread_service_principal_password" "or_kai" {
  service_principal_id = azuread_service_principal.or_kai.id
  end_date             = var.pwd_expr_date_crit2
  display_name         = "primary_kai"
}

# ---------------------------------------------------------------------------------------------
# or-nestedayend
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "or_nestedayend" {
  display_name = "${var.prefix_sp}-nestedayend-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "or_nestedayend" {
  application_id = azuread_application.or_nestedayend.application_id
  owners         = local.owners
  tags           = ["WindowsAzureActiveDirectoryIntegratedApp", "HideApp"]
}

resource "azuread_service_principal_password" "or_nestedayend" {
  service_principal_id = azuread_service_principal.or_nestedayend.id
  end_date             = var.pwd_expr_date_crit2
  display_name         = "primary"
}

# ---------------------------------------------------------------------------------------------
# or-b2bdr
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "or_b2bdr" {
  display_name = "${var.prefix_sp}-b2bdr-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "or_b2bdr" {
  application_id = azuread_application.or_b2bdr.application_id
  owners         = local.owners
  tags           = ["WindowsAzureActiveDirectoryIntegratedApp", "HideApp"]
}

resource "azuread_service_principal_password" "or_b2bdr" {
  service_principal_id = azuread_service_principal.or_b2bdr.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}

# ---------------------------------------------------------------------------------------------
# or-match
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "or_match" {
  display_name = "${var.prefix_sp}-match-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "or_match" {
  application_id = azuread_application.or_match.application_id
  owners         = local.owners
  tags           = ["WindowsAzureActiveDirectoryIntegratedApp", "HideApp"]
}

resource "azuread_service_principal_password" "or_match" {
  service_principal_id = azuread_service_principal.or_match.id
  end_date             = var.pwd_expr_date_crit2
  display_name         = "primary"
}

# ---------------------------------------------------------------------------------------------
# or-dbmaintenance
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "or_dbmaintenance" {
  display_name = "${var.prefix_sp}-dbmaintenance-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "or_dbmaintenance" {
  application_id = azuread_application.or_dbmaintenance.application_id
  owners         = local.owners
  tags           = ["WindowsAzureActiveDirectoryIntegratedApp", "HideApp"]
}

resource "azuread_service_principal_password" "or_dbmaintenance" {
  service_principal_id = azuread_service_principal.or_dbmaintenance.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}

# ---------------------------------------------------------------------------------------------
# or-deltalake
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "or_deltalake" {
  display_name = "${var.prefix_sp}-or-deltalake-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "or_deltalake" {
  application_id = azuread_application.or_deltalake.application_id
  owners         = local.owners
  tags           = ["WindowsAzureActiveDirectoryIntegratedApp", "HideApp"]
}

resource "azuread_service_principal_password" "or_deltalake" {
  service_principal_id = azuread_service_principal.or_deltalake.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}

# ---------------------------------------------------------------------------------------------
# or-companyinfo
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "or_companyinfo" {
  display_name = "${var.prefix_sp}-companyinfo-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "or_companyinfo" {
  application_id = azuread_application.or_companyinfo.application_id
  owners         = local.owners
  tags           = ["WindowsAzureActiveDirectoryIntegratedApp", "HideApp"]
}

resource "azuread_service_principal_password" "or_companyinfo" {
  service_principal_id = azuread_service_principal.or_companyinfo.id
  end_date             = var.pwd_expr_date_crit2
  display_name         = "primary"
}

# ---------------------------------------------------------------------------------------------
# or-konvehti-fe
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "or_konvehti_fe" {
  display_name = "${var.prefix_sp}-konvehti-fe-sp"
  owners       = local.owners

  api {
    known_client_applications      = []
    mapped_claims_enabled          = false
    requested_access_token_version = 1

    oauth2_permission_scope {
      admin_consent_description  = "Allow the application to access kdata-prod-konvehti-fe-sp on behalf of the signed-in user."
      admin_consent_display_name = "Access kdata-prod-konvehti-fe-sp"
      enabled                    = true
      id                         = "90c33ecc-e85f-4fe5-ba2f-3031d6a3b46b"
      type                       = "User"
      user_consent_description   = "Allow the application to access kdata-prod-konvehti-fe-sp on your behalf."
      user_consent_display_name  = "Access kdata-prod-konvehti-fe-sp"
      value                      = "user_impersonation"
    }
  }

  required_resource_access {
    resource_app_id = "00000003-0000-0000-c000-000000000000"

    resource_access {
      id   = "14dad69e-099b-42c9-810b-d002981feec1"
      type = "Scope"
    }
    resource_access {
      id   = "37f7f235-527c-4136-accd-4a02d197296e"
      type = "Scope"
    }
  }

  required_resource_access {
    resource_app_id = "0d00cf1e-731f-4558-8df3-f9efe6b40a27"

    resource_access {
      id   = "7e5a1e6f-2201-4042-bb4a-8df7a960e556"
      type = "Scope"
    }
  }

  web {
    homepage_url  = "https://kdprodwekonvehtife.azureedge.net/"
    redirect_uris = ["https://kdprodwekonvehtife.azureedge.net/","https://kdprodwekonvehtife-bdfwhyehd9c5gqg3.a01.azurefd.net/"]
    implicit_grant {
      access_token_issuance_enabled = true
      id_token_issuance_enabled     = true
    }
  }
}

resource "azuread_service_principal" "or_konvehti_fe" {
  application_id = azuread_application.or_konvehti_fe.application_id
  owners         = local.owners
  tags           = ["WindowsAzureActiveDirectoryIntegratedApp", "HideApp"]
}

resource "azuread_service_principal_password" "or_konvehti_fe" {
  display_name         = "primary"
  service_principal_id = azuread_service_principal.or_konvehti_fe.id
  end_date             = var.pwd_expr_date_crit2
}


# ---------------------------------------------------------------------------------------------
# or-flywaysql
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "or_flyway_sql" {
  display_name = "${var.prefix_sp}-flyway-sql-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "or_flyway_sql" {
  application_id = azuread_application.or_flyway_sql.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "or_flyway_sql" {
  service_principal_id = azuread_service_principal.or_flyway_sql.id
  end_date             = var.pwd_expr_date_crit2
  display_name         = "primary"
}

# ---------------------------------------------------------------------------------------------
# or-app
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "or_app" {
  display_name = "${var.prefix_sp}-or-app-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "or_app" {
  application_id = azuread_application.or_app.application_id
  owners         = local.owners
  description    = "Generic Orders & Receipts service principal"
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "or_app" {
  service_principal_id = azuread_service_principal.or_app.id
  end_date             = var.pwd_expr_date_crit2
  display_name         = "primary"
}
