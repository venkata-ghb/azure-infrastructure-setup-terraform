# ====================================================
# Contains Data Lake related AD groups               #
# ====================================================
/**
Usage:
1. Creating new system group (root level access enabler)

System level AD groups grant access for source level groups to the root level of data lake
System level AD groups should contain all source level groups as members for specified zone

e.g. KDATA_PROD_SYS_RAW_NATURAL contains all source level groups for raw zone and natural data

2. Creating new source level groups

Source level groups need to be created for accessing source specific datasets
Groups need to be created on each zone the data is stored in e.g. raw and curated
Access level specific groups need to be created with either R = read or RW = readwrite access (W = write which should be deprecated)
Group needs to be added to corresponding system group

e.g. AZ_KDATA_PROD_RAW_R_NAT_AC is AC source data for AC in raw zone for natural data with read access 

3. Creating new child level groups

Child level groups grant access to specific dataset within source folder.
Child level groups work like source level group with one exception being that it needs parent level read access.
This can be achieved by creating SUBFLD group for parent folder

e.g. AZ_KDATA_PROD_RAW_R_NAT_GTSAP_SUBFLD group is required if GTSAP needs more granular level access for datasets

SUBFLD replaces the system group for child group meaning that child group should not have membership for system groups but instead
to SUBFLD group which should have system group membership

*/

# == System Groups =============================================================================

resource "azuread_group" "dls_sys_raw_natural" {
  display_name            = "KDATA_PROD_SYS_RAW_NATURAL"
  description             = "Needed for assigning access to KDATA for service principals / requested by Sankalp Ahuja 30.7.2019"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_ac_raw_nat_r.id,
    azuread_group.dls_ac_raw_nat_rw.id,
    azuread_group.dls_adfrm_raw_nat_r.id,
    azuread_group.dls_adfrm_raw_nat_w.id,
    azuread_group.dls_adfrm_raw_nat_rw.id,
    azuread_group.dls_apps_raw_nat_r.id,
    azuread_group.dls_apps_raw_nat_w.id,
    azuread_group.dls_apps_raw_nat_rw.id,
    azuread_group.dls_ctchr_raw_nat_r.id,
    azuread_group.dls_ctchr_raw_nat_w.id,
    azuread_group.dls_ctchr_raw_nat_rw.id,
    azuread_group.dls_dgsgn_raw_nat_r.id,
    azuread_group.dls_dgsgn_raw_nat_w.id,
    azuread_group.dls_dgsgn_raw_nat_rw.id,
    azuread_group.dls_gtfr_raw_nat_r.id,
    azuread_group.dls_gtfr_raw_nat_w.id,
    azuread_group.dls_gtfr_raw_nat_rw.id,
    azuread_group.dls_gtfracr_raw_nat_r.id,
    azuread_group.dls_gtfracr_raw_nat_rw.id,
    azuread_group.dls_edw_raw_nat_r.id,
    azuread_group.dls_edw_raw_nat_w.id,
    azuread_group.dls_edw_raw_nat_rw.id,
    azuread_group.dls_edw_subfld_raw_nat_r.id,
    azuread_group.dls_gta2g_raw_nat_r.id,
    azuread_group.dls_gta2g_raw_nat_w.id,
    azuread_group.dls_gta2g_raw_nat_rw.id,
    azuread_group.dls_gtasort_raw_nat_r.id,
    azuread_group.dls_gtasort_raw_nat_w.id,
    azuread_group.dls_gtasort_raw_nat_rw.id,
    azuread_group.dls_gtasort_subfld_raw_nat_r.id,
    azuread_group.dls_gtbw_raw_nat_r.id,
    azuread_group.dls_gtbw_raw_nat_w.id,
    azuread_group.dls_gtbw_raw_nat_rw.id,
    azuread_group.dls_gtkampanjaapp_raw_nat_r.id,
    azuread_group.dls_gtkampanjaapp_raw_nat_w.id,
    azuread_group.dls_gtkampanjaapp_raw_nat_rw.id,
    azuread_group.dls_gtman_raw_nat_r.id,
    azuread_group.dls_gtman_raw_nat_w.id,
    azuread_group.dls_gtman_raw_nat_rw.id,
    azuread_group.dls_gtman_subfld_raw_nat_r.id,
    azuread_group.dls_gtpim_raw_nat_r.id,
    azuread_group.dls_gtpim_raw_nat_w.id,
    azuread_group.dls_gtpim_raw_nat_rw.id,
    azuread_group.dls_gtpos_raw_nat_r.id,
    azuread_group.dls_gtpos_raw_nat_w.id,
    azuread_group.dls_gtpos_raw_nat_rw.id,
    azuread_group.dls_gtpos_subfld_raw_nat_r.id,
    azuread_group.dls_gtsap_raw_nat_r.id,
    azuread_group.dls_gtsap_raw_nat_w.id,
    azuread_group.dls_gtsap_raw_nat_rw.id,
    azuread_group.dls_gtsap_subfld_raw_nat_r.id,
    azuread_group.dls_gtverso_raw_nat_r.id,
    azuread_group.dls_gtverso_raw_nat_w.id,
    azuread_group.dls_gtverso_raw_nat_rw.id,
    azuread_group.dls_gtwfo_raw_nat_r.id,
    azuread_group.dls_gtwfo_raw_nat_w.id,
    azuread_group.dls_gtwfo_raw_nat_rw.id,
    azuread_group.dls_kai_raw_nat_r.id,
    azuread_group.dls_kai_raw_nat_w.id,
    azuread_group.dls_kai_raw_nat_rw.id,
    azuread_group.dls_kfdm_raw_nat_r.id,
    azuread_group.dls_kfdm_raw_nat_w.id,
    azuread_group.dls_kfdm_raw_nat_rw.id,
    azuread_group.dls_kruoka_raw_nat_r.id,
    azuread_group.dls_kruoka_raw_nat_w.id,
    azuread_group.dls_kruoka_raw_nat_rw.id,
    azuread_group.dls_lumi_raw_nat_r.id,
    azuread_group.dls_lumi_raw_nat_w.id,
    azuread_group.dls_lumi_raw_nat_rw.id,
    azuread_group.dls_lumi_subfld_raw_nat_r.id,
    azuread_group.dls_neste_raw_nat_r.id,
    azuread_group.dls_neste_raw_nat_w.id,
    azuread_group.dls_neste_raw_nat_rw.id,
    azuread_group.dls_pcm_raw_nat_r.id,
    azuread_group.dls_pcm_raw_nat_w.id,
    azuread_group.dls_pcm_raw_nat_rw.id,
    azuread_group.dls_posti_raw_nat_r.id,
    azuread_group.dls_posti_raw_nat_w.id,
    azuread_group.dls_posti_raw_nat_rw.id,
    azuread_group.dls_rtcom_raw_nat_r.id,
    azuread_group.dls_rtcom_raw_nat_w.id,
    azuread_group.dls_rtcom_raw_nat_rw.id,
    azuread_group.dls_rxpos_raw_nat_r.id,
    azuread_group.dls_rxpos_raw_nat_w.id,
    azuread_group.dls_rxpos_raw_nat_rw.id,
    azuread_group.dls_rxsap_raw_nat_r.id,
    azuread_group.dls_rxsap_raw_nat_w.id,
    azuread_group.dls_rxsap_raw_nat_rw.id,
    azuread_group.dls_slfrc_raw_nat_r.id,
    azuread_group.dls_slfrc_raw_nat_w.id,
    azuread_group.dls_slfrc_raw_nat_rw.id,
    azuread_group.dls_tbtrk_raw_nat_r.id,
    azuread_group.dls_tbtrk_raw_nat_w.id,
    azuread_group.dls_tbtrk_raw_nat_rw.id,
    azuread_group.dls_tdmigration_raw_nat_r.id,
    azuread_group.dls_tdmigration_raw_nat_w.id,
    azuread_group.dls_tdmigration_raw_nat_rw.id,
    azuread_group.dls_teradata_raw_nat_r.id,
    azuread_group.dls_teradata_raw_nat_w.id,
    azuread_group.dls_teradata_raw_nat_rw.id,
    azuread_group.dls_tos_raw_nat_r.id,
    azuread_group.dls_tos_raw_nat_w.id,
    azuread_group.dls_tos_raw_nat_rw.id,
    azuread_group.dls_zetes_raw_nat_r.id,
    azuread_group.dls_zetes_raw_nat_w.id,
    azuread_group.dls_zetes_raw_nat_rw.id,
    azuread_group.dls_prides_raw_nat_r.id,
    azuread_group.dls_prides_raw_nat_w.id,
    azuread_group.dls_prides_raw_nat_rw.id,
    azuread_group.dls_gtsapacr_raw_nat_r.id,
    azuread_group.dls_gtsapacr_raw_nat_w.id,
    azuread_group.dls_gtsapacr_raw_nat_rw.id,
    azuread_group.dls_clm_raw_nat_r.id,
    azuread_group.dls_clm_raw_nat_rw.id,
    azuread_group.dls_clm_subfld_raw_nat_r.id,
    azuread_group.dls_descartes_raw_nat_r.id,
    azuread_group.dls_descartes_raw_nat_w.id,
    azuread_group.dls_descartes_raw_nat_rw.id,
    azuread_group.dls_kerays_raw_nat_r.id,
    azuread_group.dls_kerays_raw_nat_w.id,
    azuread_group.dls_kerays_raw_nat_rw.id,
    azuread_group.dls_snowedw_raw_nat_r.id,
    azuread_group.dls_snowedw_raw_nat_rw.id,
    azuread_group.dls_bric_raw_nat_r.id,
    azuread_group.dls_bric_raw_nat_rw.id,
    "0a26757e-b409-4442-bac6-f3f96ac410e0", # TODO: AZ_KDATA_PROD_RAW_RW_NAT_GTMAN_STAGE_RETROBONUS_INPUT_RETAILERS, verify removal
    "1efe51e6-a84f-44f7-a68c-ce18b6149bfb", # TODO: AZ_KDATA_PROD_RAW_R_NAT_GTSAP_CAMPAIGN, verify removal
    "500bfa49-c6b7-4e8e-8e67-4aa2d981add5", # TODO: KDATA_PROD_GT_DL_RAW_GTMAN_STAGE_RETROBONUS_INPUT_VENDORS, verify removal
    data.azuread_service_principal.kcloud_int_funcapp.id,
    "7a1e6c6c-e8c5-4f4c-87d4-e4a9df0bdabd", # TODO: KDATA_PROD_INB_TBTRK, verify removal
    data.azuread_group.ppm_dls_devops_or.id,
    data.azuread_group.ppm_natural_read_gt_tobtrac.id,
    "c120cb14-9f1d-413e-bc44-eb6217e5dfd8", # TODO: AZ_KDATA_PROD_RAW_RW_NAT_GTMAN_STAGE_RETROBONUS_INPUT_VENDORS , verify removal
    "cd573e8f-00d9-4e12-94ca-b440260be11e", # TODO: KDATA_PROD_GT_DL_RAW_GTMAN_STAGE_RETROBONUS_INPUT_RETAILERS, verify removal
    azuread_group.dls_inb_eh.id,
    azuread_group.dls_bigquery_raw_nat_r.id,
    azuread_group.dls_bigquery_raw_nat_rw.id,
    azuread_group.dls_kdam_raw_nat_r.id,
    azuread_group.dls_kdam_raw_nat_rw.id,
    azuread_group.dls_dagmar_raw_nat_r.id,
    azuread_group.dls_dagmar_raw_nat_rw.id,
    azuread_group.dls_cnp_raw_nat_r.id,
    azuread_group.dls_cnp_raw_nat_rw.id,
    azuread_group.dls_tps_raw_nat_rw.id,
    azuread_group.dls_tps_raw_nat_r.id,
    azuread_group.dls_gtkespro_raw_nat_r.id,
    azuread_group.dls_gtkespro_raw_nat_w.id,
    azuread_group.dls_gtkespro_raw_nat_rw.id,
    azuread_group.dls_gtkespro_subfld_raw_nat_r.id,
    azuread_group.dls_semmi_raw_nat_r.id,
    azuread_group.dls_semmi_raw_nat_rw.id,
    azuread_group.dls_konvehti_raw_nat_r.id,
    azuread_group.dls_konvehti_raw_nat_rw.id,
    azuread_group.dls_ktavara_raw_nat_r.id,
    azuread_group.dls_ktavara_raw_nat_rw.id,
    azuread_group.dls_cosmos_raw_nat_r.id,
    azuread_group.dls_cosmos_raw_nat_rw.id,
    azuread_group.dls_valvira_raw_nat_r.id,
    azuread_group.dls_valvira_raw_nat_rw.id,
    azuread_group.dls_kkyla_raw_nat_r.id,
    azuread_group.dls_kkyla_raw_nat_rw.id,
    azuread_group.dls_kpim_raw_nat_rw.id,
    azuread_group.dls_kpim_raw_nat_r.id,
    azuread_group.dls_fmi_raw_nat_r.id,
    azuread_group.dls_fmi_raw_nat_rw.id,
    azuread_group.dls_mintec_raw_nat_r.id,
    azuread_group.dls_mintec_raw_nat_rw.id,
    azuread_group.dls_statfin_raw_nat_r.id,
    azuread_group.dls_statfin_raw_nat_rw.id,
    azuread_group.dls_sisu_raw_nat_r.id,
    azuread_group.dls_sisu_raw_nat_rw.id,
    azuread_group.dls_ctag_raw_nat_r.id,
    azuread_group.dls_ctag_raw_nat_rw.id,
    azuread_group.dls_kesprolaskenta_raw_nat_r.id,
    azuread_group.dls_kesprolaskenta_raw_nat_rw.id,
    azuread_group.dls_ktv_raw_nat_rw.id,
    azuread_group.dls_ktv_raw_nat_r.id,
    azuread_group.dls_webdataga4_raw_nat_r.id,
    azuread_group.dls_webdataga4_raw_nat_rw.id,
    azuread_group.dls_enerkey_raw_nat_r.id,
    azuread_group.dls_enerkey_raw_nat_rw.id,
    azuread_group.dls_kruokakauppa_raw_nat_r.id,
    azuread_group.dls_kruokakauppa_raw_nat_rw.id,
    azuread_group.dls_revit_raw_nat_r.id,
    azuread_group.dls_revit_raw_nat_rw.id,
    azuread_group.dls_sharepoint_raw_nat_r.id,
    azuread_group.dls_sharepoint_raw_nat_rw.id,
    azuread_group.dls_intersport_raw_nat_r.id,
    azuread_group.dls_intersport_raw_nat_rw.id,
    azuread_group.dls_opim_raw_nat_r.id,
    azuread_group.dls_opim_raw_nat_rw.id,
    azuread_group.dls_tekso_raw_nat_r.id,
    azuread_group.dls_tekso_raw_nat_rw.id,
    azuread_group.dls_granlund_raw_nat_r.id,
    azuread_group.dls_granlund_raw_nat_rw.id,
    azuread_group.dls_msax_raw_nat_r.id,
    azuread_group.dls_msax_raw_nat_rw.id,
    azuread_group.dls_competitorprices_raw_nat_r.id,
    azuread_group.dls_competitorprices_raw_nat_rw.id,
    azuread_group.dls_lt_raw_nat_r.id,
    azuread_group.dls_lt_raw_nat_rw.id,
    azuread_group.dls_osap_raw_nat_r.id,
    azuread_group.dls_osap_raw_nat_rw.id,
    azuread_group.dls_cgi_raw_nat_r.id,
    azuread_group.dls_cgi_raw_nat_rw.id,
    azuread_group.dls_mandatum_raw_nat_r.id,
    azuread_group.dls_mandatum_raw_nat_rw.id,
    azuread_group.dls_sapwell_raw_nat_r.id,
    azuread_group.dls_sapwell_raw_nat_r.id,
    azuread_group.dls_crasman_raw_nat_r.id,
    azuread_group.dls_crasman_raw_nat_rw.id,
    azuread_group.dls_relex_raw_nat_r.id,
    azuread_group.dls_relex_raw_nat_rw.id,
    azuread_group.dls_onniaws_raw_nat_r.id,
    azuread_group.dls_onniaws_raw_nat_rw.id,
    azuread_group.dls_logentia_raw_nat_r.id,
    azuread_group.dls_logentia_raw_nat_rw.id,
    azuread_group.dls_bttreceiptarchive_raw_nat_r.id,
    azuread_group.dls_bttreceiptarchive_raw_nat_rw.id,
    azuread_group.dls_kevel_raw_nat_r.id,
    azuread_group.dls_kevel_raw_nat_rw.id,
    azuread_group.dls_luke_raw_nat_r.id,
    azuread_group.dls_luke_raw_nat_rw.id,
    azuread_group.dls_anaplan_raw_nat_r.id,
    azuread_group.dls_anaplan_raw_nat_rw.id,
    azuread_group.dls_onficrm_raw_nat_r.id,
    azuread_group.dls_onficrm_raw_nat_rw.id,
    azuread_group.dls_expana_raw_nat_r.id,
    azuread_group.dls_expana_raw_nat_rw.id,
    azuread_group.dls_kvalikoima_raw_nat_r.id,
    azuread_group.dls_kvalikoima_raw_nat_rw.id,
    azuread_group.dls_ctcdm_raw_nat_r.id,
    azuread_group.dls_ctcdm_raw_nat_rw.id,
    azuread_group.dls_kid_raw_nat_r.id,
    azuread_group.dls_kid_raw_nat_rw.id,
    azuread_group.dls_ssm_raw_nat_r.id,
    azuread_group.dls_ssm_raw_nat_rw.id,
    azuread_group.dls_dms_raw_nat_r.id,
    azuread_group.dls_dms_raw_nat_rw.id,
    azuread_group.dls_ip1_raw_nat_r.id,
    azuread_group.dls_ip1_raw_nat_rw.id,
    azuread_group.dls_vehicledata_raw_nat_r.id,
    azuread_group.dls_vehicledata_raw_nat_rw.id,
    azuread_group.dls_ofp_raw_nat_r.id,
    azuread_group.dls_ofp_raw_nat_rw.id,
    azuread_group.dls_scraper_raw_nat_r.id,
    azuread_group.dls_scraper_raw_nat_rw.id,
    azuread_group.dls_onnimarkkinat_raw_nat_r.id,
    azuread_group.dls_onnimarkkinat_raw_nat_rw.id,
    azuread_group.dls_cmdm_raw_nat_r.id,
    azuread_group.dls_cmdm_raw_nat_rw.id,
    azuread_group.dls_krautakampanjat_raw_nat_r.id,
    azuread_group.dls_krautakampanjat_raw_nat_rw.id,
    azuread_group.dls_hogia_raw_nat_r.id,
    azuread_group.dls_hogia_raw_nat_rw.id,
    azuread_group.dls_platformsrv_raw_nat_r.id,
    azuread_group.dls_platformsrv_raw_nat_rw.id,
    azuread_group.dls_lcs_raw_nat_r.id,
    azuread_group.dls_lcs_raw_nat_rw.id,
    azuread_group.dls_sisuaz_raw_nat_r.id,
    azuread_group.dls_sisuaz_raw_nat_rw.id,
  ]
}

resource "azuread_group" "dls_sys_curated_natural" {
  display_name            = "KDATA_PROD_SYS_CURATED_NATURAL"
  description             = "Needed for assigning access to KDATA for service principals / requested by Sankalp Ahuja 30.7.2019"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_ac_cur_nat_r.id,
    azuread_group.dls_ac_cur_nat_rw.id,
    azuread_group.dls_adfrm_cur_nat_r.id,
    azuread_group.dls_adfrm_cur_nat_w.id,
    azuread_group.dls_adfrm_cur_nat_rw.id,
    azuread_group.dls_apps_cur_nat_r.id,
    azuread_group.dls_apps_cur_nat_w.id,
    azuread_group.dls_apps_cur_nat_rw.id,
    azuread_group.dls_apps_subfld_cur_nat_r.id,
    azuread_group.dls_ctchr_cur_nat_r.id,
    azuread_group.dls_ctchr_cur_nat_w.id,
    azuread_group.dls_ctchr_cur_nat_rw.id,
    azuread_group.dls_ctrds_cur_nat_r.id,
    azuread_group.dls_ctrds_cur_nat_w.id,
    azuread_group.dls_ctrds_cur_nat_rw.id,
    azuread_group.dls_dgsgn_cur_nat_r.id,
    azuread_group.dls_dgsgn_cur_nat_w.id,
    azuread_group.dls_dgsgn_cur_nat_rw.id,
    azuread_group.dls_gtfr_cur_nat_r.id,
    azuread_group.dls_gtfr_cur_nat_w.id,
    azuread_group.dls_gtfr_cur_nat_rw.id,
    azuread_group.dls_gtfracr_cur_nat_r.id,
    azuread_group.dls_gtfracr_cur_nat_rw.id,
    azuread_group.dls_gta2g_cur_nat_r.id,
    azuread_group.dls_gta2g_cur_nat_w.id,
    azuread_group.dls_gta2g_cur_nat_rw.id,
    azuread_group.dls_gtasort_cur_nat_r.id,
    azuread_group.dls_gtasort_cur_nat_w.id,
    azuread_group.dls_gtasort_cur_nat_rw.id,
    azuread_group.dls_gtasort_subfld_cur_nat_r.id,
    azuread_group.dls_gtbw_cur_nat_r.id,
    azuread_group.dls_gtbw_cur_nat_w.id,
    azuread_group.dls_gtbw_cur_nat_rw.id,
    azuread_group.dls_gtkampanjaapp_cur_nat_r.id,
    azuread_group.dls_gtkampanjaapp_cur_nat_w.id,
    azuread_group.dls_gtkampanjaapp_cur_nat_rw.id,
    azuread_group.dls_gtpim_cur_nat_r.id,
    azuread_group.dls_gtpim_cur_nat_w.id,
    azuread_group.dls_gtpim_cur_nat_rw.id,
    azuread_group.dls_gtpos_cur_nat_r.id,
    azuread_group.dls_gtpos_cur_nat_w.id,
    azuread_group.dls_gtpos_cur_nat_rw.id,
    azuread_group.dls_gtpos_subfld_cur_nat_r.id,
    azuread_group.dls_gtsap_cur_nat_r.id,
    azuread_group.dls_gtsap_cur_nat_w.id,
    azuread_group.dls_gtsap_cur_nat_rw.id,
    azuread_group.dls_gtsap_subfld_cur_nat_r.id,
    azuread_group.dls_gtverso_cur_nat_r.id,
    azuread_group.dls_gtverso_cur_nat_w.id,
    azuread_group.dls_gtverso_cur_nat_rw.id,
    azuread_group.dls_gtwfo_cur_nat_r.id,
    azuread_group.dls_gtwfo_cur_nat_w.id,
    azuread_group.dls_gtwfo_cur_nat_rw.id,
    azuread_group.dls_kfdm_cur_nat_r.id,
    azuread_group.dls_kfdm_cur_nat_w.id,
    azuread_group.dls_kfdm_cur_nat_rw.id,
    azuread_group.dls_kruoka_cur_nat_r.id,
    azuread_group.dls_kruoka_cur_nat_w.id,
    azuread_group.dls_kruoka_cur_nat_rw.id,
    azuread_group.dls_neste_cur_nat_r.id,
    azuread_group.dls_neste_cur_nat_w.id,
    azuread_group.dls_neste_cur_nat_rw.id,
    azuread_group.dls_posti_cur_nat_r.id,
    azuread_group.dls_posti_cur_nat_w.id,
    azuread_group.dls_posti_cur_nat_rw.id,
    azuread_group.dls_profx_cur_nat_r.id,
    azuread_group.dls_profx_cur_nat_w.id,
    azuread_group.dls_profx_cur_nat_rw.id,
    azuread_group.dls_rtcom_cur_nat_r.id,
    azuread_group.dls_rtcom_cur_nat_w.id,
    azuread_group.dls_rtcom_cur_nat_rw.id,
    azuread_group.dls_rxpos_cur_nat_r.id,
    azuread_group.dls_rxpos_cur_nat_w.id,
    azuread_group.dls_rxpos_cur_nat_rw.id,
    azuread_group.dls_rxsap_cur_nat_r.id,
    azuread_group.dls_rxsap_cur_nat_w.id,
    azuread_group.dls_rxsap_cur_nat_rw.id,
    azuread_group.dls_slfrc_cur_nat_r.id,
    azuread_group.dls_slfrc_cur_nat_w.id,
    azuread_group.dls_slfrc_cur_nat_rw.id,
    azuread_group.dls_tbtrk_cur_nat_r.id,
    azuread_group.dls_tbtrk_cur_nat_w.id,
    azuread_group.dls_tbtrk_cur_nat_rw.id,
    azuread_group.dls_tos_cur_nat_r.id,
    azuread_group.dls_tos_cur_nat_w.id,
    azuread_group.dls_tos_cur_nat_rw.id,
    azuread_group.dls_clm_cur_nat_r.id,
    azuread_group.dls_clm_cur_nat_rw.id,
    azuread_group.dls_clm_subfld_cur_nat_r.id,
    azuread_group.dls_descartes_cur_nat_r.id,
    azuread_group.dls_descartes_cur_nat_w.id,
    azuread_group.dls_descartes_cur_nat_rw.id,
    azuread_group.dls_kerays_cur_nat_r.id,
    azuread_group.dls_kerays_cur_nat_w.id,
    azuread_group.dls_kerays_cur_nat_rw.id,
    data.azuread_group.ppm_devops_gtpim.id,
    azuread_service_principal.or_deltalake.id,
    data.azuread_group.ppm_dls_devops_or.id,
    azuread_group.dls_inb_eh.id,
    azuread_group.dls_cnp_cur_nat_r.id,
    azuread_group.dls_cnp_cur_nat_rw.id,
    azuread_group.dls_gtkespro_cur_nat_r.id,
    azuread_group.dls_gtkespro_cur_nat_w.id,
    azuread_group.dls_gtkespro_cur_nat_rw.id,
    azuread_group.dls_gtkespro_subfld_cur_nat_r.id,
    azuread_group.dls_gtsapacr_cur_nat_r.id,
    azuread_group.dls_gtsapacr_cur_nat_rw.id,
  ]
}

resource "azuread_group" "dls_sys_awb_gt" {
  display_name            = "KDATA_PROD_SYS_AWB_GT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_adima_common_awb_gt_r.id,
    azuread_group.dls_adima_common_awb_gt_w.id,
    azuread_group.dls_adima_common_awb_gt_rw.id,
    azuread_group.dls_gt_ba_awb_gt_r.id,
    data.azuread_group.ppm_bus_dls_gt_ba.id,
    data.azuread_group.ppm_bus_dls_kdigital.id,
  ]
}

resource "azuread_group" "dls_sys_gold_gt" {
  display_name            = "KDATA_PROD_SYS_GOLD_GT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_kpartner_gld_gt_r.id,
    azuread_group.dls_kpartner_gld_gt_w.id,
    azuread_group.dls_kpartner_gld_gt_rw.id,
    azuread_group.dls_retrobonus_gld_gt_r.id,
    azuread_group.dls_retrobonus_gld_gt_w.id,
    azuread_group.dls_retrobonus_gld_gt_rw.id,
    azuread_group.dls_tos_gld_gt_r.id,
    azuread_group.dls_tos_gld_gt_w.id,
    azuread_group.dls_tos_gld_gt_rw.id,
    azuread_group.dls_gtsap_gld_gt_r.id,
    azuread_group.dls_gtsap_gld_gt_rw.id,
    azuread_group.dls_wms_gld_gt_r.id,
    azuread_group.dls_wms_gld_gt_rw.id,
  ]
}


resource "azuread_group" "dls_sys_export" {
  display_name            = "KDATA_PROD_SYS_EXPORT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_lumi_exports_r.id,
    azuread_group.dls_lumi_exports_rw.id,
    azuread_group.dls_retrobonus_exports_r.id,
    azuread_group.dls_retrobonus_exports_rw.id,
    azuread_group.dls_kbusiness_exports_r.id,
    azuread_group.dls_kbusiness_exports_rw.id,
    azuread_service_principal.wfo_edw.id,
    azuread_service_principal.or_companyinfo.id,
    data.azuread_group.ppm_dls_devops_or.id,
    data.azuread_group.ppm_devops_gtwfo.id,
    "7f2c42fe-b2c5-4168-add3-77451583eaee", # KDATA_PROD_OUTB_B2BODR_OR
    "30252967-88ca-486a-a604-cd136f743a7f", # KDATA_PROD_OUTB_BOOKKEEPING_OR
    "3b9b2bd8-dd94-4086-bd85-45d776c400ea", # KDATA_PROD_OUTB_DATAPOWER_OR
    "a0de7321-c815-43d0-a1c1-bd1a51b88f36", # KDATA_PROD_OUTB_EDW_OR
    "314ee6e3-ab52-4472-8c3a-4efb93ed083b", # KDATA_PROD_OUTB_LASTDAYSALES_OR
    "20f069a0-d701-4a38-8b1d-af4add78ae0a", # KDATA_PROD_OUTB_MATCHEXPORT_OR
    "c3805fe2-dce6-4ffe-8751-65d6af7199a5", # KDATA_PROD_OUTB_OCM_OR
    "28a4c8e0-611d-4150-ae30-22ec8ace9292", # KDATA_PROD_OUTB_PLUSSA_OR
    "5dc68fd9-93ea-40b8-baaf-8585515d93ce", # KDATA_PROD_OUTB_ROBOT_OR
    "913dac54-f0dd-4f5f-9f60-50ffdd016c9d", # KDATA_PROD_OUTB_SELFSUPERVISION_OR
  ]

  lifecycle {
    ignore_changes = [description]
  }
}

# Misc

resource "azuread_group" "dls_inb_eh" {
  display_name            = "KDATA_PROD_INB_EH"
  owners                  = ["776dbadd-06cf-448d-b7ad-60e48a87bf57"]
  description             = "Needed for assigning access to KDATA for service principals / requested by Sankalp Ahuja / yuri.barseghyan@tieto.com 6.8.2019"
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.microsoft_eventhubs.id,
  ]
}

# == Groups =============================================================================
# AC
resource "azuread_group" "dls_ac_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_AC"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_group.ppm_devops_keskodev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_ac_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_AC"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.lumi_adf.id,
  ]
}

resource "azuread_group" "dls_ac_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_AC"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members                 = []
}

resource "azuread_group" "dls_ac_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_AC"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# ADFRM
resource "azuread_group" "dls_adfrm_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_ADFRM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_0518.id,
    data.azuread_group.ppm_devops_solitadev.id,
  ]
}

resource "azuread_group" "dls_adfrm_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_ADFRM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_adfrm_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_ADFRM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.attrbmodeling_adfrm.id,
  ]
}

resource "azuread_group" "dls_adfrm_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_ADFRM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_adfrm_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_ADFRM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_adfrm_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_ADFRM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.attrbmodeling_adfrm.id
  ]
}

# =======================================================================================
# ADIMA_COMMON
resource "azuread_group" "dls_adima_common_awb_gt_r" {
  display_name            = "${var.prefix_ad_group}_AWB_R_GT_ADIMA_COMMON"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_adima_common_awb_gt_w" {
  display_name            = "${var.prefix_ad_group}_AWB_W_GT_ADIMA_COMMON"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_adima_common_awb_gt_rw" {
  display_name            = "${var.prefix_ad_group}_AWB_RW_GT_ADIMA_COMMON"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.retrobonus_adb.id,
  ]
}

# =======================================================================================
# APPS
resource "azuread_group" "dls_apps_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_APPS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_apps_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_APPS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_apps_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_APPS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_apps_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_APPS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_bus_dls_gt_ba.id,
    data.azuread_group.ppm_devops_gtvalikoima.id,
    azuread_service_principal.kvalikoima_databricks.id,
    azuread_service_principal.gtanalytics_adb.id,
    data.azuread_service_principal.ktv_adf.id,
  ]
}

resource "azuread_group" "dls_apps_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_APPS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_apps_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_APPS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.catman_adb.id,
  ]
}

# =======================================================================================
# APPS_SUBFLD
resource "azuread_group" "dls_apps_subfld_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_APPS_SUBFLD"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_apps_vendorproductretailsale_cur_nat_r.id,
    azuread_group.dls_apps_vendorproductretailsale_cur_nat_w.id,
    azuread_group.dls_apps_vendorproductretailsale_cur_nat_rw.id,
  ]
}

# APPS_VENDORPRODUCTRETAILSALE
resource "azuread_group" "dls_apps_vendorproductretailsale_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_APPS_VENDORPRODUCTRETAILSALE"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_apps_vendorproductretailsale_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_APPS_VENDORPRODUCTRETAILSALE"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_apps_vendorproductretailsale_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_APPS_VENDORPRODUCTRETAILSALE"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.gtkpartner_adb.id,
  ]
}

# =======================================================================================
# CTCHR
resource "azuread_group" "dls_ctchr_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_CTCHR"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_bus_dls_kdigital.id,
    data.azuread_group.ppm_dls_devops_or.id,
  ]
}

resource "azuread_group" "dls_ctchr_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_CTCHR"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_ctchr_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_CTCHR"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_inb_eh.id,
  ]
}

resource "azuread_group" "dls_ctchr_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_CTCHR"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_dls_devops_or.id,
  ]
}

resource "azuread_group" "dls_ctchr_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_CTCHR"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_ctchr_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_CTCHR"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_inb_eh.id,
  ]
}

# =======================================================================================
# CTRDS
resource "azuread_group" "dls_ctrds_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_CTRDS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_dls_devops_or.id,
  ]
}

resource "azuread_group" "dls_ctrds_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_CTRDS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members                 = []
}

resource "azuread_group" "dls_ctrds_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_CTRDS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_inb_eh.id,
  ]
}

# =======================================================================================
# DGSGN
resource "azuread_group" "dls_dgsgn_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_DGSGN"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_platform.id,
    azuread_service_principal.or_kai.id,
    azuread_service_principal.qlik_gt.id,
    azuread_service_principal.gtkpartner_adb.id,
    azuread_service_principal.ds_deltalake.id,
    data.azuread_service_principal.snowflake_0518.id,
    data.azuread_group.ppm_devops_solitadev.id,
  ]
}

resource "azuread_group" "dls_dgsgn_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_DGSGN"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_dgsgn_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_DGSGN"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.ds_deltalake.id,
  ]
}

resource "azuread_group" "dls_dgsgn_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_DGSGN"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_platform.id,
    azuread_service_principal.or_kai.id,
    azuread_service_principal.qlik_gt.id,
    azuread_service_principal.gtanalytics_adb.id,
    azuread_service_principal.gtkpartner_adb.id,
    azuread_service_principal.ds_deltalake.id,
  ]
}

resource "azuread_group" "dls_dgsgn_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_DGSGN"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_dgsgn_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_DGSGN"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.ds_deltalake.id,
  ]
}

# =======================================================================================
# GTFR
resource "azuread_group" "dls_gtfr_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTFR"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.gtkpartner_adb.id,
  ]
}

resource "azuread_group" "dls_gtfr_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTFR"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtfr_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTFR"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_platform.id,
  ]
}

resource "azuread_group" "dls_gtfr_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTFR"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_platform.id,
  ]
}

resource "azuread_group" "dls_gtfr_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTFR"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtfr_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTFR"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# GTFRACR
resource "azuread_group" "dls_gtfracr_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTFRACR"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.gtanalytics_adb.id,
    azuread_service_principal.gtkpartner_adb.id,
    data.azuread_group.ppm_bus_dls_gt_ba.id,
    azuread_service_principal.catman_adb.id,
    data.azuread_service_principal.snowflake_0518.id,
    data.azuread_group.ppm_devops_solitadev.id,
  ]
}

resource "azuread_group" "dls_gtfracr_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTFRACR"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.aecorsoft_sink.id,
    data.azuread_group.ppm_devops_platform.id,
  ]
}

resource "azuread_group" "dls_gtfracr_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTFRACR"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtfracr_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTFRACR"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# EDW
resource "azuread_group" "dls_edw_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_EDW"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.retrobonus_adb.id,
    data.azuread_group.ppm_bus_dls_gt_ba.id,
    data.azuread_group.ppm_bus_dls_kdigital.id,
    azuread_service_principal.gtanalytics_adb.id,
    azuread_service_principal.gtkpartner_adb.id,
    azuread_service_principal.ds_deltalake.id,
  ]
}

resource "azuread_group" "dls_edw_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_EDW"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_edw_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_EDW"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.kvalikoima_dbwrite.id,
  ]
}

# ---------------------------------------------------------------------------------------
# EDW_CommonKF
resource "azuread_group" "dls_edw_commonkf_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_EDW_COMMONKF"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.kvalikoima_databricks.id,
  ]
}

resource "azuread_group" "dls_edw_commonkf_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_EDW_COMMONKF"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_edw_commonkf_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_EDW_COMMONKF"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# EDW_SLACCOUNT
resource "azuread_group" "dls_edw_slaccount_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_EDW_SLACCOUNT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.kvalikoima_databricks.id,
  ]
}

resource "azuread_group" "dls_edw_slaccount_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_EDW_SLACCOUNT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_edw_slaccount_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_EDW_SLACCOUNT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# EDW_SLCA
resource "azuread_group" "dls_edw_slca_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_EDW_SLCA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.kvalikoima_databricks.id,
    azuread_service_principal.catman_adb.id,
  ]
}

resource "azuread_group" "dls_edw_slca_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_EDW_SLCA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_edw_slca_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_EDW_SLCA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# EDW_SLGT
resource "azuread_group" "dls_edw_slgt_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_EDW_SLGT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_edw_slgt_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_EDW_SLGT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_edw_slgt_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_EDW_SLGT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# EDW_SLCOMMON
resource "azuread_group" "dls_edw_slcommon_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_EDW_SLCOMMON"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_edw_slcommon_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_EDW_SLCOMMON"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_edw_slcommon_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_EDW_SLCOMMON"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# EDW_SLORGANIZATION
resource "azuread_group" "dls_edw_slorganization_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_EDW_SLORGANIZATION"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.kvalikoima_databricks.id,
    azuread_service_principal.catman_adb.id,
  ]
}

resource "azuread_group" "dls_edw_slorganization_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_EDW_SLORGANIZATION"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_edw_slorganization_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_EDW_SLORGANIZATION"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# EDW_SLPRODUCT
resource "azuread_group" "dls_edw_slproduct_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_EDW_SLPRODUCT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.kvalikoima_databricks.id,
    azuread_service_principal.catman_adb.id,
  ]
}

resource "azuread_group" "dls_edw_slproduct_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_EDW_SLPRODUCT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_edw_slproduct_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_EDW_SLPRODUCT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# EDW_SLCUSTOMER
resource "azuread_group" "dls_edw_slcustomer_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_EDW_SLCUSTOMER"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_edw_slcustomer_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_EDW_SLCUSTOMER"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_edw_slcustomer_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_EDW_SLCUSTOMER"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# EDW_SUBFLD
resource "azuread_group" "dls_edw_subfld_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_EDW_SUBFLD"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_edw_slcustomer_raw_nat_r.id,
    azuread_group.dls_edw_slcustomer_raw_nat_w.id,
    azuread_group.dls_edw_slcustomer_raw_nat_rw.id,
    azuread_group.dls_edw_slproduct_raw_nat_r.id,
    azuread_group.dls_edw_slproduct_raw_nat_w.id,
    azuread_group.dls_edw_slproduct_raw_nat_rw.id,
    azuread_group.dls_edw_slorganization_raw_nat_r.id,
    azuread_group.dls_edw_slorganization_raw_nat_w.id,
    azuread_group.dls_edw_slorganization_raw_nat_rw.id,
    azuread_group.dls_edw_slcommon_raw_nat_r.id,
    azuread_group.dls_edw_slcommon_raw_nat_w.id,
    azuread_group.dls_edw_slcommon_raw_nat_rw.id,
    azuread_group.dls_edw_slgt_raw_nat_r.id,
    azuread_group.dls_edw_slgt_raw_nat_w.id,
    azuread_group.dls_edw_slgt_raw_nat_rw.id,
    azuread_group.dls_edw_slca_raw_nat_r.id,
    azuread_group.dls_edw_slca_raw_nat_w.id,
    azuread_group.dls_edw_slca_raw_nat_rw.id,
    azuread_group.dls_edw_slaccount_raw_nat_r.id,
    azuread_group.dls_edw_slaccount_raw_nat_w.id,
    azuread_group.dls_edw_slaccount_raw_nat_rw.id,
    azuread_group.dls_edw_commonkf_raw_nat_r.id,
    azuread_group.dls_edw_commonkf_raw_nat_w.id,
    azuread_group.dls_edw_commonkf_raw_nat_rw.id,
  ]
}

# =======================================================================================
# GTA2G
resource "azuread_group" "dls_gta2g_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTA2G"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_bus_dls_gt_ba.id,
    azuread_service_principal.gtanalytics_adb.id,
    azuread_service_principal.kvalikoima_databricks.id,
    data.azuread_group.ppm_devops_gtvalikoima.id,
  ]
}

resource "azuread_group" "dls_gta2g_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTA2G"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gta2g_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTA2G"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.catman_adb.id,
  ]
}

resource "azuread_group" "dls_gta2g_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTA2G"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.kvalikoima_databricks.id,
    data.azuread_group.ppm_bus_dls_gt_ba.id,
    data.azuread_group.ppm_bus_dls_kdigital.id,
    azuread_service_principal.qlik_gt.id,
    azuread_service_principal.gtanalytics_adb.id,
    data.azuread_service_principal.ktv_adf.id,
    data.azuread_group.ppm_devops_gtvalikoima.id,
  ]
}

resource "azuread_group" "dls_gta2g_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTA2G"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gta2g_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTA2G"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.catman_adb.id,
  ]
}

# =======================================================================================
# GTASORT
resource "azuread_group" "dls_gtasort_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTASORT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.or_kai.id,
    azuread_service_principal.kvalikoima_dbwrite.id,
    azuread_service_principal.kvalikoima_databricks.id,
    data.azuread_group.ppm_bus_dls_gt_ba.id,
    data.azuread_group.ppm_bus_dls_kdigital.id,
  ]
}

resource "azuread_group" "dls_gtasort_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTASORT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtasort_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTASORT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_sampo_contributor.id,
  ]
}

resource "azuread_group" "dls_gtasort_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTASORT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.kvalikoima_databricks.id,
    azuread_service_principal.qlik_gt.id,
  ]
}

resource "azuread_group" "dls_gtasort_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTASORT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtasort_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTASORT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.kvalikoima_dbwrite.id,
    data.azuread_group.ppm_sampo_contributor.id,
  ]
}

# ---------------------------------------------------------------------------------------
# GTASORT_MRP
resource "azuread_group" "dls_gtasort_mrp_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTASORT_MRP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtasort_mrp_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTASORT_MRP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtasort_mrp_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTASORT_MRP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_inb_eh.id,
  ]
}

# ---------------------------------------------------------------------------------------
# GTASORT_NAVIGATION
resource "azuread_group" "dls_gtasort_navigation_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTASORT_NAVIGATION"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtasort_navigation_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTASORT_NAVIGATION"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtasort_navigation_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTASORT_NAVIGATION"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_inb_eh.id,
  ]
}

# ---------------------------------------------------------------------------------------
# GTASORT_SETTINGS
resource "azuread_group" "dls_gtasort_settings_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTASORT_SETTINGS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtasort_settings_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTASORT_SETTINGS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtasort_settings_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTASORT_SETTINGS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_inb_eh.id,
  ]
}

# ---------------------------------------------------------------------------------------
# GTASORT_SUBFLD
resource "azuread_group" "dls_gtasort_subfld_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTASORT_SUBFLD"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_gtasort_settings_raw_nat_r.id,
    azuread_group.dls_gtasort_settings_raw_nat_w.id,
    azuread_group.dls_gtasort_settings_raw_nat_rw.id,
    azuread_group.dls_gtasort_navigation_raw_nat_r.id,
    azuread_group.dls_gtasort_navigation_raw_nat_w.id,
    azuread_group.dls_gtasort_navigation_raw_nat_rw.id,
    azuread_group.dls_gtasort_mrp_raw_nat_r.id,
    azuread_group.dls_gtasort_mrp_raw_nat_w.id,
    azuread_group.dls_gtasort_mrp_raw_nat_rw.id,
  ]
}

resource "azuread_group" "dls_gtasort_subfld_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTASORT_SUBFLD"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# GT_BA
resource "azuread_group" "dls_gt_ba_awb_gt_r" {
  display_name            = "${var.prefix_ad_group}_AWB_R_GT_GT_BA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_gt_ba_common_awb_gt_r.id,
    azuread_group.dls_gt_ba_common_awb_gt_w.id,
    azuread_group.dls_gt_ba_common_awb_gt_rw.id,
  ]
}

# ---------------------------------------------------------------------------------------
# GT_BA_COMMON
resource "azuread_group" "dls_gt_ba_common_awb_gt_r" {
  display_name            = "${var.prefix_ad_group}_AWB_R_GT_GT_BA_COMMON"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.qlik_gt.id,
    data.azuread_user.assistant1_virtual.object_id,
  ]
}

resource "azuread_group" "dls_gt_ba_common_awb_gt_w" {
  display_name            = "${var.prefix_ad_group}_AWB_W_GT_GT_BA_COMMON"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gt_ba_common_awb_gt_rw" {
  display_name            = "${var.prefix_ad_group}_AWB_RW_GT_GT_BA_COMMON"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.gtanalytics_adb.id,
    azuread_service_principal.gtkpartner_adb.id,
    azuread_group.adb_app_gtbusinessanalysts.id,
    data.azuread_group.ppm_bus_dls_gt_ba.id,
  ]
}

# =======================================================================================
# GTBW
resource "azuread_group" "dls_gtbw_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTBW"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_group.ppm_devops_keskodev.id,
    azuread_service_principal.kvalikoima_databricks.id,
    azuread_service_principal.retrobonus_adb.id,
    data.azuread_group.ppm_bus_dls_gt_ba.id,
    data.azuread_group.ppm_bus_dls_kdigital.id,
    data.azuread_service_principal.snowflake_0518.id,
    azuread_service_principal.gtkpartner_adb.id,
    azuread_group.adb_app_gtbusinessanalysts.id,
  ]
}

resource "azuread_group" "dls_gtbw_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTBW"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtbw_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTBW"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtbw_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTBW"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.retrobonus_adb.id,
    azuread_group.adb_app_gtbusinessanalysts.id,
  ]
}

resource "azuread_group" "dls_gtbw_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTBW"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtbw_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTBW"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# GTKAMPANJAAPP
resource "azuread_group" "dls_gtkampanjaapp_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTKAMPANJAAPP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.qlik_gt.id,
  ]
}

resource "azuread_group" "dls_gtkampanjaapp_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTKAMPANJAAPP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtkampanjaapp_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTKAMPANJAAPP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.microsoft_eventhubs.id,
    azuread_service_principal.campaign_deltalake.id,
  ]
}

resource "azuread_group" "dls_gtkampanjaapp_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTKAMPANJAAPP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtkampanjaapp_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTKAMPANJAAPP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtkampanjaapp_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTKAMPANJAAPP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# GTMAN
resource "azuread_group" "dls_gtman_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTMAN"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtman_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTMAN"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtman_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTMAN"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTMAN_STAGE_RETROBONUS_INPUT_RETAILERS
resource "azuread_group" "dls_gtman_stage_retrobonus_input_retailers_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTMAN_STAGE_RETROBONUS_INPUT_RETAILERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_gtman_stage_retrobonus_input_retailers_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTMAN_STAGE_RETROBONUS_INPUT_RETAILERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtman_stage_retrobonus_input_retailers_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTMAN_STAGE_RETROBONUS_INPUT_RETAILERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.retrobonus_adb.id,
    data.azuread_group.ppm_gt_dl_raw_gtman_stage_retrobonus_input_retailers.id,
  ]
}

# ---------------------------------------------------------------------------------------
# GTMAN_STAGE_RETROBONUS_INPUT_SUBFLD
resource "azuread_group" "dls_gtman_stage_retrobonus_input_subfld_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTMAN_STAGE_RETROBONUS_INPUT_SUBFLD"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_gtman_stage_retrobonus_input_retailers_raw_nat_r.id,
    azuread_group.dls_gtman_stage_retrobonus_input_retailers_raw_nat_w.id,
    azuread_group.dls_gtman_stage_retrobonus_input_retailers_raw_nat_rw.id,
    azuread_group.dls_gtman_stage_retrobonus_input_vendors_raw_nat_r.id,
    azuread_group.dls_gtman_stage_retrobonus_input_vendors_raw_nat_w.id,
    azuread_group.dls_gtman_stage_retrobonus_input_vendors_raw_nat_rw.id,
    data.azuread_group.ppm_gt_dl_raw_gtman_stage_retrobonus_input_retailers.id,
    data.azuread_group.ppm_gt_dl_raw_gtman_stage_retrobonus_input_vendors.id,
  ]
}

# ---------------------------------------------------------------------------------------
# GTMAN_STAGE_RETROBONUS_INPUT_VENDORS
resource "azuread_group" "dls_gtman_stage_retrobonus_input_vendors_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTMAN_STAGE_RETROBONUS_INPUT_VENDORS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtman_stage_retrobonus_input_vendors_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTMAN_STAGE_RETROBONUS_INPUT_VENDORS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtman_stage_retrobonus_input_vendors_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTMAN_STAGE_RETROBONUS_INPUT_VENDORS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.retrobonus_adb.id,
    data.azuread_group.ppm_gt_dl_raw_gtman_stage_retrobonus_input_vendors.id,
  ]
}

# ---------------------------------------------------------------------------------------
# GTMAN_STAGE_RETROBONUS_SUBFLD
resource "azuread_group" "dls_gtman_stage_retrobonus_subfld_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTMAN_STAGE_RETROBONUS_SUBFLD"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_gtman_stage_retrobonus_input_subfld_raw_nat_r.id,
  ]
}

# ---------------------------------------------------------------------------------------
# GTMAN_STAGE_KFDM RAMPDOWN_SUBFLD
resource "azuread_group" "dls_gtman_stage_kfdmrampdown_subfld_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTMAN_STAGE_KFDMRAMPDOWN_SUBFLD"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_gtman_stage_kfdmrampdown_input_subfld_raw_nat_r.id,
  ]
}

# ---------------------------------------------------------------------------------------
# GTMAN_STAGE_KFDM RAMPDWON_INPUT_SUBFLD
resource "azuread_group" "dls_gtman_stage_kfdmrampdown_input_subfld_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTMAN_STAGE_KFDMRAMPDOWN_INPUT_SUBFLD"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_gtman_stage_kfdmrampdown_input_rolloutorders_raw_nat_r.id,
    azuread_group.dls_gtman_stage_kfdmrampdown_input_rolloutorders_raw_nat_w.id,
    azuread_group.dls_gtman_stage_kfdmrampdown_input_rolloutorders_raw_nat_rw.id,
  ]
}

# ---------------------------------------------------------------------------------------
# GTMAN_STAGE_KFDM RAMPDOWN_INPUT_ROLL OUT ORDERS
resource "azuread_group" "dls_gtman_stage_kfdmrampdown_input_rolloutorders_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTMAN_STAGE_KFDMRAMPDOWN_INPUT_ROLLOUTORDERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtman_stage_kfdmrampdown_input_rolloutorders_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTMAN_STAGE_KFDMRAMPDOWN_INPUT_ROLLOUTORDERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtman_stage_kfdmrampdown_input_rolloutorders_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTMAN_STAGE_KFDMRAMPDOWN_INPUT_ROLLOUTORDERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_user.kesko_henri_dahlstrom.id,
  ]
}

# ---------------------------------------------------------------------------------------
# GTMAN_STAGE_SUBFLD
resource "azuread_group" "dls_gtman_stage_subfld_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTMAN_STAGE_SUBFLD"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_gtman_stage_retrobonus_subfld_raw_nat_r.id,
    azuread_group.dls_gtman_stage_kfdmrampdown_subfld_raw_nat_r.id,
  ]
}

# ---------------------------------------------------------------------------------------
# GTMAN_SUBFLD
resource "azuread_group" "dls_gtman_subfld_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTMAN_SUBFLD"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_gtman_stage_subfld_raw_nat_r.id,
  ]
}

# =======================================================================================
# GTPIM
resource "azuread_group" "dls_gtpim_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTPIM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_group.ppm_bus_dls_gt_ba.id,
    data.azuread_group.ppm_bus_dls_kdigital.id,
    azuread_service_principal.catman_adb.id,
  ]
}

resource "azuread_group" "dls_gtpim_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTPIM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtpim_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTPIM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_gtpim.id,
    azuread_group.dls_inb_eh.id,
  ]
}

resource "azuread_group" "dls_gtpim_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTPIM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.qlik_gt.id,
    azuread_service_principal.catman_adb.id,
  ]
}

resource "azuread_group" "dls_gtpim_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTPIM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtpim_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTPIM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_gtpim.id,
    azuread_service_principal.pxm_devops.id,
    azuread_group.dls_inb_eh.id,
  ]
}

# =======================================================================================
# GTPOS
resource "azuread_group" "dls_gtpos_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTPOS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_group.ppm_devops_keskodev.id,
    data.azuread_group.ppm_bus_dls_gt_ba.id,
    data.azuread_group.ppm_bus_dls_kdigital.id,
    data.azuread_group.ppm_dls_devops_or.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_gtpos_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTPOS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtpos_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTPOS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.lumi_adb.id,
    azuread_group.dls_inb_eh.id,
    data.azuread_service_principal.lumi_adf.id,
    data.azuread_service_principal.lumi_xmlparser_funcapp.id,
  ]
}

resource "azuread_group" "dls_gtpos_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTPOS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    azuread_service_principal.qlik_gt.id,
    data.azuread_group.ppm_dls_devops_or.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_gtpos_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTPOS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtpos_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTPOS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.or_deltalake.id,
    azuread_group.dls_inb_eh.id,
  ]
}

# ---------------------------------------------------------------------------------------
# GTPOS_ASSORTCODES
resource "azuread_group" "dls_gtpos_assortcodes_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTPOS_ASSORTCODES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtpos_assortcodes_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTPOS_ASSORTCODES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtpos_assortcodes_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTPOS_ASSORTCODES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.int_adf.id,
  ]
}

resource "azuread_group" "dls_gtpos_assortcodes_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTPOS_ASSORTCODES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtpos_assortcodes_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTPOS_ASSORTCODES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtpos_assortcodes_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTPOS_ASSORTCODES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.int_adf.id,
  ]
}

# ---------------------------------------------------------------------------------------
# GTPOS_NESTESUBCONCEPT
resource "azuread_group" "dls_gtpos_nestesubconcept_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTPOS_NESTESUBCONCEPT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtpos_nestesubconcept_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTPOS_NESTESUBCONCEPT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.int_adf.id,
  ]
}

# ---------------------------------------------------------------------------------------
# GTPOS_SUBFLD
resource "azuread_group" "dls_gtpos_subfld_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTPOS_SUBFLD"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_gtpos_assortcodes_raw_nat_r.id,
    azuread_group.dls_gtpos_assortcodes_raw_nat_w.id,
    azuread_group.dls_gtpos_assortcodes_raw_nat_rw.id,
    azuread_group.dls_gtpos_nestesubconcept_raw_nat_r.id,
    azuread_group.dls_gtpos_nestesubconcept_raw_nat_rw.id,
  ]
}

resource "azuread_group" "dls_gtpos_subfld_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTPOS_SUBFLD"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_gtpos_assortcodes_cur_nat_r.id,
    azuread_group.dls_gtpos_assortcodes_cur_nat_w.id,
    azuread_group.dls_gtpos_assortcodes_cur_nat_rw.id,
  ]
}

# =======================================================================================
# GTSAP
resource "azuread_group" "dls_gtsap_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_group.ppm_devops_keskodev.id,
    data.azuread_group.ppm_devops_gtvalikoima.id,
    data.azuread_group.ppm_bus_dls_gt_ba.id,
    data.azuread_group.ppm_bus_dls_kdigital.id,
    azuread_service_principal.or_kai.id,
    azuread_service_principal.kvalikoima_databricks.id,
    azuread_service_principal.retrobonus_adb.id,
    azuread_service_principal.qlik_gt.id,
    azuread_service_principal.gtanalytics_adb.id,
    azuread_service_principal.gtkpartner_adb.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_gtsap_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_gtpim.id,
    data.azuread_service_principal.sap_input_api.id,
    data.azuread_service_principal.centralised_apim.id,
    azuread_service_principal.catman_adb.id,
    azuread_group.dls_inb_eh.id,
  ]
}

resource "azuread_group" "dls_gtsap_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_bus_dls_gt_ba.id,
    data.azuread_group.ppm_devops_gtvalikoima.id,
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.int_adf.id,
    data.azuread_service_principal.ktv_adf.id,
    data.azuread_service_principal.snowflake_0518.id,
    azuread_service_principal.kvalikoima_databricks.id,
    azuread_service_principal.retrobonus_adb.id,
    azuread_service_principal.qlik_gt.id,
    azuread_service_principal.gtanalytics_adb.id,
    azuread_service_principal.gtkpartner_adb.id,
    azuread_group.adb_app_gtbusinessanalysts.id,
  ]
}

resource "azuread_group" "dls_gtsap_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.catman_adb.id,
  ]
}

resource "azuread_group" "dls_gtsap_gld_gt_r" {
  display_name            = "${var.prefix_ad_group}_GLD_R_GT_GTSAP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [

  ]
}

resource "azuread_group" "dls_gtsap_gld_gt_rw" {
  display_name            = "${var.prefix_ad_group}_GLD_RW_GT_GTSAP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.catman_adb.id,
  ]
}
# ---------------------------------------------------------------------------------------
# GTSAP_A2GMCATLIST
resource "azuread_group" "dls_gtsap_a2gmcatlist_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_A2GMCATLIST"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_a2gmcatlist_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_A2GMCATLIST"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_a2gmcatlist_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_A2GMCATLIST"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_a2gmcatlist_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_A2GMCATLIST"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_a2gmcatlist_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_A2GMCATLIST"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_a2gmcatlist_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_A2GMCATLIST"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_ASSORTCODES
resource "azuread_group" "dls_gtsap_assortcodes_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_ASSORTCODES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_assortcodes_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_ASSORTCODES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_assortcodes_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_ASSORTCODES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.int_adf.id,
  ]
}

resource "azuread_group" "dls_gtsap_assortcodes_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_ASSORTCODES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_assortcodes_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_ASSORTCODES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_assortcodes_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_ASSORTCODES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_BASICPRODUCTS
resource "azuread_group" "dls_gtsap_basicproducts_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_BASICPRODUCTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_basicproducts_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_BASICPRODUCTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_basicproducts_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_BASICPRODUCTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_basicproducts_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_BASICPRODUCTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_basicproducts_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_BASICPRODUCTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_basicproducts_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_BASICPRODUCTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_B2BASSORTMENT
resource "azuread_group" "dls_gtsap_b2bassortment_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_B2BASSORTMENT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_gtkesprodata.id
  ]
}

resource "azuread_group" "dls_gtsap_b2bassortment_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_B2BASSORTMENT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.centralised_apim.id,
  ]
}

resource "azuread_group" "dls_gtsap_b2bassortment_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_B2BASSORTMENT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_b2bassortment_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_B2BASSORTMENT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_b2bassortment_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_B2BASSORTMENT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_b2bassortment_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_B2BASSORTMENT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.int_adf.id,
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_B2BPRODUCTS
resource "azuread_group" "dls_gtsap_b2bproducts_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_B2BPRODUCTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_gtkesprodata.id
  ]
}

resource "azuread_group" "dls_gtsap_b2bproducts_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_B2BPRODUCTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.centralised_apim.id,
  ]
}

resource "azuread_group" "dls_gtsap_b2bproducts_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_B2BPRODUCTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_b2bproducts_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_B2BPRODUCTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_b2bproducts_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_B2BPRODUCTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_b2bproducts_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_B2BPRODUCTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.int_adf.id,
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_CAMPAIGN
resource "azuread_group" "dls_gtsap_campaign_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_CAMPAIGN"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.retrobonus_adb.id,
    azuread_service_principal.campaign_deltalake.id,
  ]
}

resource "azuread_group" "dls_gtsap_campaign_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_CAMPAIGN"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_campaign_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_CAMPAIGN"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [

  ]
}

resource "azuread_group" "dls_gtsap_campaign_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_CAMPAIGN"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.or_kai.id,
  ]
}

resource "azuread_group" "dls_gtsap_campaign_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_CAMPAIGN"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_campaign_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_CAMPAIGN"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.campaign_deltalake.id,
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_COLLECTIVEPURCHASEORDERS
resource "azuread_group" "dls_gtsap_collectivepurchaseorders_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_COLLECTIVEPURCHASEORDERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_collectivepurchaseorders_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_COLLECTIVEPURCHASEORDERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_collectivepurchaseorders_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_COLLECTIVEPURCHASEORDERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_collectivepurchaseorders_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_COLLECTIVEPURCHASEORDERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_collectivepurchaseorders_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_COLLECTIVEPURCHASEORDERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_collectivepurchaseorders_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_COLLECTIVEPURCHASEORDERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_FOODASSORTMENTS
resource "azuread_group" "dls_gtsap_foodassortments_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_FOODASSORTMENTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_foodassortments_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_FOODASSORTMENTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_foodassortments_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_FOODASSORTMENTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_foodassortments_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_FOODASSORTMENTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_foodassortments_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_FOODASSORTMENTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_foodassortments_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_FOODASSORTMENTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_CUSTOMER
resource "azuread_group" "dls_gtsap_customer_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_CUSTOMER"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_gtkesprodata.id
  ]
}

resource "azuread_group" "dls_gtsap_customer_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_CUSTOMER"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.centralised_apim.id,
  ]
}

resource "azuread_group" "dls_gtsap_customer_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_CUSTOMER"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_customer_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_CUSTOMER"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_customer_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_CUSTOMER"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_customer_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_CUSTOMER"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.int_adf.id,
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_IDENTIFIEDLOSS
resource "azuread_group" "dls_gtsap_identifiedloss_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_IDENTIFIEDLOSS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_identifiedloss_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_IDENTIFIEDLOSS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_identifiedloss_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_IDENTIFIEDLOSS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.lumi_adf.id,
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_MODULEARTICLES
resource "azuread_group" "dls_gtsap_modulearticles_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_MODULEARTICLES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_modulearticles_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_MODULEARTICLES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_modulearticles_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_MODULEARTICLES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_modulearticles_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_MODULEARTICLES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_modulearticles_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_MODULEARTICLES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_modulearticles_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_MODULEARTICLES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_MODULEMETAS
resource "azuread_group" "dls_gtsap_modulemetas_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_MODULEMETAS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_modulemetas_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_MODULEMETAS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_modulemetas_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_MODULEMETAS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_modulemetas_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_MODULEMETAS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_modulemetas_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_MODULEMETAS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_modulemetas_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_MODULEMETAS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_MRPBRAND
resource "azuread_group" "dls_gtsap_mrpbrand_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_MRPBRAND"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_mrpbrand_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_MRPBRAND"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_mrpbrand_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_MRPBRAND"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_mrpbrand_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_MRPBRAND"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_mrpbrand_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_MRPBRAND"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_mrpbrand_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_MRPBRAND"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_PRICELISTPRIORITY
resource "azuread_group" "dls_gtsap_pricelistpriority_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_PRICELISTPRIORITY"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_pricelistpriority_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_PRICELISTPRIORITY"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_pricelistpriority_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_PRICELISTPRIORITY"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_pricelistpriority_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_PRICELISTPRIORITY"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_pricelistpriority_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_PRICELISTPRIORITY"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_pricelistpriority_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_PRICELISTPRIORITY"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_PRODUCTCOMPONENTS
resource "azuread_group" "dls_gtsap_productcomponents_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_PRODUCTCOMPONENTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_productcomponents_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_PRODUCTCOMPONENTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_productcomponents_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_PRODUCTCOMPONENTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_productcomponents_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_PRODUCTCOMPONENTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_productcomponents_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_PRODUCTCOMPONENTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_productcomponents_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_PRODUCTCOMPONENTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_PRODUCTPRICES
resource "azuread_group" "dls_gtsap_productprices_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_PRODUCTPRICES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_user.kesko_janne_uutela.object_id,
    data.azuread_user.kesko_anna_luneva.object_id,
  ]
}

resource "azuread_group" "dls_gtsap_productprices_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_PRODUCTPRICES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_productprices_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_PRODUCTPRICES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_productprices_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_PRODUCTPRICES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_productprices_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_PRODUCTPRICES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_productprices_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_PRODUCTPRICES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_PRODUCTSALES
resource "azuread_group" "dls_gtsap_productsales_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_PRODUCTSALES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_productsales_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_PRODUCTSALES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_productsales_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_PRODUCTSALES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_productsales_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_PRODUCTSALES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_productsales_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_PRODUCTSALES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_productsales_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_PRODUCTSALES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_PRODUCTSTOREAVAILABILITY
resource "azuread_group" "dls_gtsap_productstoreavailability_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_PRODUCTSTOREAVAILABILITY"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_productstoreavailability_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_PRODUCTSTOREAVAILABILITY"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_productstoreavailability_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_PRODUCTSTOREAVAILABILITY"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_productstoreavailability_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_PRODUCTSTOREAVAILABILITY"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_productstoreavailability_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_PRODUCTSTOREAVAILABILITY"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_productstoreavailability_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_PRODUCTSTOREAVAILABILITY"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_PURCHASEORDERS
resource "azuread_group" "dls_gtsap_purchaseorders_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_PURCHASEORDERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_purchaseorders_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_PURCHASEORDERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_purchaseorders_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_PURCHASEORDERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_purchaseorders_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_PURCHASEORDERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_purchaseorders_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_PURCHASEORDERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_purchaseorders_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_PURCHASEORDERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_PURCHASEPRICES
resource "azuread_group" "dls_gtsap_purchaseprices_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_PURCHASEPRICES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_purchaseprices_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_PURCHASEPRICES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_purchaseprices_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_PURCHASEPRICES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_purchaseprices_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_PURCHASEPRICES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_purchaseprices_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_PURCHASEPRICES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_purchaseprices_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_PURCHASEPRICES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_QM
resource "azuread_group" "dls_gtsap_qm_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_QM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_qm_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_QM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_qm_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_QM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.qm_imageapi_msi.id,
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_RECLAMATION
resource "azuread_group" "dls_gtsap_reclamation_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_RECLAMATION"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_reclamation_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_RECLAMATION"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_reclamation_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_RECLAMATION"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_reclamation_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_RECLAMATION"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_reclamation_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_RECLAMATION"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_reclamation_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_RECLAMATION"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_REFSITEMODULES
resource "azuread_group" "dls_gtsap_refsitemodules_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_REFSITEMODULES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_refsitemodules_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_REFSITEMODULES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_refsitemodules_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_REFSITEMODULES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_refsitemodules_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_REFSITEMODULES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_refsitemodules_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_REFSITEMODULES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_refsitemodules_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_REFSITEMODULES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_SITEPRICELIST
resource "azuread_group" "dls_gtsap_sitepricelist_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_SITEPRICELIST"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_sitepricelist_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_SITEPRICELIST"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_sitepricelist_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_SITEPRICELIST"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_sitepricelist_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_SITEPRICELIST"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_sitepricelist_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_SITEPRICELIST"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_sitepricelist_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_SITEPRICELIST"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_SITEREFSITES
resource "azuread_group" "dls_gtsap_siterefsites_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_SITEREFSITES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_siterefsites_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_SITEREFSITES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_siterefsites_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_SITEREFSITES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_siterefsites_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_SITEREFSITES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_siterefsites_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_SITEREFSITES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_siterefsites_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_SITEREFSITES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_STOREORDERS
resource "azuread_group" "dls_gtsap_storeorders_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_STOREORDERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_storeorders_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_STOREORDERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_storeorders_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_STOREORDERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_storeorders_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_STOREORDERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_storeorders_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_STOREORDERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_storeorders_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_STOREORDERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_STOREPRODUCTS
resource "azuread_group" "dls_gtsap_storeproducts_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_STOREPRODUCTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_storeproducts_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_STOREPRODUCTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_storeproducts_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_STOREPRODUCTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_storeproducts_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_STOREPRODUCTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_storeproducts_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_STOREPRODUCTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_storeproducts_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_STOREPRODUCTS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_SUBFLD
resource "azuread_group" "dls_gtsap_subfld_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_SUBFLD"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_gtsap_storeproducts_raw_nat_r.id,
    azuread_group.dls_gtsap_storeproducts_raw_nat_w.id,
    azuread_group.dls_gtsap_storeproducts_raw_nat_rw.id,
    azuread_group.dls_gtsap_storeorders_raw_nat_r.id,
    azuread_group.dls_gtsap_storeorders_raw_nat_w.id,
    azuread_group.dls_gtsap_storeorders_raw_nat_rw.id,
    azuread_group.dls_gtsap_siterefsites_raw_nat_r.id,
    azuread_group.dls_gtsap_siterefsites_raw_nat_w.id,
    azuread_group.dls_gtsap_siterefsites_raw_nat_rw.id,
    azuread_group.dls_gtsap_a2gmcatlist_raw_nat_r.id,
    azuread_group.dls_gtsap_a2gmcatlist_raw_nat_w.id,
    azuread_group.dls_gtsap_a2gmcatlist_raw_nat_rw.id,
    azuread_group.dls_gtsap_assortcodes_raw_nat_r.id,
    azuread_group.dls_gtsap_assortcodes_raw_nat_w.id,
    azuread_group.dls_gtsap_assortcodes_raw_nat_rw.id,
    azuread_group.dls_gtsap_basicproducts_raw_nat_r.id,
    azuread_group.dls_gtsap_basicproducts_raw_nat_w.id,
    azuread_group.dls_gtsap_basicproducts_raw_nat_rw.id,
    azuread_group.dls_gtsap_b2bassortment_raw_nat_r.id,
    azuread_group.dls_gtsap_b2bassortment_raw_nat_w.id,
    azuread_group.dls_gtsap_b2bassortment_raw_nat_rw.id,
    azuread_group.dls_gtsap_b2bproducts_raw_nat_r.id,
    azuread_group.dls_gtsap_b2bproducts_raw_nat_w.id,
    azuread_group.dls_gtsap_b2bproducts_raw_nat_rw.id,
    azuread_group.dls_gtsap_campaign_raw_nat_r.id,
    azuread_group.dls_gtsap_campaign_raw_nat_w.id,
    azuread_group.dls_gtsap_campaign_raw_nat_rw.id,
    azuread_group.dls_gtsap_collectivepurchaseorders_raw_nat_r.id,
    azuread_group.dls_gtsap_collectivepurchaseorders_raw_nat_w.id,
    azuread_group.dls_gtsap_collectivepurchaseorders_raw_nat_rw.id,
    azuread_group.dls_gtsap_foodassortments_raw_nat_r.id,
    azuread_group.dls_gtsap_foodassortments_raw_nat_w.id,
    azuread_group.dls_gtsap_foodassortments_raw_nat_rw.id,
    azuread_group.dls_gtsap_customer_raw_nat_r.id,
    azuread_group.dls_gtsap_customer_raw_nat_w.id,
    azuread_group.dls_gtsap_customer_raw_nat_rw.id,
    azuread_group.dls_gtsap_identifiedloss_raw_nat_r.id,
    azuread_group.dls_gtsap_identifiedloss_raw_nat_w.id,
    azuread_group.dls_gtsap_identifiedloss_raw_nat_rw.id,
    azuread_group.dls_gtsap_modulearticles_raw_nat_r.id,
    azuread_group.dls_gtsap_modulearticles_raw_nat_w.id,
    azuread_group.dls_gtsap_modulearticles_raw_nat_rw.id,
    azuread_group.dls_gtsap_modulemetas_raw_nat_r.id,
    azuread_group.dls_gtsap_modulemetas_raw_nat_w.id,
    azuread_group.dls_gtsap_modulemetas_raw_nat_rw.id,
    azuread_group.dls_gtsap_mrpbrand_raw_nat_r.id,
    azuread_group.dls_gtsap_mrpbrand_raw_nat_w.id,
    azuread_group.dls_gtsap_mrpbrand_raw_nat_rw.id,
    azuread_group.dls_gtsap_pricelistpriority_raw_nat_r.id,
    azuread_group.dls_gtsap_pricelistpriority_raw_nat_w.id,
    azuread_group.dls_gtsap_pricelistpriority_raw_nat_rw.id,
    azuread_group.dls_gtsap_productcomponents_raw_nat_r.id,
    azuread_group.dls_gtsap_productcomponents_raw_nat_w.id,
    azuread_group.dls_gtsap_productcomponents_raw_nat_rw.id,
    azuread_group.dls_gtsap_productprices_raw_nat_r.id,
    azuread_group.dls_gtsap_productprices_raw_nat_w.id,
    azuread_group.dls_gtsap_productprices_raw_nat_rw.id,
    azuread_group.dls_gtsap_productsales_raw_nat_r.id,
    azuread_group.dls_gtsap_productsales_raw_nat_w.id,
    azuread_group.dls_gtsap_productsales_raw_nat_rw.id,
    azuread_group.dls_gtsap_productstoreavailability_raw_nat_r.id,
    azuread_group.dls_gtsap_productstoreavailability_raw_nat_w.id,
    azuread_group.dls_gtsap_productstoreavailability_raw_nat_rw.id,
    azuread_group.dls_gtsap_purchaseorders_raw_nat_r.id,
    azuread_group.dls_gtsap_purchaseorders_raw_nat_w.id,
    azuread_group.dls_gtsap_purchaseorders_raw_nat_rw.id,
    azuread_group.dls_gtsap_purchaseprices_raw_nat_r.id,
    azuread_group.dls_gtsap_purchaseprices_raw_nat_w.id,
    azuread_group.dls_gtsap_purchaseprices_raw_nat_rw.id,
    azuread_group.dls_gtsap_qm_raw_nat_r.id,
    azuread_group.dls_gtsap_qm_raw_nat_w.id,
    azuread_group.dls_gtsap_qm_raw_nat_rw.id,
    azuread_group.dls_gtsap_reclamation_raw_nat_r.id,
    azuread_group.dls_gtsap_reclamation_raw_nat_w.id,
    azuread_group.dls_gtsap_reclamation_raw_nat_rw.id,
    azuread_group.dls_gtsap_refsitemodules_raw_nat_r.id,
    azuread_group.dls_gtsap_refsitemodules_raw_nat_w.id,
    azuread_group.dls_gtsap_refsitemodules_raw_nat_rw.id,
    azuread_group.dls_gtsap_sitepricelist_raw_nat_r.id,
    azuread_group.dls_gtsap_sitepricelist_raw_nat_w.id,
    azuread_group.dls_gtsap_sitepricelist_raw_nat_rw.id,
    azuread_group.dls_gtsap_siterefsites_raw_nat_r.id,
    azuread_group.dls_gtsap_siterefsites_raw_nat_w.id,
    azuread_group.dls_gtsap_siterefsites_raw_nat_rw.id,
    azuread_group.dls_gtsap_storeorders_raw_nat_r.id,
    azuread_group.dls_gtsap_storeorders_raw_nat_w.id,
    azuread_group.dls_gtsap_storeorders_raw_nat_rw.id,
    azuread_group.dls_gtsap_storeproducts_raw_nat_r.id,
    azuread_group.dls_gtsap_storeproducts_raw_nat_w.id,
    azuread_group.dls_gtsap_storeproducts_raw_nat_rw.id,
    azuread_group.dls_gtsap_vendors_raw_nat_r.id,
    azuread_group.dls_gtsap_vendors_raw_nat_w.id,
    azuread_group.dls_gtsap_vendors_raw_nat_rw.id,
    azuread_group.dls_gtsap_wholesaleprices_raw_nat_r.id,
    azuread_group.dls_gtsap_wholesaleprices_raw_nat_w.id,
    azuread_group.dls_gtsap_wholesaleprices_raw_nat_rw.id,
    azuread_group.dls_gtsap_suppliers_raw_nat_r.id,
    azuread_group.dls_gtsap_suppliers_raw_nat_w.id,
    azuread_group.dls_gtsap_suppliers_raw_nat_rw.id,
    azuread_group.dls_gtsap_contractproduct_raw_nat_r.id,
    azuread_group.dls_gtsap_contractproduct_raw_nat_w.id,
    azuread_group.dls_gtsap_contractproduct_raw_nat_rw.id,
    azuread_group.dls_gtsap_suppliers_subfld_raw_nat_r.id,
    azuread_group.dls_gtsap_vendorquotations_raw_nat_r.id,
    azuread_group.dls_gtsap_vendorquotations_raw_nat_w.id,
    azuread_group.dls_gtsap_vendorquotations_raw_nat_rw.id,
    azuread_group.dls_gtsap_tobacco_raw_nat_r.id,
    azuread_group.dls_gtsap_tobacco_raw_nat_w.id,
    azuread_group.dls_gtsap_tobacco_raw_nat_rw.id,
  ]
}

resource "azuread_group" "dls_gtsap_subfld_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_SUBFLD"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_gtsap_storeproducts_cur_nat_r.id,
    azuread_group.dls_gtsap_storeproducts_cur_nat_w.id,
    azuread_group.dls_gtsap_storeproducts_cur_nat_rw.id,
    azuread_group.dls_gtsap_storeorders_cur_nat_r.id,
    azuread_group.dls_gtsap_storeorders_cur_nat_w.id,
    azuread_group.dls_gtsap_storeorders_cur_nat_rw.id,
    azuread_group.dls_gtsap_siterefsites_cur_nat_r.id,
    azuread_group.dls_gtsap_siterefsites_cur_nat_w.id,
    azuread_group.dls_gtsap_siterefsites_cur_nat_rw.id,
    azuread_group.dls_gtsap_a2gmcatlist_cur_nat_r.id,
    azuread_group.dls_gtsap_a2gmcatlist_cur_nat_w.id,
    azuread_group.dls_gtsap_a2gmcatlist_cur_nat_rw.id,
    azuread_group.dls_gtsap_assortcodes_cur_nat_r.id,
    azuread_group.dls_gtsap_assortcodes_cur_nat_w.id,
    azuread_group.dls_gtsap_assortcodes_cur_nat_rw.id,
    azuread_group.dls_gtsap_basicproducts_cur_nat_r.id,
    azuread_group.dls_gtsap_basicproducts_cur_nat_w.id,
    azuread_group.dls_gtsap_basicproducts_cur_nat_rw.id,
    azuread_group.dls_gtsap_b2bassortment_cur_nat_r.id,
    azuread_group.dls_gtsap_b2bassortment_cur_nat_w.id,
    azuread_group.dls_gtsap_b2bassortment_cur_nat_rw.id,
    azuread_group.dls_gtsap_b2bproducts_cur_nat_r.id,
    azuread_group.dls_gtsap_b2bproducts_cur_nat_w.id,
    azuread_group.dls_gtsap_b2bproducts_cur_nat_rw.id,
    azuread_group.dls_gtsap_campaign_cur_nat_r.id,
    azuread_group.dls_gtsap_campaign_cur_nat_w.id,
    azuread_group.dls_gtsap_campaign_cur_nat_rw.id,
    azuread_group.dls_gtsap_collectivepurchaseorders_cur_nat_r.id,
    azuread_group.dls_gtsap_collectivepurchaseorders_cur_nat_w.id,
    azuread_group.dls_gtsap_collectivepurchaseorders_cur_nat_rw.id,
    azuread_group.dls_gtsap_foodassortments_cur_nat_r.id,
    azuread_group.dls_gtsap_foodassortments_cur_nat_w.id,
    azuread_group.dls_gtsap_foodassortments_cur_nat_rw.id,
    azuread_group.dls_gtsap_customer_cur_nat_r.id,
    azuread_group.dls_gtsap_customer_cur_nat_w.id,
    azuread_group.dls_gtsap_customer_cur_nat_rw.id,
    azuread_group.dls_gtsap_modulearticles_cur_nat_r.id,
    azuread_group.dls_gtsap_modulearticles_cur_nat_w.id,
    azuread_group.dls_gtsap_modulearticles_cur_nat_rw.id,
    azuread_group.dls_gtsap_modulemetas_cur_nat_r.id,
    azuread_group.dls_gtsap_modulemetas_cur_nat_w.id,
    azuread_group.dls_gtsap_modulemetas_cur_nat_rw.id,
    azuread_group.dls_gtsap_mrpbrand_cur_nat_r.id,
    azuread_group.dls_gtsap_mrpbrand_cur_nat_w.id,
    azuread_group.dls_gtsap_mrpbrand_cur_nat_rw.id,
    azuread_group.dls_gtsap_pricelistpriority_cur_nat_r.id,
    azuread_group.dls_gtsap_pricelistpriority_cur_nat_w.id,
    azuread_group.dls_gtsap_pricelistpriority_cur_nat_rw.id,
    azuread_group.dls_gtsap_productcomponents_cur_nat_r.id,
    azuread_group.dls_gtsap_productcomponents_cur_nat_w.id,
    azuread_group.dls_gtsap_productcomponents_cur_nat_rw.id,
    azuread_group.dls_gtsap_productprices_cur_nat_r.id,
    azuread_group.dls_gtsap_productprices_cur_nat_w.id,
    azuread_group.dls_gtsap_productprices_cur_nat_rw.id,
    azuread_group.dls_gtsap_productsales_cur_nat_r.id,
    azuread_group.dls_gtsap_productsales_cur_nat_w.id,
    azuread_group.dls_gtsap_productsales_cur_nat_rw.id,
    azuread_group.dls_gtsap_productstoreavailability_cur_nat_r.id,
    azuread_group.dls_gtsap_productstoreavailability_cur_nat_w.id,
    azuread_group.dls_gtsap_productstoreavailability_cur_nat_rw.id,
    azuread_group.dls_gtsap_purchaseorders_cur_nat_r.id,
    azuread_group.dls_gtsap_purchaseorders_cur_nat_w.id,
    azuread_group.dls_gtsap_purchaseorders_cur_nat_rw.id,
    azuread_group.dls_gtsap_purchaseprices_cur_nat_r.id,
    azuread_group.dls_gtsap_purchaseprices_cur_nat_w.id,
    azuread_group.dls_gtsap_purchaseprices_cur_nat_rw.id,
    azuread_group.dls_gtsap_reclamation_cur_nat_r.id,
    azuread_group.dls_gtsap_reclamation_cur_nat_w.id,
    azuread_group.dls_gtsap_reclamation_cur_nat_rw.id,
    azuread_group.dls_gtsap_refsitemodules_cur_nat_r.id,
    azuread_group.dls_gtsap_refsitemodules_cur_nat_w.id,
    azuread_group.dls_gtsap_refsitemodules_cur_nat_rw.id,
    azuread_group.dls_gtsap_sitepricelist_cur_nat_r.id,
    azuread_group.dls_gtsap_sitepricelist_cur_nat_w.id,
    azuread_group.dls_gtsap_sitepricelist_cur_nat_rw.id,
    azuread_group.dls_gtsap_siterefsites_cur_nat_r.id,
    azuread_group.dls_gtsap_siterefsites_cur_nat_w.id,
    azuread_group.dls_gtsap_siterefsites_cur_nat_rw.id,
    azuread_group.dls_gtsap_storeorders_cur_nat_r.id,
    azuread_group.dls_gtsap_storeorders_cur_nat_w.id,
    azuread_group.dls_gtsap_storeorders_cur_nat_rw.id,
    azuread_group.dls_gtsap_storeproducts_cur_nat_r.id,
    azuread_group.dls_gtsap_storeproducts_cur_nat_w.id,
    azuread_group.dls_gtsap_storeproducts_cur_nat_rw.id,
    azuread_group.dls_gtsap_vendors_cur_nat_r.id,
    azuread_group.dls_gtsap_vendors_cur_nat_w.id,
    azuread_group.dls_gtsap_vendors_cur_nat_rw.id,
    azuread_group.dls_gtsap_wholesaleprices_cur_nat_r.id,
    azuread_group.dls_gtsap_wholesaleprices_cur_nat_w.id,
    azuread_group.dls_gtsap_wholesaleprices_cur_nat_rw.id,
    azuread_group.dls_gtsap_contractproduct_cur_nat_r.id,
    azuread_group.dls_gtsap_contractproduct_cur_nat_w.id,
    azuread_group.dls_gtsap_contractproduct_cur_nat_rw.id,
    azuread_group.dls_gtsap_vendorquotations_cur_nat_r.id,
    azuread_group.dls_gtsap_vendorquotations_cur_nat_w.id,
    azuread_group.dls_gtsap_vendorquotations_cur_nat_rw.id,
    azuread_group.dls_gtsap_tobacco_cur_nat_r.id,
    azuread_group.dls_gtsap_tobacco_cur_nat_w.id,
    azuread_group.dls_gtsap_tobacco_cur_nat_rw.id,
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_SUPPLIERS
resource "azuread_group" "dls_gtsap_suppliers_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_SUPPLIERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_suppliers_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_SUPPLIERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_suppliers_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_SUPPLIERS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_SUPPLIERS_BONUSES
resource "azuread_group" "dls_gtsap_suppliers_bonuses_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_SUPPLIERS_BONUSES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_suppliers_bonuses_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_SUPPLIERS_BONUSES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_suppliers_bonuses_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_SUPPLIERS_BONUSES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_bus_dls_gt_ba.id,
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_SUPPLIERS_SUBFLD
resource "azuread_group" "dls_gtsap_suppliers_subfld_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_SUPPLIERS_SUBFLD"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_gtsap_suppliers_bonuses_raw_nat_r.id,
    azuread_group.dls_gtsap_suppliers_bonuses_raw_nat_w.id,
    azuread_group.dls_gtsap_suppliers_bonuses_raw_nat_rw.id,
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_TOBACCO
resource "azuread_group" "dls_gtsap_tobacco_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_TOBACCO"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_tobacco_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_TOBACCO"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_tobacco_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_TOBACCO"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_tobacco_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_TOBACCO"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_tobacco_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_TOBACCO"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_tobacco_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_TOBACCO"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_VENDORQUOTATIONS
resource "azuread_group" "dls_gtsap_vendorquotations_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_VENDORQUOTATIONS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_vendorquotations_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_VENDORQUOTATIONS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_vendorquotations_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_VENDORQUOTATIONS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_vendorquotations_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_VENDORQUOTATIONS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_vendorquotations_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_VENDORQUOTATIONS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_vendorquotations_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_VENDORQUOTATIONS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_VENDORS
resource "azuread_group" "dls_gtsap_vendors_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_VENDORS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_vendors_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_VENDORS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_vendors_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_VENDORS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_vendors_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_VENDORS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_vendors_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_VENDORS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_vendors_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_VENDORS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_WHOLESALEPRICES
resource "azuread_group" "dls_gtsap_wholesaleprices_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_WHOLESALEPRICES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_wholesaleprices_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_WHOLESALEPRICES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_wholesaleprices_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_WHOLESALEPRICES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_wholesaleprices_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_WHOLESALEPRICES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_wholesaleprices_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_WHOLESALEPRICES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_wholesaleprices_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_WHOLESALEPRICES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# GTSAP_CONTRACTPRODUCT
resource "azuread_group" "dls_gtsap_contractproduct_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAP_CONTRACTPRODUCT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_contractproduct_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAP_CONTRACTPRODUCT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_contractproduct_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAP_CONTRACTPRODUCT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_contractproduct_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAP_CONTRACTPRODUCT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_contractproduct_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTSAP_CONTRACTPRODUCT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsap_contractproduct_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAP_CONTRACTPRODUCT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# GTVERSO
resource "azuread_group" "dls_gtverso_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTVERSO"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_group.ppm_devops_keskodev.id,
    data.azuread_group.ppm_devops_gtvalikoima.id,
    data.azuread_group.ppm_bus_dls_gt_ba.id,
    data.azuread_group.ppm_bus_dls_kdigital.id,
    azuread_service_principal.kvalikoima_databricks.id,
    data.azuread_service_principal.snowflake_0518.id,
    azuread_service_principal.gtkpartner_adb.id,
    azuread_service_principal.gtanalytics_adb.id,
    azuread_service_principal.retrobonus_adb.id,
  ]
}

resource "azuread_group" "dls_gtverso_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTVERSO"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtverso_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTVERSO"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.catman_adb.id,
  ]
}

resource "azuread_group" "dls_gtverso_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTVERSO"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_gtvalikoima.id,
    data.azuread_group.ppm_bus_dls_gt_ba.id,
    azuread_service_principal.kvalikoima_databricks.id,
    azuread_service_principal.qlik_gt.id,
    azuread_service_principal.gtanalytics_adb.id,
    azuread_service_principal.gtkpartner_adb.id,
    azuread_service_principal.retrobonus_adb.id,
    data.azuread_service_principal.ktv_adf.id,
  ]
}

resource "azuread_group" "dls_gtverso_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTVERSO"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtverso_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTVERSO"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.catman_adb.id,
  ]
}

# =======================================================================================
# GTWFO
resource "azuread_group" "dls_gtwfo_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTWFO"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_kedw_informatica_repository_admins.id,
  ]
}

resource "azuread_group" "dls_gtwfo_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTWFO"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtwfo_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTWFO"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.kcloud_int_funcapp.id,
    data.azuread_service_principal.int_adf.id,
    data.azuread_group.ppm_devops_gtwfo.id,
    data.azuread_service_principal.func_hr_wfo.id,
  ]
}

resource "azuread_group" "dls_gtwfo_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTWFO"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtwfo_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTWFO"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtwfo_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTWFO"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# KAI
resource "azuread_group" "dls_kai_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_KAI"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    "35eb4a89-1fa8-4067-85c2-e00315d641e8", # Latva-Pukkila Niilo
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_kai_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_KAI"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_kai_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_KAI"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.or_kai.id,
    "35eb4a89-1fa8-4067-85c2-e00315d641e8", # Latva-Pukkila Niilo
  ]
}

# =======================================================================================
# KFDM
resource "azuread_group" "dls_kfdm_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_KFDM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_bus_dls_gt_ba.id,
    azuread_service_principal.kvalikoima_databricks.id,
    azuread_service_principal.retrobonus_adb.id,
    azuread_service_principal.gtanalytics_adb.id,
    data.azuread_service_principal.snowflake_0518.id,
    data.azuread_group.ppm_devops_solitadev.id,
  ]
}

resource "azuread_group" "dls_kfdm_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_KFDM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_kfdm_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_KFDM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_kfdm_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_KFDM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.kvalikoima_databricks.id,
    azuread_service_principal.retrobonus_adb.id,
    data.azuread_group.ppm_bus_dls_gt_ba.id,
    azuread_service_principal.catman_adb.id,
    data.azuread_service_principal.ktv_adf.id,
    data.azuread_group.ppm_devops_gtvalikoima.id,
  ]
}

resource "azuread_group" "dls_kfdm_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_KFDM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_kfdm_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_KFDM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# KPARTNER
resource "azuread_group" "dls_kpartner_gld_gt_r" {
  display_name            = "${var.prefix_ad_group}_GLD_R_GT_KPARTNER"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_bus_dls_gt_ba.id,
  ]
}

resource "azuread_group" "dls_kpartner_gld_gt_w" {
  display_name            = "${var.prefix_ad_group}_GLD_W_GT_KPARTNER"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_kpartner_gld_gt_rw" {
  display_name            = "${var.prefix_ad_group}_GLD_RW_GT_KPARTNER"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.gtkpartner_adb.id,
  ]
}

# =======================================================================================
# KRUOKA
resource "azuread_group" "dls_kruoka_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_KRUOKA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.qlik_gt.id,
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_kruoka_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_KRUOKA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_kruoka_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_KRUOKA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.kruoka_databricks.id,
    data.azuread_service_principal.apim_kgroup.id,
  ]
}

resource "azuread_group" "dls_kruoka_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_KRUOKA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_kruoka_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_KRUOKA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_kruoka_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_KRUOKA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# LUMI
resource "azuread_group" "dls_lumi_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_LUMI"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_lumi_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_LUMI"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_lumi_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_LUMI"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_group.ppm_devops_keskodev.id,
    data.azuread_service_principal.lumi_adf.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

# ---------------------------------------------------------------------------------------
# LUMI_SUBFLD
resource "azuread_group" "dls_lumi_subfld_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_LUMI_SUBFLD"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_lumi_flags_raw_nat_r.id,
    azuread_group.dls_lumi_flags_raw_nat_w.id,
    azuread_group.dls_lumi_flags_raw_nat_rw.id,
  ]
}

# ---------------------------------------------------------------------------------------
# LUMI_FLAGS
resource "azuread_group" "dls_lumi_flags_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_LUMI_FLAGS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_lumi_flags_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_LUMI_FLAGS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_lumi_flags_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_LUMI_FLAGS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# NESTE
resource "azuread_group" "dls_neste_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_NESTE"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_platform.id,
    data.azuread_group.ppm_bus_dls_kdigital.id,
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_neste_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_NESTE"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.storageapi_funcapp.id,
    data.azuread_service_principal.centralised_apim.id,
  ]
}

resource "azuread_group" "dls_neste_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_NESTE"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.neste_databricks.id,
  ]
}

resource "azuread_group" "dls_neste_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_NESTE"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_platform.id,
  ]
}

resource "azuread_group" "dls_neste_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_NESTE"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_neste_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_NESTE"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# PCM
resource "azuread_group" "dls_pcm_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_PCM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_group.ppm_devops_keskodev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_pcm_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_PCM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_pcm_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_PCM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.lumi_adf.id,
  ]
}

# =======================================================================================
# POSTI
resource "azuread_group" "dls_posti_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_POSTI"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_posti_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_POSTI"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_posti_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_POSTI"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_group.ppm_devops_keskodev.id,
    data.azuread_service_principal.lumi_adf.id,
    data.azuread_service_principal.kesko_adf.id,
  ]
}

resource "azuread_group" "dls_posti_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_POSTI"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_group.ppm_devops_keskodev.id,
  ]
}

resource "azuread_group" "dls_posti_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_POSTI"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_posti_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_POSTI"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# PROFX
resource "azuread_group" "dls_profx_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_PROFX"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_dls_devops_or.id,
  ]
}

resource "azuread_group" "dls_profx_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_PROFX"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_profx_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_PROFX"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_inb_eh.id,
  ]
}

# =======================================================================================
# RETROBONUS
resource "azuread_group" "dls_retrobonus_gld_gt_r" {
  display_name            = "${var.prefix_ad_group}_GLD_R_GT_RETROBONUS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_bus_dls_gt_ba.id,
    data.azuread_group.ppm_bus_dls_kdigital.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_retrobonus_gld_gt_w" {
  display_name            = "${var.prefix_ad_group}_GLD_W_GT_RETROBONUS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_retrobonus_gld_gt_rw" {
  display_name            = "${var.prefix_ad_group}_GLD_RW_GT_RETROBONUS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.retrobonus_adb.id,
  ]
}

# =======================================================================================
# RTCOM
resource "azuread_group" "dls_rtcom_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_RTCOM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_bus_dls_kdigital.id,
    data.azuread_group.ppm_dls_devops_or.id,
  ]
}

resource "azuread_group" "dls_rtcom_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_RTCOM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_rtcom_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_RTCOM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_inb_eh.id,
  ]
}

resource "azuread_group" "dls_rtcom_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_RTCOM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_dls_devops_or.id,
  ]
}

resource "azuread_group" "dls_rtcom_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_RTCOM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_rtcom_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_RTCOM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_inb_eh.id,
  ]
}

# =======================================================================================
# RXPOS
resource "azuread_group" "dls_rxpos_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_RXPOS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_bus_dls_kdigital.id,
    data.azuread_group.ppm_dls_devops_or.id,
  ]
}

resource "azuread_group" "dls_rxpos_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_RXPOS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_rxpos_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_RXPOS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_inb_eh.id,
  ]
}

resource "azuread_group" "dls_rxpos_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_RXPOS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_dls_devops_or.id,
  ]
}

resource "azuread_group" "dls_rxpos_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_RXPOS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_rxpos_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_RXPOS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_inb_eh.id,
  ]
}

# =======================================================================================
# RXSAP
resource "azuread_group" "dls_rxsap_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_RXSAP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_bus_dls_kdigital.id,
    data.azuread_group.ppm_dls_devops_or.id,
    data.azuread_service_principal.snowflake_central.id,
  ]
}

resource "azuread_group" "dls_rxsap_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_RXSAP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_rxsap_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_RXSAP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_inb_eh.id,
    data.azuread_service_principal.kesko_adf.id,
  ]
}

resource "azuread_group" "dls_rxsap_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_RXSAP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_dls_devops_or.id,
  ]
}

resource "azuread_group" "dls_rxsap_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_RXSAP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_rxsap_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_RXSAP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_inb_eh.id,
  ]
}

# =======================================================================================
# SLFRC
resource "azuread_group" "dls_slfrc_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_SLFRC"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.salesforce_adb.id,
  ]
}

resource "azuread_group" "dls_slfrc_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_SLFRC"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_slfrc_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_SLFRC"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.attrbmodeling_slfrc.id,
  ]
}

resource "azuread_group" "dls_slfrc_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_SLFRC"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_slfrc_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_SLFRC"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_slfrc_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_SLFRC"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.attrbmodeling_slfrc.id,
    azuread_service_principal.salesforce_adb.id,
  ]
}

# =======================================================================================
# TBTRK
resource "azuread_group" "dls_tbtrk_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_TBTRK"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_platform.id,
    data.azuread_group.ppm_natural_read_gt_tobtrac.id
  ]
}

resource "azuread_group" "dls_tbtrk_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_TBTRK"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.kcloud_int_funcapp.id,
    data.azuread_group.ppm_inb_tbtrk.id
  ]
}

resource "azuread_group" "dls_tbtrk_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_TBTRK"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.func_hr_wfo.id,
  ]
}

resource "azuread_group" "dls_tbtrk_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_TBTRK"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_tbtrk_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_TBTRK"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_tbtrk_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_TBTRK"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# TDMIGRATION
resource "azuread_group" "dls_tdmigration_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_TDMIGRATION"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_keskodev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_tdmigration_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_TDMIGRATION"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_tdmigration_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_TDMIGRATION"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.lumi_adf.id,
  ]
}

# =======================================================================================
# TERADATA
resource "azuread_group" "dls_teradata_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_TERADATA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_group.ppm_devops_keskodev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_teradata_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_TERADATA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_teradata_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_TERADATA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.lumi_adf.id,
  ]
}

# =======================================================================================
# TOS
resource "azuread_group" "dls_tos_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_TOS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_gtkampanja.id,
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_tos_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_TOS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_tos_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_TOS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.catman_adb.id,
    data.azuread_service_principal.apim_kgroup.id,
  ]
}

resource "azuread_group" "dls_tos_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_TOS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_gtkampanja.id,
  ]
}

resource "azuread_group" "dls_tos_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_TOS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_tos_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_TOS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.int_adf.id,
    azuread_service_principal.catman_adb.id,
  ]
}

resource "azuread_group" "dls_tos_gld_gt_r" {
  display_name            = "${var.prefix_ad_group}_GLD_R_GT_TOS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.kvalikoima_databricks.id,
    data.azuread_service_principal.ktv_adf.id,
    data.azuread_group.ppm_devops_gtkampanja.id,
  ]
}

resource "azuread_group" "dls_tos_gld_gt_w" {
  display_name            = "${var.prefix_ad_group}_GLD_W_GT_TOS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_tos_gld_gt_rw" {
  display_name            = "${var.prefix_ad_group}_GLD_RW_GT_TOS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.catman_adb.id,
  ]
}

# =======================================================================================
# ZETES
resource "azuread_group" "dls_zetes_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_ZETES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_zetes_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_ZETES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_zetes_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_ZETES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.zetes_funcapp.id,
  ]
}

# =======================================================================================
# PRIDES
resource "azuread_group" "dls_prides_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_PRIDES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.eslist_funcapp.id,
  ]
}

resource "azuread_group" "dls_prides_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_PRIDES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.centralised_apim.id,
  ]
}

resource "azuread_group" "dls_prides_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_PRIDES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.catman_adb.id,
  ]
}

# =======================================================================================
# GTSAPACR
resource "azuread_group" "dls_gtsapacr_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTSAPACR"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_group.ppm_devops_keskodev.id,
    data.azuread_group.ppm_bus_dls_gt_ba.id,
    data.azuread_group.ppm_devops_gtkesprodata.id,
    data.azuread_group.ppm_devops_gtvalikoima.id,
    azuread_service_principal.gtanalytics_adb.id,
    azuread_service_principal.gtkpartner_adb.id,
    data.azuread_service_principal.snowflake_0518.id,
    azuread_service_principal.catman_adb.id,
    azuread_group.adb_app_gtbusinessanalysts.id,
  ]
}

resource "azuread_group" "dls_gtsapacr_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTSAPACR"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsapacr_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTSAPACR"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.aecorsoft_sink.id,
    azuread_service_principal.catman_adb.id,
    data.azuread_group.ppm_devops_platform.id,
  ]
}

resource "azuread_group" "dls_gtsapacr_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTSAPACR"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtsapacr_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTSAPACR"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.catman_adb.id
  ]
}

# =======================================================================================
# KERAYS
resource "azuread_group" "dls_kerays_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_KERAYS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.qlik_gt.id,
  ]
}

resource "azuread_group" "dls_kerays_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_KERAYS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_kerays_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_KERAYS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_platform.id,
  ]
}

resource "azuread_group" "dls_kerays_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_KERAYS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_kerays_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_KERAYS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_kerays_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_KERAYS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_platform.id,
  ]
}

# =======================================================================================
# DESCARTES
resource "azuread_group" "dls_descartes_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_DESCARTES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_descartes_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_DESCARTES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.centralised_apim.id,
  ]
}

resource "azuread_group" "dls_descartes_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_DESCARTES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_descartes_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_DESCARTES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_descartes_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_DESCARTES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_descartes_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_DESCARTES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# CLM
resource "azuread_group" "dls_clm_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_CLM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
    data.azuread_user.kesko_jukka_kemppinen.object_id,
    data.azuread_group.ppm_kedw_informatica_domain_admins.id,
    data.azuread_service_principal.snowflake_central.id,
  ]
}

resource "azuread_group" "dls_clm_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_CLM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.microsoft_eventhubs.id,
    azuread_service_principal.clm_adb.id,
    data.azuread_group.ppm_devops_solitadev.id,
  ]
}

resource "azuread_group" "dls_clm_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_CLM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_clm_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_CLM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.clm_adb.id,
  ]
}

# ---------------------------------------------------------------------------------------
# CLM_SUBFLD
resource "azuread_group" "dls_clm_subfld_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_CLM_SUBFLD"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_clm_customer_raw_nat_r.id,
    azuread_group.dls_clm_customer_raw_nat_rw.id,
    azuread_group.dls_clm_loyaltytransaction_raw_nat_r.id,
    azuread_group.dls_clm_loyaltytransaction_raw_nat_rw.id,
  ]
}

resource "azuread_group" "dls_clm_subfld_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_CLM_SUBFLD"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_clm_customer_cur_nat_r.id,
    azuread_group.dls_clm_customer_cur_nat_rw.id,
    azuread_group.dls_clm_loyaltytransaction_cur_nat_r.id,
    azuread_group.dls_clm_loyaltytransaction_cur_nat_rw.id,
  ]
}

# ---------------------------------------------------------------------------------------
# CLM_CUSTOMER
resource "azuread_group" "dls_clm_customer_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_CLM_CUSTOMER"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_clm_customer_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_CLM_CUSTOMER"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.wfo_edw.id,
    data.azuread_service_principal.centralised_apim.id,
  ]
}

resource "azuread_group" "dls_clm_customer_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_CLM_CUSTOMER"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_clm_customer_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_CLM_CUSTOMER"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# ---------------------------------------------------------------------------------------
# CLM_LOYALTYTRANSACTION
resource "azuread_group" "dls_clm_loyaltytransaction_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_CLM_LOYALTYTRANSACTION"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_clm_loyaltytransaction_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_CLM_LOYALTYTRANSACTION"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.wfo_edw.id,
    data.azuread_service_principal.clm_funcapp.id,
  ]
}

resource "azuread_group" "dls_clm_loyaltytransaction_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_CLM_LOYALTYTRANSACTION"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_clm_loyaltytransaction_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_CLM_LOYALTYTRANSACTION"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# SNOWFLAKE EDW (TERADATA RAMP DOWN)
resource "azuread_group" "dls_snowedw_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_SNOWEDW"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_snowedw_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_SNOWEDW"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_kedw_td_asm.id,
  ]
}

# =======================================================================================
# BRIC
resource "azuread_group" "dls_bric_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_BRIC"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_bric_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_BRIC"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.lumi_adf.id,
  ]
}
# =======================================================================================
# BIGQUERY
resource "azuread_group" "dls_bigquery_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_BIGQUERY"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_0518.id,
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_user.kesko_jarno_martikainen.id,
  ]
}

resource "azuread_group" "dls_bigquery_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_BIGQUERY"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# FEEDBUILDER 
resource "azuread_group" "dls_feedbuilder_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_FEEDBUILDER"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_feedbuilder_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_FEEDBUILDER"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_0518.id,
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.int_adf.id,
    data.azuread_group.ppm_devops_platform.id,
  ]
}

#=======================================================================================
#TPS
resource "azuread_group" "dls_tps_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_TPS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_group.ppm_devops_gtvalikoima.id,
    data.azuread_service_principal.snowflake_0518.id,
    data.azuread_group.ppm_bus_dls_gt_ba.id,
    azuread_service_principal.or_kai.id,
    azuread_group.adb_app_gtbusinessanalysts.id,
  ]
}

resource "azuread_group" "dls_tps_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_TPS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.tps_funcapp.id,
    azuread_service_principal.catman_adb.id,
  ]
}
# =======================================================================================
# KDAM
resource "azuread_group" "dls_kdam_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_KDAM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_0518.id,
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_group.ppm_devops_keskodev.id,
  ]
}

resource "azuread_group" "dls_kdam_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_KDAM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members                 = []
}

# =======================================================================================
# DAGMAR
resource "azuread_group" "dls_dagmar_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_DAGMAR"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_group.ppm_devops_keskodev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_dagmar_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_DAGMAR"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# CNP
resource "azuread_group" "dls_cnp_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_CNP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.gtanalytics_adb.id,
    data.azuread_service_principal.snowflake_0518.id,
    data.azuread_group.ppm_bus_dls_gt_ba.id,
    data.azuread_group.ppm_devops_solitadev.id,
  ]
}

resource "azuread_group" "dls_cnp_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_CNP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.cnp_adb.id
  ]
}
resource "azuread_group" "dls_cnp_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_CNP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.gtanalytics_adb.id,
    data.azuread_group.ppm_bus_dls_gt_ba.id,
    data.azuread_service_principal.snowflake_0518.id,
    data.azuread_group.ppm_devops_solitadev.id,
  ]
}

resource "azuread_group" "dls_cnp_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_CNP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.cnp_adb.id
  ]
}


# =======================================================================================

# GTKESPRO
resource "azuread_group" "dls_gtkespro_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTKESPRO"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.qlik_gt.id,
  ]
}

resource "azuread_group" "dls_gtkespro_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTKESPRO"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtkespro_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTKESPRO"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtkespro_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTKESPRO"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.qlik_gt.id,
  ]
}

resource "azuread_group" "dls_gtkespro_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTKESPRO"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtkespro_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTKESPRO"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# GTKESPRO_SUBFLD
resource "azuread_group" "dls_gtkespro_subfld_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTKESPRO_SUBFLD"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_gtkespro_werp_raw_nat_r.id,
    azuread_group.dls_gtkespro_werp_raw_nat_w.id,
    azuread_group.dls_gtkespro_werp_raw_nat_rw.id,
  ]
}

resource "azuread_group" "dls_gtkespro_subfld_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTKESPRO_SUBFLD"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_gtkespro_werp_cur_nat_r.id,
    azuread_group.dls_gtkespro_werp_cur_nat_w.id,
    azuread_group.dls_gtkespro_werp_cur_nat_rw.id,
  ]
}

# GTKESPRO_WERP
resource "azuread_group" "dls_gtkespro_werp_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTKESPRO_WERP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtkespro_werp_raw_nat_w" {
  display_name            = "${var.prefix_ad_group}_RAW_W_NAT_GTKESPRO_WERP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtkespro_werp_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTKESPRO_WERP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtkespro_werp_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTKESPRO_WERP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtkespro_werp_cur_nat_w" {
  display_name            = "${var.prefix_ad_group}_CUR_W_NAT_GTKESPRO_WERP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtkespro_werp_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTKESPRO_WERP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# GTKESPRO_WERP_SUBFLD
resource "azuread_group" "dls_gtkespro_werp_subfld_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTKESPRO_WERP_SUBFLD"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_gtkespro_werp_eriksson_raw_nat_r.id,
    azuread_group.dls_gtkespro_werp_eriksson_raw_nat_rw.id,
    azuread_group.dls_gtkespro_werp_reinin_raw_nat_r.id,
    azuread_group.dls_gtkespro_werp_reinin_raw_nat_rw.id
  ]
}

resource "azuread_group" "dls_gtkespro_werp_subfld_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTKESPRO_WERP_SUBFLD"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_group.dls_gtkespro_werp_eriksson_cur_nat_r.id,
    azuread_group.dls_gtkespro_werp_eriksson_cur_nat_rw.id,
    azuread_group.dls_gtkespro_werp_reinin_cur_nat_r.id,
    azuread_group.dls_gtkespro_werp_reinin_cur_nat_rw.id,
  ]
}



# GTKESPRO_WERP_REININ
resource "azuread_group" "dls_gtkespro_werp_reinin_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTKESPRO_WERP_REININ"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtkespro_werp_reinin_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTKESPRO_WERP_REININ"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}
resource "azuread_group" "dls_gtkespro_werp_reinin_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTKESPRO_WERP_REININ"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.qlik_gt.id
  ]
}
resource "azuread_group" "dls_gtkespro_werp_reinin_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTKESPRO_WERP_REININ"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}


# GTKESPRO_WERP_ERIKSSON
resource "azuread_group" "dls_gtkespro_werp_eriksson_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GTKESPRO_WERP_ERIKSSON"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtkespro_werp_eriksson_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GTKESPRO_WERP_ERIKSSON"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_gtkespro_werp_eriksson_cur_nat_r" {
  display_name            = "${var.prefix_ad_group}_CUR_R_NAT_GTKESPRO_WERP_ERIKSSON"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.qlik_gt.id
  ]
}
resource "azuread_group" "dls_gtkespro_werp_eriksson_cur_nat_rw" {
  display_name            = "${var.prefix_ad_group}_CUR_RW_NAT_GTKESPRO_WERP_ERIKSSON"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# SEMMI
resource "azuread_group" "dls_semmi_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_SEMMI"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_semmi_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_SEMMI"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_kespro_contributor.id,
  ]
}

# =======================================================================================
# KONVEHTI
resource "azuread_group" "dls_konvehti_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_KONVEHTI"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_0518.id,
    data.azuread_group.ppm_devops_solitadev.id,
  ]
}

resource "azuread_group" "dls_konvehti_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_KONVEHTI"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# KTAVARA
resource "azuread_group" "dls_ktavara_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_KTAVARA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.catman_adb.id,
    data.azuread_service_principal.snowflake_0518.id,
    data.azuread_group.ppm_devops_solitadev.id,
  ]
}

resource "azuread_group" "dls_ktavara_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_KTAVARA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# COSMOS
resource "azuread_group" "dls_cosmos_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_COSMOS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_0518.id,
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_user.kesko_jukka_kemppinen.object_id,
  ]
}

resource "azuread_group" "dls_cosmos_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_COSMOS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.int_adf.id,
  ]
}

# =======================================================================================
# VALVIRA
resource "azuread_group" "dls_valvira_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_VALVIRA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_valvira_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_VALVIRA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# KKYLA
resource "azuread_group" "dls_kkyla_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_KKYLA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_platform.id,
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_kkyla_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_KKYLA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# == Exports ===================================================================================
# LUMI
resource "azuread_group" "dls_lumi_exports_r" {
  display_name            = "${var.prefix_ad_group}_EXPORTS_R_LUMI"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
  ]
}

resource "azuread_group" "dls_lumi_exports_rw" {
  display_name            = "${var.prefix_ad_group}_EXPORTS_RW_LUMI"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_0518.id,
    data.azuread_service_principal.lumi_adf.id,
  ]
}

# =======================================================================================
# RETROBONUS
resource "azuread_group" "dls_retrobonus_exports_r" {
  display_name            = "${var.prefix_ad_group}_EXPORTS_R_RETROBONUS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_user.kesko_marko_inkinen.id,
  ]
}

resource "azuread_group" "dls_retrobonus_exports_rw" {
  display_name            = "${var.prefix_ad_group}_EXPORTS_RW_RETROBONUS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.retrobonus_adb.id,
  ]
}

# =======================================================================================
# KBUSINESS
resource "azuread_group" "dls_kbusiness_exports_r" {
  display_name            = "${var.prefix_ad_group}_EXPORTS_R_KBUSINESS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_kbusiness_exports_rw" {
  display_name            = "${var.prefix_ad_group}_EXPORTS_RW_KBUSINESS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.kesko_adf.id,
    data.azuread_service_principal.aks_platform.id,
  ]
}

#=============================================================================
#WMS
resource "azuread_group" "dls_wms_gld_gt_r" {
  display_name            = "${var.prefix_ad_group}_GLD_R_GT_WMS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [

  ]
}

resource "azuread_group" "dls_wms_gld_gt_rw" {
  display_name            = "${var.prefix_ad_group}_GLD_RW_GT_WMS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.catman_adb.id,
  ]
}

# =======================================================================================
# KPIM
resource "azuread_group" "dls_kpim_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_KPIM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_kpim_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_KPIM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members                 = []
}

# =======================================================================================
# FMI
resource "azuread_group" "dls_fmi_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_FMI"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_fmi_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_FMI"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# MINTEC
resource "azuread_group" "dls_mintec_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_MINTEC"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_user.kesko_pontus_lindroos.id,
    data.azuread_service_principal.snowflake_0518.id,
    data.azuread_group.ppm_devops_solitadev.id,
  ]
}

resource "azuread_group" "dls_mintec_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_MINTEC"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# STATFIN
resource "azuread_group" "dls_statfin_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_STATFIN"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_0518.id,
    data.azuread_service_principal.snowflake_central.id,
    data.azuread_group.ppm_devops_solitadev.id,
  ]
}

resource "azuread_group" "dls_statfin_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_STATFIN"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# SISU
resource "azuread_group" "dls_sisu_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_SISU"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
    data.azuread_group.ppm_devops_gtkesprodata.id
  ]
}

resource "azuread_group" "dls_sisu_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_SISU"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# CTAG - Car Trade AG analytics API
resource "azuread_group" "dls_ctag_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_CTAG"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_ctag_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_CTAG"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# KESPROLASKENTA
resource "azuread_group" "dls_kesprolaskenta_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_KESPROLASKENTA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_kesprolaskenta_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_KESPROLASKENTA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# KTV
resource "azuread_group" "dls_ktv_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_KTV"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_0518.id,
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_user.kesko_joonas_heikela.id,
  ]
}

resource "azuread_group" "dls_ktv_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_KTV"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.ktv_funcapp.id
  ]
}

# =======================================================================================
# WEB DATA GA4 - Google Analytics 4 BigQuery Export
resource "azuread_group" "dls_webdataga4_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_WEBDATAGA4"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_webdataga4_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_WEBDATAGA4"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# ENERKEY
resource "azuread_group" "dls_enerkey_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_ENERKEY"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_enerkey_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_ENERKEY"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# KRUOKAKAUPPA
resource "azuread_group" "dls_kruokakauppa_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_KRUOKAKAUPPA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
    data.azuread_user.kesko_joonas_heikela.id,
  ]
}

resource "azuread_group" "dls_kruokakauppa_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_KRUOKAKAUPPA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.ktv_funcapp.id
  ]
}

# =======================================================================================
# REVIT
resource "azuread_group" "dls_revit_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_REVIT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
    data.azuread_user.kesko_joonas_heikela.id,
  ]
}

resource "azuread_group" "dls_revit_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_REVIT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# SHAREPOINT
resource "azuread_group" "dls_sharepoint_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_SHAREPOINT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_sharepoint_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_SHAREPOINT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# INTERSPORT
resource "azuread_group" "dls_intersport_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_INTERSPORT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_intersport_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_INTERSPORT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.apim_kgroup.id,
  ]
}

# =======================================================================================
# OPIM
resource "azuread_group" "dls_opim_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_OPIM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_opim_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_OPIM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# TEKSO
resource "azuread_group" "dls_tekso_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_TEKSO"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_tekso_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_TEKSO"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.apim_kgroup.id,
    data.azuread_service_principal.nos.object_id,
  ]
}

# =======================================================================================
# GRANLUND
resource "azuread_group" "dls_granlund_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_GRANLUND"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_granlund_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_GRANLUND"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# MSAX
resource "azuread_group" "dls_msax_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_MSAX"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_msax_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_MSAX"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.apim_kgroup.id,
    data.azuread_service_principal.nos.object_id,
  ]
}

# =======================================================================================
# COMPETITORPRICES
resource "azuread_group" "dls_competitorprices_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_COMPETITORPRICES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_competitorprices_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_COMPETITORPRICES"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_user.kesko_robovias.id,
  ]
}

# =======================================================================================
# LT
resource "azuread_group" "dls_lt_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_LT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_lt_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_LT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# OSAP
resource "azuread_group" "dls_osap_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_OSAP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
    data.azuread_service_principal.snowflake_btt.id,
  ]
}

resource "azuread_group" "dls_osap_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_OSAP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.apim_kgroup.id,
  ]
}

# =======================================================================================
# CGI
resource "azuread_group" "dls_cgi_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_CGI"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_ow.id,
    data.azuread_group.ppm_ksnow_ow_data_devops_natural.id,
    data.azuread_group.ppm_ksnow_ow_data_devops_masked.id,
  ]
}

resource "azuread_group" "dls_cgi_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_CGI"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.encode_convert_funcapp.object_id,
  ]
}

# =======================================================================================
# MANDATUM
resource "azuread_group" "dls_mandatum_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_MANDATUM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_ow.id,
    data.azuread_group.ppm_ksnow_ow_data_devops_natural.id,
    data.azuread_group.ppm_ksnow_ow_data_devops_masked.id,
  ]
}

resource "azuread_group" "dls_mandatum_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_MANDATUM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}
# =======================================================================================
# SAPWELL
resource "azuread_group" "dls_sapwell_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_SAPWELL"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_sapwell_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_SAPWELL"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.nos.object_id,
  ]
}

# =======================================================================================
# CRASMAN
resource "azuread_group" "dls_crasman_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_CRASMAN"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_crasman_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_CRASMAN"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.nos.object_id,
  ]
}

# =======================================================================================
# RELEX
resource "azuread_group" "dls_relex_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_RELEX"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_relex_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_RELEX"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.nos.object_id,
  ]
}

# =======================================================================================
# ONNIAWS
resource "azuread_group" "dls_onniaws_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_ONNIAWS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_btt.id,
    data.azuread_group.ppm_devops_solitadev.id,
  ]
}

resource "azuread_group" "dls_onniaws_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_ONNIAWS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.apim_kgroup.id,
  ]
}

# =======================================================================================
# LOGENTIA
resource "azuread_group" "dls_logentia_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_LOGENTIA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_0518.id,
    data.azuread_group.ppm_devops_solitadev.id,
  ]
}

resource "azuread_group" "dls_logentia_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_LOGENTIA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# BTTRECEIPTARCHIVE
resource "azuread_group" "dls_bttreceiptarchive_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_BTTRECEIPTARCHIVE"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_0518.id,
    data.azuread_group.ppm_devops_solitadev.id,
  ]
}

resource "azuread_group" "dls_bttreceiptarchive_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_BTTRECEIPTARCHIVE"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.or_app.object_id,
  ]
}

# =======================================================================================
# KEVEL
resource "azuread_group" "dls_kevel_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_KEVEL"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_0518.id,
    data.azuread_group.ppm_devops_solitadev.id,
  ]
}

resource "azuread_group" "dls_kevel_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_KEVEL"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# ANAPLAN
resource "azuread_group" "dls_anaplan_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_ANAPLAN"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_0518.id,
    data.azuread_group.ppm_devops_solitadev.id,
  ]
}

resource "azuread_group" "dls_anaplan_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_ANAPLAN"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.kesko_adf.id,
  ]
}

# =======================================================================================
# LUKE
resource "azuread_group" "dls_luke_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_LUKE"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_luke_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_LUKE"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.ktoimittaja_adf.id
  ]
}

# =======================================================================================
# ONFICRM
resource "azuread_group" "dls_onficrm_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_ONFICRM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_btt.id,
  ]
}

resource "azuread_group" "dls_onficrm_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_ONFICRM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.apim_kgroup.id,
  ]
}

# =======================================================================================
# EXPANA
resource "azuread_group" "dls_expana_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_EXPANA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_expana_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_EXPANA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.aks_platform.id,
  ]
}

# =======================================================================================
# KVALIKOIMA
resource "azuread_group" "dls_kvalikoima_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_KVALIKOIMA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_kvalikoima_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_KVALIKOIMA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.aks_platform.id,
  ]
}

# =======================================================================================
# CTCDM
resource "azuread_group" "dls_ctcdm_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_CTCDM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_central.id,
  ]
}

resource "azuread_group" "dls_ctcdm_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_CTCDM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# KID
resource "azuread_group" "dls_kid_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_KID"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_kid_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_KID"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    "4ed2361c-913a-4c82-b7c6-3fd122285482", # ext.prashant.deherkar@kesko.fi
    data.azuread_service_principal.kid_log_processor.id,
  ]
}

# =======================================================================================
# SSM
resource "azuread_group" "dls_ssm_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_SSM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_ssm_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_SSM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# DMS
resource "azuread_group" "dls_dms_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_DMS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_central.id,
  ]
}

resource "azuread_group" "dls_dms_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_DMS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# IP1
resource "azuread_group" "dls_ip1_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_IP1"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_central.id,
  ]
}

resource "azuread_group" "dls_ip1_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_IP1"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# VEHICLEDATA
resource "azuread_group" "dls_vehicledata_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_VEHICLEDATA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_central.id,
  ]
}

resource "azuread_group" "dls_vehicledata_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_VEHICLEDATA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# OFP
resource "azuread_group" "dls_ofp_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_OFP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_central.id,
  ]
}

resource "azuread_group" "dls_ofp_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_OFP"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# SCRAPER
resource "azuread_group" "dls_scraper_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_SCRAPER"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_scraper_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_SCRAPER"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.aks_platform.id,
  ]
}

# =======================================================================================
# ONNIMARKKINAT
resource "azuread_group" "dls_onnimarkkinat_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_ONNIMARKKINAT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_central.id,
  ]
}

resource "azuread_group" "dls_onnimarkkinat_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_ONNIMARKKINAT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# CMDM
resource "azuread_group" "dls_cmdm_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_CMDM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_central.id,
  ]
}

resource "azuread_group" "dls_cmdm_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_CMDM"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# KRAUTAKAMPANJAT
resource "azuread_group" "dls_krautakampanjat_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_KRAUTAKAMPANJAT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_central.id,
  ]
}

resource "azuread_group" "dls_krautakampanjat_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_KRAUTAKAMPANJAT"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# HOGIA
resource "azuread_group" "dls_hogia_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_HOGIA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_ow.id,
    data.azuread_group.ppm_ksnow_ow_data_devops_natural.id,
    data.azuread_group.ppm_ksnow_ow_data_devops_masked.id,
  ]
}

resource "azuread_group" "dls_hogia_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_HOGIA"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

# =======================================================================================
# PLATFORMSRV
resource "azuread_group" "dls_platformsrv_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_PLATFORMSRV"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_group.ppm_devops_solitadev.id,
    data.azuread_service_principal.snowflake_0518.id,
  ]
}

resource "azuread_group" "dls_platformsrv_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_PLATFORMSRV"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.aks_platform.id,
  ]
}

# =======================================================================================
# LCS
resource "azuread_group" "dls_lcs_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_LCS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
  ]
}

resource "azuread_group" "dls_lcs_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_LCS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    # REMOVE COMMENT ONCE SP EXISTS
    # data.azuread_service_principal.lt_sposs.id,
  ]
}

# =======================================================================================
# SISUAZ
resource "azuread_group" "dls_sisuaz_raw_nat_r" {
  display_name            = "${var.prefix_ad_group}_RAW_R_NAT_SISUAZ"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.snowflake_central.id,
  ]
}

resource "azuread_group" "dls_sisuaz_raw_nat_rw" {
  display_name            = "${var.prefix_ad_group}_RAW_RW_NAT_SISUAZ"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_service_principal.sisu_r2.id,
  ]
}
