# ---------------------------------------------------------------------------------------------
# advancedanalytics-adb
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "advancedanalytics_adb" {
  display_name = "${var.prefix_sp}-advancedanalytics-adb-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "advancedanalytics_adb" {
  application_id = azuread_application.advancedanalytics_adb.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "advancedanalytics_adb" {
  service_principal_id = azuread_service_principal.advancedanalytics_adb.id
  end_date             = var.pwd_expr_date
}
