output group_access_admins_platform {
  value = {
    id           = data.azuread_group.ppm_access_admins_platform.id
    display_name = data.azuread_group.ppm_access_admins_platform.display_name
  }
}

output group_admins_platform {
  value = {
    id           = data.azuread_group.ppm_admins_platform.id
    display_name = data.azuread_group.ppm_admins_platform.display_name
  }
}

output group_devops_futuricedev {
  value = {
    id           = data.azuread_group.ppm_devops_futuricedev.id
    display_name = data.azuread_group.ppm_devops_futuricedev.display_name
  }
}

output group_devops_gtesl {
  value = {
    id           = data.azuread_group.ppm_devops_gtesl.id
    display_name = data.azuread_group.ppm_devops_gtesl.display_name
  }
}

output group_devops_gtkampanja {
  value = {
    id           = data.azuread_group.ppm_devops_gtkampanja.id
    display_name = data.azuread_group.ppm_devops_gtkampanja.display_name
  }
}

output group_devops_gtkesprodata {
  value = {
    id           = data.azuread_group.ppm_devops_gtkesprodata.id
    display_name = data.azuread_group.ppm_devops_gtkesprodata.display_name
  }
}

output group_devops_gtpim {
  value = {
    id           = data.azuread_group.ppm_devops_gtpim.id
    display_name = data.azuread_group.ppm_devops_gtpim.display_name
  }
}

output group_devops_gtvalikoima {
  value = {
    id           = data.azuread_group.ppm_devops_gtvalikoima.id
    display_name = data.azuread_group.ppm_devops_gtvalikoima.display_name
  }
}

output group_devops_gtwfo {
  value = {
    id           = data.azuread_group.ppm_devops_gtwfo.id
    display_name = data.azuread_group.ppm_devops_gtwfo.display_name
  }
}

output group_devops_keskodev {
  value = {
    id           = data.azuread_group.ppm_devops_keskodev.id
    display_name = data.azuread_group.ppm_devops_keskodev.display_name
  }
}

output group_devops_kval {
  value = {
    id           = data.azuread_group.ppm_devops_kval.id
    display_name = data.azuread_group.ppm_devops_kval.display_name
  }
}

output group_devops_or {
  value = {
    id           = data.azuread_group.ppm_devops_or.id
    display_name = data.azuread_group.ppm_devops_or.display_name
  }
}

output group_devops_platform {
  value = {
    id           = data.azuread_group.ppm_devops_platform.id
    display_name = data.azuread_group.ppm_devops_platform.display_name
  }
}

output group_devops_solitadev {
  value = {
    id           = data.azuread_group.ppm_devops_solitadev.id
    display_name = data.azuread_group.ppm_devops_solitadev.display_name
  }
}

output group_dls_admins {
  value = {
    id           = data.azuread_group.ppm_dls_admins.id
    display_name = data.azuread_group.ppm_dls_admins.display_name
  }
}

output group_dls_devops_or {
  value = {
    id           = data.azuread_group.ppm_dls_devops_or.id
    display_name = data.azuread_group.ppm_dls_devops_or.display_name
  }
}

output group_kedw_informatica_repository_admins {
  value = {
    id           = data.azuread_group.ppm_kedw_informatica_repository_admins.id
    display_name = data.azuread_group.ppm_kedw_informatica_repository_admins.display_name
  }
}

output group_kespro_contributor {
  value = {
    id           = data.azuread_group.ppm_kespro_contributor.id
    display_name = data.azuread_group.ppm_kespro_contributor.display_name
  }
}

output group_bus_dls_kdigital {
  value = {
    id           = data.azuread_group.ppm_bus_dls_kdigital.id
    display_name = data.azuread_group.ppm_bus_dls_kdigital.display_name
  }
}

output group_bronze_sap_data {
  value = {
    id           = data.azuread_group.ppm_bronze_sap_data.id
    display_name = data.azuread_group.ppm_bronze_sap_data.display_name
  }
}

output group_kruokakauppadeveloper {
  value = {
    id           = data.azuread_group.ppm_kruokakauppadeveloper.id
    display_name = data.azuread_group.ppm_kruokakauppadeveloper.display_name
  }
}

output group_adb_app_bttbusinessanalysts {
  value = {
    id           = data.azuread_group.ppm_adb_app_bttbusinessanalysts.id
    display_name = data.azuread_group.ppm_adb_app_bttbusinessanalysts.display_name
  }
}

output group_confluent_prod_admin {
  value = {
    id           = data.azuread_group.ppm_confluent_prod_admin.id
    display_name = data.azuread_group.ppm_confluent_prod_admin.display_name
  }
}
