locals {
  owners = [
    data.azuread_user.kesko_nico_miettinen.object_id,
    "7e945af3-edab-49b7-9809-a7161c6858ff", # MSI
    data.azuread_user.kesko_nakul_bansal.object_id,
  ]
}

locals {
  owners_old = [
    data.azuread_user.kesko_nico_miettinen.object_id,
    "7e945af3-edab-49b7-9809-a7161c6858ff", # MSI
  ]
}
