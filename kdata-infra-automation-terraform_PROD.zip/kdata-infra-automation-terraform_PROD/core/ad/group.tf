resource "azuread_group" "service_principals" {
  display_name            = "AZ_KDATA_PROD_SERVICE_PRINCIPALS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    azuread_service_principal.adb_metastore.id,
    azuread_service_principal.apim.id,
    azuread_service_principal.apim_authentication.id,
    azuread_service_principal.platform_devops.id,
    azuread_service_principal.securityreader.id,
    azuread_service_principal.platform_sharepoint.id,
    azuread_service_principal.advancedanalytics_adb.id,
    azuread_service_principal.aecorsoft_sink.id,
    azuread_service_principal.attrbmodeling_adfrm.id,
    azuread_service_principal.attrbmodeling_slfrc.id,
    azuread_service_principal.auditlogs_adb.id,
    azuread_service_principal.campaign_deltalake.id,
    azuread_service_principal.campaign_eventhub.id,
    azuread_service_principal.catman_adb.id,
    azuread_service_principal.controlm_adb.id,
    azuread_service_principal.controlm_adf.id,
    azuread_service_principal.ds_deltalake.id,
    azuread_service_principal.feedbuilder_qlik.id,
    azuread_service_principal.gtanalytics_adb.id,
    azuread_service_principal.gtkpartner_adb.id,
    azuread_service_principal.kpartner_dynamics.id,
    azuread_service_principal.kruoka_databricks.id,
    azuread_service_principal.kruoka_eventhub.id,
    azuread_service_principal.kvalikoima_databricks.id,
    azuread_service_principal.kvalikoima_dbwrite.id,
    azuread_service_principal.lumi_devops.id,
    azuread_service_principal.lumi_adb.id,
    azuread_service_principal.neste_databricks.id,
    azuread_service_principal.neste_eventhub.id,
    azuread_service_principal.or_terraform.id,
    azuread_service_principal.or_azdevops.id,
    azuread_service_principal.or_bookkeeping.id,
    azuread_service_principal.or_etl.id,
    azuread_service_principal.or_tobtrack.id,
    azuread_service_principal.or_datapower.id,
    azuread_service_principal.or_robot.id,
    azuread_service_principal.or_edw.id,
    azuread_service_principal.or_lastdaysales.id,
    azuread_service_principal.or_plussa.id,
    azuread_service_principal.or_selfsupervision.id,
    azuread_service_principal.or_kai.id,
    azuread_service_principal.or_nestedayend.id,
    azuread_service_principal.or_b2bdr.id,
    azuread_service_principal.or_match.id,
    azuread_service_principal.or_dbmaintenance.id,
    azuread_service_principal.or_deltalake.id,
    azuread_service_principal.or_companyinfo.id,
    azuread_service_principal.or_konvehti_fe.id,
    azuread_service_principal.or_flyway_sql.id,
    azuread_service_principal.pxm_devops.id,
    azuread_service_principal.pxm_eventhub.id,
    azuread_service_principal.qlik_gt.id,
    azuread_service_principal.retrobonus_adb.id,
    azuread_service_principal.wfo_edw.id,
    azuread_service_principal.zetes_devops.id,
    azuread_service_principal.kconfluent_devops.id,
  ]
}

resource "azuread_group" "or_sql_admin" {
  display_name            = "AZ_KDATA_PROD_OR_SQL_ADMIN"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members = [
    data.azuread_user.kesko_nakul_bansal.object_id,
    data.azuread_user.kesko_nico_miettinen.object_id,
    azuread_service_principal.or_flyway_sql.id,
  ]
}

resource "azuread_group" "platform_sql_admin" {
  display_name            = "${var.prefix_ad_group}_PLATFORM_SQL_ADMIN"
  owners                  = local.owners
  prevent_duplicate_names = false
  security_enabled        = true
  members = [
    data.azuread_user.kesko_nakul_bansal.object_id,
    data.azuread_user.kesko_nico_miettinen.object_id,
    azuread_service_principal.platform_devops.id,
    data.azuread_service_principal.infra.id,
  ]
}

# Power Putomate Users
resource "azuread_group" "powerplatform_devops" {
  display_name            = "${var.prefix_ad_group}_POWERPLATFORM_DEVOPS"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true

  lifecycle {
    ignore_changes = [members]
  }
}

resource "azuread_group" "streamlitapp_reader" {
  display_name            = "${var.prefix_ad_group}_STREAMLITAPP_READER"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members                 = [
    data.azuread_user.kesko_tiitus_kareno.id,
    data.azuread_user.kesko_ville_tarvonen.id,
    data.azuread_user.kesko_oskari_lehtonen.id,
    data.azuread_user.kesko_atte_makela.id,
  ]
}

resource "azuread_group" "streamlitapp_contributor" {
  display_name            = "${var.prefix_ad_group}_STREAMLITAPP_CONTRIBUTOR"
  owners                  = local.owners
  prevent_duplicate_names = true
  security_enabled        = true
  members                 = [
    data.azuread_user.kesko_tiitus_kareno.id,
    data.azuread_user.kesko_kalle_rasanen.id,
  ]
}
