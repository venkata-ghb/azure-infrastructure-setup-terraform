output msi_centralised_apim {
  value = {
    id             = data.azuread_service_principal.centralised_apim.id
    application_id = data.azuread_service_principal.centralised_apim.application_id
    display_name   = data.azuread_service_principal.centralised_apim.display_name
  }
}

output msi_unitycatalog {
  value = {
    id             = data.azuread_service_principal.unitycatalog.id
    application_id = data.azuread_service_principal.unitycatalog.application_id
    display_name   = data.azuread_service_principal.unitycatalog.display_name
  }
}

output msi_infra {
  value = {
    id             = data.azuread_service_principal.infra.id
    application_id = data.azuread_service_principal.infra.application_id
    display_name   = data.azuread_service_principal.infra.display_name
  }
}

output msi_ktv_adf {
  value = {
    id             = data.azuread_service_principal.ktv_adf.id
    application_id = data.azuread_service_principal.ktv_adf.application_id
    display_name   = data.azuread_service_principal.ktv_adf.display_name
  }
}

output msi_snowflake_0518 {
  value = {
    id             = data.azuread_service_principal.snowflake_0518.id
    application_id = data.azuread_service_principal.snowflake_0518.application_id
    display_name   = data.azuread_service_principal.snowflake_0518.display_name
  }
}

output msi_snowflake_central_notif {
  value = {
    id             = data.azuread_service_principal.snowflake_central_notif.id
    application_id = data.azuread_service_principal.snowflake_central_notif.application_id
    display_name   = data.azuread_service_principal.snowflake_central_notif.display_name
  }
}

output msi_snowflake_ct_notif {
  value = {
    id             = data.azuread_service_principal.snowflake_ct_notif.id
    application_id = data.azuread_service_principal.snowflake_ct_notif.application_id
    display_name   = data.azuread_service_principal.snowflake_ct_notif.display_name
  }
}

output msi_snowflake_gt_notif {
  value = {
    id             = data.azuread_service_principal.snowflake_gt_notif.id
    application_id = data.azuread_service_principal.snowflake_gt_notif.application_id
    display_name   = data.azuread_service_principal.snowflake_gt_notif.display_name
  }
}

output msi_snowflake_btt_notif {
  value = {
    id             = data.azuread_service_principal.snowflake_btt_notif.id
    application_id = data.azuread_service_principal.snowflake_btt_notif.application_id
    display_name   = data.azuread_service_principal.snowflake_btt_notif.display_name
  }
}

output msi_snowflake_dcr_gt_notif {
  value = {
    id             = data.azuread_service_principal.snowflake_dcr_gt_notif.id
    application_id = data.azuread_service_principal.snowflake_dcr_gt_notif.application_id
    display_name   = data.azuread_service_principal.snowflake_dcr_gt_notif.display_name
  }
}

output msi_snowflake_dcr_tester_notif {
  value = {
    id             = data.azuread_service_principal.snowflake_dcr_tester_notif.id
    application_id = data.azuread_service_principal.snowflake_dcr_tester_notif.application_id
    display_name   = data.azuread_service_principal.snowflake_dcr_tester_notif.display_name
  }
}

output msi_snowflake_ow_notif {
  value = {
    id             = data.azuread_service_principal.snowflake_ow_notif.id
    application_id = data.azuread_service_principal.snowflake_ow_notif.application_id
    display_name   = data.azuread_service_principal.snowflake_ow_notif.display_name
  }
}

output msi_aks_platform {
  value = {
    id             = data.azuread_service_principal.aks_platform.id
    application_id = data.azuread_service_principal.aks_platform.application_id
    display_name   = data.azuread_service_principal.aks_platform.display_name
  }
}

output msi_or {
  value = {
    id             = data.azuread_service_principal.or.id
    application_id = data.azuread_service_principal.or.application_id
    display_name   = data.azuread_service_principal.or.display_name
  }
}

output msi_apim_kgroup {
  value = {
    id             = data.azuread_service_principal.apim_kgroup.id
    application_id = data.azuread_service_principal.apim_kgroup.application_id
    display_name   = data.azuread_service_principal.apim_kgroup.display_name
  }
}
