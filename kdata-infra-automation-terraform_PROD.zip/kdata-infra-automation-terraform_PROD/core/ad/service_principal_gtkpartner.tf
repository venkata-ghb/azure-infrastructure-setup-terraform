# ---------------------------------------------------------------------------------------------
# gtkpartner-adb
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "gtkpartner_adb" {
  display_name = "${var.prefix_sp}-gtkpartner-adb-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "gtkpartner_adb" {
  application_id = azuread_application.gtkpartner_adb.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "gtkpartner_adb" {
  service_principal_id = azuread_service_principal.gtkpartner_adb.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}
