# Application for GT GenAI Marketing application
resource "azuread_application" "kgenaimarketing" {
    display_name            = "${var.prefix_sp}-gtgenai-marketing-sp"
    owners                  = local.owners
    prevent_duplicate_names = true

    api {
        known_client_applications      = []
        mapped_claims_enabled          = false
        requested_access_token_version = 1
    }

    required_resource_access {
        resource_app_id = "00000003-0000-0000-c000-000000000000"

        resource_access {
            id   = "e1fe6dd8-ba31-4d61-89e7-88639da4683d"
            type = "Scope"
        }
    }
    
    feature_tags {
        custom_single_sign_on = false
        enterprise            = true
        gallery               = false
        hide                  = false
    }
    
    app_role {
        allowed_member_types = [
            "User",
        ]
        description          = "Admin role"
        display_name         = "Admin"
        enabled              = true
        id                   = "d31c26f5-c999-4378-99ea-168cb2082059"
        value                = "Role.Admin"
    }
    app_role {
        allowed_member_types = [
            "User",
        ]
        description          = "User role"
        display_name         = "User"
        enabled              = true
        id                   = "2dd1f389-a45f-49c8-a161-211dd1e6a848"
        value                = "Role.User"
    }

    single_page_application {
        redirect_uris = [
            "https://${data.terraform_remote_state.kgenaimarketing.outputs.kgenaimarketing_fe.default_host_name}/",
        ]
    }

    web {
        logout_url    = "https://${data.terraform_remote_state.kgenaimarketing.outputs.kgenaimarketing_fe.default_host_name}/signout"
        redirect_uris = []

        implicit_grant {
            access_token_issuance_enabled = true
            id_token_issuance_enabled     = true
        }
    }
}

resource "azuread_service_principal" "kgenaimarketing" {
  application_id = azuread_application.kgenaimarketing.application_id
  owners         = local.owners
  tags           = ["WindowsAzureActiveDirectoryIntegratedApp"]
}

# Password for service principal
resource "azuread_service_principal_password" "kgenaimarketing" {
  service_principal_id = azuread_service_principal.kgenaimarketing.id
  end_date             = var.pwd_expr_date_crit2
  display_name         = "primary"
}

# Assign Groups to the app
resource "azuread_app_role_assignment" "kgenaimarketing-group_genaiapp_gt_bus_marketing" {
  app_role_id         = azuread_service_principal.kgenaimarketing.app_roles[0].id
  principal_object_id = azuread_group.genaiapp_gt_bus_marketing.id
  resource_object_id  = azuread_service_principal.kgenaimarketing.id
}
