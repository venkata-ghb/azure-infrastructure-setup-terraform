# ======================================================================
# K-Data
# ======================================================================
data "azuread_service_principal" "int_adf" {
  display_name = "K-DATA-PROD-WE-Int-Datafactory"
}

data "azuread_service_principal" "storageapi_funcapp" {
  display_name = "kdata-prod-we-storageapi-funcapp"
}

data "azuread_service_principal" "qm_imageapi_msi" {
  display_name = "kdata-prod-qm-imageapi-mi"
}

data "azuread_service_principal" "zetes_funcapp" {
  display_name = "KDATA-PROD-WE-ZETES-FUNC"
}

data "azuread_service_principal" "encode_convert_funcapp" {
  display_name = "kdata-prod-we-encode-convert-funcapp"
}

data "azuread_service_principal" "unitycatalog" {
  display_name = "kdata-prod-unitycatalog"
}


# Infra msi for Prod resources
data "azuread_service_principal" "infra" {
  display_name = "kdata-prod-infra-msi"
}

/* Resource does not exist yet
data "azuread_service_principal" "clm_parser_funcapp" {
  display_name = "kdata-prod-we-clm-parser-funcapp"
}
*/

data "azuread_service_principal" "aks_platform" {
  display_name = "kdata-prod-aks-platform-msi"
}

#======================================================================
#TPS
data "azuread_service_principal" "tps_funcapp" {
  display_name = "kdata-prod-we-tps-funcapp"
}
# ======================================================================
# LUMI
# ======================================================================
data "azuread_service_principal" "lumi_xmlparser_funcapp" {
  display_name = "kdata-prod-we-xmlparser-funcapp"
}

data "azuread_service_principal" "lumi_adf" {
  display_name = "K-DATA-PROD-WE-Lumi-Datafactory"
}

# ======================================================================
# Snowflake
# ======================================================================
data "azuread_service_principal" "snowflake_0518" {
  display_name = "SnowflakePACInt0518"
}

data "azuread_service_principal" "snowflake_btt" {
  display_name = "aczkq6snowflakepacint"
}

data "azuread_service_principal" "snowflake_ow" {
  display_name = "2zrdxxsnowflakepacint"
}

data "azuread_service_principal" "snowflake_central" {
  display_name = "nnmoavsnowflakepacint"
}

# snowflake notification integrations

data "azuread_service_principal" "snowflake_central_notif" {
  display_name = "yvcmsgsnowflakepacint"
}

data "azuread_service_principal" "snowflake_ct_notif" {
  display_name = "cjwlz5snowflakepacint"
}

data "azuread_service_principal" "snowflake_gt_notif" {
  display_name = "rlgof3snowflakepacint"
}

data "azuread_service_principal" "snowflake_btt_notif" {
  display_name = "ke2prcsnowflakepacint"
}

data "azuread_service_principal" "snowflake_dcr_gt_notif" {
  display_name = "dsz5g7snowflakepacint"
}

data "azuread_service_principal" "snowflake_dcr_tester_notif" {
  display_name = "rtj72msnowflakepacint"
}

data "azuread_service_principal" "snowflake_ow_notif" {
  display_name = "i2xj4nsnowflakepacint"
}

# ======================================================================
# Microsoft
# ======================================================================
data "azuread_service_principal" "microsoft_eventhubs" {
  display_name = "Microsoft.EventHubs"
}

# ======================================================================
# Other
# ======================================================================
data "azuread_service_principal" "sap_input_api" {
  display_name = "kdata-sap-input-api-mi-prod"
}

data "azuread_service_principal" "ktv_adf" {
  display_name = "ktv-adf-prod"
}

data "azuread_service_principal" "ktoimittaja_adf" {
  display_name = "adf-ktoimittaja-prod"
}

data "azuread_service_principal" "ktv_funcapp" {
  display_name = "kdata-prod-we-ktv-funcapp"
}

data "azuread_service_principal" "centralised_apim" {
  display_name = "K-apim-prod"
}

data "azuread_service_principal" "apim_kgroup" {
  object_id = "a38294ec-dcdf-46a3-9d95-9efd1d8d0243" # apim-kgroup-prod
}

data "azuread_service_principal" "kcloud_int_funcapp" {
  display_name = "prod-integr-kcloud-func"
}

data "azuread_service_principal" "func_hr_wfo" {
  display_name = "func-hr-wfo-prod-001"
}

data "azuread_service_principal" "eslist_funcapp" {
  display_name = "kdata-prod-we-eslist-function-app"
}

data "azuread_service_principal" "export_to_data_lake" {
  display_name = "Export to data lake"
}

data "azuread_service_principal" "power_query_online" {
  display_name = "Power Query Online"
}

# =============
# CLM Function app
# ==============
data "azuread_service_principal" "clm_funcapp" {
  display_name = "kdata-prod-we-clm-funcapp"
}

data "azuread_service_principal" "kesko_adf" {
  display_name = "adf-kesko-prod-weu-001"
}

data "azuread_service_principal" "nos" {
  display_name = "func-lt-nos-prod-001"
}

data "azuread_service_principal" "kid_log_processor" {
  display_name = "kdata-dump-id-log-processor-prod"
}

data "azuread_service_principal" "or" {
  display_name = "k-data-prod-or-mi"
}

/* REMOVE COMMENT ONCE SP EXISTS
data "azuread_service_principal" "lt_sposs" {
  display_name = "func-lt-sposs-prod-001"
}
*/

data "azuread_service_principal" "sisu_r2" {
  display_name = "Sisu R2 PROD AD write"
}
