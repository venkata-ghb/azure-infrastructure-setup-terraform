# Platform Groups
data "azuread_group" "ppm_access_admins_platform" { display_name = "KDATA_PROD_AZ_ACCESS_ADMIN_PLATFORM" }
data "azuread_group" "ppm_admins_platform" { display_name = "KDATA_PROD_AZ_ADMINS_PLATFORM" }
data "azuread_group" "ppm_devops_platform" { display_name = "KDATA_PROD_AZ_DEVOPS_PLATFORM" }
data "azuread_group" "ppm_reader_platform" { display_name = "KDATA_PROD_AZ_READER_PLATFORM" }

# Devops Groups
data "azuread_group" "ppm_devops_futuricedev" { display_name = "KDATA_PROD_AZ_DEVOPS_FUTURICEDEV" }
data "azuread_group" "ppm_devops_gtesl" { display_name = "KDATA_PROD_AZ_DEVOPS_GTESL" }
data "azuread_group" "ppm_devops_gtkampanja" { display_name = "KDATA_PROD_AZ_DEVOPS_GTKAMPANJA" }
data "azuread_group" "ppm_devops_gtkesprodata" { display_name = "KDATA_PROD_AZ_DEVOPS_GTKESPRODATA" }
data "azuread_group" "ppm_devops_gtpim" { display_name = "KDATA_PROD_AZ_DEVOPS_GTPIM" }
data "azuread_group" "ppm_devops_gtvalikoima" { display_name = "KDATA_PROD_AZ_DEVOPS_GTVALIKOIMA" }
data "azuread_group" "ppm_devops_gtwfo" { display_name = "KDATA_PROD_AZ_DEVOPS_GTWFO" }
data "azuread_group" "ppm_devops_keskodev" { display_name = "KDATA_PROD_AZ_DEVOPS_KESKODEV" }
data "azuread_group" "ppm_devops_kpimdev" { display_name = "KDATA_PROD_AZ_DEVOPS_KPIMDEV" }
data "azuread_group" "ppm_devops_kval" { display_name = "KDATA_PROD_AZ_DEVOPS_KVAL" }
data "azuread_group" "ppm_devops_or" { display_name = "KDATA_PROD_AZ_DEVOPS_OR" }
data "azuread_group" "ppm_devops_solitadev" { display_name = "KDATA_PROD_AZ_DEVOPS_SOLITADEV" }


# BUS groups

data "azuread_group" "ppm_bus_dls_gt_ba" {
  display_name = "KDATA_PROD_BUS_DLS_GT_BA"
}

data "azuread_group" "ppm_bus_dls_kdigital" {
  display_name = "KDATA_PROD_BUS_DLS_KDIGITAL"
}

# Others

data "azuread_group" "ppm_dls_admins" {
  display_name = "KDATA_PROD_DLS_ADMINS"
}

data "azuread_group" "ppm_dls_devops_or" {
  display_name = "KDATA_PROD_DLS_DEVOPS_OR"
}

data "azuread_group" "ppm_sampo_contributor" {
  display_name = "SAMPO_AZ_PROD_RG_CONTRIBUTOR"
}

data "azuread_group" "ppm_gt_dl_raw_gtman_stage_retrobonus_input_retailers" {
  display_name = "KDATA_PROD_GT_DL_RAW_GTMAN_STAGE_RETROBONUS_INPUT_RETAILERS"
}

data "azuread_group" "ppm_gt_dl_raw_gtman_stage_retrobonus_input_vendors" {
  display_name = "KDATA_PROD_GT_DL_RAW_GTMAN_STAGE_RETROBONUS_INPUT_VENDORS"
}

data "azuread_group" "ppm_natural_read_gt_tobtrac" {
  display_name = "KDATA_PROD_NATURAL_READ_GT_TOBTRAC"
}

data "azuread_group" "ppm_inb_tbtrk" {
  display_name = "KDATA_PROD_INB_TBTRK"
}

data "azuread_group" "ppm_kedw_informatica_repository_admins" {
  display_name = "KEDW_PROD_INFORMATICA_REPOSITORY_ADMINS"
}

data "azuread_group" "ppm_kedw_informatica_domain_admins" {
  display_name = "KEDW_PROD_INFORMATICA_DOMAIN_ADMINS"
}

data "azuread_group" "ppm_kedw_td_asm" {
  display_name = "KEDW_PROD_TD_ASM"
}

data "azuread_group" "ppm_kespro_contributor" {
  display_name = "Kespro_Az_dev_Contributor"
}

data "azuread_group" "ppm_bronze_sap_data" {
  display_name = "KDATA_BRONZE_SAP_DATA"
}

data "azuread_group" "ppm_kruokakauppadeveloper" {
  display_name = "K-RuokakauppaDeveloper"
}

data "azuread_group" "ppm_adb_app_bttbusinessanalysts" {
  display_name = "AZ_KDATA_PROD_ADB_APP_BTTBUSINESSANALYSTS"
}

data "azuread_group" "ppm_confluent_prod_admin" {
  display_name = "CONFLUENT_PROD_ADMIN"
}

data "azuread_group" "ppm_ksnow_ow_data_devops_natural" {
  display_name = "KDATA_KSNOW_OW_PROD_DATA_DEVOPS_NATURAL"
}

data "azuread_group" "ppm_ksnow_ow_data_devops_masked" {
  display_name = "KDATA_KSNOW_OW_PROD_DATA_DEVOPS_MASKED"
}
