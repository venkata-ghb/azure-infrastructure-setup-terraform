# ---------------------------------------------------------------------------------------------
# feedbuilder-qlik
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "feedbuilder_qlik" {
  display_name = "${var.prefix_sp}-feedbuilder-qlik-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "feedbuilder_qlik" {
  application_id = azuread_application.feedbuilder_qlik.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "feedbuilder_qlik" {
  service_principal_id = azuread_service_principal.feedbuilder_qlik.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}
