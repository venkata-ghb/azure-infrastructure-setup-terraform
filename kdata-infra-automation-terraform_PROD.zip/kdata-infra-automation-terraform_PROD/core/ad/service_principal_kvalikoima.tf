# ---------------------------------------------------------------------------------------------
# kvalikoima-databricks
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "kvalikoima_databricks" {
  display_name = "${var.prefix_sp}-kvalikoima-databricks-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "kvalikoima_databricks" {
  application_id = azuread_application.kvalikoima_databricks.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "kvalikoima_databricks" {
  service_principal_id = azuread_service_principal.kvalikoima_databricks.id
  end_date             = var.pwd_expr_date_crit2
  display_name         = "primary"
}


# ---------------------------------------------------------------------------------------------
# kvalikoima-dbwrite
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "kvalikoima_dbwrite" {
  display_name = "${var.prefix_sp}-kvalikoima-dbwrite-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "kvalikoima_dbwrite" {
  application_id = azuread_application.kvalikoima_dbwrite.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "kvalikoima_dbwrite" {
  service_principal_id = azuread_service_principal.kvalikoima_dbwrite.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}
