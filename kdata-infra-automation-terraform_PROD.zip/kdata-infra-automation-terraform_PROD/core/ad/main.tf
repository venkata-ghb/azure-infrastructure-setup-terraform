terraform {
  backend "azurerm" {}
  required_providers {
    azuread = {
      source  = "hashicorp/azuread"
      version = "2.20.0"
    }
  }

  required_version = "= 0.13.2"
}

provider "azuread" {
  tenant_id = "ae6e7baa-e1bf-4ef0-92a1-4eb28ec805c0"
}

data "terraform_remote_state" "kgenaimarketing" {
  backend = "azurerm"
  config = {
    subscription_id      = var.SUBSCRIPTION_ID
    resource_group_name  = var.TF_RG_NAME
    storage_account_name = var.TF_SA_NAME
    container_name       = var.TF_CONTAINER_NAME
    key                  = "applications/kgenaimarketing.terraform_PROD.tfstate"
  }
}

data "terraform_remote_state" "ad_dev" {
  backend = "azurerm"
  config = {
    subscription_id      = "f11ae7de-3b87-49e7-8a17-55041f3739c4"
    resource_group_name  = "K-DATA_TEST_WE_Terraform_RG"
    storage_account_name = "kdatadevtestinfrasa"
    container_name       = "tf-state"
    key                  = "DEV/core/ad.terraform_DEV.tfstate"
  }
}

data "terraform_remote_state" "ad_test" {
  backend = "azurerm"
  config = {
    subscription_id      = "f11ae7de-3b87-49e7-8a17-55041f3739c4"
    resource_group_name  = "K-DATA_TEST_WE_Terraform_RG"
    storage_account_name = "kdatadevtestinfrasa"
    container_name       = "tf-state"
    key                  = "TEST/core/ad.terraform_TEST.tfstate"
  }
}
# List of variables passed in via pipelines

variable "SUBSCRIPTION_ID" {
  type = string
}

variable "TENANT_ID" {
  type = string
}

variable "MSI_ID" {
  type = string
}

variable "TF_SUBNET_ID" {
  type = string
}

variable "TF_RG_NAME" {
  type = string
}

variable "TF_SA_NAME" {
  type = string
}

variable "TF_CONTAINER_NAME" {
  type = string
}
