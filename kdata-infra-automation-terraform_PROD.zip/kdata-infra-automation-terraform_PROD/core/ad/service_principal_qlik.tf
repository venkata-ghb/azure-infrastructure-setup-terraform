# ---------------------------------------------------------------------------------------------
# qlik-gt
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "qlik_gt" {
  display_name = "${var.prefix_sp}-qlik-gt-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "qlik_gt" {
  application_id = azuread_application.qlik_gt.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "qlik_gt" {
  service_principal_id = azuread_service_principal.qlik_gt.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}
