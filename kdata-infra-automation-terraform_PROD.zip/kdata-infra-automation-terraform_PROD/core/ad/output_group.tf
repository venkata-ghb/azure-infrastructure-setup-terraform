output group_adb_app_adima {
  value = {
    id           = azuread_group.adb_app_adima.id
    display_name = azuread_group.adb_app_adima.display_name
  }
}

output group_adb_app_aecorsoft {
  value = {
    id           = azuread_group.adb_app_aecorsoft.id
    display_name = azuread_group.adb_app_aecorsoft.display_name
  }
}

output group_adb_app_attribution {
  value = {
    id           = azuread_group.adb_app_attribution.id
    display_name = azuread_group.adb_app_attribution.display_name
  }
}

output group_adb_app_bookkeeping {
  value = {
    id           = azuread_group.adb_app_bookkeeping.id
    display_name = azuread_group.adb_app_bookkeeping.display_name
  }
}

output group_adb_app_catman {
  value = {
    id           = azuread_group.adb_app_catman.id
    display_name = azuread_group.adb_app_catman.display_name
  }
}

output group_adb_app_controlm {
  value = {
    id           = azuread_group.adb_app_controlm.id
    display_name = azuread_group.adb_app_controlm.display_name
  }
}

output group_adb_app_datareaders {
  value = {
    id           = azuread_group.adb_app_datareaders.id
    display_name = azuread_group.adb_app_datareaders.display_name
  }
}

output group_adb_app_digitalsignage {
  value = {
    id           = azuread_group.adb_app_digitalsignage.id
    display_name = azuread_group.adb_app_digitalsignage.display_name
  }
}

output group_adb_app_dmp {
  value = {
    id           = azuread_group.adb_app_dmp.id
    display_name = azuread_group.adb_app_dmp.display_name
  }
}

output group_adb_app_feedbuilder {
  value = {
    id           = azuread_group.adb_app_feedbuilder.id
    display_name = azuread_group.adb_app_feedbuilder.display_name
  }
}

output group_adb_app_gtbusinessanalysts {
  value = {
    id           = azuread_group.adb_app_gtbusinessanalysts.id
    display_name = azuread_group.adb_app_gtbusinessanalysts.display_name
  }
}

output group_adb_app_kpartner {
  value = {
    id           = azuread_group.adb_app_kpartner.id
    display_name = azuread_group.adb_app_kpartner.display_name
  }
}

output group_adb_app_kvalikoima {
  value = {
    id           = azuread_group.adb_app_kvalikoima.id
    display_name = azuread_group.adb_app_kvalikoima.display_name
  }
}

output group_adb_app_lumi {
  value = {
    id           = azuread_group.adb_app_lumi.id
    display_name = azuread_group.adb_app_lumi.display_name
  }
}

output group_adb_app_neste {
  value = {
    id           = azuread_group.adb_app_neste.id
    display_name = azuread_group.adb_app_neste.display_name
  }
}

output group_adb_app_powerbi {
  value = {
    id           = azuread_group.adb_app_powerbi.id
    display_name = azuread_group.adb_app_powerbi.display_name
  }
}

output group_adb_app_qlik {
  value = {
    id           = azuread_group.adb_app_qlik.id
    display_name = azuread_group.adb_app_qlik.display_name
  }
}

output group_adb_app_retrobonus {
  value = {
    id           = azuread_group.adb_app_retrobonus.id
    display_name = azuread_group.adb_app_retrobonus.display_name
  }
}

output group_adb_app_sps {
  value = {
    id           = azuread_group.adb_app_sps.id
    display_name = azuread_group.adb_app_sps.display_name
  }
}

output group_adb_app_uc_admins {
  value = {
    id           = azuread_group.adb_app_uc_admins.id
    display_name = azuread_group.adb_app_uc_admins.display_name
  }
}

output group_adb_app_wolt {
  value = {
    id           = azuread_group.adb_app_wolt.id
    display_name = azuread_group.adb_app_wolt.display_name
  }
}

output group_adb_app_wolt_rpa {
  value = {
    id           = azuread_group.adb_app_wolt_rpa.id
    display_name = azuread_group.adb_app_wolt_rpa.display_name
  }
}

output group_or_sql_admin {
  value = {
    id           = azuread_group.or_sql_admin.id
    display_name = azuread_group.or_sql_admin.display_name
  }
}

output group_service_principals {
  value = {
    id           = azuread_group.service_principals.id
    display_name = azuread_group.service_principals.display_name
  }
}

output "group_platform_sql_admin" {
  value = {
    id           = azuread_group.platform_sql_admin.id
    display_name = azuread_group.platform_sql_admin.display_name
  }
}

output group_adb_app_ktavara {
  value = {
    id           = azuread_group.adb_app_ktavara.id
    display_name = azuread_group.adb_app_ktavara.display_name
  }
}

# APIM

output "group_apim_kafkaproxy_inbound_api" {
  value = {
    id           = azuread_group.apim_kafkaproxy_inbound_api.id
    display_name = azuread_group.apim_kafkaproxy_inbound_api.display_name
  }
}

output "group_streamlitapp_reader" {
  value = {
    id           = azuread_group.streamlitapp_reader.id
    display_name = azuread_group.streamlitapp_reader.display_name
  }
}

output "group_streamlitapp_contributor" {
  value = {
    id           = azuread_group.streamlitapp_contributor.id
    display_name = azuread_group.streamlitapp_contributor.display_name
  }
}
