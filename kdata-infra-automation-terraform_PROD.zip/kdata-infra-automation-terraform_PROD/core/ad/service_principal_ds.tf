# ---------------------------------------------------------------------------------------------
# ds-deltalake
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "ds_deltalake" {
  display_name = "${var.prefix_sp}-ds-deltalake-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "ds_deltalake" {
  application_id = azuread_application.ds_deltalake.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "ds_deltalake" {
  service_principal_id = azuread_service_principal.ds_deltalake.id
  end_date             = var.pwd_expr_date_crit2
  display_name         = "primary"
}
