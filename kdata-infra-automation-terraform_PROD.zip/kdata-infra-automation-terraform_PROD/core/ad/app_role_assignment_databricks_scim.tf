resource "azuread_app_role_assignment" "databricks_scim-group_devops_gtkesprodata_dev" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = data.terraform_remote_state.ad_dev.outputs.group_devops_gtkesprodata.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_devops_gtkesprodata_test" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = data.terraform_remote_state.ad_test.outputs.group_devops_gtkesprodata.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_devops_gtkesprodata_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = data.azuread_group.ppm_devops_gtkesprodata.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_adb_app_adima_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = azuread_group.adb_app_adima.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_adb_app_aecorsoft_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = azuread_group.adb_app_aecorsoft.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_adb_app_attribution_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = azuread_group.adb_app_attribution.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_adb_app_bookkeeping_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = azuread_group.adb_app_bookkeeping.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_adb_app_catman_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = azuread_group.adb_app_catman.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_adb_app_controlm_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = azuread_group.adb_app_controlm.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_adb_app_datareaders_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = azuread_group.adb_app_datareaders.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_adb_app_digitalsignage_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = azuread_group.adb_app_digitalsignage.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_adb_app_dmp_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = azuread_group.adb_app_dmp.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_adb_app_feedbuilder_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = azuread_group.adb_app_feedbuilder.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_adb_app_gtbusinessanalysts_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = azuread_group.adb_app_gtbusinessanalysts.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_adb_app_kpartner_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = azuread_group.adb_app_kpartner.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_adb_app_kvalikoima_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = azuread_group.adb_app_kvalikoima.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_adb_app_lumi_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = azuread_group.adb_app_lumi.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_adb_app_neste_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = azuread_group.adb_app_neste.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_adb_app_powerbi_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = azuread_group.adb_app_powerbi.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_adb_app_qlik_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = azuread_group.adb_app_qlik.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_adb_app_retrobonus_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = azuread_group.adb_app_retrobonus.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_adb_app_sps_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = azuread_group.adb_app_sps.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_adb_app_uc_admins_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = azuread_group.adb_app_uc_admins.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_adb_app_wolt_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = azuread_group.adb_app_wolt.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_adb_app_wolt_rpa_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = azuread_group.adb_app_wolt_rpa.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_devops_platform_dev" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = data.terraform_remote_state.ad_dev.outputs.group_devops_platform.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_devops_platform_test" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = data.terraform_remote_state.ad_test.outputs.group_devops_platform.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_devops_platform_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = data.azuread_group.ppm_devops_platform.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_admins_platform_dev" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = data.terraform_remote_state.ad_dev.outputs.group_admins_platform.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_admins_platform_test" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = data.terraform_remote_state.ad_test.outputs.group_admins_platform.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_admins_platform_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = data.azuread_group.ppm_admins_platform.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

# ============================================================================================
resource "azuread_app_role_assignment" "databricks_scim-group_devops_futuricedev_dev" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = data.terraform_remote_state.ad_dev.outputs.group_devops_futuricedev.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_devops_futuricedev_test" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = data.terraform_remote_state.ad_test.outputs.group_devops_futuricedev.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_devops_futuricedev_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = data.azuread_group.ppm_devops_futuricedev.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

# ============================================================================================

resource "azuread_app_role_assignment" "databricks_scim-group_bus_dls_kdigital" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = data.azuread_group.ppm_bus_dls_kdigital.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

# ============================================================================================

resource "azuread_app_role_assignment" "databricks_scim-group_bronze_sap_data" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = data.azuread_group.ppm_bronze_sap_data.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_adb_app_ktavara_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = azuread_group.adb_app_ktavara.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_devops_keskodev_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = data.azuread_group.ppm_devops_keskodev.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

# ============================================================================================

resource "azuread_app_role_assignment" "databricks_scim-group_kruokakauppadeveloper" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = data.azuread_group.ppm_kruokakauppadeveloper.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

# ============================================================================================

resource "azuread_app_role_assignment" "databricks_scim-group_adb_app_bttbusinessanalysts" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = data.azuread_group.ppm_adb_app_bttbusinessanalysts.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

# ============================================================================================

resource "azuread_app_role_assignment" "databricks_scim-group_devops_solitadev_dev" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = data.terraform_remote_state.ad_dev.outputs.group_devops_solitadev.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_devops_solitadev_test" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = data.terraform_remote_state.ad_test.outputs.group_devops_solitadev.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_devops_solitadev_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = data.azuread_group.ppm_devops_solitadev.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

# ============================================================================================

resource "azuread_app_role_assignment" "databricks_scim-group_devops_kval_dev" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = data.terraform_remote_state.ad_dev.outputs.group_devops_kval.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_devops_kval_test" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = data.terraform_remote_state.ad_test.outputs.group_devops_kval.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}

resource "azuread_app_role_assignment" "databricks_scim-group_devops_kval_prod" {
  app_role_id         = azuread_service_principal.databricks_scim.app_roles[1].id
  principal_object_id = data.azuread_group.ppm_devops_kval.id
  resource_object_id  = azuread_service_principal.databricks_scim.id
}
