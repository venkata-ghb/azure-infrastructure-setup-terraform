# ---------------------------------------------------------------------------------------------
# attrbmodeling-adfrm
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "attrbmodeling_adfrm" {
  display_name = "${var.prefix_sp}-attrbmodeling-adfrm-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "attrbmodeling_adfrm" {
  application_id = azuread_application.attrbmodeling_adfrm.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "attrbmodeling_adfrm" {
  service_principal_id = azuread_service_principal.attrbmodeling_adfrm.id
  end_date             = var.pwd_expr_date_crit2
  display_name         = "primary"
}

# ---------------------------------------------------------------------------------------------
# attrbmodeling-slfrc
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "attrbmodeling_slfrc" {
  display_name = "${var.prefix_sp}-attrbmodeling-slfrc-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "attrbmodeling_slfrc" {
  application_id = azuread_application.attrbmodeling_slfrc.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "attrbmodeling_slfrc" {
  service_principal_id = azuread_service_principal.attrbmodeling_slfrc.id
  end_date             = var.pwd_expr_date_crit2
  display_name         = "primary"
}
