# ---------------------------------------------------------------------------------------------
# neste-databricks
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "neste_databricks" {
  display_name = "${var.prefix_sp}-neste-databricks-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "neste_databricks" {
  application_id = azuread_application.neste_databricks.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "neste_databricks" {
  service_principal_id = azuread_service_principal.neste_databricks.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}

# ---------------------------------------------------------------------------------------------
# neste-eventhub
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "neste_eventhub" {
  display_name = "${var.prefix_sp}-neste-eventhub-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "neste_eventhub" {
  application_id = azuread_application.neste_eventhub.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "neste_eventhub" {
  service_principal_id = azuread_service_principal.neste_eventhub.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}
