# ---------------------------------------------------------------------------------------------
# kruoka-databricks
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "kruoka_databricks" {
  display_name = "${var.prefix_sp}-kruoka-databricks-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "kruoka_databricks" {
  application_id = azuread_application.kruoka_databricks.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "kruoka_databricks" {
  service_principal_id = azuread_service_principal.kruoka_databricks.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}

# ---------------------------------------------------------------------------------------------
# kruoka-eventhub
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "kruoka_eventhub" {
  display_name = "${var.prefix_sp}-kruoka-eventhub-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "kruoka_eventhub" {
  application_id = azuread_application.kruoka_eventhub.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "kruoka_eventhub" {
  service_principal_id = azuread_service_principal.kruoka_eventhub.id
  end_date             = var.pwd_expr_date_crit2
  display_name         = "primary"
}
