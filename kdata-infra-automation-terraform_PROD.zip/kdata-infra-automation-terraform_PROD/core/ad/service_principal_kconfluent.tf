# ---------------------------------------------------------------------------------------------
# kconfluent
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "kconfluent_devops" {
  display_name = "${var.prefix_sp}-kconfluent-devops-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "kconfluent_devops" {
  application_id = azuread_application.kconfluent_devops.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "kconfluent_devops" {
  service_principal_id = azuread_service_principal.kconfluent_devops.id
  end_date             = var.pwd_expr_date_crit
}

# ---------------------------------------------------------------------------------------------
# kconfluent to external datalake
# ---------------------------------------------------------------------------------------------

resource "azuread_application" "kconfluent_externaldatalake" {
  display_name = "${var.prefix_sp}-kconfluent-externaldatalake-sp"
  owners       = local.owners

}

resource "azuread_service_principal" "kconfluent_externaldatalake" {
  application_id = azuread_application.kconfluent_externaldatalake.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}


resource "azuread_service_principal_password" "kconfluent_externaldatalake" {
  service_principal_id = azuread_service_principal.kconfluent_externaldatalake.id
  end_date             = var.pwd_expr_date_crit

}