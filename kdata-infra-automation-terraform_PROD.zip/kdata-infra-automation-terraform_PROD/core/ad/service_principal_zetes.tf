# ---------------------------------------------------------------------------------------------
# zetes-devops
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "zetes_devops" {
  display_name = "${var.prefix_sp}-zetes-devops-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "zetes_devops" {
  application_id = azuread_application.zetes_devops.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}
/*
resource "azuread_service_principal_password" "zetes_devops" {
  service_principal_id = azuread_service_principal.zetes_devops.id
  end_date             = var.pwd_expr_date
}
*/
