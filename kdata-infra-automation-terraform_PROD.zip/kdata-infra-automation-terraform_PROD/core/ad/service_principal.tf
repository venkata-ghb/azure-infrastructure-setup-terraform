# [ ] - eventhub_sp

resource "azuread_application" "adb_metastore" {
  display_name = "${var.prefix_sp}-adb-metastore-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "adb_metastore" {
  application_id = azuread_application.adb_metastore.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "adb_metastore" {
  service_principal_id = azuread_service_principal.adb_metastore.id
  end_date             = var.pwd_expr_date_crit2
}

resource "azuread_application" "apim" {
  display_name = "${var.prefix_sp}-apim-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "apim" {
  application_id = azuread_application.apim.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}
/*
resource "azuread_service_principal_password" "apim" {
  service_principal_id = azuread_service_principal.apim.id
  end_date             = var.pwd_expr_date
}
*/

resource "azuread_application" "apim_authentication" {
  display_name = "${var.prefix_sp}-apim-authentication-sp"
  owners       = local.owners

  required_resource_access {
    resource_app_id = "00000003-0000-0000-c000-000000000000"

    resource_access {
      id   = "e1fe6dd8-ba31-4d61-89e7-88639da4683d"
      type = "Scope"
    }
  }

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "apim_authentication" {
  application_id = azuread_application.apim_authentication.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "apim_authentication" {
  service_principal_id = azuread_service_principal.apim_authentication.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}

resource "azuread_application" "platform_devops" {
  display_name = "${var.prefix_sp}-platform-devops-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "platform_devops" {
  application_id = azuread_application.platform_devops.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_application_federated_identity_credential" "platform_devops-github_actions" {
  application_object_id = azuread_application.platform_devops.object_id
  display_name          = "github-actions"
  description           = "Deployments with github actions for kdata specific repositories"
  audiences             = ["api://AzureADTokenExchange"]
  issuer                = "https://token.actions.githubusercontent.com"
  subject               = "claims['sub'] matches 'repo:kesko-dev/kdata-*:ref:refs/heads/*'"

  lifecycle {
    ignore_changes = [ subject ] # Ignore changes on subject due to terraform not supporting claim matching expression
  }
}

/*
resource "azuread_service_principal_password" "platform_devops" {
  service_principal_id = azuread_service_principal.platform_devops.id
  end_date             = var.pwd_expr_date_crit
}
*/

resource "azuread_application" "securityreader" {
  display_name = "${var.prefix_sp}-securityreader-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "securityreader" {
  application_id = azuread_application.securityreader.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}
/*
resource "azuread_service_principal_password" "securityreader" {
  service_principal_id = azuread_service_principal.securityreader.id
  end_date             = var.pwd_expr_date
}
*/

resource "azuread_application" "platform_sharepoint" {
  display_name = "${var.prefix_sp}-platform-sharepoint-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web, required_resource_access] }
}

resource "azuread_service_principal" "platform_sharepoint" {
  application_id = azuread_application.platform_sharepoint.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "platform_sharepoint" {
  service_principal_id = azuread_service_principal.platform_sharepoint.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}

# kdata-prod-powerbi-kdig-sp
resource "azuread_application" "powerbi_kdig" {
  display_name = "${var.prefix_sp}-powerbi-kdig-sp"
  owners       = local.owners

  required_resource_access {
    resource_app_id = "00000003-0000-0000-c000-000000000000"
    resource_access {
      id   = "e1fe6dd8-ba31-4d61-89e7-88639da4683d"
      type = "Scope"
    }
  }

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "powerbi_kdig" {
  application_id = azuread_application.powerbi_kdig.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "powerbi_kdig" {
  service_principal_id = azuread_service_principal.powerbi_kdig.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}

# kdata-prod-automation (4e60b8d3-fc31-4b0b-8c55-cfd1da1e23f5)
# KDATA-PROD-WE-KDIG-Databricks-provisioning

data "azuread_application_template" "databricks_provisioning" {
  display_name = "Azure Databricks SCIM Provisioning Connector"
}

resource "azuread_application" "scimintegrator_int" {
  display_name            = "${var.prefix_sp}-scimintegrator-int-sp"
  owners                  = local.owners
  prevent_duplicate_names = true

  api {
    known_client_applications      = []
    mapped_claims_enabled          = false
    requested_access_token_version = 1

    oauth2_permission_scope {
      admin_consent_description  = "Allow the application to access kdata-prod-scimintegrator-int-sp on behalf of the signed-in user."
      admin_consent_display_name = "Access kdata-prod-scimintegrator-int-sp"
      enabled                    = true
      id                         = "393f2339-7ad4-4bd3-97b4-ec1b9a4a7c6b"
      type                       = "User"
      user_consent_description   = "Allow the application to access kdata-prod-scimintegrator-int-sp on your behalf."
      user_consent_display_name  = "Access kdata-prod-scimintegrator-int-sp"
      value                      = "user_impersonation"
    }
  }

  required_resource_access {
    resource_app_id = "00000003-0000-0000-c000-000000000000"

    resource_access {
      id   = "e1fe6dd8-ba31-4d61-89e7-88639da4683d"
      type = "Scope"
    }
  }

  web {
    homepage_url  = "https://kdata-prod-scimintegrator-int-sp"
    redirect_uris = []

    implicit_grant {
      access_token_issuance_enabled = true
      id_token_issuance_enabled     = true
    }
  }

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "scimintegrator_int" {
  application_id = azuread_application.scimintegrator_int.application_id
  owners         = local.owners
  tags           = []
}

resource "azuread_application" "scimintegrator_kdig" {
  display_name            = "${var.prefix_sp}-scimintegrator-kdig-sp"
  owners                  = local.owners
  prevent_duplicate_names = true

  api {
    known_client_applications      = []
    mapped_claims_enabled          = false
    requested_access_token_version = 1

    oauth2_permission_scope {
      admin_consent_description  = "Allow the application to access ${var.prefix_sp}-scimintegrator-kdig-sp on behalf of the signed-in user."
      admin_consent_display_name = "Access ${var.prefix_sp}-scimintegrator-kdig-sp"
      enabled                    = true
      id                         = "393f2339-7ad4-4bd3-97b4-ec1b9a4a7c6b"
      type                       = "User"
      user_consent_description   = "Allow the application to access ${var.prefix_sp}-scimintegrator-kdig-sp on your behalf."
      user_consent_display_name  = "Access ${var.prefix_sp}-scimintegrator-kdig-sp"
      value                      = "user_impersonation"
    }
  }

  required_resource_access {
    resource_app_id = "00000003-0000-0000-c000-000000000000"

    resource_access {
      id   = "e1fe6dd8-ba31-4d61-89e7-88639da4683d"
      type = "Scope"
    }
  }

  web {
    homepage_url  = "https://${var.prefix_sp}-scimintegrator-kdig-sp"
    redirect_uris = []

    implicit_grant {
      access_token_issuance_enabled = true
      id_token_issuance_enabled     = true
    }
  }

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "scimintegrator_kdig" {
  application_id = azuread_application.scimintegrator_kdig.application_id
  owners         = local.owners
  tags           = []
}

resource "azuread_application" "databricks_scim" {
  display_name            = "${var.prefix_sp}-databricks-scim-sp"
  owners                  = local.owners
  prevent_duplicate_names = true

  api {
    known_client_applications      = []
    mapped_claims_enabled          = false
    requested_access_token_version = 1

    oauth2_permission_scope {
      admin_consent_description  = "Allow the application to access ${var.prefix_sp}-databricks-scim-sp on behalf of the signed-in user."
      admin_consent_display_name = "Access ${var.prefix_sp}-databricks-scim-sp"
      enabled                    = true
      id                         = "b7288ab3-2e96-410e-ac54-0749e8e74bd1"
      type                       = "User"
      user_consent_description   = "Allow the application to access ${var.prefix_sp}-databricks-scim-sp on your behalf."
      user_consent_display_name  = "Access ${var.prefix_sp}-databricks-scim-sp"
      value                      = "user_impersonation"
    }
  }

  app_role {
    id                   = "a34c49f1-a169-404b-a890-00b3bfdbc1d6"
    allowed_member_types = ["User"]
    description          = "User"
    display_name         = "User"
    enabled              = true
  }

  app_role {
    id                   = "3c812665-ce20-461b-a381-af3a1c87db1e"
    allowed_member_types = ["User"]
    description          = "msiam_access"
    display_name         = "msiam_access"
    enabled              = true
  }

  web {
    homepage_url  = "https://account.activedirectory.windowsazure.com:444/applications/default.aspx?metadata=azuredatabricks|ISV9.1|primary|z"
    redirect_uris = []

    implicit_grant {
      access_token_issuance_enabled = false
      id_token_issuance_enabled     = true
    }
  }
}

resource "azuread_service_principal" "databricks_scim" {
  application_id               = azuread_application.databricks_scim.application_id
  owners                       = local.owners
  app_role_assignment_required = true
  tags                         = ["WindowsAzureActiveDirectoryIntegratedApp"]
}

# Dynatrace Monitoring Tool - Platform level sp
resource "azuread_application" "platform_dynatrace" {
  display_name = "${var.prefix_sp}-platform-dynatrace-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web, required_resource_access] }
}

resource "azuread_service_principal" "platform_dynatrace" {
  application_id = azuread_application.platform_dynatrace.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "platform_dynatrace" {
  service_principal_id = azuread_service_principal.platform_dynatrace.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}
