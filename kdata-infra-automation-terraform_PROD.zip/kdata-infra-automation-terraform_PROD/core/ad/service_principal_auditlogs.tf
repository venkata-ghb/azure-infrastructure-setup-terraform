# ---------------------------------------------------------------------------------------------
# auditlogs-adb
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "auditlogs_adb" {
  display_name = "${var.prefix_sp}-auditlogs-adb-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "auditlogs_adb" {
  application_id = azuread_application.auditlogs_adb.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}
/*
resource "azuread_service_principal_password" "auditlogs_adb" {
  service_principal_id = azuread_service_principal.auditlogs_adb.id
  end_date             = var.pwd_expr_date
}
*/
