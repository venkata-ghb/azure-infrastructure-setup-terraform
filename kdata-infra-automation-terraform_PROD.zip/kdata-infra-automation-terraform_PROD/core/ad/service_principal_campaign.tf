# ---------------------------------------------------------------------------------------------
# campaign-deltalake
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "campaign_deltalake" {
  display_name = "${var.prefix_sp}-campaign-deltalake-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "campaign_deltalake" {
  application_id = azuread_application.campaign_deltalake.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "campaign_deltalake" {
  service_principal_id = azuread_service_principal.campaign_deltalake.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}

# ---------------------------------------------------------------------------------------------
# campaign-eventhub
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "campaign_eventhub" {
  display_name = "${var.prefix_sp}-campaign-eventhub-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "campaign_eventhub" {
  application_id = azuread_application.campaign_eventhub.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "campaign_eventhub" {
  service_principal_id = azuread_service_principal.campaign_eventhub.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}
