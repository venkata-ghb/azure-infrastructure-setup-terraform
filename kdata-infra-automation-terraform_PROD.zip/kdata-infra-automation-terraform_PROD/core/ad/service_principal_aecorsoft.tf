# ---------------------------------------------------------------------------------------------
# aecorsoft-sink
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "aecorsoft_sink" {
  display_name = "${var.prefix_sp}-aecorsoft-sink-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "aecorsoft_sink" {
  application_id = azuread_application.aecorsoft_sink.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "aecorsoft_sink" {
  service_principal_id = azuread_service_principal.aecorsoft_sink.id
  end_date             = var.pwd_expr_date_crit
}

