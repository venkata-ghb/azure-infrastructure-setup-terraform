# Kesko
data "azuread_user" "kesko_nico_miettinen" {
  user_principal_name = "nico.miettinen@kesko.fi"
}

data "azuread_user" "kesko_sankalp_ahuja" {
  user_principal_name = "sankalp.ahuja@kesko.fi"
}

data "azuread_user" "kesko_jukka_kemppinen" {
  user_principal_name = "jukka.kemppinen@kesko.fi"
}

data "azuread_user" "kesko_lauri_kiili" {
  user_principal_name = "lauri.kiili@kesko.fi"
}

data "azuread_user" "kesko_niilo_latva-pukkila" {
  user_principal_name = "niilo.latva-pukkila@kesko.fi"
}

data "azuread_user" "kesko_jarkko_sillanpaa" {
  user_principal_name = "jarkko.sillanpaa@kesko.fi"
}

data "azuread_user" "kesko_anssi_salomaa" {
  user_principal_name = "anssi.salomaa@kesko.fi"
}

data "azuread_user" "kesko_jari_vainio" {
  user_principal_name = "jari.vainio@kesko.fi"
}

data "azuread_user" "kesko_henri_dahlstrom" {
  user_principal_name = "henri.dahlstrom@kesko.fi"
}

data "azuread_user" "kesko_janne_jaalivaara" {
  user_principal_name = "janne.jaalivaara@kesko.fi"
}

data "azuread_user" "kesko_jarno_martikainen" {
  user_principal_name = "jarno.martikainen@kesko.fi"
}

data "azuread_user" "kesko_aaro_elo" {
  user_principal_name = "aaro.elo@kesko.fi"
}

data "azuread_user" "kesko_mira_eskola" {
  user_principal_name = "mira.eskola@kesko.fi"
}

data "azuread_user" "kesko_kristiina_granlund" {
  user_principal_name = "kristiina.granlund@kesko.fi"
}

data "azuread_user" "kesko_eveliina_koski" {
  user_principal_name = "eveliina.koski@kesko.fi"
}

data "azuread_user" "kesko_oskari_lehtonen" {
  user_principal_name = "oskari.a.lehtonen@kesko.fi"
}

data "azuread_user" "kesko_pontus_lindroos" {
  user_principal_name = "pontus.lindroos@kesko.fi"
}

data "azuread_user" "kesko_markus_markkula" {
  user_principal_name = "markus.markkula@kesko.fi"
}

data "azuread_user" "kesko_jani_rantala" {
  user_principal_name = "jani.rantala@kesko.fi"
}

data "azuread_user" "kesko_ville_tarvonen" {
  user_principal_name = "ville.tarvonen@kesko.fi"
}

data "azuread_user" "kesko_jere_vilenius" {
  user_principal_name = "jere.vilenius@kesko.fi"
}

data "azuread_user" "kesko_jussi_forma" {
  user_principal_name = "jussi.forma@kesko.fi"
}

data "azuread_user" "kesko_matias_tiainen" {
  user_principal_name = "matias.tiainen@kesko.fi"
}

data "azuread_user" "kesko_joonas_heikela" {
  user_principal_name = "joonas.heikela@kesko.fi"
}

data "azuread_user" "kesko_jarno_ritala" {
  user_principal_name = "jarno.ritala@kesko.fi"
}

data "azuread_user" "kesko_saija_somero" {
  user_principal_name = "saija.somero@kesko.fi"
}

data "azuread_user" "kesko_sari_hokka" {
  user_principal_name = "sari.hokka@kesko.fi"
}

data "azuread_user" "kesko_susanna_sundberg" {
  user_principal_name = "susanna.sundberg@kesko.fi"
}

data "azuread_user" "kesko_sanna_vepsalainen" {
  user_principal_name = "sanna.vepsalainen@kesko.fi"
}

data "azuread_user" "kesko_markus_vilmunen" {
  user_principal_name = "markus.vilmunen@kesko.fi"
}

data "azuread_user" "kesko_topias_karavirta" {
  user_principal_name = "topias.karavirta@kesko.fi"
}

data "azuread_user" "kesko_ella_asikainen" {
  user_principal_name = "ella.asikainen@kesko.fi"
}

data "azuread_user" "kesko_janne_uutela" {
  user_principal_name = "janne.uutela@kesko.fi"
}

data "azuread_user" "kesko_anssi_leppakoski" {
  user_principal_name = "anssi.leppakoski@kesko.fi"
}

data "azuread_user" "kesko_moona_latvala" {
  user_principal_name = "moona.latvala@kesko.fi"
}

data "azuread_user" "kesko_joel_eronen" {
  user_principal_name = "joel.eronen@kesko.fi"
}

data "azuread_user" "kesko_juho_malm" {
  user_principal_name = "juho.malm@kesko.fi"
}

data "azuread_user" "kesko_joni_lappalainen" {
  user_principal_name = "joni.lappalainen@kesko.fi"
}

data "azuread_user" "kesko_antti_oja" {
  user_principal_name = "antti.oja@kesko.fi"
}

data "azuread_user" "kesko_hoang_pham" {
  user_principal_name = "hoang.pham@kesko.fi"
}

data "azuread_user" "kesko_joonas_savolainen" {
  user_principal_name = "joonas.savolainen@kesko.fi"
}

data "azuread_user" "kesko_marko_inkinen" {
  user_principal_name = "marko.inkinen@kesko.fi"
}

data "azuread_user" "kesko_anna_luneva" {
  user_principal_name = "anna.luneva@kesko.fi"
}

data "azuread_user" "kesko_harri_palomaa" {
  user_principal_name = "harri.palomaa@kesko.fi"
}

data "azuread_user" "kesko_patrik_merla" {
  user_principal_name = "patrik.merla@kesko.fi"
}

data "azuread_user" "kesko_atte_makela" {
  user_principal_name = "atte.makela@kesko.fi"
}

# Futurice
data "azuread_user" "futurice_kaarel_korvemaa" {
  user_principal_name = "ext.kaarel.korvemaa@kesko.fi"
}

# KESKO VIRTUAL ASSISTANT ROBOT USER
data "azuread_user" "assistant1_virtual" {
  user_principal_name = "virtual.assistant1@kesko.fi"
}

data "azuread_user" "kesko_nakul_bansal" {
  user_principal_name = "nakul.bansal@kesko.fi"
}

data "azuread_user" "kesko_tiitus_kareno" {
  user_principal_name = "tiitus.kareno@kesko.fi"
}

data "azuread_user" "kesko_kaj_giersberg" {
  user_principal_name = "kaj.giersberg@kesko.fi"
}

data "azuread_user" "kesko_robovias" {
  user_principal_name = "robovias@ku.k-netti.com"
}

data "azuread_user" "kesko_juho_tommila" {
  user_principal_name = "ext.juho.a.tommila@kesko.fi"
}

data "azuread_user" "kesko_tuomas_sauvola" {
  user_principal_name = "tuomas.sauvola@kesko.fi"
}

data "azuread_user" "kesko_kalle_rasanen" {
  user_principal_name = "kalle.rasanen@kesko.fi"
}

data "azuread_user" "kesko_shyamal_mondal" {
  user_principal_name = "shyamal.mondal@kesko.fi"
}
