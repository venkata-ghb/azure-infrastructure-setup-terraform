output sp_adb_metastore {
  value = {
    id             = azuread_service_principal.adb_metastore.id
    application_id = azuread_service_principal.adb_metastore.application_id
    display_name   = azuread_service_principal.adb_metastore.display_name
  }
}

output sp_advancedanalytics_adb {
  value = {
    id             = azuread_service_principal.advancedanalytics_adb.id
    application_id = azuread_service_principal.advancedanalytics_adb.application_id
    display_name   = azuread_service_principal.advancedanalytics_adb.display_name
  }
}

output sp_aecorsoft_sink {
  value = {
    id             = azuread_service_principal.aecorsoft_sink.id
    application_id = azuread_service_principal.aecorsoft_sink.application_id
    display_name   = azuread_service_principal.aecorsoft_sink.display_name
  }
}

output sp_apim {
  value = {
    id             = azuread_service_principal.apim.id
    application_id = azuread_service_principal.apim.application_id
    display_name   = azuread_service_principal.apim.display_name
  }
}

output sp_apim_authentication {
  value = {
    id             = azuread_service_principal.apim_authentication.id
    application_id = azuread_service_principal.apim_authentication.application_id
    display_name   = azuread_service_principal.apim_authentication.display_name
  }
}

output sp_attrbmodeling_adfrm {
  value = {
    id             = azuread_service_principal.attrbmodeling_adfrm.id
    application_id = azuread_service_principal.attrbmodeling_adfrm.application_id
    display_name   = azuread_service_principal.attrbmodeling_adfrm.display_name
  }
}

output sp_attrbmodeling_slfrc {
  value = {
    id             = azuread_service_principal.attrbmodeling_slfrc.id
    application_id = azuread_service_principal.attrbmodeling_slfrc.application_id
    display_name   = azuread_service_principal.attrbmodeling_slfrc.display_name
  }
}

output sp_auditlogs_adb {
  value = {
    id             = azuread_service_principal.auditlogs_adb.id
    application_id = azuread_service_principal.auditlogs_adb.application_id
    display_name   = azuread_service_principal.auditlogs_adb.display_name
  }
}

output sp_campaign_deltalake {
  value = {
    id             = azuread_service_principal.campaign_deltalake.id
    application_id = azuread_service_principal.campaign_deltalake.application_id
    display_name   = azuread_service_principal.campaign_deltalake.display_name
  }
}

output sp_campaign_eventhub {
  value = {
    id             = azuread_service_principal.campaign_eventhub.id
    application_id = azuread_service_principal.campaign_eventhub.application_id
    display_name   = azuread_service_principal.campaign_eventhub.display_name
  }
}

output sp_catman_adb {
  value = {
    id             = azuread_service_principal.catman_adb.id
    application_id = azuread_service_principal.catman_adb.application_id
    display_name   = azuread_service_principal.catman_adb.display_name
  }
}

output sp_controlm_adb {
  value = {
    id             = azuread_service_principal.controlm_adb.id
    application_id = azuread_service_principal.controlm_adb.application_id
    display_name   = azuread_service_principal.controlm_adb.display_name
  }
}

output sp_controlm_adf {
  value = {
    id             = azuread_service_principal.controlm_adf.id
    application_id = azuread_service_principal.controlm_adf.application_id
    display_name   = azuread_service_principal.controlm_adf.display_name
  }
}

output sp_ds_deltalake {
  value = {
    id             = azuread_service_principal.ds_deltalake.id
    application_id = azuread_service_principal.ds_deltalake.application_id
    display_name   = azuread_service_principal.ds_deltalake.display_name
  }
}

output sp_feedbuilder_qlik {
  value = {
    id             = azuread_service_principal.feedbuilder_qlik.id
    application_id = azuread_service_principal.feedbuilder_qlik.application_id
    display_name   = azuread_service_principal.feedbuilder_qlik.display_name
  }
}

output sp_gtanalytics_adb {
  value = {
    id             = azuread_service_principal.gtanalytics_adb.id
    application_id = azuread_service_principal.gtanalytics_adb.application_id
    display_name   = azuread_service_principal.gtanalytics_adb.display_name
  }
}

output sp_gtkpartner_adb {
  value = {
    id             = azuread_service_principal.gtkpartner_adb.id
    application_id = azuread_service_principal.gtkpartner_adb.application_id
    display_name   = azuread_service_principal.gtkpartner_adb.display_name
  }
}

output sp_kpartner_dynamics {
  value = {
    id             = azuread_service_principal.kpartner_dynamics.id
    application_id = azuread_service_principal.kpartner_dynamics.application_id
    display_name   = azuread_service_principal.kpartner_dynamics.display_name
  }
}

output sp_kruoka_databricks {
  value = {
    id             = azuread_service_principal.kruoka_databricks.id
    application_id = azuread_service_principal.kruoka_databricks.application_id
    display_name   = azuread_service_principal.kruoka_databricks.display_name
  }
}

output sp_kruoka_eventhub {
  value = {
    id             = azuread_service_principal.kruoka_eventhub.id
    application_id = azuread_service_principal.kruoka_eventhub.application_id
    display_name   = azuread_service_principal.kruoka_eventhub.display_name
  }
}

output sp_kvalikoima_databricks {
  value = {
    id             = azuread_service_principal.kvalikoima_databricks.id
    application_id = azuread_service_principal.kvalikoima_databricks.application_id
    display_name   = azuread_service_principal.kvalikoima_databricks.display_name
  }
}

output sp_kvalikoima_dbwrite {
  value = {
    id             = azuread_service_principal.kvalikoima_dbwrite.id
    application_id = azuread_service_principal.kvalikoima_dbwrite.application_id
    display_name   = azuread_service_principal.kvalikoima_dbwrite.display_name
  }
}

output sp_lumi_adb {
  value = {
    id             = azuread_service_principal.lumi_adb.id
    application_id = azuread_service_principal.lumi_adb.application_id
    display_name   = azuread_service_principal.lumi_adb.display_name
  }
}

output sp_lumi_devops {
  value = {
    id             = azuread_service_principal.lumi_devops.id
    application_id = azuread_service_principal.lumi_devops.application_id
    display_name   = azuread_service_principal.lumi_devops.display_name
  }
}

output sp_neste_databricks {
  value = {
    id             = azuread_service_principal.neste_databricks.id
    application_id = azuread_service_principal.neste_databricks.application_id
    display_name   = azuread_service_principal.neste_databricks.display_name
  }
}

output sp_neste_eventhub {
  value = {
    id             = azuread_service_principal.neste_eventhub.id
    application_id = azuread_service_principal.neste_eventhub.application_id
    display_name   = azuread_service_principal.neste_eventhub.display_name
  }
}

output sp_or_azdevops {
  value = {
    id             = azuread_service_principal.or_azdevops.id
    application_id = azuread_service_principal.or_azdevops.application_id
    display_name   = azuread_service_principal.or_azdevops.display_name
  }
}

output sp_or_b2bdr {
  value = {
    id             = azuread_service_principal.or_b2bdr.id
    application_id = azuread_service_principal.or_b2bdr.application_id
    display_name   = azuread_service_principal.or_b2bdr.display_name
  }
}

output sp_or_bookkeeping {
  value = {
    id             = azuread_service_principal.or_bookkeeping.id
    application_id = azuread_service_principal.or_bookkeeping.application_id
    display_name   = azuread_service_principal.or_bookkeeping.display_name
  }
}

output sp_or_companyinfo {
  value = {
    id             = azuread_service_principal.or_companyinfo.id
    application_id = azuread_service_principal.or_companyinfo.application_id
    display_name   = azuread_service_principal.or_companyinfo.display_name
  }
}

output sp_or_datapower {
  value = {
    id             = azuread_service_principal.or_datapower.id
    application_id = azuread_service_principal.or_datapower.application_id
    display_name   = azuread_service_principal.or_datapower.display_name
  }
}

output sp_or_dbmaintenance {
  value = {
    id             = azuread_service_principal.or_dbmaintenance.id
    application_id = azuread_service_principal.or_dbmaintenance.application_id
    display_name   = azuread_service_principal.or_dbmaintenance.display_name
  }
}

output sp_or_deltalake {
  value = {
    id             = azuread_service_principal.or_deltalake.id
    application_id = azuread_service_principal.or_deltalake.application_id
    display_name   = azuread_service_principal.or_deltalake.display_name
  }
}

output sp_or_edw {
  value = {
    id             = azuread_service_principal.or_edw.id
    application_id = azuread_service_principal.or_edw.application_id
    display_name   = azuread_service_principal.or_edw.display_name
  }
}

output sp_or_etl {
  value = {
    id             = azuread_service_principal.or_etl.id
    application_id = azuread_service_principal.or_etl.application_id
    display_name   = azuread_service_principal.or_etl.display_name
  }
}

output sp_or_flyway_sql {
  value = {
    id             = azuread_service_principal.or_flyway_sql.id
    application_id = azuread_service_principal.or_flyway_sql.application_id
    display_name   = azuread_service_principal.or_flyway_sql.display_name
  }
}

output sp_or_kai {
  value = {
    id             = azuread_service_principal.or_kai.id
    application_id = azuread_service_principal.or_kai.application_id
    display_name   = azuread_service_principal.or_kai.display_name
  }
}

output sp_or_konvehti_fe {
  value = {
    id             = azuread_service_principal.or_konvehti_fe.id
    application_id = azuread_service_principal.or_konvehti_fe.application_id
    display_name   = azuread_service_principal.or_konvehti_fe.display_name
  }
}

output sp_or_lastdaysales {
  value = {
    id             = azuread_service_principal.or_lastdaysales.id
    application_id = azuread_service_principal.or_lastdaysales.application_id
    display_name   = azuread_service_principal.or_lastdaysales.display_name
  }
}

output sp_or_match {
  value = {
    id             = azuread_service_principal.or_match.id
    application_id = azuread_service_principal.or_match.application_id
    display_name   = azuread_service_principal.or_match.display_name
  }
}

output sp_or_nestedayend {
  value = {
    id             = azuread_service_principal.or_nestedayend.id
    application_id = azuread_service_principal.or_nestedayend.application_id
    display_name   = azuread_service_principal.or_nestedayend.display_name
  }
}

output sp_or_plussa {
  value = {
    id             = azuread_service_principal.or_plussa.id
    application_id = azuread_service_principal.or_plussa.application_id
    display_name   = azuread_service_principal.or_plussa.display_name
  }
}

output sp_or_robot {
  value = {
    id             = azuread_service_principal.or_robot.id
    application_id = azuread_service_principal.or_robot.application_id
    display_name   = azuread_service_principal.or_robot.display_name
  }
}

output sp_or_selfsupervision {
  value = {
    id             = azuread_service_principal.or_selfsupervision.id
    application_id = azuread_service_principal.or_selfsupervision.application_id
    display_name   = azuread_service_principal.or_selfsupervision.display_name
  }
}

output sp_or_terraform {
  value = {
    id             = azuread_service_principal.or_terraform.id
    application_id = azuread_service_principal.or_terraform.application_id
    display_name   = azuread_service_principal.or_terraform.display_name
  }
}

output sp_or_tobtrack {
  value = {
    id             = azuread_service_principal.or_tobtrack.id
    application_id = azuread_service_principal.or_tobtrack.application_id
    display_name   = azuread_service_principal.or_tobtrack.display_name
  }
}

output sp_or_app {
  value = {
    id             = azuread_service_principal.or_app.id
    application_id = azuread_service_principal.or_app.application_id
    display_name   = azuread_service_principal.or_app.display_name
  }
}

output sp_platform_devops {
  value = {
    id             = azuread_service_principal.platform_devops.id
    application_id = azuread_service_principal.platform_devops.application_id
    display_name   = azuread_service_principal.platform_devops.display_name
  }
}

output sp_platform_sharepoint {
  value = {
    id             = azuread_service_principal.platform_sharepoint.id
    application_id = azuread_service_principal.platform_sharepoint.application_id
    display_name   = azuread_service_principal.platform_sharepoint.display_name
  }
}

output sp_powerbi_kdig {
  value = {
    id             = azuread_service_principal.powerbi_kdig.id
    application_id = azuread_service_principal.powerbi_kdig.application_id
    display_name   = azuread_service_principal.powerbi_kdig.display_name
  }
}

output sp_pxm_devops {
  value = {
    id             = azuread_service_principal.pxm_devops.id
    application_id = azuread_service_principal.pxm_devops.application_id
    display_name   = azuread_service_principal.pxm_devops.display_name
  }
}

output sp_pxm_eventhub {
  value = {
    id             = azuread_service_principal.pxm_eventhub.id
    application_id = azuread_service_principal.pxm_eventhub.application_id
    display_name   = azuread_service_principal.pxm_eventhub.display_name
  }
}

output sp_qlik_gt {
  value = {
    id             = azuread_service_principal.qlik_gt.id
    application_id = azuread_service_principal.qlik_gt.application_id
    display_name   = azuread_service_principal.qlik_gt.display_name
  }
}

output sp_retrobonus_adb {
  value = {
    id             = azuread_service_principal.retrobonus_adb.id
    application_id = azuread_service_principal.retrobonus_adb.application_id
    display_name   = azuread_service_principal.retrobonus_adb.display_name
  }
}

output sp_salesforce_adb {
  value = {
    id             = azuread_service_principal.salesforce_adb.id
    application_id = azuread_service_principal.salesforce_adb.application_id
    display_name   = azuread_service_principal.salesforce_adb.display_name
  }
}

output sp_scimintegrator_int {
  value = {
    id             = azuread_service_principal.scimintegrator_int.id
    application_id = azuread_service_principal.scimintegrator_int.application_id
    display_name   = azuread_service_principal.scimintegrator_int.display_name
  }
}

output sp_scimintegrator_kdig {
  value = {
    id             = azuread_service_principal.scimintegrator_kdig.id
    application_id = azuread_service_principal.scimintegrator_kdig.application_id
    display_name   = azuread_service_principal.scimintegrator_kdig.display_name
  }
}

output sp_securityreader {
  value = {
    id             = azuread_service_principal.securityreader.id
    application_id = azuread_service_principal.securityreader.application_id
    display_name   = azuread_service_principal.securityreader.display_name
  }
}

output sp_wfo_edw {
  value = {
    id             = azuread_service_principal.wfo_edw.id
    application_id = azuread_service_principal.wfo_edw.application_id
    display_name   = azuread_service_principal.wfo_edw.display_name
  }
}

output sp_zetes_devops {
  value = {
    id             = azuread_service_principal.zetes_devops.id
    application_id = azuread_service_principal.zetes_devops.application_id
    display_name   = azuread_service_principal.zetes_devops.display_name
  }
}

output "sp_cnp" {
  value = {
    id             = azuread_service_principal.cnp_adb.id
    application_id = azuread_service_principal.cnp_adb.application_id
    display_name   = azuread_service_principal.cnp_adb.display_name
  }
}

output "sp_wolt" {
  value = {
    id             = azuread_service_principal.wolt_adb.id
    application_id = azuread_service_principal.wolt_adb.application_id
    display_name   = azuread_service_principal.wolt_adb.display_name
  }
}

output "sp_kconfluent_devops" {
  value = {
    id             = azuread_service_principal.kconfluent_devops.id
    application_id = azuread_service_principal.kconfluent_devops.application_id
    display_name   = azuread_service_principal.kconfluent_devops.display_name
  }
}

output sp_wolt_rpa {
  value = {
    id             = azuread_service_principal.wolt_rpa_adb.id
    application_id = azuread_service_principal.wolt_rpa_adb.application_id
    display_name   = azuread_service_principal.wolt_rpa_adb.display_name
  }
}

output "sp_clm_adb" {
  value = {
    id             = azuread_service_principal.clm_adb.id
    application_id = azuread_service_principal.clm_adb.application_id
    display_name   = azuread_service_principal.clm_adb.display_name
  }
}

output "sp_export_to_data_lake" {
  value = {
    id             = data.azuread_service_principal.export_to_data_lake.id
    application_id = data.azuread_service_principal.export_to_data_lake.application_id
    display_name   = data.azuread_service_principal.export_to_data_lake.display_name
  }
}

output "sp_power_query_online" {
  value = {
    id             = data.azuread_service_principal.power_query_online.id
    application_id = data.azuread_service_principal.power_query_online.application_id
    display_name   = data.azuread_service_principal.power_query_online.display_name
  }
}

output "sp_kconfluent_externaldatalake" {
  value = {
    id             = azuread_service_principal.kconfluent_externaldatalake.id
    application_id = azuread_service_principal.kconfluent_externaldatalake.application_id
    display_name   = azuread_service_principal.kconfluent_externaldatalake.display_name
  }
}

output sp_kgenaimarketing {
  value = {
    id             = azuread_service_principal.kgenaimarketing.id
    application_id = azuread_service_principal.kgenaimarketing.application_id
    display_name   = azuread_service_principal.kgenaimarketing.display_name
  }
}

output sp_kgenaicontractcenter {
  value = {
    id             = azuread_service_principal.kgenaicontractcenter.id
    application_id = azuread_service_principal.kgenaicontractcenter.application_id
    display_name   = azuread_service_principal.kgenaicontractcenter.display_name
  }
}

output sp_kgenaicontractcenter_crud {
  value = {
    id             = azuread_service_principal.kgenaicontractcenter_crud.id
    application_id = azuread_service_principal.kgenaicontractcenter_crud.application_id
    display_name   = azuread_service_principal.kgenaicontractcenter_crud.display_name
  }
}

output sp_kgenaicontractcenter_sharepoint {
  value = {
    id             = azuread_service_principal.kgenaicontractcenter_sharepoint.id
    application_id = azuread_service_principal.kgenaicontractcenter_sharepoint.application_id
    display_name   = azuread_service_principal.kgenaicontractcenter_sharepoint.display_name
  }
}

output "sp_platform_dynatrace" {
  value = {
    id             = azuread_service_principal.platform_dynatrace.id
    application_id = azuread_service_principal.platform_dynatrace.application_id
    display_name   = azuread_service_principal.platform_dynatrace.display_name
  }
}
