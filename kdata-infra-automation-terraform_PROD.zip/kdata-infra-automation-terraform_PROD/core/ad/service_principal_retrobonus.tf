# ---------------------------------------------------------------------------------------------
# retrobonus-adb
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "retrobonus_adb" {
  display_name = "${var.prefix_sp}-retrobonus-adb-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "retrobonus_adb" {
  application_id = azuread_application.retrobonus_adb.application_id
  owners         = local.owners
  tags           = ["HideApp"]
}

resource "azuread_service_principal_password" "retrobonus_adb" {
  service_principal_id = azuread_service_principal.retrobonus_adb.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}
