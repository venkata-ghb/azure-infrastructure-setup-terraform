# ---------------------------------------------------------------------------------------------
# kpartner-dynamics
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "kpartner_dynamics" {
  display_name = "${var.prefix_sp}-kpartner-dynamics-sp"
  owners       = local.owners

  required_resource_access {
    resource_app_id = "00000003-0000-0000-c000-000000000000"

    resource_access {
      id   = "e1fe6dd8-ba31-4d61-89e7-88639da4683d"
      type = "Scope"
    }
  }

  required_resource_access {
    resource_app_id = "00000007-0000-0000-c000-000000000000"

    resource_access {
      id   = "78ce3f0f-a1ce-49c2-8cde-64b5c0896db4"
      type = "Scope"
    }
  }

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "kpartner_dynamics" {
  application_id = azuread_application.kpartner_dynamics.application_id
  owners         = local.owners
  tags           = ["WindowsAzureActiveDirectoryIntegratedApp", "HideApp"]
}

resource "azuread_service_principal_password" "kpartner_dynamics" {
  service_principal_id = azuread_service_principal.kpartner_dynamics.id
  end_date             = var.pwd_expr_date_crit
  display_name         = "primary"
}
