# ---------------------------------------------------------------------------------------------
# CNP
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "cnp_adb" {
  display_name = "${var.prefix_sp}-cnp-adb-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "cnp_adb" {
  application_id = azuread_application.cnp_adb.application_id
  owners         = local.owners
  tags           = ["WindowsAzureActiveDirectoryIntegratedApp", "HideApp"]
}

resource "azuread_service_principal_password" "cnp_adb" {
  service_principal_id = azuread_service_principal.cnp_adb.id
  end_date             = var.pwd_expr_date_crit
}
