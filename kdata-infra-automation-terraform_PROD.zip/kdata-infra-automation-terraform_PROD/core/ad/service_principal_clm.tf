# ---------------------------------------------------------------------------------------------
# CLM
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "clm_adb" {
  display_name = "${var.prefix_sp}-clm-adb-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "clm_adb" {
  application_id = azuread_application.clm_adb.application_id
  owners         = local.owners
  tags           = ["WindowsAzureActiveDirectoryIntegratedApp", "HideApp"]
}

resource "azuread_service_principal_password" "clm_adb" {
  service_principal_id = azuread_service_principal.clm_adb.id
  end_date             = var.pwd_expr_date_crit
}
