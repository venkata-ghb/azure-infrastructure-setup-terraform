# ---------------------------------------------------------------------------------------------
# Wolt-databricks
# ---------------------------------------------------------------------------------------------
resource "azuread_application" "wolt_adb" {
  display_name = "${var.prefix_sp}-wolt-adb-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "wolt_adb" {
  application_id = azuread_application.wolt_adb.application_id
  owners         = local.owners
  tags           = ["DatabricksForWolt", ]
}

resource "azuread_service_principal_password" "wolt_adb" {
  service_principal_id = azuread_service_principal.wolt_adb.id
  end_date             = var.pwd_expr_date_crit2
  display_name         = "primary"
}
# ----------------------------------------------------------
# WOLT RPA
# ----------------------------------------------------------

resource "azuread_application" "wolt_rpa_adb" {
  display_name = "${var.prefix_sp}-wolt-rpa-sp"
  owners       = local.owners

  lifecycle { ignore_changes = [api, web] }
}

resource "azuread_service_principal" "wolt_rpa_adb" {
  application_id = azuread_application.wolt_rpa_adb.application_id
  owners         = local.owners
  tags           = ["WindowsAzureActiveDirectoryIntegratedApp", "HideApp"]
}

resource "azuread_service_principal_password" "wolt_rpa_adb" {
  service_principal_id = azuread_service_principal.wolt_rpa_adb.id
  end_date             = var.pwd_expr_date_crit2
  display_name         = "primary"
}
