variable pwd_expr_date {
  type        = string
  description = "Service principal password expiration date"
  default     = "2024-01-01T01:03:03Z"
}

variable pwd_expr_date_crit {
  type        = string
  description = "Service principal password expiration date"
  default     = "2028-03-31T01:03:03Z"
}

variable pwd_expr_date_crit2 {
  type        = string
  description = "Service principal password expiration date"
  default     = "2028-03-31T01:03:03Z"
}

variable prefix_ad_group {
  type        = string
  description = "Prefix for AD groups"
  default     = "AZ_KDATA_PROD"
}

variable prefix_apim_ad_group {
  type        = string
  description = "Prefix for API management related AD groups"
  default     = "AZ_APIM_PROD_KDATA"
}

variable prefix_sp {
  type        = string
  description = "Prefix for Service Principals"
  default     = "kdata-prod"
}
