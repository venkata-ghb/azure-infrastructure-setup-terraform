output sp_advancedanalytics_adb_password {
  value     = azuread_service_principal_password.advancedanalytics_adb.value
  sensitive = true
}

output sp_attrbmodeling_adfrm_password {
  value     = azuread_service_principal_password.attrbmodeling_adfrm.value
  sensitive = true
}

output sp_attrbmodeling_slfrc_password {
  value     = azuread_service_principal_password.attrbmodeling_slfrc.value
  sensitive = true
}

output "sp_cnp_adb_password" {
  value     = azuread_service_principal_password.cnp_adb.value
  sensitive = true
}

output "sp_catman_adb_password" {
  value     = azuread_service_principal_password.catman_adb.value
  sensitive = true
}

output "sp_controlm_adf_password" {
  value     = azuread_service_principal_password.controlm_adf.value
  sensitive = true
}

output "sp_controlm_adb_password" {
  value     = azuread_service_principal_password.controlm_adb.value
  sensitive = true
}

output "sp_ds_deltalake_password" {
  value     = azuread_service_principal_password.ds_deltalake.value
  sensitive = true
}

output "sp_wolt_adb_password" {
  value     = azuread_service_principal_password.wolt_adb.value
  sensitive = true
}

output "sp_kconfluent_devops_password" {
  value     = azuread_service_principal_password.kconfluent_devops.value
  sensitive = true
}

output "sp_wolt_rpa_adb_password" {
  value     = azuread_service_principal_password.wolt_rpa_adb.value
  sensitive = true
}

output "sp_lumi_adb_password" {
  value     = azuread_service_principal_password.lumi_adb.value
  sensitive = true
}

output "sp_feedbuilder_qlik_password" {
  value     = azuread_service_principal_password.feedbuilder_qlik.value
  sensitive = true
}

output "sp_retrobonus_adb_password" {
  value     = azuread_service_principal_password.retrobonus_adb.value
  sensitive = true
}

output "sp_qlik_gt_password" {
  value     = azuread_service_principal_password.qlik_gt.value
  sensitive = true
}

output "sp_metastore_adb_password" {
  value     = azuread_service_principal_password.adb_metastore.value
  sensitive = true
}

output "sp_salesforce_adb_password" {
  value     = azuread_service_principal_password.salesforce_adb.value
  sensitive = true
}

output "sp_apim_authentication_password" {
  value     = azuread_service_principal_password.apim_authentication.value
  sensitive = true
}

output "sp_clm_adb_password" {
  value     = azuread_service_principal_password.clm_adb.value
  sensitive = true
}

output "sp_gtanalytics_adb_password" {
  value     = azuread_service_principal_password.gtanalytics_adb.value
  sensitive = true
}

output "sp_or_konvehti_fe_password" {
  value     = azuread_service_principal_password.or_konvehti_fe.value
  sensitive = true
}

output "sp_kruoka_databricks_password" {
  value     = azuread_service_principal_password.kruoka_databricks.value
  sensitive = true
}

output "sp_kruoka_eventhub_password" {
  value     = azuread_service_principal_password.kruoka_eventhub.value
  sensitive = true
}

output "sp_wfo_edw_password" {
  value     = azuread_service_principal_password.wfo_edw.value
  sensitive = true
}

output "sp_kpartner_dynamics_password" {
  value     = azuread_service_principal_password.kpartner_dynamics.value
  sensitive = true
}

output "sp_gtkpartner_adb_password" {
  value     = azuread_service_principal_password.gtkpartner_adb.value
  sensitive = true
}

output "sp_neste_eventhub_password" {
  value     = azuread_service_principal_password.neste_eventhub.value
  sensitive = true
}

output "sp_neste_databricks_password" {
  value     = azuread_service_principal_password.neste_databricks.value
  sensitive = true
}

output "sp_pxm_eventhub_password" {
  value     = azuread_service_principal_password.pxm_eventhub.value
  sensitive = true
}

output "sp_campaign_deltalake_password" {
  value     = azuread_service_principal_password.campaign_deltalake.value
  sensitive = true
}

output "sp_campaign_eventhub_password" {
  value     = azuread_service_principal_password.campaign_eventhub.value
  sensitive = true
}

output "sp_kvalikoima_databricks_password" {
  value     = azuread_service_principal_password.kvalikoima_databricks.value
  sensitive = true
}

output "sp_kvalikoima_dbwrite_password" {
  value     = azuread_service_principal_password.kvalikoima_dbwrite.value
  sensitive = true
}


output sp_or_azdevops_password {
  value     = azuread_service_principal_password.or_azdevops.value
  sensitive = true
}

output sp_or_b2bdr_password {
  value     = azuread_service_principal_password.or_b2bdr.value
  sensitive = true
}

output sp_or_bookkeeping_password {
  value     = azuread_service_principal_password.or_bookkeeping.value
  sensitive = true
}

output sp_or_companyinfo_password {
  value     = azuread_service_principal_password.or_companyinfo.value
  sensitive = true
}

output sp_or_datapower_password {
  value     = azuread_service_principal_password.or_datapower.value
  sensitive = true
}

output sp_or_dbmaintenance_password {
  value     = azuread_service_principal_password.or_dbmaintenance.value
  sensitive = true
}

output sp_or_deltalake_password {
  value     = azuread_service_principal_password.or_deltalake.value
  sensitive = true
}

output sp_or_edw_password {
  value     = azuread_service_principal_password.or_edw.value
  sensitive = true
}

output sp_or_etl_password {
  value     = azuread_service_principal_password.or_etl.value
  sensitive = true
}

output sp_or_flyway_sql_password {
  value     = azuread_service_principal_password.or_flyway_sql.value
  sensitive = true
}

output sp_or_lastdaysales_password {
  value     = azuread_service_principal_password.or_lastdaysales.value
  sensitive = true
}

output sp_or_match_password {
  value     = azuread_service_principal_password.or_match.value
  sensitive = true
}

output sp_or_nestedayend_password {
  value     = azuread_service_principal_password.or_nestedayend.value
  sensitive = true
}

output sp_or_plussa_password {
  value     = azuread_service_principal_password.or_plussa.value
  sensitive = true
}

output sp_or_robot_password {
  value     = azuread_service_principal_password.or_robot.value
  sensitive = true
}

output sp_or_selfsupervision_password {
  value     = azuread_service_principal_password.or_selfsupervision.value
  sensitive = true
}

output sp_or_terraform_password {
  value     = azuread_service_principal_password.or_terraform.value
  sensitive = true
}

output sp_or_tobtrack_password {
  value     = azuread_service_principal_password.or_tobtrack.value
  sensitive = true
}

output sp_kconfluent_externaldatalake_password {
  value     = azuread_service_principal_password.kconfluent_externaldatalake.value
  sensitive = true
}

output "sp_aecorsoft_sink_password" {
  value     = azuread_service_principal_password.aecorsoft_sink.value
  sensitive = true
}

output sp_or_kai_password {
  value     = azuread_service_principal_password.or_kai.value
  sensitive = true
}

output sp_or_app_password {
  value     = azuread_service_principal_password.or_app.value
  sensitive = true
}

output sp_platform_sharepoint_password {
  value     = azuread_service_principal_password.platform_sharepoint.value
  sensitive = true
}

output "sp_kgenaimarketing_password" {
  value     = azuread_service_principal_password.kgenaimarketing.value
  sensitive = true
}

output sp_powerbi_kdig_password {
  value     = azuread_service_principal_password.powerbi_kdig.value
  sensitive = true
}

output "sp_kgenaicontractcenter_password" {
  value     = azuread_service_principal_password.kgenaicontractcenter.value
  sensitive = true
}

output "sp_kgenaicontractcenter_crud_password" {
  value     = azuread_service_principal_password.kgenaicontractcenter_crud.value
  sensitive = true
}

output "sp_kgenaicontractcenter_sharepoint_password" {
  value     = azuread_service_principal_password.kgenaicontractcenter_sharepoint.value
  sensitive = true
}

output sp_platform_dynatrace_password {
  value     = azuread_service_principal_password.platform_dynatrace.value
  sensitive = true
}
