# principl values to be updated based on the databricks group ids creation 
locals {
  connection_grant = [
    {
      principal  = "ws-coreis-apm0012158-workspaceadmins-dev"
      privileges = ["ALL_PRIVILEGES","USE_CONNECTION","MANAGE","CREATE_FOREIGN_CATALOG"]
    } 
  ]

  storage_grant = [
    {
      principal  = "ws-coreis-apm0012158-workspaceadmins-dev"
      privileges = ["ALL_PRIVILEGES", "MANAGE"]
    } 
  ] 

  ext_loc_grant = [
    {
      principal  = "ws-coreis-apm0012158-workspaceadmins-dev"
      privileges = ["ALL_PRIVILEGES", "MANAGE"]
    }
  ] 

  catalog_grant_storage = [
    {
      principal  = "ws-coreis-apm0012158-workspaceadmins-dev"
      privileges = ["ALL_PRIVILEGES", "MANAGE", "EXTERNAL_USE_SCHEMA", "USE_CATALOG"]
    } 
  ]

  catalog_grant_db = [
    {
      principal  = "ws-coreis-apm0012158-workspaceadmins-dev"
      privileges = ["ALL_PRIVILEGES","MANAGE","USE_SCHEMA", "SELECT", "USE_CATALOG"]
    }
  ]
}