data "azurerm_client_config" "current" {}

data "azurerm_subnet" "endpoint_subnet" {
  name                 = var.pvt_endpoint_subnet_name
  virtual_network_name = var.coreai_vnet_name
  resource_group_name  = var.coreai_rg_name
}

data "azurerm_private_dns_zone" "databricks_dns_zone" {
  provider            = azurerm.private_dns_zones_subscription
  name                = var.dbx_private_dns_zone_name
  resource_group_name = var.private_dns_zone_rg_name
}

data "azurerm_databricks_access_connector" "dbx_dev_access_connector" {
  for_each = var.rbac_sa_list
  name                = each.value.dbx_access_connector_name
  resource_group_name = each.value.dbx_access_connector_rg_name
}

data "azurerm_storage_account" "storage_accounts" {
  provider = azurerm.ace_dev_subscription
  for_each = var.rbac_sa_list
  name                = each.value.storage_account_name
  resource_group_name = each.value.storage_account_rg_name
}