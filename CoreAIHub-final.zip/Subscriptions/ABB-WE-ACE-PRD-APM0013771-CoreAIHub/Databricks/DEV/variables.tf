# Subscription common variables

variable "databricks_account_id" {
  description = "Specifies Databricks account id"
  type        = string
}
variable "apm0012158_dev_databricks_host" {
  description = "Represents the Databricks host URL"
  type        = string
}
variable "coreai_vnet_name" {
  description = "Specifies the Virtual network"
  type        = string
}
variable "coreai_rg_name" {
  description = "Specifies the Virtual network RG"
  type        = string
}

variable "dbx_private_dns_zone_name" {
  type        = string
  description = "Specifies databricks workspace private dns zone name"
}
variable "private_dns_zone_rg_name" {
  type        = string
  description = "Private dns zone name resource group"
}
variable "private_dns_zone_subscription_id" {
  type        = string
  description = "Private dns zone resources subscription ID"
}
variable "ace_dev_subscription_id" {
  type        = string
  description = "ACE DEV resources subscription ID"
}
variable "network_resource_location" {
  description = "The location/region where the network resources created."
  type        = string
}

variable "pvt_endpoint_subnet_name" {
  description = "Specifies the subnet name of used for private endpoints"
  type        = string
}
###################----------------- Part-1 Deployments-------------------------#################
##---RGs list variable
variable "rg_list" {
  description = "Specifies the resource groups creation list"
  type = map(object({
    rg_name  = string
    location = string
    tags     = map(string)
  }))
}

##---Subnets list variable
variable "subnet_list" {
  description = "Specifies the Subnets creation list"
  type = map(object({
    subnet_name          = string
    rg_name              = string
    subnet_address_space = list(string)
    vnet_name            = string
    enable_delegation    = list(object({
      delegation_name    = string
      actions            = list(string)
      }))
  }))
}

##---NSGs list Variable
variable "nsg_list" {
  description = "Specifies the NSGs creation list"
  type = map(object({
    nsg_name = string
    rg_name  = string
    location = string
    tags     = map(string)
  }))
}

##--- NSG-Subnet association list variable
variable "nsg_snet_assoc_list" {
  description = "Specifies the Subnets and NSGs associations list"
  type = map(object({
    subnet_id      = string
    nsg_id         = string
  }))
}

##----Data bricks workspace list variable

variable "dbx_ws_list" {
  description = "Specifies the Dtabricks list"
  type = map(object({
    dbx_ws_name                      = string
    rg_name                          = string
    location                         = string
    dbx_ws_sku                       = string
    dbx_ws_managed_rg_name           = string
    enable_public_network_access     = bool
    enable_infrastructure_encryption = bool
    required_nsg_rules               = string
    private_subnet_name              = string
    public_subnet_name               = string
    dbx_vnet_name                    = string
    dbx_vnet_rg_name                 = string
    dbx_endpoint_name                = string
    enable_manual_connection         = bool
    subresource_names                = list(string)
    enable_private_dns_zone_group    = bool
    tags                             = map(string)
  }))
}

###################----------------- Part-2 Deployments-------------------------#################

##----Role Assignement list variable

variable "rbac_list" {
  description = "Assigning role to the databricks workspace with entra group object id"
  type = map(object({
    scope_type           = string
    scope_id             = string
    scope_rg_name        = string
    principal_tpye       = string
    principal_id         = string 
    principal_rg_name    = string
    role_definition_name = string
  }))
}
variable "rbac_sa_list" {
  description = "Assigning role to the storage account with databricks access connector principal identity id"
  type = map(object({
    storage_account_name         = string
    storage_account_rg_name      = string
    dbx_access_connector_name    = string
    dbx_access_connector_rg_name = string
    role_definition_name         = string
  }))
}
##---- Databricks connection list variable
variable "dbx_conn_sql" {
  type = map(object({
    connection_name = string
    connection_type = string
    comment         = string
  }))
}
variable "host" {
  description = "host name of the server"
  type = string
}
variable "port" {
  description = "Port number"
  type = string
}
variable "user_name" {
  description = "Username for connection"
  type = string
}
variable "password" {
  description = "Password for connection"
  type = string
}
##---- Storage credential list variable
variable "dbx_storage_credential_list" {
  description = "Specifies the Storage credential deployments list to the Dtabricks"
  type = map(object({
    storage_cred_name            = string
    dbx_access_connector_name    = string
    dbx_access_connector_rg_name = string
    force_destroy                = bool
    skip_validation              = bool
    comment                      = string
  }))
}

##----- Databricks External location list variable
variable "dbx_external_location_list" {
  description = "Specifies the External locations deployments list to the Dtabricks"
  type = map(object({
    ext_location_name       = string
    storage_cred_name       = string
    ext_loc_path            = string
    storage_account_name    = string
    storage_container_name  = string
    force_destroy           = bool
    skip_validation         = bool
    comment                 = string
  }))
}

##---- Catalog databricks list variables
variable "dbx_catalog_list" {
  description = "Specifies the Catalog deployments list to the Dtabricks"
  type = map(object({
    dbx_catalog_name = string
    use_storage_root = bool
    ext_loc_url      = string
    dbx_ws_id        = string
    force_destroy    = bool
    comment          = string
    connection_name  = string
  }))
}
variable "database_name" {
  description = "Name of the SQL Database"
  type = string
}