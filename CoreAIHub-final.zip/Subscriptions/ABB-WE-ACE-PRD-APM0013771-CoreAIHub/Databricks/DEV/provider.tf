provider "azurerm" {
	features {}
	resource_provider_registrations = "none"
}

provider "azuread" {
  tenant_id = data.azurerm_client_config.current.tenant_id
}

provider "databricks" {
  host       = var.apm0012158_dev_databricks_host
  account_id = var.databricks_account_id
}

provider "azurerm" {
  features {}
  alias 			    = "private_dns_zones_subscription"
  subscription_id	= var.private_dns_zone_subscription_id
}

provider "azurerm" {
  features {}
  alias = "ace_dev_subscription"
  subscription_id = var.ace_dev_subscription_id
}