###################----------------- Part-1 Deployments-------------------------#################

##--------------------------------------RGs---------------------------------------------------
module "rg" {
  for_each = var.rg_list
  source   = "../../../../Terraform_Modules/ResourceGroup"
  rg_name  = each.value.rg_name
  location = each.value.location
  tags     = each.value.tags     
}

##--------------------------------------Subnets---------------------------------------------------
module "subnet" {
  for_each             = var.subnet_list
  source               = "../../../../Terraform_Modules/Subnet"
  subnet_name          = each.value.subnet_name
  rg_name              = each.value.rg_name
  subnet_address_space = each.value.subnet_address_space
  enable_delegation    = each.value.enable_delegation
  vnet_name            = each.value.vnet_name
}

##--------------------------------------------NSG--------------------------------------------------

module "nsg" {
  for_each   = var.nsg_list
  source     = "../../../../Terraform_Modules/NSG"
  nsg_name   = each.value.nsg_name
  rg_name    = each.value.rg_name
  location   = each.value.location
  tags       = each.value.tags
}

##------------------------------------NSG Associations Subnets-------------------------------------

module "nsg_snet_assoc" {
  for_each       = var.nsg_snet_assoc_list
  source         = "../../../../Terraform_Modules/NsgAssociateSubnet"
  subnet_id      = module.subnet[each.value.subnet_id].subnet_id
  nsg_id         = module.nsg[each.value.nsg_id].nsg_id
}

##---------------------------------- Databricks Wrorkspace-----------------------------------------

module "data_bricks_workspace" {
  for_each                         = var.dbx_ws_list
  source                           = "../../../../Terraform_Modules/Databricks"
  dbx_ws_name                      = each.value.dbx_ws_name
  location                         = each.value.location
  rg_name                          = each.value.rg_name
  dbx_ws_sku                       = each.value.dbx_ws_sku
  dbx_ws_managed_rg_name           = each.value.dbx_ws_managed_rg_name
  enable_public_network_access     = each.value.enable_public_network_access
  enable_infrastructure_encryption = each.value.enable_infrastructure_encryption
  required_nsg_rules               = each.value.required_nsg_rules
  dbx_vnet_name                    = each.value.dbx_vnet_name
  dbx_vnet_rg_name                 = each.value.dbx_vnet_rg_name
  private_subnet_name              = each.value.private_subnet_name
  public_subnet_name               = each.value.public_subnet_name
  dbx_endpoint_name                = each.value.dbx_endpoint_name
  network_resource_location        = var.network_resource_location
  endpoint_subnet_id               = data.azurerm_subnet.endpoint_subnet.id
  enable_manual_connection         = each.value.enable_manual_connection
  subresource_names                = each.value.subresource_names
  enable_private_dns_zone_group    = each.value.enable_private_dns_zone_group
  private_dns_zone_ids             = [ data.azurerm_private_dns_zone.databricks_dns_zone.id ]
  tags 					                   = each.value.tags
  depends_on                       = [ module.subnet, module.nsg_snet_assoc ]
}

###################----------------- Part-2 Deployments-------------------------#################

##------------------------------------Role Assignement ---------------------------------------
module "rbac" {
  for_each     = var.rbac_list
  source       = "../../../../Terraform_Modules/RoleAssignment"
  scope_type           = each.value.scope_type
  scope_id             = each.value.scope_id
  scope_rg_name        = each.value.scope_rg_name
  role_definition_name = each.value.role_definition_name
  principal_tpye       = each.value.principal_tpye
  principal_id         = each.value.principal_id
  principal_rg_name    = each.value.principal_rg_name
}

module "rbac_sa_dbx_connector" {
  for_each     = var.rbac_sa_list
  source       = "../../../../Terraform_Modules/RoleAssignment_SA_DBX_Con"
  scope_id             = data.azurerm_storage_account.storage_accounts[each.key].id
  principal_id         = data.azurerm_databricks_access_connector.dbx_dev_access_connector[each.key].identity[0].principal_id
  role_definition_name = each.value.role_definition_name
  depends_on           = [ module.data_bricks_workspace ]
}
##------------------------------Databricks Connection-------------------------------------------

module "dbx_connection" {
  providers = {
    databricks = databricks
  }
  for_each          = var.dbx_conn_sql
  source            = "../../../../Terraform_Modules/Databricks/Connection"
  connection_name   = each.value.connection_name
  connection_type   = each.value.connection_type
  comment           = each.value.comment
  host              = var.host
  port              = var.port
  user_name         = var.user_name
  password          = var.password
  connection_grant  = local.connection_grant
}
##----------------------------------Databricks Storage credential-----------------------------------------
module "storage_credential_dbx" {
  providers = {
    databricks = databricks
  }
  for_each = var.dbx_storage_credential_list
  source = "../../../../Terraform_Modules/Databricks/Credential"
  storage_cred_name            = each.value.storage_cred_name
  dbx_access_connector_name    = each.value.dbx_access_connector_name
  dbx_access_connector_rg_name = module.data_bricks_workspace[each.value.dbx_access_connector_rg_name].managed_rg
  storage_grant                = local.storage_grant
  force_destroy                = each.value.force_destroy
  skip_validation              = each.value.skip_validation
  comment                      = each.value.comment
}

##------------------------------------- Databricks External location----------------------------------
module "dbx_external_location" {
  providers = {
    databricks = databricks
  }
  for_each = var.dbx_external_location_list
  source = "../../../../Terraform_Modules/Databricks/ExternalLocation"
  ext_location_name       = each.value.ext_location_name
  storage_account_name    = each.value.storage_account_name
  storage_container_name  = each.value.storage_container_name
  storage_cred_name       = module.storage_credential_dbx[each.value.storage_cred_name].sto_cred_name
  ext_loc_path            = each.value.ext_loc_path
  ext_loc_grant           = local.ext_loc_grant
  force_destroy           = each.value.force_destroy
  skip_validation         = each.value.skip_validation 
  comment                 = each.value.comment
}

##----------------------------------Databricks Catalog-----------------------------------------

module "dbx_catalog" {
  providers = {
    databricks = databricks
  }
  for_each = var.dbx_catalog_list
  source = "../../../../Terraform_Modules/Databricks/Catalog"
  dbx_catalog_name = each.value.dbx_catalog_name
  use_storage_root = each.value.use_storage_root
  ext_loc_url      = module.dbx_external_location[each.value.ext_loc_url].ext_loc_url 
  dbx_ws_id        = module.data_bricks_workspace[each.value.dbx_ws_id].ws_id
  force_destroy    = each.value.force_destroy
  comment          = each.value.comment
  connection_name  = each.value.connection_name
  database_name    = var.database_name
  catalog_grant    = each.value.connection_name != null ? local.catalog_grant_db : local.catalog_grant_storage
}