### ----------------------------Subscription common variables-------------------------------------
network_resource_location = "westeurope"                           # Network Azure Location
coreai_vnet_name          = "WE-ACE-DEV-Z1A-VNET85"                # Core AI vNet name
coreai_rg_name            = "ISWEACEDEV01-RG-01"                   # Core AI vNet RG name
pvt_endpoint_subnet_name  = "WE-ACE-DEV-Z1A-VNET85-INT07-PEP"      # Core AI subnet for private endpoints
apm0012158_dev_databricks_host = "https://adb-2415507055823018.18.azuredatabricks.net"
private_dns_zone_rg_name  = "ISWEHUB01-RG-F-DNS"                   # DNS zone RG Name
dbx_private_dns_zone_name = "privatelink.azuredatabricks.net"      # Databricks  private dns zone name

###################----------------- Part-1 Deployments-------------------------#################

###--------------------------------------RG-------------------------------------------------------
rg_list = {
  "CoreAIHub-WE-Databricks-DEV-RG" = {
    rg_name  = "CoreAIHub-WE-Databricks-DEV-RG"
    location = "westeurope" 
    tags  = {
      "Environment"    = "DEV"
      "Project"        = "Moon"
      "Application ID" = "APM0012158"
    }
  }
}

###--------------------------------------Subnet-------------------------------------------------
subnet_list = {
  "WE-ACE-DEV-Z1A-VNET85-INT01-APM0012158-PVT" = {
    subnet_name           = "WE-ACE-DEV-Z1A-VNET85-INT01-APM0012158-PVT"
    rg_name               = "ISWEACEDEV01-RG-01"
    subnet_address_space  = ["10.230.63.64/28"]
    vnet_name             = "WE-ACE-DEV-Z1A-VNET85"
    enable_delegation     = [ {
      delegation_name = "Microsoft.Databricks/workspaces"
      actions         = ["Microsoft.Network/virtualNetworks/subnets/join/action", "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action", "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action"]
    }]
  },
  "WE-ACE-DEV-Z1A-VNET85-INT01-APM0012158-PUB" = {
    subnet_name           = "WE-ACE-DEV-Z1A-VNET85-INT01-APM0012158-PUB"
    rg_name               = "ISWEACEDEV01-RG-01"
    vnet_name             = "WE-ACE-DEV-Z1A-VNET85"
    subnet_address_space  = ["10.230.63.80/28"]
    enable_delegation     = [ {
      delegation_name = "Microsoft.Databricks/workspaces"
      actions         = ["Microsoft.Network/virtualNetworks/subnets/join/action", "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action", "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action"]
    }]
  }
}

###----------------------------------------------NSG---------------------------------------------------
nsg_list = {
  "SN-NSG-DBX-INT01" = {
    nsg_name = "SN-NSG-DBX-INT01"
    rg_name  = "ISWEACEDEV01-RG-01"
    location = "westeurope" 
    tags  = {
      "Environment"    = "DEV"
      "Project"        = "Moon"
      "Application ID" = "APM0012158"
    }
  }
}

###-----------------------------------------NSG Subnet Association -------------------------------------
nsg_snet_assoc_list = {
  "pub_apm0012158_we_dev_nsg_snet_assoc" = { 
    subnet_id    = "WE-ACE-DEV-Z1A-VNET85-INT01-APM0012158-PUB"
    nsg_id       = "SN-NSG-DBX-INT01"
  },
  "pvt_apm0012158_we_dev_nsg_snet_assoc" = {
    subnet_id    = "WE-ACE-DEV-Z1A-VNET85-INT01-APM0012158-PVT"
    nsg_id       = "SN-NSG-DBX-INT01"
  }
}

###-------------------------------------Data Bricks WS---------------------------------------------------

dbx_ws_list = {
  "apm0012158-we-dev-ws" = {
    dbx_ws_name                      = "apm0012158-we-dev-ws"
    rg_name                          = "CoreAIHub-WE-Databricks-DEV-RG"
    location                         = "westeurope"
    dbx_ws_sku                       = "premium"
    dbx_ws_managed_rg_name           = "apm0012158-we-dev-managed-rg"
    enable_public_network_access     = false
    enable_infrastructure_encryption = false
    required_nsg_rules               = "NoAzureDatabricksRules"
    private_subnet_name              = "WE-ACE-DEV-Z1A-VNET85-INT01-APM0012158-PVT"
    public_subnet_name               = "WE-ACE-DEV-Z1A-VNET85-INT01-APM0012158-PUB"
    private_subnet_name_association  = "pvt_apm0012158_we_dev_nsg_snet_assoc"
    public_subnet_name_association   = "pub_apm0012158_we_dev_nsg_snet_assoc"
    dbx_vnet_name                    = "WE-ACE-DEV-Z1A-VNET85"
    dbx_vnet_rg_name                 = "ISWEACEDEV01-RG-01" 
    dbx_endpoint_name                = "apm0012158-we-dev-ws-pe"
    enable_manual_connection         = false
    subresource_names                = ["databricks_ui_api"]
    enable_private_dns_zone_group    = true
    tags  = {
      "Environment"    = "DEV"
      "Project"        = "Moon"
      "Application ID" = "APM0012158"
    }
  }
}


###################----------------- Part-2 Deployments-------------------------#################

###-------------------------------------Role Assignments---------------------------------------------------

rbac_list = { 
  "admin_grp_dbx" = {
    scope_type           = "Databricks"
    scope_id             = "apm0012158-we-dev-ws"     
    scope_rg_name        = "CoreAIHub-WE-Databricks-DEV-RG"
    role_definition_name = "Owner"
    principal_tpye       = "ADGroup"
    principal_id         = "ws-coreis-apm0012158-workspaceadmins-dev"
    principal_rg_name    = ""
  }
}

rbac_sa_list = {
  "rbac_sa_dbx_connector" = {
    storage_account_name         = "moon2ucdev"
    storage_account_rg_name      = "AI-HUB-APM0012158-RG"
    dbx_access_connector_name    = "unity-catalog-access-connector"
    dbx_access_connector_rg_name = "apm0012158-we-dev-managed-rg"
    role_definition_name         = "Storage Blob Data Contributor"
  }
}

##-------------------------------Databricks Connections-----------------------------

dbx_conn_sql = {
  "moon2-dev-connection" = {
    connection_name = "moon2-dev-connection"
    connection_type = "SQLSERVER"
    comment         = "this is a connection to sql db"
  }
}
##-------------------------------Databricks Storage credential-----------------------------

dbx_storage_credential_list = {
  "apm0012158-we-dev-sc" = {
    storage_cred_name            = "apm0012158-we-dev-sc"
    dbx_access_connector_name    = "unity-catalog-access-connector"
    dbx_access_connector_rg_name = "apm0012158-we-dev-ws"  # Index name from the Data bricks workspace block (apm0012158-we-dev-ws)
    skip_validation              = true
    force_destroy                = true
    comment                      = "Storage credentials for Analytics Creator Team for Dev environment."
  }
}

##------------------------------------- Databricks External location----------------------------------

dbx_external_location_list = {
  "apm0012158-we-dev-el" = {
    ext_location_name       = "apm0012158-we-dev-el"
    storage_cred_name       = "apm0012158-we-dev-sc"    # Index name from the Data bricks Storage credential block (apm0012158-we-dev-sc)
    storage_account_name    = "moon2ucdev"
    storage_container_name  = "apm0012158-we-dev-container"
    ext_loc_path            = ""
    skip_validation         = true
    force_destroy           = true
    comment                 = "External location for Analytics Creator Team for Dev environment."
  }
}

##----------------------------------Databricks Catalog-----------------------------------------

dbx_catalog_list = {
  "apm0012158-we-dev-catalog" = {
    dbx_catalog_name = "apm0012158-we-dev-catalog"
    use_storage_root = false
    ext_loc_url      = "apm0012158-we-dev-el"          # Index name from the Data bricks external location block ("apm0012158-we-dev-el"). 
    dbx_ws_id        = "apm0012158-we-dev-ws"          # Index name from the Data bricks workspace block (dbx_ws_list) index value 
    force_destroy    = true
    comment          = "Catalog for Analytics Creator Team for Dev environment."
    connection_name  = "moon2-dev-connection"
  }
}