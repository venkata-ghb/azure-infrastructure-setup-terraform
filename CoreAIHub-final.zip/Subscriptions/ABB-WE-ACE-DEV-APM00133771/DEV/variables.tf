# Subscription common variables

variable "network_resource_location" {
  description = "The location/region where the network resources created."
  type        = string
}
variable "ace_dev_vnet_name" {
  description = "Specifies the Virtual network"
  type        = string
}
variable "ace_dev_rg_name" {
  description = "Specifies the Virtual network RG"
  type        = string
}
variable "pvt_endpoint_subnet_name" {
  description = "Specifies the subnet name of used for private endpoints"
  type        = string
}

variable "ace_dev_subscription_id" {
  type        = string
  description = "ACE DEV resources subscription ID"
}   
variable "coreai_hub_subscription_id" {
  type        = string
  description = "CoreAIHub resources subscription ID"
}   

variable "sa_blob_private_dns_zone_name" {
  type        = string
  description = "Specifies storage account private dns zone name Blob"
}
variable "sa_dfs_private_dns_zone_name" {
  type        = string
  description = "Specifies storage account private dns zone name DFS"
}
variable "private_dns_zone_rg_name" {
  type        = string
  description = "Private dns zone name resource group"
}
variable "private_dns_zone_subscription_id" {
  type        = string
  description = "Private dns zone resources subscription ID"
}

##--- Storage Account list variable
variable "storage_account_list" {
  description = "Specifies the Storage accounts list"
  type = map(object({
    rg_name                          = string
    location                         = string
    sa_name                          = string
    sa_account_tier                  = string
    sa_access_tier                   = string
    sa_account_replication_type      = string
    allow_blob_public_access         = bool
    enable_public_network_access     = bool
    enable_infrastructure_encryption = bool
    enable_shared_access_key         = bool
    enable_cross_tenant_replication  = bool
    enable_versioning                = bool
    delete_retention_days            = number
    enable_hns                       = bool
    container_delete_retention_days  = number
    enable_large_file_share          = bool
    min_tls_version                  = string
    identity_type                    = string
    identity_ids                     = list(string)
    network_rules = object({
      bypass   	     = list(string)
      default_action = string
      ip_rules       = list(string)
    })
    sa_subnet_names                  = list(string)
    vnet_name                        = string
    vnet_rg_name                     = string
    containers = map(object({
      container_name   	    = string
      container_access_type = optional(string)
    }))
    enable_manual_connection      = bool
    sa_blob_endpoint_name         = string
    blob_subresource_names        = list(string)
    create_dfs_endpoint           = bool
    sa_dfs_endpoint_name          = string
    dfs_subresource_names         = list(string)
    enable_private_dns_zone_group = bool
    tags                          = map(string)
  }))
}

##----Role Assignement list variable

variable "rbac_list" {
  description = "Assigning role to the databricks workspace with entra group object id"
  type = map(object({
    scope_type           = string
    scope_id             = string
    scope_rg_name        = string
    principal_tpye       = string
    principal_id         = string 
    principal_rg_name    = string
    role_definition_name = string
  }))
}