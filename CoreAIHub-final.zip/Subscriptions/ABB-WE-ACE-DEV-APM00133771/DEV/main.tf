##------------------------------------Storage accounts-------------------------------------
module "storage_account" {
  for_each                         = var.storage_account_list
  source                           = "../../../Terraform_Modules/StorageAccount"
  rg_name                          = each.value.rg_name
  location                         = each.value.location
  sa_name                 	       = each.value.sa_name
  sa_account_tier                  = each.value.sa_account_tier
  sa_access_tier                   = each.value.sa_access_tier
  sa_account_replication_type      = each.value.sa_account_replication_type
  allow_blob_public_access         = each.value.allow_blob_public_access
  enable_public_network_access     = each.value.enable_public_network_access
  enable_infrastructure_encryption = each.value.enable_infrastructure_encryption
  enable_shared_access_key         = each.value.enable_shared_access_key
  enable_cross_tenant_replication  = each.value.enable_cross_tenant_replication
  enable_versioning                = each.value.enable_versioning 
  delete_retention_days            = each.value.delete_retention_days
  enable_hns                       = each.value.enable_hns
  container_delete_retention_days  = each.value.container_delete_retention_days
  enable_large_file_share          = each.value.enable_large_file_share
  min_tls_version                  = each.value.min_tls_version
  identity_type                    = each.value.identity_type
  identity_ids                     = each.value.identity_ids
  containers                       = each.value.containers
  network_rules                    = each.value.network_rules
  sa_subnet_names                  = each.value.sa_subnet_names
  vnet_name                        = each.value.vnet_name
  vnet_rg_name                     = each.value.vnet_rg_name
  other_subs_sa_subnet_ids         = local.other_subs_sa_subnet_ids
  network_resource_location        = var.network_resource_location
  endpoint_subnet_id               = data.azurerm_subnet.endpoint_subnet.id
  enable_manual_connection         = each.value.enable_manual_connection
  sa_blob_endpoint_name            = each.value.sa_blob_endpoint_name
  blob_subresource_names           = each.value.blob_subresource_names
  create_dfs_endpoint              = each.value.create_dfs_endpoint
  sa_dfs_endpoint_name             = each.value.sa_dfs_endpoint_name
  dfs_subresource_names            = each.value.dfs_subresource_names
  enable_private_dns_zone_group    = each.value.enable_private_dns_zone_group
  sa_blob_private_dns_zone_ids     = [data.azurerm_private_dns_zone.storage_blob_dns_zone.id]
  sa_dfs_private_dns_zone_ids      = [data.azurerm_private_dns_zone.storage_dfs_dns_zone.id]
  tags 					                   = each.value.tags
}

##------------------------------------Role Assignement ---------------------------------------
module "rbac" {
  for_each     = var.rbac_list
  source       = "../../../Terraform_Modules/RoleAssignment"
  scope_type           = each.value.scope_type
  scope_id             = each.value.scope_id
  scope_rg_name        = each.value.scope_rg_name
  role_definition_name = each.value.role_definition_name
  principal_tpye       = each.value.principal_tpye
  principal_id         = each.value.principal_id
  principal_rg_name    = each.value.principal_rg_name
  depends_on           = [ module.storage_account ]
}