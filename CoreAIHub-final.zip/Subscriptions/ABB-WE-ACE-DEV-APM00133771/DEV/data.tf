data "azurerm_client_config" "current" {}

data "azurerm_subnet" "endpoint_subnet" {
  name                 = var.pvt_endpoint_subnet_name
  virtual_network_name = var.ace_dev_vnet_name
  resource_group_name  = var.ace_dev_rg_name
}

data "azurerm_subnet" "sa_prd_coreai_subnets" {
  provider = azurerm.corai_hub_subscription
  for_each = local.sa_prd_coreai_subnets_list
  name                 = each.value.subnet_name
  virtual_network_name = each.value.vnet_name
  resource_group_name  = each.value.vnet_rg_name
}

data "azurerm_private_dns_zone" "storage_blob_dns_zone" {
  provider            = azurerm.private_dns_zones_subscription
  name                = var.sa_blob_private_dns_zone_name
  resource_group_name = var.private_dns_zone_rg_name
}

data "azurerm_private_dns_zone" "storage_dfs_dns_zone" {
  provider            = azurerm.private_dns_zones_subscription
  name                = var.sa_dfs_private_dns_zone_name
  resource_group_name = var.private_dns_zone_rg_name
}

