locals {
    sa_prd_coreai_subnets_list = {
      subnets_prd_coreai_vmss = {
        subnet_name  = "we-ace-dev-z1a-vnet85-int06-vmss"
        vnet_name    = "WE-ACE-DEV-Z1A-VNET85"
        vnet_rg_name = "ISWEACEDEV01-RG-01"
      },
      subnets_prd_coreai_pep = {
        subnet_name  = "WE-ACE-DEV-Z1A-VNET85-INT07-PEP"
        vnet_name    = "WE-ACE-DEV-Z1A-VNET85"
        vnet_rg_name = "ISWEACEDEV01-RG-01"
      }
    }

    other_subs_sa_subnet_ids = [for subnet in data.azurerm_subnet.sa_prd_coreai_subnets : subnet.id ]
}
