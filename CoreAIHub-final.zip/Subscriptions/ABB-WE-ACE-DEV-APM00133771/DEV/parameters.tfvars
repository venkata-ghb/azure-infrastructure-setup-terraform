### ----------------------------Subscription common variables-------------------------------------
network_resource_location     = "westeurope"                        # Network Azure Location
ace_dev_vnet_name             = "WE-ACE-DEV-Z1A-VNET66"             # ACE DEV vNet name
ace_dev_rg_name               = "ISWEACEDEV01-RG-01"                # ACE DEV vNet RG name
pvt_endpoint_subnet_name      = "WE-ACE-DEV-Z1A-VNET66-INI01-PEP"   # ACE DEV subscription subnet for private endpoints
private_dns_zone_rg_name      = "ISWEHUB01-RG-F-DNS"                # DNS zone RG Name
sa_blob_private_dns_zone_name = "privatelink.blob.core.windows.net" # Storage account blob private dns zone name 
sa_dfs_private_dns_zone_name  = "privatelink.dfs.core.windows.net"  # Storage account dfs private dns zone name

###-----------------------------------------Storage account--------------------------------------------

storage_account_list = {
  "moon2ucdev" = {
    sa_name                          = "moon2ucdev"
    rg_name                          = "AI-HUB-APM0012158-RG"  
    location                         = "westeurope"
    sa_account_tier                  = "Standard"
    sa_access_tier                   = "Hot"
    sa_account_replication_type      = "GRS"
    allow_blob_public_access         = false
    enable_public_network_access     = false
    enable_infrastructure_encryption = true
    enable_shared_access_key         = true
    enable_cross_tenant_replication  = false
    enable_versioning                = false
    delete_retention_days            = 0
    enable_hns                       = true
    container_delete_retention_days  = 0
    enable_large_file_share          = true
    min_tls_version                  = "TLS1_2"
    identity_type                    = "SystemAssigned"
    identity_ids                     = []
    network_rules = {
      bypass         = ["AzureServices"] 
      default_action = "Deny" 
      ip_rules       = []
    }
    sa_subnet_names                  = ["WE-ACE-DEV-Z1A-VNET66-INI01-PEP"]
    vnet_name                        = "WE-ACE-DEV-Z1A-VNET66"
    vnet_rg_name                     = "ISWEACEDEV01-RG-01" 
    containers = {
      container_1 = {
        container_name        = "apm0012158-we-dev-container"
      } 
    }
    enable_manual_connection         = false
    sa_blob_endpoint_name            = "moon2ucdev-blob-pe"
    blob_subresource_names           = ["blob"]
    create_dfs_endpoint              = true
    sa_dfs_endpoint_name             = "moon2ucdev-dfs-pe"
    dfs_subresource_names            = ["dfs"]
    enable_private_dns_zone_group    = true
    tags  = {
      "Environment"    = "DEV"
      "Project"        = "Moon"
      "Application ID" = "APM0012158"
    }
  }
}

##------------------------------------Role Assignement ---------------------------------------
rbac_list = { 
  "admin_grp_dbx_02" = {
    scope_type           = "Storage"
    scope_id             = "moon2ucdev"     
    scope_rg_name        = "AI-HUB-APM0012158-RG"
    role_definition_name = "Owner"
    principal_tpye       = "ADGroup"
    principal_id         = "ws-coreis-apm0012158-workspaceadmins-dev"
    principal_rg_name    = ""
  }
}