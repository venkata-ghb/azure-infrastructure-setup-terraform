provider "azurerm" {
	features {}
  resource_provider_registrations = "none"
  subscription_id = var.ace_dev_subscription_id
}

provider "azuread" {
  tenant_id = data.azurerm_client_config.current.tenant_id
}

provider "azurerm" {
  features {}
  alias 			    = "corai_hub_subscription"
  subscription_id	= var.coreai_hub_subscription_id
}

provider "azurerm" {
  features {}
  alias 			    = "private_dns_zones_subscription"
  subscription_id	= var.private_dns_zone_subscription_id
}
