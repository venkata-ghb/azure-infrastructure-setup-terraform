locals {
  other_subs_sa_subnet_ids = []
}
