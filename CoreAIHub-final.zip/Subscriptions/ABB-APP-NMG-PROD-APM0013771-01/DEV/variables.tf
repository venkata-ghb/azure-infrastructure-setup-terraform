# Subscription common variables
variable "network_resource_location" {
  description = "The location/region where the network resources created."
  type        = string
}
variable "cirrus_prod_vnet_name" {
  type        = string
  description = "Specifies the Cirrus subscription Virtual network"
}
variable "cirrus_prod_rg_name" {
  type        = string
  description = "Specifies the Cirrus subscription Virtual network RG"
}
variable "pvt_endpoint_subnet_name" {
  type        = string
  description = "Specifies the subnet name of used for private endpoints"
}
variable "keyvault_private_dns_zone_name" {
  description = "Specifies keyvault private dns zone name"
  type        = string
}
variable "sa_blob_private_dns_zone_name" {
  type        = string
  description = "Specifies storage account private dns zone name Blob"
}
variable "sa_dfs_private_dns_zone_name" {
  type        = string
  description = "Specifies storage account private dns zone name DFS"
}
variable "aisearch_private_dns_zone_name" {
  type        = string
  description = "Specifies AI Search service private dns zone name"
}
variable "private_dns_zone_rg_name" {
  description = "Private dns zone name resource group"
  type        = string
}
variable "private_dns_zone_subscription_id" {
  description = "West Europe HUB subscription ID to manage private dns zone records"
  type        = string
}

##---RGs list variable
variable "rg_list" {
  description = "Specifies the resource groups creation list"
  type = map(object({
    rg_name  = string
    location = string
    tags     = map(string)
  }))
}


##--- Storage Account list variable
variable "storage_account_list" {
  description = "Specifies the Storage accounts list"
  type = map(object({
    rg_name                          = string
    location                         = string
    sa_name                          = string
    sa_account_tier                  = string
    sa_access_tier                   = string
    sa_account_replication_type      = string
    allow_blob_public_access         = bool
    enable_public_network_access     = bool
    enable_infrastructure_encryption = bool
    enable_shared_access_key         = bool
    enable_cross_tenant_replication  = bool
    enable_versioning                = bool
    delete_retention_days            = number
    enable_hns                       = bool
    container_delete_retention_days  = number
    enable_large_file_share          = bool
    min_tls_version                  = string
    identity_type                    = string
    identity_ids                     = list(string)
    network_rules = object({
      bypass   	     = list(string)
      default_action = string
      ip_rules       = list(string)
    })
    sa_subnet_names                  = list(string)
    vnet_name                        = string
    vnet_rg_name                     = string
    containers = map(object({
      container_name   	    = string
      container_access_type = optional(string)
    }))
    enable_manual_connection      = bool
    sa_blob_endpoint_name         = string
    blob_subresource_names        = list(string)
    create_dfs_endpoint           = bool
    sa_dfs_endpoint_name          = string
    dfs_subresource_names         = list(string)
    enable_private_dns_zone_group = bool
    tags                          = map(string)
  }))
}

##--- Key Vault list variable
variable "keyvault_list" {
  description = "Specifies the list of keyvault and associated private endpoints"
  type = map(object({
    kv_name                       = string
    kv_sku_name                   = string
    rg_name                       = string
    location                      = string
    enable_disk_encryption        = bool
    soft_delete_retention_days    = number
    enable_purge_protection       = bool
    enable_rbac_authorization     = bool
    enable_public_network_access  = bool
    network_acls = object({
      bypass   	     = string
      default_action = string
      ip_rules       = list(string)
    })
    kv_endpoint_name              = string
    enable_manual_connection      = bool
    subresource_names             = list(string)
    enable_private_dns_zone_group = bool
    tags                          = map(string)
  }))
}

##--- AI Search Service list variable
variable "ai_search_list" {
  description = "Specifies the search services deployment list"
  type = map(object({
    ai_search_name                 = string
    rg_name                        = string 
    location                       = string
    ai_search_sku                  = string
    allowed_ips                    = list(string)
    enable_public_network_access   = bool
    enable_local_authentication    = bool
    authentication_failure_mode    = string
    hosting_mode                   = string
    partition_count                = number
    replica_count                  = number
    semantic_search_sku            = string
    network_rule_bypass_option     = string
    identity_type                  = string
    identity_ids                   = list(string)
    ai_search_endpoint_name        = string
    enable_manual_connection       = bool
    subresource_names              = list(string)
    enable_private_dns_zone_group  = bool
    tags                           = map(string)
  })) 
}


##--- Private links list variable
variable "pvt_links_list" {
  description = "Specifies the List of Shared Private Links"
  type = map(object({
    private_link_name          = string
    ai_search_name             = string
    subresource_name           = string 
    ai_foundry_service_name    = string
  }))
}

#-------------------------AI Services -------------------------------------
variable "ai_service_list" {
  description = "Specifies the details to deploy the AI Service."
  type        = map(object({ 
    ai_service_name               = string
    rg_name                       = string
    location                      = string
    ai_service_sku                = string
    custom_subdomain_name         = string
    public_network_access         = string
    identity_type                = string
    identity_ids                 = list(string)
    ai_service_endpoint_name      = string
    enable_manual_connection      = bool
    subresource_names             = list(string)
    enable_private_dns_zone_group = bool
    tags                          = map(string)
  }))
}

variable "ai_foundry_services_private_dns_zone_names" {
  type        = list(string)
  description = "Specifies ai services private dns zone name"
} 

#-------------------------AI Foundry Hub ------------------------------------------
variable "ai_foundry_hub_list" {
  description = "Azure AI Foundry configuration details"
  type        = map(object({
    ai_hub_name                  = string
    location                     = string
    rg_name                      = string
    sa_name                      = string
    key_vault_name               = string
    public_network_access        = string
    isolation_mode               = string
    identity_type                = string
    identity_ids                 = list(string)
    ai_hub_endpoint_name         = string
    enable_manual_connection      = bool
    subresource_names             = list(string)
    enable_private_dns_zone_group = bool
    tags                         = map(string)
  }))
}

variable "ai_foundry_hub_private_dns_zone_names" {
  type        = list(string)
  description = "Specifies ai foundry private dns zone name"
} 

#-------------------------AI Foundry Hub Connection------------------------------------------

variable "ai_foundry_hub_connection_list" {
  type = map(object({
    connection_name = string
    parent_name     = string
    category        = string
    resource_name   = string
  }))
  description = "Specifies the connections in the AI Foundry Hub."
}

#-------------------------AI Foundry Project -------------------------------------
variable "ai_foundry_project_list" {
  description = "Azure( Foundry project configuration details."
  type        = map(object({
    ai_project_name              = string
    ai_project_description       = string
    rg_name                      = string
    location                     = string
    ai_hub_name                  = string
    high_business_impact_enabled = bool
    identity_type                = string
    identity_ids                 = list(string)
    tags                         = map(string)
    public_network_access        = string
  }))
}

# #-------------------------AI Models deploy -------------------------------------
variable "ai_models_list" {
  description = "Specifies the details for the models deployment."
  type = map(object({
  ai_deployment_name     = string
  cognitive_account_name = string
  model_format           = string
  model_version          = string
  model_name             = string
  sku_capacity           = number
  sku_name               = string
  version_upgrade_option = string
  }))
}