data "azurerm_client_config" "current" {}

data "azurerm_subnet" "endpoint_subnet" {
  name                 = var.pvt_endpoint_subnet_name
  virtual_network_name = var.cirrus_prod_vnet_name
  resource_group_name  = var.cirrus_prod_rg_name
}
#--------------------------------- Private DNS Zone ------------------------------------------
data "azurerm_private_dns_zone" "keyvault_dns_zone" {
  provider            = azurerm.private_dns_zones_subscription
  name                = var.keyvault_private_dns_zone_name
  resource_group_name = var.private_dns_zone_rg_name
}

data "azurerm_private_dns_zone" "storage_blob_dns_zone" {
  provider            = azurerm.private_dns_zones_subscription
  name                = var.sa_blob_private_dns_zone_name
  resource_group_name = var.private_dns_zone_rg_name
}

data "azurerm_private_dns_zone" "storage_dfs_dns_zone" {
  provider            = azurerm.private_dns_zones_subscription
  name                = var.sa_dfs_private_dns_zone_name
  resource_group_name = var.private_dns_zone_rg_name
}

data "azurerm_private_dns_zone" "aisearch_dns_zone" {
  provider            = azurerm.private_dns_zones_subscription
  name                = var.aisearch_private_dns_zone_name
  resource_group_name = var.private_dns_zone_rg_name
}

data "azurerm_private_dns_zone" "ai_foundry_services_dns_zone" {
  provider            = azurerm.private_dns_zones_subscription
  for_each            = toset(var.ai_foundry_services_private_dns_zone_names)
  name                = each.key
  resource_group_name = var.private_dns_zone_rg_name
}

data "azurerm_private_dns_zone" "ai_foundry_hub_dns_zone" {
  provider            = azurerm.private_dns_zones_subscription
  for_each            = toset(var.ai_foundry_hub_private_dns_zone_names)
  name                = each.key
  resource_group_name = var.private_dns_zone_rg_name
}