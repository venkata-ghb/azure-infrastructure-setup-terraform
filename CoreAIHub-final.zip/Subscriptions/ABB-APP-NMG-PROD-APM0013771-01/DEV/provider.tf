provider "azurerm" {
	features {}
	resource_provider_registrations = "none"
}

provider "azapi" {
  alias 			= "azapi"
}

provider "azurerm" {
  features {}
  alias 			    = "private_dns_zones_subscription"
  subscription_id	= var.private_dns_zone_subscription_id
}