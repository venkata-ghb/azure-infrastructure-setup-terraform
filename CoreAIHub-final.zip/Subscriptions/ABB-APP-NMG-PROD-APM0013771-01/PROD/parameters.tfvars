### ----------------------------Subscription common variables----------------------------------

network_resource_location      = "swedencentral"                                # Network resource Azure Location
cirrus_prod_vnet_name          = "SWC-NP-APM0013771-01-APP-VNET01"              # Cirrus prod subscription vNet name
cirrus_prod_rg_name            = "SWC-NP-APM0013771-01-RG-F-NETWORK"            # Cirrus prod subscription vNet RG name
pvt_endpoint_subnet_name       = "SWC-NP-APM0013771-01-APP-VNET01-INT01-PEP"    # Cirrus prod subscription subnet for private endpoints
keyvault_private_dns_zone_name = "privatelink.vaultcore.azure.net"              # Keyvault private dns zone name
sa_blob_private_dns_zone_name  = "privatelink.blob.core.windows.net"            # Storage account blob private dns zone name   
sa_dfs_private_dns_zone_name   = "privatelink.dfs.core.windows.net"             # Storage account dfs private dns zone name
aisearch_private_dns_zone_name = "privatelink.search.windows.net"               # AI Search service private dns zone name
private_dns_zone_rg_name       = "ISWEHUB01-RG-F-DNS"                           # DNS zones RG Name

###--------------------------------------RG-------------------------------------------------------

rg_list = {
  "COREAIHUB-SC-SEARCH-PROD-RG" = {
    rg_name  = "COREAIHUB-SC-SEARCH-PROD-RG"
    location = "swedencentral" 
    tags = {
      application  = "core ai hub"
      costcenter   = "chgpl_52015103"
      environment  = "prod"
      igar         = "apm0013771"
      model        = "cirrus"
    }
  }
  "COREAIHUB-SC-MODELS-PROD-RG" = {
    rg_name  = "COREAIHUB-SC-MODELS-PROD-RG"
    location = "swedencentral"
    tags = {
      application  = "core ai hub"
      costcenter   = "chgpl_52015103"
      environment  = "prod"
      igar         = "apm0013771"
      model        = "cirrus"
    }
  }
  "COREAIHUB-SC-PROJECTS-PROD-RG" = {
    rg_name  = "COREAIHUB-SC-PROJECTS-PROD-RG"
    location = "swedencentral"
    tags = {
      application  = "core ai hub"
      costcenter   = "chgpl_52015103"
      environment  = "prod"
      igar         = "apm0013771"
      model        = "cirrus"
    }
  }
}

###-----------------------------------------Storage account--------------------------------------------

storage_account_list = {
  "coreaihubprodsa" = {
    sa_name                          = "coreaihubprodsa"
    rg_name                          = "COREAIHUB-SC-SEARCH-PROD-RG"
    location                         = "swedencentral"
    sa_account_tier                  = "Standard"
    sa_access_tier                   = "Hot"
    sa_account_replication_type      = "LRS"
    allow_blob_public_access         = false
    enable_public_network_access     = true
    enable_infrastructure_encryption = true
    enable_shared_access_key         = true
    enable_cross_tenant_replication  = false
    enable_versioning                = false
    delete_retention_days            = 7
    enable_hns                       = false
    container_delete_retention_days  = 0
    enable_large_file_share          = true
    min_tls_version                  = "TLS1_2"
    identity_type                    = "SystemAssigned"
    identity_ids                     = []
    network_rules                    = {
      bypass         = ["AzureServices"] 
      default_action = "Deny" 
      ip_rules       = []
    }
    sa_subnet_names                  = []
    vnet_name                        = ""
    vnet_rg_name                     = ""
    containers = {
      container_1 = {
        container_name        = "coreaihubprodsa-container01"
      } 
    }
    enable_manual_connection         = false
    sa_blob_endpoint_name            = "coreaihubprodsa-blob-pe"
    blob_subresource_names           = ["blob"]
    create_dfs_endpoint              = false
    sa_dfs_endpoint_name             = ""
    dfs_subresource_names            = []
    enable_private_dns_zone_group    = true
    tags  = {
      application  = "core ai hub"
      costcenter   = "chgpl_52015103"
      environment  = "prod"
      igar         = "apm0013771"
      model        = "cirrus"
    }
  },
  "coreaihubprodfoundrysa" = {
    sa_name                          = "coreaihubprodfoundrysa"
    rg_name                          = "COREAIHUB-SC-MODELS-PROD-RG"
    location                         = "swedencentral"
    sa_account_tier                  = "Standard"
    sa_access_tier                   = "Hot"
    sa_account_replication_type      = "LRS"
    allow_blob_public_access         = false
    enable_public_network_access     = true
    enable_infrastructure_encryption = true
    enable_shared_access_key         = true
    enable_cross_tenant_replication  = false
    enable_versioning                = false
    delete_retention_days            = 7
    enable_hns                       = false
    container_delete_retention_days  = 0
    enable_large_file_share          = true
    min_tls_version                  = "TLS1_2"
    identity_type                    = "SystemAssigned"
    identity_ids                     = []
    network_rules                    = {
      bypass         = ["AzureServices"] 
      default_action = "Deny" 
      ip_rules       = []
    }
    sa_subnet_names                  = []
    vnet_name                        = "SWC-NP-APM0013771-01-APP-VNET01"
    vnet_rg_name                     = "SWC-NP-APM0013771-01-RG-F-NETWORK"
    containers                       = {
      container_1 = {
        container_name        = "coreaihubprodfoundrysa-container01"
      }  
    }
    enable_manual_connection         = false
    sa_blob_endpoint_name            = "coreaihubprodfoundrysa-blob-pe"
    blob_subresource_names           = ["blob"]
    enable_private_dns_zone_group    = true
    create_dfs_endpoint              = false
    sa_dfs_endpoint_name             = ""
    dfs_subresource_names            = []
    tags  = {
      application  = "core ai hub"
      costcenter   = "chgpl_52015103"
      environment  = "prod"
      igar         = "apm0013771"
      model        = "cirrus"
    }
  }
}

##----------------------------------------- Search Services --------------------------------------
ai_search_list = {
  "coreaihub-prod-search" = {
    ai_search_name                 = "coreaihub-prod-search"
    rg_name                        = "COREAIHUB-SC-SEARCH-PROD-RG"
    location                       = "swedencentral"
    ai_search_sku                  = "standard"
    allowed_ips                    = []
    enable_public_network_access   = false
    enable_local_authentication    = false
    authentication_failure_mode    = null
    hosting_mode                   = "default"
    partition_count                = 1
    replica_count                  = 1
    semantic_search_sku            = "standard"
    network_rule_bypass_option     = "AzureServices"
    identity_type                  = "SystemAssigned"
    identity_ids                   = []
    ai_search_endpoint_name        = "coreaihub-prod-search-pe"
    enable_manual_connection       = false
    subresource_names              = ["searchService"]
    enable_private_dns_zone_group  = true
    tags     = {
      application  = "core ai hub"
      costcenter   = "chgpl_52015103"
      environment  = "prod"
      igar         = "apm0013771"
      model        = "cirrus"
    }  
  }
}

##----------------------------------- Key Vault Creation ---------------------------
keyvault_list = {
  "coreaihub-prod-kv" = {
    kv_name                       = "coreaihub-prod-kv"
    rg_name                       = "COREAIHUB-SC-SEARCH-PROD-RG"
    location                      = "swedencentral"
    kv_sku_name                   = "standard"
    enable_disk_encryption        = true
    soft_delete_retention_days    = 7
    enable_purge_protection       = true
    enable_rbac_authorization     = true
    enable_public_network_access  = true
    network_acls     = {
      bypass         = "AzureServices" 
      default_action = "Deny" 
      ip_rules       = []
    }
    kv_endpoint_name              = "coreaihub-prod-kv-pe"
    enable_manual_connection      = false
    subresource_names             = ["vault"]
    enable_private_dns_zone_group = true  
    tags     = {
      application  = "core ai hub"
      costcenter   = "chgpl_52015103"
      environment  = "prod"
      igar         = "apm0013771"
      model        = "cirrus"
    } 
  },
  "coreaihub-foundry-prd-kv" = {
    kv_name                       = "coreaihub-foundry-prd-kv"
    location                      = "swedencentral"
    rg_name                       = "COREAIHUB-SC-MODELS-PROD-RG"
    kv_sku_name                   = "standard"
    enable_disk_encryption        = true
    soft_delete_retention_days    = 7
    enable_purge_protection       = true
    enable_rbac_authorization     = true
    enable_public_network_access  = true
    network_acls     = {
      bypass         = "AzureServices" 
      default_action = "Deny" 
      ip_rules       = []
    }
    kv_endpoint_name              = "coreaihub-foundry-prd-kv-pe"
    enable_manual_connection      = false
    subresource_names             = ["vault"]
    enable_private_dns_zone_group = true
    tags = {
      application  = "core ai hub"
      costcenter   = "chgpl_52015103"
      environment  = "prod"
      igar         = "apm0013771"
      model        = "cirrus"
    }
  }
}

#--------------------------------- Shared Private Link -------------------------------------------

pvt_links_list = {
  "cogser-coreaihub-sc-aiservices-prod" = {
    private_link_name          = "cogser-coreaihub-sc-aiservices-prod"
    ai_search_name             = "coreaihub-prod-search"
    subresource_name           = "cognitiveservices_account"
    ai_foundry_service_name    = "coreaihub-sc-aiservices-prod" 
  }
  "openai-coreaihub-sc-aiservices-prod" = {
    private_link_name          = "openai-coreaihub-sc-aiservices-prod"
    ai_search_name             = "coreaihub-prod-search"
    subresource_name           = "openai_account"
    ai_foundry_service_name    = "coreaihub-sc-aiservices-prod"
  }
  "cogser-coreaihub-eus-aiservices-prod" = {
    private_link_name          = "cogser-coreaihub-eus-aiservices-prod"
    ai_search_name             = "coreaihub-prod-search"
    subresource_name           = "cognitiveservices_account"
    ai_foundry_service_name    = "coreaihub-eus-aiservices-prod"
  }
  "openai-coreaihub-eus-aiservices-prod" = {
    private_link_name          = "openai-coreaihub-eus-aiservices-prod"
    ai_search_name             = "coreaihub-prod-search"
    subresource_name           = "openai_account"
    ai_foundry_service_name    = "coreaihub-eus-aiservices-prod"
  }
}

#-------------------------AI Foundry Services -------------------------------------

ai_service_list = {
  "coreaihub-sc-aiservices-prod" = { 
    ai_service_name               = "coreaihub-sc-aiservices-prod"
    rg_name                       = "COREAIHUB-SC-MODELS-PROD-RG"
    location                      = "swedencentral"
    ai_service_sku                = "S0"
    custom_subdomain_name         = "coreaihub-sc-aiservices-prod"
    public_network_access         = "Disabled"
    identity_type                 = "SystemAssigned"
    identity_ids                  = []
    ai_service_endpoint_name      = "coreaihub-sc-aiservices-prod-pe"
    enable_manual_connection      = false
    subresource_names             = ["account"]
    enable_private_dns_zone_group = true
    tags                          = {
      application  = "core ai hub"
      costcenter   = "chgpl_52015103"
      environment  = "prod"
      igar         = "apm0013771"
      model        = "cirrus"
    }
  }
  "coreaihub-eus-aiservices-prod" = { 
    ai_service_name               = "coreaihub-eus-aiservices-prod"
    rg_name                       = "COREAIHUB-SC-MODELS-PROD-RG"
    location                      = "eastus2"
    ai_service_sku                = "S0"
    custom_subdomain_name         = "coreaihub-eus-aiservices-prod"
    public_network_access         = "Disabled"
    identity_type                 = "SystemAssigned"
    identity_ids                  = []
    ai_service_endpoint_name      = "coreaihub-eus-aiservices-prod-pe"
    enable_manual_connection      = false
    subresource_names             = ["account"]
    enable_private_dns_zone_group = true
    tags                          = {
      application  = "core ai hub"
      costcenter   = "chgpl_52015103"
      environment  = "prod"
      igar         = "apm0013771"
      model        = "cirrus"
    }
  }
}
ai_foundry_services_private_dns_zone_names = ["privatelink.cognitiveservices.azure.com", "privatelink.openai.azure.com", "privatelink.services.ai.azure.com"]

#-------------------------AI Foundry Hub ------------------------------------------

ai_foundry_hub_list = {
  "coreaihub-sc-aiserviceshub-prod" = {
    ai_hub_name                   = "coreaihub-sc-aiserviceshub-prod"
    rg_name                       = "COREAIHUB-SC-MODELS-PROD-RG"
    location                      = "swedencentral"
    sa_name                       = "coreaihubprodfoundrysa"
    key_vault_name                = "coreaihub-foundry-prd-kv"
    public_network_access         = "Disabled"
    isolation_mode                = "AllowOnlyApprovedOutbound"
    identity_type                 = "SystemAssigned"
    identity_ids                  = []
    ai_hub_endpoint_name          = "coreaihub-sc-aiserviceshub-prod-pe"
    enable_manual_connection      = false
    subresource_names             = ["amlworkspace"]
    enable_private_dns_zone_group = true
    tags                          = {
      application  = "core ai hub"
      costcenter   = "chgpl_52015103"
      environment  = "prod"
      igar         = "apm0013771"
      model        = "cirrus"
    }
  }
}
ai_foundry_hub_private_dns_zone_names  = ["privatelink.api.azureml.ms", "privatelink.notebooks.azure.net"]

#-------------------------AI Foundry Hub Connection------------------------------------------
ai_foundry_hub_connection_list = {
  "coreaihub-sc-aiservices-hubconn-prod" = {
    connection_name = "coreaihub-sc-aiservices-prod"
    parent_name     = "coreaihub-sc-aiserviceshub-prod"
    category        = "AIServices"
    resource_name   = "coreaihub-sc-aiservices-prod"
  }
  "coreaihub-eus-aiservices-hubconn-prod" = {
    connection_name = "coreaihub-eus-aiservices-prod"
    parent_name     = "coreaihub-sc-aiserviceshub-prod"
    category        = "AIServices"
    resource_name   = "coreaihub-eus-aiservices-prod"
  }
}

#-------------------------AI Foundry Project -------------------------------------

ai_foundry_project_list  = {
  "coreaihub-sc-project-int-prod-01" = {
    ai_project_name              = "coreaihub-sc-project-int-prod-01"
    ai_project_description       = ""
    rg_name                      = "COREAIHUB-SC-PROJECTS-PROD-RG"
    location                     = "swedencentral"
    ai_hub_name                  = "coreaihub-sc-aiserviceshub-prod"
    high_business_impact_enabled = false
    identity_type                = "SystemAssigned"
    identity_ids                 = []
    tags                         = {
      application  = "core ai hub"
      costcenter   = "chgpl_52015103"
      environment  = "prod"
      igar         = "apm0013771"
      model        = "cirrus"
    }
    public_network_access        = "Disabled"
  }
}

# #-------------------------AI Models deploy -------------------------------------
ai_models_list = {
  "gpt-4.1" = { 
    ai_deployment_name     = "gpt-4.1"
    cognitive_account_name = "coreaihub-sc-aiservices-prod"
    model_format           = "OpenAI"
    model_version          = "2025-04-14"
    model_name             = "gpt-4.1"
    sku_capacity           = 250
    sku_name               = "DataZoneStandard"
    version_upgrade_option = "OnceNewDefaultVersionAvailable"
  }
  "gpt-4o-mini" = { 
    ai_deployment_name     = "gpt-4o-mini"
    cognitive_account_name = "coreaihub-sc-aiservices-prod"
    model_format           = "OpenAI"
    model_version          = "2024-07-18"
    model_name             = "gpt-4o-mini"
    sku_capacity           = 250
    sku_name               = "DataZoneStandard"
    version_upgrade_option = "OnceNewDefaultVersionAvailable"
  }
  "gpt-5" = { 
    ai_deployment_name     = "gpt-5"
    cognitive_account_name = "coreaihub-sc-aiservices-prod"
    model_format           = "OpenAI"
    model_version          = "2025-08-07"
    model_name             = "gpt-5"
    sku_capacity           = 250
    sku_name               = "DataZoneStandard"
    version_upgrade_option = "OnceNewDefaultVersionAvailable"
  }
  "o3" = { 
    ai_deployment_name     = "o3"
    cognitive_account_name = "coreaihub-sc-aiservices-prod"
    model_format           = "OpenAI"
    model_version          = "2025-04-16"
    model_name             = "o3"
    sku_capacity           = 250
    sku_name               = "DataZoneStandard"
    version_upgrade_option = "OnceNewDefaultVersionAvailable"
  }
  "o4-mini" = { 
    ai_deployment_name     = "o4-mini"
    cognitive_account_name = "coreaihub-sc-aiservices-prod"
    model_format           = "OpenAI"
    model_version          = "2025-04-16"
    model_name             = "o4-mini"
    sku_capacity           = 250
    sku_name               = "DataZoneStandard"
    version_upgrade_option = "OnceNewDefaultVersionAvailable"
  }
  "text-embedding-3-large" = { 
    ai_deployment_name     = "text-embedding-3-large"
    cognitive_account_name = "coreaihub-sc-aiservices-prod"
    model_format           = "OpenAI"
    model_version          = "1"
    model_name             = "text-embedding-3-large"
    sku_capacity           = 240
    sku_name               = "Standard"
    version_upgrade_option = "OnceNewDefaultVersionAvailable"
  }
  "text-embedding-ada-002" = { 
    ai_deployment_name     = "text-embedding-ada-002"
    cognitive_account_name = "coreaihub-sc-aiservices-prod"
    model_format           = "OpenAI"
    model_version          = "2"
    model_name             = "text-embedding-ada-002"
    sku_capacity           = 150
    sku_name               = "Standard"
    version_upgrade_option = "OnceNewDefaultVersionAvailable"
  }
  "DeepSeek-R1" = { 
    ai_deployment_name     = "DeepSeek-R1"
    cognitive_account_name = "coreaihub-eus-aiservices-prod"
    model_format           = "DeepSeek"
    model_version          = "1"
    model_name             = "DeepSeek-R1"
    sku_capacity           = 5000
    sku_name               = "GlobalStandard"
    version_upgrade_option = "OnceNewDefaultVersionAvailable"
  }
}