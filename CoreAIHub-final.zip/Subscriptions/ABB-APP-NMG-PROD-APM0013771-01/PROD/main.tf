
##--------------------------------------RGs---------------------------------------------------
module "rg" {
  for_each = var.rg_list
  source   = "../../../Terraform_Modules/ResourceGroup"
  rg_name  = each.value.rg_name
  location = each.value.location
  tags     = each.value.tags
}

##------------------------------------Storage accounts-------------------------------------
module "storage_account" {
  for_each                         = var.storage_account_list
  source                           = "../../../Terraform_Modules/StorageAccount"
  rg_name                          = each.value.rg_name
  location                         = each.value.location
  sa_name                 	       = each.value.sa_name
  sa_account_tier                  = each.value.sa_account_tier
  sa_access_tier                   = each.value.sa_access_tier
  sa_account_replication_type      = each.value.sa_account_replication_type
  allow_blob_public_access         = each.value.allow_blob_public_access
  enable_public_network_access     = each.value.enable_public_network_access
  enable_infrastructure_encryption = each.value.enable_infrastructure_encryption
  enable_shared_access_key         = each.value.enable_shared_access_key
  enable_cross_tenant_replication  = each.value.enable_cross_tenant_replication
  enable_versioning                = each.value.enable_versioning 
  delete_retention_days            = each.value.delete_retention_days
  enable_hns                       = each.value.enable_hns
  container_delete_retention_days  = each.value.container_delete_retention_days
  enable_large_file_share          = each.value.enable_large_file_share
  min_tls_version                  = each.value.min_tls_version
  identity_type                    = each.value.identity_type
  identity_ids                     = each.value.identity_ids
  containers                       = each.value.containers
  network_rules                    = each.value.network_rules
  sa_subnet_names                  = each.value.sa_subnet_names
  vnet_name                        = each.value.vnet_name
  vnet_rg_name                     = each.value.vnet_rg_name
  other_subs_sa_subnet_ids         = local.other_subs_sa_subnet_ids
  network_resource_location        = var.network_resource_location
  endpoint_subnet_id               = data.azurerm_subnet.endpoint_subnet.id
  enable_manual_connection         = each.value.enable_manual_connection
  sa_blob_endpoint_name            = each.value.sa_blob_endpoint_name
  blob_subresource_names           = each.value.blob_subresource_names
  create_dfs_endpoint              = each.value.create_dfs_endpoint
  sa_dfs_endpoint_name             = each.value.sa_dfs_endpoint_name
  dfs_subresource_names            = each.value.dfs_subresource_names
  enable_private_dns_zone_group    = each.value.enable_private_dns_zone_group
  sa_blob_private_dns_zone_ids     = [data.azurerm_private_dns_zone.storage_blob_dns_zone.id]
  sa_dfs_private_dns_zone_ids      = [data.azurerm_private_dns_zone.storage_dfs_dns_zone.id]
  tags 					                   = each.value.tags
}

##----------------------------------- Key Vaults ----------------------------------------------------------
module "keyvault" {
  for_each                      = var.keyvault_list
  source                        = "../../../Terraform_Modules/Keyvault"
  location                      = each.value.location
  kv_name                       = each.value.kv_name
  rg_name                       = module.rg[each.value.rg_name].rg_name
  kv_sku_name                   = each.value.kv_sku_name
  tenant_id                     = data.azurerm_client_config.current.tenant_id 
  enable_disk_encryption        = each.value.enable_disk_encryption
  enable_purge_protection       = each.value.enable_purge_protection
  enable_rbac_authorization     = each.value.enable_rbac_authorization
  soft_delete_retention_days    = each.value.soft_delete_retention_days
  enable_public_network_access  = each.value.enable_public_network_access  
  network_acls                  = each.value.network_acls
  kv_endpoint_name              = each.value.kv_endpoint_name
  network_resource_location     = var.network_resource_location
  endpoint_subnet_id            = data.azurerm_subnet.endpoint_subnet.id
  enable_manual_connection      = each.value.enable_manual_connection
  subresource_names             = each.value.subresource_names
  enable_private_dns_zone_group = each.value.enable_private_dns_zone_group  
  private_dns_zone_ids          = [data.azurerm_private_dns_zone.keyvault_dns_zone.id]
  tags                          = each.value.tags
}

##------------------------------- AI Search Services----------------------------------------------------
module "ai_search" {
  for_each                      = var.ai_search_list
  source                        = "../../../Terraform_Modules/AISearch"
  ai_search_name                = each.value.ai_search_name
  rg_name                       = module.rg[each.value.rg_name].rg_name
  location                      = each.value.location
  ai_search_sku                 = each.value.ai_search_sku
  allowed_ips                   = each.value.allowed_ips
  enable_public_network_access  = each.value.enable_public_network_access
  enable_local_authentication   = each.value.enable_local_authentication
  authentication_failure_mode   = each.value.authentication_failure_mode
  hosting_mode                  = each.value.hosting_mode
  partition_count               = each.value.partition_count
  replica_count                 = each.value.replica_count
  semantic_search_sku           = each.value.semantic_search_sku
  network_rule_bypass_option    = each.value.network_rule_bypass_option
  identity_type     		        = each.value.identity_type
  identity_ids                  = each.value.identity_ids
  network_resource_location     = var.network_resource_location
  ai_search_endpoint_name       = each.value.ai_search_endpoint_name
  endpoint_subnet_id            = data.azurerm_subnet.endpoint_subnet.id
  enable_manual_connection      = each.value.enable_manual_connection
  subresource_names             = each.value.subresource_names
  enable_private_dns_zone_group = each.value.enable_private_dns_zone_group  
  private_dns_zone_ids          = [data.azurerm_private_dns_zone.aisearch_dns_zone.id]
  tags 				                  = each.value.tags
}

#----------------------------------- Shared Private Link -----------------------------------------------

module "private_link" {
  for_each                   = var.pvt_links_list
  source                     = "../../../Terraform_Modules/SharedPrivateLink"
  private_link_name          = each.value.private_link_name
  ai_search_id               = module.ai_search[each.value.ai_search_name].ai_search_id
  subresource_name           = each.value.subresource_name
  request_message            = each.value.private_link_name
  target_resource_id         = module.ai_services[each.value.ai_foundry_service_name].ai_service_id 
}

#-------------------------AI Foundry Services -------------------------------------

module "ai_services" {
  for_each                      = var.ai_service_list
  source                        = "../../../Terraform_Modules/AIFoundryService"
  ai_service_name               = each.value.ai_service_name
  rg_name                       = module.rg[each.value.rg_name].rg_name
  location                      = each.value.location
  ai_service_sku                = each.value.ai_service_sku
  custom_subdomain_name         = each.value.custom_subdomain_name
  public_network_access         = each.value.public_network_access
  identity_type                 = each.value.identity_type
  identity_ids                  = each.value.identity_ids
  ai_service_endpoint_name      = each.value.ai_service_endpoint_name
  network_resource_location     = var.network_resource_location
  endpoint_subnet_id            = data.azurerm_subnet.endpoint_subnet.id
  enable_manual_connection      = each.value.enable_manual_connection
  subresource_names             = each.value.subresource_names
  enable_private_dns_zone_group = each.value.enable_private_dns_zone_group
  private_dns_zone_ids          = values(data.azurerm_private_dns_zone.ai_foundry_services_dns_zone)[*].id
  tags                          = each.value.tags

}

#-------------------------AI Foundry Hub ------------------------------------------

module "ai_foundry_hub" {
  for_each                      = var.ai_foundry_hub_list
  source                        = "../../../Terraform_Modules/AIFoundryHub"
  ai_hub_name                   = each.value.ai_hub_name
  location                      = each.value.location
  rg_name                       = module.rg[each.value.rg_name].rg_name
  storage_account_id            = module.storage_account[each.value.sa_name].storage_account_id
  key_vault_id                  = module.keyvault[each.value.key_vault_name].kv_id
  public_network_access         = each.value.public_network_access
  isolation_mode                = each.value.isolation_mode
  tags                          = each.value.tags
  identity_type                 = each.value.identity_type
  identity_ids                  = each.value.identity_ids
  ai_hub_endpoint_name          = each.value.ai_hub_endpoint_name
  network_resource_location     = var.network_resource_location
  endpoint_subnet_id            = data.azurerm_subnet.endpoint_subnet.id
  enable_manual_connection      = each.value.enable_manual_connection
  subresource_names             = each.value.subresource_names
  enable_private_dns_zone_group = each.value.enable_private_dns_zone_group
  private_dns_zone_ids          = values(data.azurerm_private_dns_zone.ai_foundry_hub_dns_zone)[*].id
}

#-------------------------AI Foundry Hub Connection------------------------------------------

module "ai_foundry_hub_connections" {
  for_each                      = var.ai_foundry_hub_connection_list
  source                        = "../../../Terraform_Modules/AIFoundryHubConnection"
  connection_name               = each.value.connection_name
  parent_id                     = module.ai_foundry_hub[each.value.parent_name].ai_hub_id
  category                      = each.value.category
  resource_id                   = module.ai_services[each.value.resource_name].ai_service_id 
  resource_endpoint             = module.ai_services[each.value.resource_name].ai_service_endpoint
  location                      = module.ai_services[each.value.resource_name].ai_service_location
}

#-------------------------AI Foundry Project-------------------------------------

module "ai_foundry_project" {
  for_each                     = var.ai_foundry_project_list
  source                       = "../../../Terraform_Modules/AIFoundryProject_azapi"
  ai_project_name              = each.value.ai_project_name
  ai_project_description       = each.value.ai_project_description
  rg_id                        = module.rg[each.value.rg_name].rg_id
  location                     = each.value.location
  tags                         = each.value.tags
  ai_services_hub_id           = module.ai_foundry_hub[each.value.ai_hub_name].ai_hub_id
  high_business_impact_enabled = each.value.high_business_impact_enabled
  identity_type                = each.value.identity_type
  identity_ids                 = each.value.identity_ids
  public_network_access        = each.value.public_network_access
}

#-------------------------AI Models deploy -------------------------------------
module "ai_models" {
  for_each                     = var.ai_models_list
  source                       = "../../../Terraform_Modules/AIModels"
  ai_deployment_name           = each.value.ai_deployment_name
  cognitive_account_id         = module.ai_services[each.value.cognitive_account_name].ai_service_id
  model_format                 = each.value.model_format
  model_version                = each.value.model_version
  model_name                   = each.value.model_name
  sku_capacity                 = each.value.sku_capacity
  sku_name                     = each.value.sku_name
  version_upgrade_option       = each.value.version_upgrade_option
}

