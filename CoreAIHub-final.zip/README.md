# Azure CoreAI HUB Infrastructure Deployment(Terraform)
This project automates the deployment of Core AI services- Azure Databricks, Azure AI Search and AI Foundry including any dependent resources like subnets, Storage, key vaults, etc by using terraform and will be deployed using Azure DevOps pipelines.

# Prerequisites for terraform deployments

1. Azure Subscription with required permisssions - Service Principal should have subscription onwer role granted
2. Ensure stoarge account with container created and availble for maintaining terraform statefile(s)
3. Ensure service connection is created to link Azure service principal used for the terraform deployments
4. Ensure required parameters stored in the devops library
5. Register the provider "Microsoft.Databricks" for the subscription

# Modules - Terraform_Modules
1. Subnet - Terraform Azurerm module to create subnet(s) under given vNet 
2. StorageAccount - Terraform Azurerm module to create storeage account with private endpoint and private dns zone configuration. Storage account should be created with below Data protection options
   Disable:
      Blob soft delete
      Container soft delete
      Blob Storage Events (Event Grid integration)
3. RoleAssignment - Terraform Azurerm module to assign given role to the principal (user or group) 
4. ResourceGroup - Terraform Azurerm module to create resource group(s)
5. NSG - Terraform Azurerm module to create Network Security Group(s)
6. NSGAssociationSubnet - Terraform Azurerm module to associate Subnet to Network Security Group
7. Databricks - Terraform Azurerm module to to create Databricks workspace with private endpoint and private dns zone 
   configuration
     -  Databricks/Catalog - Terraform Databricks module to create catalog, grants and binding to the workspace
     -  Databricks/Credential - Terraform Databricks module to create databricks storage credential (authentication method 
        to access Azure storage account) and grants
     -  Databricks/External Location - Terraform Databricks module to create Databricks external location 
        (objects that combine a cloud storage path with a Storage Credential that can be used to access the location)
     -  Databricks/Schema -  Terraform Databricks module to create Databricks Schema and grants

# Deployments flow for Databricks
1. Refer the below URL for deployment for Databricks
    -  [Databricks Setup Overview](https://dev.azure.com/ABB-IS/APM00133771-CoreAI/_wiki/wikis/APM00133771-CoreAI.wiki/2739/Databricks-Setup-Overview)

## Known Issues for databricks deployment
1. Databricks workspaces are not automatically assigned to a metastore. It has to be added by an account admin manually. Please reach out to an admin if you see `Error: cannot create external location: No metastore assigned for the current workspace.`
2. It is not possible to create account level groups with terraform. Thus the user has to create them manually when the pipeline fails with `Error: cannot create group: failed during request visitor: default auth: cannot configure default credentials`.