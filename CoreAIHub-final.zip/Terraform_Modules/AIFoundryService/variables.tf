# variables for AI Service
variable "ai_service_name" {
  type = string
  description = "(Required) Specifies the name of the AI Services Account."
}

variable "location" {
  type = string
  description = "(Required) The Azure Region where the AI Foundry Hub should exist."
}

variable "rg_name" {
  type = string
  description = "(Required) The name of the Resource Group where the AI Foundry Hub should exist."
}

variable "ai_service_sku" {
  type = string
  description = "(Required) Specifies the SKU Name for this AI Services Account. Possible values are F0, F1, S0, S, S1, S2, S3, S4, S5, S6, P0, P1, P2, E0 and DC0."
}

variable "custom_subdomain_name" {
  description = "Custom subdomain name for the AI Foundry service.The subdomain name used for token-based authentication."
  type        = string
}

variable "public_network_access" {
  description = "(Optional) Whether public network access is allowed for the AI Services Account. Possible values are Enabled and Disabled. Defaults to Enabled."
  type        = string
}

variable "identity_type" {
  description = "(Required) Specifies the type of Managed Service Identity that should be configured on this AI Foundry Project. Possible values are SystemAssigned, UserAssigned, SystemAssigned, UserAssigned (to enable both)."
  type        = string
}

variable "identity_ids" {
  description = "(Optional) Specifies a list of User Assigned Managed Identity IDs to be assigned to this AI Foundry Project."
  type        = list(string)
}

variable "tags" {
  description = "(Optional) A mapping of tags which should be assigned to the AI Foundry Hub."
  type        = map(string)
}

#variables used for private endpoint
variable "ai_service_endpoint_name" {
  description = "Specifies the name of the private end point."
  type        = string
}
variable "network_resource_location" {
  description = "Specifies the location where the Storage Account need to be created."
  type        = string
}

variable "endpoint_subnet_id" {
  description = "Specifies the subnet for the private endpoint."
  type        = string
}
variable "enable_manual_connection" {
  description = "Flag for the Private Endpoint's Manual Approval from the remote resource owner"
  type        = bool
}
 
variable "subresource_names" {
  description = "Specifies the name of the private service connection subresources."
  type = list(string)
}

variable "enable_private_dns_zone_group" {
  description = "Flag for the enabling private dns zone"
  type        = bool
}

variable "private_dns_zone_ids" {
  description = "The Private DNS Zone Ids"
  type        = list(string)
}