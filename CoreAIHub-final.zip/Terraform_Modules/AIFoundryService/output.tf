output "ai_service_id" {
  description = "The ID of the AI Services Account."
  value       = azurerm_ai_services.ai_service.id
}

output "ai_service_endpoint" {
  description = "The endpoint of the AI services account"
  value       = azurerm_ai_services.ai_service.endpoint
}

output "ai_service_location" {
  description = "The location of the AI Services Account."
  value       = azurerm_ai_services.ai_service.location
}