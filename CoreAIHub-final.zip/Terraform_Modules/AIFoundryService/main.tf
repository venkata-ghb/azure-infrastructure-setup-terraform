locals {
  creation_date_tags     = { creationDate = formatdate("DD/MM/YYYY", time_static.created.rfc3339) }
}

##Manages a static time resource
resource "time_static" "created" {}

#Manages an AI Services Account.
resource "azurerm_ai_services" "ai_service" {
  name                  = var.ai_service_name
  location              = var.location
  resource_group_name   = var.rg_name
  sku_name              = var.ai_service_sku
  custom_subdomain_name = var.custom_subdomain_name
  public_network_access = var.public_network_access
  dynamic identity {
    for_each = var.identity_type != null ? [1] : []  
    content {
      type         = var.identity_type
      identity_ids = var.identity_type == "SystemAssigned" ? [] : var.identity_ids
    }
  }
  
  tags                  = merge(var.tags, local.creation_date_tags)
}

resource "azurerm_private_endpoint" "ai_service_pep" {
  count               = var.ai_service_endpoint_name != null ? 1 : 0
  name                = var.ai_service_endpoint_name
  location            = var.network_resource_location
  resource_group_name = var.rg_name
  subnet_id           = var.endpoint_subnet_id
 
  private_service_connection {
    name                           = "${var.ai_service_endpoint_name}-connection"
    is_manual_connection           = var.enable_manual_connection
    private_connection_resource_id = azurerm_ai_services.ai_service.id
    subresource_names              = var.subresource_names
  }
  
  dynamic "private_dns_zone_group" {
    for_each = var.enable_private_dns_zone_group == true ? [1] : []
    content {
      name                 = "deployedByTerraform"
      private_dns_zone_ids = var.private_dns_zone_ids
    }
  }
  
  tags = merge(var.tags, local.creation_date_tags)
  }