output "ai_hub_id" {
  description = "The ID of the AI Foundry Hub."
  value       = azurerm_ai_foundry.ai_hub.id
}
output "ai_hub_principal_id" {
  description = "The Principal ID of the AI Foundry Hub."
  value       = azurerm_ai_foundry.ai_hub.identity[0].principal_id
}

output "ai_hub_kv_id" {
  description = "The ID of the Key Vault."
  value       = azurerm_ai_foundry.ai_hub.key_vault_id
}

output "ai_hub_sa_id" {
  description = "The id of the newly created storage account"
  value       = azurerm_ai_foundry.ai_hub.storage_account_id
}

output "ai_hub_discovery_url" {
  description = "The URL for the discovery service to identify regional endpoints for AI Foundry Hub services."
  value       = azurerm_ai_foundry.ai_hub.discovery_url
}