locals {
  creation_date_tags     = { creationDate = formatdate("DD/MM/YYYY", time_static.created.rfc3339) }
}

##Manages a static time resource
resource "time_static" "created" {}

#Manages an AI Foundry Hub.
resource "azurerm_ai_foundry" "ai_hub" {
  name                = var.ai_hub_name
  location            = var.location
  resource_group_name = var.rg_name
  storage_account_id  = var.storage_account_id
  key_vault_id        = var.key_vault_id
  friendly_name       = var.ai_hub_name

  public_network_access = var.public_network_access

  dynamic identity {
    for_each = var.identity_type != null ? [1] : []  
    content {
      type         = var.identity_type
      identity_ids = var.identity_type == "SystemAssigned" ? [] : var.identity_ids
    }
  }

  dynamic managed_network {
    for_each = var.isolation_mode != null ? [1] : []  
    content {
      isolation_mode = var.isolation_mode  
    }
  }

  tags    = merge(var.tags, local.creation_date_tags)

}

resource "azurerm_private_endpoint" "ai_hub_pep" {
  count               = var.ai_hub_endpoint_name != null ? 1 : 0
  name                = var.ai_hub_endpoint_name
  location            = var.network_resource_location
  resource_group_name = var.rg_name
  subnet_id           = var.endpoint_subnet_id
 
  private_service_connection {
    name                           = "${var.ai_hub_endpoint_name}-connection"
    is_manual_connection           = var.enable_manual_connection
    private_connection_resource_id = azurerm_ai_foundry.ai_hub.id
    subresource_names              = var.subresource_names
  }
  
  dynamic "private_dns_zone_group" {
    for_each = var.enable_private_dns_zone_group == true ? [1] : []
    content {
      name                 = "deployedByTerraform"
      private_dns_zone_ids = var.private_dns_zone_ids
    }
  }
  
  tags = merge(var.tags, local.creation_date_tags)
}