# variables for AI HUB
variable "ai_hub_name" {
  type        = string
  description = "(Required) The name which should be used for this AI Foundry Hub."
}

variable "location" {
  type        = string
  description = "(Required) The Azure Region where the AI Foundry Hub should exist."
}

variable "rg_name" {
  type        = string
  description = "(Required) The name of the Resource Group where the AI Foundry Hub should exist."
}

variable "storage_account_id" {
  type        = string
  description = "(Required) The Storage Account ID that should be used by this AI Foundry Hub."
}

variable "key_vault_id" {
  type        = string
  description = "(Required) The Key Vault ID that should be used by this AI Foundry Hub."
}

variable "public_network_access" {
  type        = string
  description = "(Optional) Whether public network access for this AI Service Hub should be enabled. Possible values include Enabled and Disabled."
}

variable "tags" {
  description = "(Optional) A mapping of tags which should be assigned to the AI Foundry Hub."
  type        = map(string)
}

variable "identity_type" {
  description = "(Required) Specifies the type of Managed Service Identity that should be configured on this AI Foundry Project. Possible values are SystemAssigned, UserAssigned, SystemAssigned, UserAssigned (to enable both)."
  type        = string
}

variable "identity_ids" {
  description = "(Optional) Specifies a list of User Assigned Managed Identity IDs to be assigned to this AI Foundry Project."
  type        = list(string)
}

variable "isolation_mode" {
  type        = string
  description = "(Optional) The isolation mode of the AI Foundry Hub. Possible values are Disabled, AllowOnlyApprovedOutbound, and AllowInternetOutbound."
}

#variables used for private endpoint
variable "ai_hub_endpoint_name" {
  description = "Specifies the name of the private end point."
  type        = string
}

variable "network_resource_location" {
  description = "Specifies the location where the Storage Account need to be created."
  type        = string
}

variable "endpoint_subnet_id" {
  description = "Specifies the subnet for the private endpoint."
  type        = string
}
variable "enable_manual_connection" {
  description = "Flag for the Private Endpoint's Manual Approval from the remote resource owner"
  type        = bool
}
 
variable "subresource_names" {
  description = "Specifies the name of the private service connection subresources."
  type        = list(string)
}

variable "enable_private_dns_zone_group" {
  description = "Flag for the enabling private dns zone"
  type        = bool
}

variable "private_dns_zone_ids" {
  description = "The Private DNS Zone Ids"
  type        = list(string)
}