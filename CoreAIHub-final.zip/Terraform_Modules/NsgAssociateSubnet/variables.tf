variable "subnet_id" {
  description = "(Required) The ID of the subnet. Changing this forces a new resource to be created."
  type        = string
}
variable "nsg_id" {
  description = "(Required) Specifies the ID of the network security group. Changing this forces a new resource to be created."
  type        = string
}