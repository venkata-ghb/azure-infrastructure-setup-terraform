output "subnet_nsg_association_id" {
  description = "The ID of the Subnet."
  value       = azurerm_subnet_network_security_group_association.subnet_network_security_group.id
}