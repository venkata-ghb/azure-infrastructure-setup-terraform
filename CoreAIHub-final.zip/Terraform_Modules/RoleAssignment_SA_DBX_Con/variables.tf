variable "role_definition_name" {
  type        = string
  description = "(Optional) The name of a built-in Role. Changing this forces a new resource to be created."
}
variable "principal_id" {
  description = "Specifies the Principal ID of the resource"
  type        = string
}
variable "scope_id" {
  description = "Specifies the Scope ID"
  type        = string
}