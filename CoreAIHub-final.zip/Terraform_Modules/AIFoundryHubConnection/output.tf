output "connection_name" {
  description = "The name of the AI Foundry HUb Connection"
  value = azapi_resource.AIConnection.name
}