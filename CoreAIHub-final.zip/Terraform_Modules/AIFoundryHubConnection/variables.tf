variable "connection_name" {
  type        = string
  description = "The connection name"
}

variable "parent_id" {
  type        = string
  description = "The ID of the resource that is the parent for this resource such as AI Foundry Hub."
}

variable "category" {
  type        = string
  description = "Category of the connection"
}
variable "resource_id" {
  type        = string
  description = "The resource ID of the AI Foundry Services."
}

variable "resource_endpoint" {
  type        = string
  description = "The resource endpoint of the AI Foundry Services."
}

variable "location" {
  type = string
  description = "The Azure Region where the AI Foundry service exist."
}