locals {
  auth_type = "AAD"
}
resource "azapi_resource" "AIConnection" {
  type      = "Microsoft.MachineLearningServices/workspaces/connections@2025-07-01-preview"
  name      = var.connection_name
  parent_id = var.parent_id

  body = {
    properties = {
      category = var.category
      isSharedToAll = true
      metadata = {
        ApiType = "Azure"
        ResourceId = var.resource_id
        Location = var.location
      }
      target = var.resource_endpoint
      authType = local.auth_type
    }
  }
}