resource "azurerm_role_assignment" "role_assign" {
  scope                = var.scope_type == "Databricks" ? data.azurerm_databricks_workspace.dbx_ws[0].id : data.azurerm_storage_account.storage_account[0].id
  principal_id         = var.principal_tpye == "Connector" ? data.azurerm_databricks_access_connector.dbx_access_connector[0].identity[0].principal_id : data.azuread_group.ad_group[0].object_id
  role_definition_name = var.role_definition_name
}
