data "azurerm_storage_account" "storage_account" {
  count = var.scope_type == "Storage" ? 1 : 0
  name                = var.scope_id
  resource_group_name = var.scope_rg_name
}

data "azurerm_databricks_workspace" "dbx_ws" {
  count = var.scope_type == "Databricks" ? 1 : 0
  name                = var.scope_id
  resource_group_name = var.scope_rg_name
}

data "azuread_group" "ad_group" {
  count = var.principal_tpye == "ADGroup" ? 1 : 0
  display_name = var.principal_id
}

data "azurerm_databricks_access_connector" "dbx_access_connector" {
  count = var.principal_tpye == "Connector" ? 1 : 0
  name                = var.principal_id
  resource_group_name = var.principal_rg_name
}