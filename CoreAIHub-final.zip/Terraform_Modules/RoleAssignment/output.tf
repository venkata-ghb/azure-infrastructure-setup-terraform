output "role_assign_name" {
  description = "Name of the Role Assignment."
  value       = azurerm_role_assignment.role_assign.role_definition_name 
}

output "role_assign_id" {
  description = "ID of the Role Assignment."
  value       = azurerm_role_assignment.role_assign.id 
}