variable "tenant_id" {
  description = "(Required) The Azure Active Directory tenant ID that should be used for authenticating requests to the key vault."
  type        = string
}
variable "rg_name" {
  description = "(Required) The name of the resource group in which to create the Key Vault. Changing this forces a new resource to be created."
  type        = string
}
variable "location" {
  description = "(Required) Specifies the supported Azure location where the resource exists. Changing this forces a new resource to be created."
  type        = string
}
variable "network_resource_location" {
  description = "Specifies the location where the Private Endpoint need to be created."
  type        = string
}
variable "kv_name" {
  description = "(Required) Specifies the name of the Key Vault. Changing this forces a new resource to be created."
  type        = string
}
variable "kv_sku_name" {
  description = "(Required) The Name of the SKU used for this Key Vault. Possible values are standard and premium."
  type        = string
}
variable "enable_disk_encryption" {
  description = "(Optional) Boolean flag to specify whether Azure Disk Encryption is permitted to retrieve secrets from the vault and unwrap keys."
  type        = bool
}
variable "enable_rbac_authorization" {
  description = "(Optional) Boolean flag to specify whether Azure Key Vault uses Role Based Access Control (RBAC) for authorization of data actions."
  type        = bool
}
variable "soft_delete_retention_days" {
  description = "(Optional) The number of days that items should be retained for once soft-deleted. This value can be between 7 and 90 (the Default) days."
  type        = number
}
variable "enable_purge_protection" {
  description = "(Optional) Is Purge Protection enabled for this Key Vault? Defaults to false. Once Purge Protection has been Enabled it's not possible to Disable it."
  type        = bool
} 
variable "enable_public_network_access" {
  description = "(Optional) Whether public network access is allowed for this Key Vault. Defaults to true."
  type        = bool
}
variable "tags" {
  description = "(Optional) A mapping of tags to assign to the resource."
  type        = map(string)
}

variable "network_acls" {
  description = "Specifies the network acls properties of the keyvault"
  type        = object({
      bypass   	     = string
      default_action = string
      ip_rules       = list(string)
  })
}
variable "kv_endpoint_name" {
  description = "(Required) Specifies the Name of the Private Endpoint. Changing this forces a new resource to be created."
  type        = string
}

variable "endpoint_subnet_id" {
  description = "(Required) The ID of the Subnet from which Private IP Addresses will be allocated for this Private Endpoint. Changing this forces a new resource to be created."
  type        = string
}
variable "enable_manual_connection" {
  description = "Flag for the Private Endpoint's Manual Approval from the remote resource owner"
  type        = bool
}
variable "subresource_names" {
  description = "(Optional) A list of subresource names which the Private Endpoint is able to connect to. subresource_names corresponds to group_id. Changing this forces a new resource to be created."
  type        = list(string)
}
variable "enable_private_dns_zone_group" {
  description = "Flag for enabling the private dns zone"
  type        = bool
}
variable "private_dns_zone_ids" {
  description = "The Private DNS Zone Ids"
  type        = list(string)
}