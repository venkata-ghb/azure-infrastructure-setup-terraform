locals {
  creation_date_tags     = { creationDate = formatdate("DD/MM/YYYY", time_static.created.rfc3339) }
}

##Manages a static time resource
resource "time_static" "created" {}

resource "azurerm_key_vault" "key_vault" {
  name                          = var.kv_name
  location                      = var.location
  resource_group_name           = var.rg_name
  sku_name                      = var.kv_sku_name
  tenant_id                     = var.tenant_id
  purge_protection_enabled      = var.enable_purge_protection
  soft_delete_retention_days    = var.soft_delete_retention_days
  enabled_for_disk_encryption   = var.enable_disk_encryption
  rbac_authorization_enabled    = var.enable_rbac_authorization
  public_network_access_enabled = var.enable_public_network_access
  tags                          = merge(var.tags, local.creation_date_tags)
 
  network_acls {
    bypass         = var.network_acls.bypass
    default_action = var.network_acls.default_action
    ip_rules       = var.network_acls.ip_rules
  }
}

resource "azurerm_private_endpoint" "kv_pep" {
  name                = var.kv_endpoint_name
  location            = var.network_resource_location
  resource_group_name = var.rg_name
  subnet_id           = var.endpoint_subnet_id
 
  private_service_connection {
    name                           = "${var.kv_endpoint_name}-connection"
    is_manual_connection           = var.enable_manual_connection
    private_connection_resource_id = azurerm_key_vault.key_vault.id
    subresource_names              = var.subresource_names
  }

  dynamic "private_dns_zone_group" {
    for_each = var.enable_private_dns_zone_group == true ? [1] : []
    content {
      name                 = "deployedByTerraform"
      private_dns_zone_ids = [var.private_dns_zone_ids[0]]
    }
  }
  
  tags = merge(var.tags, local.creation_date_tags)
}