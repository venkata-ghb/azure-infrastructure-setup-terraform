output "kv_id" {
  description = "The ID of the Key Vault."
  value       = azurerm_key_vault.key_vault.id
}
output "kv_name" {
  description = "The name of the Key Vault."
  value       = azurerm_key_vault.key_vault.name
}
output "vault_uri" {
  description = "The URI of the Key Vault, used for performing operations on keys and secrets."
  value       = azurerm_key_vault.key_vault.vault_uri
}
output "pvt_endpoint_id" {
  description = "ID of the provisioned private endpoint"
  value       = azurerm_private_endpoint.kv_pep.id
}
output "pvt_endpoint_name" {
  description = "The name of the private endpoint"
  value       = azurerm_private_endpoint.kv_pep.name
}