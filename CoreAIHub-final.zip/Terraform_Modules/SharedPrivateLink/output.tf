output "search_pvt_link_id" {
  description = "The ID of the Azure Search Shared Private Link resource."
  value       = azurerm_search_shared_private_link_service.shared_pvt_link.id
}