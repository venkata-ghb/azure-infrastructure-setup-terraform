resource "azurerm_search_shared_private_link_service" "shared_pvt_link" {
  name               = var.private_link_name
  search_service_id  = var.ai_search_id
  subresource_name   = var.subresource_name
  target_resource_id = var.target_resource_id
  request_message    = var.request_message
}
