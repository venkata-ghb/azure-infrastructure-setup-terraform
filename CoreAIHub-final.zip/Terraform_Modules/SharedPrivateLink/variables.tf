variable "private_link_name" {
  description = "(Required) Specify the name of the Azure Search Shared Private Link Resource. Changing this forces a new resource to be created."
  type        = string
}
variable "ai_search_id" {
  description = "(Required) Specify the id of the Azure Search Service. Changing this forces a new resource to be created."
  type        = string
}
variable "subresource_name" {
  description = "(Required) Specify the sub resource name which the Azure Search Private Endpoint is able to connect to. Changing this forces a new resource to be created."
  type        = string
}
variable "request_message" {
  description = "(Optional) Specify the request message for requesting approval of the Shared Private Link Enabled Remote Resource."
  type        = string
}
variable "target_resource_id" {
  description = "(Required) Specify the ID of the Shared Private Link Enabled Remote Resource which this Azure Search Private Endpoint should be connected to. Changing this forces a new resource to be created."
  type        = string
}
