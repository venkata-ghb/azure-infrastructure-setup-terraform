output "rg_name" {
  description = "name of the provisioned resource group"
  value       = azurerm_resource_group.resource_group.name
}
output "rg_location" {
  description = "location of the provisioned resource group"
  value       = azurerm_resource_group.resource_group.location
}
output "rg_id" {
  description = "ID of the provisioned resource group"
  value       = azurerm_resource_group.resource_group.id
}