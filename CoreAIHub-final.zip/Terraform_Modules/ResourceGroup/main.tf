locals {
  creation_date_tags     = { creationDate = formatdate("DD/MM/YYYY", time_static.created.rfc3339) }
}

##Manages a static time resource
resource "time_static" "created" {}

#Azure Resource Group Creation
resource "azurerm_resource_group" "resource_group" {
  name 	   = var.rg_name
  location = var.location
  tags	   = merge(var.tags, local.creation_date_tags)
}