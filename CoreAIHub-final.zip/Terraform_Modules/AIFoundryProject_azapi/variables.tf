#variables for AI Foundry Project
variable "ai_project_name" {
  type = string
  description = "(Required) The name which should be used for this AI Foundry Project."
}

variable "ai_project_description" {
  type = string
  description = "The description which should be used for this AI Foundry Project."
}

variable "location" {
  type = string
  description = "(Required) The Azure Region where the AI Foundry Hub should exist."
}

variable "tags" {
  description = "(Optional) A mapping of tags which should be assigned to the AI Foundry Hub."
  type        = map(string)
}

variable "ai_services_hub_id" {
  type        = string
  description = "(Required) The AI Foundry ID under which this Project should be created. Changing this forces a new AI Foundry Project to be created."
}

variable "high_business_impact_enabled" {
  type        = bool
  description = "(Optional) Whether High Business Impact (HBI) should be enabled or not. Enabling this setting will reduce diagnostic data collected by the service. Changing this forces a new AI Foundry Project to be created. Defaults to false."
}

variable "identity_type" {
  description = "(Required) Specifies the type of Managed Service Identity that should be configured on this AI Foundry Project. Possible values are SystemAssigned, UserAssigned, SystemAssigned, UserAssigned (to enable both)."
  type        = string
}

variable "identity_ids" {
  description = "(Optional) Specifies a list of User Assigned Managed Identity IDs to be assigned to this AI Foundry Project."
  type        = list(string)
}

variable "public_network_access" {
  type        = string
  description = "(Optional) Whether public network access for this AI Service Hub should be enabled. Possible values include Enabled and Disabled."
}

variable "rg_id" {
  type = string
  description = "The ID of the Resource group"
}