locals {
  creation_date_tags     = { creationDate = formatdate("DD/MM/YYYY", time_static.created.rfc3339) }
}

##Manages a static time resource
resource "time_static" "created" {}

#Manages an AI Foundry Project
resource "azapi_resource" "ai_project" {
  location                  = var.location
  name                      = var.ai_project_name
  parent_id                 = var.rg_id
  type                      = "Microsoft.MachineLearningServices/workspaces@2025-07-01-preview"
  dynamic identity {
    for_each = var.identity_type != null ? [1] : []  
    content {
      type         = var.identity_type
      identity_ids = var.identity_type == "SystemAssigned" ? [] : var.identity_ids
    }
  }

  body = {
    kind = "Project"
    properties = {
      description         = var.ai_project_description
      friendlyName        = var.ai_project_name
      hubResourceId       = var.ai_services_hub_id
      publicNetworkAccess = var.public_network_access
    }
  }
  tags =merge(var.tags, local.creation_date_tags)

}
