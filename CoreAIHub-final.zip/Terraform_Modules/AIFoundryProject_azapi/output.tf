output "ai_hub_id" {
  description = "The ID of the AI Foundry Hub."
  value       = azapi_resource.ai_project.parent_id
}

output "ai_project_id" {
  description = "The ID of the AI Foundry Project."
  value       = azapi_resource.ai_project.id
}

output "ai_project_principal_id" {
  description = "The Idenetity Principal ID of the AI Foundry Project."
  value       = azapi_resource.ai_project.identity[0].principal_id
}
