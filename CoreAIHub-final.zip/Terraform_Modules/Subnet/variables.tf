variable "subnet_name" {
  description = "(Required) The name of the subnet. Changing this forces a new resource to be created."
  type        = string
}
variable "rg_name" {
  description = "(Required) The name of the resource group in which to create the subnet. Changing this forces a new resource to be created."
  type        = string
}
variable "vnet_name" {
  description = "(Required) The name of the virtual network to which to attach the subnet. Changing this forces a new resource to be created."
  type        = string
}
variable "subnet_address_space" {
  description = "(Required) The address prefixes to use for the subnet."
  type        = list(string)
}
variable "enable_delegation" {
  description = "(Optional) Subnet delegation details."
  type = list(object({
    delegation_name = string
    actions         = list(string)
  }))
}