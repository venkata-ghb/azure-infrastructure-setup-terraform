resource "azurerm_subnet" "subnet" {
  name                 = var.subnet_name
  resource_group_name  = var.rg_name
  virtual_network_name = var.vnet_name
  address_prefixes     = var.subnet_address_space

  dynamic delegation {
    for_each = var.enable_delegation == null ? [] : var.enable_delegation
    content {
      name = "delegation"

      service_delegation {
        name    = delegation.value.delegation_name
        actions = delegation.value.actions
      }
    }
  }
}