# Model Deployment (e.g., GPT-3.5-turbo)
resource "azurerm_cognitive_deployment" "model_deploy" {
  name                   = var.ai_deployment_name
  cognitive_account_id   = var.cognitive_account_id
  version_upgrade_option = var.version_upgrade_option
  
  model {
    format  = var.model_format
    name    = var.model_name
    version = var.model_version
    }
  
  sku {
    name     = var.sku_name
    capacity = var.sku_capacity
  }  
}
