#variables for models deployment
variable "ai_deployment_name" {
  description = "(Required) The name of the Cognitive Services Account Deployment. Changing this forces a new resource to be created."
  type        = string
}

variable "cognitive_account_id" {
  description = "(Required) The ID of the Cognitive Services Account. Changing this forces a new resource to be created."
  type        = string
}
 
variable "model_format" {
  description = "(Required) The format of the Cognitive Services Account Deployment model. Changing this forces a new resource to be created."
  type        = string
}

variable "model_name" {
  description = "(Required) The name of the Cognitive Services Account Deployment model. Changing this forces a new resource to be created."
  type        = string
}

variable "model_version" {
  description = "(Optional) The version of Cognitive Services Account Deployment model. If version is not specified, the default version of the model at the time will be assigned."
  type        = string
}

variable "sku_name" {
  description = "(Required) The name of the SKU. Possible values include Standard, DataZoneBatch, DataZoneStandard, DataZoneProvisionedManaged, GlobalBatch, GlobalProvisionedManaged, GlobalStandard, and ProvisionedManaged."
  type       = string
}

variable "version_upgrade_option" {
  description = "Deployment model version upgrade option. Possible values are OnceNewDefaultVersionAvailable, OnceCurrentVersionExpired, and NoAutoUpgrade. Defaults to OnceNewDefaultVersionAvailable."
  type        = string
}

variable "sku_capacity" {
  description = "(Optional) Tokens-per-Minute (TPM). The unit of measure for this field is in the thousands of Tokens-per-Minute. Defaults to 1 which means that the limitation is 1000 tokens per minute."
  type        = number
}