output "model_deploy_id" {
  description = "The ID of the Deployment for Azure Cognitive Services Account."
  value       = azurerm_cognitive_deployment.model_deploy.id
}