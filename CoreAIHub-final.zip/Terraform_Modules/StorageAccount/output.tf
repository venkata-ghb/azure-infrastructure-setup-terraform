output "storage_account_name" {
  description = "The Name of the newly created storage account."
  value       = azurerm_storage_account.storage_account.name
}
output "storage_account_id" {
  description = "The id of the newly created storage account"
  value       = azurerm_storage_account.storage_account.id
}
output "storage_account_rg" {
  description = "The Name of the newly created storage account"
  value       = azurerm_storage_account.storage_account.resource_group_name
}
output "storage_account_primary_blob_endpoint" {
  description = "The endpoint URL for blob storage in the primary location of the newly storage account."
  value       = azurerm_storage_account.storage_account.primary_blob_endpoint
}
output "principal_id" {
  description = "The System assigned identity principal ID of the newly storage account."
  value       = azurerm_storage_account.storage_account.identity[0].principal_id
}
output "blob-pvt_endpoint_id" {
  description = "ID of the provisioned private endpoint"
  value       = azurerm_private_endpoint.sa-blob-pep.id
}
output "blob-pvt_endpoint_name" {
  description = "The name of the private endpoint"
  value       = azurerm_private_endpoint.sa-blob-pep.name
}