locals {
  creation_date_tags     = { creationDate = formatdate("DD/MM/YYYY", time_static.created.rfc3339) }
}

##Manages a static time resource
resource "time_static" "created" {}

#Azure Storage Account Creation
resource "azurerm_storage_account" "storage_account" {
  resource_group_name               = var.rg_name
  location                          = var.location
  name                              = var.sa_name 
  account_tier                      = var.sa_account_tier
  access_tier                       = var.sa_access_tier 
  account_replication_type          = var.sa_account_replication_type
  allow_nested_items_to_be_public   = var.allow_blob_public_access
  public_network_access_enabled     = var.enable_public_network_access
  infrastructure_encryption_enabled = var.enable_infrastructure_encryption
  cross_tenant_replication_enabled  = var.enable_cross_tenant_replication
  is_hns_enabled                    = var.enable_hns
  min_tls_version                   = var.min_tls_version
  large_file_share_enabled          = var.enable_large_file_share
  shared_access_key_enabled         = var.enable_shared_access_key
  tags                              = merge(var.tags, local.creation_date_tags)

  dynamic "identity" {
    for_each = var.identity_type != null ? [1] : []
    content {
       type         = var.identity_type
       identity_ids = var.identity_type == "SystemAssigned" ? [] : var.identity_ids
    }
  }

  network_rules {
      bypass                     = var.network_rules.bypass
      default_action             = var.network_rules.default_action
      ip_rules                   = var.network_rules.ip_rules
      virtual_network_subnet_ids = concat([for subnet in data.azurerm_subnet.sa_subnets : subnet.id ], var.other_subs_sa_subnet_ids)
  }


  dynamic blob_properties {
    for_each = anytrue([(var.delete_retention_days > 0),(var.enable_versioning != "")]) ? [1] : []
     content {
      versioning_enabled = try(var.enable_versioning,false)
       dynamic delete_retention_policy {
        for_each = var.delete_retention_days > 0 ? [1] : []
        content {
          days = try(var.delete_retention_days,7)
        }
      }
       dynamic container_delete_retention_policy {
        for_each = var.container_delete_retention_days > 0 ? [1] : []
        content {
          days = try(var.container_delete_retention_days,7)
        }
      }
    }
  } 
  lifecycle {
    ignore_changes = [ blob_properties[0].cors_rule, network_rules.0.private_link_access ]
  }
}

resource "azurerm_storage_container" "storage_account_container" {
  for_each = var.containers 
    name                  = each.value.container_name        
    storage_account_id    = azurerm_storage_account.storage_account.id
    container_access_type = each.value.container_access_type
}

resource "azurerm_private_endpoint" "sa-blob-pep" {
  name                = var.sa_blob_endpoint_name
  location            = var.network_resource_location
  resource_group_name = var.rg_name
  subnet_id           = var.endpoint_subnet_id

  private_service_connection {
    name                           = "${var.sa_blob_endpoint_name}-connection"
    is_manual_connection           = var.enable_manual_connection
    private_connection_resource_id = azurerm_storage_account.storage_account.id
    subresource_names              = var.blob_subresource_names
  }

  dynamic "private_dns_zone_group" {
    for_each = var.enable_private_dns_zone_group == true ? [1] : []
    content {
      name                 = "deployedByTerraform"
      private_dns_zone_ids = [var.sa_blob_private_dns_zone_ids[0]]
    }
  }

  tags = merge(var.tags, local.creation_date_tags)

}

resource "azurerm_private_endpoint" "sa-dfs-pep" {
  count               = var.create_dfs_endpoint ? 1 : 0
  name                = var.sa_dfs_endpoint_name
  location            = var.network_resource_location
  resource_group_name = var.rg_name
  subnet_id           = var.endpoint_subnet_id

  private_service_connection {
    name                           = "${var.sa_dfs_endpoint_name}-connection"
    is_manual_connection           = var.enable_manual_connection
    private_connection_resource_id = azurerm_storage_account.storage_account.id
    subresource_names              = var.dfs_subresource_names
  }

  dynamic "private_dns_zone_group" {
    for_each = var.enable_private_dns_zone_group == true ? [1] : []
    content {
      name                 = "deployedByTerraform"
      private_dns_zone_ids = [var.sa_dfs_private_dns_zone_ids[0]]
    }
  }
 
  tags = merge(var.tags, local.creation_date_tags)

}