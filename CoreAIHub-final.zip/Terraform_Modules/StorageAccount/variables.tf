variable "sa_name" {
  description = "Specifies the name of the storage account."
  type        = string
}
variable "location" {
  description = "Specifies the location where the Storage Account need to be created."
  type        = string
}
variable "network_resource_location" {
  description = "Specifies the location where the Private Endpoint need to be created."
  type        = string
}
variable "rg_name" {
  description = "Specifies the name of the resource group in which to create the storage account."
  type        = string
}
variable "sa_account_tier" {
  description = "Specifies the tier to use for the storage account. Valid options are Standard and Premium."
  type        = string
}
variable "sa_access_tier" {
  description = "Specifies the tier to use for the storage account. Valid options are Hot, Cool, Cold and Archive."
  type        = string
}
variable "sa_account_replication_type" {
  description = "Specifies the type of replication to use for the storage account. Valid options are LRS, GRS, RAGRS, ZRS, GZRS and RAGZRS."
  type        =  string
}
variable "enable_cross_tenant_replication" {
  description = "Specifies the type of replication to use for the storage account. Valid options are LRS, GRS, RAGRS, ZRS, GZRS and RAGZRS."
  type        =  bool
}
variable "delete_retention_days" {
  description = "(Optional) Specifies the number of days that the container should be retained, between 1 and 365 days. Defaults to 7."
  type        = number
}
variable "enable_hns" {
  description = "(Optional) Is Hierarchical Namespace enabled? This can be used with Azure Data Lake Storage Gen 2 (see here for more information). Changing this forces a new resource to be created."
  type        = bool
}
variable "container_delete_retention_days" {
  default     = null
  description = "(Optional) Specifies the number of days that the container should be retained, between 1 and 365 days. Defaults to 7."
  type        = number
}
variable "tags" {
  description = "Specifies the mapping of tags to assign to the storage account."
  type        = map(string)
}
variable "allow_blob_public_access" {
  description = "Allow or disallow public access to all blobs or containers in the storage account. Defaults to false."
  type        = bool
} 
variable "enable_public_network_access" {
  description = "Specifies whether the public network access is enabled or not. Defaults to true."
  type        = bool
}
variable "enable_infrastructure_encryption" {
  description = "Specifies if the infrastructure encryption enabled or not.Changing this forces a new resource to be created. Defaults to false."
  type        = bool
  default     = null
}
variable "enable_versioning" {
  description = "Specifies if the versioning enabled or not.Default to false"
  type        = bool
}
variable "enable_large_file_share" {
  description = "(Optional) Are Large File Shares Enabled? Defaults to false."
  type        = bool
}
variable "enable_shared_access_key" {
  description = "Flag to enable shared access key"
  type = bool
}
variable "min_tls_version" {
  description = "The minimum supported TLS version for the storage account. Possible values are TLS1_0, TLS1_1, and TLS1_2. Defaults to TLS1_2 for new storage accounts."
  type        = string
}
variable "identity_type" {
  description = "Specifies the type of Managed Service Identity that should be configured on this Storage Account"
  type        = string
}
variable "identity_ids" {
  description = "(Optional) Specifies a list of User Assigned Managed Identity IDs to be assigned to this AI Foundry Project."
  type        = list(string)
}
variable "containers" {
  description = "Storage account databases"
  type = map(object({
    container_name   	    = string
    container_access_type = optional(string)
  }))
}
variable "sa_subnet_names" {
  description = "Key value subnet names"
  type        = list(string)
}
variable "network_rules" {
  description = "Network rules for the storage account"
  type = object({
      bypass   	     = list(string)
      default_action = string
      ip_rules       = list(string)
    })
}
variable "other_subs_sa_subnet_ids" {
  description = "Subnet IDs of the subnets from other subscriptions"
  type        = list(string)
}
variable "vnet_name" {
  type        = string
  description = "Specifies the Virtual network"
}
variable "vnet_rg_name" {
  type        = string
  description = "Specifies the Virtual network"
}
variable "sa_blob_endpoint_name" {
  type        = string
  description = "Specifies the name of the private end point."
}
variable "endpoint_subnet_id" {
  type        = string
  description = "Specifies the subnet for the private endpoint."
}
variable "enable_manual_connection" {
  type        = bool
  description = "Flag for the Private Endpoint's Manual Approval from the remote resource owner"
}
variable "blob_subresource_names" {
  type        = list(string)
  description = "Specifies the name of the private service connection subresources."
}
variable "enable_private_dns_zone_group" {
  description = "Flag for the enabling private dns zone"
  type        = bool
}
variable "sa_blob_private_dns_zone_ids" {
  description = "The Private DNS Zone Ids"
  type        = list(string)
}
variable "sa_dfs_private_dns_zone_ids" {
  description = "The Private DNS Zone Ids"
  type        = list(string)
}
variable "create_dfs_endpoint" {
  type = bool
}
variable "sa_dfs_endpoint_name" {
  type        = string
  description = "Specifies the name of the private end point."
}
variable "dfs_subresource_names" {
  type        = list(string)
  description = "Specifies the name of the private service connection subresources."
}
