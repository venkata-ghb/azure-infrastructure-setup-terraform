data "azurerm_subnet" "sa_subnets" {
  for_each             = toset(var.sa_subnet_names)
  name                 = each.key
  virtual_network_name = var.vnet_name
  resource_group_name  = var.vnet_rg_name
}
