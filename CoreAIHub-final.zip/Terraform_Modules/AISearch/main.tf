locals {
  creation_date_tags     = { creationDate = formatdate("DD/MM/YYYY", time_static.created.rfc3339) }
}

##Manages a static time resource
resource "time_static" "created" {}

resource "azurerm_search_service" "ai_search" {
  name                          = var.ai_search_name
  resource_group_name           = var.rg_name
  location                      = var.location
  sku                           = var.ai_search_sku
  allowed_ips                   = var.allowed_ips
  public_network_access_enabled = var.enable_public_network_access
  local_authentication_enabled  = var.enable_local_authentication
  authentication_failure_mode   = var.authentication_failure_mode
  hosting_mode                  = var.hosting_mode
  partition_count               = var.partition_count 
  replica_count                 = var.replica_count 
  semantic_search_sku           = var.semantic_search_sku
  network_rule_bypass_option    = var.network_rule_bypass_option

  dynamic "identity" {
    for_each = var.identity_type != null ? [1] : []  
    content {
       type         = var.identity_type
       identity_ids = var.identity_type == "SystemAssigned" ? [] : var.identity_ids
    }
  }

  tags = merge(var.tags, local.creation_date_tags)
}

resource "azurerm_private_endpoint" "ai_search_pep" {
  name                = var.ai_search_endpoint_name
  location            = var.network_resource_location
  resource_group_name = var.rg_name
  subnet_id           = var.endpoint_subnet_id
 
  private_service_connection {
    name                           = "${var.ai_search_endpoint_name}-connection"
    is_manual_connection           = var.enable_manual_connection
    private_connection_resource_id = azurerm_search_service.ai_search.id
    subresource_names              = var.subresource_names
  }

  dynamic "private_dns_zone_group" {
    for_each = var.enable_private_dns_zone_group == true ? [1] : []
    content {
      name                 = "deployedByTerraform"
      private_dns_zone_ids = [var.private_dns_zone_ids[0]]
    }
  }

  tags = merge(var.tags, local.creation_date_tags)
}