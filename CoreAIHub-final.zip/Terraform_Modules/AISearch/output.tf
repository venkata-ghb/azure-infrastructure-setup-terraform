output "ai_search_name" {
  description = "The ID of the Search Service."
  value       = azurerm_search_service.ai_search.name
}
output "ai_search_id" {
  description = "The ID of the Search Service."
  value       = azurerm_search_service.ai_search.id
}
output "primary_key" {
  description = "The Primary Key used for Search Service Administration."
  value       = azurerm_search_service.ai_search.primary_key
}
output "secondary_key" {
  description = "The Secondary Key used for Search Service Administration."
  value       = azurerm_search_service.ai_search.secondary_key
}
output "pvt_endpoint_id" {
  description = "ID of the provisioned private endpoint"
  value       = azurerm_private_endpoint.ai_search_pep.id
}
output "pvt_endpoint_name" {
  description = "The name of the private endpoint"
  value       = azurerm_private_endpoint.ai_search_pep.name
}
output "principal_id" {
  description = "The Principal ID associated with this Managed Service Identity."
  value       = azurerm_search_service.ai_search.identity[0].principal_id
}