variable "ai_search_name" {
  description = "(Required) The Name which should be used for this Search Service. Changing this forces a new Search Service to be created."
  type        = string
}
variable "rg_name" {
  description = "(Required) The name of the Resource Group where the Search Service should exist. Changing this forces a new Search Service to be created."
  type        = string
}
variable "location" {
  description = "(Required) The Azure Region where the Search Service should exist. Changing this forces a new Search Service to be created."
  type        = string
}
variable "network_resource_location" {
  description = "Specifies the location where the Private Endpoint need to be created."
  type        = string
}
variable "ai_search_sku" {
  description = "(Required) The SKU which should be used for this Search Service. Possible values include basic, free, standard, standard2, standard3, storage_optimized_l1 and storage_optimized_l2. Changing this forces a new Search Service to be created."
  type        = string
}
variable "allowed_ips" {
  description = "(Optional) Specifies a list of inbound IPv4 or CIDRs that are allowed to access the Search Service. If the incoming IP request is from an IP address which is not included in the allowed_ips it will be blocked by the Search Services firewall."
  type        = list(string)
}
variable "enable_public_network_access" {
  description = "(Optional) Specifies whether Public Network Access is allowed for this resource. Defaults to true."
  type        = bool
}
variable "enable_local_authentication" {
  description = "(Optional) Specifies whether the Search Service allows authenticating using API Keys? Defaults to true."
  type        = bool
}
variable "authentication_failure_mode" {
  description = "(Optional) Specifies the response that the Search Service should return for requests that fail authentication. Possible values include http401WithBearerChallenge or http403."
  type        = string
}
variable "hosting_mode" {
  description = "(Optional) Specifies the Hosting Mode, which allows for High Density partitions (that allow for up to 1000 indexes) should be supported. Possible values are highDensity or default. Defaults to default. Changing this forces a new Search Service to be created."
  type        = string
}
variable "partition_count" {
  description = "(Optional) Specifies the number of partitions which should be created. This field cannot be set when using a free sku (see the Microsoft documentation). Possible values include 1, 2, 3, 4, 6, or 12. Defaults to 1."
  type        = number
}
variable "replica_count" {
  description = "(Optional) Specifies the number of Replica's which should be created for this Search Service. This field cannot be set when using a free sku (see the Microsoft documentation)."
  type        = number
}
variable "semantic_search_sku" {
  description = "(Optional) Specifies the Semantic Search SKU which should be used for this Search Service. Possible values include free and standard."
  type        = string
}
variable "network_rule_bypass_option" {
  description = "(Optional) Whether to allow trusted Azure services to access a network restricted Search Service? Possible values are None and AzureServices. Defaults to None."
  type        = string
}
variable "identity_type" {
  description = "(Required) Specifies the type of Managed Service Identity that should be configured on this Search Service. Possible values are SystemAssigned, UserAssigned, and SystemAssigned, UserAssigned."
  type        = string
}
variable "identity_ids" {
  description = "(Optional) Specifies a list of User Assigned Managed Identity IDs to be assigned to this AI Foundry Project."
  type        = list(string)
}
variable "tags" {
  description = "(Optional) Specifies a mapping of tags which should be assigned to this Search Service."
  type        = map(string)
}
variable "ai_search_endpoint_name" {
  description = "(Required) Specifies the Name of the Private Endpoint. Changing this forces a new resource to be created."
  type        = string
}
variable "endpoint_subnet_id" {
  description = "(Required) The ID of the Subnet from which Private IP Addresses will be allocated for this Private Endpoint. Changing this forces a new resource to be created."
  type        = string
}
variable "enable_manual_connection" {
  description = "(Required) Does the Private Endpoint require Manual Approval from the remote resource owner? Changing this forces a new resource to be created."
  type        = bool
}
variable "subresource_names" {
  description = "(Optional) A list of subresource names which the Private Endpoint is able to connect to. subresource_names corresponds to group_id. Changing this forces a new resource to be created."
  type        = list(string)
}

variable "enable_private_dns_zone_group" {
  description = "Flag for enabling the private dns zone"
  type        = bool
}
variable "private_dns_zone_ids" {
  description = "The Private DNS Zone Ids"
  type        = list(string)
}