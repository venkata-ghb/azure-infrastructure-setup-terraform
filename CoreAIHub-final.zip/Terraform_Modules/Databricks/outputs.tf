output "dbx_ws_url" {
  description = "The workspace URL which is of the format 'adb-{workspaceId}.{random}.azuredatabricks.net"
  value       = azurerm_databricks_workspace.dbx_workspace.workspace_url
}
output "dbx_ws_name" {
  description = "The ID of the Databricks Workspace in the Azure management plane."
  value       = azurerm_databricks_workspace.dbx_workspace.name
}
output "dbx_ws_id" {
  description = "The ID of the Databricks Workspace in the Azure management plane."
  value       = azurerm_databricks_workspace.dbx_workspace.id
}
output "ws_id" {
  description = "The unique identifier of the databricks workspace in Databricks control plane."
  value       = azurerm_databricks_workspace.dbx_workspace.workspace_id
}
output "managed_rg" {
  value = azurerm_databricks_workspace.dbx_workspace.managed_resource_group_name
}