data "azurerm_virtual_network" "dbx_vnet" {
  name                = var.dbx_vnet_name
  resource_group_name = var.dbx_vnet_rg_name
}
data "azurerm_subnet" "public_subnet" {
  name                 = var.public_subnet_name
  virtual_network_name = var.dbx_vnet_name
  resource_group_name  = var.dbx_vnet_rg_name
}
data "azurerm_subnet" "private_subnet" {
  name                 = var.private_subnet_name
  virtual_network_name = var.dbx_vnet_name
  resource_group_name  = var.dbx_vnet_rg_name
}