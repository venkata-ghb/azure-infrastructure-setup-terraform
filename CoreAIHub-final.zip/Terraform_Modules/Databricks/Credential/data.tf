data "azurerm_databricks_access_connector" "dbx_acc_conne" {
  name                = var.dbx_access_connector_name
  resource_group_name = var.dbx_access_connector_rg_name
}