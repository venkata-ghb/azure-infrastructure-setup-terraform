## Storage Credential
resource "databricks_storage_credential" "storage_credential" {
  provider        = databricks
  name            = var.storage_cred_name
  azure_managed_identity {
    access_connector_id = data.azurerm_databricks_access_connector.dbx_acc_conne.id
  }
  comment         = var.comment
  skip_validation = var.skip_validation
  force_destroy   = var.force_destroy
}

## Storage Credential Grants
resource "databricks_grants" "ext_storage_creds" {
  provider           = databricks
  storage_credential = databricks_storage_credential.storage_credential.id
  dynamic grant {
    for_each = var.storage_grant == null ? [] : var.storage_grant
    content {
      principal  = grant.value.principal
      privileges = grant.value.privileges
    }
  }
  depends_on = [ databricks_storage_credential.storage_credential ]
}