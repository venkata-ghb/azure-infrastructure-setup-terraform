variable "storage_cred_name" {
  description = "Storage credential name"
  type        = string
}
variable "storage_grant" {
  description  = "List of roles to be granted access for storage credentials"
  type = list(object({
    principal  = string
    privileges = list(string)
  }))
}
variable "dbx_access_connector_name" {
  description = "Specifies the Access Connector Name"
  type        = string
}
variable "dbx_access_connector_rg_name" {
  description = "Specifies the Access Connector resource group Name"
  type        = string
}
variable "skip_validation" {
  description = "Suppress validation errors if any & force save the storage credential."
  type        = bool
}
variable "force_destroy" {
  description = "Delete storage credential regardless of its dependencies."
  type        = bool
}
variable "comment" {
  description = "User-supplied free-form text"
  type        = string
}