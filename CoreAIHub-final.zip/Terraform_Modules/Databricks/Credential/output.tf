output "sto_cred_id" {
  description = "Storage Credential name"
  value       = databricks_storage_credential.storage_credential.id 
}
output "sto_cred_name" {
  description = "ID of this storage credential - same as the name"
  value       = databricks_storage_credential.storage_credential.name
}