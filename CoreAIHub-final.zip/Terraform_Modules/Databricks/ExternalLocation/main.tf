## External location
resource "databricks_external_location" "ext-location" {
  provider        = databricks
  name            = var.ext_location_name
  url             = format("abfss://%s@%s.dfs.core.windows.net/%s", var.storage_container_name, var.storage_account_name,var.ext_loc_path)
  credential_name = var.storage_cred_name
  comment         = var.comment
  skip_validation = var.skip_validation
  force_destroy   = var.force_destroy
}

## External location Grants
resource "databricks_grants" "dbx-ext-location" {
  provider          = databricks
  external_location = databricks_external_location.ext-location.id
  dynamic grant {
    for_each = var.ext_loc_grant == null ? [] : var.ext_loc_grant
    content {
      principal  = grant.value.principal
      privileges = grant.value.privileges
    }
  }
}