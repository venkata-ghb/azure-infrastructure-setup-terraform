variable "ext_location_name" {
  description = "External location name"
  type        = string
}
variable "storage_cred_name" {
  description = "storage credential name"
  type        = string
}
variable "ext_loc_grant" {
  description  = "List of roles to be granted access for external locations"
  type = list(object({
    principal  = string
    privileges = list(string)
  }))
}
variable "storage_account_name" {
  description = "Specifies the Storage account name"
  type        = string
}

variable "storage_container_name" {
  description = "Specifies the Storage container name"
  type        = string
}
variable "ext_loc_path" {
  description = "External location path under storage account"
  type        = string
}
variable "skip_validation" {
  description = "Suppress validation errors if any & force save the external location"
  type        = bool
}
variable "force_destroy" {
  description = "Destroy external location regardless of its dependents."
  type        = bool
}
variable "comment" {
  description = "User-supplied free-form text"
  type        = string
}