output "ext_loc_name" {
  description = "External location name"
  value       = databricks_external_location.ext-location.name 
}
output "ext_loc_id" {
  description = "ID of this external location - same as name"
  value       = databricks_external_location.ext-location.id
}
output "ext_loc_url" {
  description = "External location URL"
  value       = databricks_external_location.ext-location.url 
}