variable "location" {
  description = "Location for Databricks"
  type        = string
} 
variable "network_resource_location" {
  description = "Specifies the location where the Storage Account need to be created."
  type        = string
}
variable "dbx_ws_name" {
  description = "Databricks workspace name"
  type        = string
} 
variable "dbx_ws_sku" {
  description = "SKU tier: standard or premium"
  type        = string
}
variable "rg_name" {
  description = "The name of the Resource Group"
  type        = string
}
variable "dbx_ws_managed_rg_name" {
  description = "Databricks managed resource group name"
  type        = string
}
variable "enable_public_network_access" {
  description = "Allow public access for accessing workspace. Set value to false to access workspace only via private link endpoint."
  type        = bool
}
variable "enable_infrastructure_encryption" {
  description = "This field is only valid if the Databricks Workspace sku is set to premium."
  type        = bool
}
variable "required_nsg_rules" {
  description = "Required when public_network_access_enabled is set to false"
  type        = string
}
variable "private_subnet_name" {
  description = "The name of the Private Subnet within the Virtual Network. Required if virtual_network_id is set"
  type        = string
}
variable "public_subnet_name" {
  description = "The name of the Public Subnet within the Virtual Network. Required if virtual_network_id is set."
  type        = string
}
variable "dbx_vnet_name" {
  description = "Virtual Network where Databricks Cluster should be created"
  type        = string
}
variable "dbx_vnet_rg_name" {
  description = "Virtual Network resoruce group name"
  type        = string
}
variable "dbx_endpoint_name" {
  description = "Specifies the name of the private end point."
  type        = string
}
variable "endpoint_subnet_id" {
  description = "Specifies the subnet for the private endpoint."
  type        = string
}
variable "enable_manual_connection" {
  description = "Flag for the Private Endpoint's Manual Approval from the remote resource owner"
  type        = bool
}
variable "subresource_names" {
  description = "Specifies the name of the private service connection subresources."
  type        = list(string)
}
variable "enable_private_dns_zone_group" {
  description = "Flag for the enabling private dns zone"
  type        = bool
}
variable "private_dns_zone_ids" {
  description = "The Private DNS Zone Ids"
  type        = list(string)
}
variable "tags" {
  description = "Specifies the mapping of tags to assign to the storage account."
  type        = map(string)
}