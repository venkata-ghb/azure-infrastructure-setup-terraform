## Datbricks Connections
resource "databricks_connection" "sql" {
  provider        = databricks
  name            = var.connection_name
  connection_type = var.connection_type
  comment         = var.comment
  options = {
    host     = var.host
    port     = var.port
    user     = var.user_name
    password = var.password
  }
}

## Connection Grants
resource "databricks_grants" "connection_creds" {
  provider           = databricks
 foreign_connection = databricks_connection.sql.name
  dynamic grant {
    for_each = var.connection_grant == null ? [] : var.connection_grant
    content {
      principal  = grant.value.principal
      privileges = grant.value.privileges
    }
  }
  depends_on = [ databricks_connection.sql ]
}