variable "connection_name" {
  description = "Name of the Connection"
  type = string
}
variable "connection_type" {
  description = "Connection type"
  type = string
}
variable "comment" {
  description = "Free-form text. Change forces creation of a new resource."
  type = string
}
variable "host" {
  description = "host name of the server"
  type = string
}
variable "port" {
  description = "Port number"
  type = string
}
variable "user_name" {
  description = "Username for connection"
  type = string
}
variable "password" {
  description = "Password for connection"
  type = string
}
variable "connection_grant" {
  description  = "List of roles to be granted access for connections"
  type = list(object({
    principal  = string
    privileges = list(string)
  }))
}