output "connection_id" {
    description = "Unique ID of the connection."
    value = databricks_connection.sql.connection_id
}
output "name" {
    description = "Name of connection"
    value = databricks_connection.sql.name
}
output "metastore_id" {
    description = "Unique ID of the UC metastore for this connection."
    value = databricks_connection.sql.metastore_id
}
output "id" {
    description = "ID of this connection in form of <metastore_id>|<name>."
    value = databricks_connection.sql.id
}