output "catalog_name" {
  description = "Name of this catalog"
  value       = databricks_catalog.dbx_catalog.name
}
output "catalog_id" {
  description = "ID of this catalog - same as the name."
  value       = databricks_catalog.dbx_catalog.id
}