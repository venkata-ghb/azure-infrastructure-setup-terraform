variable "dbx_catalog_name" {
  description = "Databricks catalog name"
  type        = string
}
variable "dbx_ws_id" {
  description = "Specifies the Databricks workspace name"
  type        = string
}
variable "ext_loc_url" {
  description = "Specifies the Databricks external location url"
  type        = string
}
variable "catalog_grant" {
  description = "List of roles to be granted access for databricks Catalog"
  type = list(object({
    principal  = string
    privileges = list(string)
  }))
}
variable "force_destroy" {
  description = "Delete catalog regardless of its contents"
  type        = bool
}
variable "comment" {
  description = "User-supplied free-form text"
  type        = string
}
variable "connection_name" {
  description = "Name of the Connection"
  type = string
}
variable "use_storage_root" {
  description = "Flag to use storage root"
  type = bool
}
variable "database_name" {
  description = "Name of the SQL Database"
  type = string
}