# Catalog
resource "databricks_catalog" "dbx_catalog" {
  provider      = databricks
  name          = var.dbx_catalog_name
  storage_root  = var.use_storage_root ? var.ext_loc_url : null
  force_destroy = var.force_destroy
  comment       = var.comment
  connection_name = var.use_storage_root ? null : var.connection_name
  options = var.connection_name != null ? { database = var.database_name } : {}
}

# Catalog Grants
resource "databricks_grants" "dbx-catalog-permissions" {
  provider = databricks
  catalog  = databricks_catalog.dbx_catalog.id
  dynamic grant {
    for_each = var.catalog_grant == null ? [] : var.catalog_grant
    content {
      principal  = grant.value.principal
      privileges = grant.value.privileges
    }
  }
  depends_on = [ databricks_catalog.dbx_catalog ]
}

# Binding
resource "databricks_workspace_binding" "dbx_binding" {
  provider       = databricks
  securable_name = databricks_catalog.dbx_catalog.name
  workspace_id   = var.dbx_ws_id
  depends_on = [ databricks_catalog.dbx_catalog ]
}