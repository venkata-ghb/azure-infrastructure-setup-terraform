locals {
  creation_date_tags     = { creationDate = formatdate("DD/MM/YYYY", time_static.created.rfc3339) }
}

##Manages a static time resource
resource "time_static" "created" {}

# Databricks Worspace 
resource "azurerm_databricks_workspace" "dbx_workspace" {
  name                                  = var.dbx_ws_name
  location                              = var.location
  resource_group_name                   = var.rg_name
  sku                                   = var.dbx_ws_sku
  managed_resource_group_name           = var.dbx_ws_managed_rg_name
  public_network_access_enabled         = var.enable_public_network_access
  network_security_group_rules_required = var.required_nsg_rules
  infrastructure_encryption_enabled     = var.enable_infrastructure_encryption
  tags                                  = merge(var.tags, local.creation_date_tags)

  custom_parameters {
    virtual_network_id                                   = data.azurerm_virtual_network.dbx_vnet.id
    private_subnet_name                                  = var.private_subnet_name
    public_subnet_name                                   = var.public_subnet_name
    private_subnet_network_security_group_association_id = data.azurerm_subnet.private_subnet.network_security_group_id
    public_subnet_network_security_group_association_id  = data.azurerm_subnet.public_subnet.network_security_group_id
  }

  lifecycle {
    ignore_changes = [ custom_parameters.0.virtual_network_id ]
  }
}

resource "azurerm_private_endpoint" "dbx-pep" {
  name                = var.dbx_endpoint_name
  location            = var.network_resource_location
  resource_group_name = var.rg_name
  subnet_id           = var.endpoint_subnet_id

  private_service_connection {
    name                           = "${var.dbx_endpoint_name}-connection"
    is_manual_connection           = var.enable_manual_connection
    private_connection_resource_id = azurerm_databricks_workspace.dbx_workspace.id
    subresource_names              = var.subresource_names
  }

  dynamic "private_dns_zone_group" {
    for_each = var.enable_private_dns_zone_group == true ? [1] : []
    content {
      name                 = "deployedByTerraform"
      private_dns_zone_ids = [var.private_dns_zone_ids[0]]
    }
  }
  
  tags = merge(var.tags, local.creation_date_tags)
  
  lifecycle {
    ignore_changes = [ private_dns_zone_group  ]
  }
}