locals {
  creation_date_tags     = { creationDate = formatdate("DD/MM/YYYY", time_static.created.rfc3339) }
}

##Manages a static time resource
resource "time_static" "created" {}

resource "azurerm_network_security_group" "nsg" {
  name                = var.nsg_name
  location            = var.location
  resource_group_name = var.rg_name
  tags                = merge(var.tags, local.creation_date_tags)
}