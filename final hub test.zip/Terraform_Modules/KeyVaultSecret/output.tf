output "kv_id" {
  description = "The Key Vault Secret ID."
  value       = azurerm_key_vault_secret.secret.id
}
output "kv_secret_version" {
  description = "The current version of the Key Vault Secret."
  value       = azurerm_key_vault_secret.secret.version
}

output "kv_secret_value" {
  description = "The value of the Key Vault Secret."
  value       = azurerm_key_vault_secret.secret.value
}