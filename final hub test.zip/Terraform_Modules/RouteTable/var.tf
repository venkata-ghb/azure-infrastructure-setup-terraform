variable "resource_group_name" {
   description = "The name of the  resource group in which to create the virtual network"
   type        = string
}

variable "location" {
 description = "The location/region where the Resource Group is created"
 type        = string
}

variable "tags" {
  description = "A mapping of tags for all resources"
  type        = map
}

variable "route_table_name" {
  description = "The name of the route table."
  type        = string
}