#Manages a Route Table
resource "azurerm_route_table" "routetable" {
  name                          = var.route_table_name
  location                      = var.location
  resource_group_name           = var.resource_group_name
  tags                          = merge(var.tags, {name = var.route_table_name})
}
