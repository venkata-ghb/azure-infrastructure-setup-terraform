output "mc_id" {
  value = azapi_resource.mc_vngw.id
}
output "mc_name" {
  value = azapi_resource.mc_vngw.name
}