resource "azapi_resource" "mc_vngw" {
  body = {
    properties = {
      extensionProperties = {
        maintenanceSubScope = var.maintenanceSubScope
      }
      maintenanceScope = var.scope
      maintenanceWindow = {
        duration      = var.duration
        recurEvery    = var.recur_every
        startDateTime = var.start_date_time
        timeZone      = var.time_zone
      }
      visibility = "Custom"
    }
  }
  ignore_casing             = false
  ignore_missing_property   = true
  location                  = var.location
  name                      = var.vnetgw-maintenance-config
  parent_id                 = "/subscriptions/${var.subscription_id}/resourceGroups/${var.resource_group_name}"
  schema_validation_enabled = true
  type                      = "Microsoft.Maintenance/maintenanceConfigurations@2023-10-01-preview"
  tags                      = merge(var.tags, {name = var.vnetgw-maintenance-config})
}

resource "azapi_resource" "vnet_gateway_maintenance_assignment" {
  type      = "Microsoft.Maintenance/configurationAssignments@2023-04-01"
  name      = var.vng_maintenace_assign_name
  parent_id = var.vng_id
  location  = var.location
    body = {
      properties = {
        maintenanceConfigurationId = lower(azapi_resource.mc_vngw.id)
      }
    }
}