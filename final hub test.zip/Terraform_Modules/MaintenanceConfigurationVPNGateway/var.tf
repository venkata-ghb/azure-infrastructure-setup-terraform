variable "vnetgw-maintenance-config" {
  type = string
}
variable "resource_group_name" {
  type = string
}
variable "location" {
  type = string
}
variable "scope" {
  type = string
}
variable "start_date_time" {
  type = string
}
variable "time_zone" {
  type = string
}
variable "recur_every" {
  type = string
}
variable "duration" {
  type = string
}
variable "maintenanceSubScope" {
  type = string
}
variable "tags" {
  type = map(string)
}
variable "subscription_id" {
  type = string
}

variable "vng_maintenace_assign_name" {
  type = string
}
variable "vng_id" {
  type = string
}