variable "alert_name" {
  description = "(Required) The name of the activity log alert. Changing this forces a new resource to be created."
  type        = string
}

variable "resource_group_name" {
  description = "(Required) The name of the resource group in which to create the activity log alert instance. Changing this forces a new resource to be created."
  type        = string
}

variable "location" {
  description = "(Required) The Azure Region where the activity log alert rule should exist. Changing this forces a new resource to be created."
  type        = string
}

variable "description" {
  description = "(Optional) The description of this activity log alert."
  type        = string
}

variable "category" {
  description = "(Required) The category of the operation. Possible values are Administrative, Autoscale, Policy, Recommendation, ResourceHealth, Security and ServiceHealth."
  type        = string
}

variable "tags" {
  description = "A mapping of tags to al the resources"
  type        = map 
}

variable "enabled" {
  description = "(Optional) Should this Activity Log Alert be enabled? Defaults to true."
  type        = bool
}

variable "service_health_events" {
 description = "(Optional) Events this alert will monitor Possible values are Incident, Maintenance, Informational, ActionRequired and Security."
 type        = list(string)
}

variable "action_group_id" {
 description = " (Required) The ID of the Action Group can be sourced from the azurerm_monitor_action_group resource."
 type        = string
}

variable "scope_id" {
  description = "(Required) The Scope at which the Activity Log should be applied. A list of strings which could be a resource group , or a subscription, or a resource ID (such as a Storage Account)."
 type        = list(string)
}
