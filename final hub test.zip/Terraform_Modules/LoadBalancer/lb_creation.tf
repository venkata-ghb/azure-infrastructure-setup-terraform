#Azure Internal Load Balancer Creation
locals {
  fe_ip_address = cidrhost(var.subnet_cidr, 4)
}

resource "azurerm_lb" "azilb" {
  name                			  = var.lb_name
  location            			  = var.location
  resource_group_name 			  = var.rg_name
  sku                 			  = var.lb_sku
  sku_tier                    = var.lb_sku_tier  
  tags               			    = merge(var.tags, {name = var.lb_name})

dynamic frontend_ip_configuration {
    for_each					  = var.frontend_ip_details
	content {
		name                          = "${var.lb_name}-${frontend_ip_configuration.value.fe_name}"
    zones                         = var.availability_zone == [] ? null : var.availability_zone
		subnet_id                     = var.subnet_id == "" ? null : var.subnet_id
		private_ip_address_allocation = var.private_ip_allocation
    private_ip_address_version    = var.private_ip_address_version 
		private_ip_address            =  frontend_ip_configuration.value.private_ip_address == "" ? local.fe_ip_address : frontend_ip_configuration.value.private_ip_address  
	}
  }
  lifecycle {
    ignore_changes = [frontend_ip_configuration]
  }
}

#Manages the Load Balancer Backend Address Pool.
resource "azurerm_lb_backend_address_pool" "azilbbackend" {
  for_each                    = var.bp_details
  loadbalancer_id     			  = azurerm_lb.azilb.id
  name                			  = "${var.lb_name}-${each.key}"
  virtual_network_id          = each.value.virtual_network_id == "" ? null : each.value.virtual_network_id
}

#Manages the LoadBalancer Probe Resource.
resource "azurerm_lb_probe" "azilbprobe" {
  for_each                    = var.lb_probe_details
  loadbalancer_id     			  = azurerm_lb.azilb.id
  name                			  = "${var.lb_name}-${each.key}"
  protocol            			  = each.value.protocol
  port                			  = each.value.port
  interval_in_seconds 			  = var.interval_in_seconds
  request_path        			  = each.value.path
}

#Manages the Load Balancer Rule.
resource "azurerm_lb_rule" "azilbrule" {
  for_each                       = var.lb_rule_details
  loadbalancer_id                = azurerm_lb.azilb.id
  name                           = "${var.lb_name}-${each.key}"
  protocol                       = each.value.protocol
  frontend_port                  = each.value.frontend_port
  backend_port                   = each.value.backend_port
  frontend_ip_configuration_name = "${var.lb_name}-${each.value.fe_ipconfig_name}"
  backend_address_pool_ids       = [azurerm_lb_backend_address_pool.azilbbackend[each.value.bp_name].id]
  idle_timeout_in_minutes        = each.value.idle_timeout_in_minutes
  probe_id                       = azurerm_lb_probe.azilbprobe[each.value.probe_name].id
  disable_outbound_snat          = each.value.disable_outbound_snat
  enable_floating_ip			       = each.value.enable_floating_ip
  load_distribution              = each.value.load_distribution
  depends_on                     = [ resource.azurerm_lb_probe.azilbprobe ]
}

