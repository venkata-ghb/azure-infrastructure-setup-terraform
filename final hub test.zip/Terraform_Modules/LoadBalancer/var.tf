variable "lb_name" {
  description = "Specifies the name of the Load Balancer"
  type        = string
}

variable "location" {
  description = "Specifies the supported Azure Region where the Load Balancer should be created"
  type        = string
}

variable "rg_name" {
  description = "The name of the Resource Group in which to create the Load Balancer"
  type        = string
}

variable "lb_sku" {
  description = "Specifies the type of the Load Balancer"
  type        = string
}

variable "lb_sku_tier" {
  description = " (Optional) sku_tier - (Optional) The SKU tier of this Load Balancer. Possible values are Global and Regional. Defaults to Regional. Changing this forces a new resource to be created."
  type 		  = string
}

variable "frontend_ip_details" {
type = list(object({
    fe_name= string
    private_ip_address = string
  }))
}

variable "subnet_id" {
  description = "The ID of the Subnet which should be associated with the IP Configuration"
  type        = string
}

variable "subnet_cidr" {
  description = "To fetch the fifth ip from the Subnet CIDR"
  type 		  = string
}

variable "private_ip_allocation" {
  description = "The allocation method for the Private IP Address used by this Load Balancer. Possible values as Dynamic and Static."
  type 		  = string
}

variable "private_ip_address_version" {
  description = "(Optional) The version of IP that the Private IP Address is. Possible values are IPv4 or IPv6."
  type 		  = string
}

variable "availability_zone"{ 
  description = "(Optional) Specifies a list of Availability Zones in which the IP Address for this Load Balancer should be located." 
  type 		  = list(string)
}

variable "tags" {
  description = "Tags to be applied to load balancer"
  type        = map(string)
}

variable "interval_in_seconds"{
  description = "The interval in seconds for how frequently to probe the endpoint for health status."
  type 		  = number
}

variable "bp_details" {
  description = "(Required) The backend pool address details. Changing this forces a new resource to be created."
  type        = map(object({
    virtual_network_id = string
  }))
}

variable "lb_probe_details" {
  description = "(Required) The backend pool address details. Changing this forces a new resource to be created."
  type        = map(object({
    protocol = string
    port = string
    path = string
  }))
}

variable "lb_rule_details" {
  description = "(Required) The backend pool address details. Changing this forces a new resource to be created."
  type        = map(object({
    protocol = string
    frontend_port = string
    backend_port = string
    fe_ipconfig_name = string
    bp_name = string
    idle_timeout_in_minutes = number
    probe_name = string
    enable_floating_ip = bool
    disable_outbound_snat = bool
    load_distribution = string

  }))
}
