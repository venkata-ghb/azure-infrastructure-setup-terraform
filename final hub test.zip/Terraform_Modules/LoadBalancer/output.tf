output "azlb_id" {
  description = "ID of Azure Load Balancer."
  value       = azurerm_lb.azilb.id
}

output "azlb_name" {
  description = "ID of Azure Load Balancer."
  value       = azurerm_lb.azilb.name
}

output "backendpool_id" {
  description = "The ID of the Backend Address Pool."
  value       = one([ for pool in azurerm_lb_backend_address_pool.azilbbackend : pool.id])
}


output "azlb_frontend_ip_config" {
  description = "Frontend IP Configuration of Azure Load Balancer."
  value       = azurerm_lb.azilb.*.frontend_ip_configuration
}

output "azlb_backend_pool_id" {
  description = "Id of Azure Load Balancer Backend pool."
  value       = toset([
    for lb in azurerm_lb_backend_address_pool.azilbbackend : lb.id
  ])
}

output "azlb_backend_pool_id_list" {
  description = "Id of Azure Load Balancer Backend pool."
  value       = tolist([
    for lb in azurerm_lb_backend_address_pool.azilbbackend : lb.id
  ])
}

output "azlb_lb_probe_ids" {
  description = "Id of Azure Load Balancer Probes."
  value       = toset([
    for lb in azurerm_lb_probe.azilbprobe : lb.id
  ])
}

