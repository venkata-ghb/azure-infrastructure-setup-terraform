resource "azurerm_network_ddos_protection_plan" "ddosp"{
  count               =   var.enabled ? 1 : 0
  name                = var.ddos_plan_name
  resource_group_name = var.resource_group_name
  location            = var.location
  tags                = merge(var.tags, {name = var.ddos_plan_name})

}