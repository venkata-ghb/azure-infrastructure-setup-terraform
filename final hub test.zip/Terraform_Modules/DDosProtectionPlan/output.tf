output "ddos_plan_name" {
  description = "Specifies the name of the DDOS Protection Plan created."
  value       = azurerm_network_ddos_protection_plan.ddosp[*].name
}
output "ddos_plan_id" {
  description = "Specifies the id of the DDOS Protection Plan created."
  value       = var.enabled ? azurerm_network_ddos_protection_plan.ddosp[0].id : null
}