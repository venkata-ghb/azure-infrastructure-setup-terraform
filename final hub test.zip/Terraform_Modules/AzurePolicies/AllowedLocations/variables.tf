variable "name" {
  description = "(Required) The name which should be used for this Policy Assignment. Possible values must be between 3 and 24 characters in length. Changing this forces a new Policy Assignment to be created."
  type = string
}

variable "policy_definition_id" {
  description = "(Required) The ID of the Policy Definition or Policy Definition Set. Changing this forces a new Policy Assignment to be created."
  type = string
}

variable "management_group_id" {
  description = "(Required) The ID of the Management Group. Changing this forces a new Policy Assignment to be created."
  type = string
}

variable "description" {
  description = "(Optional) A description which should be used for this Policy Assignment."
  type = string
}

variable "enforce" {
  description = "(Optional) Specifies if this Policy should be enforced or not? Defaults to true."
  type = bool
}

variable "allowed_location" {
  description = "The value of the parameters"
  type = list(string)
}
