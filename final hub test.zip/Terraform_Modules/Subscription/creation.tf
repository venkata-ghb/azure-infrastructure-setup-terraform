resource "azurerm_subscription" "subscription" {
  subscription_name = var.subscription_name
  alias             = var.alias
  billing_scope_id  = var.billing_scope_id
  workload          = var.workload
  tags              = merge(var.tags_sub, {name = var.subscription_name})
  lifecycle {
    prevent_destroy = false
  }
}
