variable "billing_scope_id" {
    description = "(Required) The Azure Billing Scope ID. Can be a Microsoft Customer Account Billing Scope ID, a Microsoft Partner Account Billing Scope ID or an Enrollment Billing Scope ID."
    type = string
}

variable "subscription_name" {
    description = "(Required) The Name of the Subscription. This is the Display Name in the portal."
    type = string
}

variable "alias" {
  description = "(Optional) The Alias name for the subscription. Terraform will generate a new GUID if this is not supplied. Changing this forces a new Subscription to be created."
  type = string
}

variable "workload" {
  type = string
  description = "(Optional) The workload type of the Subscription. Possible values are Production (default) and DevTest. Changing this forces a new Subscription to be created."
}
variable "tags_sub" {
  description = "A mapping of tags to all the resources."
  type       = map(string)
}