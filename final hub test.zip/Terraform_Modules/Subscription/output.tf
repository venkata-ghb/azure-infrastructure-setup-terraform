output "subscription_id" {
  value = azurerm_subscription.subscription.subscription_id
}

