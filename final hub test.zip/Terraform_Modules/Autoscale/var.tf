variable "resource_group_name" {
  description = "Specifies the name of the Resource Group in which the dqata disk should exist"
  type        = string
}

variable "location" {
  description = "Specifies the Azure Region where the respurce should exists"
  type        = string
}

variable "autoscale_name" {
  description = "Specifies the name of additional data disks."
  type = string
}

variable "target_resource_id" {
  description = "Specify the number of instances and the availability zones of VM Servers."
   type = string
}

variable "profile_name" {
  description = "Specifies the names of specific vms.Need tobe used only if some vms are tobe selected else its empty set."
  type        = string
}

variable "min_instance_count" {
  description = "Specifies the storage account type of additional data disk"
  type        = string
}

variable "max_instance_count" {
  description = "(Required) The method to use when creating the managed disk. Changing this forces a new resource to be created."
  type        = string
}

variable "default_instance_count" {
  description = "A mapping of tags to al the resources"
  type        = string
}

variable "tags" {
  description = "A mapping of tags to al the resources"
  type        = map
}

variable "autoscale_rules" {
  description = "Specifies the ids of virtual machines and names"
  type        = list(object({
    metric_name = string
    metric_namespace=string
    time_grain = string
    statistic = string
    time_window = string
    time_aggregation = string
    operator = string
    threshold =  number
    direction = string
    instance_change_value = number
    cooldown = string
  }))
}

