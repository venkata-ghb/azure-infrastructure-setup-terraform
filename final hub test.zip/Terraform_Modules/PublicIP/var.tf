variable "public_ip_name" {
 description = "Specifies the name of the Public IP resource"
 type        = string
}

variable "location" {
description = "Specifies the supported Azure location where the resource exists"
 type       = string
}

variable "rg_name" {
description = "The name of the resource group in which to create the public ip"
 type       = string
}

variable "public_ip_allocation" {
description = "Defines the allocation method for this IP address. Possible values are Static or Dynamic."
 type       = string
}

variable "sku" {
 description = "(Optional) Specifies the timeout for the TCP idle connection. The value can be set between 4 and 30 minutes."
 type       = string
}

variable "idle_timeout_in_minutes" {
 description = "The SKU of the Public IP. Accepted values are Basic and Standard. Defaults to Basic."
 type       = string
}

variable "domain_name_label" {
 description = " (Optional) Label for the Domain Name. Will be used to make up the FQDN. If a domain name label is specified, an A DNS record is created for the public IP in the Microsoft Azure DNS system."
 type       = string
}

variable "sku_tier" {
 description = " (Optional) The SKU Tier that should be used for the Public IP. Possible values are Regional and Global. Defaults to Regional. Changing this forces a new resource to be created."
 type       = string
}

variable "zones" {
  description = "(Optional) Specifies a list of Availability Zones in which this Application Gateway should be located. Changing this forces a new Application Gateway to be created."
  type        = list(string) 
}

variable "ddos_protection_mode" {
  description = "(Optional) The DDoS protection mode of the public IP. Possible values are Disabled, Enabled, and VirtualNetworkInherited. Defaults to VirtualNetworkInherited."
  type = string
}
variable "ddos_protection_plan_id" {
  description = "(Optional) The ID of DDoS protection plan associated with the public IP."
  type = string
}

variable "tags" {
 description = "The SKU of the Public IP. Accepted values are Basic and Standard. Defaults to Basic."
 type       = map(any)
}