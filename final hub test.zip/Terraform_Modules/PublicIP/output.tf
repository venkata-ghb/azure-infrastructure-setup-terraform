output "public_ip_id" {
  description = "Specifies the Public IP ID."
  value = azurerm_public_ip.publicip.id
}

output "public_ip_address" {
  description = "Specifies the Public IP Address."
  value = azurerm_public_ip.publicip.ip_address
}

output "public_ip_name_id" {
   description = "Specifies the Public IP Name ID."
  value = { 
    (azurerm_public_ip.publicip.name) = (azurerm_public_ip.publicip.id)
  }
 }

output "public_ip_name" {
   description = "Specifies the Public IP Name."
  value = azurerm_public_ip.publicip.name
 }