#Manages a Public IP Address.
resource "azurerm_public_ip" "publicip" {
  name                = var.public_ip_name
  location            = var.location
  resource_group_name = var.rg_name
  allocation_method   = var.public_ip_allocation
  sku                 = var.sku
  zones               = var.zones == [] ? null : var.zones
  domain_name_label   = var.domain_name_label == "" ? null : var.domain_name_label
  idle_timeout_in_minutes = var.idle_timeout_in_minutes == null ? null : var.idle_timeout_in_minutes
  sku_tier            = var.sku_tier
  ddos_protection_mode = var.ddos_protection_mode
  ddos_protection_plan_id = anytrue([(var.ddos_protection_plan_id == ""),(var.ddos_protection_mode == "Disabled")]) ? null : var.ddos_protection_plan_id
  tags                      = merge(var.tags, {name = var.public_ip_name})
}

