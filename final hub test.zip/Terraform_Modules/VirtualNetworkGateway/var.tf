variable "location" {
  description="The Azure location where this Virtual Network Gateway should be created."
  type=string
}

variable "resource_group_name" {
  description="The Name of the Resource Group in which this Virtual Network Gateway should be created. "
  type=string
}

variable "tags" {
  description="tags for virtual network gateway"
  type=map(string)
}

variable "vnet_gateway_name" {
  description="The Name which should be used for this Virtual Network Gateway."
  type=string
}

variable "vnet_gateway_type" {
  description="The type of the Virtual Network Gateway. Valid options are Vpn or ExpressRoute."
  type=string
}

variable "vpn_type" {
  description="The routing type of the Virtual Network Gateway. Valid options are RouteBased or PolicyBased. "
  type=string
}

variable "enable_active_active" {
  description="If true an active-active Virtual Network Gateway will be created. An active-active gateway requires a HighPerformance or an UltraPerformance sku. If false an active-standby gateway will be created. "
  type=string
}

variable "enable_bgp" {
  description="If true BGP Border Gateway Protocol will be enabled for this Virtual Network Gateway."
  type=string
}

variable "vnet_gateway_sku" {
  description="Configuration of the size and capacity of the virtual network gateway. Valid options are Basic Standard HighPerformance UltraPerformance ErGw1AZ ErGw2AZ ErGw3AZ VpnGw1 VpnGw2 VpnGw3 VpnGw4 VpnGw5 VpnGw1AZ VpnGw2AZ VpnGw3AZVpnGw4AZ and VpnGw5AZ and depend on the type vpn_type and generation arguments. A PolicyBased gateway only supports the Basic sku. Further the UltraPerformance sku is only supported by an ExpressRoute gateway."
  type=string
}

variable "generation" {
  description = "(Optional) The Generation of the Virtual Network gateway. Possible values include Generation1, Generation2 or None. Changing this forces a new resource to be created."
  type = string
}

variable "subnet_id" {
  description="The ID of the gateway subnet of a virtual network in which the virtual network gateway will be created. It is mandatory that the associated subnet is named GatewaySubnet"
  type=string
}

variable "vpn_ip_config" {
  description = "Specifies the details of the subnets."
  type        = list(object( {
    ip_config_name          = string
    public_ip_address_name  = string
  }))
}

variable "remote_vnet_traffic_enabled" {
  type = bool
}
variable "virtual_wan_traffic_enabled" {
  type = bool
}
variable "public_ip_address_name_ids" {
  type = map(string)
  description = "The name to the id of the public ip address as a map"
}