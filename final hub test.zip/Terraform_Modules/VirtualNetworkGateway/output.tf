output "vnet_gateway_id" {
  description = "The virtual network gateway id"
  value = azurerm_virtual_network_gateway.virtualnetworkgateway.id
}
output "vnet_gateway_name" {
  description = "The virtual network gateway id"
  value = azurerm_virtual_network_gateway.virtualnetworkgateway.name
}
output "vnet_gateway_location" {
  description = "The virtual network gateway id"
  value = azurerm_virtual_network_gateway.virtualnetworkgateway.location
}