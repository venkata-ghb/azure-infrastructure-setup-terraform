 resource "azurerm_virtual_network_gateway" "virtualnetworkgateway" {
  name                = var.vnet_gateway_name
  location            = var.location
  resource_group_name = var.resource_group_name
  type                = var.vnet_gateway_type
  vpn_type            = var.vpn_type
  active_active       = var.enable_active_active
  enable_bgp          = var.enable_bgp
  sku                 = var.vnet_gateway_sku
  generation          = var.generation
  remote_vnet_traffic_enabled = var.remote_vnet_traffic_enabled
  virtual_wan_traffic_enabled = var.virtual_wan_traffic_enabled
  dynamic ip_configuration {
    for_each = var.vpn_ip_config == [] ? null : var.vpn_ip_config
    content {
      name                          = ip_configuration.value.ip_config_name == "" ? null : ip_configuration.value.ip_config_name
      subnet_id                     = var.subnet_id
      public_ip_address_id          = lookup(var.public_ip_address_name_ids, ip_configuration.value.public_ip_address_name, null)
    }
  }

  tags = merge(var.tags, {name = var.vnet_gateway_name})
}