variable "resource_group_name" {
  type = string
  description = "The name of the resource group."
}

variable "location" {
  type = string
  description = "The Azure location where resources should be deployed."
}

variable "nat_gateway_name" {
  type = string
  description = "The name of the NAT gateway."
}

variable "tags" {
  description = "(Optional) A mapping of tags to assign to the resource."
  type        = map(string)
}

variable "idle_timeout_in_minutes" {
  description =  "(Optional) The idle timeout which should be used in minutes. Defaults to 4."
  type        = number
}

variable "zones" {
  description =  "(Optional) A list of Availability Zones in which this NAT Gateway should be located. Changing this forces a new NAT Gateway to be created."
  type        = list(string)
}