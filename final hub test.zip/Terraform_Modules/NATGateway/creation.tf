# NAT Gateway Creation
resource "azurerm_nat_gateway" "nat_gateway" {
  name                 = var.nat_gateway_name
  location             = var.location
  resource_group_name  = var.resource_group_name
  idle_timeout_in_minutes = var.idle_timeout_in_minutes == null ? null : var.idle_timeout_in_minutes
  zones                = var.zones == [] ? null : var.zones
  tags                = merge(var.tags, {name = var.nat_gateway_name})
}

