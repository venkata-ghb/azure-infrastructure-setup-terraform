variable "sta_id" {
  type = string
}
variable "default_action" {
  type = string
}
variable "ip_rules" {
  type = list(string)
}
variable "virtual_network_subnet_ids" {
  type = list(string)
}
variable "bypass" {
  type = list(string)
}