output "lp_name" {
  description = "The log profile name"
  value = azapi_resource.logProfile.name
}

output "lp_id" {
  description = "The log profile ID"
  value = azapi_resource.logProfile.id
}