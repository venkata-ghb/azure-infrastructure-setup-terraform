
#Manages a Log Profile. A Log Profile configures how Activity Logs are exported.
resource "azapi_resource" "logProfile" {
  type      = "Microsoft.Insights/logProfiles@2016-03-01"
  parent_id = "/subscriptions/${var.subscription_id}"
  location  = var.location 
  name      = var.log_profile_name
  body = {
    properties = {
      categories = var.categories
      locations = [for location in var.locations: lower(location)]

      retentionPolicy = {
        days    = var.retention_policy_enabled ? var.retention_policy_days : null
        enabled = var.retention_policy_enabled
      }
      storageAccountId = var.storage_account_id
    }
  }
}
