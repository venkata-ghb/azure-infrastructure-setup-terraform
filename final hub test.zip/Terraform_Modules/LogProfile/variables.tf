variable "log_profile_name" {
  type = string
  description = "(Required) The name of the Log Profile. Changing this forces a new resource to be created."
}

variable "location" {
  type = string
  description = "(Required) The Azure location where resources should be deployed."
}

variable "locations" {
  type = list(string)
  description = " (Required) List of regions for which Activity Log events are stored or streamed."
}

variable "categories" {
  type = list(string)
  description = "(Required) List of categories of the logs."
}

variable "retention_policy_enabled" {
  type = bool
  description = "(Required) A boolean value to indicate whether the retention policy is enabled."
}

variable "retention_policy_days" {
  type = number
  description = "(Optional) The number of days for the retention policy. Defaults to 0"
}

variable "storage_account_id" {
  type = string
  description = "The resource ID of the storage account in which the Activity Log is stored. "
}

variable "subscription_id" {
  type = string
  description = "The GUID of the subscription."
}