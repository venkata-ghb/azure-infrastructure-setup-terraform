resource "azurerm_subnet" "subnet" {
  name                 = var.snt_name
  resource_group_name  = var.resource_group_name
  virtual_network_name = var.vnt_name
  address_prefixes     = var.address_space
  service_endpoints    = var.service_endpoints 
  }