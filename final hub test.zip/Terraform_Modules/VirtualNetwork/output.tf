output "vnet_id" {
  description = "The virtual NetworkConfiguration ID."
  value       = azurerm_virtual_network.vnet.id
 
}
output "vnet_name" {
  description = "The name of the virtual network."
  value       = azurerm_virtual_network.vnet.name
}
output "vnet_rg_name" {
  description = "The name of resource_group"
  value       = azurerm_virtual_network.vnet.resource_group_name
}
output "first_vnet_address_space" {
  description = "The first address space of the virtual network"
  value       = element(tolist(azurerm_virtual_network.vnet.address_space), 0)
}

output "vnet_address_space" {
  description = "The address space of the virtual network"
  value       = azurerm_virtual_network.vnet.address_space
}