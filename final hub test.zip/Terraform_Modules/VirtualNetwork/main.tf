resource "azurerm_virtual_network" "vnet" {
  name                = var.vnt_name
  location            = var.location
  resource_group_name = var.resource_group_name
  address_space       = var.vnt_address_space
  dns_servers     =     var.dns_servers
  dynamic ddos_protection_plan {
    for_each = var.ddos_protection_plan_enabled ? [1] : []
    content {
      id     = var.ddos_protection_plan_id
      enable = var.ddos_protection_plan_enabled 
    }
  }

  tags                =  merge(var.tags, {name = var.vnt_name})
}