variable "vnt_name" {
  description = "(Required) The name of the virtual network. Changing this forces a new resource to be created."
  type        = string
}
variable "location" {
  description = "(Required) The location/region where the virtual network is created. Changing this forces a new resource to be created."
  type        = string
}
variable "resource_group_name" {
  description = "(Required) The name of the resource group in which to create the virtual network."
  type        = string
}
variable "vnt_address_space" {
  description = "(Required) The address space that is used the virtual network. You can supply more than one address space."
  type        = list(string)
}

variable "ddos_protection_plan_enabled" {
  description = "(Required) Enable/disable DDoS Protection Plan on Virtual Network."
  type        = bool
}

variable "ddos_protection_plan_id" {
  description = "(Required) The ID of DDoS Protection Plan."
  type        = string
}
 
variable "tags" {
  description = "A mapping of tags to all the resources."
   type       = map(string)
}
variable "dns_servers" {
  type = list(string)
} 