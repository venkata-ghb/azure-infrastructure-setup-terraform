output "nsr_id" {
  description = "The ID of the Network Security Rule."
  value       = azurerm_network_security_rule.network_security_rules.id
}
