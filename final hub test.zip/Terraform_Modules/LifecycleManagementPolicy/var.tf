variable "storage_account_id" {
  description = " (Required) Specifies the id of the storage account to apply the management policy to. Changing this forces a new resource to be created."
  type        = string
}
variable "rule_name" {
  description = "(Required) The name of the rule. Rule name is case-sensitive. It must be unique within a policy."
  type        = string
}
variable "blob_types" {
  description = "(Required) Boolean to specify whether the rule is enabled."
  type        = list(string)
}
variable "delete_after_days_since_modification_greater_than" {
  description = "(Optional) The age in days after last modification to delete the blob. Must be between 0 and 99999. Defaults to -1"
  type        = number
}
variable "rule_enabled" {
  description = "(Required) Boolean to specify whether the rule is enabled."
  type        = bool
}
variable "prefix_match" {
  type = list(string)
  default = null
}