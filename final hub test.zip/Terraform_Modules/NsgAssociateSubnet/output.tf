output "sng_id" {
  description = "The ID of the Subnet."
  value       = azurerm_subnet_network_security_group_association.subnet_with_network_security_group.id
}
