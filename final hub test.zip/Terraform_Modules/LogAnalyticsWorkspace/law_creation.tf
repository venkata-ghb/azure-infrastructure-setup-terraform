resource "azurerm_log_analytics_workspace" log_analytics_workspace {
  count               = var.enabled ? 1 : 0
  name                = var.law_name
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = var.law_sku == "" ? "" : var.law_sku
  retention_in_days   = var.law_retention_in_days == null ? null : var.law_retention_in_days
  daily_quota_gb      = var.daily_quota_gb == null ? null :  var.daily_quota_gb
  tags                = merge( var.tags, { name = var.law_name })
}