output "law_id" {
  description = "The Log Analytics Workspace ID."
  value       = var.enabled ? azurerm_log_analytics_workspace.log_analytics_workspace[0].id : null
}
output "workspace_id" {
  description = "The Workspace (or Customer) ID for the Log Analytics Workspace."
  value       = var.enabled ? azurerm_log_analytics_workspace.log_analytics_workspace[0].workspace_id : null
}
output "law_name" {
  description = "The name of the Log Analytics Workspace."
  value       = var.enabled ? azurerm_log_analytics_workspace.log_analytics_workspace[0].name : null
}
output "law_location" {
  description = "Azure location where the resource exists."
  value       = var.enabled ? azurerm_log_analytics_workspace.log_analytics_workspace[0].location : null
}
output "primary_shared_key" {
  description = "The Primary shared key for the Log Analytics Workspace."
  value       = var.enabled ? azurerm_log_analytics_workspace.log_analytics_workspace[0].primary_shared_key : null
}