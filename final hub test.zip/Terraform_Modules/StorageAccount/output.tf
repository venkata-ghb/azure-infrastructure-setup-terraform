output "stgaccount_name" {
  description = "The Name of the newly created storage account."
  value       = azurerm_storage_account.stgac.name
}
 
output "stgaccount_id" {
  description = "The id of the newly created storage account"
  value       = azurerm_storage_account.stgac.id
}
 
output "stgaccount_rg" {
  description = "The Name of the newly created storage account"
  value       = azurerm_storage_account.stgac.resource_group_name
}
 
output "stgaccount_primary_blob_endpoint" {
  description = "The endpoint URL for blob storage in the primary location of the newly storage account."
  value       = azurerm_storage_account.stgac.primary_blob_endpoint
}