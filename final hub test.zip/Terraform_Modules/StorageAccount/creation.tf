#Azure Storage Account Creation
resource "azurerm_storage_account" "stgac" {
  resource_group_name               = var.resource_group_name
  location                          = var.location
  name                              = var.name 
  account_tier                      = var.account_tier
  access_tier                       = var.access_tier 
  account_replication_type          = var.account_replication_type
  allow_nested_items_to_be_public   = var.allow_blob_public_access
  public_network_access_enabled     = var.public_network_access_enabled
  infrastructure_encryption_enabled = var.infrastructure_encryption_enabled
  cross_tenant_replication_enabled  = var.cross_tenant_replication_enabled
  is_hns_enabled                    = var.is_hns_enabled
  min_tls_version                   = var.min_tls_version
  tags                              = merge(var.tags, {name = var.name})
  large_file_share_enabled          = var.large_file_share_enabled
  shared_access_key_enabled         = var.shared_access_key_enabled
   dynamic share_properties {
    for_each = var.fs_delete_retention_days > 0 ? [1] : []
      content {
        retention_policy {
          days = var.fs_delete_retention_days
        }
    }
  }

  
  dynamic blob_properties {
    for_each = anytrue([(var.delete_retention_days > 0),(var.versioning_enabled != "")]) ? [1] : []
 
    content {
      versioning_enabled = try(var.versioning_enabled,false)
 
      dynamic delete_retention_policy {
        for_each = var.delete_retention_days > 0 ? [1] : []
        content {
          days = try(var.delete_retention_days,7)
        }
      }
 
      dynamic container_delete_retention_policy {
        for_each = var.container_delete_retention_days > 0 ? [1] : []
        content {
          days = try(var.container_delete_retention_days,7)
        }
      }
    }
  }
 
  lifecycle {
    ignore_changes = [tags]
  }
}