//********************** Basic Configuration Variables **************************//
variable "vmss_name"{
  description = "vmss name"
  type = string
}

variable "resource_group_name" {
  description = "Azure Resource Group name to build into"
  type = string
}

variable "location" {
  description = "The location/region where resources will be created. The full list of Azure regions can be found at https://azure.microsoft.com/regions"
  type = string
}

//********************** Virtual Machine Instances Variables **************************//
variable "source_image_vhd_uri" {
  type = string
  description = "The URI of the blob containing the development image. Please use noCustomUri if you want to use marketplace images."
}

variable "admin_username" {
  description = "Administrator username of deployed VM. Due to Azure limitations 'notused' name can be used"
}

variable "admin_password" {
  description = "Administrator password of deployed Virtual Machine. The password must meet the complexity requirements of Azure"
  type = string
}

variable "serial_console_password_hash" {
  description = "Optional parameter, used to enable serial console connection in case of SSH key as authentication type"
  type = string
}

variable "maintenance_mode_password_hash" {
  description = "Maintenance mode password hash, relevant only for R81.20 and higher versions"
  type = string
}

variable "availability_zones_num" {
  description = "The number of availability zones to use for Scale Set. Note that the load balancers and their IP addresses will be redundant in any case."
  type = list(string)
}

variable "sic_key" {
  description = "Secure Internal Communication(SIC) key"
  type = string
}
resource "null_resource" "sic_key_invalid" {
  count = length(var.sic_key) >= 12 ? 0 : "SIC key must be at least 12 characters long"
}

variable "template_name"{
  description = "Template name. Should be defined according to deployment type(ha, vmss)"
  type = string
}

variable "template_version"{
  description = "Template version. It is recommended to always use the latest template version"
  type = string
}

variable "template_type"{
  description = "Template name. Should be defined according to deployment type(ha, vmss)"
  type = string
}
variable "installation_type"{
  description = "Installation type"
  type = string
}

variable "number_of_vm_instances"{
  description = "Default number of VM instances to deploy"
  type = string
}

variable "minimum_number_of_vm_instances" {
  description = "Minimum number of VM instances to deploy"
  type = string
}

variable "maximum_number_of_vm_instances" {
  description = "Maximum number of VM instances to deploy"
  type = string
}

variable "vm_size" {
  description = "Specifies size of Virtual Machine"
  type = string
}

variable "publisher" {
  description = "CheckPoint publisher"
}

variable "vm_os_version" {
  description = "The version of the image that you want to deploy. "
  type = string
}

variable "os_version" {
  description = "GAIA OS version"
  type = string
}

locals { // locals for 'vm_os_offer' allowed values
  os_version_allowed_values = [
    "R81",
    "R8110",
    "R8120",
    "R82"
  ]
  // will fail if [var.os_version] is invalid:
  validate_os_version_value = index(local.os_version_allowed_values, var.os_version)
}
variable "disk_size" {
  description = "Storage data disk size size(GB). Select a number between 100 and 3995, if you are using R81.20 or below, the disk size must be 100"
  type = string
}
resource "null_resource" "disk_size_validation" {
  // Will fail if var.disk_size is not 100 and the version is R81.20 or below
  count = tonumber(var.disk_size) != 100 && contains(["R81", "R8110", "R8120"], var.os_version) ? "variable disk_size can not be changed for R81.20 and below" : 0
}
variable "vm_os_sku" {
  description = "The sku of the image to be deployed."
  type = string
}

variable "authentication_type" {
  description = "Specifies whether a password authentication or SSH Public Key authentication should be used"
  type = string
}
locals { // locals for 'authentication_type' allowed values
  authentication_type_allowed_values = [
    "Password",
    "SSH Public Key"
  ]
  // will fail if [var.authentication_type] is invalid:
  validate_authentication_type_value = index(local.authentication_type_allowed_values, var.authentication_type)
}

variable "allow_upload_download" {
  description = "Automatically download Blade Contracts and other important data. Improve product experience by sending data to Check Point"
  type = bool
}

variable "is_blink" {
  description = "Define if blink image is used for deployment"
}

variable "management_name" {
  description = "The name of the management server as it appears in the configuration file"
  type = string
}

variable "management_IP" {
  description = "The IP address used to manage the VMSS instances"
  type = string
}

variable "management_interface" {
  description = "Manage the Gateways in the Scale Set via the instance's external (eth0) or internal (eth1) NIC's private IP address"
  type = string
}
locals { // locals for 'management_interface' allowed values
  management_interface_allowed_values = [
    "eth0-public",
    "eth0-private",
    "eth1-private"
  ]
  // will fail if [var.management_interface] is invalid:
  validate_management_interface_value = index(local.management_interface_allowed_values, var.management_interface)
}

variable "configuration_template_name" {
  description = "The configuration template name as it appears in the configuration file"
  type = string
}

variable "admin_shell" {
  description = "The admin shell to configure on machine or the first time"
  type = string
}

locals {
  admin_shell_allowed_values = [
    "/etc/cli.sh",
    "/bin/bash",
    "/bin/csh",
    "/bin/tcsh"
  ]
  // Will fail if [var.admin_shell] is invalid
  validate_admin_shell_value = index(local.admin_shell_allowed_values, var.admin_shell)
}

variable "public_ssh_key" {
  description = "The public SSH key used for the VMSS authentication"
  type = string
}

//********************** Networking Variables **************************//
variable "vnet_name" {
  description = "Virtual Network name"
  type = string
}

variable "frontend_subnet_name" {
  description = "Frontend subnet name"
  type = string
}

variable "backend_subnet_name" {
  description = "Backend subnet name"
  type = string
}

variable "vnet_resource_group" {
  description = "Resource group of existing vnet"
  type = string
}

variable "vnet_allocation_method" {
  description = "IP address allocation method"
  type = string
}

variable "add_storage_account_ip_rules" {
  type = bool
  default = false
  description = "Add Storage Account IP rules that allow access to the Serial Console only for IPs based on their geographic location"
}

variable "storage_account_additional_ips" {
  type = list(string)
  description = "IPs/CIDRs that are allowed access to the Storage Account"
}

//********************* Load Balancers Variables **********************//

variable "deployment_mode" {
  description = "The type of the deployment, can be 'Standard' for both load balancers or 'External' for external load balancer or 'Internal for internal load balancer"
  type = string
}

locals {  // locals for 'deployment_mode' allowed values
  deployment_mode_allowd_values = [
    "Standard",
    "External",
    "Internal"
  ]
  // will fail if [var.deployment_mode] is invalid:
  validate_deployment_mode_value = index(local.deployment_mode_allowd_values, var.deployment_mode)
}

variable "backend_lb_IP_address" {
  description = "The IP address is defined by its position in the subnet"
  type = number
}

variable "lb_probe_port" {
  description = "Port to be used for load balancer health probes and rules"
  default = "8117"
}

variable "lb_probe_protocol" {
  description = "Protocols to be used for load balancer health probes and rules"
  default = "Tcp"
}

variable "lb_probe_unhealthy_threshold" {
  description = "Number of times load balancer health probe has an unsuccessful attempt before considering the endpoint unhealthy."
  default     = 2
}

variable "lb_probe_interval" {
  description = "Interval in seconds load balancer health probe rule performs a check"
  default = 5
}

variable "frontend_port" {
  description = "Port that will be exposed to the external Load Balancer"
  type = string
  default = "80"
}

variable "backend_port" {
  description = "Port that will be exposed to the external Load Balance"
  type = string
  default = "8081"
}

variable "frontend_load_distribution" {
  description = "Specifies the load balancing distribution type to be used by the frontend load balancer"
  type = string
}

locals { // locals for 'frontend_load_distribution' allowed values
  frontend_load_distribution_allowed_values = [
    "Default",
    "SourceIP",
    "SourceIPProtocol"
  ]
  // will fail if [var.frontend_load_distribution] is invalid:
  validate_frontend_load_distribution_value = index(local.frontend_load_distribution_allowed_values, var.frontend_load_distribution)
}

variable "backend_load_distribution" {
  description = "Specifies the load balancing distribution type to be used by the backend load balancer"
  type = string
}

locals { // locals for 'frontend_load_distribution' allowed values
  backend_load_distribution_allowed_values = [
    "Default",
    "SourceIP",
    "SourceIPProtocol"
  ]
  // will fail if [var.backend_load_distribution] is invalid:
  validate_backend_load_distribution_value = index(local.backend_load_distribution_allowed_values, var.backend_load_distribution)
}

//********************** Scale Set variables *******************//

variable "vm_os_offer" {
  description = "The name of the offer of the image that you want to deploy.Choose from:  check-point-cg-r81, check-point-cg-r8110, check-point-cg-r8120, check-point-cg-r82"
  type = string
}

locals { // locals for 'vm_os_offer' allowed values
  vm_os_offer_allowed_values = [
    "check-point-cg-r81",
    "check-point-cg-r8110",
    "check-point-cg-r8120",
    "check-point-cg-r82"
  ]
  // will fail if [var.vm_os_offer] is invalid:
  validate_os_offer_value = index(local.vm_os_offer_allowed_values, var.vm_os_offer)
}

variable "bootstrap_script"{
  description = "An optional script to run on the initial boot"
  #example:
  #"touch /home/admin/bootstrap.txt; echo 'hello_world' > /home/admin/bootstrap.txt"
}

variable "notification_email" {
  description = "Specifies a list of custom email addresses to which the email notifications will be sent"
  type = string
}

variable "subscription_id" {
  description = "Subscription ID"
  type = string
}

variable "sku" {
  description = "SKU"
  type = string
  default = "Standard"
}

variable "enable_custom_metrics" {
  description = "Enable CloudGuard metrics in order to send statuses and statistics collected from VMSS instances to the Azure Monitor service."
  type = bool
}

variable "enable_floating_ip" {
  description = "Indicates whether the load balancers will be deployed with floating IP."
  type = bool
}

variable "nsg_id" {
  description = "NSG ID - Optional - if empty use default NSG"
  default = ""
}

variable "bypass" {
  type = list(string)
  description = "Optional) Specifies whether traffic is bypassed for Logging/Metrics/AzureServices. Valid options are any combination of Logging, Metrics, AzureServices, or None. Defaults to AzureServices."
}

variable "infrastructure_encryption_enabled" {
  description = "Specifies if the infrastructure encryption enabled or not.Changing this forces a new resource to be created. Defaults to false."
  type        = bool
  default     = null
}

variable "encryption_at_host_enabled" {
  description = "(Optional) Should all of the disks (including the temp disk) attached to this Virtual Machine be encrypted by enabling Encryption at Host?"
  type = bool
}
variable "allow_blob_public_access" {
  type = bool
  description = "(Optional) Allow or disallow nested items within this Account to opt into being public. Defaults to true"
}

variable "shared_access_key_enabled" {
  type = bool
  description = "(Optional) Indicates whether the storage account permits requests to be authorized with the account access key via Shared Key. If false, then all requests, including shared access signatures, must be authorized with Azure Active Directory (Azure AD). Defaults to true."
}

variable "ddos_protection_mode" {
  description = "(Optional) The DDoS protection mode of the public IP. Possible values are Disabled, Enabled, and VirtualNetworkInherited. Defaults to VirtualNetworkInherited."
  type = string
}
variable "ddos_protection_plan_id" {
  description = "(Optional) The ID of DDoS protection plan associated with the public IP."
  type = string
}

variable "rg_tags" {
  description = "Tags to be applied to load balancer"
  type        = map(string)
}
variable "min_tls_version" {
  type = string
}
variable "delete_retention_days" {
  description = "(Optional) Specifies the number of days that the container should be retained, between 1 and 365 days. Defaults to 7."
  type        = number
}

variable "container_delete_retention_days" {
  default = null
  description = "(Optional) Specifies the number of days that the container should be retained, between 1 and 365 days. Defaults to 7."
  type        = number
}
variable "versioning_enabled" {
  description = "Specifies if the versioning enabled or not.Default to false"
  type        = bool
}
variable "access_tier" {
  description = "Specifies the tier to use for the storage account. Valid options are Hot, Cool, Cold and Archive."
  type        = string
}

variable "frontend_subnet_address_prefix" {
  type = string
  description = "address prefix of the frontend subnet"
}

variable "backend_subnet_address_prefix" {
  type = string
  description = "address prefix of the backend subnet"
}