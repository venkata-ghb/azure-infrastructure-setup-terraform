output "resource_group_link" {
  value = module.common.resource_group_link
}
output "lb_public_ip" {
  value = length(azurerm_public_ip.public-ip-lb) == 1 ? azurerm_public_ip.public-ip-lb[0].ip_address : null
}
output "resource_group" {
  value = azurerm_linux_virtual_machine_scale_set.vmss.resource_group_name
}
output "location" {
  value = azurerm_linux_virtual_machine_scale_set.vmss.location
}
output "vmss_name" {
  value = azurerm_linux_virtual_machine_scale_set.vmss.name
}
output "os_version" {
  value = module.common.os_version
}
output "disk_size" {
  value = azurerm_linux_virtual_machine_scale_set.vmss.os_disk[0].disk_size_gb
}
output "storage_account_id" {
  value = azurerm_storage_account.vm-boot-diagnostics-storage.id
}
output "vmss_id" {
  value = azurerm_linux_virtual_machine_scale_set.vmss.identity[0].principal_id
}
output "backend_lb_frontend_ip" {
  value=var.deployment_mode != "External" ? azurerm_lb.backend-lb[0].private_ip_address : null
}

output "nsg_name" {
  value = module.network-security-group[0].network_security_group_name
}

output "nsg_id" {
  value = module.network-security-group[0].network_security_group_id
}

output "publicip_id" {
  value = length(azurerm_public_ip.public-ip-lb) == 1 ? azurerm_public_ip.public-ip-lb[0].id : null
}

output "backend_lb_id" {
  value = var.deployment_mode != "External" ? azurerm_lb.backend-lb[0].id : null
}
 
output "frontend_lb_id" {
  value = var.deployment_mode != "Internal" ? azurerm_lb.frontend-lb[0].id : null
}

output "backend_lb_name" {
  value = var.deployment_mode != "External" ? azurerm_lb.backend-lb[0].name : null
}
 
output "frontend_lb_name" {
  value = var.deployment_mode != "Internal" ? azurerm_lb.frontend-lb[0].name : null
}