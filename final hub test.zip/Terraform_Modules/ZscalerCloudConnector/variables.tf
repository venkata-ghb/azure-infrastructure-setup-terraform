variable "cc_vmss_name" {
  description = " (Required) The name of the Virtual Machine Scale Set. Changing this forces a new resource to be created."
  type        = string
}
 
variable "tags" {
  type        = map(string)
  description = "Populate any custom user defined tags from a map"
}
 
variable "resource_group" {
  type        = string
  description = "Main Resource Group Name"
}
 
variable "location" {
  type        = string
  description = "Cloud Connector Azure Region"
}
 
variable "cc_username" {
  type        = string
  description = "Default Cloud Connector admin/root username"
}

variable "ssh_key" {
  type        = string
  description = "SSH Key for instances"
}
 
variable "ccvmss_instance_type" {
  type        = string
  description = "Cloud Connector Image size"
}
 
variable "ccvmss_image_publisher" {
  type        = string
  description = "Azure Marketplace Cloud Connector Image Publisher"
}
 
variable "ccvmss_image_offer" {
  type        = string
  description = "Azure Marketplace Cloud Connector Image Offer"
}
 
variable "ccvmss_image_sku" {
  type        = string
  description = "Azure Marketplace Cloud Connector Image SKU"
}
 
variable "ccvmss_image_version" {
  type        = string
  description = "Azure Marketplace Cloud Connector Image Version"
}
 
variable "ccvmss_source_image_id" {
  type        = string
  description = "Custom Cloud Connector Source Image ID. Set this value to the path of a local subscription Microsoft.Compute image to override the Cloud Connector deployment instead of using the marketplace publisher"
}
 
variable "zones" {
  type        = list(string)
  description = " (Optional) Specifies a list of Availability Zones across which the Virtual Machine Scale Set will create instances."
}
 
variable "managed_identity_id" {
  type        = string
  description = "ID of the User Managed Identity assigned to Cloud Connector VM"
}

variable "encryption_at_host_enabled" {
  type        = bool
  description = "User input for enabling or disabling host encryption"
}

variable "storage_account_uri" {
  type = string
}

variable "user_data" {
  type        = string
  description = "Cloud Init data"
}

variable "fault_domain_count" {
  type        = number
  description = "(Required) Specifies the number of fault domains that are used by this Virtual Machine Scale Set. Changing this forces a new resource to be created.platformFaultDomainCount must be set to 1 for max spreading or 5 for static fixed spreading. Fixed spreading with 2 or 3 fault domains isn't supported for zonal deployments" 
}

variable "zone_balance" {
  type        = bool
  description = "(Optional) Should the Virtual Machines in this Scale Set be strictly evenly distributed across Availability Zones? Defaults to false. Changing this forces a new resource to be created."
}

variable "termination_notification_enabled" {
  type        = bool
  description = "(Required) Should the termination notification be enabled on this Virtual Machine Scale Set? Possible values true or false"
}

variable "termination_notification_timeout" {
  type        = string
  description = "(Optional) Length of time (in minutes, between 5 and 15) a notification to be sent to the VM on the instance metadata server till the VM gets deleted. The time duration should be specified in ISO 8601 format. Defaults to PT5M."
}

variable "accelerated_networking_enabled" {
  type        = bool
  description = "Enable/Disable accelerated networking support on all Cloud Connector service interfaces"
  default     = true
}

variable "resource_group_name_ntw" {
  type = string
}

variable "nw_interface_details" {
  description = "The configurations of the network interface block"
  type = list(object({
    nw_interface_name      = string
    primary                = bool
    ip_forwarding          = bool
    accelerated_networking = bool
    nsg_name               = string
    ip_config = list(object({
      ip_config_name      = string
      subnet_id           = string
      ip_config_primary   = bool
      lb_backend_ids      = list(string)
    }))
  }))
}

variable "subscription_id" {
  description = "The GUID of the subscription"
  type        = string
}

variable "shortlocation" {
  type        = string
  description = "The short naming of resource"
}

variable "virtual_network_name" {
  description = "(Optional) A list of Virtual Machine Scale Set network interface ip Configuration name and Backend Address Pools ID's from a Load Balancer which VMSS should be connected to."
  type        = string
}

variable "storage_account_type" {
    description = "(Required) The Type of Storage Account which should back this Data Disk. Possible values include Standard_LRS, StandardSSD_LRS, StandardSSD_ZRS, Premium_LRS, PremiumV2_LRS, Premium_ZRS and UltraSSD_LRS."
    type = string
}

variable "caching" {
  type        = string
  description = "(Required) The type of Caching which should be used for this Data Disk. Possible values are None, ReadOnly and ReadWrite."
}

variable "lb_backend_address_pool_ids" {
  type        = list(string)
  description = "Azure LB Backend Address Pool ID for NIC association"
}

variable "nsg_name_ids" {
  type        = map
  description = "Network security group with name as key and id as value"
}