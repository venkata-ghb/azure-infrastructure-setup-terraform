output "ccvmss_id" {
  description = "The ID of the Virtual Machine Scale Set"
  value = azurerm_orchestrated_virtual_machine_scale_set.cc_vmss.id
}
output "ccvmss_name" {
  description = "The Name of the Virtual Machine Scale Set"
  value = azurerm_orchestrated_virtual_machine_scale_set.cc_vmss.name
}