###Create Cloud Connector VMSS
resource "azurerm_orchestrated_virtual_machine_scale_set" "cc_vmss" {
  name                        = var.cc_vmss_name
  location                    = var.location
  resource_group_name         = var.resource_group
  platform_fault_domain_count = var.fault_domain_count
  sku_name                    = var.ccvmss_instance_type
  encryption_at_host_enabled  = var.encryption_at_host_enabled
  zones                       = var.zones
  zone_balance                = var.zone_balance
  user_data_base64            = base64encode(var.user_data)

  dynamic termination_notification {
    for_each = var.termination_notification_enabled ? [1] : []
    content {
      enabled = var.termination_notification_enabled
      timeout = var.termination_notification_timeout
    }
  }
  
  dynamic network_interface {
    for_each = var.nw_interface_details == null ? [] : var.nw_interface_details
    content {
      name                             = "${var.cc_vmss_name}-${network_interface.value.nw_interface_name}"
      primary                          = network_interface.value.primary
      enable_ip_forwarding             = network_interface.value.ip_forwarding
      enable_accelerated_networking    = network_interface.value.accelerated_networking
      network_security_group_id        = network_interface.value.nsg_name == "" ? null : var.nsg_name_ids[network_interface.value.nsg_name]
      dynamic ip_configuration {
        for_each = network_interface.value.ip_config == null ? [] : network_interface.value.ip_config
        content {
          name                                   = ip_configuration.value.ip_config_name
          primary                                = ip_configuration.value.ip_config_primary
          subnet_id                              = ip_configuration.value.subnet_id == "" ? null : format("/subscriptions/%s/resourceGroups/%s/providers/Microsoft.Network/virtualNetworks/%s/subnets/%s-%s", var.subscription_id, var.resource_group_name_ntw, var.virtual_network_name, var.shortlocation, ip_configuration.value.subnet_id)  
          load_balancer_backend_address_pool_ids = length(ip_configuration.value.lb_backend_ids)> 0 ? var.lb_backend_address_pool_ids : []
        }
      }
    }
  }

  os_profile {
    custom_data = base64encode(var.user_data)
    linux_configuration {
      admin_username = var.cc_username
      admin_ssh_key {
        username   = var.cc_username
        public_key = "${trimspace(var.ssh_key)} ${var.cc_username}@me.io"
      }
    }
  }

  os_disk {
    storage_account_type = var.storage_account_type
    caching              = var.caching
  }
 
  identity {
    type         = "UserAssigned"
    identity_ids = [var.managed_identity_id]
  }

  dynamic "source_image_reference" {
    for_each = var.ccvmss_source_image_id == null ? [var.ccvmss_image_publisher] : []

    content {
      publisher = var.ccvmss_image_publisher
      offer     = var.ccvmss_image_offer
      sku       = var.ccvmss_image_sku
      version   = var.ccvmss_image_version
    }
  }

  dynamic "plan" {
    for_each = var.ccvmss_source_image_id == null ? [var.ccvmss_image_publisher] : []

    content {
      publisher = var.ccvmss_image_publisher
      name      = var.ccvmss_image_sku
      product   = var.ccvmss_image_offer
    }
  }
  boot_diagnostics {
    storage_account_uri = var.storage_account_uri
  }
  source_image_id = var.ccvmss_source_image_id != null ? var.ccvmss_source_image_id : null

  tags = merge(var.tags, {name = var.cc_vmss_name}, {hostname = var.cc_vmss_name})
}