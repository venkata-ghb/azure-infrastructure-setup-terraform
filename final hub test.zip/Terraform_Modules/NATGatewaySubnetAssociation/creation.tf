# Associate NAT Gateway with Subnet
resource "azurerm_subnet_nat_gateway_association" "subnet_nat" {
  subnet_id      = var.subnet_id
  nat_gateway_id = var.nat_gateway_id
}