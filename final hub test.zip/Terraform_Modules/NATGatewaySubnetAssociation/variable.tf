variable "subnet_id" {
  type = string
  description = "The ID of the subnet."
}

variable "nat_gateway_id" {
  type = string
  description = "The ID of the public IP address."
}
