output "pe_id" {
  value = azurerm_private_endpoint.pvtendpoint.id
}
output "pe_name" {
  value = azurerm_private_endpoint.pvtendpoint.name
}