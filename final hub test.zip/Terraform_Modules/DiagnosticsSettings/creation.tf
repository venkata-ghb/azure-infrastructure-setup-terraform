#Manages a Diagnostic Setting for an existing Resource.
resource "azurerm_monitor_diagnostic_setting" "diag_name" {
  name                       = var.dlog_name
  target_resource_id         = var.target_id
  storage_account_id         = var.storage_acc_id == "" ? null : var.storage_acc_id
  log_analytics_workspace_id = var.workspace_rs_id

  enabled_log {
    category = "Administrative"
  }
  enabled_log {
    category = "Security"
  }
  enabled_log {
    category = "ServiceHealth"
  }
  enabled_log {
    category = "Alert"
  }
  enabled_log {
    category = "Policy"
  }
  }