variable "workspace_rs_id" {
  description = "(Optional) Specifies the ID of a Log Analytics Workspace where Diagnostics Data should be sent."
  type        = string
}
 
variable "dlog_name" {
  description = "(Required) Specifies the names of the Diagnostic Settings."
  type        = string
}
 
variable "target_id" {
  description = "(Required) The IDs of an existing Resources on which to configure Diagnostic Settings. "
  type        = string
}
 
variable "storage_acc_id" {
  description = "(Optional) The ID of the Storage Account where logs should be sent."
  type        = string
}