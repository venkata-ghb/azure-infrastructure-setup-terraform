variable "nat_gateway_id" {
  type = string
  description = "The ID of the subnet."
}

variable "public_ip_address_id" {
  type = string
  description = "The ID of the public IP address."
}