shortlocation    = "INC"
###-------------------------------- Azure Policy for Resource Lock ------------------------------
policy_resource_lock = {
    "resource_lock" = {
        "policy_name"         = "Custom-CanNotDelete_Lock"
        "display_name"        = "Custom-CanNotDelete_Lock"
        "policy_mode"         = "All"
        "policy_description"  = "This policy is intended to Lock all the Resources in the hub to ensure that the Resources once deployed cannot be modified or deleted."
        "assignment_name"     = "Custom-CanNotDelete_Lock"
    }
}
policy_resource_group_lock = {
    "resource_group_lock" = {
        "policy_name"         = "Custom-CanNotDelete_Lock_RG"
        "display_name"        = "Custom-CanNotDelete_Lock_RG"
        "policy_mode"         = "All"
        "policy_description"  = "This policy is intended to Lock all the Resource Groups in the hub to ensure that the Resource groups once deployed cannot be modified or deleted."
        "assignment_name"     = "Custom-CanNotDelete_Lock_RG"
    }
}

enforce              = true

### -----------------------------------Resource Lock Ipmplemented for Hub resources ----------------
hub_public_ips = {
  "public_ip_01" =  {
    public_ip_names     = "PIP-HUB-CC-VNET01-NATGW01"
    public_ip_rg_name   = "HUB02-RG-C-9AAG028759"
  }
  "public_ip_02" =  {
    public_ip_names     = "PIP-HUB-CC-VNET01-NATGW02"
    public_ip_rg_name   = "HUB02-RG-C-9AAG028759"
  }
}

int_fw_public_ip = {
  "intfw_pip_01" = {
    public_ip_names     = "HUBINTSCALESET01-app-1"
    public_ip_rg_name   = "HUB02-RG-F-INTFW"
  }
}

hub_keyvaults = {
  "kv_01"  = {
    key_vault_name  = "hubglbkv07"
    kv_rg_name      = "HUB02-RG-F-MGMT"
  }
  "kv_02"  = {
    key_vault_name  = "hubintkv07"
    kv_rg_name      = "HUB02-RG-F-MGMT"
  }
}
 
hub_nat_gateways = {
  "nat_gw_01" = {
    nat_gateway_name        = "HUB-CC-VNET01-NAT-GW-01"
    nat_gateway_rg_name     = "HUB02-RG-C-9AAG028759"
  },
 
  "nat_gw_02" = {
    nat_gateway_name        = "HUB-CC-VNET01-NAT-GW-02"
    nat_gateway_rg_name     = "HUB02-RG-C-9AAG028759"
  }
}
 
hub_vpn_gateways = {
  "vpn_gateway_01"  =  {
    vpn_gateway_name    = "HUB-VNET01-ER-GW01"
    vpn_gateway_rg_name  = "HUB02-RG-F-NETWORK"
  }
}

hub_storage_accounts       = {
  "sta_01"  = {
    sta_name      = "glbprdstalog01"
    sta_rg_name   = "HUB02-RG-F-MGMT"
  },
  "sta_02"  = {
    sta_name       = "glbprdstalog02"
    sta_rg_name    = "HUB02-RG-F-MGMT"
  }
}

fws_storage_accounts       = {
  "glb_sta"  = {
    sta_name      = "diag1727bb36c9aab334" #This storage account name using Random id, so it will be changing based on new creations
    sta_rg_name   = "HUB02-RG-F-GLBFW"
  },
  "int_sta"  = {
    sta_name       = "diag7801286937fbba88" #This storage account name using Random id, so it will be changing based on new creations
    sta_rg_name    = "HUB02-RG-F-INTFW"
  }
}

kv_private_endpoints = {
  "pe_kv_glb" = {
    pe_name       = "HUBGLBPE01"
    pe_rg_name    = "HUB02-RG-F-MGMT"
  },
  "pe_kv_int" = {
    pe_name       = "HUBINTPE01"
    pe_rg_name    = "HUB02-RG-F-MGMT"
  }
}

hub_vnetgw_mc = {
  "vnetgw_mc_01" = {
vnetgw_mc_name  = "HUB-VNET01-ER-GW01-Maintenance-01"
  }
}

mc_rg_name      = "HUB02-RG-F-NETWORK"

zslr_ssh_public_keys = {
  "zsclr_ssh_key_01" = {
    ssh_public_key_name    = "CC-Public-SSH-KEY"
    ssh_public_key_rg_name = "HUB02-RG-C-9AAG028759"
  }
}

fws_ssh_public_keys = {
  "ssh_key_01" = {
    ssh_public_key_name    = "HUBGLB"
    ssh_public_key_rg_name = "HUB02-RG-F-MGMT"
  },
  "ssh_key_02" = {
    ssh_public_key_name    = "HUBINT"
    ssh_public_key_rg_name = "HUB02-RG-F-MGMT"
  }
}

hub_law = {
  "hub_law_01" = {
    law_name  = "LA-01"
    law_rg    = "HUB02-RG-F-MGMT"
  }
}
subscription_identifier = "HUB02"

hub_ntw_watcher_rg   = {
  "ntw_watcher_01"  = {
ntw_watcher_rg_name = "NetworkWatcherRG"
  }
}