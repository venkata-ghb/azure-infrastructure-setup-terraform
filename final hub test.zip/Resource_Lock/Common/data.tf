### ----------------------- Azure Policy for Resource Lock -------------------------------------------
data "azurerm_public_ip" "hub_public_ips" {
  provider            = azurerm.current_sub
  for_each            = var.hub_public_ips != {} ? var.hub_public_ips : {}
  name                = "${var.shortlocation}-${each.value.public_ip_names}"
  resource_group_name = "IS${var.shortlocation}${each.value.public_ip_rg_name}"
}

data "azurerm_public_ip" "int_fw_public_ip" {
  provider            = azurerm.current_sub
  for_each            = var.int_fw_public_ip != {} ? var.int_fw_public_ip : {}
  name                = "XC${var.shortlocation}${each.value.public_ip_names}"
  resource_group_name = "IS${var.shortlocation}${each.value.public_ip_rg_name}"
}

data "azurerm_key_vault" "hub_keyvaults" {
  provider            = azurerm.current_sub
  for_each            = var.hub_keyvaults != {} ? var.hub_keyvaults : {}
  name                = "is${lower(var.shortlocation)}${each.value.key_vault_name}"
  resource_group_name = "IS${var.shortlocation}${each.value.kv_rg_name}"
}

data "azurerm_nat_gateway" "hub_nat_gateways" {
  provider            = azurerm.current_sub
  for_each            = var.hub_nat_gateways != {} ? var.hub_nat_gateways : {}
  name                = "${var.shortlocation}-${each.value.nat_gateway_name}"
  resource_group_name =  "IS${var.shortlocation}${each.value.nat_gateway_rg_name}"
}

data "azurerm_virtual_network_gateway" "hub_vpn_gateways" {
  provider            = azurerm.current_sub
  for_each            = var.hub_vpn_gateways != {} ? var.hub_vpn_gateways : {}
  name                = "${var.shortlocation}-${each.value.vpn_gateway_name}"
  resource_group_name = "IS${var.shortlocation}${each.value.vpn_gateway_rg_name}"
}

data "azurerm_storage_account" "hub_storage_accounts" {
  provider            = azurerm.current_sub
  for_each            = var.hub_storage_accounts != {} ? var.hub_storage_accounts : {}
  name                = "abbis${lower(var.shortlocation)}${each.value.sta_name}"
  resource_group_name = "IS${var.shortlocation}${each.value.sta_rg_name}"
}

data "azurerm_storage_account" "fws_storage_accounts" {
  provider            = azurerm.current_sub
  for_each            = var.fws_storage_accounts != {} ? var.fws_storage_accounts : {}
  name                = each.value.sta_name
  resource_group_name = "IS${var.shortlocation}${each.value.sta_rg_name}"
}

data "azurerm_private_endpoint_connection" "kv_private_endpoints" {
  provider            = azurerm.current_sub
  for_each            = var.kv_private_endpoints != {} ? var.kv_private_endpoints : {}
  name                = "IS${var.shortlocation}${each.value.pe_name}"
  resource_group_name = "IS${var.shortlocation}${each.value.pe_rg_name}"
}

data "azurerm_resource_group" "hub_mc_vnet_gateway_rg" {
  provider = azurerm.current_sub
  name     = "IS${var.shortlocation}${var.mc_rg_name}" 
}

data "azapi_resource" "hub_mc_vnet_gateways" {
  for_each  = var.hub_vnetgw_mc != {} ? var.hub_vnetgw_mc : {}
  type      = "Microsoft.Maintenance/maintenanceConfigurations@2023-10-01-preview"
  name      = "${var.shortlocation}-${each.value.vnetgw_mc_name}"
  parent_id = data.azurerm_resource_group.hub_mc_vnet_gateway_rg.id
}

data "azurerm_ssh_public_key" "zslr_ssh_public_key" {
  provider            = azurerm.current_sub
  for_each            = var.zslr_ssh_public_keys != {} ? var.zslr_ssh_public_keys : {}
  name                = each.value.ssh_public_key_name
  resource_group_name = "IS${var.shortlocation}${each.value.ssh_public_key_rg_name}"
}

data "azurerm_ssh_public_key" "fws_ssh_public_keys" {
  provider            = azurerm.current_sub
  for_each            = var.fws_ssh_public_keys != {} ? var.fws_ssh_public_keys : {}
  name                = "IS${var.shortlocation}${each.value.ssh_public_key_name}SSHKEY01"
  resource_group_name = "IS${var.shortlocation}${each.value.ssh_public_key_rg_name}"
}

data "azurerm_log_analytics_workspace" "hub_law" {
    provider            = azurerm.current_sub
    for_each            = var.hub_law != {} ? var.hub_law : {}
    name                = "IS${var.shortlocation}${var.subscription_identifier}-${var.shortlocation}-${each.value.law_name}"
    resource_group_name = "IS${var.shortlocation}${each.value.law_rg}"
}

data "azurerm_resource_group" "hub_ntw_watcher_rg" {
  provider  = azurerm.current_sub
  for_each  = var.hub_ntw_watcher_rg != {} ? var.hub_ntw_watcher_rg : {}
  name      = each.value.ntw_watcher_rg_name 
}