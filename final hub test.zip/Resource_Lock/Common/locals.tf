locals {  
  ###----------------------------------------- Resource Lock ------------------------------------------
  resource_ids_map = merge(
    { for key, rs in data.azurerm_public_ip.hub_public_ips : key =>  rs.id },
    { for key, rs in data.azurerm_public_ip.int_fw_public_ip : key => rs.id },
    { for key, rs in data.azurerm_key_vault.hub_keyvaults : key => rs.id },
    { for key, rs in data.azurerm_nat_gateway.hub_nat_gateways : key => rs.id },
    { for key, rs in data.azurerm_virtual_network_gateway.hub_vpn_gateways : key => rs.id },
    { for key, rs in data.azurerm_storage_account.hub_storage_accounts : key => rs.id },
    { for key, rs in data.azurerm_storage_account.fws_storage_accounts : key => rs.id },
    { for key, rs in data.azurerm_private_endpoint_connection.kv_private_endpoints : key => rs.id },
    { for key, rs in data.azapi_resource.hub_mc_vnet_gateways : key => rs.id },
    { for key, rs in data.azurerm_ssh_public_key.zslr_ssh_public_key : key => rs.id },
    { for key, rs in data.azurerm_ssh_public_key.fws_ssh_public_keys : key => rs.id },
    { for key, rs in data.azurerm_log_analytics_workspace.hub_law : key => rs.id }
  )
  ###-------------------------------------- Resource Group Lock ----------------------------------------
  resource_group_ids_map = merge(
    { for key, rg in data.azurerm_resource_group.hub_ntw_watcher_rg : key => rg.id }
  )
}