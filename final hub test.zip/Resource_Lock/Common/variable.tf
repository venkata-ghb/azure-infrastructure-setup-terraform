variable "sa_subscription_id" {
  type = string
}

variable "subscription_id" {
  type = string
}

variable "shortlocation" {
  type = string
}
### ------------------------ Azure Policy for REsource Lock -------------------------------------
variable "policy_resource_lock" {
    type = map(object({
    policy_name = string
    display_name = string
    policy_mode = string
    policy_description = string
    assignment_name = string
  }))
  description = "Resource lock details to be applied at the resource level."
}

variable "policy_resource_group_lock" {
  type = map(object({
    policy_name = string
    display_name = string
    policy_mode = string
    policy_description = string
    assignment_name = string
  }))
  description = "Resource lock details to be applied at the resource group level."
}

variable "enforce" {
  description = "(Optional) Specifies if this Policy should be enforced or not? Defaults to true."
  type = bool
}

variable "hub_public_ips" {
  description = "Specify the public ips from SWC HUB Subscription"
  type =  map(object({
    public_ip_names = string
    public_ip_rg_name = string
  }))
}

variable "int_fw_public_ip" {
  description = "Specify the public ips from SWC HUB Subscription"
  type =  map(object({
    public_ip_names = string
    public_ip_rg_name = string
  }))
}

variable "hub_keyvaults" {
  description = "Specify the Keyvaults from HUB Subscription"
  type =  map(object({
    key_vault_name = string
    kv_rg_name = string
  }))
}

variable "hub_nat_gateways" {
  description = "Specify the Nat Gateways from HUB Subscription"
  type =  map(object({
    nat_gateway_name = string
    nat_gateway_rg_name = string
  }))
}

variable "hub_vpn_gateways" {
  description = "Specify the Virtual Network Gateways from HUB Subscription"
  type =  map(object({
    vpn_gateway_name = string
    vpn_gateway_rg_name = string
  }))
}

variable "hub_storage_accounts" {
  description = "Specify the Storage Accounts from HUB Subscription"
  type =  map(object({
    sta_name = string
    sta_rg_name = string
  }))
}

variable "fws_storage_accounts" {
  description = "Specify the Storage Accounts from HUB Subscription"
  type =  map(object({
    sta_name = string
    sta_rg_name = string
  }))
}
variable "kv_private_endpoints" {
  description = "Specify the Private Endpoints from HUB Subscription"
  type =  map(object({
    pe_name = string
    pe_rg_name = string
  }))
}

variable "hub_vnetgw_mc" {
  description = "The name of the Maintenance Configuration of Virtual Network Gateway from HUB Subscription"
  type =  map(object({
    vnetgw_mc_name = string
  }))
}

variable "mc_rg_name" {
description = "The name of Resource Group of Virtual Network Gatetway Maintenance Configuration"
type = string
}

variable "zslr_ssh_public_keys" {
  description = "Specify the SSH Public Key from HUB Subscription"
  type =  map(object({
    ssh_public_key_name    = string
    ssh_public_key_rg_name = string
  }))
}

variable "fws_ssh_public_keys" {
  description = "Specify the SSH Public Key for Checkpoint Firewall from HUB Subscription"
  type =  map(object({
    ssh_public_key_name    = string
    ssh_public_key_rg_name = string
  }))
}

variable "hub_law" {
  description = "Specifies the HUB Log analytics workspace name"
  type = map(object({
    law_name  = string
    law_rg    = string
  }))
}

variable "hub_ntw_watcher_rg" {
description = "Specifies the Network Watcher Resource Group"
  type = map(object({
    ntw_watcher_rg_name  = string
  }))
}
variable "subscription_identifier" {
  type = string
}