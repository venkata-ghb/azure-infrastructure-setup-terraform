### --------------------------- Azure Policy for Resource Lock --------------------------------
module "policies_resource_lock" {
  providers = {
      azurerm = azurerm.current_sub
    }
    for_each             = var.policy_resource_lock
    source               = "../../Terraform_Modules/AzurePolicies/ResourceLockResourceLevel"
    policy_name          = each.value.policy_name
    display_name         = each.value.display_name
    policy_mode          = each.value.policy_mode
    policy_description   = each.value.policy_description
    assignment_name      = each.value.assignment_name
    enforce              = var.enforce
    resource_ids         = local.resource_ids_map
 }

module "policies_resource_group_lock" {
  providers = {
       azurerm = azurerm.current_sub
     }
     for_each             = var.policy_resource_group_lock
     source               = "../../Terraform_Modules/AzurePolicies/ResourceLockRGLevel"
     policy_name          = each.value.policy_name
     display_name         = each.value.display_name
     policy_mode          = each.value.policy_mode
     policy_description   = each.value.policy_description
     assignment_name      = each.value.assignment_name
     enforce              = var.enforce
     resource_group_ids   = local.resource_group_ids_map
}