variable "location" {
  type = string
}

variable "sa_subscription_id" {
  type = string
}

variable "subscription_id" {
  type = string
}

variable "shortlocation" {
  type = string
}

##----------------------------------------Data & Provider Variables-----------------------------------------
variable "mngd_shortlocation" {
  description = "Existing Managed identity short location"
  type = string
}

variable "law_shortlocation" {
  description = "Existing Log analaytics workspace short location"
  type = string
}
variable "ddos_shortlocation" {
  description = "Existing DDoS short location"
  type = string
}
variable "existing_ddos_name" {
  type = string
}
variable "existing_ddos_rg" {
  type = string
}
variable "kv_shortlocation" {
  description = "Existing key vault short location"
  type = string
}

variable "cc_vm_managed_identity_name" {
  type = string
}

variable "cc_vm_managed_identity_rg" {
  type = string
}

variable "managed_subscription_id" {
   type = string
}

variable "act_grp_rg" {
  type = string
}

variable "act_grp_name" {
  type = string
}

variable "actgrp_subscription_id" {
  type = string
}

variable "kv_name" {
  type = string
}

variable "kv_resource_group_name" {
  type = string
}

variable "ddos_id" {
  type = string
}

variable "law_subscription_id" {
  type = string
}
variable "law_name" {
  type = string
}
variable "law_rg" {
  type = string
}
variable "send_logs_to_global" {
  type = bool
}
variable "send_logs_to_local" {
  type = bool
}
variable "subscription_identifier" {
  type = string
}
###-------------------------------------------- Resource Groups ---------------------------------------

variable "resource_groups"{}
variable "cc_resource_groups"{}
variable "mgt_resource_groups" {}
variable "rg_ntw_watch" {}

variable "rg_tags" {}
variable "cc_rg_tags" {}
variable "mgt_rg_tags" {}
variable "ntw_watch_tags" {}
# #---------------------------------------Network Watcher----------------------------------------
 variable "network_watchers" {}
# #---------------------------------------------- Vnets -------------------------------------------

variable "vnets" {}

# #-------------------------------------------- Subnets -----------------------------------------

 variable "subnets"{}

#---------------------------------------NSG/NSG Subnet Association/NSG Rules--------------------------------------

variable "nsgs"{}
variable "nsg_rules_static" {}
variable "glb_nsg_rules_fw" {}
variable "int_nsg_rules_fw" {}

# #-------------------------------- Route table, Subnet Associations, Routes---------------------------------------

variable "route_table_names" {}

variable "RouteTableSubnetAssociations" {}

#---------------------------------------Virtual Network Gateway------------------------------------

variable "vpn_gateways" {}
variable "mc_vnet_gateways" {}
variable "public_ip_address_name_ids" {}
# #------------------------------------------ Public IP -----------------------------------------
variable "public_ips_cc" {}

#-----------------------------------NAT Gateway------------------------------------

variable "nat_gateways_cc" {} 

variable "natgw_pip_association_cc" {}

variable "natgw_snet_association_cc" {}

#---------------------------------------- Log Analytical Workspace --------------------------------

variable "create_local_law" {
  type = bool
}
variable "law_name_local" {
  type = string
  default = ""
}
variable "resource_group_name_local" {
  type          = string
  default = ""
}
variable "law_sku_local" {
  type          = string
  default = ""
}
variable "law_retention_in_days_local" {
  type          = number
  default = 0
}
variable "law_tags" {
  type          = map(string)
  default = {  
  }
}
variable "daily_quota_gb_local" {
  type = number
  default = 0
}
##----------------------------------------Load Balancer -----------------------------------------------

variable "lbs_cc" {}

variable "bp_details_cc" {
  description = "(Required) The backend pool address details. Changing this forces a new resource to be created."
  type        = map(object({
    virtual_network_id = string
  }))
}

variable "lb_probe_details_cc" {
  description = "(Required) The backend pool address details. Changing this forces a new resource to be created."
  type        = map(object({
    protocol = string
    port = string
    path = string
  }))
}

variable "lb_rule_details_cc" {
  description = "(Required) The backend pool address details. Changing this forces a new resource to be created."
  type        = map(object({
    protocol = string
    frontend_port = string
    backend_port = string
    fe_ipconfig_name = string
    bp_name = string
    idle_timeout_in_minutes = number
    probe_name = string
    enable_floating_ip = bool
    disable_outbound_snat = bool
    load_distribution = string

  }))
}

variable "frontend_ip_details_cc" {
type = list(object({
    fe_name= string
    private_ip_address =string
  }))
}

variable "interval_in_seconds_cc" {
  description = "The interval in seconds for how frequently to probe the endpoint for health status."
  type 		  = number
}

variable "lb_sku" {
  description = "Specifies the type of the Load Balancer"
  type        = string
}

variable "lb_sku_tier" {
  description = " (Optional) sku_tier - (Optional) The SKU tier of this Load Balancer. Possible values are Global and Regional. Defaults to Regional. Changing this forces a new resource to be created."
  type 		  = string
}


variable "private_ip_allocation" {
  description = "The allocation method for the Private IP Address used by this Load Balancer. Possible values as Dynamic and Static."
  type 		  = string
}


variable "private_ip_address_version" {
  description = "(Optional) The version of IP that the Private IP Address is. Possible values are IPv4 or IPv6."
  type 		  = string
}
variable "availability_zone"{ 
  description = "(Optional) Specifies a list of Availability Zones in which the IP Address for this Load Balancer should be located." 
  type 		  = list(string)
}

##------------------------------------TSL Key------------------------------------

variable "tls_key_algorithm" {
  type = string
}
#------------------------------------------- NSG - Subnet Association ------------------------------
variable "nsg_snet_association" {}

##-------------------------------------------- CHT alerts -----------------------------------
variable "cht_alerts" {}

###-------------------------------------------- Diagnostic settings ------------------------------
variable "diag_settings" {}
variable "enable_logs" {
  type = bool
  description = "enable logs for the diagnostic settings"
}

variable "enabled_metric" {
  type = bool
}

###----------------------------------------- Vnet Flow logs ----------------------------------------
variable "flow_logs_vnet" {}
variable "vfl_enabled" {}
variable "vfl_traffic_analytics_enabled" {}
variable "vfl_flow_log_version" {}
variable "vfl_retention_days" {}
variable "vfl_interval_in_minutes" {}
variable "vfl_send_logs_to_local" {
  type = bool
}
variable "workspace_location" {
  type = string
}
# #-------------------------------------------- Azure Policy---------------------------------
variable "policies" {}

variable "policy_management_group_id" {
  type = string
}

variable "mgshortlocation" {
  type = string
} 
variable "policies_sta_kv_nsg" {}
variable "policies_activity_max3owner" {}

variable "enforce" {
  description = "(Optional) Specifies if this Policy should be enforced or not? Defaults to true."
  type = bool
}

variable "enforce_01" {
  description = "(Optional) Specifies if this Policy should be enforced or not? Defaults to true."
  type = bool
}
variable "effect" {
  type = string
}

variable "effect_01" {
  type = string
}

#---------------------------------- Public SSH KEY------------------------------------
variable "ssh_rg_name" {
  type = string
}
 
variable "ssh_key_name" {
  type = string
}

# #---------------------------------- KV - Private KEY -------------------------------------

variable "kv_secret" {}

#--------------------------------------- Storage Account ----------------------------

variable "storage_accounts_hub" {}

variable "container_delete_retention_days" {
  default = null
  description = "(Optional) Specifies the number of days that the container should be retained, between 1 and 365 days. Defaults to 7."
  type        = number
}
variable "min_tls_version" {
  description = "The minimum supported TLS version for the storage account. Possible values are TLS1_0, TLS1_1, and TLS1_2. Defaults to TLS1_2 for new storage accounts."
  type        = string
}

# ##---------------------------------------Role Assignemnt------------------------------------
variable "role_assign_user" {
  description = "The role assignment details include scope and role definition name"
  type        = map(object({
    role_definition_name = string
    principal_id = string
  }))
}

variable "role_assign_cc" {
  description = "The role assignment details include scope and role definition name"
  type        = map(object({
    resource_group = string
    role_definition_name = string
  }))
}


##----------------------------------DDoS Protection Plan------------------------------------

variable "ddos_to_create" {
   type = bool
}

variable "ddos_tags" {}

variable "ddos_plan_name" {
  type = string
  default = ""
}

##-------------------------------------- Cloud Connector VMSS---------------------------------------------
variable "cc_vmss" {}

variable "cc_caching" {
  type        = string
  description = "(Required) The type of Caching which should be used for this Data Disk. Possible values are None, ReadOnly and ReadWrite."
}
variable "termination_notification_enabled" {
  type        = bool
  description = "(Required) Should the termination notification be enabled on this Virtual Machine Scale Set? Possible values true or false"
}

variable "termination_notification_timeout" {
  type        = string
  description = "(Optional) Length of time (in minutes, between 5 and 15) a notification to be sent to the VM on the instance metadata server till the VM gets deleted. The time duration should be specified in ISO 8601 format. Defaults to PT5M."
}
variable "fault_domain_count" {
  type = number
}
variable "ccvmss_instance_type" {
  type = string
}
variable "zone_balance" {
  type        = bool
  description = "(Optional) Should the Virtual Machines in this Scale Set be strictly evenly distributed across Availability Zones? Defaults to false. Changing this forces a new resource to be created."
}
 
variable "ccvmss_image_publisher" {
  type        = string
  description = "Azure Marketplace Cloud Connector Image Publisher"
}
 
variable "ccvmss_image_offer" {
  type        = string
  description = "Azure Marketplace Cloud Connector Image Offer"
}
 
variable "ccvmss_image_sku" {
  type        = string
  description = "Azure Marketplace Cloud Connector Image SKU"
}
 
variable "ccvmss_image_version" {
  type        = string
  description = "Azure Marketplace Cloud Connector Image Version"
}
 
variable "ccvmss_source_image_id" {
  type        = string
  description = "Custom Cloud Connector Source Image ID. Set this value to the path of a local subscription Microsoft.Compute image to override the Cloud Connector deployment instead of using the marketplace publisher"
}

variable "cc_encryption_at_host_enabled" {
  type = bool
}

variable "nsg_name_ids" {
  type = map(string)
}
variable "lb_cc_vmss_name" {
  type  = string
  description = "The Load balancer name used for resource creation"
}
variable "cc_username" {
  type        = string
  description = "Default Cloud Connector admin/root username"
}

variable "cc_vm_prov_url" {
  type        = string
  description = "Zscaler Cloud Connector Provisioning URL"
}

variable "azure_vault_url" {
  type        = string
  description = "Azure Vault URL"
}

variable "http_probe_port" {
  type = number
  description = "Port number for Cloud Connector cloud init to enable listener port for HTTP probe from Azure LB"
}

variable "AZURE_MANAGED_IDENTITY_CLIENT_ID" {
  type = string
}

variable "cc_tags" {
type = map(string)
}
variable "storage_account_type" {
    description = "(Required) The Type of Storage Account which should back this Data Disk. Possible values include Standard_LRS, StandardSSD_LRS, StandardSSD_ZRS, Premium_LRS, PremiumV2_LRS, Premium_ZRS and UltraSSD_LRS."
    type = string
}

variable "storage_account_uri" {
  description = "The primary blob endpoint/secondary blob endpoint of the Storage Account"
  type = string
}
# #---------------------------------AutoScale Zscaler VMSS------------------------------------------
variable "zslr_profile_name" {
  description = "Specifies the names of specific vms.Need tobe used only if some vms are tobe selected else its empty set."
  type        = string
}

variable "zslr_min_instance_count" {
  description = "Specifies the storage account type of additional data disk"
  type        = string
}

variable "zslr_max_instance_count" {
  description = "(Required) The method to use when creating the managed disk. Changing this forces a new resource to be created."
  type        = string
}

variable "zslr_default_instance_count" {
  description = "A mapping of tags to al the resources"
  type        = string
}

variable "zslr_autoscale_rules" {
  description = "Specifies the ids of virtual machines and names"
  type        = list(object({
    metric_name = string
    metric_namespace=string
    time_grain = string
    statistic = string
    time_window = string
    time_aggregation = string
    operator = string
    threshold =  number
    direction = string
    instance_change_value = number
    cooldown = string
  }))
}
variable "zslr_autoscales" {}
###-------------------------------Log Profile----------------------------------------
variable "log_profile" {}

variable "categories" {
  type = list(string)
  description = "(Required) List of categories of the logs."
}

variable "retention_policy_enabled" {
  type = bool
  description = "(Required) A boolean value to indicate whether the retention policy is enabled."
}

variable "retention_policy_days" {
  type = number
  description = "(Optional) The number of days for the retention policy. Defaults to 0"
}

###-------------------Checkpoint Variables------------------------------------------------

variable "vmss_name_int"{
   description = "vmss name"
   type = string
}
variable "resource_group_name_int" {
   description = "Azure Resource Group name to build into"
   type = string
}
variable "frontend_subnet_name_int" {
   description = "Frontend subnet name"
   type = string
 }

 variable "backend_subnet_name_int" {
   description = "Backend subnet name"
   type = string
 }

 variable "vm_size_int" {
   description = "Specifies size of Virtual Machine"
   type = string
}
variable "configuration_template_name_int" {
  type = string
}

variable "deployment_mode_int" {
  type = string
}

variable "admin_username" {
  description = "Administrator username of deployed VM. Due to Azure limitations 'notused' name can be used"
  default = "notused"
  sensitive = true
}

variable "admin_password" {
  description = "Administrator password of deployed Virtual Machine. The password must meet the complexity requirements of Azure"
  type = string
  sensitive = true
}
variable "sic_key" {
  description = "Secure Internal Communication(SIC) key"
  type = string
}
variable "resource_group_name_glb" {
   description = "Azure Resource Group name to build into"
   type = string
}

variable "vmss_name_glb"{
   description = "vmss name"
   type = string
}

variable "vnet_name" {
   description = "Virtual Network name"
   type = string
}

variable "frontend_subnet_name_glb" {
   description = "Frontend subnet name"
   type = string
 }

 variable "backend_subnet_name_glb" {
   description = "Backend subnet name"
   type = string
 }

variable "vnet_resource_group" {
   description = "Resource group of existing vnet"
   type = string
}

variable "backend_lb_IP_address" {
   description = "The IP address is defined by its position in the subnet"
   type = number
}
variable "vm_size_glb" {
   description = "Specifies size of Virtual Machine"
   type = string
}
 variable "vm_os_offer" {
   description = "The name of the offer of the image that you want to deploy.Choose from:  check-point-cg-r8110, check-point-cg-r8120, check-point-cg-r82"
   type = string
}

 variable "vm_os_sku" {
   description = "The sku of the image to be deployed."
   type = string
 }

 variable "os_version" {
   description = "GAIA OS version"
   type = string
}
variable "disk_size" {
   description = "Storage data disk size size(GB). Select a number between 100 and 3995, if you are using R81.20 or below, the disk size must be 100"
   type = string
}
variable "bootstrap_script"{
  description = "An optional script to run on the initial boot"
  type = string
}
variable "allow_upload_download" {
  description = "Automatically download Blade Contracts and other important data. Improve product experience by sending data to Check Point"
  type = bool
}
variable "authentication_type" {
   description = "Specifies whether a password authentication or SSH Public Key authentication should be used"
   type = string
}

 variable "availability_zones_num" {
   description = "The number of availability zones to use for Scale Set. Note that the load balancers and their IP addresses will be redundant in any case"
   type = list(string)
 }

 variable "minimum_number_of_vm_instances" {
   description = "Minimum number of VM instances to deploy"
   type = string
 }

 variable "maximum_number_of_vm_instances" {
   description = "Maximum number of VM instances to deploy"
   type = string
}
 variable "management_name" {
   description = "The name of the management server as it appears in the configuration file"
   type = string
}

 variable "management_IP" {
   description = "The IP address used to manage the VMSS instances"
   type = string
}

 variable "management_interface" {
   description = "Manage the Gateways in the Scale Set via the instance's external (eth0) or internal (eth1) NIC's private IP address"
   type = string
}
variable "configuration_template_name_glb" {
  type = string
}
variable "notification_email" {
   description = "Specifies a list of custom email addresses to which the email notifications will be sent"
   type = string
}

variable "enable_custom_metrics" {
   description = "Enable CloudGuard metrics in order to send statuses and statistics collected from VMSS instances to the Azure Monitor service."
   type = bool
}

variable "enable_floating_ip" {
   description = "Enable CloudGuard metrics in order to send statuses and statistics collected from VMSS instances to the Azure Monitor service."
   type = bool
}

variable "add_storage_account_ip_rules" {
   type = bool
   description = "Add Storage Account IP rules that allow access to the Serial Console only for IPs based on their geographic location"
}

variable "storage_account_additional_ips" {
   type = list(string)
   description = "IPs/CIDRs that are allowed access to the Storage Account"
}

variable "frontend_load_distribution" {
   description = "Specifies the load balancing distribution type to be used by the frontend load balancer"
   type = string
}

variable "backend_load_distribution" {
   description = "Specifies the load balancing distribution type to be used by the backend load balancer"
   type = string
}

variable "admin_shell" {
   description = "The admin shell to configure on machine or the first time"
   type = string
}
variable "deployment_mode_glb" {
  type = string
}
variable "serial_console_password_hash" {
  description = "Optional parameter, used to enable serial console connection in case of SSH key as authentication type"
  type = string
}
variable "maintenance_mode_password_hash" {
   description = "Maintenance mode password hash, relevant only for R81.20 and higher versions"
   type = string
}
variable "nsg_id" {
  type = string
}
variable "source_image_vhd_uri" {
  type = string
}
variable "template_name"{
  description = "Template name. Should be defined according to deployment type(ha, vmss)"
  type = string
}

variable "template_version"{
  description = "Template version. It is recommended to always use the latest template version"
  type = string
}

variable "template_type"{
  description = "Template name. Should be defined according to deployment type(ha, vmss)"
  type = string
}
variable "publisher" {
  description = "CheckPoint publisher"
}
variable "is_blink" {
  description = "Define if blink image is used for deployment"
}
variable "installation_type"{
  description = "Installation type"
  type = string
}
variable "admin_username_checkpoint" {
  description = "Administrator username of deployed VM. Due to Azure limitations 'notused' name can be used"
}
variable "vnet_allocation_method" {
  description = "IP address allocation method"
  type = string
}
variable "number_of_vm_instances"{
  description = "Default number of VM instances to deploy"
  type = string
}
variable "vm_os_version" {
  type = string
}

variable "delete_retention_days_vmss" {
  description = "(Optional) Specifies the number of days that the container should be retained, between 1 and 365 days. Defaults to 7."
  type        = number
}

variable "container_delete_retention_days_vmss" {
  default = null
  description = "(Optional) Specifies the number of days that the container should be retained, between 1 and 365 days. Defaults to 7."
  type        = number
}
variable "versioning_enabled_vmss" {
  description = "Specifies if the versioning enabled or not.Default to false"
  type        = bool
}
variable "access_tier_vmss" {
  description = "Specifies the tier to use for the storage account. Valid options are Hot, Cool, Cold and Archive."
  type        = string
}
#------------------------------------- Lifecycle Management of Storage Account-----------------------
variable "storage_accounts_hub_lcm" {}
variable "mgt_pol_glb_rule_name" {
  description = "(Required) The name of the rule. Rule name is case-sensitive. It must be unique within a policy."
  type        = string
}
variable "mgt_pol_int_rule_name" {
  description = "(Required) The name of the rule. Rule name is case-sensitive. It must be unique within a policy."
  type        = string
}
variable "blob_types" {
  description = "(Required) Boolean to specify whether the rule is enabled."
  type        = list(string)
}
variable "delete_after_days_since_modification_greater_than" {
  description = "(Optional) The age in days after last modification to delete the blob. Must be between 0 and 99999. Defaults to -1"
  type        = number
}
variable "rule_enabled" {
  description = "(Required) Boolean to specify whether the rule is enabled."
  type        = bool
}
variable "prefix_match_hub_sta" {
  type = list(string)
}
# ##---------------------------------------Role Assignemnt------------------------------------
variable "role_definition_name" {
  type        = string
  description = "(Optional) The name of a built-in Role. Changing this forces a new resource to be created."
}

##--------------------- Variables for checkpoint --------------------------

variable "sta_fw_bypass" {
  type = list(string)
  description = "(Optional) Specifies whether traffic is bypassed for Logging/Metrics/AzureServices. Valid options are any combination of Logging, Metrics, AzureServices, or None. Defaults to AzureServices."

}

variable "sta_fw_infrastructure_encryption_enabled" {
  description = "Specifies if the infrastructure encryption enabled or not.Changing this forces a new resource to be created. Defaults to false."
  type        = bool
  default     = null
}

variable "sta_fw_encryption_at_host_enabled" {
  description = "(Optional) Should all of the disks (including the temp disk) attached to this Virtual Machine be encrypted by enabling Encryption at Host?"
  type = bool
}

variable "sta_fw_allow_blob_public_access" {
  type = bool
  description = "(Optional) Allow or disallow nested items within this Account to opt into being public. Defaults to true"
}

variable "sta_fw_shared_access_key_enabled" {
  type = bool
  description = "(Optional) Indicates whether the storage account permits requests to be authorized with the account access key via Shared Key. If false, then all requests, including shared access signatures, must be authorized with Azure Active Directory (Azure AD). Defaults to true."
}

variable "pip_fw_ddos_protection_mode" {
  description = "(Optional) The DDoS protection mode of the public IP. Possible values are Disabled, Enabled, and VirtualNetworkInherited. Defaults to VirtualNetworkInherited."
  type = string
}

variable "fw_tags" {
  description = "Tags to be applied to load balancer"
  type        = map(string)
}

###---------------------------------- Key Vault ----------------------------------------------
variable "keyvault_fw" {}

variable "kv_sku_name" {
  type  = string
  description = "(Required) The Name of the SKU used for this Key Vault. Possible values are standard and premium."
}

variable "kv_enabled_for_deployment" {
  description = "(Optional) Boolean flag to specify whether Azure Virtual Machines are permitted to retrieve certificates stored as secrets from the key vault. defaults to false."
  type        = bool
}

variable "kv_enabled_for_disk_encryption" {
  description = "(Optional) Boolean flag to specify whether Azure Disk Encryption is permitted to retrieve secrets from the vault and unwrap keys. Defaults to false."
  type        = bool
}

variable "kv_enabled_for_template_deployment" {
  description = "(Optional) Boolean flag to specify whether Azure Resource Manager is permitted to retrieve secrets from the key vault. Defaults to false."
  type        = bool
}

variable "kv_purge_protection_enabled" {
  description = "(Optional) Is Purge Protection enabled for this Key Vault? Defaults to false. Once Purge Protection has been Enabled it's not possible to Disable it."
  type        = bool
}

variable "kv_soft_delete_retention_days" {
  description = "(Optional) The number of days that items should be retained for once soft-deleted. This value can be between 7 and 90 (the Default) days."
  type        = number
}

variable "kv_enable_rbac_authorization" {
  description = "(Optional) Boolean flag to specify whether Azure Key Vault uses Role Based Access Control (RBAC) for authorization of data actions. Defaults to false."
  type        = bool
}

variable "kv_default_action" {
  type = string
  description = "(Required) The Default Action to use when no rules match from ip_rules / virtual_network_subnet_ids. Possible values are Allow and Deny."
}

variable "kv_ip_rules" {
  type = list(string)
  description = " (Optional) One or more IP Addresses, or CIDR Blocks which should be able to access the Key Vault."
}

variable "kv_bypass" {
  type = string
  description = "(Required) Specifies which traffic can bypass the network rules. Possible values are AzureServices and None"
}

variable "kv_public_network_access_enabled" {
  description = "(Optional) Whether public network access is allowed for this Key Vault. Defaults to true."
  type = bool
}

variable "kv_firewall_enabled" {
  description = "Enable the keyvault firewalls including vnet rules and private endpoints."
  type        = bool
}

variable "workspace_rs_id" {
  description = "(Optional) Specifies the ID of a Log Analytics Workspace where Diagnostics Data should be sent."
  type        = string
}
 
variable "keyvault_diag_glb" {}
variable "keyvault_diag_int" {}

####-----------------------------------Private Endpoint-----------------------------------------------
variable "pvt_endpoints" {}
variable "dns_shortlocation" {
  type = string
}
variable "private_dns_zone_subscription_id" {
  type = string
}
variable "private_dns_zone_rgName" {
  type = string
}
variable "kv_dns_zone_name" {
  type = string
}
#----------------------------------- Public SSH key ------------------------------------
variable "ssh_key_name_glb" {
  description = "The name of the SSH key for GLB FW"
  type        = string
}

variable "ssh_key_name_int" {
  description = "The name of the SSH key for INT FW"
  type        = string
}


# ##---------------------------------------Role Assignemnt------------------------------------
variable "kv_role_definition_names" {
  type        = set(string)
  description = "(Optional) The names of a built-in Role. Changing this forces a new resource to be created."
}

#self hosted vm network details
variable "iac_vnet_name" {
  type = string
}
variable "iac_vnet_rg" {
  type = string
}
variable "iac_subnet_name" {
  type = string
}

variable "iac_shortlocation" {
  description = "Existing IAC subscription short location"
  type = string
}

variable "swc_iac_subscription_id" {
  type = string
}