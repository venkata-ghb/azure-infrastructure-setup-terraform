data "azurerm_user_assigned_identity" "selected" {
  provider            = azurerm.mngd_id
  name                = "IS${var.mngd_shortlocation}${var.cc_vm_managed_identity_name}"
  resource_group_name = "IS${var.mngd_shortlocation}${var.cc_vm_managed_identity_rg}"
}

data "azurerm_monitor_action_group" "act_grp" {
  provider            = azurerm.actgrp_id
  name                = lower(var.act_grp_name)
  resource_group_name = var.act_grp_rg
}

data "azurerm_key_vault" "keyvault" {
  provider            = azurerm.mngd_id
  name                = "is${lower(var.kv_shortlocation)}-${var.kv_name}" 
  resource_group_name = "IS${var.kv_shortlocation}${var.kv_resource_group_name}"
}

data "azurerm_network_ddos_protection_plan" "existing" {
  provider = azurerm.ddos_id
  count = var.ddos_to_create == true ? 0 : 1
  name = "ABBIS${var.ddos_shortlocation}${var.existing_ddos_name}"
  resource_group_name = "IS${var.ddos_shortlocation}${var.existing_ddos_rg}"
}

data "azurerm_log_analytics_workspace" "global" {
  for_each = var.send_logs_to_global && var.law_name != "" ? { "global" = var.law_name } : {}
  provider            = azurerm.law_id
  name                = "IS${var.law_shortlocation}HUB01-${var.law_shortlocation}-${var.law_name}"
  resource_group_name = "is${lower(var.law_shortlocation)}${var.law_rg}"
}

data "azurerm_client_config" "current" {}

data "azurerm_subnet" "swc_iac_subnet" {
    provider             = azurerm.swc_iac_sub_id
    name                 = "${var.iac_shortlocation}-${var.iac_subnet_name}"
    virtual_network_name = "${var.iac_shortlocation}-${var.iac_vnet_name}"
    resource_group_name  = "IS${var.iac_shortlocation}${var.iac_vnet_rg}"
}