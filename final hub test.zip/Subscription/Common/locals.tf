locals {
  userdata = <<USERDATA
[ZSCALER]
CC_URL=${var.cc_vm_prov_url}
AZURE_VAULT_URL=${var.azure_vault_url}
HTTP_PROBE_PORT=${var.http_probe_port}
AZURE_MANAGED_IDENTITY_CLIENT_ID=${var.AZURE_MANAGED_IDENTITY_CLIENT_ID}
USERDATA

#####-----------------------------NSG rules ---------------------------------------
subnet_prefix      = { for k, s in module.snet : k => s.subnet_address_prefix }
vnet_address_space = { for key, vnet in var.vnets: key => vnet.vnet_address_space[0] }
vnet_subnet_address = merge(local.subnet_prefix, local.vnet_address_space)

nsg_rules_static = {
  for key, nsr in var.nsg_rules_static: key => merge(nsr, {
    nsr_source_address_prefix        = ((nsr.nsr_source_address_prefix != null) && (nsr.nsr_source_address_prefix != "*")) ? (try(local.vnet_subnet_address[nsr.nsr_source_address_prefix], nsr.nsr_source_address_prefix)) : nsr.nsr_source_address_prefix
    nsr_destination_address_prefix   = ((nsr.nsr_destination_address_prefix != null) && (nsr.nsr_destination_address_prefix != "*")) ? (try(local.vnet_subnet_address[nsr.nsr_destination_address_prefix], nsr.nsr_destination_address_prefix)) : nsr.nsr_destination_address_prefix
    nsr_source_address_prefixes      = (nsr.nsr_source_address_prefixes != null) ? (try([local.vnet_subnet_address[nsr.nsr_source_address_prefixes[0]]], nsr.nsr_source_address_prefixes)) : nsr.nsr_source_address_prefixes
    nsr_destination_address_prefixes = (nsr.nsr_destination_address_prefixes != null) ? (try([local.vnet_subnet_address[nsr.nsr_destination_address_prefixes[0]]], nsr.nsr_destination_address_prefixes)) : nsr.nsr_destination_address_prefixes
  })
  }

glb_nsg_rules_fw = {
  for key, nsr in var.glb_nsg_rules_fw: key => merge(nsr, {
    nsr_source_address_prefix        = ((nsr.nsr_source_address_prefix != null) && (nsr.nsr_source_address_prefix != "*")) ? (try(local.vnet_subnet_address[nsr.nsr_source_address_prefix], nsr.nsr_source_address_prefix)) : nsr.nsr_source_address_prefix
    nsr_destination_address_prefix   = ((nsr.nsr_destination_address_prefix != null) && (nsr.nsr_destination_address_prefix != "*")) ? (try(local.vnet_subnet_address[nsr.nsr_destination_address_prefix], nsr.nsr_destination_address_prefix)) : nsr.nsr_destination_address_prefix
    nsr_source_address_prefixes      = (nsr.nsr_source_address_prefixes != null) ? (try([local.vnet_subnet_address[nsr.nsr_source_address_prefixes[0]]], nsr.nsr_source_address_prefixes)) : nsr.nsr_source_address_prefixes
    nsr_destination_address_prefixes = (nsr.nsr_destination_address_prefixes != null) ? (try([local.vnet_subnet_address[nsr.nsr_destination_address_prefixes[0]]], nsr.nsr_destination_address_prefixes)) : nsr.nsr_destination_address_prefixes
  })
  }

int_nsg_rules_fw = {
  for key, nsr in var.int_nsg_rules_fw: key => merge(nsr, {
    nsr_source_address_prefix        = ((nsr.nsr_source_address_prefix != null) && (nsr.nsr_source_address_prefix != "*")) ? (try(local.vnet_subnet_address[nsr.nsr_source_address_prefix], nsr.nsr_source_address_prefix)) : nsr.nsr_source_address_prefix
    nsr_destination_address_prefix   = ((nsr.nsr_destination_address_prefix != null) && (nsr.nsr_destination_address_prefix != "*")) ? (try(local.vnet_subnet_address[nsr.nsr_destination_address_prefix], nsr.nsr_destination_address_prefix)) : nsr.nsr_destination_address_prefix
    nsr_source_address_prefixes      = (nsr.nsr_source_address_prefixes != null) ? (try([local.vnet_subnet_address[nsr.nsr_source_address_prefixes[0]]], nsr.nsr_source_address_prefixes)) : nsr.nsr_source_address_prefixes
    nsr_destination_address_prefixes = (nsr.nsr_destination_address_prefixes != null) ? (try([local.vnet_subnet_address[nsr.nsr_destination_address_prefixes[0]]], nsr.nsr_destination_address_prefixes)) : nsr.nsr_destination_address_prefixes
  })
  }
}