#-------------------------------------------- Resource Groups ---------------------------------------
module "rg" {
    providers = {
        azurerm = azurerm.current_sub
    }
        for_each            = var.resource_groups 
        source              = "../../Terraform_Modules/ResourceGroup"
        resource_group_name = "IS${var.shortlocation}${each.value.name}" 
        location            = var.location
        tags                = var.rg_tags
}

####-------------------------------------------- Resource Groups ---------------------------------------
module "rg_cc" {
    providers = {
        azurerm = azurerm.current_sub
    }
        for_each            = var.cc_resource_groups
        source              = "../../Terraform_Modules/ResourceGroup"
        resource_group_name = "IS${var.shortlocation}${each.value.name}" 
        location            = var.location
        tags                = merge(var.cc_rg_tags, each.value.tags)
}

###-------------------------------------------- Resource Groups ---------------------------------------
module "rg_mgt" {
    providers = {
        azurerm = azurerm.current_sub
    }
        for_each            = var.mgt_resource_groups
        source              = "../../Terraform_Modules/ResourceGroup"
        resource_group_name = "IS${var.shortlocation}${each.value.name}" 
        location            = var.location
        tags                = var.mgt_rg_tags 
}

#--------------------------------------------Ntw watcher Resource Groups ---------------------------------------

module "rg_ntw_watch" {
    providers = {
        azurerm = azurerm.current_sub
    }
        for_each            = var.rg_ntw_watch
        source              = "../../Terraform_Modules/ResourceGroup"
        resource_group_name = each.value.name
        location            = var.location
        tags                = var.ntw_watch_tags 
}
#---------------------------------------Network Watcher----------------------------------------

module "network_watcher" {
  providers = {
        azurerm = azurerm.current_sub
    }
    for_each                    = var.network_watchers
    source                      = "../../Terraform_Modules/NetworkWatcher"
    nwr_name                    = "${each.value.nwr_name}_${var.location}" 
    location                    = var.location
    resource_group_name         = module.rg_ntw_watch[each.value.resource_group].rg_name
    tags_NWR                    = var.ntw_watch_tags
    depends_on                  = [ module.rg_ntw_watch ]
}      
#------------------------------------------Virtual Network ---------------------------------------------
module "vnet" {
    providers = {
        azurerm = azurerm.current_sub
    }
        for_each = var.vnets
        source   =  "../../Terraform_Modules/VirtualNetwork"
        vnt_name            = "${var.shortlocation}-${each.value.vnet_name}"
        location            = var.location
        resource_group_name = module.rg[each.value.resource_group].rg_name
        vnt_address_space   = each.value.vnet_address_space
        dns_servers                   = each.value.dns_servers
        ddos_protection_plan_enabled  = each.value.ddos_protection_plan_enabled
        ddos_protection_plan_id       = var.ddos_to_create ? module.DDoS.ddos_plan_id : try(data.azurerm_network_ddos_protection_plan.existing[0].id, null)
        tags            	  = merge(var.rg_tags, each.value.vnet_tags)    
        depends_on          = [ module.rg, module.network_watcher,module.DDoS ] 
}

#-------------------------------------------- Subnets ---------------------------------------------
module "snet"{
    providers = {
        azurerm = azurerm.current_sub
    }
        for_each = var.subnets
        source   = "../../Terraform_Modules/Subnet"
        snt_name               = each.value.snet_name == "GatewaySubnet" ? each.value.snet_name : "${var.shortlocation}-${each.value.snet_name}"
        resource_group_name    = module.rg[each.value.resource_group].rg_name
        vnt_name               = module.vnet[each.value.vnet_name].vnet_name
        address_space          = [cidrsubnet(module.vnet[each.value.vnet_name].first_vnet_address_space, each.value.newbits, each.value.netnum)]   
        service_endpoints      = each.value.service_endpoints != [] ? each.value.service_endpoints : null
        depends_on             = [ module.rg, module.vnet ]
}

#------------------------------------------ DDOS Protection Plan ----------------------------------
module "DDoS" {
    providers = {
        azurerm = azurerm.current_sub
    }
        source              = "../../Terraform_Modules/DDosProtectionPlan"
        enabled             = var.ddos_to_create
        ddos_plan_name      = "ABBIS${var.shortlocation}${var.ddos_plan_name}"
        resource_group_name = module.rg["RG_ntw"].rg_name
        location            = var.location
        tags                = merge(var.rg_tags, var.ddos_tags)
        depends_on          = [ module.rg ]
}

##----------------------------------------------NSG---------------------------------------------

module "nsg"{
    providers = {
        azurerm = azurerm.current_sub
    }
        for_each            = var.nsgs
        source              = "../../Terraform_Modules/NSG"
        nsg_name            = "${var.shortlocation}-NSG-${var.shortlocation}-${each.value.nsg_name}"
        resource_group_name = module.rg[each.value.resource_group].rg_name
        location            = var.location
        tags_NSG            = merge(var.rg_tags,each.value.nsg_tags)
        depends_on          = [ module.rg ]
}

#--------------------------------------------NSG Rules-------------------------------------------

module "nsg_rules" {
    providers = {
        azurerm = azurerm.current_sub
    }
   
        for_each                              = local.nsg_rules_static  
        source                                = "../../Terraform_Modules/NsgRule"
        nsr_name                              = each.value.nsr_name
        nsr_resource_group_name               = module.rg[each.value.resource_group].rg_name
        nsr_nsg_name                          = module.nsg[each.value.nsg].nsg_name
        nsr_protocol                          = each.value.nsr_protocol
        nsr_source_port_range                 = each.value.nsr_source_port_range
        nsr_source_port_ranges                = each.value.nsr_source_port_ranges
        nsr_destination_port_range            = each.value.nsr_destination_port_range
        nsr_destination_port_ranges           = each.value.nsr_destination_port_ranges
        nsr_source_address_prefix             = each.value.nsr_source_address_prefix
        nsr_source_address_prefixes           = each.value.nsr_source_address_prefixes
        nsr_destination_address_prefix        = each.value.nsr_destination_address_prefix
        nsr_destination_address_prefixes      = each.value.nsr_destination_address_prefixes
        nsr_priority                          = each.value.nsr_priority
        nsr_direction                         = each.value.nsr_direction
        nsr_access                            = each.value.nsr_access
        depends_on                            = [ module.nsg, module.rg ]
}

module "glb_nsg_rules_fw" {
    providers = {
        azurerm = azurerm.current_sub
    }
   
        for_each                              = local.glb_nsg_rules_fw 
        source                                = "../../Terraform_Modules/NsgRule"
        nsr_name                              = each.value.nsr_name
        nsr_resource_group_name               = module.glb_module.resource_group
        nsr_nsg_name                          = module.glb_module.nsg_name
        nsr_protocol                          = each.value.nsr_protocol
        nsr_source_port_range                 = each.value.nsr_source_port_range
        nsr_source_port_ranges                = each.value.nsr_source_port_ranges
        nsr_destination_port_range            = each.value.nsr_destination_port_range
        nsr_destination_port_ranges           = each.value.nsr_destination_port_ranges
        nsr_source_address_prefix             = each.value.nsr_source_address_prefix
        nsr_source_address_prefixes           = each.value.nsr_source_address_prefixes
        nsr_destination_address_prefix        = each.value.nsr_destination_address_prefix
        nsr_destination_address_prefixes      = each.value.nsr_destination_address_prefixes
        nsr_priority                          = each.value.nsr_priority
        nsr_direction                         = each.value.nsr_direction
        nsr_access                            = each.value.nsr_access
        depends_on                            = [ module.glb_module ]
}  

module "int_nsg_rules_fw" {
    providers = {
        azurerm = azurerm.current_sub
    }
   
        for_each                              = local.int_nsg_rules_fw 
        source                                = "../../Terraform_Modules/NsgRule"
        nsr_name                              = each.value.nsr_name
        nsr_resource_group_name               = module.int_module.resource_group
        nsr_nsg_name                          = module.int_module.nsg_name
        nsr_protocol                          = each.value.nsr_protocol
        nsr_source_port_range                 = each.value.nsr_source_port_range
        nsr_source_port_ranges                = each.value.nsr_source_port_ranges
        nsr_destination_port_range            = each.value.nsr_destination_port_range
        nsr_destination_port_ranges           = each.value.nsr_destination_port_ranges
        nsr_source_address_prefix             = each.value.nsr_source_address_prefix
        nsr_source_address_prefixes           = each.value.nsr_source_address_prefixes
        nsr_destination_address_prefix        = each.value.nsr_destination_address_prefix
        nsr_destination_address_prefixes      = each.value.nsr_destination_address_prefixes
        nsr_priority                          = each.value.nsr_priority
        nsr_direction                         = each.value.nsr_direction
        nsr_access                            = each.value.nsr_access
        depends_on                            = [ module.glb_module ]
}             
#------------------------Route table---------------------------------------

module "route_table" {
  providers = {
      azurerm = azurerm.current_sub
  }
  
    for_each                      = var.route_table_names
    source                        = "../../Terraform_Modules/RouteTable"
    route_table_name              = "${var.shortlocation}-${each.value.name}"
    location                      = var.location
    resource_group_name           = module.rg[each.value.resource_group].rg_name
    tags                          = merge(var.rg_tags,each.value.rt_tags)
    depends_on                    = [ module.rg ]
 
}

#------------------------Route table Association Subnet---------------------------------------

module "rt_association" {
  providers = {
      azurerm = azurerm.current_sub
    }
    for_each                  = var.RouteTableSubnetAssociations
    source                    = "../../Terraform_Modules/RouteTableAssociateSubnet"
    route_table_name_id       = module.route_table[each.value.route_table_name].route_table_id
    subnet_id                 = module.snet[each.value.subnet_name].subnet_id
    depends_on                = [ module.route_table, module.snet ]
}

# # #---------------------------------------Virtual Network Gateway------------------------------------

module "vpn_gateway"{            
  providers = {
      azurerm = azurerm.current_sub
    }
    for_each                         = var.vpn_gateways
    source                           = "../../Terraform_Modules/VirtualNetworkGateway"
    location                         = var.location
    resource_group_name              = module.rg[each.value.resource_group].rg_name
    vnet_gateway_name                = "${var.shortlocation}-${each.value.vnet_gateway_name}"
    vnet_gateway_type                = each.value.vnet_gateway_type
    vpn_type                         = each.value.vpn_type
    enable_active_active             = each.value.vpn_enable_active_active
    enable_bgp                       = each.value.enable_bgp
    vnet_gateway_sku                 = each.value.vnet_gateway_sku
    generation                       = each.value.generation
    vpn_ip_config                    = each.value.vpn_ip_config
    remote_vnet_traffic_enabled      = each.value.remote_vnet_traffic_enabled
    virtual_wan_traffic_enabled      = each.value.virtual_wan_traffic_enabled
    subnet_id                        = module.snet[each.value.subnet_names_ids].subnet_id
    public_ip_address_name_ids       = var.public_ip_address_name_ids
    tags                             = merge(var.rg_tags,each.value.gw_tags)
    depends_on                       = [ module.rg, module.snet, module.load_balancer_cc] 
}
###-------------------Maintainance Configuration Vnet Gateway-----------------------------------

module "mc_vnet_gateway" {
  for_each                   = var.mc_vnet_gateways
  source                     = "../../Terraform_Modules/MaintenanceConfigurationVPNGateway"
  vnetgw-maintenance-config  = "${module.vpn_gateway[each.value.vpn_gateway].vnet_gateway_name}-${each.value.vnetgw-maintenance-config}"
  resource_group_name        = module.rg[each.value.resource_group].rg_name
  location                   = var.location
  scope                      = each.value.scope
  maintenanceSubScope        = each.value.maintenanceSubScope
  subscription_id            = var.subscription_id 
  start_date_time            = each.value.start_date_time
  duration                   = each.value.duration
  time_zone                  = each.value.time_zone
  recur_every                = each.value.recur_every
  tags                       = var.rg_tags
  vng_id                     = module.vpn_gateway[each.value.vpn_gateway].vnet_gateway_id
  vng_maintenace_assign_name = "${module.vpn_gateway[each.value.vpn_gateway].vnet_gateway_name}-${each.value.vng_maintenace_assign_name}"
  depends_on                 = [ module.rg, module.vpn_gateway]
  

}

#----------------------------------------Public IP--------------------------------
module "publicip_cc" {
providers = {
      azurerm = azurerm.current_sub
    }
      for_each                = var.public_ips_cc
      source                  = "../../Terraform_Modules/PublicIPV2"
      public_ip_name          = "${var.shortlocation}-${each.value.public_ip_name}"
      location                = var.location
      rg_name                 = module.rg_cc[each.value.resource_group].rg_name
      public_ip_allocation    = each.value.public_ip_allocation
      sku                     = each.value.sku
      sku_tier                = each.value.sku_tier
      domain_name_label       = each.value.domain_name_label
      idle_timeout_in_minutes = each.value.idle_timeout_in_minutes      
      zones                   = each.value.zones
      tags                    = merge(var.cc_rg_tags,each.value.pip_tags)
      depends_on              = [ module.rg_cc , module.DDoS]
   
}

#-----------------------------------------NAT Gateway ---------------------------------------------
module "nat_gateway_cc" {
providers = {
      azurerm = azurerm.current_sub
    }
    for_each                = var.nat_gateways_cc 
    source                  = "../../Terraform_Modules/NATGateway"
    nat_gateway_name        = "${var.shortlocation}-${each.value.nat_gateway_name}"
    location                = var.location 
    resource_group_name     = module.rg_cc[each.value.resource_group].rg_name
    idle_timeout_in_minutes = each.value.idle_timeout_in_minutes
    zones                   = each.value.zones 
    tags                    = merge(var.cc_rg_tags,each.value.nat_tags)   
    depends_on              = [ module.rg_cc ]                         
}

module "nat_gw_snet_association_cc" {
providers = {
      azurerm = azurerm.current_sub
    }
    for_each       = var.natgw_snet_association_cc 
    source         = "../../Terraform_Modules/NATGatewaySubnetAssociation"
    subnet_id      = module.snet[each.value.subnet_id].subnet_id
    nat_gateway_id = module.nat_gateway_cc[each.value.nat_gw_id].natgw_id
    depends_on          = [ module.snet, module.nat_gateway_cc ]

}

module "nat_gw_pip_association_cc" {
providers = {
      azurerm = azurerm.current_sub
    }
    for_each                = var.natgw_pip_association_cc 
    source                  = "../../Terraform_Modules/NATGatewayPublicIPAssociation"
    public_ip_address_id    = module.publicip_cc[each.value.public_ip_address_id].public_ip_id
    nat_gateway_id          = module.nat_gateway_cc[each.value.nat_gw_id].natgw_id
    depends_on              = [ module.publicip_cc, module.nat_gateway_cc ]
   
}

# #---------------------------------------- Log Analytical Workspace --------------------------------
module "loganalytics_workspace" {
    providers = {
      azurerm = azurerm.current_sub
    }
  source                  = "../../Terraform_Modules/LogAnalyticsWorkspace"
  enabled                 = var.create_local_law
  law_name                = "IS${var.shortlocation}${var.subscription_identifier}-${var.shortlocation}-${var.law_name_local}"
  location                = var.location
  resource_group_name     = "IS${var.shortlocation}${var.resource_group_name_local}"
  law_sku                 = var.law_sku_local
  law_retention_in_days   = var.law_retention_in_days_local
  daily_quota_gb          = var.daily_quota_gb_local
  tags                    = merge(var.mgt_rg_tags,var.law_tags)
  depends_on              = [ module.rg_mgt ]
}

#---------------------------------------- Load Balancer - Cloud Connector --------------------------------
module "load_balancer_cc" {
  providers = {
    azurerm = azurerm.current_sub
  }

    for_each = var.lbs_cc  
    source                     = "../../Terraform_Modules/LoadBalancer"
    lb_name                    = "IS${var.shortlocation}${var.subscription_identifier}-${var.shortlocation}-${each.value.lb_name}"
    location                   = var.location
	  rg_name                    = module.rg_cc[each.value.resource_group].rg_name
	  lb_sku                     = var.lb_sku
    lb_sku_tier                = var.lb_sku_tier
    frontend_ip_details        = var.frontend_ip_details_cc
    subnet_cidr                = element(module.snet[each.value.subnet_name].subnet_address_prefixes, 0)
	  subnet_id                  = module.snet[each.value.subnet_name].subnet_id
	  private_ip_allocation      = var.private_ip_allocation
    private_ip_address_version = var.private_ip_address_version
    availability_zone          = var.availability_zone
    bp_details                 = var.bp_details_cc
	  lb_probe_details           = var.lb_probe_details_cc
	  interval_in_seconds        = var.interval_in_seconds_cc
	  lb_rule_details 	         = var.lb_rule_details_cc
	  tags                       = merge(var.cc_rg_tags,each.value.lb_tags)
    depends_on                 = [ module.snet, module.rg_cc ]

}

# ################################TSL Key######################################
resource "tls_private_key" "key" {
  algorithm = var.tls_key_algorithm
  rsa_bits  = 2048
}

resource "azurerm_ssh_public_key" "public_ssh_key" {
  provider            = azurerm.current_sub
  name                = var.ssh_key_name
  resource_group_name = "IS${var.shortlocation}${var.ssh_rg_name}"
  location            = var.location
  public_key          = tls_private_key.key.public_key_openssh
  tags                = var.cc_rg_tags
  depends_on          = [ module.rg_cc ]
}  

#--------------------------------------- NSG Subnet Association------------------------------------------
module "nsg_snet_association" {
providers = {
      azurerm = azurerm.current_sub
    }
  for_each        = var.nsg_snet_association
  source          = "../../Terraform_Modules/NsgAssociateSubnet"
  network_security_group_id = module.nsg[each.value.nsg_name].nsg_id
  subnet_id                 = module.snet[each.value.subnet_name].subnet_id
  depends_on                = [ module.snet, module.nsg ]
}

##--------------------------------------------CHT Alerts -------------------------------------------

module "cht_alert" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each           = var.cht_alerts
  source = "../../Terraform_Modules/AlertRule"
  alert_name            = each.value.alert_name
  resource_group_name   = module.rg_mgt[each.value.resource_group_name].rg_name
  scope_id              = ["/subscriptions/${var.subscription_id}"]
  location              = each.value.location 
  description           = each.value.description
  tags                  = merge(var.mgt_rg_tags, each.value.alert_tags )
  enabled               = each.value.enabled
  category              = each.value.category
  service_health_events = each.value.service_health_events
  action_group_id       = data.azurerm_monitor_action_group.act_grp.id
  depends_on              = [ module.rg_mgt ]
 }

###------------------------------------ Diagnostic Settings ----------------------------------------
module "diagnostic_settings" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each                = var.diag_settings
  source                  = "../../Terraform_Modules/DiagnosticsSettings"
  dlog_name               = "${var.shortlocation}-${each.value.dlog_name}"
  target_id               = "/subscriptions/${var.subscription_id}"
  storage_acc_id          = each.value.storage_acc_id
  workspace_rs_id         = var.send_logs_to_local && var.create_local_law ? module.loganalytics_workspace.law_id : data.azurerm_log_analytics_workspace.global["global"].id
  depends_on = [ module.loganalytics_workspace ]
}

module "diagnostic_settings_nsg" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each                = var.nsgs
  source                  = "../../Terraform_Modules/DiagnosticsSettingsV2"
  dlog_name               = "${module.nsg[each.key].nsg_name}-Diags"
  target_id               = module.nsg[each.key].nsg_id
  enable_logs             = var.enable_logs
  enabled_metric         = var.enabled_metric
  storage_acc_id          = values(module.storage_account_hub)[0].stgaccount_id
  workspace_rs_id         = var.send_logs_to_local && var.create_local_law ? module.loganalytics_workspace.law_id : data.azurerm_log_analytics_workspace.global["global"].id
  depends_on = [ module.loganalytics_workspace, module.storage_account_hub ]
}

module "diagnostic_settings_pip_cc" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each                = var.public_ips_cc
  source                  = "../../Terraform_Modules/DiagnosticsSettingsV2"
  dlog_name               = "${module.publicip_cc[each.key].public_ip_name}-Diags"
  target_id               = module.publicip_cc[each.key].public_ip_id
  enable_logs             = var.enable_logs
  enabled_metric         = var.enabled_metric
  storage_acc_id          = values(module.storage_account_hub)[0].stgaccount_id
  workspace_rs_id         = var.send_logs_to_local == false && var.create_local_law ? module.loganalytics_workspace.law_id : data.azurerm_log_analytics_workspace.global["global"].id
  depends_on = [ module.loganalytics_workspace, module.storage_account_hub, module.publicip_cc]
}

###----------------------------------------- Vnet Flow logs ----------------------------------------
module "flow_log_vnet" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each              = var.flow_logs_vnet
  source                = "../../Terraform_Modules/VNetFlowLogs"
  network_watcher_name  = module.network_watcher[each.value.network_watcher_name].network_watcher_name
  resource_group_name   = module.rg_ntw_watch[each.value.resource_group].rg_name
  flow_log_name         = "${module.vnet[each.value.vnet].vnet_name}-${lower(module.vnet[each.value.vnet].vnet_rg_name)}-flowlog"
  vnet_id               = module.vnet[each.value.vnet].vnet_id
  sta_id                = module.storage_account_hub[each.value.sta_name].stgaccount_id
  enabled               = var.vfl_enabled
  flow_log_version      = var.vfl_flow_log_version
  retention_days        = var.vfl_retention_days
  traffic_analytics_enabled   = var.vfl_traffic_analytics_enabled
  workspace_id          = var.vfl_send_logs_to_local && var.create_local_law ? module.loganalytics_workspace.workspace_id : data.azurerm_log_analytics_workspace.global["global"].workspace_id
  workspace_location    = var.vfl_send_logs_to_local && var.create_local_law ? var.location : var.workspace_location
  workspace_resource_id = var.vfl_send_logs_to_local && var.create_local_law ? module.loganalytics_workspace.law_id : data.azurerm_log_analytics_workspace.global["global"].id
  interval_in_minutes   = var.vfl_interval_in_minutes
  tags                  = merge(var.ntw_watch_tags, each.value.tags)
  depends_on            = [ module.rg_ntw_watch, module.network_watcher, module.vnet, module.storage_account_hub, module.loganalytics_workspace, module.management_policy_hub ]
}
#----------------------------------------------Azure Policies--------------------------------------

 module "policies_location" {
  for_each             = var.policies
  source               = "../../Terraform_Modules/AzurePolicies/AllowedLocations"
  name                 = each.value.name
  policy_definition_id = each.value.policy_definition_id
  management_group_id  = "/providers/Microsoft.Management/managementGroups/ABB-${var.mgshortlocation}-${var.policy_management_group_id}"
  description          = "Allowed location for primary: ${var.location}"
  enforce              = var.enforce
  allowed_location     = [ var.location ]
}

 module "policies_sta_kv_nsg" {
  for_each             = var.policies_sta_kv_nsg
  source               = "../../Terraform_Modules/AzurePolicies/StorageAccountCMKencrypt"
  name                 = each.value.name
  policy_definition_id = each.value.policy_definition_id
  management_group_id  = "/providers/Microsoft.Management/managementGroups/ABB-${var.mgshortlocation}-${var.policy_management_group_id}"
  enforce              = var.enforce_01
  effect               = var.effect
}

  module "policies_activity_max3owner" {
  for_each             = var.policies_activity_max3owner
  source               = "../../Terraform_Modules/AzurePolicies/ActivityLogMaximum3Owners"
  name                 = each.value.name
  policy_definition_id = each.value.policy_definition_id
  management_group_id  = "/providers/Microsoft.Management/managementGroups/ABB-${var.mgshortlocation}-${var.policy_management_group_id}"
  enforce              = var.enforce_01
  effect               = var.effect_01
 }

#------------------------------------Key vault secret -----------------------------------
module "key_vault_secret" {
  providers = {
      azurerm = azurerm.mngd_id
    }
    for_each            = var.kv_secret
    source              = "../../Terraform_Modules/KeyVaultSecret"
    secret_name         = "${var.shortlocation}-${each.value.secret_name}"
    secret_value        = tls_private_key.key.private_key_pem     
    kv_id               = data.azurerm_key_vault.keyvault.id
}

#------------------------------------Storage Account -----------------------------------------

module "storage_account_hub" {
  
  providers = {
      azurerm = azurerm.current_sub
    }
    for_each                          = var.storage_accounts_hub
    source                            = "../../Terraform_Modules/StorageAccount"
    resource_group_name               = module.rg_mgt[each.value.resource_group].rg_name
    location                          = var.location
    name                 	            = "abbis${lower(var.shortlocation)}${each.value.sta_name}"
    account_tier                      = each.value.account_tier
    access_tier                       = each.value.access_tier_01
    account_replication_type          = each.value.account_replication_type
    allow_blob_public_access          = each.value.allow_blob_public_access
    public_network_access_enabled     = each.value.public_network_access_enabled
    infrastructure_encryption_enabled = each.value.infrastructure_encryption_enabled
    shared_access_key_enabled         = each.value.shared_access_key_enabled
    cross_tenant_replication_enabled  = each.value.cross_tenant_replication_enabled
    versioning_enabled                = each.value.versioning_enabled
    is_hns_enabled                    = each.value.is_hns_enabled
    delete_retention_days             = each.value.delete_retention_days
    tags 					                    = merge(var.mgt_rg_tags, each.value.tags)
    container_delete_retention_days   = var.container_delete_retention_days
    fs_delete_retention_days          = each.value.fs_delete_retention_days
    large_file_share_enabled          = each.value.large_file_share_enabled
    min_tls_version                   = var.min_tls_version
    depends_on                        = [ module.rg_mgt , module.snet]
}
#------------------------------------Storage Account Rules-----------------------------------------

module "storage_account_rules_hub" {
  providers = {
      azurerm = azurerm.current_sub
    }
    for_each                   = var.storage_accounts_hub
    source                     = "../../Terraform_Modules/StaNetworkRules"
    sta_id                     = module.storage_account_hub[each.key].stgaccount_id
    default_action             = var.add_storage_account_ip_rules ? "Deny" : "Allow"
    ip_rules                   = var.storage_account_additional_ips
    virtual_network_subnet_ids = [for name in each.value.subnet_names : module.snet[name].subnet_id]
    bypass                     = var.sta_fw_bypass
    depends_on                 = [ module.storage_account_hub, module.snet ]
}

###------------------------------------- Lifecycle Management of Storage Account-----------------------
module "management_policy_hub" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each                                          =  var.storage_accounts_hub_lcm
  source                                            = "../../Terraform_Modules/LifecycleManagementPolicy"
  rule_name                                         = "LCM-${module.storage_account_hub[each.value.sta_name].stgaccount_name}"
  rule_enabled                                      = var.rule_enabled
  prefix_match                                      = var.prefix_match_hub_sta
  storage_account_id                                = module.storage_account_hub[each.value.sta_name].stgaccount_id
  blob_types                                        = var.blob_types
  delete_after_days_since_modification_greater_than = var.delete_after_days_since_modification_greater_than
  depends_on                                        = [ module.storage_account_hub ]
}

##-------------------------------Role Assignment----------------------------------------------

module "role_assign" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each        = var.role_assign_user
  source          = "../../Terraform_Modules/RoleAssignment"
  scope           = "/subscriptions/${var.subscription_id}"
  principal_id    = each.value.principal_id
  role_definition_name = each.value.role_definition_name
}


module "role_assign_cc" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each        = var.role_assign_cc
  source          = "../../Terraform_Modules/RoleAssignment"
  scope           = module.rg_cc[each.value.resource_group].rg_id
  principal_id    = data.azurerm_user_assigned_identity.selected.principal_id
  role_definition_name = each.value.role_definition_name
  depends_on = [ module.rg_cc ]
}

# ##-------------------------------------- Cloud Connector VMSS---------------------------------------------

module "cc_vmss" {
providers = {
      azurerm = azurerm.current_sub
    }
  for_each                          = var.cc_vmss
  source                            = "../../Terraform_Modules/ZscalerCloudConnector"
  cc_vmss_name                      = "XC${var.shortlocation}${each.value.cc_vmss_names}"
  location                          = var.location
  resource_group                    = module.rg_cc[each.value.resource_group_name].rg_name
  zones                             = each.value.zones
  nw_interface_details              = each.value.nw_interface_details
  caching                           = var.cc_caching
  ccvmss_source_image_id            = var.ccvmss_source_image_id
  ccvmss_image_sku                  = var.ccvmss_image_sku
  ccvmss_image_offer                = var.ccvmss_image_offer
  ccvmss_image_version              = var.ccvmss_image_version
  ccvmss_image_publisher            = var.ccvmss_image_publisher
  fault_domain_count                = var.fault_domain_count
  ccvmss_instance_type              = var.ccvmss_instance_type
  encryption_at_host_enabled        = var.cc_encryption_at_host_enabled
  zone_balance                      = var.zone_balance 
  termination_notification_enabled  = var.termination_notification_enabled
  termination_notification_timeout  = var.termination_notification_timeout
  subscription_id                   = var.subscription_id
  shortlocation                     = var.shortlocation
  cc_username                       = var.cc_username
  storage_account_type              = var.storage_account_type                         
  storage_account_uri               = var.storage_account_uri
  user_data                         = local.userdata
  resource_group_name_ntw           = module.rg[each.value.resource_group_name_ntw].rg_name
  virtual_network_name              = module.vnet[each.value.vnet_name].vnet_name
  ssh_key                           = azurerm_ssh_public_key.public_ssh_key.public_key 
  managed_identity_id               = data.azurerm_user_assigned_identity.selected.id
  lb_backend_address_pool_ids       = module.load_balancer_cc[var.lb_cc_vmss_name].azlb_backend_pool_id_list
  nsg_name_ids                      = var.nsg_name_ids
  tags                              = merge(var.cc_rg_tags, var.cc_tags)
  depends_on                        = [ module.rg_cc, module.rg, module.vnet, module.load_balancer_cc, azurerm_ssh_public_key.public_ssh_key ]
}


#-----------------------------------------Autoscale Zscaler VMSS----------------------------------------
module "zslr_autoscale" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each                = var.zslr_autoscales
  source                  = "../../Terraform_Modules/Autoscale"
  autoscale_name          = "XC${var.shortlocation}${each.value.autoscale_name}"
  resource_group_name     = module.rg_cc[each.value.resource_group_name].rg_name
  location                = var.location
  target_resource_id      = module.cc_vmss[each.value.zslr_vmss].ccvmss_id
  profile_name            = var.zslr_profile_name
  min_instance_count      = var.zslr_min_instance_count
  max_instance_count      = var.zslr_max_instance_count
  default_instance_count  = var.zslr_default_instance_count
  autoscale_rules         = var.zslr_autoscale_rules
  tags                    =  merge(var.cc_rg_tags, each.value.tags)
  depends_on              = [module.rg_cc, module.cc_vmss]
}

#----------------------------------------Log Profile----------------------------------
module "log_profile" {
  for_each                 = var.log_profile
  source                   = "../../Terraform_Modules/LogProfile"
  log_profile_name         = each.value.log_profile_name
  subscription_id          = var.subscription_id
  location                 = var.location 
  categories               = var.categories
  locations                = [var.location]
  retention_policy_enabled = var.retention_policy_enabled
  retention_policy_days    = var.retention_policy_days
  storage_account_id       = module.storage_account_hub[each.value.sta_name].stgaccount_id
  depends_on               = [ module.storage_account_hub ]
}

###---------------------------------------GLB Checkpoint VMSS-------------------------

module "glb_module" {
  providers = {
    azurerm = azurerm.current_sub
  }
    source  = "../../Terraform_Modules/CheckpointVMSS/Checkpoint_TF"
    subscription_id                 = var.subscription_id
    source_image_vhd_uri            = var.source_image_vhd_uri
    resource_group_name             = "IS${var.shortlocation}${var.resource_group_name_glb}"
    location                        = var.location
    vmss_name                       = "XC${var.shortlocation}${var.vmss_name_glb}"
    vnet_name                       = "${var.shortlocation}-${var.vnet_name}"
    vnet_resource_group             = "IS${var.shortlocation}${var.vnet_resource_group}"
    frontend_subnet_name            = module.snet[var.frontend_subnet_name_glb].subnet_name
    backend_subnet_name             = module.snet[var.backend_subnet_name_glb].subnet_name
    frontend_subnet_address_prefix  = module.snet[var.frontend_subnet_name_glb].subnet_address_prefix
    backend_subnet_address_prefix   = module.snet[var.backend_subnet_name_glb].subnet_address_prefix
    backend_lb_IP_address           = var.backend_lb_IP_address
    admin_username                  = var.admin_username_checkpoint
    admin_password                  = var.admin_password
    sic_key                         = var.sic_key
    vm_size                         = var.vm_size_glb
    disk_size                       = var.disk_size
    publisher                       = var.publisher
    vm_os_sku                       = var.vm_os_sku
    vm_os_offer                     = var.vm_os_offer
    os_version                      = var.os_version
    bootstrap_script                = var.bootstrap_script
    allow_upload_download           = var.allow_upload_download
    authentication_type             = var.authentication_type
    availability_zones_num          = var.availability_zones_num
    minimum_number_of_vm_instances  = var.minimum_number_of_vm_instances
    maximum_number_of_vm_instances  = var.maximum_number_of_vm_instances
    management_name                 = var.management_name
    management_IP                   = var.management_IP
    management_interface            = var.management_interface
    configuration_template_name     = "XC-${var.shortlocation}-${var.configuration_template_name_glb}"
    notification_email              = var.notification_email
    frontend_load_distribution      = var.frontend_load_distribution
    backend_load_distribution       = var.backend_load_distribution
    enable_custom_metrics           = var.enable_custom_metrics
    enable_floating_ip              = var.enable_floating_ip
    deployment_mode                 = var.deployment_mode_glb
    admin_shell                     = var.admin_shell
    serial_console_password_hash    = var.serial_console_password_hash
    maintenance_mode_password_hash  = var.maintenance_mode_password_hash
    nsg_id                          = var.nsg_id
    add_storage_account_ip_rules    = var.add_storage_account_ip_rules
    storage_account_additional_ips  = var.storage_account_additional_ips
    template_name                   = var.template_name
    template_version                = var.template_version
    template_type                   = var.template_type
    is_blink                        = var.is_blink
    installation_type               = var.installation_type
    vm_os_version                   = var.vm_os_version
    number_of_vm_instances          = var.number_of_vm_instances
    vnet_allocation_method          = var.vnet_allocation_method 
    bypass                          = var.sta_fw_bypass
    infrastructure_encryption_enabled = var.sta_fw_infrastructure_encryption_enabled
    encryption_at_host_enabled        = var.sta_fw_encryption_at_host_enabled
    allow_blob_public_access          = var.sta_fw_allow_blob_public_access
    shared_access_key_enabled         = var.sta_fw_shared_access_key_enabled
    ddos_protection_mode              = var.pip_fw_ddos_protection_mode
    ddos_protection_plan_id           = var.ddos_to_create ? module.DDoS.ddos_plan_id : try(data.azurerm_network_ddos_protection_plan.existing[0].id, null)
    public_ssh_key                    = azurerm_ssh_public_key.public_ssh_key_glb.public_key
    rg_tags                           = var.fw_tags
    min_tls_version                   = var.min_tls_version
    access_tier                       = var.access_tier_vmss
    versioning_enabled                = var.versioning_enabled_vmss
    delete_retention_days             = var.delete_retention_days_vmss
    container_delete_retention_days   = var.container_delete_retention_days_vmss
    depends_on                        = [ module.snet, module.vnet, azurerm_ssh_public_key.public_ssh_key_glb, module.DDoS ]
}

###---------------------------------------INT Checkpoint VMSS-------------------------

module "int_module" {
  providers = {
    azurerm = azurerm.current_sub
  }
    source  = "../../Terraform_Modules/CheckpointVMSS/Checkpoint_TF"
    subscription_id                 = var.subscription_id
    source_image_vhd_uri            = var.source_image_vhd_uri
    resource_group_name             = "IS${var.shortlocation}${var.resource_group_name_int}"
    location                        = var.location
    vmss_name                       = "XC${var.shortlocation}${var.vmss_name_int}"
    vnet_name                       = "${var.shortlocation}-${var.vnet_name}"
    vnet_resource_group             = "IS${var.shortlocation}${var.vnet_resource_group}"
    frontend_subnet_name            = module.snet[var.frontend_subnet_name_int].subnet_name
    backend_subnet_name             = module.snet[var.backend_subnet_name_int].subnet_name
    frontend_subnet_address_prefix  = module.snet[var.frontend_subnet_name_int].subnet_address_prefix
    backend_subnet_address_prefix   = module.snet[var.backend_subnet_name_int].subnet_address_prefix
    backend_lb_IP_address           = var.backend_lb_IP_address
    admin_username                  = var.admin_username_checkpoint
    admin_password                  = var.admin_password
    sic_key                         = var.sic_key
    vm_size                         = var.vm_size_int
    disk_size                       = var.disk_size
    publisher                       = var.publisher
    vm_os_sku                       = var.vm_os_sku
    vm_os_offer                     = var.vm_os_offer
    os_version                      = var.os_version
    bootstrap_script                = var.bootstrap_script
    allow_upload_download           = var.allow_upload_download
    authentication_type             = var.authentication_type
    availability_zones_num          = var.availability_zones_num
    minimum_number_of_vm_instances  = var.minimum_number_of_vm_instances
    maximum_number_of_vm_instances  = var.maximum_number_of_vm_instances
    management_name                 = var.management_name
    management_IP                   = var.management_IP
    management_interface            = var.management_interface
    configuration_template_name     = "XC-${var.shortlocation}-${var.configuration_template_name_int}"
    notification_email              = var.notification_email
    frontend_load_distribution      = var.frontend_load_distribution
    backend_load_distribution       = var.backend_load_distribution
    enable_custom_metrics           = var.enable_custom_metrics
    enable_floating_ip              = var.enable_floating_ip
    deployment_mode                 = var.deployment_mode_int
    admin_shell                     = var.admin_shell
    serial_console_password_hash    = var.serial_console_password_hash
    maintenance_mode_password_hash  = var.maintenance_mode_password_hash
    nsg_id                          = var.nsg_id
    add_storage_account_ip_rules    = var.add_storage_account_ip_rules
    storage_account_additional_ips  = var.storage_account_additional_ips
    template_name                   = var.template_name
    template_version                = var.template_version
    template_type                   = var.template_type
    is_blink                        = var.is_blink
    installation_type               = var.installation_type
    vm_os_version                   = var.vm_os_version
    number_of_vm_instances          = var.number_of_vm_instances
    vnet_allocation_method          = var.vnet_allocation_method
    bypass                          = var.sta_fw_bypass
    infrastructure_encryption_enabled = var.sta_fw_infrastructure_encryption_enabled
    encryption_at_host_enabled        = var.sta_fw_encryption_at_host_enabled
    allow_blob_public_access          = var.sta_fw_allow_blob_public_access
    shared_access_key_enabled         = var.sta_fw_shared_access_key_enabled
    ddos_protection_mode              = var.pip_fw_ddos_protection_mode
    ddos_protection_plan_id           = var.ddos_to_create ? module.DDoS.ddos_plan_id : try(data.azurerm_network_ddos_protection_plan.existing[0].id, null)
    public_ssh_key                    = azurerm_ssh_public_key.public_ssh_key_int.public_key 
    rg_tags                           = var.fw_tags
    min_tls_version                   = var.min_tls_version
    access_tier                       = var.access_tier_vmss
    versioning_enabled                = var.versioning_enabled_vmss
    delete_retention_days             = var.delete_retention_days_vmss
    container_delete_retention_days   = var.container_delete_retention_days_vmss
    depends_on                        = [ module.snet, module.vnet, azurerm_ssh_public_key.public_ssh_key_int, module.DDoS ]
}

###------------------------------------- Lifecycle Management of Storage Account-----------------------
module "glb_management_policy_fw" {
  providers = {
      azurerm = azurerm.current_sub
    }
  source                                            = "../../Terraform_Modules/LifecycleManagementPolicy"
  rule_name                                         = "LCM-xc${lower(var.shortlocation)}${var.mgt_pol_glb_rule_name}"
  rule_enabled                                      = var.rule_enabled
  storage_account_id                                = module.glb_module.storage_account_id
  blob_types                                        = var.blob_types
  delete_after_days_since_modification_greater_than = var.delete_after_days_since_modification_greater_than
  depends_on                                        = [ module.glb_module ]
}

module "int_management_policy_fw" {
  providers = {
      azurerm = azurerm.current_sub
    }
  source                                            = "../../Terraform_Modules/LifecycleManagementPolicy"
  rule_name                                         = "LCM-xc${lower(var.shortlocation)}${var.mgt_pol_int_rule_name}"
  rule_enabled                                      = var.rule_enabled
  storage_account_id                                = module.int_module.storage_account_id
  blob_types                                        = var.blob_types
  delete_after_days_since_modification_greater_than = var.delete_after_days_since_modification_greater_than
  depends_on                                        = [ module.int_module ]
}

# ##---------------------------------------Role Assignment------------------------------------

module "glb_vmss_role_assign_storage_account" {
  providers = {
      azurerm = azurerm.current_sub
    }
  source               = "../../Terraform_Modules/RoleAssignment"
  scope                = module.glb_module.storage_account_id
  principal_id         = module.glb_module.vmss_id
  role_definition_name = var.role_definition_name
  depends_on           = [ module.glb_module ]
}

module "int_vmss_role_assign_storage_account" {
  providers = {
      azurerm = azurerm.current_sub
  }
  source               = "../../Terraform_Modules/RoleAssignment"
  scope                = module.int_module.storage_account_id
  principal_id         = module.int_module.vmss_id
  role_definition_name = var.role_definition_name
  depends_on           = [ module.int_module ]
}

module "diagnostic_settings_nsg_glb" {
  providers = {
      azurerm = azurerm.current_sub
    }
  source                  = "../../Terraform_Modules/DiagnosticsSettingsV2"
  dlog_name               = "${module.glb_module.nsg_name}-Diags"
  target_id               = module.glb_module.nsg_id
  enable_logs             = var.enable_logs
  enabled_metric          = var.enabled_metric
  storage_acc_id          = values(module.storage_account_hub)[0].stgaccount_id
  workspace_rs_id         = var.send_logs_to_local  && var.create_local_law ? module.loganalytics_workspace.law_id : data.azurerm_log_analytics_workspace.global["global"].id
  depends_on = [ module.glb_module]
}

module "diagnostic_settings_nsg_int" {
  providers = {
      azurerm = azurerm.current_sub
    }
  source                  = "../../Terraform_Modules/DiagnosticsSettingsV2"
  dlog_name               = "${module.int_module.nsg_name}-Diags"
  target_id               = module.int_module.nsg_id
  enable_logs             = var.enable_logs
  enabled_metric          = var.enabled_metric
  storage_acc_id          = values(module.storage_account_hub)[0].stgaccount_id
  workspace_rs_id         = var.send_logs_to_local && var.create_local_law ? module.loganalytics_workspace.law_id : data.azurerm_log_analytics_workspace.global["global"].id
  depends_on = [ module.int_module]
}

module "diagnostic_settings_pip_int" {
  providers = {
      azurerm = azurerm.current_sub
    }
  source                  = "../../Terraform_Modules/DiagnosticsSettingsV2"
  dlog_name               = "XC${var.shortlocation}${var.vmss_name_int}-app-1-Diags"
  target_id               = module.int_module.publicip_id
  enable_logs             = var.enable_logs
  enabled_metric         = var.enabled_metric
  storage_acc_id          = values(module.storage_account_hub)[0].stgaccount_id
  workspace_rs_id         = var.send_logs_to_local == false && var.create_local_law ? module.loganalytics_workspace.law_id : data.azurerm_log_analytics_workspace.global["global"].id
  depends_on = [ module.int_module]
}

module "diagnostic_settings_lb_glb" {
  providers = {
      azurerm = azurerm.current_sub
    }
  count                   = var.deployment_mode_glb == "Internal" ? 1 : 0
  source                  = "../../Terraform_Modules/DiagnosticsSettingsV2"
  dlog_name               = "${ module.glb_module.backend_lb_name}-Diags"
  target_id               = module.glb_module.backend_lb_id
  enable_logs             = var.enable_logs
  enabled_metric          = var.enabled_metric
  storage_acc_id          = values(module.storage_account_hub)[0].stgaccount_id
  workspace_rs_id         = var.send_logs_to_local == false && var.create_local_law ? module.loganalytics_workspace.law_id : data.azurerm_log_analytics_workspace.global["global"].id
  depends_on              = [ module.glb_module]
}

module "diagnostic_settings_lb_int" {
  providers = {
      azurerm = azurerm.current_sub
    }
  count                   = var.deployment_mode_int == "Standard" ? 2 : 0
  source                  = "../../Terraform_Modules/DiagnosticsSettingsV2"
  dlog_name               = count.index == 1 ? "${module.int_module.backend_lb_name}-Diags" : "${module.int_module.frontend_lb_name}-Diags"
  target_id               = count.index == 1 ? module.int_module.backend_lb_id : module.int_module.frontend_lb_id
  enable_logs             = var.enable_logs
  enabled_metric          = var.enabled_metric
  storage_acc_id          = values(module.storage_account_hub)[0].stgaccount_id
  workspace_rs_id         = var.send_logs_to_local == false && var.create_local_law ? module.loganalytics_workspace.law_id : data.azurerm_log_analytics_workspace.global["global"].id
  depends_on              = [ module.int_module]
}

module "diagnostic_settings_lb_cc" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each                = var.lbs_cc 
  source                  = "../../Terraform_Modules/DiagnosticsSettingsV2"
  dlog_name               = "${ module.load_balancer_cc[each.key].azlb_name }-Diags"
  target_id               = module.load_balancer_cc[each.key].azlb_id
  enable_logs             = var.enable_logs
  enabled_metric          = var.enabled_metric
  storage_acc_id          = values(module.storage_account_hub)[0].stgaccount_id
  workspace_rs_id         = var.send_logs_to_local == false && var.create_local_law ? module.loganalytics_workspace.law_id : data.azurerm_log_analytics_workspace.global["global"].id
  depends_on              = [ module.glb_module]
}

##-------------------------------------- Key vault Creation --------------------------------------
module "keyvault_fw" {
  providers = {
     azurerm = azurerm.current_sub
   } 
  for_each                           = var.keyvault_fw
  source                             = "../../Terraform_Modules/KeyVault"
  key_vault_name                     = "is${lower(var.shortlocation)}${each.value.key_vault_name}" 
  location                           = var.location
  resource_group_name                = module.rg_mgt[each.value.resource_group_name].rg_name
  tenant_id                          = data.azurerm_client_config.current.tenant_id 
  kv_sku_name                        = var.kv_sku_name
  kv_purge_protection_enabled        = var.kv_purge_protection_enabled
  kv_soft_delete_retention_days      = var.kv_soft_delete_retention_days
  kv_enable_rbac_authorization       = var.kv_enable_rbac_authorization
  kv_enabled_for_disk_encryption     = var.kv_enabled_for_disk_encryption
  kv_enabled_for_template_deployment = var.kv_enabled_for_template_deployment
  kv_enabled_for_deployment          = var.kv_enabled_for_deployment
  kv_public_network_access_enabled   = var.kv_public_network_access_enabled
  bypass                             = var.kv_firewall_enabled ? var.kv_bypass : null
  default_action                     = var.kv_default_action
  ip_rules                           = var.kv_ip_rules
  virtual_network_subnet_ids         = concat([for name in each.value.subnet_names : module.snet[name].subnet_id],[data.azurerm_subnet.swc_iac_subnet.id])
  tags                               = merge(var.mgt_rg_tags, each.value.tags)
  depends_on                         = [ module.rg_mgt, module.snet ]     
}

###-----------------------------------Private Endpoint-----------------------------------------------

module "pvtendpoint_fw"{
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each                              = var.kv_firewall_enabled ? var.pvt_endpoints : {}
  source                                = "../../Terraform_Modules/PrivateEndpoint"
  location                              = var.location
  pe_name                               = "IS${var.shortlocation}${each.value.pe_name}"
  resource_group_name                   = module.rg_mgt[each.value.resource_group].rg_name
  subnet_id                             = module.snet[each.value.subnet_name].subnet_id
  custom_network_interface_name         = "IS${var.shortlocation}${each.value.pe_name}-nic"
  is_manual_connection                  = each.value.is_manual_connection
  private_service_connection_name       = "IS${var.shortlocation}${each.value.pe_name}-Connection"
  private_connection_resource_id        = module.keyvault_fw[each.value.key_vault_name].kv_id
  subresource_names                     = each.value.subresource_names
  private_dns_zone_ids                  = ["/subscriptions/${var.private_dns_zone_subscription_id}/resourceGroups/IS${var.dns_shortlocation}${var.private_dns_zone_rgName}/providers/Microsoft.Network/privateDnsZones/${var.kv_dns_zone_name}"]
  tags                                  = merge(var.mgt_rg_tags, each.value.pe_tags)
  depends_on                            = [ module.rg_mgt, module.snet, module.keyvault_fw ]
}

#-------------------------------------Diagnostic settings-----------------------------------

module "diagnostic_settings_kv_glb" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each                = var.keyvault_diag_glb
  source                  = "../../Terraform_Modules/DiagnosticsSettingsV2"
  dlog_name               = "is-${lower(var.shortlocation)}-${each.value.dlog_name}-diag"
  target_id               = module.keyvault_fw[each.value.kv_name].kv_id
  enable_logs             = var.enable_logs
  enabled_metric          = var.enabled_metric
  storage_acc_id          = module.glb_module.storage_account_id
  workspace_rs_id         = var.workspace_rs_id
  depends_on              = [ module.keyvault_fw, module.glb_module ]
}

module "diagnostic_settings_kv_int" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each                = var.keyvault_diag_int
  source                  = "../../Terraform_Modules/DiagnosticsSettingsV2"
  dlog_name               = "is-${lower(var.shortlocation)}-${each.value.dlog_name}-diag"
  target_id               = module.keyvault_fw[each.value.kv_name].kv_id
  enable_logs             = var.enable_logs
  enabled_metric          = var.enabled_metric
  storage_acc_id          = module.int_module.storage_account_id
  workspace_rs_id         = var.workspace_rs_id
  depends_on              = [ module.keyvault_fw, module.int_module ]
}

##---------------------------------TLS Key and Public SSH key-------------------------------------------
resource "tls_private_key" "key_glb" {
  algorithm = var.tls_key_algorithm
  rsa_bits  = 2048
}

resource "tls_private_key" "key_int" {
  algorithm = var.tls_key_algorithm
  rsa_bits  = 2048
}

resource "azurerm_ssh_public_key" "public_ssh_key_glb" {
  provider            = azurerm.current_sub
  name                = "IS${var.shortlocation}${var.ssh_key_name_glb}SSHKEY01"
  resource_group_name = module.rg_mgt["RG_mgt"].rg_name
  location            = var.location
  public_key          = tls_private_key.key_glb.public_key_openssh
  tags                = merge(var.mgt_rg_tags, {name = "IS${var.shortlocation}${var.ssh_key_name_glb}SSHKEY01" })
  depends_on          = [ module.rg_mgt ]
}  

resource "azurerm_ssh_public_key" "public_ssh_key_int" {
  provider            = azurerm.current_sub
  name                = "IS${var.shortlocation}${var.ssh_key_name_int}SSHKEY01"
  resource_group_name = module.rg_mgt["RG_mgt"].rg_name
  location            = var.location
  public_key          = tls_private_key.key_int.public_key_openssh
  tags                = merge(var.mgt_rg_tags, {name = "IS${var.shortlocation}${var.ssh_key_name_int}SSHKEY01" })
  depends_on          = [ module.rg_mgt ]
}

#------------------------------------Key vault secret -----------------------------------
module "key_vault_secret_glb" {
  providers = {
      azurerm = azurerm.current_sub
    }
    source              = "../../Terraform_Modules/KeyVaultSecret"
    secret_name         = "XC${var.shortlocation}${var.vmss_name_glb}-private-key"
    secret_value        = tls_private_key.key_glb.private_key_pem     
    kv_id               = module.keyvault_fw["kv_glb"].kv_id
    depends_on          = [ module.keyvault_fw, module.role_assign_kv ]
}

module "key_vault_secret_int" {
  providers = {
      azurerm = azurerm.current_sub
    }
    source              = "../../Terraform_Modules/KeyVaultSecret"
    secret_name         = "XC${var.shortlocation}${var.vmss_name_int}-private-key"
    secret_value        = tls_private_key.key_int.private_key_pem     
    kv_id               = module.keyvault_fw["kv_int"].kv_id
     depends_on         = [ module.keyvault_fw, module.role_assign_kv ]
}

##------------------------------- KeyVault - Role Assignment----------------------------------------------

module "role_assign_kv" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each             = var.kv_role_definition_names
  source               = "../../Terraform_Modules/RoleAssignment"
  scope                = "/subscriptions/${var.subscription_id}"
  principal_id         = data.azurerm_client_config.current.object_id
  role_definition_name = each.key
}
