provider "azurerm" {
	features {}
	subscription_id = var.sa_subscription_id
	resource_provider_registrations = "none"
}
 provider "azurerm" {
 	features {}
 	alias = "current_sub"
    subscription_id = var.subscription_id
    storage_use_azuread = true
 }
provider "azurerm" {
   alias = "mngd_id"
   subscription_id = var.managed_subscription_id
   resource_provider_registrations = "none"
   features {}
}
provider "azurerm" {
   alias = "actgrp_id"
   subscription_id = var.actgrp_subscription_id
   resource_provider_registrations = "none"
   features {}
}
provider "azurerm" {
   alias = "law_id"
   subscription_id = var.law_subscription_id
   resource_provider_registrations = "none"
   features {}
}
 provider "azurerm" {
   alias 			= "ddos_id"
   subscription_id  = var.ddos_id
   features {}
}
provider "azapi" {
   alias 			= "azapi"
}

#---------------------- Self hosted VM ---------------------------------------------
provider "azurerm" {
  features {}
   alias 			= "swc_iac_sub_id"
   subscription_id	= var.swc_iac_subscription_id
}