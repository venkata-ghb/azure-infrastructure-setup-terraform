terraform {
  backend "azurerm" {
  }
  required_version = ">= 0.14.3"
   required_providers {
     azurerm = {
       source  = "hashicorp/azurerm"
       version = "4.35.0"
     }
     tls = {
       source  = "hashicorp/tls"
       version = "~> 4.0.0"
     }
     azapi = {
      source  = "Azure/azapi"
      version = "2.3.0"
    }
   }

}
