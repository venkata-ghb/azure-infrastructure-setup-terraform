#------------------------------------------- Subscription ----------------------------------
subscription_name       = "HUB-01"
billing_account_name    = "5099306"
enrollment_account_name = "264764"
management_group_id = "HUB-MGMTGRP"
subscription_billing_scope = "/providers/Microsoft.Billing/billingAccounts/5099306/enrollmentAccounts/264764"
workload = "Production"
tags_sub = {
    remark              = ""
    environment         = ""
    model               = "dedicated"
    application         = ""
    costcenter          = "52013300"
    costcenterowner     = "lars.helmersson@se.abb.com"
    country             = "global"
    owningbusinessarea  = "zc"
    owningdivision      = "zcgs"
    owningcompany       = "chgpl"
}
#------------------------------------------- Location ---------------------------------------

location = "swedencentral"
shortlocation = "SWC"
mgshortlocation = "SWC"

#------------------------------------------- Tags------ --------------------------------------
rg_tags ={
    itsmnr    = "WO1173"
    remark = ""
    environment = ""
    model = "Application"
    igar = "9AAG026594"
    application = "cloud hosting service infrastructure"
    costcenter = "52013300"
    costcenterowner = "tomasz.repinski1@pl.abb.com"
    country = "global"
    owningbusinessarea = "zc"
    owningdivision = "zcgs"
    owningcompany = "chgpl"
}

cc_rg_tags ={
    remark = ""
    model = "Application"
    environment = ""
    igar = "9AAG028759"
    application = "global secure web gateway service prod"
    costcenter = "52012604"
    costcenterowner = "gyanendra.kumar1@in.abb.com"
    country = "global"
    owningbusinessarea = "zc"
    owningdivision = "zcgs"
    owningcompany = "chgpl"
    itsmnr    = "WO1173"
}

mgt_rg_tags = {
    remark = ""
    model = "Application"
    environment = ""
    igar = "9AAG026594"
    application = "cloud hosting service infrastructure"
    costcenter = "52013300"
    costcenterowner = "tomasz.repinski1@pl.abb.com"
    country = "global"
    owningbusinessarea = "zc"
    owningdivision = "zcgs"
    owningcompany = "chgpl"
    itsmnr    = "WO1173"
}

ntw_watch_tags = {
    itsmnr    = "ritm5066418"
    remark = "BizTalk - required for whitlisting"
    environment = ""
    model = "Application"
    igar = "9AAG026594"
    application = "cloud hosting service infrastructure"
    costcenter = "52013300"
    costcenterowner = "tomasz.repinski1@pl.abb.com"
    country = "global"
    owningbusinessarea = "zc"
    owningdivision = "zcgs"
    owningcompany = "chgpl"
}
#-------------------------------------Resource Groups------------------------------------------
resource_groups = {
"RG_ntw"          =   {
    "name" = "HUB01-RG-F-NETWORK"
}
}

cc_resource_groups = {
"RG_CC"          =   {
    "name" = "HUB01-RG-C-9AAG028759" 
     "tags"  = {   
        "autoshutdownschedule" = ""
        }  
}
}

mgt_resource_groups = {
  "RG_mgt" = {
     "name"  = "HUB01-RG-F-MGMT"
}
}

rg_ntw_watch = {
    "ntw_watch" = {
        "name" = "NetworkWatcherRG"
    }
}

#---------------------------------------Network Watcher----------------------------------------
network_watchers = {
    "networkwatcher" = {
    "nwr_name"            = "NetworkWatcher"
    "resource_group"      = "ntw_watch"
}
}

#---------------------------------------------- Vnets -------------------------------------------
vnets = {
    "hub_vnet_01"            =  {
    "vnet_name"           = "HUB-VNET01",
    "vnet_address_space"  = ["10.234.184.0/22"],
    "resource_group"      = "RG_ntw"
    "dns_servers"         = ["10.16.7.12", "10.17.106.6", "168.63.129.16", "10.16.114.10", "10.16.113.6"]
    "ddos_protection_plan_enabled" = true
    "vnet_tags"           = {
        "remark"    = "WO-1173"
        }
    }

}

#-------------------------------------------- Subnets -------------------------------------------
subnets = {
    "gateway"           = {
        "snet_name"          = "GatewaySubnet"
        "newbits"            = 5
        "netnum"             = 1
        "vnet_name"          = "hub_vnet_01"
        "resource_group"     = "RG_ntw" 
        "service_endpoints"  = []

        },

    "hub_glb_01"           = {
        "snet_name"          = "HUB-VNET01-GLB-NIC-01"
        "newbits"            = 6
        "netnum"             = 4
        "vnet_name"          = "hub_vnet_01"
        "resource_group"     = "RG_ntw"
        "service_endpoints"  = ["Microsoft.Storage", "Microsoft.KeyVault"]  
    },

    "hub_glb_02"           = {
        "snet_name"          = "HUB-VNET01-GLB-NIC-02"
        "newbits"            = 6
        "netnum"             = 20
        "vnet_name"          = "hub_vnet_01"
        "resource_group"     = "RG_ntw"  
        "service_endpoints"  = ["Microsoft.Storage", "Microsoft.KeyVault"] 
    },

    "hub_int_01"           = {
        "snet_name"          = "HUB-VNET01-INT-NIC01"
        "newbits"            = 6
        "netnum"             = 5
        "vnet_name"          = "hub_vnet_01"
        "resource_group"     = "RG_ntw"
        "service_endpoints"  = ["Microsoft.Storage", "Microsoft.KeyVault"]   
    },

    "hub_int_02"           = {
        "snet_name"          = "HUB-VNET01-INT-NIC02"
        "newbits"            = 6
        "netnum"             = 21
        "vnet_name"          = "hub_vnet_01"
        "resource_group"     = "RG_ntw"
        "service_endpoints"  = ["Microsoft.Storage", "Microsoft.KeyVault"]   
    },

    "hub_cc_01"       = {
        "snet_name"          = "HUB-VNET01-CC01"
        "newbits"            = 6
        "netnum"             = 32
        "vnet_name"          = "hub_vnet_01"
        "resource_group"     = "RG_ntw"
        "service_endpoints"  = []   
    },
    "hub_cc_02"            = {
        "snet_name"          = "HUB-VNET01-CC02"
        "newbits"            = 6
        "netnum"             = 48
        "vnet_name"          = "hub_vnet_01"
        "resource_group"     = "RG_ntw"
        "service_endpoints"  = []  
    },
    "hub_pvtend"            = {
        "snet_name"          = "HUB-VNET01-PVTEND01"
        "newbits"            = 6
        "netnum"             = 7
        "vnet_name"          = "hub_vnet_01"
        "resource_group"     = "RG_ntw"
        "service_endpoints"  = ["Microsoft.KeyVault"]  
    }              
}

#--------------------------------------------- DDOS Protection Plan ---------------------------

ddos_to_create     = true
ddos_shortlocation = "SWC"
ddos_plan_name = "HUB01-DDoS-01"
existing_ddos_name = "HUB01-DDoS-01"
existing_ddos_rg   = "HUB01-RG-F-NETWORK"
ddos_tags = {"remark" = ""}
#------------------------------------------------- NSGs ---------------------------------------
nsgs = {
    "hub_cc01"                =   {
        "nsg_name"           = "HUB-VNET01-CC01"
        "resource_group"     = "RG_ntw"
        "nsg_tags"           = {
            "remark" = ""
        }
    },
 
    "hub_cc02"                =   {
        "nsg_name"           = "HUB-VNET01-CC02"
        "resource_group"     = "RG_ntw"
        "nsg_tags"           = {
        "remark" = ""
        }
    }
}

# #---------------------------------------------- NSG RULES ------------------------------------
        nsg_rules_static = {          
            "cc02_nsg_rule-01" = {
                "nsr_name"                    =   "In-Allow-LBHealthProbe"       
                "nsg"                         =   "hub_cc02"
                "nsr_protocol"                =   "*"                
                "nsr_source_port_range"       =   "*",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "*",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "AzureLoadBalancer",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "hub_vnet_01"
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3999"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Allow"
                "resource_group"              =   "RG_ntw"
            },
            "cc02_nsg_rule-02" = {
                "nsr_name"                    =   "In-Allow-ABBnetwork-01"    
                "nsg"                         =   "hub_cc02"
                "nsr_protocol"                =   "*"                
                "nsr_source_port_range"       =   "*",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "*",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "VirtualNetwork",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "*",
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3998"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Allow"
                "resource_group"              =   "RG_ntw"
            },
            "cc02_nsg_rule-03" = {
                "nsr_name"                    =   "Out-Allow-ABBnetwork-01"    
                "nsg"                         =   "hub_cc02"
                "nsr_protocol"                =   "*"                
                "nsr_source_port_range"       =   "*",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "*",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "*",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "VirtualNetwork",
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3998"
                "nsr_direction"               =   "Outbound"
                "nsr_access"                  =   "Allow"
                "resource_group"              =   "RG_ntw"
            },
            "cc02_nsg_rule-04" = {
                "nsr_name"                    =   "Out-Allow-LBHealthProbe"    
                "nsg"                         =   "hub_cc02"
                "nsr_protocol"                =   "*"                
                "nsr_source_port_range"       =   "*",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "*",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "AzureLoadBalancer",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "*",
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3999"
                "nsr_direction"               =   "Outbound"
                "nsr_access"                  =   "Allow"
                "resource_group"              =   "RG_ntw"
            },
            "cc02_nsg_rule-05" = {
                "nsr_name"                    =   "In-Allow-9AAG028759-01"    
                "nsg"                         =   "hub_cc02"
                "nsr_protocol"                =   "Tcp"                
                "nsr_source_port_range"       =   "*",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "22",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "VirtualNetwork",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "hub_cc_02" 
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3000"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Allow"
                "resource_group"              =   "RG_ntw"
            },
            "cc02_nsg_rule-06" = {
                "nsr_name"                    =   "In-Allow-9AAG028759-02"    
                "nsg"                         =   "hub_cc02"
                "nsr_protocol"                =   "Icmp"                
                "nsr_source_port_range"       =   "*",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "*",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "VirtualNetwork",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "hub_cc_02" 
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "2999"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Allow"
                "resource_group"              =   "RG_ntw"
            },
            "cc02_nsg_rule-07" = {
                "nsr_name"                    =   "Out-Allow-9AAG028759-01"    
                "nsg"                         =   "hub_cc02"
                "nsr_protocol"                =   "Tcp"                
                "nsr_source_port_range"       =   "*",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "12002",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "*",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "199.168.148.101",
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3000"
                "nsr_direction"               =   "Outbound"
                "nsr_access"                  =   "Allow"
                "resource_group"              =   "RG_ntw"
            },
            "cc02_nsg_rule-08" = {
                "nsr_name"                    =   "Out-Allow-9AAG028759-02"    
                "nsg"                         =   "hub_cc02"
                "nsr_protocol"                =   "*"                
                "nsr_source_port_range"       =   "*",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "*",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "hub_cc_02" 
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "*",
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "2999"
                "nsr_direction"               =   "Outbound"
                "nsr_access"                  =   "Allow"
                "resource_group"              =   "RG_ntw"
            },
            "cc02_nsg_rule-09" = {
                "nsr_name"                    =   "In-Deny-RDP"       
                "nsg"                         =   "hub_cc02"
                "nsr_protocol"                =   "Tcp"                
                "nsr_source_port_range"       =   "3389",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "3389",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "*",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "hub_cc_02"
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3301"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Deny"
                "resource_group"              =   "RG_ntw"
            },
            "cc02_nsg_rule-10" = {
                "nsr_name"                    =   "In-Allow-SSH"    
                "nsg"                         =   "hub_cc02"
                "nsr_protocol"                =   "Tcp"                
                "nsr_source_port_range"       =   "22",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "22",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "10.0.0.0/8",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "hub_cc_02",
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3302"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Allow"
                "resource_group"              =   "RG_ntw"
            },
            "cc02_nsg_rule-11" = {
                "nsr_name"                    =   "In-Deny-SSH"    
                "nsg"                         =   "hub_cc02"
                "nsr_protocol"                =   "Tcp"                
                "nsr_source_port_range"       =   "22",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "22",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "*",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "hub_cc_02",
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3303"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Deny"
                "resource_group"              =   "RG_ntw"
            },
            "cc02_nsg_rule-12" = {
                "nsr_name"                    =   "In-Deny-HTTP"    
                "nsg"                         =   "hub_cc02"
                "nsr_protocol"                =   "Tcp"                
                "nsr_source_port_range"       =   "80",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "80",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "*",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "hub_cc_02",
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3304"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Deny"
                "resource_group"              =   "RG_ntw"
            },
            "cc02_nsg_rule-13" = {
                "nsr_name"                    =   "In-Deny-INTERNET"    
                "nsg"                         =   "hub_cc02"
                "nsr_protocol"                =   "Udp"                
                "nsr_source_port_range"       =   "*",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "*",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "Internet",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "hub_cc_02" 
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3300"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Deny"
                "resource_group"              =   "RG_ntw"
            },
            "cc02_nsg_rule-14" = {
                "nsr_name"                    =   "ICMP_VNET"    
                "nsg"                         =   "hub_cc02"
                "nsr_protocol"                =   "Icmp"                
                "nsr_source_port_range"       =   "*",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "*",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "VirtualNetwork",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "*" 
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "4001"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Allow"
                "resource_group"              =   "RG_ntw"
            },
            "cc02_nsg_rule-15" = {
                "nsr_name"                    =   "OUTBOUND"    
                "nsg"                         =   "hub_cc02"
                "nsr_protocol"                =   "*"                
                "nsr_source_port_range"       =   "*",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "*",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "*",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "*",
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "4000"
                "nsr_direction"               =   "Outbound"
                "nsr_access"                  =   "Allow"
                "resource_group"              =   "RG_ntw"
            },
            "cc02_nsg_rule-16" = {
                "nsr_name"                    =   "ALL_VNET"    
                "nsg"                         =   "hub_cc02"
                "nsr_protocol"                =   "Tcp"                
                "nsr_source_port_range"       =   "*",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "*",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "VirtualNetwork" 
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "*",
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "4000"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Allow"
                "resource_group"              =   "RG_ntw"
            },

            "cc01_nsg_rule-01" = {
                "nsr_name"                    =   "In-Allow-LBHealthProbe"       
                "nsg"                         =   "hub_cc01"
                "nsr_protocol"                =   "*"                
                "nsr_source_port_range"       =   "*",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "*",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "AzureLoadBalancer",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "hub_vnet_01" 
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3999"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Allow"
                "resource_group"              =   "RG_ntw"
            },
            "cc01_nsg_rule-02" = {
                "nsr_name"                    =   "In-Allow-ABBnetwork-01"    
                "nsg"                         =   "hub_cc01"
                "nsr_protocol"                =   "*"                
                "nsr_source_port_range"       =   "*",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "*",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "VirtualNetwork",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "*",
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3998"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Allow"
                "resource_group"              =   "RG_ntw"
            },
            "cc01_nsg_rule-03" = {
                "nsr_name"                    =   "Out-Allow-ABBnetwork-01"    
                "nsg"                         =   "hub_cc01"
                "nsr_protocol"                =   "*"                
                "nsr_source_port_range"       =   "*",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "*",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "*",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "VirtualNetwork",
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3998"
                "nsr_direction"               =   "Outbound"
                "nsr_access"                  =   "Allow"
                "resource_group"              =   "RG_ntw"
            },
            "cc01_nsg_rule-04" = {
                "nsr_name"                    =   "Out-Allow-LBHealthProbe"    
                "nsg"                         =   "hub_cc01"
                "nsr_protocol"                =   "*"                
                "nsr_source_port_range"       =   "*",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "*",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "AzureLoadBalancer",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "*",
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3999"
                "nsr_direction"               =   "Outbound"
                "nsr_access"                  =   "Allow"
                "resource_group"              =   "RG_ntw"
            },
            "cc01_nsg_rule-05" = {
                "nsr_name"                    =   "In-Allow-9AAG028759-01"    
                "nsg"                         =   "hub_cc01"
                "nsr_protocol"                =   "Tcp"                
                "nsr_source_port_range"       =   "*",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "22",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "VirtualNetwork",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "hub_cc_01" 
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3000"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Allow"
                "resource_group"              =   "RG_ntw"
            },
            "cc01_nsg_rule-06" = {
                "nsr_name"                    =   "In-Allow-9AAG028759-02"    
                "nsg"                         =   "hub_cc01"
                "nsr_protocol"                =   "Icmp"                
                "nsr_source_port_range"       =   "*",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "*",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "VirtualNetwork",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "hub_cc_01" 
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "2999"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Allow"
                "resource_group"              =   "RG_ntw"
            },
            "cc01_nsg_rule-07" = {
                "nsr_name"                    =   "Out-Allow-9AAG028759-01"    
                "nsg"                         =   "hub_cc01"
                "nsr_protocol"                =   "Tcp"                
                "nsr_source_port_range"       =   "*",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "12002",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "*",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "199.168.148.101",
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3000"
                "nsr_direction"               =   "Outbound"
                "nsr_access"                  =   "Allow"
                "resource_group"              =   "RG_ntw"
            },
            "cc01_nsg_rule-08" = {
                "nsr_name"                    =   "Out-Allow-9AAG028759-02"    
                "nsg"                         =   "hub_cc01"
                "nsr_protocol"                =   "*"                
                "nsr_source_port_range"       =   "*",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "*",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "hub_cc_01" 
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "*",
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "2999"
                "nsr_direction"               =   "Outbound"
                "nsr_access"                  =   "Allow"
                "resource_group"              =   "RG_ntw"
            },
            "cc01_nsg_rule-09" = {
                "nsr_name"                    =   "In-Deny-RDP"       
                "nsg"                         =   "hub_cc01"
                "nsr_protocol"                =   "Tcp"                
                "nsr_source_port_range"       =   "3389",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "3389",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "*",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "hub_cc_01"
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3301"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Deny"
                "resource_group"              =   "RG_ntw"
            },
         "cc01_nsg_rule-10" = {
                "nsr_name"                    =   "In-Allow-SSH"    
                "nsg"                         =   "hub_cc01"
                "nsr_protocol"                =   "Tcp"                
                "nsr_source_port_range"       =   "22",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "22",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "10.0.0.0/8",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "hub_cc_01",
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3302"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Allow"
                "resource_group"              =   "RG_ntw"
            }
             "cc01_nsg_rule-11" = {
                "nsr_name"                    =   "In-Deny-SSH"    
                "nsg"                         =   "hub_cc01"
                "nsr_protocol"                =   "Tcp"                
                "nsr_source_port_range"       =   "22",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "22",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "*",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "hub_cc_01",
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3303"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Deny"
                "resource_group"              =   "RG_ntw"
            },
              "cc01_nsg_rule-12" = {
                "nsr_name"                    =   "In-Deny-HTTP"    
                "nsg"                         =   "hub_cc01"
                "nsr_protocol"                =   "Tcp"                
                "nsr_source_port_range"       =   "80",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "80",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "*",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "hub_cc_01",
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3304"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Deny"
                "resource_group"              =   "RG_ntw"
            },
           "cc01_nsg_rule-13" = {
                "nsr_name"                    =   "In-Deny-INTERNET"    
                "nsg"                         =   "hub_cc01"
                "nsr_protocol"                =   "Udp"                
                "nsr_source_port_range"       =   "*",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "*",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "Internet",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "hub_cc_01" 
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3300"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Deny"
                "resource_group"              =   "RG_ntw"
            },
           "cc01_nsg_rule-14" = {
                "nsr_name"                    =   "ICMP_VNET"    
                "nsg"                         =   "hub_cc01"
                "nsr_protocol"                =   "Icmp"                
                "nsr_source_port_range"       =   "*",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "*",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "VirtualNetwork",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "*" 
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "4001"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Allow"
                "resource_group"              =   "RG_ntw"
            },
            "cc01_nsg_rule-15" = {
                "nsr_name"                    =   "OUTBOUND"    
                "nsg"                         =   "hub_cc01"
                "nsr_protocol"                =   "*"                
                "nsr_source_port_range"       =   "*",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "*",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "*",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "*",
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "4000"
                "nsr_direction"               =   "Outbound"
                "nsr_access"                  =   "Allow"
                "resource_group"              =   "RG_ntw"
            },
           "cc01_nsg_rule-16" = {
                "nsr_name"                    =   "ALL_VNET"    
                "nsg"                         =   "hub_cc01"
                "nsr_protocol"                =   "Tcp"                
                "nsr_source_port_range"       =   "*",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "*",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "VirtualNetwork" 
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "*",
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "4000"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Allow"
                "resource_group"              =   "RG_ntw"
            }
            }
glb_nsg_rules_fw = {
            "glb_nsg_rule-01" = {
                "nsr_name"                    =   "In-Deny-RDP"       
                "nsg"                         =   "hub_nsg_glb"
                "nsr_protocol"                =   "Tcp"                
                "nsr_source_port_range"       =   "3389",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "3389",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "*",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "hub_glb_02"
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3301"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Deny"
                "resource_group"              =   "RG_ntw"
            },
            "glb_nsg_rule-02" = {
                "nsr_name"                    =   "In-Allow-SSH"    
                "nsg"                         =   "hub_nsg_glb"
                "nsr_protocol"                =   "Tcp"                
                "nsr_source_port_range"       =   "22",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "22",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "10.0.0.0/8",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "hub_glb_02",
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3302"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Allow"
                "resource_group"              =   "RG_ntw"
            }
            "glb_nsg_rule-03" = {
                "nsr_name"                    =   "In-Deny-SSH"    
                "nsg"                         =   "hub_nsg_glb"
                "nsr_protocol"                =   "Tcp"                
                "nsr_source_port_range"       =   "22",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "22",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "*",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "hub_glb_02",
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3303"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Deny"
                "resource_group"              =   "RG_ntw"
            },
            "glb_nsg_rule-04" = {
                "nsr_name"                    =   "In-Deny-HTTP"    
                "nsg"                         =   "hub_nsg_glb"
                "nsr_protocol"                =   "Tcp"                
                "nsr_source_port_range"       =   "80",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "80",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "*",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "hub_glb_02",
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3304"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Deny"
                "resource_group"              =   "RG_ntw"
            },
            "glb_nsg_rule-05" = {
                "nsr_name"                    =   "In-Deny-INTERNET"    
                "nsg"                         =   "hub_nsg_glb"
                "nsr_protocol"                =   "Udp"                
                "nsr_source_port_range"       =   "*",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "*",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "Internet",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "hub_glb_02" 
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3300"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Deny"
                "resource_group"              =   "RG_ntw"
            }
}
int_nsg_rules_fw = {
            "intfw_nsg_rule-01" = {
                "nsr_name"                    =   "In-Deny-RDP"       
                "nsg"                         =   "hub_nsg_int"
                "nsr_protocol"                =   "Tcp"                
                "nsr_source_port_range"       =   "3389",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "3389",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "*",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "hub_int_02"
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3301"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Deny"
                "resource_group"              =   "RG_ntw"
            },
         "intfw_nsg_rule-02" = {
                "nsr_name"                    =   "In-Allow-SSH"    
                "nsg"                         =   "hub_nsg_int"
                "nsr_protocol"                =   "Tcp"                
                "nsr_source_port_range"       =   "22",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "22",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "10.0.0.0/8",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "hub_int_02",
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3302"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Allow"
                "resource_group"              =   "RG_ntw"
            }
             "intfw_nsg_rule-03" = {
                "nsr_name"                    =   "In-Deny-SSH"    
                "nsg"                         =   "hub_nsg_int"
                "nsr_protocol"                =   "Tcp"                
                "nsr_source_port_range"       =   "22",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "22",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "*",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "hub_int_02",
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3303"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Deny"
                "resource_group"              =   "RG_ntw"
            },
              "intfw_nsg_rule-04" = {
                "nsr_name"                    =   "In-Deny-HTTP"    
                "nsg"                         =   "hub_nsg_int"
                "nsr_protocol"                =   "Tcp"                
                "nsr_source_port_range"       =   "80",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "80",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "*",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "hub_int_02",
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3304"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Deny"
                "resource_group"              =   "RG_ntw"
            },
           "intfw_nsg_rule-05" = {
                "nsr_name"                    =   "In-Deny-INTERNET"    
                "nsg"                         =   "hub_nsg_int"
                "nsr_protocol"                =   "Udp"                
                "nsr_source_port_range"       =   "*",
                "nsr_source_port_ranges"      =   null,
                "nsr_destination_port_range"  =   "*",
                "nsr_destination_port_ranges" =   null,
                "nsr_source_address_prefix"   =   "Internet",
                "nsr_source_address_prefixes" =   null,
                "nsr_destination_address_prefix"      = "hub_int_02" 
                "nsr_destination_address_prefixes"    = null,
                "nsr_priority"                =   "3300"
                "nsr_direction"               =   "Inbound"
                "nsr_access"                  =   "Deny"
                "resource_group"              =   "RG_ntw"
            }
}

#--------------------------------------------Route table------------------------------------------------------

route_table_names = {
    "hub_glb_rt" = {
        "name" = "HUB-VNET01-GLB-UDR01"
        "resource_group" = "RG_ntw"
        "rt_tags" = {
            "remark"    = ""
        }
    },
    
}

#------------------------Route table - Subnet Association ---------------------------------------

RouteTableSubnetAssociations = {
    "hub_glb_rt_snet" = {
        "route_table_name"       = "hub_glb_rt"
        "subnet_name"            = "hub_glb_01"
    }
}

#---------------------------------------Virtual Network Gateway------------------------------------

vpn_gateways = {
 
     "hub_vpn_gateway"            =  {
         "vnet_gateway_name"                = "HUB-VNET01-ER-GW01"
         "resource_group"                   = "RG_ntw"
         "vnet_gateway_type"                = "ExpressRoute"
         "vpn_type"                         = "RouteBased"
         "vpn_enable_active_active"         = false
         "enable_bgp"                       = false
         "vnet_gateway_sku"                 = "ErGw2AZ"
         "generation"                       = "None"
         "remote_vnet_traffic_enabled"      = true
         "virtual_wan_traffic_enabled"      = true
         "vpn_ip_config"                    = [
             {
              ip_config_name =""
              public_ip_address_name=""
            }
         ]
         "subnet_names_ids"                 = "gateway"
         "gw_tags"                          = { 
            "remark"    = ""
        }
         }
}
public_ip_address_name_ids = {}
###-------------------Maintenance Configuration Vnet Gateway-----------------------------------
mc_vnet_gateways = {
    
    "mc_vnet_01" = {
        "vnetgw-maintenance-config"                 =   "Maintenance-01"
        "resource_group"                            =   "RG_ntw"
        "scope"                                     =   "Resource"
        "maintenanceSubScope"                       =   "NetworkGatewayMaintenance"
        "start_date_time"                           =   "2025-08-10 00:00"
        "duration"                                  =   "05:00"
        "time_zone"                                 =   "W. Europe Standard Time"
        "recur_every"                               =   "Day"
        "vpn_gateway"                               =   "hub_vpn_gateway"
        "vng_maintenace_assign_name"                =   "Assignment-01"
    }
}

#----------------------------------------Public IP----------------------------


public_ips_cc = {
     "cc_nat01_pip" ={
    "public_ip_name" ="PIP-HUB-CC-VNET01-NATGW01"
    "resource_group" ="RG_CC"
    "public_ip_allocation"= "Static"
    "sku"            = "Standard"
    "sku_tier"       = "Regional"
    "idle_timeout_in_minutes" = 10
    "domain_name_label" = ""
    "zones"          = ["2"]
     "pip_tags" = {
        "remark"    = ""
     }
     },
     "cc_nat02_pip" ={
    "public_ip_name" ="PIP-HUB-CC-VNET01-NATGW02"
    "resource_group" ="RG_CC"
    "public_ip_allocation"= "Static"
    "sku"            = "Standard"
    "sku_tier"       = "Regional"
    "idle_timeout_in_minutes" = 10
    "domain_name_label" = ""
    "zones"          = ["3"]
     "pip_tags" = {
        "remark"    = ""
     }
     }
}
#-----------------------------------------NAT Gateway---------------------------------------------

nat_gateways_cc = {
    "cc_nat01" = {
        "nat_gateway_name"          = "HUB-CC-VNET01-NAT-GW-01"
        "resource_group"             = "RG_CC"
        "idle_timeout_in_minutes"   = 10
        "zones"                     = ["2"]
        "nat_tags"                  = {
            "remark"    = ""
        }
    },

    "cc_nat02" = {
        "nat_gateway_name"          = "HUB-CC-VNET01-NAT-GW-02"
        "resource_group"             = "RG_CC"
        "idle_timeout_in_minutes"   = 10
        "zones"                     = ["3"]
        "nat_tags"                  = {
            "remark"    = ""
        }
    }
}

natgw_snet_association_cc = {
    "cc_nat_snet_01" = {
        "subnet_id" = "hub_cc_01"
        "nat_gw_id" = "cc_nat01"
    }

    "cc_nat_snet_02" = {
        "subnet_id" = "hub_cc_02"
        "nat_gw_id" = "cc_nat02"
    }
}

natgw_pip_association_cc ={

    "cc_nat_pip_01" ={
        "nat_gw_id" = "cc_nat01"
        "public_ip_address_id"="cc_nat01_pip"
    },

    "cc_nat_pip_02" ={
        "nat_gw_id" = "cc_nat02"
        "public_ip_address_id"="cc_nat02_pip"
    }
}

# #---------------------------------------- Log Analytical Workspace --------------------------------
create_local_law            = true
law_name_local              = "LA-01"
resource_group_name_local   = "HUB01-RG-F-MGMT"
law_sku_local               = "PerGB2018"
law_retention_in_days_local = null
daily_quota_gb_local        = null
law_tags                    = {
    remark = ""
}
subscription_identifier = "HUB01"
#----------------------------Load Balancer--------------------------------------
lbs_cc = {
   "cc_hub_lb" ={
    "lb_name" = "LLB-9AAG028759-01"
    "resource_group" = "RG_CC"
    "subnet_name"  = "hub_cc_01"
    "lb_tags"        = {
            "remark" = ""          
           
    }
    } 
}

frontend_ip_details_cc = [{
    fe_name= "FIP01"
    private_ip_address = ""
}
]

bp_details_cc                      ={
     "BEP01" = {
    virtual_network_id = ""
}
}
lb_probe_details_cc                 ={
    "PRB01" = {
    protocol = "Http"
    port = "50000"
    path = "/?cchealth"
  }
}
interval_in_seconds_cc              = 15
lb_rule_details_cc                  = {
    LBR01 = {
    protocol = "All" 
    frontend_port = "0" 
    backend_port = "0" 
    fe_ipconfig_name = "FIP01" 
    bp_name = "BEP01"
    idle_timeout_in_minutes = 4
    probe_name = "PRB01"
    enable_floating_ip = false
    load_distribution = "SourceIPProtocol"
    disable_outbound_snat = false
    enable_tcp_reset = false 
  }
}
lb_sku                          = "Standard"
lb_sku_tier                     = "Regional"
availability_zone               = ["1","2","3"]
private_ip_allocation           = "Static" 
private_ip_address_version      = "IPv4"

# ################################TSL Key######################################

tls_key_algorithm = "RSA"
ssh_key_name = "CC-Public-SSH-KEY"
ssh_rg_name = "HUB01-RG-C-9AAG028759"

#----------------------------------------NSG Subnet Association--------------------------------
nsg_snet_association = {
   "cc01_snet_nsg" = {
        "subnet_name"      = "hub_cc_01"
        "nsg_name"      = "hub_cc01"
    },
    "cc02_snet_nsg" = {
        "subnet_name"      = "hub_cc_02"
        "nsg_name"      = "hub_cc02"
    } 
}

#---------------------------------------Alert Rule -------------------------------------------
cht_alerts = {
    "alert01" = {
  "alert_name"            = "CHT Alert for Azure Planned Maintenance"
  "resource_group_name"   = "RG_mgt"
  "location"              = "global"
  "description"           = "CHT Alert for Azure Planned Maintenance"
  "alert_tags"            = {}
  "enabled"               = true
  "category"              = "ServiceHealth"
  "service_health_events" = ["Maintenance"]
    }
}

act_grp_name = "Planned Maintenance Notification"
act_grp_rg = "isst01-rg-c-plisi"

#---------------------------------------- Diagnostic Settings --------------------------------
diag_settings ={
    "diag-01" = {
    "dlog_name" ="ActivityLogs-01"
    "workspace"    = "hub_log"
    "storage_acc_id" = ""
    }
}
law_shortlocation = "WE"
law_name =  "LA-01"
law_rg   = "hub01-rg-f-mgmt"
send_logs_to_local = false
send_logs_to_global =  true

enable_logs = true
enabled_metric = false
###----------------------------------------- Vnet Flow logs ----------------------------------------

flow_logs_vnet = {
    "flw_01" = {
        "network_watcher_name" = "networkwatcher"
        "resource_group"       = "ntw_watch"
        "vnet"                 = "hub_vnet_01"
        "sta_name"             = "hub_sta_02"
        "tags" = {
            "remark"        = "" 
        }
    }
}
vfl_enabled               = true
vfl_flow_log_version      = 2
vfl_retention_days        = 31
vfl_traffic_analytics_enabled   = true
vfl_interval_in_minutes   = 10
vfl_send_logs_to_local = true
workspace_location  = "WestEurope" 
#--------------------------------------- Azure Policy -----------------------------------------
policies = {
  "allowedlocation" = {
  "name"                 = "bd3eaa615dd94b8b9ed282fa" 
  "policy_definition_id" = "/providers/Microsoft.Authorization/policyDefinitions/e56962a6-4747-49cd-b67b-bf8b01975c4c"
  },
  "allowedlocationRG" = {
  "name"                 = "63e11eeb7729432bb9ff989b" 
  "policy_definition_id" = "/providers/Microsoft.Authorization/policyDefinitions/e765b5de-1225-4ba3-bd56-1ac6695af988"
  }
}

policies_sta_kv_nsg = {
  "sta_cmk_encryption" = {
  "name"                 = "9072b0c442bb4d159c24ba5e" 
  "policy_definition_id" = "/providers/Microsoft.Authorization/policyDefinitions/6fac406b-40ca-413b-bf8e-0bf964659c25"
  },
  "kv_soft_delete" = {
  "name"                 = "607d62a4522f4f28aeb1e024" 
  "policy_definition_id" = "/providers/Microsoft.Authorization/policyDefinitions/1e66c121-a66a-4b1f-9b83-0fd99bf0fc2d"
  }
}

policies_activity_max3owner = {
  "maximum_3owners" = {
  "name"                 = "4b348411ea3d4e2dacd475b3" 
  "policy_definition_id" = "/providers/Microsoft.Authorization/policyDefinitions/4f11b553-d42e-4e3a-89be-32ca364cad4c"
  },
  "activity_log_1year" = {
  "name"                 = "3d99f8818c374418806b7dfd" 
  "policy_definition_id" = "/providers/Microsoft.Authorization/policyDefinitions/b02aacc0-b073-424e-8298-42b22829ee0a"
  }

}
enforce                 = false
enforce_01              = true
policy_management_group_id = "MGMTGRP"
effect                  = "Audit"
effect_01               = "AuditIfNotExists"

#---------------------------------------KV Secret------------------------------------
kv_secret = {
    "kv_secret_private_key" = {
       "secret_name" = "ccvms-pkey-prod"
    }
}
kv_shortlocation = "EUS2"
kv_name = "kv-9aag028759"
kv_resource_group_name = "GLBPROD01-RG-C-9AAG028759"

#------------------------------------Storage Accounts-------------------------------
container_delete_retention_days   = 0

storage_accounts_hub       = {
    "hub_sta"  = {
        "sta_name"                          = "glbprdstalog01"
        "resource_group"                    = "RG_mgt"
        "account_tier"                      = "Standard"
        "access_tier_01"                    = "Hot"
        "default_action"                    = "Deny"
        "account_replication_type"          = "LRS"
        "cross_tenant_replication_enabled"  = false
        "is_hns_enabled"                    = false
        "delete_retention_days"             = 0
        "container_delete_retention_days"   = 0
        "allow_blob_public_access"          = false
        "public_network_access_enabled"     = true
        "infrastructure_encryption_enabled" = true
        "shared_access_key_enabled"         = false
        "versioning_enabled"                = false
        "fs_delete_retention_days"          = 0
        "large_file_share_enabled"          = true
        "tags"              = {
          "remark"    = ""
        }
        subnet_names = ["hub_glb_01","hub_glb_02","hub_int_01","hub_int_02"]
    },
    "hub_sta_02"  = {
        "sta_name"                          = "glbprdstalog02"
        "resource_group"                    = "RG_mgt"
        "account_tier"                      = "Standard"
        "access_tier_01"                    = "Hot"
        "default_action"                    = "Deny"
        "account_replication_type"          = "LRS"
        "cross_tenant_replication_enabled"  = false
        "is_hns_enabled"                    = false
        "delete_retention_days"             = 0
        "container_delete_retention_days"   = 0
        "allow_blob_public_access"          = false
        "public_network_access_enabled"     = true
        "infrastructure_encryption_enabled" = true
        "shared_access_key_enabled"         = false
        "versioning_enabled"                = false
        "fs_delete_retention_days"          = 0
        "large_file_share_enabled"          = true
        "tags"              = {
          "remark"    = ""
        }
        subnet_names = ["hub_glb_01","hub_glb_02","hub_int_01","hub_int_02"]
    }
}
min_tls_version = "TLS1_2"

###---------------------------------------Role Assignemnt------------------------------------
role_assign_user = {
    role_user = {
        "role_definition_name" = "Contributor"
        "principal_id" = "9a6dce69-3e4c-43a1-9100-ccb9c1adc0ac"
    }
}
role_assign_cc = {
    zsclr_user = {
        "resource_group" = "RG_CC"
        "role_definition_name" = "Network Contributor"
    }
}

##-------------------------------------- Cloud Connector VMSS---------------------------------------------

cc_vmss = {
    "zs_ccvmss_01" = {
        "cc_vmss_names"                    = "ZCCSCALESET01"
        "resource_group_name"              = "RG_CC"
        "resource_group_name_ntw"          = "RG_ntw"
        "vnet_name"                        = "hub_vnet_01"
        "zones"                            = ["2"]
        "sta_name"                         = "glb_sta"
        "nw_interface_details"             = [{
            nw_interface_name      = "mgmt-Nic01"
            primary                = true
            ip_forwarding          = false
            accelerated_networking = false
            nsg_name               = ""
            ip_config = [{
                ip_config_name      = "mgmt-nic01-ip_config1"
                subnet_id           = "HUB-VNET01-CC01"
                ip_config_primary   = true
                lb_backend_ids      = []
            }]
        },
        {
            nw_interface_name      = "fwd-Nic02"
            primary                = false
            ip_forwarding          = true
            accelerated_networking = true
            nsg_name               = ""
            ip_config = [{
                ip_config_name      = "fwd-nic02-ip_config1"
                subnet_id           = "HUB-VNET01-CC01"
                ip_config_primary   = true
                lb_backend_ids      = ["cc_hub_lb"]
            }]
        }]

    },

    "zs_ccvmss_02" = {
        "cc_vmss_names"                    = "ZCCSCALESET02"
        "resource_group_name"              = "RG_CC"
        "resource_group_name_ntw"          = "RG_ntw"
        "vnet_name"                        = "hub_vnet_01"
        "zones"                            = ["3"]
        "sta_name"                         = "glb_sta"
        "nw_interface_details"             = [{
            nw_interface_name      = "mgmt-Nic01"
            primary                = true
            ip_forwarding          = false
            accelerated_networking = false
            nsg_name               = ""
            ip_config = [{
                ip_config_name      = "mgmt-nic01-ip_config1"
                subnet_id           = "HUB-VNET01-CC02"
                ip_config_primary   = true
                lb_backend_ids      = []
            }]
        },
        {
            nw_interface_name      = "fwd-Nic02"
            primary                = false
            ip_forwarding          = true
            accelerated_networking = true
            nsg_name               = ""
            ip_config = [{
                ip_config_name      = "fwd-mic02-ip_config1"
                subnet_id           = "HUB-VNET01-CC02"
                ip_config_primary   = true
                lb_backend_ids      = ["cc_hub_lb"]
            }]
        }]

    }
}
nsg_name_ids                      = null
cc_caching                        = "ReadWrite"
ccvmss_source_image_id            = null
cc_encryption_at_host_enabled     = true
ccvmss_image_sku                  = "zs_ser_gen1_cc_01"
ccvmss_image_offer                = "zia_cloud_connector"
ccvmss_image_version              = "latest"
ccvmss_image_publisher            = "zscaler1579058425289"
fault_domain_count                = 1
ccvmss_instance_type              = "Standard_D2s_v5"
zone_balance                      = false 
termination_notification_enabled  = true
termination_notification_timeout  = "PT5M"
lb_cc_vmss_name                   = "cc_hub_lb"
cc_tags = {
  "remark"    = ""        
 "operatingsystem" = "Linux" 
 "autoshutdownschedule" = ""
}
mngd_shortlocation = "EUS2"
cc_vm_managed_identity_name = "GLBPROD01-MI-ZSCALERCC"
cc_vm_managed_identity_rg = "GLBPROD01-RG-C-9AAG028759"
storage_account_type = "Standard_LRS"
storage_account_uri  = null
cc_vm_prov_url  = "connector.zscaler.net/api/v1/provUrl?name=Azure-TCS-Global-Autoscaling"
http_probe_port = 50000 
azure_vault_url = "https://iseus2-kv-9aag028759.vault.azure.net"

###---------------------------------AutoScale Zscaler VMSS---------------------------------
zslr_autoscales = {
"zslr_autoscale_cc01"={
"autoscale_name"        = "ZCCSCALESET01-Autoscale-01"
"resource_group_name"   = "RG_CC"
"zslr_vmss"             = "zs_ccvmss_01"
"tags"  = {   
    "remark" = ""
        }
},
"zslr_autoscale_cc02"={
"autoscale_name"        = "ZCCSCALESET02-Autoscale-01"
"resource_group_name"   = "RG_CC"
"zslr_vmss"             = "zs_ccvmss_02"
"tags"  = {   
    "remark" = ""
        }
}
}

zslr_profile_name = "Profile1"
zslr_min_instance_count = "1"
zslr_max_instance_count = "2"
zslr_default_instance_count = "1"
zslr_autoscale_rules = [
    {
    metric_name = "Percentage CPU"
    metric_namespace="microsoft.compute/virtualmachinescalesets"
    time_grain = "PT1M"
    statistic = "Average"
    time_window = "PT10M"
    time_aggregation = "Average"
    operator = "GreaterThan"
    threshold =  80
    direction = "Increase"
    instance_change_value = 1
    cooldown = "PT5M"
    },
    {
    metric_name = "Percentage CPU"
    metric_namespace="microsoft.compute/virtualmachinescalesets"
    time_grain = "PT1M"
    statistic = "Average"
    time_window = "PT10M"
    time_aggregation = "Average"
    operator = "LessThan"
    threshold =  60
    direction = "Decrease"
    instance_change_value = 1
    cooldown = "PT5M"
    }
]

##----------------------------------Log Profile---------------------------
log_profile = {
    "log_profile"={
        log_profile_name = "ExportLogProfile"
        sta_name         = "hub_sta"
    }
}
categories               = ["Write", "Delete", "Action"]
retention_policy_enabled = true
retention_policy_days    = 365

###-----------------------------------Checkpoints VMSS----------------------------------------

###-----------------------------------------INT FW VMSS----------------------------------------
resource_group_name_int             = "HUB01-RG-F-INTFW"
vmss_name_int                       = "HUBINTSCALESET01"
frontend_subnet_name_int            = "hub_int_02"
backend_subnet_name_int             = "hub_int_01"
vm_size_int                         = "Standard_D2s_v5"
configuration_template_name_int     = "HUBINTFWCFGT01"
deployment_mode_int                 = "Standard"
###-----------------------------------------GLB FW VMSS----------------------------------------
resource_group_name_glb             = "HUB01-RG-F-GLBFW"
vmss_name_glb                       = "HUBGLBSCALESET01"
frontend_subnet_name_glb            = "hub_glb_02"
backend_subnet_name_glb             = "hub_glb_01"
vm_size_glb                         = "Standard_D4s_v5"
configuration_template_name_glb     = "HUBGLBFWCFGT01"
deployment_mode_glb                 = "Internal"
##common parameters for both GLB and INT
sic_key                             = "autocme56781234"
source_image_vhd_uri                = "noCustomUri"
vnet_name                           = "HUB-VNET01"
vnet_resource_group                 = "HUB01-RG-F-NETWORK"
backend_lb_IP_address               = 4
disk_size                           = "100"
publisher                           = "checkpoint"
vm_os_sku                           = "sg-byol"
vm_os_offer                         = "check-point-cg-r8120"
os_version                          = "R8120"
bootstrap_script                    = ""
allow_upload_download               = true
authentication_type                 = "SSH Public Key"
availability_zones_num              = ["1", "2", "3"]
minimum_number_of_vm_instances      = 2
maximum_number_of_vm_instances      = 10
notification_email                  = "ch.tcsdcnetworksupport@abb.com"
frontend_load_distribution          = "SourceIPProtocol"
backend_load_distribution           = "SourceIPProtocol"
enable_custom_metrics               = true
enable_floating_ip                  = false
admin_shell                         = "/etc/cli.sh"
serial_console_password_hash        = ""
maintenance_mode_password_hash      = ""
add_storage_account_ip_rules        = true
storage_account_additional_ips      = ["20.91.100.236", "51.12.22.174", "51.12.22.175", "51.12.22.204", "51.12.72.222", "51.12.72.223", "51.12.73.92", "172.160.216.6"]
nsg_id                              = ""
template_name                       = "vmss_terraform_registry"
template_version                    = "1.0.4"
template_type                       = "terraform"
is_blink                            = true
installation_type                   = "vmss"
vm_os_version                       = "latest"
number_of_vm_instances              = 2
vnet_allocation_method              = "Static"
admin_username_checkpoint           = "notused"
management_name                     = "xelpg-lza1"
management_IP                       = "10.16.209.17"
management_interface                = "eth1-private"
access_tier_vmss                    = "Cool"
delete_retention_days_vmss          = 0
container_delete_retention_days_vmss = 0
versioning_enabled_vmss              = false
###---------------------------------------Role Assignemnt------------------------------------
role_definition_name       = "Contributor"

#------------------------------------- Lifecycle Management of Storage Account-----------------------
mgt_pol_glb_rule_name                             = "hubglbfwstgacct1"
mgt_pol_int_rule_name                             = "hubintfwstgacct1"
rule_enabled                                      = true
blob_types                                        = ["blockBlob"]
delete_after_days_since_modification_greater_than = 31
prefix_match_hub_sta                              = null

storage_accounts_hub_lcm = {
    "hub_sta_lcm" = {
        "sta_name"          = "hub_sta"
    }
}
#-------------------------------------- Checkpoint -----------------------
sta_fw_bypass                            = ["AzureServices"]
sta_fw_infrastructure_encryption_enabled = true
sta_fw_encryption_at_host_enabled        = true
sta_fw_allow_blob_public_access          = false
sta_fw_shared_access_key_enabled         = true
pip_fw_ddos_protection_mode              = "Enabled"
fw_tags ={
    itsmnr    = "WO1173"
    remark = ""
    igar = "9AAG026594"
    application = "cloud hosting service infrastructure"
    costcenter = "52013300"
    costcenterowner = "tomasz.repinski1@pl.abb.com"
    country = "global"
    model = "Application"
    owningbusinessarea = "zc"
    owningdivision = "zcgs"
    owningcompany = "chgpl"
}

##------------------------------------ Key Vault Creation --------------------------
keyvault_fw = {
    "kv_glb"    = {
        key_vault_name      = "hubglbkv01"
        resource_group_name = "RG_mgt"
        subnet_names        = ["hub_glb_01", "hub_glb_02"]
        tags                = {}
    },
    "kv_int"    = {
        key_vault_name      = "hubintkv01"
        resource_group_name = "RG_mgt"
        subnet_names        = ["hub_int_01", "hub_int_02"]
        tags                = {}
    }
}
kv_sku_name                     = "standard"
kv_purge_protection_enabled     = true
kv_soft_delete_retention_days   = 30
kv_enable_rbac_authorization    = true
kv_enabled_for_disk_encryption  = false 
kv_enabled_for_template_deployment  = true
kv_enabled_for_deployment           = false
kv_public_network_access_enabled    = true 
kv_bypass                     = "AzureServices"
kv_default_action             = "Deny"
kv_ip_rules                   = []
workspace_rs_id               = ""

#firewall keyvaults to enable vnet rules and private endpoints
kv_firewall_enabled = true 

keyvault_diag_glb = {
    kv_diag_glb = {
        dlog_name = "kv-fw01"
        kv_name   = "kv_glb"
    }
}

keyvault_diag_int = {
    kv_diag_int = {
        dlog_name = "kv-fw01"
        kv_name   = "kv_int"
    }
}
###-----------------------------------Private Endpoint-----------------------------------------------
pvt_endpoints = {
    "pe_kv-glb" = {
        "pe_name"                               = "HUBGLBPE01"
        "resource_group"                        = "RG_mgt"
        "subnet_name"                           = "hub_pvtend" 
        "key_vault_name"                        = "kv_glb"
        "is_manual_connection"                  = false
        "subresource_names"                     = ["vault"]
        "pe_tags"                               = {
            "remark"        = ""
        }
    },
    "pe_kv_int" = {
        "pe_name"                               = "HUBINTPE01"
        "resource_group"                        = "RG_mgt"
        "subnet_name"                           = "hub_pvtend" 
        "key_vault_name"                        = "kv_int"
        "is_manual_connection"                  = false
        "subresource_names"                     = ["vault"]
        "pe_tags"                               = {
            "remark"        = ""
        }
    }
}

dns_shortlocation                   = "WE"
private_dns_zone_rgName             = "HUB01-RG-F-DNS"
kv_dns_zone_name                       = "privatelink.vaultcore.azure.net"
###---------------------------------------Role Assignemnt------------------------------------
kv_role_definition_names       = ["Key Vault Administrator", "Key Vault Purge Operator"]

#----------------------------------------- Public SSH key -----------------------------
ssh_key_name_glb = "HUBGLB"
ssh_key_name_int = "HUBINT"

#self hosted vm network details
iac_vnet_name     = "IAC-VNET01"
iac_vnet_rg       = "IAC01-RG-F-NETWORK"
iac_subnet_name   = "IAC-VNET01-INT01"
iac_shortlocation = "SWC"