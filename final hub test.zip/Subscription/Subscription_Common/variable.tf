variable "billing_account_name" {
    description = "(Required) The Billing Account Name of the Enterprise Account."
    type = string
}
 
variable "enrollment_account_name" {
    description = "(Required) The Enrollment Account Name in the above Enterprise Account."
    type = string
}

variable "sa_subscription_id" {
  type = string
}

variable "shortlocation" {
  type = string
}

variable "mgshortlocation" {
  type = string
}

###-------------------------------------------- Subscription ---------------------------------------

variable "subscription_name" {
  description = "(Required) The Name of the Subscription. This is the Display Name in the portal."
  type = string
}

variable "management_group_id" {
  description = "(Required) The ID of the Management Group. This is the Display Name in the portal."
  type = string
}

variable "workload" {
  type = string
  description = "(Optional) The workload type of the Subscription. Possible values are Production (default) and DevTest. Changing this forces a new Subscription to be created."
}

variable "subscription_billing_scope" {
type = string
}
variable "tags_sub" {
  description = "A mapping of tags to all the resources."
  type       = map(string)
}