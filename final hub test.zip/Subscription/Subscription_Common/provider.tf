provider "azurerm" {
	features {}
	subscription_id = var.sa_subscription_id
	resource_provider_registrations = "none"
}