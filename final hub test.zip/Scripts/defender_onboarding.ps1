param ([string] $managementGroupName)

# Check if Az.Security is available
if (-not (Get-Module -ListAvailable -Name Az.Security)) {
    try {
        Install-Module -Name Az.Security -RequiredVersion 1.8.0 -Force -Scope CurrentUser
    } catch {
        Write-Error "Az.Security module is required but could not be installed."
        exit 1
    }
}

Write-Host "Running script for management group: $managementGroupName"
$allSubs = Search-AzGraph -Query "ResourceContainers | where type =~ 'microsoft.resources/subscriptions'" -ManagementGroup $managementGroupName
$subscriptions = $allSubs|where {$_.Properties.state -eq "Enabled"}

foreach ($sub in $subscriptions) {
    Set-AzContext -Subscription $sub.subscriptionId
    $secSetting = Get-AzSecurityPricing -Name "VirtualMachines"
    if ($secSetting.PricingTier -ne "Standard" -or $secSetting.SubPlan -ne "P1") {
        Set-AzSecurityPricing -Name "VirtualMachines" -PricingTier 'Standard' -SubPlan 'P1'
    } else {
        "Subscription $($sub.name) with ID $($sub.subscriptionId) configured correctly."
    }
}