variable "sta_id" {
  description = "(Required) Specifies the ID of the storage account. Changing this forces a new resource to be created."
  type = string
}
variable "default_action" {
  description = "(Required) Specifies the default action of allow or deny when no other rules match. Valid options are Deny or Allow."
  type = string
}
variable "ip_rules" {
  description = "(Optional) List of public IP or IP ranges in CIDR Format. Only IPv4 addresses are allowed. Private IP address ranges (as defined in RFC 1918) are not allowed."
  type = list(string)
}
variable "virtual_network_subnet_ids" {
  description = "(Optional) A list of virtual network subnet ids to secure the storage account."
  type = list(string)
}
variable "bypass" {
  description = "(Optional) Specifies whether traffic is bypassed for Logging/Metrics/AzureServices. Valid options are any combination of Logging, Metrics, AzureServices, or None. Defaults to AzureServices."
  type = list(string)
}