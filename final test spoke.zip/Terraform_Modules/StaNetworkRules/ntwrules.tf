resource "azurerm_storage_account_network_rules" "sta_rule" {
  storage_account_id         = var.sta_id
  default_action             = var.default_action
  ip_rules                   = var.ip_rules
  virtual_network_subnet_ids = var.virtual_network_subnet_ids
  bypass                     = var.bypass
}