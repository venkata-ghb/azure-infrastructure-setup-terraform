variable "resource_group_name" {
  description = "Specifies the name of the Resource Group where the Disk Encryption Set should exist. Changing this forces a new resource to be created."
  type = string
}

variable "location" {
  description = "Specifies the Azure Region where the Disk Encryption Set exists. Changing this forces a new resource to be created."
  type = string
}

variable "key_vault_name" {
  description = "(Required) Specifies the name of the Key Vault. Changing this forces a new resource to be created."
  type = string
}

variable "kv_sku_name" {
  description = "(Required) The Name of the SKU used for this Key Vault. Possible values are standard and premium."
}

variable "kv_enabled_for_deployment" {
  description = "(Optional) Boolean flag to specify whether Azure Virtual Machines are permitted to retrieve certificates stored as secrets from the key vault. defaults to false."
  type        = bool
}

variable "kv_enabled_for_disk_encryption" {
  description = "(Optional) Boolean flag to specify whether Azure Disk Encryption is permitted to retrieve secrets from the vault and unwrap keys. Defaults to false."
  type        = bool
}

variable "kv_enabled_for_template_deployment" {
  description = "(Optional) Boolean flag to specify whether Azure Resource Manager is permitted to retrieve secrets from the key vault. Defaults to false."
  type        = bool
}

variable "kv_purge_protection_enabled" {
  description = "(Optional) Is Purge Protection enabled for this Key Vault? Defaults to false. Once Purge Protection has been Enabled it's not possible to Disable it."
  type        = bool
}

variable "kv_soft_delete_retention_days" {
  description = "(Optional) The number of days that items should be retained for once soft-deleted. This value can be between 7 and 90 (the Default) days."
  type        = number
}

variable "kv_enable_rbac_authorization" {
  description = "(Optional) Boolean flag to specify whether Azure Key Vault uses Role Based Access Control (RBAC) for authorization of data actions. Defaults to false."
  type        = bool
}

variable "tags" {
  description   = "A mapping of tags to assign to the resource."
  type          = map(string)
}

variable "kv_public_network_access_enabled" {
  description = "(Optional) Whether public network access is allowed for this Key Vault. Defaults to true."
  type = bool
}

variable "tenant_id" {
  description = "(Required) The Azure Active Directory tenant ID that should be used for authenticating requests to the key vault."
  type = string
}

variable "default_action" {
  type = string
  description = "(Required) The Default Action to use when no rules match from ip_rules / virtual_network_subnet_ids. Possible values are Allow and Deny."
}

variable "ip_rules" {
  type = list(string)
  description = " (Optional) One or more IP Addresses, or CIDR Blocks which should be able to access the Key Vault."
}

variable "bypass" {
  type        = string
  description = "(Required) Specifies which traffic can bypass the network rules. Possible values are AzureServices and None"
}

variable "virtual_network_subnet_ids" {
  type = list(string)
  description = "(Optional) One or more Subnet IDs which should be able to access this Key Vault."
}