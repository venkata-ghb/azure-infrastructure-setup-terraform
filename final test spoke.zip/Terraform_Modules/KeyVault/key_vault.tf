resource "azurerm_key_vault" "key_vault" {
  name                            = var.key_vault_name
  location                        = var.location
  resource_group_name             = var.resource_group_name
  tenant_id                       = var.tenant_id
  sku_name                        = var.kv_sku_name
  purge_protection_enabled        = var.kv_purge_protection_enabled
  soft_delete_retention_days      = var.kv_soft_delete_retention_days
  enable_rbac_authorization       = var.kv_enable_rbac_authorization
  enabled_for_disk_encryption     = var.kv_enabled_for_disk_encryption
  enabled_for_template_deployment = var.kv_enabled_for_template_deployment
  enabled_for_deployment          = var.kv_enabled_for_deployment
  public_network_access_enabled   = var.kv_public_network_access_enabled
  
  dynamic "network_acls" {
    for_each = var.bypass == null ? [] : [1]
    content {
      bypass                     = var.bypass
      default_action             = var.default_action
      ip_rules                   = var.ip_rules
      virtual_network_subnet_ids = var.virtual_network_subnet_ids
    }
  }
  
  tags                            = merge( var.tags, { name = var.key_vault_name })
  lifecycle {
    ignore_changes = [ contact ]
  }
}
