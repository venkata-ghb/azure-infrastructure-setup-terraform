variable "nsr_name" {
  description = "(Required) The name of the security rule. This needs to be unique across all Rules in the Network Security Group. Changing this forces a new resource to be created."
  type        = string
}
variable "nsr_resource_group_name" {
  description = "(Required) The name of the resource group in which to create the Network Security Rule. Changing this forces a new resource to be created."
  type        = string
}
variable "nsr_nsg_name" {
  description = "(Required) The name of the Network Security Group that we want to attach the rule to. Changing this forces a new resource to be created."
  type        = string
}
variable "nsr_description" {
  default     = null
  description = "(Optional) A description for this rule. Restricted to 140 characters."
  type        = string
}
variable "nsr_protocol" {
  description = "(Required) Network protocol this rule applies to. Possible values include Tcp, Udp, Icmp, or * (which matches all)."
  type        = string
}
variable "nsr_source_port_range" {
  default     = null
  description = "(Optional) Source Port or Range. Integer or range between 0 and 65535 or * to match any. This is required if source_port_ranges is not specified."
  type        = string
}
variable "nsr_source_port_ranges" {
  default     = []
  description = "(Optional) List of source ports or port ranges. This is required if source_port_range is not specified."
  type        = list(string)
}
variable "nsr_destination_port_range" {
  default     = null
  description = "(Optional) Destination Port or Range. Integer or range between 0 and 65535 or * to match any. This is required if destination_port_ranges is not specified."
  type        = string
}
variable "nsr_destination_port_ranges" {
  default     = []
  description = "(Optional) List of destination ports or port ranges. This is required if destination_port_range is not specified."
  type        = list(string)
}
variable "nsr_source_address_prefix" {
  default     = null
  description = "(Optional) CIDR or source IP range or * to match any IP. Tags such as ‘VirtualNetwork’, ‘AzureLoadBalancer’ and ‘Internet’ can also be used. This is required if source_address_prefixes is not specified."
  type        = string
}
variable "nsr_source_address_prefixes" {
  default     = []
  description = "(Optional) List of source address prefixes. Tags may not be used. This is required if source_address_prefix is not specified."
  type        = list(string)
}
variable "nsr_source_application_security_group_ids" {
  default     = []
  description = "(Optional) A List of source Application Security Group ID's."
  type        = list(string)
}
variable "nsr_destination_address_prefix" {
  default     = null
  description = "(Optional) CIDR or destination IP range or * to match any IP. Tags such as ‘VirtualNetwork’, ‘AzureLoadBalancer’ and ‘Internet’ can also be used. Besides, it also supports all available Service Tags like ‘Sql.WestEurope‘, ‘Storage.EastUS‘, etc. You can list the available service tags with the cli: shell az network list-service-tags --location westcentralus. For further information please see Azure CLI - az network list-service-tags. This is required if destination_address_prefixes is not specified."
  type        = string
}
variable "nsr_destination_address_prefixes" {
  default     = []
  description = "(Optional) List of destination address prefixes. Tags may not be used. This is required if destination_address_prefix is not specified."
  type        = list(string)
}
variable "nsr_destination_application_security_group_ids" {
  default     = []
  description = "(Optional) A List of destination Application Security Group ID's."
  type        = list(string)
}
variable "nsr_access" {
  description = "(Required) Specifies whether network traffic is allowed or denied. Possible values are Allow and Deny."
  type        = string
}
variable "nsr_priority" {
  description = "(Required) Specifies the priority of the rule. The value can be between 100 and 4096. The priority number must be unique for each rule in the collection. The lower the priority number, the higher the priority of the rule."
  type        = string
}
variable "nsr_direction" {
  description = "(Required) The direction specifies if rule will be evaluated on incoming or outgoing traffic. Possible values are Inbound and Outbound."
  type        = string
}