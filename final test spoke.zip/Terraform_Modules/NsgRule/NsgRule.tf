resource "azurerm_network_security_rule" "network_security_rules" {
  name                                       = var.nsr_name
  description                                = var.nsr_description
  resource_group_name                        = var.nsr_resource_group_name
  network_security_group_name                = var.nsr_nsg_name
  protocol                                   = var.nsr_protocol
  source_port_range                          = var.nsr_source_port_range
  source_port_ranges                         = var.nsr_source_port_ranges
  destination_port_range                     = var.nsr_destination_port_range
  destination_port_ranges                    = var.nsr_destination_port_ranges
  source_address_prefix                      = var.nsr_source_address_prefix
  source_address_prefixes                    = var.nsr_source_address_prefixes
  source_application_security_group_ids      = var.nsr_source_application_security_group_ids
  destination_address_prefix                 = var.nsr_destination_address_prefix
  destination_address_prefixes               = var.nsr_destination_address_prefixes
  destination_application_security_group_ids = var.nsr_destination_application_security_group_ids
  priority                                   = var.nsr_priority
  direction                                  = var.nsr_direction
  access                                     = var.nsr_access
}