resource "azurerm_linux_virtual_machine" "vm" {
  name                = var.slvm_name
  resource_group_name = var.resource_group_name
  location            = var.location
  size                = var.vm_instance_type
  admin_username      = var.admin_username
  admin_password      = var.admin_password
  computer_name       = var.slvm_name
  zone                       = anytrue([(var.availability_set_id != ""),(var.zone == "")]) ? null : var.zone
  availability_set_id        = anytrue([(var.availability_set_id != ""),(var.zone == "")]) ? var.availability_set_id : null
  encryption_at_host_enabled = var.encryption_at_host_enabled
  secure_boot_enabled        = var.secure_boot_enabled 
  vtpm_enabled               = var.vtpm_enabled
  network_interface_ids = var.network_interface_ids
  disable_password_authentication = var.disable_password_authentication
  source_image_id = var.source_image_id != null ? var.source_image_id : null

  dynamic source_image_reference {
    for_each = var.vm_source_image_reference == null ? [] : var.vm_source_image_reference
 
    content {
      publisher = source_image_reference.value.vm_image_publisher
      offer     = source_image_reference.value.vm_image_offer
      sku       = source_image_reference.value.vm_image_sku
      version   = source_image_reference.value.vm_image_version
    }
  }

  dynamic plan {
    for_each = var.plan_details == null ? [] : var.plan_details
    content {
      publisher = plan.value.publisher
      name      = plan.value.name
      product   = plan.value.product
    }
  }

  os_disk {
    caching              = "ReadWrite"
    name                 = var.vm_os_disk_name == null ? "${var.slvm_name}-osdisk" : var.vm_os_disk_name
    storage_account_type = var.storage_account_type
    disk_encryption_set_id = var.disk_encryption_set_id
  }
 identity {
    type         = var.identity_type
    identity_ids = var.identity_ids 
  }

  dynamic boot_diagnostics {
    for_each = var.storage_account_uri != null ? [1] : []
    content {
      storage_account_uri = var.storage_account_uri
    }
  }
  tags = merge(var.tags, {name = var.slvm_name}, {hostname = var.slvm_name})
}