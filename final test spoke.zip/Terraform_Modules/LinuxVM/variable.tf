variable "resource_group_name" {
  description = "(Required) The name of the Resource Group in which the Linux Virtual Machine should be exist. Changing this forces a new resource to be created."
  type = string
}
variable "location" {
  description = "(Required) The Azure location where the Linux Virtual Machine should exist. Changing this forces a new resource to be created."
  type = string
}
variable "admin_username" {
  description = "(Optional) The username of the local administrator used for the Virtual Machine. Changing this forces a new resource to be created."
  type = string
}
variable "admin_password" {
  description = "(Optional) The Password which should be used for the local-administrator on this Virtual Machine. Changing this forces a new resource to be created."
  type = string
}
variable "slvm_name" {
  description = "(Required) The name of the Linux Virtual Machine. Changing this forces a new resource to be created."
  type = string
}
variable "vm_instance_type" {
  description = "(Required) The SKU which should be used for this Virtual Machine, such as Standard_F2."
  type = string
}
variable "storage_account_type" {
  description = "(Optional) The Type of Storage Account which should back this the Internal OS Disk. Possible values are Standard_LRS, StandardSSD_LRS, Premium_LRS, StandardSSD_ZRS and Premium_ZRS. Changing this forces a new resource to be created."
  type = string
}
variable "availability_set_id" {
  description = "(Optional) Specifies the ID of the Availability Set in which the Virtual Machine should exist. Changing this forces a new resource to be created."
  type = string
}
variable "zone" {
  description = "(Optional) Specifies the Availability Zones in which this Linux Virtual Machine should be located. Changing this forces a new Linux Virtual Machine to be created."
  type = string
}
variable "secure_boot_enabled" {
  description = "(Optional) Specifies whether secure boot should be enabled on the virtual machine. Changing this forces a new resource to be created."
  type = bool
}
variable "vtpm_enabled" {
  description = "(Optional) Specifies whether vTPM should be enabled on the virtual machine. Changing this forces a new resource to be created."
  type = bool
}
variable "network_interface_ids" {
  description = " (Required). A list of Network Interface IDs which should be attached to this Virtual Machine. The first Network Interface ID in this list will be the Primary Network Interface on the Virtual Machine."
  type = list(string)
}
variable "disable_password_authentication" {
  description = "(Optional) Should Password Authentication be disabled on this Virtual Machine? Defaults to true. Changing this forces a new resource to be created."
  type = bool
}
variable "vm_os_disk_name" {
  description = "(Optional) The name which should be used for the Internal OS Disk. Changing this forces a new resource to be created."
  type = string
}
variable "identity_type" {
  description = "(Required) Specifies the type of Managed Service Identity that should be configured on this Linux Virtual Machine. Possible values are SystemAssigned, UserAssigned, SystemAssigned, UserAssigned (to enable both)."
  type = string
}
variable "identity_ids" {
  description = "(Optional) Specifies a list of User Assigned Managed Identity IDs to be assigned to this Linux Virtual Machine."
  type = list(string)
}
variable "storage_account_uri" {
  description = "(Optional) The Primary/Secondary Endpoint for the Azure Storage Account which should be used to store Boot Diagnostics, including Console Output and Screenshots from the Hypervisor."
  type = string
}
variable "tags" {
  description = "(Optional) A mapping of tags to assign to the resource."
  type = map(string)
}
variable "disk_encryption_set_id" {
  description = "(Optional) The ID of the Disk Encryption Set which should be used to Encrypt this OS Disk. Conflicts with secure_vm_disk_encryption_set_id."
  type = string
}
variable "encryption_at_host_enabled" {
  description = " (Optional) Should all of the disks (including the temp disk) attached to this Virtual Machine be encrypted by enabling Encryption at Host?"
  type = bool
}
variable "source_image_id" {
  description = "(Optional) The ID of the Image which this Virtual Machine should be created from. Changing this forces a new resource to be created. Possible Image ID types include Image IDs, Shared Image IDs, Shared Image Version IDs, Community Gallery Image IDs, Community Gallery Image Version IDs, Shared Gallery Image IDs and Shared Gallery Image Version IDs."
  type = string
}
variable "vm_source_image_reference" {
  description = "(Optional) A source_image_reference block as defined below. Changing this forces a new resource to be created."
  type = list(object({
    vm_image_publisher = string
    vm_image_offer     = string
    vm_image_version   = string
    vm_image_sku       = string
  }))
}
variable "plan_details" {
  description = "Specifies the plan details of the Virtual Machine"
  type = list(object({
    publisher = string
    name      = string
    product   = string
  }))
}