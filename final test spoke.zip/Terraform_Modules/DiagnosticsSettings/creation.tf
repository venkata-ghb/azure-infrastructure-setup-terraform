data "azurerm_monitor_diagnostic_categories" "names" {
  count       = length([var.target_id])
  resource_id = [var.target_id][count.index]
}

#Manages a Diagnostic Setting for an existing Resource.
resource "azurerm_monitor_diagnostic_setting" "diag_name" {
  name                       = var.dlog_name
  target_resource_id         = var.target_id
  storage_account_id         = var.storage_acc_id == "" ? null : var.storage_acc_id
  log_analytics_workspace_id = var.workspace_rs_id == "" ? null : var.workspace_rs_id

  dynamic "enabled_log" {
    for_each = var.enable_logs ? [ for lg in data.azurerm_monitor_diagnostic_categories.names[0].log_category_groups : {
      lg_name = lg
      }
    ] : []
    content {
      category_group = enabled_log.value.lg_name
      
    }
  }
 dynamic "metric" {
    for_each = var.enabled_metric ? [ for mt in data.azurerm_monitor_diagnostic_categories.names[0].metrics : {
      mt_name = mt
      }] : []
    content {
      category = metric.key
      enabled  = var.enabled_metric
    }
  }
  lifecycle {
    ignore_changes = [ enabled_log ]
  }
}