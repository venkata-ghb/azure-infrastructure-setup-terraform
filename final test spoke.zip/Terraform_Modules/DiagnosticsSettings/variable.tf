variable "workspace_rs_id" {
  description = "(Optional) Specifies the ID of a Log Analytics Workspace where Diagnostics Data should be sent."
  type        = string
}
 
variable "dlog_name" {
  description = "(Required) Specifies the names of the Diagnostic Settings."
  type        = string
}
 
variable "target_id" {
  description = "(Required) The ID of an existing Resources on which to configure Diagnostic Settings. "
  type        = string
}
 
variable "storage_acc_id" {
  description = "(Optional) The ID of the Storage Account where logs should be sent."
  type        = string
}
variable "enable_logs" {
  type = bool
  description = "(Optional) One or more enabled_log blocks as defined below"
}

variable "enabled_metric" {
  type = bool
  description = "The name of a Diagnostic Metric Category for this Resource"
}