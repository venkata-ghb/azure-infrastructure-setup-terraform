output "diag_settings_names" {
  description = "Names of Diagnostic Setings created."
  value       = azurerm_monitor_diagnostic_setting.diag_name.*.name
}
 
output "diag_settings_ids" {
  description = "IDs of Diagnostic Setings created."
  value       = azurerm_monitor_diagnostic_setting.diag_name.*.id
}