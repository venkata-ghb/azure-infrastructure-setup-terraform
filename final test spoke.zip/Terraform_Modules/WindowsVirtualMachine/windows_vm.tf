resource "azurerm_windows_virtual_machine" "vm" {
  name                       = var.vm_name
  location                   = var.location
  resource_group_name        = var.resource_group_name
  size                       = var.vm_instance_type
  admin_username             = var.admin_username
  admin_password             = var.admin_password
  zone                       = anytrue([(var.availability_set_id != ""),(var.zone == "")]) ? null : var.zone
  encryption_at_host_enabled = var.encryption_at_host_enabled
  network_interface_ids      = var.network_interface_ids
  computer_name              = var.vm_name
  availability_set_id        = anytrue([(var.availability_set_id != ""),(var.zone == "")]) ? var.availability_set_id : null
  secure_boot_enabled        = var.secure_boot_enabled 
  vtpm_enabled               = var.vtpm_enabled 
  license_type               = var.license_type 
  disk_controller_type       = var.disk_controller_type   
  
  os_disk {
    caching                = "ReadWrite"
    storage_account_type   = var.disk_storage_account_type
	  name                   = var.vm_os_disk_name == null ? "${var.vm_name}-osdisk" : var.vm_os_disk_name
    disk_encryption_set_id = var.disk_encryption_set_id
  }
 
  dynamic source_image_reference {
    for_each = var.vm_source_image_reference == null ? [] : var.vm_source_image_reference
 
    content {
      publisher = source_image_reference.value.vm_image_publisher
      offer     = source_image_reference.value.vm_image_offer
      sku       = source_image_reference.value.vm_image_sku
      version   = source_image_reference.value.vm_image_version
    }
  }

  dynamic plan {
    for_each = var.plan_details == null ? [] : var.plan_details
    content {
      publisher = plan.value.publisher
      name      = plan.value.name
      product   = plan.value.product
    }
  }
 
source_image_id = var.vm_source_image_id != null ? var.vm_source_image_id : null
 
 identity {
    type         = var.identity_type
    identity_ids = var.identity_ids 
  }

  dynamic boot_diagnostics {
    for_each = var.storage_account_uri != null ? [1] : []
    content {
      storage_account_uri = var.storage_account_uri
    }
  }
 
  tags = merge(var.tags, {name = var.vm_name}, {hostname = var.vm_name})
 
}

#Manages a Virtual Machine Extension to provide post deployment configuration and run automated tasks.
resource "azurerm_virtual_machine_extension" "vme" {
  name                       = var.vm_extension_name
  virtual_machine_id         = azurerm_windows_virtual_machine.vm.id
  publisher                  = var.publisher
  type                       = var.type
  type_handler_version       = var.type_handler_version
  auto_upgrade_minor_version = var.auto_upgrade_minor_version
  tags                       = var.tags
}