variable "vm_name" {
  description = "(Required) The name of the Windows Virtual Machine. Changing this forces a new resource to be created."
  type = string
}
 
variable "tags" {
  type        = map(string)
  description = "(Optional) A mapping of tags which should be assigned to this Virtual Machine."
}
 
variable "resource_group_name" {
  type        = string
  description = "(Required) The name of the Resource Group in which the Windows Virtual Machine should be exist. Changing this forces a new resource to be created."
}
 
variable "location" {
  type        = string
  description = "(Required) The Azure location where the Windows Virtual Machine should exist. Changing this forces a new resource to be created."
}
 
variable "admin_username" {
  type        = string
  description = "Default Virtual Machine admin/root username"
  sensitive   = true
}
 
variable "vm_instance_type" {
  type        = string
  description = "Virtual Machine Image size"
}

variable "disk_controller_type" {
  type        = string
  description = "(Optional) Specifies the Disk Controller Type used for this Virtual Machine. Possible values are SCSI and NVMe."
}

variable "disk_storage_account_type" {
  type        = string
  description = "(Required) The Type of Storage Account which should back this the Internal OS Disk. Possible values are Standard_LRS, StandardSSD_LRS, Premium_LRS, StandardSSD_ZRS and Premium_ZRS. Changing this forces a new resource to be created."
}

variable "admin_password" {
  type        = string
  description = "(Required) The Password which should be used for the local-administrator on this Virtual Machine. Changing this forces a new resource to be created."
  sensitive   = true
}

variable "availability_set_id" {
  type        = string
  description = "(Optional) Specifies the ID of the Availability Set in which the Virtual Machine should exist. Changing this forces a new resource to be created."
}

variable "vtpm_enabled" {
  type        = bool
  description = "(Optional) Specifies if vTPM (virtual Trusted Platform Module) and Trusted Launch is enabled for the Virtual Machine. Changing this forces a new resource to be created."
}

variable "secure_boot_enabled" {
  type        = bool
  description = "(Optional) Specifies if Secure Boot and Trusted Launch is enabled for the Virtual Machine. Changing this forces a new resource to be created."
}

variable "license_type" {
  type        = string
  description = "(Optional) Specifies the type of on-premise license (also known as Azure Hybrid Use Benefit) which should be used for this Virtual Machine. Possible values are None, Windows_Client and Windows_Server."
}

variable "disk_encryption_set_id" {
  type        = string
  description = "(Optional) The ID of the Disk Encryption Set which should be used to Encrypt this OS Disk. Conflicts with secure_vm_disk_encryption_set_id."
}
 
variable "vm_source_image_id" {
  type        = string
  description = "Custom Virtual Machine Source Image ID. Set this value to the path of a local subscription Microsoft.Compute image to override the Cloud Connector deployment instead of using the marketplace publisher"
}

variable "zone" {
  type        = string
  description = "Specify which availability zone(s) to deploy VM resources in if zones_enabled variable is set to true"
}

variable "encryption_at_host_enabled" {
  type        = bool
  description = "User input for enabling or disabling host encryption"
}

variable "network_interface_ids" {
  type        = list(string)
  description = "(Required).A list of Network Interface IDs which should be attached to this Virtual Machine. The first Network Interface ID in this list will be the Primary Network Interface on the Virtual Machine."
}

variable "storage_account_uri" {
  type        = string
  description = "The Primary/Secondary Endpoint for the Azure Storage Account which should be used to store Boot Diagnostics, including Console Output and Screenshots from the Hypervisor."
}

variable "vm_os_disk_name" {
  type        = string
  description = "The name of the VM OS Disk."
}

#variables related to vm extensions
variable "vm_extension_name" {
    description = "(Required) The name of the virtual machine extension peering. Changing this forces a new resource to be created."
    type        = string
}

variable "publisher" {
    description = "(Required) The publisher of the extension, available publishers can be found by using the Azure CLI. Changing this forces a new resource to be created."
    type        = string
}

variable "type" {
    description = "(Required) The type of extension, available types for a publisher can be found using the Azure CLI."
    type        = string
}

variable "type_handler_version" {
    description = "(Required) Specifies the version of the extension to use, available versions can be found using the Azure CLI."
    type        = string
}

variable "auto_upgrade_minor_version" {
    description = "(Optional) Specifies if the platform deploys the latest minor version update to the type_handler_version specified."
    type        = bool
}
variable "identity_type" {
  description = "(Required) Specifies the type of Managed Service Identity that should be configured on this Windows Virtual Machine. Possible values are SystemAssigned, UserAssigned, SystemAssigned, UserAssigned (to enable both)."
  type = string
}
variable "identity_ids" {
  description = "(Optional) Specifies a list of User Assigned Managed Identity IDs to be assigned to this Windows Virtual Machine."
  type = list(string)
}
variable "vm_source_image_reference" {
  description = "Specifies the Source Image reference for the Virtual Machine"
  type = list(object({
    vm_image_publisher = string
    vm_image_offer     = string
    vm_image_version   = string
    vm_image_sku       = string
  }))
}
variable "plan_details" {
  description = "Specifies the Plan Details for the Virtual Machine"
  type = list(object({
    publisher = string
    name      = string
    product   = string
  }))
}