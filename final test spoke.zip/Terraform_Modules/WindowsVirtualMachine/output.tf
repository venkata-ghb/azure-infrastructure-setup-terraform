output "vm_hostname" {
  description = "The computer name of the Virtual Machine."
  value       = azurerm_windows_virtual_machine.vm.computer_name
}
output "vm_principal_id" {
  description = "The principal ID of the Virtual Machine."
  value = azurerm_windows_virtual_machine.vm.identity[0].principal_id
}
output "vm_id" {
  description = "The ID of the Virtual Machine."
  value = azurerm_windows_virtual_machine.vm.id
}
output "vm_name" {
  description = "The name of the Virtual Machine."
  value = azurerm_windows_virtual_machine.vm.name
}
output "vm_os_disk_name" {
  description = "The name of the OS Disk Virtual Machine."
  value = azurerm_windows_virtual_machine.vm.os_disk[0].name
}
output "vm_zone" {
  description = "The availability zone of the Virtual Machine"
  value       = try(azurerm_windows_virtual_machine.vm.zone, null)
}