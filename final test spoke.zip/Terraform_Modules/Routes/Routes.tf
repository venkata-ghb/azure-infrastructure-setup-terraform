#Manages a Route within a Route Table.
resource "azurerm_route" "routetableroute" {
  name                   = var.route_names
  resource_group_name    = var.resource_group_name
  route_table_name       = var.route_table_name
  address_prefix         = var.route_address_prefix
  next_hop_type          = var.next_hop_type
  next_hop_in_ip_address = alltrue([var.next_hop_type == "VirtualAppliance", length(var.next_hop_in_ip_address) > 0]) ? var.next_hop_in_ip_address : null

  lifecycle {
    ignore_changes = [ ]
  }
}