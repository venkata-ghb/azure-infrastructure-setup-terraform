resource "azurerm_role_assignment" "name" {
  scope = var.scope
  principal_id = var.principal_id
  role_definition_name = var.role_definition_name
}