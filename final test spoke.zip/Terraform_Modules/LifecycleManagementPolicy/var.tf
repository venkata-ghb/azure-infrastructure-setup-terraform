variable "storage_account_id" {
  description = "(Required) Specifies the id of the storage account to apply the management policy to."
  type        = string
}
variable "rule_name" {
  description = "(Required) A rule name can contain any combination of alpha numeric characters. Rule name is case-sensitive. It must be unique within a policy."
  type        = string
}

variable "rule_name_01" {
  description = "(Required) A rule name can contain any combination of alpha numeric characters. Rule name is case-sensitive. It must be unique within a policy."
  type        = string
}
variable "blob_types" {
  description = "An array of predefined values. Only blockBlob is supported."
  type        = list(string)
}
variable "delete_after_days_since_modification_greater_than" {
  description = "The age in days after last modification to delete the blob. Must be at least 0."
  type        = number
}
variable "rule_enabled" {
   description = " (Required) Boolean to specify whether the rule is enabled."
  type        = bool
}

variable "delete_after_days_since_creation_greater_than" {
  description = "The age in days after create to delete the snaphot. Must be at least 0."
  type        = number
}