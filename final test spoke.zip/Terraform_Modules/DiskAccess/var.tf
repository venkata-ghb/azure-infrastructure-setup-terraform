variable "disk_name" {
  description = "(Required) The name which should be used for this Disk Access. Changing this forces a new Disk Access to be created."
  type = string
}
variable "location" {
  description = "(Required) The Azure Region where the Disk Access should exist. Changing this forces a new Disk to be created."
  type = string
}
variable "tags" {
  description = "(Optional) A mapping of tags which should be assigned to the Disk Access."
  type = map(string)
}
variable "resource_group_name" {
  description = "(Required) The name of the Resource Group where the Disk Access should exist. Changing this forces a new Disk Access to be created."
  type = string
}