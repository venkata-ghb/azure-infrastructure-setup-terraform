output "disk_id" {
  description = "The ID of the Disk Access resource."
  value = azurerm_disk_access.disk.id
}
output "disk_name" {
  description = "The name of the Disk Access resource."
  value = azurerm_disk_access.disk.name
}