#Manages a Route Table
resource "azurerm_route_table" "routetable" {
  name                          = var.route_table_name
  location                      = var.location
  resource_group_name           = var.resource_group_name
  bgp_route_propagation_enabled = var.bgp_route_propagation_enabled
  tags                          = merge(var.tags, {name = var.route_table_name})
}