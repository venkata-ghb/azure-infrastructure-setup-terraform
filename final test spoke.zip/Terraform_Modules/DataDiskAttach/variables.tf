variable "disk_name" {
  description = "(Required) Specifies the name of the Managed Disk. Changing this forces a new resource to be created."
  type        = string
}

variable "resource_group_name" {
  description = "Specifies the name of the Resource Group in which the dqata disk should exist"
  type        = string
}

variable "location" {
  description = "Specifies the Azure Region where the respurce should exists"
  type        = string
}

variable "data_disk_sa_type" {
  description = "Specifies the storage account type of additional data disk"
  type        = string
}

variable "data_disk_create_option" {
  description = "(Required) The method to use when creating the managed disk. Changing this forces a new resource to be created."
  type        = string
}

variable "disk_size_gb" {
  description = "(Optional) (Optional, Required for a new managed disk) Specifies the size of the managed disk to create in gigabytes. If create_option is Copy or FromImage, then the value must be equal to or greater than the source's size. The size can only be increased."
  type        = string
}

variable "disk_encryption_set_id" {
  description = "(Optional) The ID of a Disk Encryption Set which should be used to encrypt this Managed Disk. Conflicts with secure_vm_disk_encryption_set_id."
  type = string
  
}
variable "zone" {
  description = "(Optional) Specifies the Availability Zone in which this Managed Disk should be located. Changing this property forces a new resource to be created."
  type        = string
}

variable "tags" {
  description = "A mapping of tags to al the resources"
  type        = map 
}

variable "vm_id" {
  description = "Specifies the id of virtual machines"
  type        = string
}

variable "lun" {
  description = " (Required) The Logical Unit Number of the Data Disk, which needs to be unique within the Virtual Machine. Changing this forces a new resource to be created."
  type        = string
}

variable "data_disk_caching" {
  description = "(Required) Specifies the caching requirements for this Data Disk. Possible values include None, ReadOnly and ReadWrite."
  type        = string
}

variable "data_disk_write_accelerator" {
  description = "Boolean flag to notify whether write accelerator for data disk enabled."
  type        = bool
}

variable "disk_access_id" {
  description = "(Optional) The ID of the disk access resource for using private endpoints on disks."
  type        = string
}
variable "public_network_access_enabled" {
  description = "(Optional) Whether it is allowed to access the disk via public network. Defaults to true."
  type        = bool
}
variable "network_access_policy" {
  description = "(Optional) Policy for accessing the disk via network. Allowed values are AllowAll, AllowPrivate, and DenyAll."
  type        = string
}