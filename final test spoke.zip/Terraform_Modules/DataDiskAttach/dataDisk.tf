#Manages a managed disk.
resource "azurerm_managed_disk" "data_disk" {

 name                           = var.disk_name
 location                       = var.location 
 resource_group_name            = var.resource_group_name 
 storage_account_type           = var.data_disk_sa_type
 create_option                  = var.data_disk_create_option
 disk_size_gb                   = var.disk_size_gb
 disk_encryption_set_id         = var.disk_encryption_set_id
 zone                           = var.zone == "" ? null : var.zone
 disk_access_id                 = var.disk_access_id
 hyper_v_generation             = "V2"
 public_network_access_enabled  = var.public_network_access_enabled
 network_access_policy             = var.network_access_policy
 tags                           = var.tags
  lifecycle {
    ignore_changes = [tags]
  }
}

#Manages Attaching a Disk to a Virtual Machine.
resource "azurerm_virtual_machine_data_disk_attachment" "attach_disk" {

  managed_disk_id               = azurerm_managed_disk.data_disk.id
  virtual_machine_id            = var.vm_id
  caching                       = var.data_disk_caching
  lun                           = var.lun
  write_accelerator_enabled     = var.data_disk_write_accelerator
}
