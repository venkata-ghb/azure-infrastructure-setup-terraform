output "datadisk_id" {
  description = "The ID of the Managed Disk"
  value = azurerm_managed_disk.data_disk.id
}