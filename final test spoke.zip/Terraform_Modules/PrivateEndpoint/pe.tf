resource "azurerm_private_endpoint" "pvtendpoint" {
  location                      = var.location
  name                          = var.pe_name
  resource_group_name           = var.resource_group_name
  subnet_id                     = var.subnet_id
  tags                          = merge( var.tags, { name = var.pe_name })
  custom_network_interface_name = var.custom_network_interface_name
  private_service_connection {
    is_manual_connection              = var.is_manual_connection
    name                              = var.private_service_connection_name
    private_connection_resource_id    = var.private_connection_resource_id
    subresource_names                 = var.subresource_names
  }

  private_dns_zone_group {
    name                 = var.pe_name
    private_dns_zone_ids = [var.private_dns_zone_ids[0]]
  }
}