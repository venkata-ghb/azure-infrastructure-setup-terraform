output "pe_id" {
  description = "The ID of the Private Endpoint."
  value = azurerm_private_endpoint.pvtendpoint.id
}
output "pe_name" {
  description = "The name of the Private Endpoint."
  value = azurerm_private_endpoint.pvtendpoint.name
}