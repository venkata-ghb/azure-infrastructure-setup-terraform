variable "disk_encryption_set_name" {
  description = "The name of the Disk Encryption Set. Changing this forces a new resource to be created."
  type = string
}
variable "resource_group_name" {
  description = "Specifies the name of the Resource Group where the Disk Encryption Set should exist. Changing this forces a new resource to be created."
  type = string
}
variable "location" {
  description = "Specifies the Azure Region where the Disk Encryption Set exists. Changing this forces a new resource to be created."
  type = string
}
variable "key_vault_key_id" {
  description = "Specifies the URL to a Key Vault Key (either from a Key Vault Key, or the Key URL for the Key Vault Secret). Exactly one of managed_hsm_key_id, key_vault_key_id must be specified."
  type = string
}

variable "key_vault_id" {
  description = "The keyvault ID"
  type        = string
}
variable "tags" {
  type        = map
  description = " (Optional) A mapping of tags to assign to the Disk Encryption Set"
}
variable "role_definition_name" {
  description = "The Role Assignment Name."
  type = string
}