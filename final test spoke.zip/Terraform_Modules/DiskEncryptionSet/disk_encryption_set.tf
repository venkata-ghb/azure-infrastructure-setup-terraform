#Manages a Disk Encryption Set.
resource "azurerm_disk_encryption_set" "disk_encription_set" {
  name                      = var.disk_encryption_set_name
  resource_group_name       = var.resource_group_name
  location                  = var.location
  key_vault_key_id          = var.key_vault_key_id
  identity {
    type = "SystemAssigned"
  }
  tags                      = merge( var.tags, { name = var.disk_encryption_set_name })

}

resource "azurerm_role_assignment" "rbac-disk" {
  scope                = var.key_vault_id
  role_definition_name = var.role_definition_name
  principal_id         = azurerm_disk_encryption_set.disk_encription_set.identity[0].principal_id
  depends_on = [ azurerm_disk_encryption_set.disk_encription_set ]
}
