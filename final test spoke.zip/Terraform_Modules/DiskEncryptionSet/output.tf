output "des_id" {
    description = "The ID of the Disk Encryption Set."
    value = azurerm_disk_encryption_set.disk_encription_set.id 
}

output "des_key_vault_key_url" {
    description = "The URL for the Key Vault Key or Key Vault Secret that is currently being used by the service.."
    value = azurerm_disk_encryption_set.disk_encription_set.key_vault_key_url
}

