resource "azurerm_subnet_network_security_group_association" "subnet_with_network_security_group" {
  network_security_group_id = var.sng_network_security_group_id
  subnet_id                 = var.sng_subnet_id
}