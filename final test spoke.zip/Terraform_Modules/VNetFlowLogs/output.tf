output "flowlog_id" {
  description = "The ID of the Network Watcher."
  value = azurerm_network_watcher_flow_log.test.id
}