resource "azurerm_network_watcher_flow_log" "test" {
  network_watcher_name  = var.network_watcher_name
  resource_group_name   = var.resource_group_name
  name                  = var.flow_log_name
  version               = var.flow_log_version
  target_resource_id    = var.vnet_id
  storage_account_id    = var.sta_id
  enabled               = var.enabled

  retention_policy {
    enabled = true
    days    = var.retention_days
  }

  traffic_analytics {
    enabled               = var.traffic_analytics_enabled
    workspace_id          = var.workspace_id
    workspace_region      = var.workspace_location
    workspace_resource_id = var.workspace_resource_id
    interval_in_minutes   = var.interval_in_minutes
  }
  tags = var.tags
}