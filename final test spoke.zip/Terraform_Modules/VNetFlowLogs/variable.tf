variable "network_watcher_name" {
description = "(Required) The name of the Network Watcher. Changing this forces a new resource to be created."
type = string
}
 
variable "resource_group_name" {
description = "(Required) The name of the resource group in which the Network Watcher was deployed. Changing this forces a new resource to be created."
type = string
}
 
variable "flow_log_name" {
description = "(Required) The name of the Network Watcher Flow Log. Changing this forces a new resource to be created."
type = string
}
 
variable "vnet_id" {
description = "(Required) The ID of the Resource for which to enable flow logs for. Changing this forces a new resource to be created."
type = string
}
 
variable "sta_id" {
description = "(Required) The ID of the Storage Account where flow logs are stored."
type = string
}
 
variable "enabled" {
description = "(Required) Should Network Flow Logging be Enabled?"
type = bool
}
 
variable "flow_log_version" {
description = "(Optional) The version (revision) of the flow log. Possible values are 1 and 2. Defaults to 1."
type = number
}
 
variable "retention_days" {
description = "(Required) The number of days to retain flow log records."
type = number
}
 
variable "traffic_analytics_enabled" {
description = "(Required) Boolean flag to enable/disable traffic analytics."
type = bool
}
 
variable "workspace_id" {
description = "(Required) The resource GUID of the attached workspace."
type = string
}
 
variable "workspace_location" {
description = "(Required) The location of the attached workspace."
type = string
}
 
variable "workspace_resource_id" {
description = "(Required) The resource ID of the attached workspace."
type = string
}
 
variable "interval_in_minutes" {
description = "(Optional) How frequently service should do flow analytics in minutes. Defaults to 60."
type = number
}
 
variable "tags" {
  description = "(Optional) A mapping of tags to assign to the resource."
  type        = map(string)
}