resource "azurerm_network_interface" "nic" {
    name                = var.nic_name
  location            = var.location
  resource_group_name = var.resource_group_name
 
  dynamic ip_configuration {
for_each = var.ip_configs == [] ? null: var.ip_configs
content {
    name                          = ip_configuration.value.ip_config_name == "" ? null : ip_configuration.value.ip_config_name
    subnet_id                     = var.subnet_id
    private_ip_address_allocation = ip_configuration.value.private_ip_address_allocation == "" ? null : ip_configuration.value.private_ip_address_allocation
    primary                       = ip_configuration.value.primary
  }
  }
 accelerated_networking_enabled   = var.accelerated_networking_enabled 
  tags = merge(var.tags, {name = var.nic_name})
}