
variable "nic_name" {
  description = "(Required) The name of the Network Interface. Changing this forces a new resource to be created."
  type = string 
  }

variable "tags" {
  type        = map(string)
  description = "Populate any custom user defined tags from a map"
}

variable "resource_group_name" {
  type        = string
  description = "(Required) The name of the Resource Group in which to create the Network Interface. Changing this forces a new resource to be created."
}

variable "location" {
  type        = string
  description = "(Required) The location where the Network Interface should exist. Changing this forces a new resource to be created."
}

variable "subnet_id" {
  type        = string
  description = "The id of subnet where the workload host has to be attached"
}

variable "ip_configs" {
  description = "specifies the ip configuration of the Network interface"
  type = list(object({
    ip_config_name = string
    private_ip_address_allocation = string
    primary = bool
  }))
}

variable "accelerated_networking_enabled" {
  type        = bool
  description = "Enable/Disable accelerated networking support on all Cloud Connector service interfaces"
}