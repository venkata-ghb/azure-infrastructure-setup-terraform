output "private_ip" {
  description = "The first private IP address of the network interface."
  value       = azurerm_network_interface.nic.private_ip_address
}

output "nic_id" {
  description = "The ID of the Network Interface."
  value = azurerm_network_interface.nic.id
}

output "nic_ids" {
  description = " The IDs of the Network Interface."
  value = [azurerm_network_interface.nic.id]
}