variable "key_vault_key_name" {
  description = "(Required) The name of Key Vault Key."
  type        = string
}

variable "key_vault_id" {
  description = "(Optional) The ID of the Key Vault. Exactly one of managed_hsm_key_id, key_vault_id, or key_vault_uri must be specified."
  type        = string
}

variable "storage_account_id" {
  description = "(Required) The ID of the Storage Account. Changing this forces a new resource to be created."
  type        = string
}
