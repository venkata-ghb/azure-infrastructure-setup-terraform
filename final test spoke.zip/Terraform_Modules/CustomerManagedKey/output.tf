output "stgaccount_id" {
  description = "The storage Account ID."
  value       = azurerm_storage_account_customer_managed_key.cmk.id
}
