variable "policy_name" {
  description = "(Required) The name of the policy definition. Changing this forces a new resource to be created."
  type = string
}
variable "display_name" {
    description = "(Required) The display name of the policy definition."
  type = string
}
variable "policy_mode" {
    description = " (Required) The policy resource manager mode that allows you to specify which resource types will be evaluated. Possible values are All, Indexed, Microsoft.ContainerService.Data, Microsoft.CustomerLockbox.Data, Microsoft.DataCatalog.Data, Microsoft.KeyVault.Data, Microsoft.Kubernetes.Data, Microsoft.MachineLearningServices.Data, Microsoft.Network.Data and Microsoft.Synapse.Data."
  type = string
}
variable "policy_description" {
    description = " (Optional) The description of the policy definition."
  type = string
}

variable "assignment_name" {
    description = " (Required) The name which should be used for this Policy Assignment. Possible values must be between 3 and 24 characters in length. Changing this forces a new Policy Assignment to be created."
  type = string
}
variable "enforce" {
   description = "(Optional) Specifies if this Policy should be enforced or not? Defaults to true."
  type = bool
}

variable "resource_ids" {
  type = map(string)
  description = "The resource ids as a map to assign the policy"
}