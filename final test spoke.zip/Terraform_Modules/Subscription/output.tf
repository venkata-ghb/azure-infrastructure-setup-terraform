output "subscription_id" {
  description = "The GUID of the subscription"
  value = azurerm_subscription.subscription.subscription_id
}