variable "exemption_name" {
  description = "(Required) The name of the Policy Exemption. Changing this forces a new resource to be created."
  type = string
}
variable "resource_id" {
  description = "(Required) The Resource ID where the Policy Exemption should be applied. Changing this forces a new resource to be created."
  type = string
}
variable "policy_assignment_id" {
  description = "(Required) The ID of the Policy Assignment to be exempted at the specified Scope. Changing this forces a new resource to be created."
  type = string
}
variable "exemption_expiry" {
  description = "(Optional) The expiration date and time in UTC ISO 8601 format of this policy exemption."
  type        = string
}

variable "exemption_display_name" {
  description = "(Optional) A friendly display name to use for this Policy Exemption."
  type = string
}

variable "exemption_description" {
  description = "(Optional) A description to use for this Policy Exemption."
  type = string
}