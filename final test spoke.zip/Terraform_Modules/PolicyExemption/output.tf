output "exemption_id" {
  description = "The Policy Exemption id."
  value       = azurerm_resource_policy_exemption.exemption.id
}
