resource "azurerm_resource_policy_exemption" "exemption" {
  name                 = var.exemption_name
  resource_id          = var.resource_id
  policy_assignment_id = var.policy_assignment_id
  exemption_category   = "Waiver"
  expires_on           = var.exemption_expiry
  display_name         = var.exemption_display_name 
  description          = var.exemption_description 
}