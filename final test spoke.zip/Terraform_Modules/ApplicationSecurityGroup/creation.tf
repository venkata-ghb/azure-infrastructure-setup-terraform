resource "azurerm_application_security_group" "asg" {
  name 	              = var.asg_name
  resource_group_name = var.resource_group_name
  location            = var.location
  tags                = merge(var.tags, {name = var.asg_name})
}