resource "azurerm_network_watcher" network_watcher {
  name                = var.nwr_name
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = merge(var.tags_NWR, {name = var.nwr_name})
}