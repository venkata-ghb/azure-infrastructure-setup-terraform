variable "nwr_name" {
  description   = "(Required) The name of the Network Watcher. Changing this forces a new resource to be created."
  type          = string
}
variable "location" {
  description   = "(Required) Specifies the supported Azure location where the resource exists. Changing this forces a new resource to be created."
  type          = string
}
variable "resource_group_name" {
  description   = "(Required) The name of the resource group in which to create the Network Watcher. Changing this forces a new resource to be created."
  type          = string
}
variable "tags_NWR" {
  description   = "A mapping of tags to assign to the resource."
  type          = map(string)
}