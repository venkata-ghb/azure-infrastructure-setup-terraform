output "network_watcher_name" {
  description = "The name of the Network Watcher."
  value       = azurerm_network_watcher.network_watcher.name
}
output "nwr_id" {
  description = "The ID of the Network Watcher."
  value       = azurerm_network_watcher.network_watcher.id
}