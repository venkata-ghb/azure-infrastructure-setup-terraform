variable "name" {
  description = "Specifies the name of the storage account."
  type = string
}
 
variable "location" {
  description = "Specifies the location where the Storage Account need to be created."
  type = string
}
 
variable "resource_group_name" {
  description = "Specifies the name of the resource group in which to create the storage account."
  type = string
}

variable "account_tier" {
  description = "Specifies the tier to use for the storage account. Valid options are Standard and Premium."
  type        = string
}
 
variable "access_tier" {
  description = "Specifies the tier to use for the storage account. Valid options are Hot, Cool, Cold and Archive."
  type        = string
}
variable "account_replication_type" {
  description = "Specifies the type of replication to use for the storage account. Valid options are LRS, GRS, RAGRS, ZRS, GZRS and RAGZRS."
  type        =  string
}
 
variable "cross_tenant_replication_enabled" {
  description = "Specifies the type of replication to use for the storage account. Valid options are LRS, GRS, RAGRS, ZRS, GZRS and RAGZRS."
  type        =  bool
}

variable "delete_retention_days" {
  description = "(Optional) Specifies the number of days that the container should be retained, between 1 and 365 days. Defaults to 7."
  type        = number
}

variable "is_hns_enabled" {
   description = "(Optional) Is Hierarchical Namespace enabled? This can be used with Azure Data Lake Storage Gen 2 (see here for more information). Changing this forces a new resource to be created."
  type        = bool
}

variable "container_delete_retention_days" {
  default = null
  description = "(Optional) Specifies the number of days that the container should be retained, between 1 and 365 days. Defaults to 7."
  type        = number
}
 
variable "tags" {
  description = "Specifies the mapping of tags to assign to the storage account."
  type        = map
}
 
variable "allow_blob_public_access" {
  description = "Allow or disallow public access to all blobs or containers in the storage account. Defaults to false."
  type        = bool
}
 
variable "public_network_access_enabled" {
  description = "Specifies whether the public network access is enabled or not. Defaults to true."
  type        = bool
}
 
variable "infrastructure_encryption_enabled" {
  description = "Specifies if the infrastructure encryption enabled or not.Changing this forces a new resource to be created. Defaults to false."
  type        = bool
  default     = null
}
 
variable "versioning_enabled" {
  description = "Specifies if the versioning enabled or not.Default to false"
  type        = bool
}

variable "large_file_share_enabled" {
  description = "(Optional) Are Large File Shares Enabled? Defaults to false."
  type = bool
}
variable "shared_access_key_enabled" {
  type = bool
}

variable "min_tls_version" {
  description = "The minimum supported TLS version for the storage account. Possible values are TLS1_0, TLS1_1, and TLS1_2. Defaults to TLS1_2 for new storage accounts."
  type        = string
}