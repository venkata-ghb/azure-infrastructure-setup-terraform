resource "azurerm_network_interface_application_security_group_association" "asg_nic_association" {
  network_interface_id          = var.nic_id
  application_security_group_id = var.asg_id
}