variable "nic_id" {
  type        = string
  description = " (Required) The ID of the Network Interface. Changing this forces a new resource to be created."
}

variable "asg_id" {
  type        = string
  description = "(Required) The ID of the Application Security Group which this Network Interface which should be connected to. Changing this forces a new resource to be created."
}
