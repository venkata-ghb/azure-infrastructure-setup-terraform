#Associates a Route Table with a Subnet within a Virtual Network.
resource "azurerm_subnet_route_table_association" "routetableassociation" {
  subnet_id                     = var.subnet_id
  route_table_id                = var.route_table_name_id
}