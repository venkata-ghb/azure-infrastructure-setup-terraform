output "subnet_id" {
  description = "The subnet ID."
  value       = azurerm_subnet.subnet.id
}
output "subnet_address_prefixes" {
  description = "The address prefixes for the subnet"
  value       = azurerm_subnet.subnet.address_prefixes
}
output "subnet_name" {
  description = "(Required) The name of the subnet. Changing this forces a new resource to be created."
  value = azurerm_subnet.subnet.name
}
output "subnet_address_prefix" {
  description = "The first address prefix for the subnet"
  value       = tolist(azurerm_subnet.subnet.address_prefixes)[0]
}
output "subnet_name_address_prefix_map" {
  description = "The map the name to the first address prefix for the subnet"
  value       = {
  (azurerm_subnet.subnet.name)  = (tolist(azurerm_subnet.subnet.address_prefixes)[0])
  }
}

output "subnet_name_id" {
  description = "The name of the subnet to the id of the subnet as map. Changing this forces a new resource to be created."
  value = { (azurerm_subnet.subnet.name) = (azurerm_subnet.subnet.id) }
}