output "kvk_id" {
  description = "The Key Vault Key ID."
  value       = azurerm_key_vault_key.key_vault_key.id
}
output "kvk_version" {
  description = "The current version of the Key Vault Key."
  value       = azurerm_key_vault_key.key_vault_key.version
}
output "kvk_versionless_id" {
  description = "The Base ID of the Key Vault Key."
  value       = azurerm_key_vault_key.key_vault_key.versionless_id
}
output "kvk_n" {
  description = "The RSA modulus of this Key Vault Key."
  value       = azurerm_key_vault_key.key_vault_key.n
}
output "kvk_e" {
  description = "The RSA public exponent of this Key Vault Key."
  value       = azurerm_key_vault_key.key_vault_key.e
}
output "kvk_x" {
  description = "The EC X component of this Key Vault Key."
  value       = azurerm_key_vault_key.key_vault_key.x
}
output "kvk_y" {
  description = "The EC Y component of this Key Vault Key."
  value       = azurerm_key_vault_key.key_vault_key.y
}
