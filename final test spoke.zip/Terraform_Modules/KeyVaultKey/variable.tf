variable "kv_key_name" {
  description = "(Required) Specifies the name of the Key Vault Key. Changing this forces a new resource to be created."
  type        = string
}

variable "key_vault_id" {
  description = "(Required) The ID of the Key Vault where the Key should be created. Changing this forces a new resource to be created."
  type        = string
}

variable "kv_key_type" {
  description = "(Required) Specifies the Key Type to use for this Key Vault Key. Possible values are EC (Elliptic Curve), EC-HSM, Oct (Octet), RSA and RSA-HSM. Changing this forces a new resource to be created."
  type        = string
}

variable "kv_key_opts" {
  default     = ["decrypt", "encrypt", "sign", "unwrapKey", "verify", "wrapKey"]
  description = "(Required) A list of JSON web key operations. Possible values include: decrypt, encrypt, sign, unwrapKey, verify and wrapKey. Please note these values are case sensitive."
  type        = list(string)
}

variable "kv_key_size" {
  default     = null
  description = "(Optional) Specifies the Size of the RSA key to create in bytes. For example, 1024 or 2048. Note: This field is required if key_type is RSA or RSA-HSM. Changing this forces a new resource to be created."
  type        = number
}
variable "expiration_date" {
  default     = null
  description = "(Optional) Expiration UTC datetime (Y-m-d'T'H:M:S'Z')."
  type        = string
}

variable "tags" {
  description   = "A mapping of tags to assign to the resource."
  type          = map(string)
}