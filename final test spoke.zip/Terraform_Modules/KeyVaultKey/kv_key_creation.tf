#Manages a Key Vault Key.
resource "azurerm_key_vault_key" "key_vault_key" {
  name            = var.kv_key_name
  key_vault_id    = var.key_vault_id
  key_type        = var.kv_key_type
  key_opts        = var.kv_key_opts

  key_size        = var.kv_key_size
  expiration_date = var.expiration_date

  tags            = merge( var.tags, { name = var.kv_key_name })
}
