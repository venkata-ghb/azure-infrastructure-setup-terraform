provider "azurerm" {
	features {}
	subscription_id					  = var.sa_subscription_id
	resource_provider_registrations = "none"
}
 provider "azurerm" {
 	features {}
 	alias			= "current_sub"
    subscription_id	= var.subscription_id
}
provider "azapi" {
   alias 			= "azapi"
}
provider "azurerm" {
   features {}
   alias 			= "network_manager_id"
   subscription_id  = var.network_manager_id
}
provider "azurerm" {
   features {}
   alias 			= "swc_iac_sub_id"
   subscription_id	= var.swc_iac_subscription_id
}
provider "azurerm" {
  features {}
  alias = "vhd_image"
  subscription_id = var.vhd_subscription_id
  resource_provider_registrations = "none"
}
provider "azurerm" {
  alias = "golden_win_image"
  subscription_id = var.golden_win_subscription_id
  resource_provider_registrations = "none"
  features {}
}
## For SWC resources from other Subscriptions
 provider "azurerm" {
   features {}
   alias 			= "swc_hub_sub_id"
   subscription_id	= var.swc_hub_subscription_id
}
provider "azurerm" {
   features {}
   alias 			= "swc_glb_sub_id"
   subscription_id	= var.swc_glb_subscription_id
}
## For INC resources from other Subscriptions
provider "azurerm" {
   features {}
   alias 			= "inc_hub_sub_id"
   subscription_id  = var.inc_hub_subscription_id
}
provider "azurerm" {
   features {}
   alias 			= "inc_glb_sub_id"
   subscription_id	= var.inc_glb_subscription_id
}