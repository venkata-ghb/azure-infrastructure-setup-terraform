###-------------------------------------------- Subscription ---------------------------------------
module "subscription" {
  source                   = "../../../Terraform_Modules/Subscription"
  subscription_name        = "ABB-${var.shortlocation}-${var.subscription_name}"
  alias                    = local.subscription_alias_name
  billing_scope_id         = data.azurerm_billing_enrollment_account_scope.enrollment_scope.id
  workload                 =  var.workload
  tags_sub                 = var.tags_sub
} 
###-------------------------------------------- Management Group Association ---------------------------------------
module "mg_association" {
  source              = "../../../Terraform_Modules/ManagementGroupAssociation"
  management_group_id = "/providers/Microsoft.Management/managementGroups/ABB-${var.mgshortlocation}-${var.management_group_id}"
  subscription_id     = "/subscriptions/${module.subscription.subscription_id}"
  depends_on          = [ module.subscription ]
}

output "new_subscription_id" {
  value = module.subscription.subscription_id
}