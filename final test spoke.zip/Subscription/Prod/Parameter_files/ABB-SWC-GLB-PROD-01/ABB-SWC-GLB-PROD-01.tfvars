###------------------------------------------- Subscription ----------------------------------
subscription_name           = "GLB-PROD-01"
billing_account_name        = "5099306"
enrollment_account_name     = "264764"
management_group_id         = "PROD-MGMTGRP" 
subscription_billing_scope  = "/providers/Microsoft.Billing/billingAccounts/5099306/enrollmentAccounts/264764"
workload                    = "Production"
tags_sub ={
    remark              = ""
    environment         = ""
    model               = "application"
    application         = ""
    costcenter          = "r220900"
    costcenterowner     = "tomasz.repinski1@pl.abb.com"
    country             = "global"
    owningbusinessarea  = "zc"
    owningdivision      = "zcgs"
    owningcompany       = "chgpl"
}
###------------------------------------------- Location ---------------------------------------
location        = "SwedenCentral"
shortlocation   = "SWC"
mgshortlocation = "SWC"
###------------------------------------------- Tags------ --------------------------------------
rg_tags ={
    itsmnr              = "WO1173"
    remark              = ""
    environment         = ""
    model               = "application"
    igar                = "9aag026594"
    application         = "cloud hosting service infrastructure"
    costcenter          = "52013300"
    costcenterowner     = "tomasz.repinski1@pl.abb.com"
    country             = "global"
    owningbusinessarea  = "zc"
    owningdivision      = "zcgs"
    owningcompany       = "chgpl"
}

cv_tags = {
    itsmnr                  = "WO1173"
    remark                  = ""
    environment             = ""
    model                   = "application"
    igar                    = "9aag029946"
    application             = "commvault"
    costcenter              = "52013004"
    costcenterowner         = "lars.helmersson@se.abb.com"
    country                 = "global"
    owningbusinessarea      = "zc"
    owningdivision          = "zcgs"
    owningcompany           = "chgpl"
}

sccm_tags = {
    itsmnr                  = "WO1173"
    remark                  = ""
    environment             = ""
    model                   = "application"
    igar                    = "9AAG033642"
    application             = "sccm cloud"
    costcenter              = "52013300"
    costcenterowner         = "maciej.zborowski@pl.abb.com"
    country                 = "global"
    owningbusinessarea      = "zc"
    owningdivision          = "zcgs"
    owningcompany           = "chgpl"
}

sl_tags = {
    itsmnr                  = ""
    remark                  = ""
    environment             = ""
    model                   = "Application"
    igar                    = "9aag029945"
    application             = "sciencelogic"
    costcenter              = "52013004"
    costcenterowner         = "lars.helmersson@se.abb.com"
    country                 = "global"
    owningbusinessarea      = "zc"
    owningdivision          = "zcco"
    owningcompany           = "chgpl"
}

ntw_watch_tags = {
    itsmnr    = "ritm5066418"
    remark = "BizTalk - required for whitlisting"
    environment = ""
    model = "application"
    igar = "9aag026594"
    application = "cloud hosting service infrastructure"
    costcenter = "52013300"
    costcenterowner = "tomasz.repinski1@pl.abb.com"
    country = "global"
    owningbusinessarea = "zc"
    owningdivision = "zcgs"
    owningcompany = "chgpl"
}
###-------------------------------------Resource Groups------------------------------------------
resource_groups = {
    "RG_ntw" =   {
        "name" = "GLBPROD01-RG-F-NETWORK"
    },
    "RG_app" =   {
        "name" = "GLBPROD01-RG-F-APP-01"
    },
    "RG_mgmt" =   {
        "name" = "GLBPROD01-RG-F-MGMT"
    }
}

resource_groups_cv = {
    "RG_cv" =   {
        "name" = "GLBPROD01-RG-C-9AAG029946"
    }
}

resource_groups_sccm = {
    "RG_sccm" =   {
        "name" = "GLBPROD01-RG-C-9AAG033642"
    }
}
resource_groups_sl = {
    "RG_sl" =   {
        "name" = "GLBPROD01-RG-C-9AAG029945"
    }
}
rg_ntw_watch = {
    "ntw_watch" = {
        "name" = "NetworkWatcherRG"
    }
}

#---------------------------------------Network Watcher----------------------------------------
network_watchers = {
    "networkwatcher" = {
    "nwr_name"            = "NetworkWatcher"
    "resource_group"      = "ntw_watch"
}
}
###---------------------------------------------- Vnets -------------------------------------------
vnets = {
    "vnet_z1a" =  {
        "vnet_name"           = "GLB-PROD-Z1A-VNET01",
        "vnet_address_space"  = ["10.234.128.0/21"],
        "resource_group"      = "RG_ntw"
        "dns_servers"         = ["10.16.7.12", "10.17.106.6", "168.63.129.16", "10.16.114.10", "10.16.113.6"]
        "vnet_tags"           = {
        "remark"              = ""
        }
    },
    "vnet_z1b" =  {
        "vnet_name"           = "GLB-PROD-Z1B-VNET01",
        "vnet_address_space"  = ["10.234.136.0/21"],
        "resource_group"      = "RG_ntw"
        "dns_servers"         = ["10.16.7.12", "10.17.106.6", "168.63.129.16", "10.16.114.10", "10.16.113.6"]
        "vnet_tags"           = {
        "remark"              = ""
        }
    },
    "vnet_z1c"  =  {
        "vnet_name"           = "GLB-PROD-Z1C-VNET01",
        "vnet_address_space"  = ["10.234.144.0/21"],
        "resource_group"      = "RG_ntw"
        "dns_servers"         = ["10.16.7.12", "10.17.106.6", "168.63.129.16", "10.16.114.10", "10.16.113.6"]
        "vnet_tags"           = {
        "remark"              = ""
        }
    },
    "vnet_z3"  =  {
        "vnet_name"           = "GLB-PROD-Z3-VNET01",
        "vnet_address_space"  = ["10.234.160.0/21"],
        "resource_group"      = "RG_ntw"
        "dns_servers"         = ["10.16.7.12", "10.17.106.6", "168.63.129.16", "10.16.114.10", "10.16.113.6"]
        "vnet_tags"           = {        
        "remark"              = ""
        }
    }
}
####--------------------------DDos Plan details in Hub-------------------------
ddos_protection_plan_enabled = true
ddos_shortlocation = "SWC"
ddos_name = "DDoS-01"
ddos_rg = "RG-F-NETWORK"
inc_hub_subscription_identifier = "HUB02"
swc_hub_subscription_identifier = "HUB01"
###-------------------------------------------- Subnets -------------------------------------------
        subnets = {
            "z1a_int01"           = {
                "snet_name"          = "GLB-PROD-Z1A-VNET01-INT01"
                "newbits"            = 3
                "netnum"             = 0
                "vnet_name"          = "vnet_z1a"
                "resource_group"     = "RG_ntw"  
                "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"]
            },

            "z1a_idmz01"           = {
                "snet_name"          = "GLB-PROD-Z1A-VNET01-IDMZ01"
                "newbits"            = 6
                "netnum"             = 32
                "vnet_name"          = "vnet_z1a"
                "resource_group"     = "RG_ntw"  
                "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"]
            },

            "z1a_edmz01"           = {
                "snet_name"          = "GLB-PROD-Z1A-VNET01-EDMZ01"
                "newbits"            = 6
                "netnum"             = 48
                "vnet_name"          = "vnet_z1a"
                "resource_group"     = "RG_ntw" 
                "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"] 
            },

            "z1a_edmz_pvtend01"       = {
                "snet_name"          = "GLB-PROD-Z1A-VNET01-EDMZ-PVTEND01"
                "newbits"            = 7
                "netnum"             = 127
                "vnet_name"          = "vnet_z1a"
                "resource_group"     = "RG_ntw" 
                "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"] 
            },

            "z1a_cv01"       = {
                "snet_name"          = "GLB-PROD-Z1A-VNET01-CV01"
                "newbits"            = 7
                "netnum"             = 63
                "vnet_name"          = "vnet_z1a"
                "resource_group"     = "RG_ntw" 
                "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"] 
            },

            "z1b_int01"            = {
                "snet_name"          = "GLB-PROD-Z1B-VNET01-INT01"
                "newbits"            = 6
                "netnum"             = 0
                "vnet_name"          = "vnet_z1b"
                "resource_group"     = "RG_ntw" 
                "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"]
            },

            "z1b_idmz01"            = {
                "snet_name"          = "GLB-PROD-Z1B-VNET01-IDMZ01"
                "newbits"            = 6
                "netnum"             = 32
                "vnet_name"          = "vnet_z1b"
                "resource_group"     = "RG_ntw" 
                "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"]
            },

            "z1b_edmz01"            = {
                "snet_name"          = "GLB-PROD-Z1B-VNET01-EDMZ01"
                "newbits"            = 6
                "netnum"             = 48
                "vnet_name"          = "vnet_z1b"
                "resource_group"     = "RG_ntw" 
                "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"]
            },

            "z1b_edmz_pvtend01"            = {
                "snet_name"          = "GLB-PROD-Z1B-VNET01-EDMZ-PVTEND01"
                "newbits"            = 7
                "netnum"             = 126
                "vnet_name"          = "vnet_z1b"
                "resource_group"     = "RG_ntw" 
                "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"]
            },

            "z1b_int_sox01"            = {
                "snet_name"          = "GLB-PROD-Z1B-VNET01-INT-SOX01"
                "newbits"            = 7
                "netnum"             = 63
                "vnet_name"          = "vnet_z1b"
                "resource_group"     = "RG_ntw"
                "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"] 
            },
            "z1b_idmz_sox01"            = {
                "snet_name"          = "GLB-PROD-Z1B-VNET01-IDMZ-SOX01"
                "newbits"            = 7
                "netnum"             = 95
                "vnet_name"          = "vnet_z1b"
                "resource_group"     = "RG_ntw" 
                "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"]
            },
            "z1b_edmz_sox01"            = {
                "snet_name"          = "GLB-PROD-Z1B-VNET01-EDMZ-SOX01"
                "newbits"            = 7
                "netnum"             = 127
                "vnet_name"          = "vnet_z1b"
                "resource_group"     = "RG_ntw" 
                "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"]
            },

            "z1b_cv01"       = {
                "snet_name"          = "GLB-PROD-Z1B-VNET01-CV01"
                "newbits"            = 7
                "netnum"             = 47
                "vnet_name"          = "vnet_z1b"
                "resource_group"     = "RG_ntw"  
                "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"]
            },

            "z1c_int01"            = {
                "snet_name"          = "GLB-PROD-Z1C-VNET01-INT01"
                "newbits"            = 6
                "netnum"             = 0
                "vnet_name"          = "vnet_z1c"
                "resource_group"     = "RG_ntw" 
                "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"]
            },

            "z1c_idmz01"            = {
                "snet_name"          = "GLB-PROD-Z1C-VNET01-IDMZ01"
                "newbits"            = 6
                "netnum"             = 32
                "vnet_name"          = "vnet_z1c"
                "resource_group"     = "RG_ntw" 
                "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"]
            },

            "z1c_edmz01"            = {
                "snet_name"          = "GLB-PROD-Z1C-VNET01-EDMZ01"
                "newbits"            = 6
                "netnum"             = 48
                "vnet_name"          = "vnet_z1c"
                "resource_group"     = "RG_ntw" 
                "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"]
            },

            "z1c_edmz_pvtend01"            = {
                "snet_name"          = "GLB-PROD-Z1C-VNET01-EDMZ-PVTEND01"
                "newbits"            = 7
                "netnum"             = 127
                "vnet_name"          = "vnet_z1c"
                "resource_group"     = "RG_ntw" 
                "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"]
            },

            "z1c_cv01"       = {
                "snet_name"          = "GLB-PROD-Z1C-VNET01-CV01"
                "newbits"            = 7
                "netnum"             = 61
                "vnet_name"          = "vnet_z1c"
                "resource_group"     = "RG_ntw"  
                "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"]
            },

            "z1c_sl01"       = {
                "snet_name"          = "GLB-PROD-Z1C-VNET01-SL01"
                "newbits"            = 7
                "netnum"             = 62
                "vnet_name"          = "vnet_z1c"
                "resource_group"     = "RG_ntw"  
                "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"]
            },

            "z1c_sccm01"       = {
                "snet_name"          = "GLB-PROD-Z1C-VNET01-SCCM01"
                "newbits"            = 7
                "netnum"             = 63
                "vnet_name"          = "vnet_z1c"
                "resource_group"     = "RG_ntw"  
                "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"]
            },


            "z3_int01"            = {
                "snet_name"          = "GLB-PROD-Z3-VNET01-INT01"
                "newbits"            = 3
                "netnum"             = 0
                "vnet_name"          = "vnet_z3"
                "resource_group"     = "RG_ntw" 
                "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"]
            },

            "z3_idmz01"            = {
                "snet_name"          = "GLB-PROD-Z3-VNET01-IDMZ01"
                "newbits"            = 6
                "netnum"             = 32
                "vnet_name"          = "vnet_z3"
                "resource_group"     = "RG_ntw" 
                "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"]
            },

            "z3_edmz01"            = {
                "snet_name"          = "GLB-PROD-Z3-VNET01-EDMZ01"
                "newbits"            = 6
                "netnum"             = 48
                "vnet_name"          = "vnet_z3"
                "resource_group"     = "RG_ntw" 
                "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"]
            },

            "z3_cv01"       = {
                "snet_name"          = "GLB-PROD-Z3-VNET01-CV01"
                "newbits"            = 7
                "netnum"             = 63
                "vnet_name"          = "vnet_z3"
                "resource_group"     = "RG_ntw"  
                "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"]
            },

            "z3_edmz_pvtend01"            = {
                "snet_name"          = "GLB-PROD-Z3-VNET01-EDMZ-PVTEND01"
                "newbits"            = 7
                "netnum"             = 127
                "vnet_name"          = "vnet_z3"
                "resource_group"     = "RG_ntw" 
                "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"]
            }
        } 

###--------------------------------------Route table---------------------------------------

route_table_names = {
    "z1a_edmz01" = {
        "name" = "GLB-PROD-Z1A-VNET01-EDMZ01-UDR01"
        "resource_group" = "RG_ntw"
        "rt_tags" = {
            "remark"    = ""
        }
    },
    "z1a_idmz01" = {
        "name" = "GLB-PROD-Z1A-VNET01-IDMZ01-UDR01"
        "resource_group" = "RG_ntw"
        "rt_tags" = {
            "remark"    = ""
        }
    },
    "z1a_int01" = {
        "name" = "GLB-PROD-Z1A-VNET01-INT01-UDR01"
        "resource_group" = "RG_ntw"
        "rt_tags" = {
            "remark"    = ""
        }
    },
    "z1a_cv01" = {
        "name" = "GLB-PROD-Z1A-VNET01-CV01-UDR01"
        "resource_group" = "RG_ntw"
        "rt_tags" = {
            "remark"    = ""
        }
    },
    "z1b_edmz_sox01" = {
        "name" = "GLB-PROD-Z1B-VNET01-EDMZ-SOX01-UDR01"
        "resource_group" = "RG_ntw"
        "rt_tags" = {
            "remark"    = ""
        }
    },
    "z1b_edmz01" = {
        "name" = "GLB-PROD-Z1B-VNET01-EDMZ01-UDR01"
        "resource_group" = "RG_ntw"
        "rt_tags" = {  
            "remark"    = ""
        }
    },
    "z1b_idmz_sox01" = {
        "name" = "GLB-PROD-Z1B-VNET01-IDMZ-SOX01-UDR01"
        "resource_group" = "RG_ntw"
        "rt_tags" = {   
            "remark"    = ""
        }
    },
    "z1b_idmz01" = {
        "name" = "GLB-PROD-Z1B-VNET01-IDMZ01-UDR01"
        "resource_group" = "RG_ntw"
        "rt_tags" = { 
            "remark"    = ""
        }
    },
    "z1b_int_sox01" = {
        "name" = "GLB-PROD-Z1B-VNET01-INT-SOX01-UDR01"
        "resource_group" = "RG_ntw"
        "rt_tags" = {
            "remark"    = ""
        }
    },
    "z1b_int01" = {
        "name" = "GLB-PROD-Z1B-VNET01-INT01-UDR01"
        "resource_group" = "RG_ntw"
        "rt_tags" = { 
            "remark"    = ""
        }
    },
    "z1b_cv01" = {
        "name" = "GLB-PROD-Z1B-VNET01-CV01-UDR01"
        "resource_group" = "RG_ntw"
        "rt_tags" = {  
            "remark"    = ""   
        }
    },
    "z1c_edmz01" = {
        "name" = "GLB-PROD-Z1C-VNET01-EDMZ01-UDR01"
        "resource_group" = "RG_ntw"
        "rt_tags" = {  
            "remark"    = ""
        }
    },
    "z1c_idmz01" = {
        "name" = "GLB-PROD-Z1C-VNET01-IDMZ01-UDR01"
        "resource_group" = "RG_ntw"
        "rt_tags" = {  
            "remark"    = ""
        }
    },
    "z1c_int01" = {
        "name" = "GLB-PROD-Z1C-VNET01-INT01-UDR01"
        "resource_group" = "RG_ntw"
        "rt_tags" = { 
            "remark"    = ""
        }
    },
    "z1c_cv01" = {
        "name" = "GLB-PROD-Z1C-VNET01-CV01-UDR01"
        "resource_group" = "RG_ntw"
        "rt_tags" = {
            "remark"    = ""  
        }
    },
    "z1c_sl01" = {
        "name" = "GLB-PROD-Z1C-VNET01-SL01-UDR01"
        "resource_group" = "RG_ntw"
        "rt_tags" = { 
            "remark"    = ""
        }
    },
    "z1c_sccm01" = {
        "name" = "GLB-PROD-Z1C-VNET01-SCCM01-UDR01"
        "resource_group" = "RG_ntw"
        "rt_tags" = {  
            "remark"    = ""
        }
    },
    "z3_edmz01" = {
        "name" = "GLB-PROD-Z3-VNET01-EDMZ01-UDR01"
        "resource_group" = "RG_ntw"
        "rt_tags" = {  
            "remark"    = ""
        }
    },
    "z3_idmz01" = {
        "name" = "GLB-PROD-Z3-VNET01-IDMZ01-UDR01"
        "resource_group" = "RG_ntw"
        "rt_tags" = {
            "remark"    = ""
        }
    },
    "z3_int01" = {
        "name" = "GLB-PROD-Z3-VNET01-INT01-UDR01"
        "resource_group" = "RG_ntw"
        "rt_tags" = {  
            "remark"    = ""
        }
    },
    "z3_cv01" = {
        "name" = "GLB-PROD-Z3-VNET01-CV01-UDR01"
        "resource_group" = "RG_ntw"
        "rt_tags" = {
            "remark"    = "" 
        }
    }
}

bgp_route_propagation_enabled = false

###-----------------------------------Route table - Subnet Associations---------------------------------------

RouteTableSubnetAssociations = {
    "z1a_edmz01" = {
        "route_table_name"       = "z1a_edmz01"
        "subnet_name"            = "z1a_edmz01"
    },
    "z1a_idmz01" = {
        "route_table_name"       = "z1a_idmz01"
        "subnet_name"            = "z1a_idmz01"
    },
    "z1a_int01" = {
        "route_table_name"       = "z1a_int01"
        "subnet_name"            = "z1a_int01"
    },
    "z1a_cv01" = {
        "route_table_name"       = "z1a_cv01"
        "subnet_name"            = "z1a_cv01"
    },
    "z1b_edmz_sox01" = {
        "route_table_name"       = "z1b_edmz_sox01"
        "subnet_name"            = "z1b_edmz_sox01"
    },
    "z1b_edmz01" = {
        "route_table_name"       = "z1b_edmz01"
        "subnet_name"            = "z1b_edmz01"
    },
    "z1b_idmz_sox01" = {
        "route_table_name"       = "z1b_idmz_sox01"
        "subnet_name"            = "z1b_idmz_sox01"
    },
    "z1b_idmz01" = {
        "route_table_name"       = "z1b_idmz01"
        "subnet_name"            = "z1b_idmz01"
    },
    "z1b_int_sox01" = {
        "route_table_name"       = "z1b_int_sox01"
        "subnet_name"            = "z1b_int_sox01"
    },
    "z1b_int01" = {
        "route_table_name"       = "z1b_int01"
        "subnet_name"            = "z1b_int01"
    },
    "z1b_cv01" = {
        "route_table_name"       = "z1b_cv01"
        "subnet_name"            = "z1b_cv01"
    },
    "z1c_edmz01" = {
        "route_table_name"       = "z1c_edmz01"
        "subnet_name"            = "z1c_edmz01"
    },
    "z1c_idmz01" = {
        "route_table_name"       = "z1c_idmz01"
        "subnet_name"            = "z1c_idmz01"
    },
    "z1c_int01" = {
        "route_table_name"       = "z1c_int01"
        "subnet_name"            = "z1c_int01"
    },
    "z1c_cv01" = {
        "route_table_name"       = "z1c_cv01"
        "subnet_name"            = "z1c_cv01"
    },
    "z1c_sl01" = {
        "route_table_name"       = "z1c_sl01"
        "subnet_name"            = "z1c_sl01"
    },
    "z1c_sccm01" = {
        "route_table_name"       = "z1c_sccm01"
        "subnet_name"            = "z1c_sccm01"
    },
    "z3_edmz01" = {
        "route_table_name"       = "z3_edmz01"
        "subnet_name"            = "z3_edmz01"
    },
    "z3_idmz01" = {
        "route_table_name"       = "z3_idmz01"
        "subnet_name"            = "z3_idmz01"
    },
    "z3_int01" = {
        "route_table_name"       = "z3_int01"
        "subnet_name"            = "z3_int01"
    },
    "z3_cv01" = {
        "route_table_name"       = "z3_cv01"
        "subnet_name"            = "z3_cv01"
    }
}

###--------------------------------------------Routes---------------------------------------
###--------------------------------------------Hub GLB FW and ZScaler details----------------------------------
glb-fw-lb-name = "backend-lb"
glb_fw_lb_rg = "RG-F-GLBFW"
zscaler-lb-name = "LLB-9AAG028759-01"
zscaler-rg = "RG-C-9AAG028759"

routes = {
"z1a_int01_abbnw01" = {
        "name"                    = "RTB-ABBNW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "10.0.0.0/8"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_int01_abbnw02" = {
        "name"                    = "RTB-ABBNW-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "138.224.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_int01_abbnw03" = {
        "name"                    = "RTB-ABBNW-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "138.222.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
   "z1a_int01_abbnw04" = {
        "name"                    = "RTB-ABBNW-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "138.226.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_int01_abbnw05" = {
        "name"                    = "RTB-ABBNW-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "172.16.0.0/12"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1a_int01_abbnw06" = {
        "name"                    = "RTB-ABBNW-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "130.110.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_int01_abbnw07" = {
        "name"                    = "RTB-ABBNW-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "137.133.128.0/17"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_int01_abbnw08" = {
        "name"                    = "RTB-ABBNW-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "138.221.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_int01_abbnw09" = {
        "name"                    = "RTB-ABBNW-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "138.223.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1a_int01_abbnw10" = {
        "name"                    = "RTB-ABBNW-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "138.227.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1a_int01_abbnw11" = {
        "name"                    = "RTB-ABBNW-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "138.228.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1a_int01_abbnw12" = {
        "name"                    = "RTB-ABBNW-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "192.125.60.0/22"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1a_int01_abbnw13" = {
        "name"                    = "RTB-ABBNW-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "100.64.0.0/10"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_int01_abbnw14" = {
        "name"                    = "RTB-ABBNW-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "193.45.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
    "z1a_int01_abbnw15" = {
        "name"                    = "RTB-ABBNW-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "193.71.72.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
  "z1a_int01_abbnw16" = {
        "name"                    = "RTB-ABBNW-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "193.75.73.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_int01_abbnw17" = {
        "name"                    = "RTB-ABBNW-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "193.164.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_int01_abbnw18" = {
        "name"                    = "RTB-ABBNW-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "198.113.64.0/18"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_int01_abbnw19" = {
        "name"                    = "RTB-ABBNW-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "129.35.205.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_int01_abbnw20" = {
        "name"                    = "RTB-ABBNW-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "129.35.207.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1a_int01_abbnw21" = {
        "name"                    = "RTB-ABBNW-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "80.75.192.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1a_int01_abbnw22" = {
        "name"                    = "RTB-ABBNW-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "80.75.195.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_int01_abbnw23" = {
        "name"                    = "RTB-ABBNW-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "145.241.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_int01_abbnw24" = {
        "name"                    = "RTB-ABBNW-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "204.231.112.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_int01_abbnw25" = {
        "name"                    = "RTB-ABBNW-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "206.208.208.0/23"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_int01_abbnw26" = {
        "name"                    = "RTB-ABBNW-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "210.24.147.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_int01_abbnw27" = {
        "name"                    = "RTB-ABBNW-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "193.164.24.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_int01_abbnw28" = {
        "name"                    = "RTB-ABBNW-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "193.164.31.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_idmz01_abbnw01" = {
        "name"                    = "RTB-ABBNW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "10.0.0.0/8"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_idmz01_abbnw02" = {
        "name"                    = "RTB-ABBNW-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "138.224.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_idmz01_abbnw03" = {
        "name"                    = "RTB-ABBNW-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "138.222.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
   "z1a_idmz01_abbnw04" = {
        "name"                    = "RTB-ABBNW-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "138.226.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_idmz01_abbnw05" = {
        "name"                    = "RTB-ABBNW-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "172.16.0.0/12"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1a_idmz01_abbnw06" = {
        "name"                    = "RTB-ABBNW-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "130.110.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_idmz01_abbnw07" = {
        "name"                    = "RTB-ABBNW-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "137.133.128.0/17"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_idmz01_abbnw08" = {
        "name"                    = "RTB-ABBNW-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "138.221.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_idmz01_abbnw09" = {
        "name"                    = "RTB-ABBNW-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "138.223.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1a_idmz01_abbnw10" = {
        "name"                    = "RTB-ABBNW-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "138.227.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1a_idmz01_abbnw11" = {
        "name"                    = "RTB-ABBNW-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "138.228.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1a_idmz01_abbnw12" = {
        "name"                    = "RTB-ABBNW-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "192.125.60.0/22"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1a_idmz01_abbnw13" = {
        "name"                    = "RTB-ABBNW-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "100.64.0.0/10"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_idmz01_abbnw14" = {
        "name"                    = "RTB-ABBNW-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "193.45.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
    "z1a_idmz01_abbnw15" = {
        "name"                    = "RTB-ABBNW-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "193.71.72.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
  "z1a_idmz01_abbnw16" = {
        "name"                    = "RTB-ABBNW-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "193.75.73.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_idmz01_abbnw17" = {
        "name"                    = "RTB-ABBNW-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "193.164.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_idmz01_abbnw18" = {
        "name"                    = "RTB-ABBNW-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "198.113.64.0/18"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_idmz01_abbnw19" = {
        "name"                    = "RTB-ABBNW-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "129.35.205.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_idmz01_abbnw20" = {
        "name"                    = "RTB-ABBNW-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "129.35.207.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1a_idmz01_abbnw21" = {
        "name"                    = "RTB-ABBNW-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "80.75.192.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1a_idmz01_abbnw22" = {
        "name"                    = "RTB-ABBNW-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "80.75.195.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_idmz01_abbnw23" = {
        "name"                    = "RTB-ABBNW-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "145.241.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_idmz01_abbnw24" = {
        "name"                    = "RTB-ABBNW-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "204.231.112.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_idmz01_abbnw25" = {
        "name"                    = "RTB-ABBNW-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "206.208.208.0/23"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_idmz01_abbnw26" = {
        "name"                    = "RTB-ABBNW-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "210.24.147.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_idmz01_abbnw27" = {
        "name"                    = "RTB-ABBNW-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "193.164.24.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_idmz01_abbnw28" = {
        "name"                    = "RTB-ABBNW-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "193.164.31.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_cv01_abbnw01" = {
        "name"                    = "RTB-ABBNW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "10.0.0.0/8"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_cv01_abbnw02" = {
        "name"                    = "RTB-ABBNW-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "138.224.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_cv01_abbnw03" = {
        "name"                    = "RTB-ABBNW-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "138.222.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
   "z1a_cv01_abbnw04" = {
        "name"                    = "RTB-ABBNW-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "138.226.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_cv01_abbnw05" = {
        "name"                    = "RTB-ABBNW-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "172.16.0.0/12"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1a_cv01_abbnw06" = {
        "name"                    = "RTB-ABBNW-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "130.110.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_cv01_abbnw07" = {
        "name"                    = "RTB-ABBNW-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "137.133.128.0/17"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_cv01_abbnw08" = {
        "name"                    = "RTB-ABBNW-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "138.221.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_cv01_abbnw09" = {
        "name"                    = "RTB-ABBNW-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "138.223.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1a_cv01_abbnw10" = {
        "name"                    = "RTB-ABBNW-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "138.227.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1a_cv01_abbnw11" = {
        "name"                    = "RTB-ABBNW-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "138.228.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1a_cv01_abbnw12" = {
        "name"                    = "RTB-ABBNW-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "192.125.60.0/22"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1a_cv01_abbnw13" = {
        "name"                    = "RTB-ABBNW-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "100.64.0.0/10"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_cv01_abbnw14" = {
        "name"                    = "RTB-ABBNW-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "193.45.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
    "z1a_cv01_abbnw15" = {
        "name"                    = "RTB-ABBNW-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "193.71.72.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
  "z1a_cv01_abbnw16" = {
        "name"                    = "RTB-ABBNW-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "193.75.73.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_cv01_abbnw17" = {
        "name"                    = "RTB-ABBNW-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "193.164.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_cv01_abbnw18" = {
        "name"                    = "RTB-ABBNW-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "198.113.64.0/18"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_cv01_abbnw19" = {
        "name"                    = "RTB-ABBNW-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "129.35.205.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_cv01_abbnw20" = {
        "name"                    = "RTB-ABBNW-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "129.35.207.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1a_cv01_abbnw21" = {
        "name"                    = "RTB-ABBNW-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "80.75.192.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1a_cv01_abbnw22" = {
        "name"                    = "RTB-ABBNW-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "80.75.195.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_cv01_abbnw23" = {
        "name"                    = "RTB-ABBNW-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "145.241.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_cv01_abbnw24" = {
        "name"                    = "RTB-ABBNW-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "204.231.112.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_cv01_abbnw25" = {
        "name"                    = "RTB-ABBNW-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "206.208.208.0/23"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_cv01_abbnw26" = {
        "name"                    = "RTB-ABBNW-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "210.24.147.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_cv01_abbnw27" = {
        "name"                    = "RTB-ABBNW-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "193.164.24.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_cv01_abbnw28" = {
        "name"                    = "RTB-ABBNW-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "193.164.31.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_edmz_sox01_abbnw01" = {
        "name"                    = "RTB-ABBNW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "10.0.0.0/8"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_edmz_sox01_abbnw02" = {
        "name"                    = "RTB-ABBNW-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "138.224.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_edmz_sox01_abbnw03" = {
        "name"                    = "RTB-ABBNW-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "138.222.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
   "z1b_edmz_sox01_abbnw04" = {
        "name"                    = "RTB-ABBNW-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "138.226.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_edmz_sox01_abbnw05" = {
        "name"                    = "RTB-ABBNW-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "172.16.0.0/12"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_edmz_sox01_abbnw06" = {
        "name"                    = "RTB-ABBNW-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "130.110.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_edmz_sox01_abbnw07" = {
        "name"                    = "RTB-ABBNW-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "137.133.128.0/17"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_edmz_sox01_abbnw08" = {
        "name"                    = "RTB-ABBNW-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "138.221.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_edmz_sox01_abbnw09" = {
        "name"                    = "RTB-ABBNW-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "138.223.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_edmz_sox01_abbnw10" = {
        "name"                    = "RTB-ABBNW-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "138.227.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_edmz_sox01_abbnw11" = {
        "name"                    = "RTB-ABBNW-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "138.228.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_edmz_sox01_abbnw12" = {
        "name"                    = "RTB-ABBNW-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "192.125.60.0/22"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_edmz_sox01_abbnw13" = {
        "name"                    = "RTB-ABBNW-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "100.64.0.0/10"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_edmz_sox01_abbnw14" = {
        "name"                    = "RTB-ABBNW-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "193.45.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
    "z1b_edmz_sox01_abbnw15" = {
        "name"                    = "RTB-ABBNW-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "193.71.72.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
  "z1b_edmz_sox01_abbnw16" = {
        "name"                    = "RTB-ABBNW-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "193.75.73.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_edmz_sox01_abbnw17" = {
        "name"                    = "RTB-ABBNW-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "193.164.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_edmz_sox01_abbnw18" = {
        "name"                    = "RTB-ABBNW-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "198.113.64.0/18"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_edmz_sox01_abbnw19" = {
        "name"                    = "RTB-ABBNW-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "129.35.205.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_edmz_sox01_abbnw20" = {
        "name"                    = "RTB-ABBNW-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "129.35.207.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_edmz_sox01_abbnw21" = {
        "name"                    = "RTB-ABBNW-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "80.75.192.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_edmz_sox01_abbnw22" = {
        "name"                    = "RTB-ABBNW-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "80.75.195.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_edmz_sox01_abbnw23" = {
        "name"                    = "RTB-ABBNW-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "145.241.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_edmz_sox01_abbnw24" = {
        "name"                    = "RTB-ABBNW-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "204.231.112.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_edmz_sox01_abbnw25" = {
        "name"                    = "RTB-ABBNW-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "206.208.208.0/23"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_edmz_sox01_abbnw26" = {
        "name"                    = "RTB-ABBNW-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "210.24.147.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_edmz_sox01_abbnw27" = {
        "name"                    = "RTB-ABBNW-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "193.164.24.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_edmz_sox01_abbnw28" = {
        "name"                    = "RTB-ABBNW-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "193.164.31.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz_sox01_abbnw01" = {
        "name"                    = "RTB-ABBNW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "10.0.0.0/8"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz_sox01_abbnw02" = {
        "name"                    = "RTB-ABBNW-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "138.224.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz_sox01_abbnw03" = {
        "name"                    = "RTB-ABBNW-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "138.222.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
   "z1b_idmz_sox01_abbnw04" = {
        "name"                    = "RTB-ABBNW-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "138.226.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz_sox01_abbnw05" = {
        "name"                    = "RTB-ABBNW-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "172.16.0.0/12"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_idmz_sox01_abbnw06" = {
        "name"                    = "RTB-ABBNW-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "130.110.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz_sox01_abbnw07" = {
        "name"                    = "RTB-ABBNW-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "137.133.128.0/17"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz_sox01_abbnw08" = {
        "name"                    = "RTB-ABBNW-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "138.221.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz_sox01_abbnw09" = {
        "name"                    = "RTB-ABBNW-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "138.223.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_idmz_sox01_abbnw10" = {
        "name"                    = "RTB-ABBNW-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "138.227.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_idmz_sox01_abbnw11" = {
        "name"                    = "RTB-ABBNW-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "138.228.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_idmz_sox01_abbnw12" = {
        "name"                    = "RTB-ABBNW-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "192.125.60.0/22"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_idmz_sox01_abbnw13" = {
        "name"                    = "RTB-ABBNW-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "100.64.0.0/10"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz_sox01_abbnw14" = {
        "name"                    = "RTB-ABBNW-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "193.45.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
    "z1b_idmz_sox01_abbnw15" = {
        "name"                    = "RTB-ABBNW-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "193.71.72.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
  "z1b_idmz_sox01_abbnw16" = {
        "name"                    = "RTB-ABBNW-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "193.75.73.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz_sox01_abbnw17" = {
        "name"                    = "RTB-ABBNW-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "193.164.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz_sox01_abbnw18" = {
        "name"                    = "RTB-ABBNW-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "198.113.64.0/18"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz_sox01_abbnw19" = {
        "name"                    = "RTB-ABBNW-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "129.35.205.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz_sox01_abbnw20" = {
        "name"                    = "RTB-ABBNW-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "129.35.207.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_idmz_sox01_abbnw21" = {
        "name"                    = "RTB-ABBNW-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "80.75.192.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_idmz_sox01_abbnw22" = {
        "name"                    = "RTB-ABBNW-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "80.75.195.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz_sox01_abbnw23" = {
        "name"                    = "RTB-ABBNW-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "145.241.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz_sox01_abbnw24" = {
        "name"                    = "RTB-ABBNW-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "204.231.112.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz_sox01_abbnw25" = {
        "name"                    = "RTB-ABBNW-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "206.208.208.0/23"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz_sox01_abbnw26" = {
        "name"                    = "RTB-ABBNW-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "210.24.147.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz_sox01_abbnw27" = {
        "name"                    = "RTB-ABBNW-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "193.164.24.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz_sox01_abbnw28" = {
        "name"                    = "RTB-ABBNW-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "193.164.31.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int_sox01_abbnw01" = {
        "name"                    = "RTB-ABBNW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "10.0.0.0/8"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int_sox01_abbnw02" = {
        "name"                    = "RTB-ABBNW-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "138.224.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int_sox01_abbnw03" = {
        "name"                    = "RTB-ABBNW-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "138.222.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
   "z1b_int_sox01_abbnw04" = {
        "name"                    = "RTB-ABBNW-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "138.226.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int_sox01_abbnw05" = {
        "name"                    = "RTB-ABBNW-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "172.16.0.0/12"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_int_sox01_abbnw06" = {
        "name"                    = "RTB-ABBNW-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "130.110.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int_sox01_abbnw07" = {
        "name"                    = "RTB-ABBNW-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "137.133.128.0/17"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int_sox01_abbnw08" = {
        "name"                    = "RTB-ABBNW-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "138.221.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int_sox01_abbnw09" = {
        "name"                    = "RTB-ABBNW-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "138.223.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_int_sox01_abbnw10" = {
        "name"                    = "RTB-ABBNW-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "138.227.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_int_sox01_abbnw11" = {
        "name"                    = "RTB-ABBNW-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "138.228.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_int_sox01_abbnw12" = {
        "name"                    = "RTB-ABBNW-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "192.125.60.0/22"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_int_sox01_abbnw13" = {
        "name"                    = "RTB-ABBNW-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "100.64.0.0/10"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int_sox01_abbnw14" = {
        "name"                    = "RTB-ABBNW-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "193.45.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
    "z1b_int_sox01_abbnw15" = {
        "name"                    = "RTB-ABBNW-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "193.71.72.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
  "z1b_int_sox01_abbnw16" = {
        "name"                    = "RTB-ABBNW-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "193.75.73.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int_sox01_abbnw17" = {
        "name"                    = "RTB-ABBNW-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "193.164.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int_sox01_abbnw18" = {
        "name"                    = "RTB-ABBNW-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "198.113.64.0/18"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int_sox01_abbnw19" = {
        "name"                    = "RTB-ABBNW-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "129.35.205.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int_sox01_abbnw20" = {
        "name"                    = "RTB-ABBNW-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "129.35.207.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_int_sox01_abbnw21" = {
        "name"                    = "RTB-ABBNW-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "80.75.192.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_int_sox01_abbnw22" = {
        "name"                    = "RTB-ABBNW-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "80.75.195.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int_sox01_abbnw23" = {
        "name"                    = "RTB-ABBNW-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "145.241.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int_sox01_abbnw24" = {
        "name"                    = "RTB-ABBNW-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "204.231.112.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int_sox01_abbnw25" = {
        "name"                    = "RTB-ABBNW-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "206.208.208.0/23"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int_sox01_abbnw26" = {
        "name"                    = "RTB-ABBNW-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "210.24.147.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int_sox01_abbnw27" = {
        "name"                    = "RTB-ABBNW-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "193.164.24.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int_sox01_abbnw28" = {
        "name"                    = "RTB-ABBNW-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "193.164.31.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int01_abbnw01" = {
        "name"                    = "RTB-ABBNW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "10.0.0.0/8"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int01_abbnw02" = {
        "name"                    = "RTB-ABBNW-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "138.224.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int01_abbnw03" = {
        "name"                    = "RTB-ABBNW-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "138.222.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
   "z1b_int01_abbnw04" = {
        "name"                    = "RTB-ABBNW-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "138.226.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int01_abbnw05" = {
        "name"                    = "RTB-ABBNW-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "172.16.0.0/12"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_int01_abbnw06" = {
        "name"                    = "RTB-ABBNW-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "130.110.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int01_abbnw07" = {
        "name"                    = "RTB-ABBNW-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "137.133.128.0/17"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int01_abbnw08" = {
        "name"                    = "RTB-ABBNW-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "138.221.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int01_abbnw09" = {
        "name"                    = "RTB-ABBNW-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "138.223.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_int01_abbnw10" = {
        "name"                    = "RTB-ABBNW-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "138.227.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_int01_abbnw11" = {
        "name"                    = "RTB-ABBNW-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "138.228.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_int01_abbnw12" = {
        "name"                    = "RTB-ABBNW-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "192.125.60.0/22"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_int01_abbnw13" = {
        "name"                    = "RTB-ABBNW-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "100.64.0.0/10"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int01_abbnw14" = {
        "name"                    = "RTB-ABBNW-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "193.45.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
    "z1b_int01_abbnw15" = {
        "name"                    = "RTB-ABBNW-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "193.71.72.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
  "z1b_int01_abbnw16" = {
        "name"                    = "RTB-ABBNW-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "193.75.73.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int01_abbnw17" = {
        "name"                    = "RTB-ABBNW-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "193.164.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int01_abbnw18" = {
        "name"                    = "RTB-ABBNW-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "198.113.64.0/18"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int01_abbnw19" = {
        "name"                    = "RTB-ABBNW-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "129.35.205.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int01_abbnw20" = {
        "name"                    = "RTB-ABBNW-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "129.35.207.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_int01_abbnw21" = {
        "name"                    = "RTB-ABBNW-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "80.75.192.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_int01_abbnw22" = {
        "name"                    = "RTB-ABBNW-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "80.75.195.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int01_abbnw23" = {
        "name"                    = "RTB-ABBNW-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "145.241.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int01_abbnw24" = {
        "name"                    = "RTB-ABBNW-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "204.231.112.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int01_abbnw25" = {
        "name"                    = "RTB-ABBNW-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "206.208.208.0/23"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int01_abbnw26" = {
        "name"                    = "RTB-ABBNW-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "210.24.147.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int01_abbnw27" = {
        "name"                    = "RTB-ABBNW-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "193.164.24.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_int01_abbnw28" = {
        "name"                    = "RTB-ABBNW-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "193.164.31.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz01_abbnw01" = {
        "name"                    = "RTB-ABBNW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "10.0.0.0/8"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz01_abbnw02" = {
        "name"                    = "RTB-ABBNW-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "138.224.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz01_abbnw03" = {
        "name"                    = "RTB-ABBNW-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "138.222.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
   "z1b_idmz01_abbnw04" = {
        "name"                    = "RTB-ABBNW-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "138.226.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz01_abbnw05" = {
        "name"                    = "RTB-ABBNW-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "172.16.0.0/12"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_idmz01_abbnw06" = {
        "name"                    = "RTB-ABBNW-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "130.110.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz01_abbnw07" = {
        "name"                    = "RTB-ABBNW-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "137.133.128.0/17"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz01_abbnw08" = {
        "name"                    = "RTB-ABBNW-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "138.221.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz01_abbnw09" = {
        "name"                    = "RTB-ABBNW-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "138.223.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_idmz01_abbnw10" = {
        "name"                    = "RTB-ABBNW-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "138.227.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_idmz01_abbnw11" = {
        "name"                    = "RTB-ABBNW-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "138.228.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_idmz01_abbnw12" = {
        "name"                    = "RTB-ABBNW-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "192.125.60.0/22"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_idmz01_abbnw13" = {
        "name"                    = "RTB-ABBNW-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "100.64.0.0/10"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz01_abbnw14" = {
        "name"                    = "RTB-ABBNW-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "193.45.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
    "z1b_idmz01_abbnw15" = {
        "name"                    = "RTB-ABBNW-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "193.71.72.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
  "z1b_idmz01_abbnw16" = {
        "name"                    = "RTB-ABBNW-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "193.75.73.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz01_abbnw17" = {
        "name"                    = "RTB-ABBNW-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "193.164.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz01_abbnw18" = {
        "name"                    = "RTB-ABBNW-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "198.113.64.0/18"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz01_abbnw19" = {
        "name"                    = "RTB-ABBNW-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "129.35.205.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz01_abbnw20" = {
        "name"                    = "RTB-ABBNW-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "129.35.207.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_idmz01_abbnw21" = {
        "name"                    = "RTB-ABBNW-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "80.75.192.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_idmz01_abbnw22" = {
        "name"                    = "RTB-ABBNW-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "80.75.195.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz01_abbnw23" = {
        "name"                    = "RTB-ABBNW-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "145.241.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz01_abbnw24" = {
        "name"                    = "RTB-ABBNW-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "204.231.112.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz01_abbnw25" = {
        "name"                    = "RTB-ABBNW-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "206.208.208.0/23"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz01_abbnw26" = {
        "name"                    = "RTB-ABBNW-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "210.24.147.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz01_abbnw27" = {
        "name"                    = "RTB-ABBNW-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "193.164.24.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_idmz01_abbnw28" = {
        "name"                    = "RTB-ABBNW-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "193.164.31.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_cv01_abbnw01" = {
        "name"                    = "RTB-ABBNW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "10.0.0.0/8"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_cv01_abbnw02" = {
        "name"                    = "RTB-ABBNW-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "138.224.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_cv01_abbnw03" = {
        "name"                    = "RTB-ABBNW-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "138.222.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
   "z1b_cv01_abbnw04" = {
        "name"                    = "RTB-ABBNW-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "138.226.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_cv01_abbnw05" = {
        "name"                    = "RTB-ABBNW-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "172.16.0.0/12"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_cv01_abbnw06" = {
        "name"                    = "RTB-ABBNW-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "130.110.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_cv01_abbnw07" = {
        "name"                    = "RTB-ABBNW-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "137.133.128.0/17"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_cv01_abbnw08" = {
        "name"                    = "RTB-ABBNW-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "138.221.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_cv01_abbnw09" = {
        "name"                    = "RTB-ABBNW-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "138.223.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_cv01_abbnw10" = {
        "name"                    = "RTB-ABBNW-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "138.227.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_cv01_abbnw11" = {
        "name"                    = "RTB-ABBNW-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "138.228.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_cv01_abbnw12" = {
        "name"                    = "RTB-ABBNW-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "192.125.60.0/22"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_cv01_abbnw13" = {
        "name"                    = "RTB-ABBNW-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "100.64.0.0/10"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_cv01_abbnw14" = {
        "name"                    = "RTB-ABBNW-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "193.45.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
    "z1b_cv01_abbnw15" = {
        "name"                    = "RTB-ABBNW-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "193.71.72.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
  "z1b_cv01_abbnw16" = {
        "name"                    = "RTB-ABBNW-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "193.75.73.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_cv01_abbnw17" = {
        "name"                    = "RTB-ABBNW-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "193.164.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_cv01_abbnw18" = {
        "name"                    = "RTB-ABBNW-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "198.113.64.0/18"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_cv01_abbnw19" = {
        "name"                    = "RTB-ABBNW-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "129.35.205.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_cv01_abbnw20" = {
        "name"                    = "RTB-ABBNW-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "129.35.207.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_cv01_abbnw21" = {
        "name"                    = "RTB-ABBNW-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "80.75.192.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1b_cv01_abbnw22" = {
        "name"                    = "RTB-ABBNW-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "80.75.195.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_cv01_abbnw23" = {
        "name"                    = "RTB-ABBNW-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "145.241.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_cv01_abbnw24" = {
        "name"                    = "RTB-ABBNW-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "204.231.112.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_cv01_abbnw25" = {
        "name"                    = "RTB-ABBNW-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "206.208.208.0/23"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_cv01_abbnw26" = {
        "name"                    = "RTB-ABBNW-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "210.24.147.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_cv01_abbnw27" = {
        "name"                    = "RTB-ABBNW-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "193.164.24.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1b_cv01_abbnw28" = {
        "name"                    = "RTB-ABBNW-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "193.164.31.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_idmz01_abbnw01" = {
        "name"                    = "RTB-ABBNW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "10.0.0.0/8"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_idmz01_abbnw02" = {
        "name"                    = "RTB-ABBNW-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "138.224.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_idmz01_abbnw03" = {
        "name"                    = "RTB-ABBNW-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "138.222.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
   "z1c_idmz01_abbnw04" = {
        "name"                    = "RTB-ABBNW-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "138.226.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_idmz01_abbnw05" = {
        "name"                    = "RTB-ABBNW-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "172.16.0.0/12"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_idmz01_abbnw06" = {
        "name"                    = "RTB-ABBNW-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "130.110.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_idmz01_abbnw07" = {
        "name"                    = "RTB-ABBNW-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "137.133.128.0/17"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_idmz01_abbnw08" = {
        "name"                    = "RTB-ABBNW-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "138.221.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_idmz01_abbnw09" = {
        "name"                    = "RTB-ABBNW-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "138.223.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_idmz01_abbnw10" = {
        "name"                    = "RTB-ABBNW-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "138.227.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_idmz01_abbnw11" = {
        "name"                    = "RTB-ABBNW-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "138.228.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_idmz01_abbnw12" = {
        "name"                    = "RTB-ABBNW-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "192.125.60.0/22"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_idmz01_abbnw13" = {
        "name"                    = "RTB-ABBNW-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "100.64.0.0/10"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_idmz01_abbnw14" = {
        "name"                    = "RTB-ABBNW-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "193.45.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
    "z1c_idmz01_abbnw15" = {
        "name"                    = "RTB-ABBNW-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "193.71.72.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
  "z1c_idmz01_abbnw16" = {
        "name"                    = "RTB-ABBNW-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "193.75.73.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_idmz01_abbnw17" = {
        "name"                    = "RTB-ABBNW-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "193.164.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_idmz01_abbnw18" = {
        "name"                    = "RTB-ABBNW-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "198.113.64.0/18"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_idmz01_abbnw19" = {
        "name"                    = "RTB-ABBNW-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "129.35.205.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_idmz01_abbnw20" = {
        "name"                    = "RTB-ABBNW-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "129.35.207.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_idmz01_abbnw21" = {
        "name"                    = "RTB-ABBNW-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "80.75.192.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_idmz01_abbnw22" = {
        "name"                    = "RTB-ABBNW-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "80.75.195.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_idmz01_abbnw23" = {
        "name"                    = "RTB-ABBNW-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "145.241.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_idmz01_abbnw24" = {
        "name"                    = "RTB-ABBNW-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "204.231.112.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_idmz01_abbnw25" = {
        "name"                    = "RTB-ABBNW-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "206.208.208.0/23"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_idmz01_abbnw26" = {
        "name"                    = "RTB-ABBNW-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "210.24.147.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_idmz01_abbnw27" = {
        "name"                    = "RTB-ABBNW-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "193.164.24.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_idmz01_abbnw28" = {
        "name"                    = "RTB-ABBNW-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "193.164.31.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_int01_abbnw01" = {
        "name"                    = "RTB-ABBNW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "10.0.0.0/8"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_int01_abbnw02" = {
        "name"                    = "RTB-ABBNW-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "138.224.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_int01_abbnw03" = {
        "name"                    = "RTB-ABBNW-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "138.222.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
   "z1c_int01_abbnw04" = {
        "name"                    = "RTB-ABBNW-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "138.226.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_int01_abbnw05" = {
        "name"                    = "RTB-ABBNW-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "172.16.0.0/12"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_int01_abbnw06" = {
        "name"                    = "RTB-ABBNW-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "130.110.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_int01_abbnw07" = {
        "name"                    = "RTB-ABBNW-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "137.133.128.0/17"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_int01_abbnw08" = {
        "name"                    = "RTB-ABBNW-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "138.221.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_int01_abbnw09" = {
        "name"                    = "RTB-ABBNW-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "138.223.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_int01_abbnw10" = {
        "name"                    = "RTB-ABBNW-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "138.227.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_int01_abbnw11" = {
        "name"                    = "RTB-ABBNW-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "138.228.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_int01_abbnw12" = {
        "name"                    = "RTB-ABBNW-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "192.125.60.0/22"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_int01_abbnw13" = {
        "name"                    = "RTB-ABBNW-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "100.64.0.0/10"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_int01_abbnw14" = {
        "name"                    = "RTB-ABBNW-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "193.45.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
    "z1c_int01_abbnw15" = {
        "name"                    = "RTB-ABBNW-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "193.71.72.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
  "z1c_int01_abbnw16" = {
        "name"                    = "RTB-ABBNW-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "193.75.73.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_int01_abbnw17" = {
        "name"                    = "RTB-ABBNW-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "193.164.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_int01_abbnw18" = {
        "name"                    = "RTB-ABBNW-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "198.113.64.0/18"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_int01_abbnw19" = {
        "name"                    = "RTB-ABBNW-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "129.35.205.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_int01_abbnw20" = {
        "name"                    = "RTB-ABBNW-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "129.35.207.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_int01_abbnw21" = {
        "name"                    = "RTB-ABBNW-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "80.75.192.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_int01_abbnw22" = {
        "name"                    = "RTB-ABBNW-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "80.75.195.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_int01_abbnw23" = {
        "name"                    = "RTB-ABBNW-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "145.241.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_int01_abbnw24" = {
        "name"                    = "RTB-ABBNW-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "204.231.112.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_int01_abbnw25" = {
        "name"                    = "RTB-ABBNW-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "206.208.208.0/23"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_int01_abbnw26" = {
        "name"                    = "RTB-ABBNW-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "210.24.147.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_int01_abbnw27" = {
        "name"                    = "RTB-ABBNW-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "193.164.24.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_int01_abbnw28" = {
        "name"                    = "RTB-ABBNW-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "193.164.31.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_cv01_abbnw01" = {
        "name"                    = "RTB-ABBNW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "10.0.0.0/8"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_cv01_abbnw02" = {
        "name"                    = "RTB-ABBNW-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "138.224.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_cv01_abbnw03" = {
        "name"                    = "RTB-ABBNW-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "138.222.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
   "z1c_cv01_abbnw04" = {
        "name"                    = "RTB-ABBNW-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "138.226.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_cv01_abbnw05" = {
        "name"                    = "RTB-ABBNW-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "172.16.0.0/12"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_cv01_abbnw06" = {
        "name"                    = "RTB-ABBNW-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "130.110.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_cv01_abbnw07" = {
        "name"                    = "RTB-ABBNW-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "137.133.128.0/17"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_cv01_abbnw08" = {
        "name"                    = "RTB-ABBNW-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "138.221.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_cv01_abbnw09" = {
        "name"                    = "RTB-ABBNW-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "138.223.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_cv01_abbnw10" = {
        "name"                    = "RTB-ABBNW-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "138.227.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_cv01_abbnw11" = {
        "name"                    = "RTB-ABBNW-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "138.228.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_cv01_abbnw12" = {
        "name"                    = "RTB-ABBNW-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "192.125.60.0/22"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_cv01_abbnw13" = {
        "name"                    = "RTB-ABBNW-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "100.64.0.0/10"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_cv01_abbnw14" = {
        "name"                    = "RTB-ABBNW-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "193.45.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
    "z1c_cv01_abbnw15" = {
        "name"                    = "RTB-ABBNW-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "193.71.72.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
  "z1c_cv01_abbnw16" = {
        "name"                    = "RTB-ABBNW-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "193.75.73.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_cv01_abbnw17" = {
        "name"                    = "RTB-ABBNW-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "193.164.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_cv01_abbnw18" = {
        "name"                    = "RTB-ABBNW-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "198.113.64.0/18"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_cv01_abbnw19" = {
        "name"                    = "RTB-ABBNW-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "129.35.205.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_cv01_abbnw20" = {
        "name"                    = "RTB-ABBNW-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "129.35.207.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_cv01_abbnw21" = {
        "name"                    = "RTB-ABBNW-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "80.75.192.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_cv01_abbnw22" = {
        "name"                    = "RTB-ABBNW-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "80.75.195.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_cv01_abbnw23" = {
        "name"                    = "RTB-ABBNW-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "145.241.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_cv01_abbnw24" = {
        "name"                    = "RTB-ABBNW-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "204.231.112.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_cv01_abbnw25" = {
        "name"                    = "RTB-ABBNW-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "206.208.208.0/23"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_cv01_abbnw26" = {
        "name"                    = "RTB-ABBNW-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "210.24.147.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_cv01_abbnw27" = {
        "name"                    = "RTB-ABBNW-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "193.164.24.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_cv01_abbnw28" = {
        "name"                    = "RTB-ABBNW-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "193.164.31.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sl01_abbnw01" = {
        "name"                    = "RTB-ABBNW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "10.0.0.0/8"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sl01_abbnw02" = {
        "name"                    = "RTB-ABBNW-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "138.224.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sl01_abbnw03" = {
        "name"                    = "RTB-ABBNW-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "138.222.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
   "z1c_sl01_abbnw04" = {
        "name"                    = "RTB-ABBNW-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "138.226.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sl01_abbnw05" = {
        "name"                    = "RTB-ABBNW-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "172.16.0.0/12"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_sl01_abbnw06" = {
        "name"                    = "RTB-ABBNW-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "130.110.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sl01_abbnw07" = {
        "name"                    = "RTB-ABBNW-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "137.133.128.0/17"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sl01_abbnw08" = {
        "name"                    = "RTB-ABBNW-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "138.221.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sl01_abbnw09" = {
        "name"                    = "RTB-ABBNW-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "138.223.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_sl01_abbnw10" = {
        "name"                    = "RTB-ABBNW-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "138.227.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_sl01_abbnw11" = {
        "name"                    = "RTB-ABBNW-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "138.228.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_sl01_abbnw12" = {
        "name"                    = "RTB-ABBNW-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "192.125.60.0/22"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_sl01_abbnw13" = {
        "name"                    = "RTB-ABBNW-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "100.64.0.0/10"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sl01_abbnw14" = {
        "name"                    = "RTB-ABBNW-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "193.45.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
    "z1c_sl01_abbnw15" = {
        "name"                    = "RTB-ABBNW-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "193.71.72.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
  "z1c_sl01_abbnw16" = {
        "name"                    = "RTB-ABBNW-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "193.75.73.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sl01_abbnw17" = {
        "name"                    = "RTB-ABBNW-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "193.164.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sl01_abbnw18" = {
        "name"                    = "RTB-ABBNW-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "198.113.64.0/18"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sl01_abbnw19" = {
        "name"                    = "RTB-ABBNW-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "129.35.205.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sl01_abbnw20" = {
        "name"                    = "RTB-ABBNW-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "129.35.207.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_sl01_abbnw21" = {
        "name"                    = "RTB-ABBNW-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "80.75.192.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_sl01_abbnw22" = {
        "name"                    = "RTB-ABBNW-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "80.75.195.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sl01_abbnw23" = {
        "name"                    = "RTB-ABBNW-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "145.241.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sl01_abbnw24" = {
        "name"                    = "RTB-ABBNW-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "204.231.112.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sl01_abbnw25" = {
        "name"                    = "RTB-ABBNW-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "206.208.208.0/23"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sl01_abbnw26" = {
        "name"                    = "RTB-ABBNW-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "210.24.147.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sl01_abbnw27" = {
        "name"                    = "RTB-ABBNW-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "193.164.24.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sl01_abbnw28" = {
        "name"                    = "RTB-ABBNW-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "193.164.31.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sccm01_abbnw01" = {
        "name"                    = "RTB-ABBNW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "10.0.0.0/8"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sccm01_abbnw02" = {
        "name"                    = "RTB-ABBNW-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "138.224.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sccm01_abbnw03" = {
        "name"                    = "RTB-ABBNW-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "138.222.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
   "z1c_sccm01_abbnw04" = {
        "name"                    = "RTB-ABBNW-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "138.226.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sccm01_abbnw05" = {
        "name"                    = "RTB-ABBNW-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "172.16.0.0/12"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_sccm01_abbnw06" = {
        "name"                    = "RTB-ABBNW-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "130.110.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sccm01_abbnw07" = {
        "name"                    = "RTB-ABBNW-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "137.133.128.0/17"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sccm01_abbnw08" = {
        "name"                    = "RTB-ABBNW-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "138.221.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sccm01_abbnw09" = {
        "name"                    = "RTB-ABBNW-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "138.223.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_sccm01_abbnw10" = {
        "name"                    = "RTB-ABBNW-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "138.227.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_sccm01_abbnw11" = {
        "name"                    = "RTB-ABBNW-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "138.228.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_sccm01_abbnw12" = {
        "name"                    = "RTB-ABBNW-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "192.125.60.0/22"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_sccm01_abbnw13" = {
        "name"                    = "RTB-ABBNW-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "100.64.0.0/10"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sccm01_abbnw14" = {
        "name"                    = "RTB-ABBNW-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "193.45.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
    "z1c_sccm01_abbnw15" = {
        "name"                    = "RTB-ABBNW-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "193.71.72.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
  "z1c_sccm01_abbnw16" = {
        "name"                    = "RTB-ABBNW-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "193.75.73.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sccm01_abbnw17" = {
        "name"                    = "RTB-ABBNW-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "193.164.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sccm01_abbnw18" = {
        "name"                    = "RTB-ABBNW-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "198.113.64.0/18"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sccm01_abbnw19" = {
        "name"                    = "RTB-ABBNW-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "129.35.205.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sccm01_abbnw20" = {
        "name"                    = "RTB-ABBNW-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "129.35.207.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_sccm01_abbnw21" = {
        "name"                    = "RTB-ABBNW-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "80.75.192.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z1c_sccm01_abbnw22" = {
        "name"                    = "RTB-ABBNW-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "80.75.195.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sccm01_abbnw23" = {
        "name"                    = "RTB-ABBNW-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "145.241.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sccm01_abbnw24" = {
        "name"                    = "RTB-ABBNW-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "204.231.112.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sccm01_abbnw25" = {
        "name"                    = "RTB-ABBNW-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "206.208.208.0/23"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sccm01_abbnw26" = {
        "name"                    = "RTB-ABBNW-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "210.24.147.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sccm01_abbnw27" = {
        "name"                    = "RTB-ABBNW-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "193.164.24.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1c_sccm01_abbnw28" = {
        "name"                    = "RTB-ABBNW-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "193.164.31.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_idmz01_abbnw01" = {
        "name"                    = "RTB-ABBNW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "10.0.0.0/8"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_idmz01_abbnw02" = {
        "name"                    = "RTB-ABBNW-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "138.224.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_idmz01_abbnw03" = {
        "name"                    = "RTB-ABBNW-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "138.222.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
   "z3_idmz01_abbnw04" = {
        "name"                    = "RTB-ABBNW-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "138.226.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_idmz01_abbnw05" = {
        "name"                    = "RTB-ABBNW-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "172.16.0.0/12"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z3_idmz01_abbnw06" = {
        "name"                    = "RTB-ABBNW-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "130.110.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_idmz01_abbnw07" = {
        "name"                    = "RTB-ABBNW-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "137.133.128.0/17"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_idmz01_abbnw08" = {
        "name"                    = "RTB-ABBNW-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "138.221.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_idmz01_abbnw09" = {
        "name"                    = "RTB-ABBNW-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "138.223.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z3_idmz01_abbnw10" = {
        "name"                    = "RTB-ABBNW-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "138.227.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z3_idmz01_abbnw11" = {
        "name"                    = "RTB-ABBNW-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "138.228.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z3_idmz01_abbnw12" = {
        "name"                    = "RTB-ABBNW-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "192.125.60.0/22"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z3_idmz01_abbnw13" = {
        "name"                    = "RTB-ABBNW-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "100.64.0.0/10"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_idmz01_abbnw14" = {
        "name"                    = "RTB-ABBNW-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "193.45.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
    "z3_idmz01_abbnw15" = {
        "name"                    = "RTB-ABBNW-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "193.71.72.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
  "z3_idmz01_abbnw16" = {
        "name"                    = "RTB-ABBNW-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "193.75.73.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_idmz01_abbnw17" = {
        "name"                    = "RTB-ABBNW-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "193.164.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_idmz01_abbnw18" = {
        "name"                    = "RTB-ABBNW-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "198.113.64.0/18"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_idmz01_abbnw19" = {
        "name"                    = "RTB-ABBNW-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "129.35.205.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_idmz01_abbnw20" = {
        "name"                    = "RTB-ABBNW-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "129.35.207.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z3_idmz01_abbnw21" = {
        "name"                    = "RTB-ABBNW-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "80.75.192.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z3_idmz01_abbnw22" = {
        "name"                    = "RTB-ABBNW-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "80.75.195.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_idmz01_abbnw23" = {
        "name"                    = "RTB-ABBNW-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "145.241.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_idmz01_abbnw24" = {
        "name"                    = "RTB-ABBNW-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "204.231.112.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_idmz01_abbnw25" = {
        "name"                    = "RTB-ABBNW-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "206.208.208.0/23"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_idmz01_abbnw26" = {
        "name"                    = "RTB-ABBNW-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "210.24.147.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_idmz01_abbnw27" = {
        "name"                    = "RTB-ABBNW-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "193.164.24.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_idmz01_abbnw28" = {
        "name"                    = "RTB-ABBNW-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "193.164.31.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_int01_abbnw01" = {
        "name"                    = "RTB-ABBNW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "10.0.0.0/8"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_int01_abbnw02" = {
        "name"                    = "RTB-ABBNW-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "138.224.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_int01_abbnw03" = {
        "name"                    = "RTB-ABBNW-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "138.222.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
   "z3_int01_abbnw04" = {
        "name"                    = "RTB-ABBNW-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "138.226.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_int01_abbnw05" = {
        "name"                    = "RTB-ABBNW-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "172.16.0.0/12"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z3_int01_abbnw06" = {
        "name"                    = "RTB-ABBNW-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "130.110.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_int01_abbnw07" = {
        "name"                    = "RTB-ABBNW-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "137.133.128.0/17"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_int01_abbnw08" = {
        "name"                    = "RTB-ABBNW-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "138.221.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_int01_abbnw09" = {
        "name"                    = "RTB-ABBNW-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "138.223.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z3_int01_abbnw10" = {
        "name"                    = "RTB-ABBNW-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "138.227.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z3_int01_abbnw11" = {
        "name"                    = "RTB-ABBNW-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "138.228.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z3_int01_abbnw12" = {
        "name"                    = "RTB-ABBNW-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "192.125.60.0/22"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z3_int01_abbnw13" = {
        "name"                    = "RTB-ABBNW-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "100.64.0.0/10"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_int01_abbnw14" = {
        "name"                    = "RTB-ABBNW-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "193.45.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
    "z3_int01_abbnw15" = {
        "name"                    = "RTB-ABBNW-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "193.71.72.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
  "z3_int01_abbnw16" = {
        "name"                    = "RTB-ABBNW-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "193.75.73.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_int01_abbnw17" = {
        "name"                    = "RTB-ABBNW-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "193.164.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_int01_abbnw18" = {
        "name"                    = "RTB-ABBNW-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "198.113.64.0/18"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_int01_abbnw19" = {
        "name"                    = "RTB-ABBNW-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "129.35.205.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_int01_abbnw20" = {
        "name"                    = "RTB-ABBNW-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "129.35.207.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z3_int01_abbnw21" = {
        "name"                    = "RTB-ABBNW-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "80.75.192.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z3_int01_abbnw22" = {
        "name"                    = "RTB-ABBNW-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "80.75.195.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_int01_abbnw23" = {
        "name"                    = "RTB-ABBNW-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "145.241.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_int01_abbnw24" = {
        "name"                    = "RTB-ABBNW-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "204.231.112.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_int01_abbnw25" = {
        "name"                    = "RTB-ABBNW-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "206.208.208.0/23"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_int01_abbnw26" = {
        "name"                    = "RTB-ABBNW-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "210.24.147.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_int01_abbnw27" = {
        "name"                    = "RTB-ABBNW-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "193.164.24.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_int01_abbnw28" = {
        "name"                    = "RTB-ABBNW-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "193.164.31.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_cv01_abbnw01" = {
        "name"                    = "RTB-ABBNW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "10.0.0.0/8"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_cv01_abbnw02" = {
        "name"                    = "RTB-ABBNW-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "138.224.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_cv01_abbnw03" = {
        "name"                    = "RTB-ABBNW-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "138.222.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
   "z3_cv01_abbnw04" = {
        "name"                    = "RTB-ABBNW-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "138.226.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_cv01_abbnw05" = {
        "name"                    = "RTB-ABBNW-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "172.16.0.0/12"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z3_cv01_abbnw06" = {
        "name"                    = "RTB-ABBNW-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "130.110.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_cv01_abbnw07" = {
        "name"                    = "RTB-ABBNW-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "137.133.128.0/17"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_cv01_abbnw08" = {
        "name"                    = "RTB-ABBNW-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "138.221.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_cv01_abbnw09" = {
        "name"                    = "RTB-ABBNW-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "138.223.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z3_cv01_abbnw10" = {
        "name"                    = "RTB-ABBNW-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "138.227.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z3_cv01_abbnw11" = {
        "name"                    = "RTB-ABBNW-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "138.228.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z3_cv01_abbnw12" = {
        "name"                    = "RTB-ABBNW-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "192.125.60.0/22"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z3_cv01_abbnw13" = {
        "name"                    = "RTB-ABBNW-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "100.64.0.0/10"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_cv01_abbnw14" = {
        "name"                    = "RTB-ABBNW-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "193.45.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
    "z3_cv01_abbnw15" = {
        "name"                    = "RTB-ABBNW-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "193.71.72.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
  "z3_cv01_abbnw16" = {
        "name"                    = "RTB-ABBNW-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "193.75.73.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_cv01_abbnw17" = {
        "name"                    = "RTB-ABBNW-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "193.164.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_cv01_abbnw18" = {
        "name"                    = "RTB-ABBNW-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "198.113.64.0/18"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_cv01_abbnw19" = {
        "name"                    = "RTB-ABBNW-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "129.35.205.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_cv01_abbnw20" = {
        "name"                    = "RTB-ABBNW-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "129.35.207.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z3_cv01_abbnw21" = {
        "name"                    = "RTB-ABBNW-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "80.75.192.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "z3_cv01_abbnw22" = {
        "name"                    = "RTB-ABBNW-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "80.75.195.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_cv01_abbnw23" = {
        "name"                    = "RTB-ABBNW-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "145.241.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_cv01_abbnw24" = {
        "name"                    = "RTB-ABBNW-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "204.231.112.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_cv01_abbnw25" = {
        "name"                    = "RTB-ABBNW-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "206.208.208.0/23"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_cv01_abbnw26" = {
        "name"                    = "RTB-ABBNW-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "210.24.147.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_cv01_abbnw27" = {
        "name"                    = "RTB-ABBNW-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "193.164.24.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z3_cv01_abbnw28" = {
        "name"                    = "RTB-ABBNW-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "193.164.31.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"z1a_edmz01_akamai01" = {
        "name"                    = "RTB-AKAMAI-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "104.64.0.0/10"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai02" = {
        "name"                    = "RTB-AKAMAI-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "118.214.0.0/16"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai03" = {
        "name"                    = "RTB-AKAMAI-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "124.40.41.200/29"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai04" = {
        "name"                    = "RTB-AKAMAI-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "125.252.224.36/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai05" = {
        "name"                    = "RTB-AKAMAI-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "125.56.219.52/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai06" = {
        "name"                    = "RTB-AKAMAI-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "173.205.7.116/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai07" = {
        "name"                    = "RTB-AKAMAI-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "173.222.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai08" = {
        "name"                    = "RTB-AKAMAI-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "184.24.0.0/13"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai09" = {
        "name"                    = "RTB-AKAMAI-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "184.50.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai10" = {
        "name"                    = "RTB-AKAMAI-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "184.84.0.0/14"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai11" = {
        "name"                    = "RTB-AKAMAI-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "192.204.11.4/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai12" = {
        "name"                    = "RTB-AKAMAI-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "193.108.155.118/32"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai13" = {
        "name"                    = "RTB-AKAMAI-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "2.16.0.0/13"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai14" = {
        "name"                    = "RTB-AKAMAI-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "201.33.187.68/30"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai15" = {
        "name"                    = "RTB-AKAMAI-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "203.69.138.120/30"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai16" = {
        "name"                    = "RTB-AKAMAI-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "204.1.136.238/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai17" = {
        "name"                    = "RTB-AKAMAI-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "204.2.159.68/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai18" = {
        "name"                    = "RTB-AKAMAI-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "204.2.160.182/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai19" = {
        "name"                    = "RTB-AKAMAI-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "204.201.160.246/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai20" = {
        "name"                    = "RTB-AKAMAI-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "205.185.205.132/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai21" = {
        "name"                    = "RTB-AKAMAI-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "207.126.104.118/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai22" = {
        "name"                    = "RTB-AKAMAI-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "209.107.208.188/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai23" = {
        "name"                    = "RTB-AKAMAI-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "209.249.98.36/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai24" = {
        "name"                    = "RTB-AKAMAI-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "220.90.198.178/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai25" = {
        "name"                    = "RTB-AKAMAI-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.0.0.0/12"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai26" = {
        "name"                    = "RTB-AKAMAI-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.192.0.0/11"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai27" = {
        "name"                    = "RTB-AKAMAI-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.32.0.0/11"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai28" = {
        "name"                    = "RTB-AKAMAI-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.64.0.0/14"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai29" = {
        "name"                    = "RTB-AKAMAI-29"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.72.0.0/13"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai30" = {
        "name"                    = "RTB-AKAMAI-30"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "60.254.173.30/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai31" = {
        "name"                    = "RTB-AKAMAI-31"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "61.111.58.82/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai32" = {
        "name"                    = "RTB-AKAMAI-32"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "63.217.211.110/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai33" = {
        "name"                    = "RTB-AKAMAI-33"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "63.217.211.116/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai34" = {
        "name"                    = "RTB-AKAMAI-34"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "63.235.21.192/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai35" = {
        "name"                    = "RTB-AKAMAI-35"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "64.145.89.236/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai36" = {
        "name"                    = "RTB-AKAMAI-36"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "65.124.174.194/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai37" = {
        "name"                    = "RTB-AKAMAI-37"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "66.198.26.68/30"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai38" = {
        "name"                    = "RTB-AKAMAI-38"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "66.198.8.167/32"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai39" = {
        "name"                    = "RTB-AKAMAI-39"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "66.198.8.168/32"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai40" = {
        "name"                    = "RTB-AKAMAI-40"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "67.220.143.216/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai41" = {
        "name"                    = "RTB-AKAMAI-41"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "69.192.0.0/16"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai42" = {
        "name"                    = "RTB-AKAMAI-42"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "69.31.121.20/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai43" = {
        "name"                    = "RTB-AKAMAI-43"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "69.31.138.100/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai44" = {
        "name"                    = "RTB-AKAMAI-44"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "72.246.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai45" = {
        "name"                    = "RTB-AKAMAI-45"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "77.67.85.52/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai46" = {
        "name"                    = "RTB-AKAMAI-46"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "8.18.43.199/32"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai47" = {
        "name"                    = "RTB-AKAMAI-47"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "8.18.43.240/32"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai48" = {
        "name"                    = "RTB-AKAMAI-48"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "88.221.0.0/16"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai49" = {
        "name"                    = "RTB-AKAMAI-49"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "92.122.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai50" = {
        "name"                    = "RTB-AKAMAI-50"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "95.100.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai51" = {
        "name"                    = "RTB-AKAMAI-51"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "96.16.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_akamai52" = {
        "name"                    = "RTB-AKAMAI-52"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "96.6.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },

"z1a_edmz01_EDMZ01" = {
        "name"                    = "RTB-EDMZ-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "184.31.1.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ02" = {
        "name"                    = "RTB-EDMZ-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "184.50.85.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ03" = {
        "name"                    = "RTB-EDMZ-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "2.17.112.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ04" = {
        "name"                    = "RTB-EDMZ-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "2.21.22.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ05" = {
        "name"                    = "RTB-EDMZ-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "2.21.33.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ06" = {
        "name"                    = "RTB-EDMZ-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "2.22.121.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ07" = {
        "name"                    = "RTB-EDMZ-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "2.22.30.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ08" = {
        "name"                    = "RTB-EDMZ-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "2.22.54.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ09" = {
        "name"                    = "RTB-EDMZ-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.10.249.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ10" = {
        "name"                    = "RTB-EDMZ-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.15.178.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ11" = {
        "name"                    = "RTB-EDMZ-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.198.5.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ12" = {
        "name"                    = "RTB-EDMZ-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.200.142.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ13" = {
        "name"                    = "RTB-EDMZ-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.203.249.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ14" = {
        "name"                    = "RTB-EDMZ-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.3.88.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ15" = {
        "name"                    = "RTB-EDMZ-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.35.110.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ16" = {
        "name"                    = "RTB-EDMZ-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.35.111.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ17" = {
        "name"                    = "RTB-EDMZ-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.44.4.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ18" = {
        "name"                    = "RTB-EDMZ-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.48.94.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ19" = {
        "name"                    = "RTB-EDMZ-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.55.36.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ20" = {
        "name"                    = "RTB-EDMZ-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.56.109.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ21" = {
        "name"                    = "RTB-EDMZ-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.61.244.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ22" = {
        "name"                    = "RTB-EDMZ-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "72.246.97.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ23" = {
        "name"                    = "RTB-EDMZ-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "80.67.72.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ24" = {
        "name"                    = "RTB-EDMZ-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "84.53.138.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ25" = {
        "name"                    = "RTB-EDMZ-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "92.122.193.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ26" = {
        "name"                    = "RTB-EDMZ-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "92.122.215.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ27" = {
        "name"                    = "RTB-EDMZ-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "92.122.54.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ28" = {
        "name"                    = "RTB-EDMZ-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "92.123.107.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ29" = {
        "name"                    = "RTB-EDMZ-29"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "92.123.78.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ30" = {
        "name"                    = "RTB-EDMZ-30"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "95.100.169.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ31" = {
        "name"                    = "RTB-EDMZ-31"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "95.100.97.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ32" = {
        "name"                    = "RTB-EDMZ-32"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "95.101.143.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ33" = {
        "name"                    = "RTB-EDMZ-33"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "95.101.230.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ34" = {
        "name"                    = "RTB-EDMZ-34"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "96.17.180.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ35" = {
        "name"                    = "RTB-EDMZ-35"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "104.103.71.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ36" = {
        "name"                    = "RTB-EDMZ-36"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "104.104.52.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ37" = {
        "name"                    = "RTB-EDMZ-37"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "104.107.216.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ38" = {
        "name"                    = "RTB-EDMZ-38"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "104.107.217.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ39" = {
        "name"                    = "RTB-EDMZ-39"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "104.120.139.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ40" = {
        "name"                    = "RTB-EDMZ-40"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "104.124.56.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ41" = {
        "name"                    = "RTB-EDMZ-41"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "104.70.235.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ42" = {
        "name"                    = "RTB-EDMZ-42"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "173.222.148.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ43" = {
        "name"                    = "RTB-EDMZ-43"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "184.28.199.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ44" = {
        "name"                    = "RTB-EDMZ-44"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "184.28.229.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ45" = {
        "name"                    = "RTB-EDMZ-45"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "104.109.250.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ46" = {
        "name"                    = "RTB-EDMZ-46"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "184.28.194.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ47" = {
        "name"                    = "RTB-EDMZ-47"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "184.50.112.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ48" = {
        "name"                    = "RTB-EDMZ-48"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.10.252.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ49" = {
        "name"                    = "RTB-EDMZ-49"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.192.164.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ150" = {
        "name"                    = "RTB-EDMZ-50"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.195.73.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ51" = {
        "name"                    = "RTB-EDMZ-51"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.206.170.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ52" = {
        "name"                    = "RTB-EDMZ-52"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.212.108.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ53" = {
        "name"                    = "RTB-EDMZ-53"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.217.99.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ54" = {
        "name"                    = "RTB-EDMZ-54"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.55.170.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ55" = {
        "name"                    = "RTB-EDMZ-55"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.64.122.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ56" = {
        "name"                    = "RTB-EDMZ-56"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.67.40.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ57" = {
        "name"                    = "RTB-EDMZ-57"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "23.72.253.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ58" = {
        "name"                    = "RTB-EDMZ-58"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "88.221.24.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ59" = {
        "name"                    = "RTB-EDMZ-59"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "88.221.25.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ60" = {
        "name"                    = "RTB-EDMZ-60"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "92.123.122.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_edmz01_EDMZ61" = {
        "name"                    = "RTB-EDMZ-61"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_edmz01"
        "route_address_prefix"    = "95.100.193.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai01" = {
        "name"                    = "RTB-AKAMAI-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "104.64.0.0/10"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai02" = {
        "name"                    = "RTB-AKAMAI-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "118.214.0.0/16"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai03" = {
        "name"                    = "RTB-AKAMAI-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "124.40.41.200/29"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai04" = {
        "name"                    = "RTB-AKAMAI-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "125.252.224.36/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai05" = {
        "name"                    = "RTB-AKAMAI-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "125.56.219.52/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai06" = {
        "name"                    = "RTB-AKAMAI-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "173.205.7.116/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai07" = {
        "name"                    = "RTB-AKAMAI-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "173.222.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai08" = {
        "name"                    = "RTB-AKAMAI-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "184.24.0.0/13"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai09" = {
        "name"                    = "RTB-AKAMAI-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "184.50.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai10" = {
        "name"                    = "RTB-AKAMAI-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "184.84.0.0/14"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai11" = {
        "name"                    = "RTB-AKAMAI-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "192.204.11.4/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai12" = {
        "name"                    = "RTB-AKAMAI-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "193.108.155.118/32"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai13" = {
        "name"                    = "RTB-AKAMAI-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "2.16.0.0/13"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai14" = {
        "name"                    = "RTB-AKAMAI-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "201.33.187.68/30"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai15" = {
        "name"                    = "RTB-AKAMAI-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "203.69.138.120/30"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai16" = {
        "name"                    = "RTB-AKAMAI-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "204.1.136.238/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai17" = {
        "name"                    = "RTB-AKAMAI-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "204.2.159.68/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai18" = {
        "name"                    = "RTB-AKAMAI-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "204.2.160.182/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai19" = {
        "name"                    = "RTB-AKAMAI-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "204.201.160.246/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai20" = {
        "name"                    = "RTB-AKAMAI-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "205.185.205.132/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai21" = {
        "name"                    = "RTB-AKAMAI-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "207.126.104.118/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai22" = {
        "name"                    = "RTB-AKAMAI-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "209.107.208.188/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai23" = {
        "name"                    = "RTB-AKAMAI-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "209.249.98.36/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai24" = {
        "name"                    = "RTB-AKAMAI-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "220.90.198.178/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai25" = {
        "name"                    = "RTB-AKAMAI-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.0.0.0/12"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai26" = {
        "name"                    = "RTB-AKAMAI-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.192.0.0/11"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai27" = {
        "name"                    = "RTB-AKAMAI-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.32.0.0/11"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai28" = {
        "name"                    = "RTB-AKAMAI-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.64.0.0/14"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai29" = {
        "name"                    = "RTB-AKAMAI-29"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.72.0.0/13"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai30" = {
        "name"                    = "RTB-AKAMAI-30"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "60.254.173.30/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai31" = {
        "name"                    = "RTB-AKAMAI-31"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "61.111.58.82/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai32" = {
        "name"                    = "RTB-AKAMAI-32"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "63.217.211.110/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai33" = {
        "name"                    = "RTB-AKAMAI-33"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "63.217.211.116/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai34" = {
        "name"                    = "RTB-AKAMAI-34"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "63.235.21.192/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai35" = {
        "name"                    = "RTB-AKAMAI-35"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "64.145.89.236/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai36" = {
        "name"                    = "RTB-AKAMAI-36"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "65.124.174.194/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai37" = {
        "name"                    = "RTB-AKAMAI-37"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "66.198.26.68/30"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai38" = {
        "name"                    = "RTB-AKAMAI-38"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "66.198.8.167/32"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai39" = {
        "name"                    = "RTB-AKAMAI-39"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "66.198.8.168/32"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai40" = {
        "name"                    = "RTB-AKAMAI-40"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "67.220.143.216/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai41" = {
        "name"                    = "RTB-AKAMAI-41"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "69.192.0.0/16"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai42" = {
        "name"                    = "RTB-AKAMAI-42"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "69.31.121.20/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai43" = {
        "name"                    = "RTB-AKAMAI-43"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "69.31.138.100/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai44" = {
        "name"                    = "RTB-AKAMAI-44"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "72.246.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai45" = {
        "name"                    = "RTB-AKAMAI-45"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "77.67.85.52/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai46" = {
        "name"                    = "RTB-AKAMAI-46"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "8.18.43.199/32"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai47" = {
        "name"                    = "RTB-AKAMAI-47"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "8.18.43.240/32"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai48" = {
        "name"                    = "RTB-AKAMAI-48"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "88.221.0.0/16"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai49" = {
        "name"                    = "RTB-AKAMAI-49"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "92.122.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai50" = {
        "name"                    = "RTB-AKAMAI-50"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "95.100.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai51" = {
        "name"                    = "RTB-AKAMAI-51"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "96.16.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_akamai52" = {
        "name"                    = "RTB-AKAMAI-52"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "96.6.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },

"z1b_edmz01_EDMZ01" = {
        "name"                    = "RTB-EDMZ-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "184.31.1.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ02" = {
        "name"                    = "RTB-EDMZ-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "184.50.85.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ03" = {
        "name"                    = "RTB-EDMZ-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "2.17.112.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ04" = {
        "name"                    = "RTB-EDMZ-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "2.21.22.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ05" = {
        "name"                    = "RTB-EDMZ-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "2.21.33.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ06" = {
        "name"                    = "RTB-EDMZ-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "2.22.121.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ07" = {
        "name"                    = "RTB-EDMZ-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "2.22.30.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ08" = {
        "name"                    = "RTB-EDMZ-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "2.22.54.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ09" = {
        "name"                    = "RTB-EDMZ-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.10.249.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ10" = {
        "name"                    = "RTB-EDMZ-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.15.178.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ11" = {
        "name"                    = "RTB-EDMZ-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.198.5.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ12" = {
        "name"                    = "RTB-EDMZ-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.200.142.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ13" = {
        "name"                    = "RTB-EDMZ-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.203.249.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ14" = {
        "name"                    = "RTB-EDMZ-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.3.88.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ15" = {
        "name"                    = "RTB-EDMZ-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.35.110.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ16" = {
        "name"                    = "RTB-EDMZ-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.35.111.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ17" = {
        "name"                    = "RTB-EDMZ-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.44.4.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ18" = {
        "name"                    = "RTB-EDMZ-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.48.94.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ19" = {
        "name"                    = "RTB-EDMZ-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.55.36.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ20" = {
        "name"                    = "RTB-EDMZ-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.56.109.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ21" = {
        "name"                    = "RTB-EDMZ-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.61.244.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ22" = {
        "name"                    = "RTB-EDMZ-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "72.246.97.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ23" = {
        "name"                    = "RTB-EDMZ-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "80.67.72.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ24" = {
        "name"                    = "RTB-EDMZ-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "84.53.138.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ25" = {
        "name"                    = "RTB-EDMZ-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "92.122.193.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ26" = {
        "name"                    = "RTB-EDMZ-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "92.122.215.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ27" = {
        "name"                    = "RTB-EDMZ-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "92.122.54.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ28" = {
        "name"                    = "RTB-EDMZ-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "92.123.107.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ29" = {
        "name"                    = "RTB-EDMZ-29"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "92.123.78.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ30" = {
        "name"                    = "RTB-EDMZ-30"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "95.100.169.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ31" = {
        "name"                    = "RTB-EDMZ-31"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "95.100.97.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ32" = {
        "name"                    = "RTB-EDMZ-32"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "95.101.143.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ33" = {
        "name"                    = "RTB-EDMZ-33"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "95.101.230.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ34" = {
        "name"                    = "RTB-EDMZ-34"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "96.17.180.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ35" = {
        "name"                    = "RTB-EDMZ-35"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "104.103.71.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ36" = {
        "name"                    = "RTB-EDMZ-36"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "104.104.52.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ37" = {
        "name"                    = "RTB-EDMZ-37"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "104.107.216.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ38" = {
        "name"                    = "RTB-EDMZ-38"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "104.107.217.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ39" = {
        "name"                    = "RTB-EDMZ-39"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "104.120.139.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ40" = {
        "name"                    = "RTB-EDMZ-40"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "104.124.56.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ41" = {
        "name"                    = "RTB-EDMZ-41"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "104.70.235.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ42" = {
        "name"                    = "RTB-EDMZ-42"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "173.222.148.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ43" = {
        "name"                    = "RTB-EDMZ-43"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "184.28.199.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ44" = {
        "name"                    = "RTB-EDMZ-44"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "184.28.229.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ45" = {
        "name"                    = "RTB-EDMZ-45"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "104.109.250.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ46" = {
        "name"                    = "RTB-EDMZ-46"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "184.28.194.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ47" = {
        "name"                    = "RTB-EDMZ-47"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "184.50.112.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ48" = {
        "name"                    = "RTB-EDMZ-48"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.10.252.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ49" = {
        "name"                    = "RTB-EDMZ-49"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.192.164.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ150" = {
        "name"                    = "RTB-EDMZ-50"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.195.73.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ51" = {
        "name"                    = "RTB-EDMZ-51"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.206.170.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ52" = {
        "name"                    = "RTB-EDMZ-52"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.212.108.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ53" = {
        "name"                    = "RTB-EDMZ-53"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.217.99.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ54" = {
        "name"                    = "RTB-EDMZ-54"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.55.170.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ55" = {
        "name"                    = "RTB-EDMZ-55"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.64.122.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ56" = {
        "name"                    = "RTB-EDMZ-56"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.67.40.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ57" = {
        "name"                    = "RTB-EDMZ-57"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "23.72.253.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ58" = {
        "name"                    = "RTB-EDMZ-58"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "88.221.24.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ59" = {
        "name"                    = "RTB-EDMZ-59"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "88.221.25.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ60" = {
        "name"                    = "RTB-EDMZ-60"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "92.123.122.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1b_edmz01_EDMZ61" = {
        "name"                    = "RTB-EDMZ-61"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz01"
        "route_address_prefix"    = "95.100.193.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai01" = {
        "name"                    = "RTB-AKAMAI-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "104.64.0.0/10"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai02" = {
        "name"                    = "RTB-AKAMAI-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "118.214.0.0/16"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai03" = {
        "name"                    = "RTB-AKAMAI-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "124.40.41.200/29"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai04" = {
        "name"                    = "RTB-AKAMAI-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "125.252.224.36/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai05" = {
        "name"                    = "RTB-AKAMAI-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "125.56.219.52/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai06" = {
        "name"                    = "RTB-AKAMAI-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "173.205.7.116/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai07" = {
        "name"                    = "RTB-AKAMAI-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "173.222.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai08" = {
        "name"                    = "RTB-AKAMAI-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "184.24.0.0/13"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai09" = {
        "name"                    = "RTB-AKAMAI-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "184.50.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai10" = {
        "name"                    = "RTB-AKAMAI-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "184.84.0.0/14"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai11" = {
        "name"                    = "RTB-AKAMAI-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "192.204.11.4/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai12" = {
        "name"                    = "RTB-AKAMAI-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "193.108.155.118/32"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai13" = {
        "name"                    = "RTB-AKAMAI-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "2.16.0.0/13"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai14" = {
        "name"                    = "RTB-AKAMAI-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "201.33.187.68/30"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai15" = {
        "name"                    = "RTB-AKAMAI-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "203.69.138.120/30"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai16" = {
        "name"                    = "RTB-AKAMAI-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "204.1.136.238/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai17" = {
        "name"                    = "RTB-AKAMAI-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "204.2.159.68/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai18" = {
        "name"                    = "RTB-AKAMAI-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "204.2.160.182/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai19" = {
        "name"                    = "RTB-AKAMAI-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "204.201.160.246/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai20" = {
        "name"                    = "RTB-AKAMAI-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "205.185.205.132/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai21" = {
        "name"                    = "RTB-AKAMAI-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "207.126.104.118/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai22" = {
        "name"                    = "RTB-AKAMAI-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "209.107.208.188/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai23" = {
        "name"                    = "RTB-AKAMAI-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "209.249.98.36/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai24" = {
        "name"                    = "RTB-AKAMAI-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "220.90.198.178/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai25" = {
        "name"                    = "RTB-AKAMAI-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.0.0.0/12"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai26" = {
        "name"                    = "RTB-AKAMAI-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.192.0.0/11"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai27" = {
        "name"                    = "RTB-AKAMAI-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.32.0.0/11"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai28" = {
        "name"                    = "RTB-AKAMAI-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.64.0.0/14"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai29" = {
        "name"                    = "RTB-AKAMAI-29"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.72.0.0/13"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai30" = {
        "name"                    = "RTB-AKAMAI-30"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "60.254.173.30/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai31" = {
        "name"                    = "RTB-AKAMAI-31"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "61.111.58.82/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai32" = {
        "name"                    = "RTB-AKAMAI-32"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "63.217.211.110/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai33" = {
        "name"                    = "RTB-AKAMAI-33"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "63.217.211.116/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai34" = {
        "name"                    = "RTB-AKAMAI-34"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "63.235.21.192/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai35" = {
        "name"                    = "RTB-AKAMAI-35"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "64.145.89.236/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai36" = {
        "name"                    = "RTB-AKAMAI-36"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "65.124.174.194/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai37" = {
        "name"                    = "RTB-AKAMAI-37"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "66.198.26.68/30"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai38" = {
        "name"                    = "RTB-AKAMAI-38"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "66.198.8.167/32"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai39" = {
        "name"                    = "RTB-AKAMAI-39"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "66.198.8.168/32"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai40" = {
        "name"                    = "RTB-AKAMAI-40"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "67.220.143.216/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai41" = {
        "name"                    = "RTB-AKAMAI-41"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "69.192.0.0/16"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai42" = {
        "name"                    = "RTB-AKAMAI-42"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "69.31.121.20/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai43" = {
        "name"                    = "RTB-AKAMAI-43"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "69.31.138.100/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai44" = {
        "name"                    = "RTB-AKAMAI-44"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "72.246.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai45" = {
        "name"                    = "RTB-AKAMAI-45"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "77.67.85.52/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai46" = {
        "name"                    = "RTB-AKAMAI-46"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "8.18.43.199/32"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai47" = {
        "name"                    = "RTB-AKAMAI-47"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "8.18.43.240/32"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai48" = {
        "name"                    = "RTB-AKAMAI-48"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "88.221.0.0/16"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai49" = {
        "name"                    = "RTB-AKAMAI-49"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "92.122.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai50" = {
        "name"                    = "RTB-AKAMAI-50"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "95.100.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai51" = {
        "name"                    = "RTB-AKAMAI-51"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "96.16.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_akamai52" = {
        "name"                    = "RTB-AKAMAI-52"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "96.6.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },

"z1c_edmz01_EDMZ01" = {
        "name"                    = "RTB-EDMZ-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "184.31.1.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ02" = {
        "name"                    = "RTB-EDMZ-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "184.50.85.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ03" = {
        "name"                    = "RTB-EDMZ-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "2.17.112.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ04" = {
        "name"                    = "RTB-EDMZ-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "2.21.22.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ05" = {
        "name"                    = "RTB-EDMZ-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "2.21.33.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ06" = {
        "name"                    = "RTB-EDMZ-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "2.22.121.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ07" = {
        "name"                    = "RTB-EDMZ-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "2.22.30.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ08" = {
        "name"                    = "RTB-EDMZ-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "2.22.54.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ09" = {
        "name"                    = "RTB-EDMZ-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.10.249.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ10" = {
        "name"                    = "RTB-EDMZ-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.15.178.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ11" = {
        "name"                    = "RTB-EDMZ-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.198.5.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ12" = {
        "name"                    = "RTB-EDMZ-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.200.142.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ13" = {
        "name"                    = "RTB-EDMZ-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.203.249.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ14" = {
        "name"                    = "RTB-EDMZ-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.3.88.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ15" = {
        "name"                    = "RTB-EDMZ-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.35.110.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ16" = {
        "name"                    = "RTB-EDMZ-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.35.111.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ17" = {
        "name"                    = "RTB-EDMZ-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.44.4.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ18" = {
        "name"                    = "RTB-EDMZ-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.48.94.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ19" = {
        "name"                    = "RTB-EDMZ-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.55.36.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ20" = {
        "name"                    = "RTB-EDMZ-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.56.109.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ21" = {
        "name"                    = "RTB-EDMZ-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.61.244.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ22" = {
        "name"                    = "RTB-EDMZ-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "72.246.97.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ23" = {
        "name"                    = "RTB-EDMZ-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "80.67.72.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ24" = {
        "name"                    = "RTB-EDMZ-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "84.53.138.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ25" = {
        "name"                    = "RTB-EDMZ-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "92.122.193.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ26" = {
        "name"                    = "RTB-EDMZ-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "92.122.215.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ27" = {
        "name"                    = "RTB-EDMZ-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "92.122.54.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ28" = {
        "name"                    = "RTB-EDMZ-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "92.123.107.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ29" = {
        "name"                    = "RTB-EDMZ-29"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "92.123.78.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ30" = {
        "name"                    = "RTB-EDMZ-30"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "95.100.169.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ31" = {
        "name"                    = "RTB-EDMZ-31"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "95.100.97.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ32" = {
        "name"                    = "RTB-EDMZ-32"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "95.101.143.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ33" = {
        "name"                    = "RTB-EDMZ-33"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "95.101.230.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ34" = {
        "name"                    = "RTB-EDMZ-34"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "96.17.180.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ35" = {
        "name"                    = "RTB-EDMZ-35"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "104.103.71.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ36" = {
        "name"                    = "RTB-EDMZ-36"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "104.104.52.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ37" = {
        "name"                    = "RTB-EDMZ-37"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "104.107.216.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ38" = {
        "name"                    = "RTB-EDMZ-38"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "104.107.217.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ39" = {
        "name"                    = "RTB-EDMZ-39"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "104.120.139.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ40" = {
        "name"                    = "RTB-EDMZ-40"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "104.124.56.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ41" = {
        "name"                    = "RTB-EDMZ-41"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "104.70.235.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ42" = {
        "name"                    = "RTB-EDMZ-42"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "173.222.148.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ43" = {
        "name"                    = "RTB-EDMZ-43"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "184.28.199.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ44" = {
        "name"                    = "RTB-EDMZ-44"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "184.28.229.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ45" = {
        "name"                    = "RTB-EDMZ-45"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "104.109.250.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ46" = {
        "name"                    = "RTB-EDMZ-46"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "184.28.194.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ47" = {
        "name"                    = "RTB-EDMZ-47"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "184.50.112.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ48" = {
        "name"                    = "RTB-EDMZ-48"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.10.252.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ49" = {
        "name"                    = "RTB-EDMZ-49"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.192.164.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ150" = {
        "name"                    = "RTB-EDMZ-50"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.195.73.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ51" = {
        "name"                    = "RTB-EDMZ-51"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.206.170.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ52" = {
        "name"                    = "RTB-EDMZ-52"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.212.108.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ53" = {
        "name"                    = "RTB-EDMZ-53"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.217.99.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ54" = {
        "name"                    = "RTB-EDMZ-54"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.55.170.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ55" = {
        "name"                    = "RTB-EDMZ-55"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.64.122.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ56" = {
        "name"                    = "RTB-EDMZ-56"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.67.40.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ57" = {
        "name"                    = "RTB-EDMZ-57"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "23.72.253.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ58" = {
        "name"                    = "RTB-EDMZ-58"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "88.221.24.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ59" = {
        "name"                    = "RTB-EDMZ-59"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "88.221.25.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ60" = {
        "name"                    = "RTB-EDMZ-60"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "92.123.122.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1c_edmz01_EDMZ61" = {
        "name"                    = "RTB-EDMZ-61"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_edmz01"
        "route_address_prefix"    = "95.100.193.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai01" = {
        "name"                    = "RTB-AKAMAI-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "104.64.0.0/10"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai02" = {
        "name"                    = "RTB-AKAMAI-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "118.214.0.0/16"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai03" = {
        "name"                    = "RTB-AKAMAI-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "124.40.41.200/29"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai04" = {
        "name"                    = "RTB-AKAMAI-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "125.252.224.36/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai05" = {
        "name"                    = "RTB-AKAMAI-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "125.56.219.52/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai06" = {
        "name"                    = "RTB-AKAMAI-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "173.205.7.116/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai07" = {
        "name"                    = "RTB-AKAMAI-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "173.222.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai08" = {
        "name"                    = "RTB-AKAMAI-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "184.24.0.0/13"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai09" = {
        "name"                    = "RTB-AKAMAI-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "184.50.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai10" = {
        "name"                    = "RTB-AKAMAI-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "184.84.0.0/14"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai11" = {
        "name"                    = "RTB-AKAMAI-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "192.204.11.4/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai12" = {
        "name"                    = "RTB-AKAMAI-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "193.108.155.118/32"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai13" = {
        "name"                    = "RTB-AKAMAI-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "2.16.0.0/13"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai14" = {
        "name"                    = "RTB-AKAMAI-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "201.33.187.68/30"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai15" = {
        "name"                    = "RTB-AKAMAI-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "203.69.138.120/30"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai16" = {
        "name"                    = "RTB-AKAMAI-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "204.1.136.238/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai17" = {
        "name"                    = "RTB-AKAMAI-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "204.2.159.68/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai18" = {
        "name"                    = "RTB-AKAMAI-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "204.2.160.182/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai19" = {
        "name"                    = "RTB-AKAMAI-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "204.201.160.246/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai20" = {
        "name"                    = "RTB-AKAMAI-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "205.185.205.132/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai21" = {
        "name"                    = "RTB-AKAMAI-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "207.126.104.118/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai22" = {
        "name"                    = "RTB-AKAMAI-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "209.107.208.188/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai23" = {
        "name"                    = "RTB-AKAMAI-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "209.249.98.36/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai24" = {
        "name"                    = "RTB-AKAMAI-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "220.90.198.178/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai25" = {
        "name"                    = "RTB-AKAMAI-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.0.0.0/12"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai26" = {
        "name"                    = "RTB-AKAMAI-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.192.0.0/11"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai27" = {
        "name"                    = "RTB-AKAMAI-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.32.0.0/11"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai28" = {
        "name"                    = "RTB-AKAMAI-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.64.0.0/14"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai29" = {
        "name"                    = "RTB-AKAMAI-29"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.72.0.0/13"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai30" = {
        "name"                    = "RTB-AKAMAI-30"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "60.254.173.30/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai31" = {
        "name"                    = "RTB-AKAMAI-31"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "61.111.58.82/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai32" = {
        "name"                    = "RTB-AKAMAI-32"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "63.217.211.110/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai33" = {
        "name"                    = "RTB-AKAMAI-33"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "63.217.211.116/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai34" = {
        "name"                    = "RTB-AKAMAI-34"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "63.235.21.192/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai35" = {
        "name"                    = "RTB-AKAMAI-35"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "64.145.89.236/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai36" = {
        "name"                    = "RTB-AKAMAI-36"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "65.124.174.194/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai37" = {
        "name"                    = "RTB-AKAMAI-37"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "66.198.26.68/30"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai38" = {
        "name"                    = "RTB-AKAMAI-38"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "66.198.8.167/32"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai39" = {
        "name"                    = "RTB-AKAMAI-39"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "66.198.8.168/32"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai40" = {
        "name"                    = "RTB-AKAMAI-40"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "67.220.143.216/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai41" = {
        "name"                    = "RTB-AKAMAI-41"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "69.192.0.0/16"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai42" = {
        "name"                    = "RTB-AKAMAI-42"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "69.31.121.20/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai43" = {
        "name"                    = "RTB-AKAMAI-43"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "69.31.138.100/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai44" = {
        "name"                    = "RTB-AKAMAI-44"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "72.246.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai45" = {
        "name"                    = "RTB-AKAMAI-45"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "77.67.85.52/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai46" = {
        "name"                    = "RTB-AKAMAI-46"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "8.18.43.199/32"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai47" = {
        "name"                    = "RTB-AKAMAI-47"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "8.18.43.240/32"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai48" = {
        "name"                    = "RTB-AKAMAI-48"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "88.221.0.0/16"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai49" = {
        "name"                    = "RTB-AKAMAI-49"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "92.122.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai50" = {
        "name"                    = "RTB-AKAMAI-50"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "95.100.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai51" = {
        "name"                    = "RTB-AKAMAI-51"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "96.16.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_akamai52" = {
        "name"                    = "RTB-AKAMAI-52"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "96.6.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },

"z3_edmz01_EDMZ01" = {
        "name"                    = "RTB-EDMZ-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "184.31.1.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ02" = {
        "name"                    = "RTB-EDMZ-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "184.50.85.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ03" = {
        "name"                    = "RTB-EDMZ-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "2.17.112.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ04" = {
        "name"                    = "RTB-EDMZ-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "2.21.22.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ05" = {
        "name"                    = "RTB-EDMZ-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "2.21.33.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ06" = {
        "name"                    = "RTB-EDMZ-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "2.22.121.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ07" = {
        "name"                    = "RTB-EDMZ-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "2.22.30.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ08" = {
        "name"                    = "RTB-EDMZ-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "2.22.54.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ09" = {
        "name"                    = "RTB-EDMZ-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.10.249.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ10" = {
        "name"                    = "RTB-EDMZ-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.15.178.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ11" = {
        "name"                    = "RTB-EDMZ-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.198.5.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ12" = {
        "name"                    = "RTB-EDMZ-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.200.142.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ13" = {
        "name"                    = "RTB-EDMZ-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.203.249.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ14" = {
        "name"                    = "RTB-EDMZ-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.3.88.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ15" = {
        "name"                    = "RTB-EDMZ-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.35.110.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ16" = {
        "name"                    = "RTB-EDMZ-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.35.111.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ17" = {
        "name"                    = "RTB-EDMZ-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.44.4.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ18" = {
        "name"                    = "RTB-EDMZ-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.48.94.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ19" = {
        "name"                    = "RTB-EDMZ-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.55.36.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ20" = {
        "name"                    = "RTB-EDMZ-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.56.109.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ21" = {
        "name"                    = "RTB-EDMZ-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.61.244.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ22" = {
        "name"                    = "RTB-EDMZ-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "72.246.97.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ23" = {
        "name"                    = "RTB-EDMZ-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "80.67.72.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ24" = {
        "name"                    = "RTB-EDMZ-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "84.53.138.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ25" = {
        "name"                    = "RTB-EDMZ-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "92.122.193.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ26" = {
        "name"                    = "RTB-EDMZ-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "92.122.215.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ27" = {
        "name"                    = "RTB-EDMZ-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "92.122.54.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ28" = {
        "name"                    = "RTB-EDMZ-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "92.123.107.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ29" = {
        "name"                    = "RTB-EDMZ-29"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "92.123.78.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ30" = {
        "name"                    = "RTB-EDMZ-30"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "95.100.169.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ31" = {
        "name"                    = "RTB-EDMZ-31"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "95.100.97.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ32" = {
        "name"                    = "RTB-EDMZ-32"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "95.101.143.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ33" = {
        "name"                    = "RTB-EDMZ-33"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "95.101.230.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ34" = {
        "name"                    = "RTB-EDMZ-34"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "96.17.180.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ35" = {
        "name"                    = "RTB-EDMZ-35"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "104.103.71.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ36" = {
        "name"                    = "RTB-EDMZ-36"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "104.104.52.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ37" = {
        "name"                    = "RTB-EDMZ-37"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "104.107.216.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ38" = {
        "name"                    = "RTB-EDMZ-38"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "104.107.217.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ39" = {
        "name"                    = "RTB-EDMZ-39"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "104.120.139.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ40" = {
        "name"                    = "RTB-EDMZ-40"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "104.124.56.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ41" = {
        "name"                    = "RTB-EDMZ-41"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "104.70.235.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ42" = {
        "name"                    = "RTB-EDMZ-42"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "173.222.148.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ43" = {
        "name"                    = "RTB-EDMZ-43"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "184.28.199.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ44" = {
        "name"                    = "RTB-EDMZ-44"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "184.28.229.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ45" = {
        "name"                    = "RTB-EDMZ-45"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "104.109.250.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ46" = {
        "name"                    = "RTB-EDMZ-46"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "184.28.194.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ47" = {
        "name"                    = "RTB-EDMZ-47"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "184.50.112.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ48" = {
        "name"                    = "RTB-EDMZ-48"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.10.252.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ49" = {
        "name"                    = "RTB-EDMZ-49"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.192.164.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ150" = {
        "name"                    = "RTB-EDMZ-50"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.195.73.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ51" = {
        "name"                    = "RTB-EDMZ-51"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.206.170.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ52" = {
        "name"                    = "RTB-EDMZ-52"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.212.108.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ53" = {
        "name"                    = "RTB-EDMZ-53"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.217.99.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ54" = {
        "name"                    = "RTB-EDMZ-54"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.55.170.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ55" = {
        "name"                    = "RTB-EDMZ-55"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.64.122.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ56" = {
        "name"                    = "RTB-EDMZ-56"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.67.40.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ57" = {
        "name"                    = "RTB-EDMZ-57"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "23.72.253.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ58" = {
        "name"                    = "RTB-EDMZ-58"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "88.221.24.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ59" = {
        "name"                    = "RTB-EDMZ-59"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "88.221.25.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ60" = {
        "name"                    = "RTB-EDMZ-60"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "92.123.122.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z3_edmz01_EDMZ61" = {
        "name"                    = "RTB-EDMZ-61"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_edmz01"
        "route_address_prefix"    = "95.100.193.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"z1a_int01_intfw01" = {
        "name"                    = "RTB-INTFW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_int01"
        "route_address_prefix"    = "0.0.0.0/0"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "Zscaler-FrontendIP"
    },
"z1a_idmz01_intfw01" = {
        "name"                    = "RTB-INTFW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_idmz01"
        "route_address_prefix"    = "0.0.0.0/0"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "Zscaler-FrontendIP"
    },
"z1a_cv01_intfw01" = {
        "name"                    = "RTB-INTFW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1a_cv01"
        "route_address_prefix"    = "0.0.0.0/0"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "Zscaler-FrontendIP"
    },
"z1b_int01_intfw01" = {
        "name"                    = "RTB-INTFW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int01"
        "route_address_prefix"    = "0.0.0.0/0"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "Zscaler-FrontendIP"
    },
"z1b_idmz01_intfw01" = {
        "name"                    = "RTB-INTFW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz01"
        "route_address_prefix"    = "0.0.0.0/0"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "Zscaler-FrontendIP"
    },
"z1b_cv01_intfw01" = {
        "name"                    = "RTB-INTFW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_cv01"
        "route_address_prefix"    = "0.0.0.0/0"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "Zscaler-FrontendIP"
    },
"z1b_int_sox01_intfw01" = {
        "name"                    = "RTB-INTFW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_int_sox01"
        "route_address_prefix"    = "0.0.0.0/0"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "Zscaler-FrontendIP"
    },
"z1b_idmz_sox01_intfw01" = {
        "name"                    = "RTB-INTFW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_idmz_sox01"
        "route_address_prefix"    = "0.0.0.0/0"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "Zscaler-FrontendIP"
    },
"z1b_edmz_sox01_intfw01" = {
        "name"                    = "RTB-INTFW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1b_edmz_sox01"
        "route_address_prefix"    = "0.0.0.0/0"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "Zscaler-FrontendIP"
    },
"z1c_int01_intfw01" = {
        "name"                    = "RTB-INTFW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_int01"
        "route_address_prefix"    = "0.0.0.0/0"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "Zscaler-FrontendIP"
    },
"z1c_idmz01_intfw01" = {
        "name"                    = "RTB-INTFW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_idmz01"
        "route_address_prefix"    = "0.0.0.0/0"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "Zscaler-FrontendIP"
    },
"z1c_cv01_intfw01" = {
        "name"                    = "RTB-INTFW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_cv01"
        "route_address_prefix"    = "0.0.0.0/0"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "Zscaler-FrontendIP"
    },
"z1c_sl01_intfw01" = {
        "name"                    = "RTB-INTFW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sl01"
        "route_address_prefix"    = "0.0.0.0/0"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "Zscaler-FrontendIP"
    },
"z1c_sccm01_intfw01" = {
        "name"                    = "RTB-INTFW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z1c_sccm01"
        "route_address_prefix"    = "0.0.0.0/0"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "Zscaler-FrontendIP"
    },
"z3_int01_intfw01" = {
        "name"                    = "RTB-INTFW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_int01"
        "route_address_prefix"    = "0.0.0.0/0"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "Zscaler-FrontendIP"
    },
"z3_idmz01_intfw01" = {
        "name"                    = "RTB-INTFW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_idmz01"
        "route_address_prefix"    = "0.0.0.0/0"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "Zscaler-FrontendIP"
    },
"z3_cv01_intfw01" = {
        "name"                    = "RTB-INTFW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "z3_cv01"
        "route_address_prefix"    = "0.0.0.0/0"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "Zscaler-FrontendIP"
    }
}

###--------------------------------------NSGS---------------------------------------

nsgs = {
    "z1a_edmz01" = {
        "nsg_name" = "GLB-PROD-Z1A-VNET01-EDMZ01"
        "resource_group" = "RG_ntw"
        "nsg_tags" = {
            "remark"    = ""
        }
    },
    "z1a_idmz01" = {
        "nsg_name" = "GLB-PROD-Z1A-VNET01-IDMZ01"
        "resource_group" = "RG_ntw"
        "nsg_tags" = {
            "remark"    = ""
        }
    },
    "z1a_int01" = {
        "nsg_name" = "GLB-PROD-Z1A-VNET01-INT01"
        "resource_group" = "RG_ntw"
        "nsg_tags" = {
            "remark"    = ""
        }
    },
    "z1a_edmz_pvtend01" = {
        "nsg_name" = "GLB-PROD-Z1A-VNET01-EDMZ-PVTEND01"
        "resource_group" = "RG_ntw"
        "nsg_tags" = {
            "remark"    = ""
        }
    },
    "z1a_cv01" = {
        "nsg_name" = "GLB-PROD-Z1A-VNET01-CV01"
        "resource_group" = "RG_ntw"
        "nsg_tags" = {
            "remark"    = ""
        }
    },
    "z1b_edmz_sox01" = {
        "nsg_name" = "GLB-PROD-Z1B-VNET01-EDMZ-SOX01"
        "resource_group" = "RG_ntw"
        "nsg_tags" = {
            "remark"    = ""
        }
    },
    "z1b_edmz01" = {
        "nsg_name" = "GLB-PROD-Z1B-VNET01-EDMZ01"
        "resource_group" = "RG_ntw"
        "nsg_tags" = { 
            "remark"    = ""
        }
    },
    "z1b_idmz_sox01" = {
        "nsg_name" = "GLB-PROD-Z1B-VNET01-IDMZ-SOX01"
        "resource_group" = "RG_ntw"
        "nsg_tags" = {
            "remark"    = ""
        }
    },
    "z1b_idmz01" = {
        "nsg_name" = "GLB-PROD-Z1B-VNET01-IDMZ01"
        "resource_group" = "RG_ntw"
        "nsg_tags" = {
            "remark"    = ""
        }
    },
    "z1b_int_sox01" = {
        "nsg_name" = "GLB-PROD-Z1B-VNET01-INT-SOX01"
        "resource_group" = "RG_ntw"
        "nsg_tags" = {
            "remark"    = ""
        }
    },
    "z1b_int01" = {
        "nsg_name" = "GLB-PROD-Z1B-VNET01-INT01"
        "resource_group" = "RG_ntw"
        "nsg_tags" = {
            "remark"    = ""
        }
    },
    "z1b_edmz_pvtend01" = {
        "nsg_name" = "GLB-PROD-Z1B-VNET01-EDMZ-PVTEND01"
        "resource_group" = "RG_ntw"
        "nsg_tags" = { 
            "remark"    = ""
        }
    },
    "z1b_cv01" = {
        "nsg_name" = "GLB-PROD-Z1B-VNET01-CV01"
        "resource_group" = "RG_ntw"
        "nsg_tags" = {
            "remark"    = ""
        }
    },
    "z1c_edmz01" = {
        "nsg_name" = "GLB-PROD-Z1C-VNET01-EDMZ01"
        "resource_group" = "RG_ntw"
        "nsg_tags" = {  
            "remark"    = ""
        }
    },
    "z1c_idmz01" = {
        "nsg_name" = "GLB-PROD-Z1C-VNET01-IDMZ01"
        "resource_group" = "RG_ntw"
        "nsg_tags" = { 
            "remark"    = ""
        }
    },
    "z1c_int01" = {
        "nsg_name" = "GLB-PROD-Z1C-VNET01-INT01"
        "resource_group" = "RG_ntw"
        "nsg_tags" = {
            "remark"    = ""
        }
    },
    "z1c_edmz_pvtend01" = {
        "nsg_name" = "GLB-PROD-Z1C-VNET01-EDMZ-PVTEND01"
        "resource_group" = "RG_ntw"
        "nsg_tags" = {
            "remark"    = ""
        }
    },
    "z1c_cv01" = {
        "nsg_name" = "GLB-PROD-Z1C-VNET01-CV01"
        "resource_group" = "RG_ntw"
        "nsg_tags" = {
            "remark"    = ""
        }
    },
    "z1c_sl01" = {
        "nsg_name" = "GLB-PROD-Z1C-VNET01-SL01"
        "resource_group" = "RG_ntw"
        "nsg_tags" = {
            "remark"    = ""
        }
    },
    "z1c_sccm01" = {
        "nsg_name" = "GLB-PROD-Z1C-VNET01-SCCM01"
        "resource_group" = "RG_ntw"
        "nsg_tags" = {
            "remark"    = "" 
        }

    },
    "z3_edmz01" = {
        "nsg_name" = "GLB-PROD-Z3-VNET01-EDMZ01"
        "resource_group" = "RG_ntw"
        "nsg_tags" = {
            "remark"    = ""
        }
    },
    "z3_idmz01" = {
        "nsg_name" = "GLB-PROD-Z3-VNET01-IDMZ01"
        "resource_group" = "RG_ntw"
        "nsg_tags" = {
            "remark"    = ""
        }
    },
    "z3_int01" = {
        "nsg_name" = "GLB-PROD-Z3-VNET01-INT01"
        "resource_group" = "RG_ntw"
        "nsg_tags" = {
            "remark"    = ""
        }
    },
    "z3_edmz_pvtend01" = {
        "nsg_name" = "GLB-PROD-Z3-VNET01-EDMZ-PVTEND01"
        "resource_group" = "RG_ntw"
        "nsg_tags" = {
            "remark"    = ""
        }
    },
    "z3_cv01" = {
        "nsg_name" = "GLB-PROD-Z3-VNET01-CV01"
        "resource_group" = "RG_ntw"
        "nsg_tags" = {
            "remark"    = ""
        }
    }
}
###-----------------------------------NSG - Subnet Associations---------------------------------------

nsgAssociationSubnet = {
    "z1a_edmz01" = {
        "nsg_name"       = "z1a_edmz01"
        "subnet_name"    = "z1a_edmz01"
    },
    "z1a_idmz01" = {
        "nsg_name"       = "z1a_idmz01"
        "subnet_name"    = "z1a_idmz01"
    },
    "z1a_int01" = {
        "nsg_name"       = "z1a_int01"
        "subnet_name"    = "z1a_int01"
    },
    "z1a_edmz_pvtend01" = {
        "nsg_name"       = "z1a_edmz_pvtend01"
        "subnet_name"    = "z1a_edmz_pvtend01"
    },
    "z1a_cv01" = {
        "nsg_name"       = "z1a_cv01"
        "subnet_name"    = "z1a_cv01"
    },
    "z1b_edmz_sox01" = {
        "nsg_name"       = "z1b_edmz_sox01"
        "subnet_name"    = "z1b_edmz_sox01"
    },
    "z1b_edmz01" = {
        "nsg_name"       = "z1b_edmz01"
        "subnet_name"    = "z1b_edmz01"
    },
    "z1b_idmz_sox01" = {
        "nsg_name"       = "z1b_idmz_sox01"
        "subnet_name"    = "z1b_idmz_sox01"
    },
    "z1b_idmz01" = {
        "nsg_name"       = "z1b_idmz01"
        "subnet_name"    = "z1b_idmz01"
    },
    "z1b_int_sox01" = {
        "nsg_name"       = "z1b_int_sox01"
        "subnet_name"    = "z1b_int_sox01"
    },
    "z1b_int01" = {
        "nsg_name"       = "z1b_int01"
        "subnet_name"    = "z1b_int01"
    },
    "z1b_edmz_pvtend01" = {
        "nsg_name"       = "z1b_edmz_pvtend01"
        "subnet_name"    = "z1b_edmz_pvtend01"
    },
    "z1b_cv01" = {
        "nsg_name"       = "z1b_cv01"
        "subnet_name"    = "z1b_cv01"
    },
    "z1c_edmz01" = {
        "nsg_name"       = "z1c_edmz01"
        "subnet_name"    = "z1c_edmz01"
    },
    "z1c_idmz01" = {
        "nsg_name"       = "z1c_idmz01"
        "subnet_name"    = "z1c_idmz01"
    },
    "z1c_int01" = {
        "nsg_name"       = "z1c_int01"
        "subnet_name"    = "z1c_int01"
    },
    "z1c_edmz_pvtend01" = {
        "nsg_name"       = "z1c_edmz_pvtend01"
        "subnet_name"    = "z1c_edmz_pvtend01"
    },
    "z1c_cv01" = {
        "nsg_name"       = "z1c_cv01"
        "subnet_name"    = "z1c_cv01"
    },
    "z1c_sl01" = {
        "nsg_name"       = "z1c_sl01"
        "subnet_name"    = "z1c_sl01"
    },
    "z1c_sccm01" = {
        "nsg_name"       = "z1c_sccm01"
        "subnet_name"    = "z1c_sccm01"
    },
    "z3_edmz01" = {
        "nsg_name"       = "z3_edmz01"
        "subnet_name"    = "z3_edmz01"
    },
    "z3_idmz01" = {
        "nsg_name"       = "z3_idmz01"
        "subnet_name"    = "z3_idmz01"
    },
    "z3_int01" = {
        "nsg_name"       = "z3_int01"
        "subnet_name"    = "z3_int01"
    },
    "z3_edmz_pvtend01" = {
        "nsg_name"       = "z3_edmz_pvtend01"
        "subnet_name"    = "z3_edmz_pvtend01"
    },
    "z3_cv01" = {
        "nsg_name"       = "z3_cv01"
        "subnet_name"    = "z3_cv01"
    }
}

###--------------------------------------------NSG Rules-------------------------------------------
sl_asg_name     = null
sl_asg_rg_name  = null
nsg_rules = {

	"z1a_int01_01" = {
        "nsr_name" = "In-Allow-Z1ACommvault01"
        "nsg" = "z1a_int01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["8400","8401","8403","445","135","443","1434","1433","8111","8112","902","111","2049","9400","9401","5000","3306","1521","10000","22","8090"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1a"],
        "nsr_priority" = "3202"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["cv_z1a_asgs"]
    },
    "z1a_int01_02" = {
        "nsr_name" = "In-Allow-ScienceLogic"
        "nsg" = "z1a_int01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["22","5985","5986"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1a"],
        "nsr_priority" = "3204"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["sl_z1c_asgs"]
    },
    "z1a_int01_03" = {
        "nsr_name" = "In-Allow-Azure-GLBZ1A-VNET01-INT01"
        "nsg" = "z1a_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1a_int01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1a_int01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_int01_04" = {
        "nsr_name" = "In-Deny-Azure-GLBZ1A-VNET-01"
        "nsg" = "z1a_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1a"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1a"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_int01_05" = {
        "nsr_name" = "In-Allow-ABBnetwork-01"
        "nsg" = "z1a_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "VirtualNetwork",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_int01_06" = {
        "nsr_name" = "In-Allow-LBHealthProbe"
        "nsg" = "z1a_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1a"],
        "nsr_priority" = "3999"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_int01_07" = {
        "nsr_name" = "DenyAllInbound"
        "nsg" = "z1a_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_int01_08" = {
        "nsr_name" = "Out-Allow-Z1ACommvault01"
        "nsg" = "z1a_int01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["8400","8403","8401","445","135","443","1434 ","433","8111","8112","902","111","2049","9400","9401","5000","3306","1521","10000","22","8090","8091","8097","81","53"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1a"],
        "nsr_priority" = "3202"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["cv_z1a_asgs"]
    },
    "z1a_int01_09" = {
        "nsr_name" = "Out-Allow-Azure-GLBZ1A-VNET01-INT01"
        "nsg" = "z1a_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1a_int01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1a_int01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_int01_10" = {
        "nsr_name" = "Out-Deny-Azure-GLBZ1A-VNET-01"
        "nsg" = "z1a_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1a"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1a"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_int01_11" = {
        "nsr_name" = "Out-Allow-ABBnetwork-01"
        "nsg" = "z1a_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_int01_12" = {
        "nsr_name" = "Out-Allow-LBHealthProbe"
        "nsg" = "z1a_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3999"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_int01_13" = {
        "nsr_name" = "DenyAllOutBound"
        "nsg" = "z1a_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    }, 
    "z1a_idmz01_01" = {
        "nsr_name" = "In-Allow-Z1ACommvault01"
        "nsg" = "z1a_idmz01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["8400","8401","8403","445","135","443","1434","1433","8111","8112","902","111","2049","9400","9401","5000","3306","1521","10000","22","8090"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1a_idmz01"],
        "nsr_priority" = "3202"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["cv_z1a_asgs"]
    },
    "z1a_idmz01_02" = {
        "nsr_name" = "In-Allow-ScienceLogic"
        "nsg" = "z1a_idmz01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["22","5985","5986"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1a"],
        "nsr_priority" = "3204"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["sl_z1c_asgs"]
    },
    "z1a_idmz01_03" = {
        "nsr_name" = "In-Allow-Azure-GLBZ1A-VNET01-IDMZ01"
        "nsg" = "z1a_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1a_idmz01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1a_idmz01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_idmz01_04" = {
        "nsr_name" = "In-Deny-Azure-GLBZ1A-VNET-01"
        "nsg" = "z1a_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1a"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1a"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_idmz01_05" = {
        "nsr_name" = "In-Allow-ABBnetwork-01"
        "nsg" = "z1a_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "VirtualNetwork",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_idmz01_06" = {
        "nsr_name" = "In-Allow-LBHealthProbe"
        "nsg" = "z1a_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1a"],
        "nsr_priority" = "3999"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_idmz01_07" = {
        "nsr_name" = "DenyAllInbound"
        "nsg" = "z1a_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
       "z1a_idmz01_08" = {
        "nsr_name" = "Out-Allow-Azure-GLBZ1A-VNET01-IDMZ01"
        "nsg" = "z1a_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1a_idmz01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1a_idmz01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_idmz01_9" = {
        "nsr_name" = "Out-Deny-Azure-GLBZ1A-VNET-01"
        "nsg" = "z1a_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1a"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1a"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_idmz01_10" = {
        "nsr_name" = "Out-Allow-ABBnetwork-01"
        "nsg" = "z1a_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_idmz01_11" = {
        "nsr_name" = "Out-Allow-LBHealthProbe"
        "nsg" = "z1a_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3999"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_idmz01_12" = {
        "nsr_name" = "DenyAllOutBound"
        "nsg" = "z1a_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
	"z1a_edmz01_01" = {
        "nsr_name" = "In-Allow-Z1ACommvault01"
        "nsg" = "z1a_edmz01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["8400","8401","8403","445","135","443","1434","1433","8111","8112","902","111","2049","9400","9401","5000","3306","1521","10000","22","8090"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1a_edmz01"],
        "nsr_priority" = "3202"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["cv_z1a_asgs"]
    },
    "z1a_edmz01_02" = {
        "nsr_name" = "In-Allow-ScienceLogic"
        "nsg" = "z1a_edmz01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["22","5985","5986"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1a"],
        "nsr_priority" = "3204"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["sl_z1c_asgs"]
    },
    "z1a_edmz01_03" = {
        "nsr_name" = "In-Allow-Azure-GLBZ1A-VNET01-EDMZ01"
        "nsg" = "z1a_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1a_edmz01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1a_edmz01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_edmz01_04" = {
        "nsr_name" = "In-Deny-Azure-GLBZ1A-VNET-01"
        "nsg" = "z1a_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1a"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1a"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_edmz01_05" = {
        "nsr_name" = "In-Allow-ABBnetwork-01"
        "nsg" = "z1a_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "VirtualNetwork",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_edmz01_06" = {
        "nsr_name" = "In-Allow-LBHealthProbe"
        "nsg" = "z1a_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1a"],
        "nsr_priority" = "3999"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_edmz01_07" = {
        "nsr_name" = "DenyAllInbound"
        "nsg" = "z1a_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
       "z1a_edmz01_08" = {
        "nsr_name" = "Out-Allow-Azure-GLBZ1A-VNET01-EDMZ01"
        "nsg" = "z1a_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1a_edmz01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1a_edmz01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_edmz01_9" = {
        "nsr_name" = "Out-Deny-Azure-GLBZ1A-VNET-01"
        "nsg" = "z1a_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1a"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1a"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_edmz01_10" = {
        "nsr_name" = "Out-Allow-ABBnetwork-01"
        "nsg" = "z1a_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_edmz01_11" = {
        "nsr_name" = "Out-Allow-LBHealthProbe"
        "nsg" = "z1a_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3999"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_edmz01_12" = {
        "nsr_name" = "DenyAllOutBound"
        "nsg" = "z1a_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },

    "z1a_edmz_pvtend01_01" = {
        "nsr_name" = "In-Allow-ASR-PREP-01"
        "nsg" = "z1a_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1a"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1a_edmz_pvtend01"],
        "nsr_priority" = "3206"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_edmz_pvtend01_02" = {
        "nsr_name" = "Out-Allow-ASR-PREP-01"
        "nsg" = "z1a_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1a_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "Storage",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3206"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_edmz_pvtend01_03" = {
        "nsr_name" = "Out-Allow-ASR-PREP-02"
        "nsg" = "z1a_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1a_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "AzureActiveDirectory",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3207"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_edmz_pvtend01_04" = {
        "nsr_name" = "Out-Allow-ASR-PREP-03"
        "nsg" = "z1a_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1a_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "EventHub",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3208"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_edmz_pvtend01_05" = {
        "nsr_name" = "Out-Allow-ASR-PREP-04"
        "nsg" = "z1a_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1a_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "AzureSiteRecovery",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3209"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_edmz_pvtend01_06" = {
        "nsr_name" = "Out-Allow-ASR-PREP-05"
        "nsg" = "z1a_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1a_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "AzureKeyVault",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3210"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_edmz_pvtend01_07" = {
        "nsr_name" = "Out-Allow-ASR-PREP-06"
        "nsg" = "z1a_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1a_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "GuestAndHybridManagement",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3211"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
	"z1b_int01_01" = {
        "nsr_name" = "In-Allow-Z1BCommvault01"
        "nsg" = "z1b_int01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["8400","8401","8403","445","135","443","1434","1433","8111","8112","902","111","2049","9400","9401","5000","3306","1521","10000","22","8090"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3202"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["cv_z1b_asgs"]
    },
    "z1b_int01_02" = {
        "nsr_name" = "In-Allow-ScienceLogic"
        "nsg" = "z1b_int01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["22","5985","5986"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3204"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["sl_z1c_asgs"]
    },
    "z1b_int01_03" = {
        "nsr_name" = "In-Allow-Azure-GLBZ1B-VNET01-INT01"
        "nsg" = "z1b_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1b_int01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1b_int01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_int01_04" = {
        "nsr_name" = "In-Deny-Azure-GLBZ1B-VNET-01"
        "nsg" = "z1b_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1b"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_int01_05" = {
        "nsr_name" = "In-Allow-ABBnetwork-01"
        "nsg" = "z1b_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "VirtualNetwork",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_int01_06" = {
        "nsr_name" = "In-Allow-LBHealthProbe"
        "nsg" = "z1b_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3999"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_int01_07" = {
        "nsr_name" = "DenyAllInbound"
        "nsg" = "z1b_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_int01_08" = {
        "nsr_name" = "Out-Allow-z1bCommvault01"
        "nsg" = "z1b_int01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["8400","8403","8401","445","135","443","1434 ","433","8111","8112","902","111","2049","9400","9401","5000","3306","1521","10000","22","8090","8091","8097","81","53"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3202"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["cv_z1b_asgs"]
    },
    "z1b_int01_09" = {
        "nsr_name" = "Out-Allow-Azure-GLBZ1B-VNET01-INT01"
        "nsg" = "z1b_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1b_int01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1b_int01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_int01_10" = {
        "nsr_name" = "Out-Deny-Azure-GLBZ1B-VNET-01"
        "nsg" = "z1b_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1b"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_int01_11" = {
        "nsr_name" = "Out-Allow-ABBnetwork-01"
        "nsg" = "z1b_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_int01_12" = {
        "nsr_name" = "Out-Allow-LBHealthProbe"
        "nsg" = "z1b_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3999"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_int01_13" = {
        "nsr_name" = "DenyAllOutBound"
        "nsg" = "z1b_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    }, 
    "z1b_idmz01_01" = {
        "nsr_name" = "In-Allow-Z1BCommvault01"
        "nsg" = "z1b_idmz01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["8400","8401","8403","445","135","443","1434","1433","8111","8112","902","111","2049","9400","9401","5000","3306","1521","10000","22","8090"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1b_idmz01"],
        "nsr_priority" = "3202"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["cv_z1b_asgs"]
    },
    "z1b_idmz01_02" = {
        "nsr_name" = "In-Allow-ScienceLogic"
        "nsg" = "z1b_idmz01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["22","5985","5986"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3204"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["sl_z1c_asgs"]
    },
    "z1b_idmz01_03" = {
        "nsr_name" = "In-Allow-Azure-GLBZ1B-VNET01-IDMZ01"
        "nsg" = "z1b_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1b_idmz01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1b_idmz01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_idmz01_04" = {
        "nsr_name" = "In-Deny-Azure-GLBZ1B-VNET-01"
        "nsg" = "z1b_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1b"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_idmz01_05" = {
        "nsr_name" = "In-Allow-ABBnetwork-01"
        "nsg" = "z1b_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "VirtualNetwork",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_idmz01_06" = {
        "nsr_name" = "In-Allow-LBHealthProbe"
        "nsg" = "z1b_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3999"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_idmz01_07" = {
        "nsr_name" = "DenyAllInbound"
        "nsg" = "z1b_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
       "z1b_idmz01_08" = {
        "nsr_name" = "Out-Allow-Azure-GLBZ1B-VNET01-IDMZ01"
        "nsg" = "z1b_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1b_idmz01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1b_idmz01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_idmz01_9" = {
        "nsr_name" = "Out-Deny-Azure-GLBZ1B-VNET-01"
        "nsg" = "z1b_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1b"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_idmz01_10" = {
        "nsr_name" = "Out-Allow-ABBnetwork-01"
        "nsg" = "z1b_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_idmz01_11" = {
        "nsr_name" = "Out-Allow-LBHealthProbe"
        "nsg" = "z1b_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3999"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_idmz01_12" = {
        "nsr_name" = "DenyAllOutBound"
        "nsg" = "z1b_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
	"z1b_edmz01_01" = {
        "nsr_name" = "In-Allow-Z1BCommvault01"
        "nsg" = "z1b_edmz01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["8400","8401","8403","445","135","443","1434","1433","8111","8112","902","111","2049","9400","9401","5000","3306","1521","10000","22","8090"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1b_edmz01"],
        "nsr_priority" = "3202"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["cv_z1b_asgs"]
    },
    "z1b_edmz01_02" = {
        "nsr_name" = "In-Allow-ScienceLogic"
        "nsg" = "z1b_edmz01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["22","5985","5986"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3204"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["sl_z1c_asgs"]
    },
    "z1b_edmz01_03" = {
        "nsr_name" = "In-Allow-Azure-GLBZ1B-VNET01-EDMZ01"
        "nsg" = "z1b_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1b_edmz01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1b_edmz01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_edmz01_04" = {
        "nsr_name" = "In-Deny-Azure-GLBZ1B-VNET-01"
        "nsg" = "z1b_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1b"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_edmz01_05" = {
        "nsr_name" = "In-Allow-ABBnetwork-01"
        "nsg" = "z1b_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "VirtualNetwork",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_edmz01_06" = {
        "nsr_name" = "In-Allow-LBHealthProbe"
        "nsg" = "z1b_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3999"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_edmz01_07" = {
        "nsr_name" = "DenyAllInbound"
        "nsg" = "z1b_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
       "z1b_edmz01_08" = {
        "nsr_name" = "Out-Allow-Azure-GLBZ1B-VNET01-EDMZ01"
        "nsg" = "z1b_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1b_edmz01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1b_edmz01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_edmz01_9" = {
        "nsr_name" = "Out-Deny-Azure-GLBZ1B-VNET-01"
        "nsg" = "z1b_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1b"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_edmz01_10" = {
        "nsr_name" = "Out-Allow-ABBnetwork-01"
        "nsg" = "z1b_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_edmz01_11" = {
        "nsr_name" = "Out-Allow-LBHealthProbe"
        "nsg" = "z1b_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3999"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_edmz01_12" = {
        "nsr_name" = "DenyAllOutBound"
        "nsg" = "z1b_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },

    "z1b_edmz_pvtend01_01" = {
        "nsr_name" = "In-Allow-ASR-PREP-01"
        "nsg" = "z1b_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1b"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1b_edmz_pvtend01"],
        "nsr_priority" = "3206"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_edmz_pvtend01_02" = {
        "nsr_name" = "Out-Allow-ASR-PREP-01"
        "nsg" = "z1b_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1b_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "Storage",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3206"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_edmz_pvtend01_03" = {
        "nsr_name" = "Out-Allow-ASR-PREP-02"
        "nsg" = "z1b_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1b_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "AzureActiveDirectory",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3207"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_edmz_pvtend01_04" = {
        "nsr_name" = "Out-Allow-ASR-PREP-03"
        "nsg" = "z1b_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1b_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "EventHub",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3208"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_edmz_pvtend01_05" = {
        "nsr_name" = "Out-Allow-ASR-PREP-04"
        "nsg" = "z1b_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1b_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "AzureSiteRecovery",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3209"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_edmz_pvtend01_06" = {
        "nsr_name" = "Out-Allow-ASR-PREP-05"
        "nsg" = "z1b_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1b_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "AzureKeyVault",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3210"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_edmz_pvtend01_07" = {
        "nsr_name" = "Out-Allow-ASR-PREP-06"
        "nsg" = "z1b_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1b_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "GuestAndHybridManagement",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3211"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
"z1b_int_sox01_01" = {
        "nsr_name" = "In-Allow-Z1BCommvault01"
        "nsg" = "z1b_int_sox01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["8400","8401","8403","445","135","443","1434","1433","8111","8112","902","111","2049","9400","9401","5000","3306","1521","10000","22","8090"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3202"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["cv_z1b_asgs"]
    },
    "z1b_int_sox01_02" = {
        "nsr_name" = "In-Allow-ScienceLogic"
        "nsg" = "z1b_int_sox01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["22","5985","5986"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3204"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["sl_z1c_asgs"]
    },
    "z1b_int_sox01_03" = {
        "nsr_name" = "In-Allow-Azure-GLBZ1B-VNET01-int_sox01"
        "nsg" = "z1b_int_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1b_int_sox01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1b_int_sox01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_int_sox01_04" = {
        "nsr_name" = "In-Deny-Azure-GLBZ1B-VNET-01"
        "nsg" = "z1b_int_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1b"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_int_sox01_05" = {
        "nsr_name" = "In-Allow-ABBnetwork-01"
        "nsg" = "z1b_int_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "VirtualNetwork",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_int_sox01_06" = {
        "nsr_name" = "In-Allow-LBHealthProbe"
        "nsg" = "z1b_int_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3999"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_int_sox01_07" = {
        "nsr_name" = "DenyAllInbound"
        "nsg" = "z1b_int_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_int_sox01_08" = {
        "nsr_name" = "Out-Allow-z1bCommvault01"
        "nsg" = "z1b_int_sox01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["8400","8403","8401","445","135","443","1434 ","433","8111","8112","902","111","2049","9400","9401","5000","3306","1521","10000","22","8090","8091","8097","81","53"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3202"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["cv_z1b_asgs"]
    },
    "z1b_int_sox01_09" = {
        "nsr_name" = "Out-Allow-Azure-GLBZ1B-VNET01-int_sox01"
        "nsg" = "z1b_int_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1b_int_sox01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1b_int_sox01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_int_sox01_10" = {
        "nsr_name" = "Out-Deny-Azure-GLBZ1B-VNET-01"
        "nsg" = "z1b_int_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1b"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_int_sox01_11" = {
        "nsr_name" = "Out-Allow-ABBnetwork-01"
        "nsg" = "z1b_int_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_int_sox01_12" = {
        "nsr_name" = "Out-Allow-LBHealthProbe"
        "nsg" = "z1b_int_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3999"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_int_sox01_13" = {
        "nsr_name" = "DenyAllOutBound"
        "nsg" = "z1b_int_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    }, 
    "z1b_idmz_sox01_01" = {
        "nsr_name" = "In-Allow-Z1BCommvault01"
        "nsg" = "z1b_idmz_sox01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["8400","8401","8403","445","135","443","1434","1433","8111","8112","902","111","2049","9400","9401","5000","3306","1521","10000","22","8090"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1b_idmz_sox01"],
        "nsr_priority" = "3202"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["cv_z1b_asgs"]
    },
    "z1b_idmz_sox01_02" = {
        "nsr_name" = "In-Allow-ScienceLogic"
        "nsg" = "z1b_idmz_sox01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["22","5985","5986"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3204"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["sl_z1c_asgs"]
    },
    "z1b_idmz_sox01_03" = {
        "nsr_name" = "In-Allow-Azure-GLBZ1B-VNET01-idmz_sox01"
        "nsg" = "z1b_idmz_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1b_idmz_sox01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1b_idmz_sox01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_idmz_sox01_04" = {
        "nsr_name" = "In-Deny-Azure-GLBZ1B-VNET-01"
        "nsg" = "z1b_idmz_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1b"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_idmz_sox01_05" = {
        "nsr_name" = "In-Allow-ABBnetwork-01"
        "nsg" = "z1b_idmz_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "VirtualNetwork",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_idmz_sox01_06" = {
        "nsr_name" = "In-Allow-LBHealthProbe"
        "nsg" = "z1b_idmz_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3999"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_idmz_sox01_07" = {
        "nsr_name" = "DenyAllInbound"
        "nsg" = "z1b_idmz_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
       "z1b_idmz_sox01_08" = {
        "nsr_name" = "Out-Allow-Azure-GLBZ1B-VNET01-idmz_sox01"
        "nsg" = "z1b_idmz_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1b_idmz_sox01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1b_idmz_sox01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_idmz_sox01_9" = {
        "nsr_name" = "Out-Deny-Azure-GLBZ1B-VNET-01"
        "nsg" = "z1b_idmz_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1b"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_idmz_sox01_10" = {
        "nsr_name" = "Out-Allow-ABBnetwork-01"
        "nsg" = "z1b_idmz_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_idmz_sox01_11" = {
        "nsr_name" = "Out-Allow-LBHealthProbe"
        "nsg" = "z1b_idmz_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3999"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_idmz_sox01_12" = {
        "nsr_name" = "DenyAllOutBound"
        "nsg" = "z1b_idmz_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
	"z1b_edmz_sox01_01" = {
        "nsr_name" = "In-Allow-Z1BCommvault01"
        "nsg" = "z1b_edmz_sox01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["8400","8401","8403","445","135","443","1434","1433","8111","8112","902","111","2049","9400","9401","5000","3306","1521","10000","22","8090"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1b_edmz_sox01"],
        "nsr_priority" = "3202"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["cv_z1b_asgs"]
    },
    "z1b_edmz_sox01_02" = {
        "nsr_name" = "In-Allow-ScienceLogic"
        "nsg" = "z1b_edmz_sox01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["22","5985","5986"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3204"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["sl_z1c_asgs"]
    },
    "z1b_edmz_sox01_03" = {
        "nsr_name" = "In-Allow-Azure-GLBZ1B-VNET01-edmz_sox01"
        "nsg" = "z1b_edmz_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1b_edmz_sox01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1b_edmz_sox01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_edmz_sox01_04" = {
        "nsr_name" = "In-Deny-Azure-GLBZ1B-VNET-01"
        "nsg" = "z1b_edmz_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1b"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_edmz_sox01_05" = {
        "nsr_name" = "In-Allow-ABBnetwork-01"
        "nsg" = "z1b_edmz_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "VirtualNetwork",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_edmz_sox01_06" = {
        "nsr_name" = "In-Allow-LBHealthProbe"
        "nsg" = "z1b_edmz_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3999"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_edmz_sox01_07" = {
        "nsr_name" = "DenyAllInbound"
        "nsg" = "z1b_edmz_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
       "z1b_edmz_sox01_08" = {
        "nsr_name" = "Out-Allow-Azure-GLBZ1B-VNET01-edmz_sox01"
        "nsg" = "z1b_edmz_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1b_edmz_sox01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1b_edmz_sox01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_edmz_sox01_9" = {
        "nsr_name" = "Out-Deny-Azure-GLBZ1B-VNET-01"
        "nsg" = "z1b_edmz_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1b"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1b"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_edmz_sox01_10" = {
        "nsr_name" = "Out-Allow-ABBnetwork-01"
        "nsg" = "z1b_edmz_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_edmz_sox01_11" = {
        "nsr_name" = "Out-Allow-LBHealthProbe"
        "nsg" = "z1b_edmz_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3999"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1b_edmz_sox01_12" = {
        "nsr_name" = "DenyAllOutBound"
        "nsg" = "z1b_edmz_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
	"z1c_int01_01" = {
        "nsr_name" = "In-Allow-Z1CCommvault01"
        "nsg" = "z1c_int01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["8400","8401","8403","445","135","443","1434","1433","8111","8112","902","111","2049","9400","9401","5000","3306","1521","10000","22","8090"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1c"],
        "nsr_priority" = "3202"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["cv_z1c_asgs"]
    },
    "z1c_int01_02" = {
        "nsr_name" = "In-Allow-ScienceLogic"
        "nsg" = "z1c_int01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["22","5985","5986"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1c"],
        "nsr_priority" = "3204"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["sl_z1c_asgs"]
    },
    "z1c_int01_03" = {
        "nsr_name" = "In-Allow-Azure-GLBZ1C-VNET01-INT01"
        "nsg" = "z1c_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1c_int01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1c_int01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_int01_04" = {
        "nsr_name" = "In-Deny-Azure-GLBZ1C-VNET-01"
        "nsg" = "z1c_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1c"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1c"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_int01_05" = {
        "nsr_name" = "In-Allow-ABBnetwork-01"
        "nsg" = "z1c_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "VirtualNetwork",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_int01_06" = {
        "nsr_name" = "In-Allow-LBHealthProbe"
        "nsg" = "z1c_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1c"],
        "nsr_priority" = "3999"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_int01_07" = {
        "nsr_name" = "DenyAllInbound"
        "nsg" = "z1c_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_int01_08" = {
        "nsr_name" = "Out-Allow-Z1CCommvault01"
        "nsg" = "z1c_int01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["8400","8403","8401","445","135","443","1434 ","433","8111","8112","902","111","2049","9400","9401","5000","3306","1521","10000","22","8090","8091","8097","81","53"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1c"],
        "nsr_priority" = "3202"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["cv_z1c_asgs"]
    },
    "z1c_int01_09" = {
        "nsr_name" = "Out-Allow-Azure-GLBZ1C-VNET01-INT01"
        "nsg" = "z1c_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1c_int01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1c_int01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_int01_10" = {
        "nsr_name" = "Out-Deny-Azure-GLBZ1C-VNET-01"
        "nsg" = "z1c_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1c"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1c"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_int01_11" = {
        "nsr_name" = "Out-Allow-ABBnetwork-01"
        "nsg" = "z1c_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_int01_12" = {
        "nsr_name" = "Out-Allow-LBHealthProbe"
        "nsg" = "z1c_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3999"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_int01_13" = {
        "nsr_name" = "DenyAllOutBound"
        "nsg" = "z1c_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    }, 
    "z1c_idmz01_01" = {
        "nsr_name" = "In-Allow-Z1CCommvault01"
        "nsg" = "z1c_idmz01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["8400","8401","8403","445","135","443","1434","1433","8111","8112","902","111","2049","9400","9401","5000","3306","1521","10000","22","8090"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1c_idmz01"],
        "nsr_priority" = "3202"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["cv_z1c_asgs"]
    },
    "z1c_idmz01_02" = {
        "nsr_name" = "In-Allow-ScienceLogic"
        "nsg" = "z1c_idmz01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["22","5985","5986"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1c"],
        "nsr_priority" = "3204"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["sl_z1c_asgs"]
    },
    "z1c_idmz01_03" = {
        "nsr_name" = "In-Allow-Azure-GLBZ1C-VNET01-IDMZ01"
        "nsg" = "z1c_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1c_idmz01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1c_idmz01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_idmz01_04" = {
        "nsr_name" = "In-Deny-Azure-GLBZ1C-VNET-01"
        "nsg" = "z1c_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1c"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1c"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_idmz01_05" = {
        "nsr_name" = "In-Allow-ABBnetwork-01"
        "nsg" = "z1c_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "VirtualNetwork",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_idmz01_06" = {
        "nsr_name" = "In-Allow-LBHealthProbe"
        "nsg" = "z1c_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1c"],
        "nsr_priority" = "3999"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_idmz01_07" = {
        "nsr_name" = "DenyAllInbound"
        "nsg" = "z1c_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
       "z1c_idmz01_08" = {
        "nsr_name" = "Out-Allow-Azure-GLBZ1C-VNET01-IDMZ01"
        "nsg" = "z1c_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1c_idmz01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1c_idmz01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_idmz01_9" = {
        "nsr_name" = "Out-Deny-Azure-GLBZ1C-VNET-01"
        "nsg" = "z1c_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1c"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1c"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_idmz01_10" = {
        "nsr_name" = "Out-Allow-ABBnetwork-01"
        "nsg" = "z1c_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_idmz01_11" = {
        "nsr_name" = "Out-Allow-LBHealthProbe"
        "nsg" = "z1c_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3999"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_idmz01_12" = {
        "nsr_name" = "DenyAllOutBound"
        "nsg" = "z1c_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
	"z1c_edmz01_01" = {
        "nsr_name" = "In-Allow-Z1CCommvault01"
        "nsg" = "z1c_edmz01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["8400","8401","8403","445","135","443","1434","1433","8111","8112","902","111","2049","9400","9401","5000","3306","1521","10000","22","8090"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1c_edmz01"],
        "nsr_priority" = "3202"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["cv_z1c_asgs"]
    },
    "z1c_edmz01_02" = {
        "nsr_name" = "In-Allow-ScienceLogic"
        "nsg" = "z1c_edmz01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["22","5985","5986"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1c"],
        "nsr_priority" = "3204"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["sl_z1c_asgs"]
    },
    "z1c_edmz01_03" = {
        "nsr_name" = "In-Allow-Azure-GLBZ1C-VNET01-EDMZ01"
        "nsg" = "z1c_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1c_edmz01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1c_edmz01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_edmz01_04" = {
        "nsr_name" = "In-Deny-Azure-GLBZ1C-VNET-01"
        "nsg" = "z1c_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1c"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1c"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_edmz01_05" = {
        "nsr_name" = "In-Allow-ABBnetwork-01"
        "nsg" = "z1c_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "VirtualNetwork",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_edmz01_06" = {
        "nsr_name" = "In-Allow-LBHealthProbe"
        "nsg" = "z1c_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1c"],
        "nsr_priority" = "3999"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_edmz01_07" = {
        "nsr_name" = "DenyAllInbound"
        "nsg" = "z1c_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
       "z1c_edmz01_08" = {
        "nsr_name" = "Out-Allow-Azure-GLBZ1C-VNET01-EDMZ01"
        "nsg" = "z1c_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1c_edmz01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1c_edmz01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_edmz01_9" = {
        "nsr_name" = "Out-Deny-Azure-GLBZ1C-VNET-01"
        "nsg" = "z1c_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1c"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z1c"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_edmz01_10" = {
        "nsr_name" = "Out-Allow-ABBnetwork-01"
        "nsg" = "z1c_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_edmz01_11" = {
        "nsr_name" = "Out-Allow-LBHealthProbe"
        "nsg" = "z1c_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3999"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_edmz01_12" = {
        "nsr_name" = "DenyAllOutBound"
        "nsg" = "z1c_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },

    "z1c_edmz_pvtend01_01" = {
        "nsr_name" = "In-Allow-ASR-PREP-01"
        "nsg" = "z1c_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z1c"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1c_edmz_pvtend01"],
        "nsr_priority" = "3206"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_edmz_pvtend01_02" = {
        "nsr_name" = "Out-Allow-ASR-PREP-01"
        "nsg" = "z1c_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1c_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "Storage",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3206"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_edmz_pvtend01_03" = {
        "nsr_name" = "Out-Allow-ASR-PREP-02"
        "nsg" = "z1c_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1c_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "AzureActiveDirectory",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3207"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_edmz_pvtend01_04" = {
        "nsr_name" = "Out-Allow-ASR-PREP-03"
        "nsg" = "z1c_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1c_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "EventHub",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3208"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_edmz_pvtend01_05" = {
        "nsr_name" = "Out-Allow-ASR-PREP-04"
        "nsg" = "z1c_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1c_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "AzureSiteRecovery",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3209"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_edmz_pvtend01_06" = {
        "nsr_name" = "Out-Allow-ASR-PREP-05"
        "nsg" = "z1c_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1c_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "AzureKeyVault",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3210"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1c_edmz_pvtend01_07" = {
        "nsr_name" = "Out-Allow-ASR-PREP-06"
        "nsg" = "z1c_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z1c_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "GuestAndHybridManagement",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3211"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
	"z3_int01_01" = {
        "nsr_name" = "In-Allow-Z3Commvault01"
        "nsg" = "z3_int01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["8400","8401","8403","445","135","443","1434","1433","8111","8112","902","111","2049","9400","9401","5000","3306","1521","10000","22","8090"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z3"],
        "nsr_priority" = "3202"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["cv_z3_asgs"]
    },
    "z3_int01_02" = {
        "nsr_name" = "In-Allow-ScienceLogic"
        "nsg" = "z3_int01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["22","5985","5986"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z3"],
        "nsr_priority" = "3204"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["sl_z1c_asgs"]
    },
    "z3_int01_03" = {
        "nsr_name" = "In-Allow-Azure-GLBZ3-VNET01-INT01"
        "nsg" = "z3_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z3_int01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z3_int01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_int01_04" = {
        "nsr_name" = "In-Deny-Azure-GLBZ3-VNET-01"
        "nsg" = "z3_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z3"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z3"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_int01_05" = {
        "nsr_name" = "In-Allow-ABBnetwork-01"
        "nsg" = "z3_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "VirtualNetwork",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_int01_06" = {
        "nsr_name" = "In-Allow-LBHealthProbe"
        "nsg" = "z3_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z3"],
        "nsr_priority" = "3999"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_int01_07" = {
        "nsr_name" = "DenyAllInbound"
        "nsg" = "z3_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_int01_08" = {
        "nsr_name" = "Out-Allow-Z3Commvault01"
        "nsg" = "z3_int01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["8400","8403","8401","445","135","443","1434 ","433","8111","8112","902","111","2049","9400","9401","5000","3306","1521","10000","22","8090","8091","8097","81","53"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z3"],
        "nsr_priority" = "3202"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["cv_z3_asgs"]
    },
    "z3_int01_09" = {
        "nsr_name" = "Out-Allow-Azure-GLBZ3-VNET01-INT01"
        "nsg" = "z3_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z3_int01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z3_int01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_int01_10" = {
        "nsr_name" = "Out-Deny-Azure-GLBZ3-VNET-01"
        "nsg" = "z3_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z3"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z3"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_int01_11" = {
        "nsr_name" = "Out-Allow-ABBnetwork-01"
        "nsg" = "z3_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_int01_12" = {
        "nsr_name" = "Out-Allow-LBHealthProbe"
        "nsg" = "z3_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3999"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_int01_13" = {
        "nsr_name" = "DenyAllOutBound"
        "nsg" = "z3_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    }, 
    "z3_idmz01_01" = {
        "nsr_name" = "In-Allow-Z3Commvault01"
        "nsg" = "z3_idmz01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["8400","8401","8403","445","135","443","1434","1433","8111","8112","902","111","2049","9400","9401","5000","3306","1521","10000","22","8090"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z3_idmz01"],
        "nsr_priority" = "3202"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["cv_z3_asgs"]
    },
    "z3_idmz01_02" = {
        "nsr_name" = "In-Allow-ScienceLogic"
        "nsg" = "z3_idmz01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["22","5985","5986"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z3"],
        "nsr_priority" = "3204"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["sl_z1c_asgs"]
    },
    "z3_idmz01_03" = {
        "nsr_name" = "In-Allow-Azure-GLBZ3-VNET01-IDMZ01"
        "nsg" = "z3_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z3_idmz01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z3_idmz01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_idmz01_04" = {
        "nsr_name" = "In-Deny-Azure-GLBZ3-VNET-01"
        "nsg" = "z3_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z3"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z3"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_idmz01_05" = {
        "nsr_name" = "In-Allow-ABBnetwork-01"
        "nsg" = "z3_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "VirtualNetwork",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_idmz01_06" = {
        "nsr_name" = "In-Allow-LBHealthProbe"
        "nsg" = "z3_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z3"],
        "nsr_priority" = "3999"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_idmz01_07" = {
        "nsr_name" = "DenyAllInbound"
        "nsg" = "z3_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
       "z3_idmz01_08" = {
        "nsr_name" = "Out-Allow-Azure-GLBZ3-VNET01-IDMZ01"
        "nsg" = "z3_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z3_idmz01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z3_idmz01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_idmz01_9" = {
        "nsr_name" = "Out-Deny-Azure-GLBZ3-VNET-01"
        "nsg" = "z3_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z3"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z3"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_idmz01_10" = {
        "nsr_name" = "Out-Allow-ABBnetwork-01"
        "nsg" = "z3_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_idmz01_11" = {
        "nsr_name" = "Out-Allow-LBHealthProbe"
        "nsg" = "z3_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3999"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_idmz01_12" = {
        "nsr_name" = "DenyAllOutBound"
        "nsg" = "z3_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
	"z3_edmz01_01" = {
        "nsr_name" = "In-Allow-Z3Commvault01"
        "nsg" = "z3_edmz01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["8400","8401","8403","445","135","443","1434","1433","8111","8112","902","111","2049","9400","9401","5000","3306","1521","10000","22","8090"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z3_edmz01"],
        "nsr_priority" = "3202"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["cv_z3_asgs"]
    },
    "z3_edmz01_02" = {
        "nsr_name" = "In-Allow-ScienceLogic"
        "nsg" = "z3_edmz01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["22","5985","5986"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z3"],
        "nsr_priority" = "3204"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["sl_z1c_asgs"]
    },
    "z3_edmz01_03" = {
        "nsr_name" = "In-Allow-Azure-GLBZ3-VNET01-EDMZ01"
        "nsg" = "z3_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z3_edmz01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z3_edmz01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_edmz01_04" = {
        "nsr_name" = "In-Deny-Azure-GLBZ3-VNET-01"
        "nsg" = "z3_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z3"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z3"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_edmz01_05" = {
        "nsr_name" = "In-Allow-ABBnetwork-01"
        "nsg" = "z3_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "VirtualNetwork",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_edmz01_06" = {
        "nsr_name" = "In-Allow-LBHealthProbe"
        "nsg" = "z3_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z3"],
        "nsr_priority" = "3999"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_edmz01_07" = {
        "nsr_name" = "DenyAllInbound"
        "nsg" = "z3_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
       "z3_edmz01_08" = {
        "nsr_name" = "Out-Allow-Azure-GLBZ3-VNET01-EDMZ01"
        "nsg" = "z3_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z3_edmz01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z3_edmz01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_edmz01_9" = {
        "nsr_name" = "Out-Deny-Azure-GLBZ3-VNET-01"
        "nsg" = "z3_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z3"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_z3"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_edmz01_10" = {
        "nsr_name" = "Out-Allow-ABBnetwork-01"
        "nsg" = "z3_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_edmz01_11" = {
        "nsr_name" = "Out-Allow-LBHealthProbe"
        "nsg" = "z3_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3999"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_edmz01_12" = {
        "nsr_name" = "DenyAllOutBound"
        "nsg" = "z3_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },

    "z3_edmz_pvtend01_01" = {
        "nsr_name" = "In-Allow-ASR-PREP-01"
        "nsg" = "z3_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_z3"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z3_edmz_pvtend01"],
        "nsr_priority" = "3206"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_edmz_pvtend01_02" = {
        "nsr_name" = "Out-Allow-ASR-PREP-01"
        "nsg" = "z3_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z3_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "Storage",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3206"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_edmz_pvtend01_03" = {
        "nsr_name" = "Out-Allow-ASR-PREP-02"
        "nsg" = "z3_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z3_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "AzureActiveDirectory",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3207"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_edmz_pvtend01_04" = {
        "nsr_name" = "Out-Allow-ASR-PREP-03"
        "nsg" = "z3_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z3_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "EventHub",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3208"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_edmz_pvtend01_05" = {
        "nsr_name" = "Out-Allow-ASR-PREP-04"
        "nsg" = "z3_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z3_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "AzureSiteRecovery",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3209"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_edmz_pvtend01_06" = {
        "nsr_name" = "Out-Allow-ASR-PREP-05"
        "nsg" = "z3_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z3_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "AzureKeyVault",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3210"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z3_edmz_pvtend01_07" = {
        "nsr_name" = "Out-Allow-ASR-PREP-06"
        "nsg" = "z3_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["z3_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "GuestAndHybridManagement",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3211"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "z1a_edmz01_13" = {
        "nsr_name" = "In-Deny-WIZ-Ports"
        "nsg" = "z1a_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = null,
        "nsr_source_port_ranges" = ["5984","7473","7474","110","995","8080","28015","29015","8087","8098","7574","8983","1024","7000","7001","7199","9042", "9142","9160","137","138","445","139","445","53","9200","9300","2379","20","21","80","443","5601","11211","27017-27020","4333","1433","1434","3306","1521", "1830","2483","2484","5432","3389","6379","135","445","25","22","23","5500","5800","5900"]
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1a_edmz01"],
        "nsr_priority" = "3800"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
      "nsr_source_application_security_group_ids" = null
    },
    "z1a_idmz01_13" = {
        "nsr_name" = "In-Deny-WIZ-Ports"
        "nsg" = "z1a_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = null,
        "nsr_source_port_ranges" = ["5984","7473","7474","110","995","8080","28015","29015","8087","8098","7574","8983","1024","7000","7001","7199","9042", "9142","9160","137","138","445","139","445","53","9200","9300","2379","20","21","80","443","5601","11211","27017-27020","4333","1433","1434","3306","1521", "1830","2483","2484","5432","3389","6379","135","445","25","22","23","5500","5800","5900"]
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1a_idmz01"],
        "nsr_priority" = "3800"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
      "nsr_source_application_security_group_ids" = null
    },
    "z1a_int01_14" = {
        "nsr_name" = "In-Deny-WIZ-Ports"
        "nsg" = "z1a_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = null,
        "nsr_source_port_ranges" = ["5984","7473","7474","110","995","8080","28015","29015","8087","8098","7574","8983","1024","7000","7001","7199","9042", "9142","9160","137","138","445","139","445","53","9200","9300","2379","20","21","80","443","5601","11211","27017-27020","4333","1433","1434","3306","1521", "1830","2483","2484","5432","3389","6379","135","445","25","22","23","5500","5800","5900"]
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1a_int01"],
        "nsr_priority" = "3800"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
      "nsr_source_application_security_group_ids" = null
    },
    "z1b_edmz01_13" = {
        "nsr_name" = "In-Deny-WIZ-Ports"
        "nsg" = "z1b_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = null,
        "nsr_source_port_ranges" = ["5984","7473","7474","110","995","8080","28015","29015","8087","8098","7574","8983","1024","7000","7001","7199","9042", "9142","9160","137","138","445","139","445","53","9200","9300","2379","20","21","80","443","5601","11211","27017-27020","4333","1433","1434","3306","1521", "1830","2483","2484","5432","3389","6379","135","445","25","22","23","5500","5800","5900"]
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1b_edmz01"],
        "nsr_priority" = "3800"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
      "nsr_source_application_security_group_ids" = null
    },
    "z1b_idmz01_13" = {
        "nsr_name" = "In-Deny-WIZ-Ports"
        "nsg" = "z1b_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = null,
        "nsr_source_port_ranges" = ["5984","7473","7474","110","995","8080","28015","29015","8087","8098","7574","8983","1024","7000","7001","7199","9042", "9142","9160","137","138","445","139","445","53","9200","9300","2379","20","21","80","443","5601","11211","27017-27020","4333","1433","1434","3306","1521", "1830","2483","2484","5432","3389","6379","135","445","25","22","23","5500","5800","5900"]
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1b_idmz01"],
        "nsr_priority" = "3800"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
      "nsr_source_application_security_group_ids" = null
    },
    "z1b_int01_14" = {
        "nsr_name" = "In-Deny-WIZ-Ports"
        "nsg" = "z1b_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = null,
        "nsr_source_port_ranges" = ["5984","7473","7474","110","995","8080","28015","29015","8087","8098","7574","8983","1024","7000","7001","7199","9042", "9142","9160","137","138","445","139","445","53","9200","9300","2379","20","21","80","443","5601","11211","27017-27020","4333","1433","1434","3306","1521", "1830","2483","2484","5432","3389","6379","135","445","25","22","23","5500","5800","5900"]
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1b_int01"],
        "nsr_priority" = "3800"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
	    "nsr_source_application_security_group_ids" = null
    },
    "z1b_edmz_sox01_13" = {
        "nsr_name" = "In-Deny-WIZ-Ports"
        "nsg" = "z1b_edmz_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = null,
        "nsr_source_port_ranges" = ["5984","7473","7474","110","995","8080","28015","29015","8087","8098","7574","8983","1024","7000","7001","7199","9042", "9142","9160","137","138","445","139","445","53","9200","9300","2379","20","21","80","443","5601","11211","27017-27020","4333","1433","1434","3306","1521", "1830","2483","2484","5432","3389","6379","135","445","25","22","23","5500","5800","5900"]
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1b_edmz_sox01"],
        "nsr_priority" = "3800"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
	    "nsr_source_application_security_group_ids" = null
    },
    "z1b_idmz_sox01_13" = {
        "nsr_name" = "In-Deny-WIZ-Ports"
        "nsg" = "z1b_idmz_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = null,
        "nsr_source_port_ranges" = ["5984","7473","7474","110","995","8080","28015","29015","8087","8098","7574","8983","1024","7000","7001","7199","9042", "9142","9160","137","138","445","139","445","53","9200","9300","2379","20","21","80","443","5601","11211","27017-27020","4333","1433","1434","3306","1521", "1830","2483","2484","5432","3389","6379","135","445","25","22","23","5500","5800","5900"]
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1b_idmz_sox01"],
        "nsr_priority" = "3800"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
	    "nsr_source_application_security_group_ids" = null
    },
    "z1b_int_sox01_14" = {
        "nsr_name" = "In-Deny-WIZ-Ports"
        "nsg" = "z1b_int_sox01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = null,
        "nsr_source_port_ranges" = ["5984","7473","7474","110","995","8080","28015","29015","8087","8098","7574","8983","1024","7000","7001","7199","9042", "9142","9160","137","138","445","139","445","53","9200","9300","2379","20","21","80","443","5601","11211","27017-27020","4333","1433","1434","3306","1521", "1830","2483","2484","5432","3389","6379","135","445","25","22","23","5500","5800","5900"]
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1b_int_sox01"],
        "nsr_priority" = "3800"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
	    "nsr_source_application_security_group_ids" = null
    },

    "z1c_edmz01_13" = {
        "nsr_name" = "In-Deny-WIZ-Ports"
        "nsg" = "z1c_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = null,
        "nsr_source_port_ranges" = ["5984","7473","7474","110","995","8080","28015","29015","8087","8098","7574","8983","1024","7000","7001","7199","9042", "9142","9160","137","138","445","139","445","53","9200","9300","2379","20","21","80","443","5601","11211","27017-27020","4333","1433","1434","3306","1521", "1830","2483","2484","5432","3389","6379","135","445","25","22","23","5500","5800","5900"]
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1c_edmz01"],
        "nsr_priority" = "3800"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
	    "nsr_source_application_security_group_ids" = null
    },
    "z1c_idmz01_13" = {
        "nsr_name" = "In-Deny-WIZ-Ports"
        "nsg" = "z1c_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = null,
        "nsr_source_port_ranges" = ["5984","7473","7474","110","995","8080","28015","29015","8087","8098","7574","8983","1024","7000","7001","7199","9042", "9142","9160","137","138","445","139","445","53","9200","9300","2379","20","21","80","443","5601","11211","27017-27020","4333","1433","1434","3306","1521", "1830","2483","2484","5432","3389","6379","135","445","25","22","23","5500","5800","5900"]
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1c_idmz01"],
        "nsr_priority" = "3800"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
	    "nsr_source_application_security_group_ids" = null
    },
    "z1c_int01_14" = {
        "nsr_name" = "In-Deny-WIZ-Ports"
        "nsg" = "z1c_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = null,
        "nsr_source_port_ranges" = ["5984","7473","7474","110","995","8080","28015","29015","8087","8098","7574","8983","1024","7000","7001","7199","9042", "9142","9160","137","138","445","139","445","53","9200","9300","2379","20","21","80","443","5601","11211","27017-27020","4333","1433","1434","3306","1521", "1830","2483","2484","5432","3389","6379","135","445","25","22","23","5500","5800","5900"]
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z1c_int01"],
        "nsr_priority" = "3800"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
	    "nsr_source_application_security_group_ids" = null
    },

    "z3_edmz01_13" = {
        "nsr_name" = "In-Deny-WIZ-Ports"
        "nsg" = "z3_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = null,
        "nsr_source_port_ranges" = ["5984","7473","7474","110","995","8080","28015","29015","8087","8098","7574","8983","1024","7000","7001","7199","9042", "9142","9160","137","138","445","139","445","53","9200","9300","2379","20","21","80","443","5601","11211","27017-27020","4333","1433","1434","3306","1521", "1830","2483","2484","5432","3389","6379","135","445","25","22","23","5500","5800","5900"]
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z3_edmz01"],
        "nsr_priority" = "3800"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
	    "nsr_source_application_security_group_ids" = null
    },
    "z3_idmz01_13" = {
        "nsr_name" = "In-Deny-WIZ-Ports"
        "nsg" = "z3_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = null,
        "nsr_source_port_ranges" = ["5984","7473","7474","110","995","8080","28015","29015","8087","8098","7574","8983","1024","7000","7001","7199","9042", "9142","9160","137","138","445","139","445","53","9200","9300","2379","20","21","80","443","5601","11211","27017-27020","4333","1433","1434","3306","1521", "1830","2483","2484","5432","3389","6379","135","445","25","22","23","5500","5800","5900"]
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z3_idmz01"],
        "nsr_priority" = "3800"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
	    "nsr_source_application_security_group_ids" = null
    },
    "z3_int01_14" = {
        "nsr_name" = "In-Deny-WIZ-Ports"
        "nsg" = "z3_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = null,
        "nsr_source_port_ranges" = ["5984","7473","7474","110","995","8080","28015","29015","8087","8098","7574","8983","1024","7000","7001","7199","9042", "9142","9160","137","138","445","139","445","53","9200","9300","2379","20","21","80","443","5601","11211","27017-27020","4333","1433","1434","3306","1521", "1830","2483","2484","5432","3389","6379","135","445","25","22","23","5500","5800","5900"]
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["z3_int01"],
        "nsr_priority" = "3800"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
	    "nsr_source_application_security_group_ids" = null
    }
}

#------------------------------------Azure Virtual Network Manager---------------------------

avnm_shortlocation = "SWC"
avnm_subscription_name = "HUB-01"
ntw_group_name = "ALL-VNETs"
ntw_manager_name = "AVNM01"
static_members = {
    "static_member_01" = {
        avnm_static_member_name = "Z1A-Vnet"
        vnet_name = "vnet_z1a"
    },
    "static_member_02" = {
        avnm_static_member_name = "Z1B-Vnet"
        vnet_name = "vnet_z1b"
    },
    "static_member_03" = {
        avnm_static_member_name = "Z1C-Vnet"
        vnet_name = "vnet_z1c"
    },
    "static_member_04" = {
        avnm_static_member_name = "Z3-Vnet"
        vnet_name = "vnet_z3"
    }
}

avnm_rules = {
    "avnm_rule_01" = {
        avnm_rule_name = "RTB-GLBZ1A-VNET-01"
        vnet_name = "vnet_z1a"
        type = "AddressPrefix"
        nextHopType = "VirtualAppliance"
        lb_name = "glb_fw"
    },
     "avnm_rule_02" = {
        avnm_rule_name = "RTB-GLBZ1B-VNET-01"
        vnet_name = "vnet_z1b"
        type = "AddressPrefix"
        nextHopType = "VirtualAppliance"
        lb_name = "glb_fw"
    },
     "avnm_rule_03" = {
        avnm_rule_name = "RTB-GLBZ1C-VNET-01"
        vnet_name = "vnet_z1c"
        type = "AddressPrefix"
        nextHopType = "VirtualAppliance"
        lb_name = "glb_fw"
    },
     "avnm_rule_04" = {
        avnm_rule_name = "RTB-GLBZ3-VNET-01"
        vnet_name = "vnet_z3"
        type = "AddressPrefix"
        nextHopType = "VirtualAppliance"
        lb_name = "glb_fw"
    }
}

avnm_rule_collection_name = "VNET01-GW01-UDR01-RC01"
avnm_routing_name = "VNET01-GW01-UDR01"
glb_fw = {
    "glb_fw" = {
        glb-fw-lb-name = "backend-lb"
        glb_fw_lb_rg = "RG-F-GLBFW"
    }
}

###----------------------------------------- Vnet Flow logs ----------------------------------------
sta_name          = "glbprdstalog02"
sta_rg            = "RG-F-MGMT"
law_name          = "LA-01"
law_rg            = "RG-F-MGMT"
enabled               = true
flow_log_version      = 2
retention_days        = 31
traffic_analytics_enabled   = true
interval_in_minutes   = 10

#----------------------------------- Key Vault Creation ---------------------------
keyvault = {
    "kv_glb"    = {
        key_vault_name ="glbprd-kv-01"
        resource_group_name ="RG_app"
        subnet_name         = ["z1a_int01","z1a_idmz01","z1a_edmz01","z1a_edmz_pvtend01","z1a_cv01","z1b_int01","z1b_idmz01","z1b_edmz01","z1b_edmz_pvtend01","z1b_int_sox01","z1b_idmz_sox01","z1b_edmz_sox01","z1b_cv01","z1c_int01","z1c_idmz01","z1c_edmz01","z1c_edmz_pvtend01","z1c_cv01","z1c_sl01","z1c_sccm01","z3_int01","z3_idmz01","z3_edmz01","z3_cv01","z3_edmz_pvtend01"]
        tags                ={}
        dlog_name           = "kv-cv01"
    }
}
kv_sku_name                     = "standard"
kv_purge_protection_enabled     = true
kv_soft_delete_retention_days   = 30
kv_enable_rbac_authorization    = true
kv_enabled_for_disk_encryption  = true
kv_enabled_for_template_deployment  = true
kv_enabled_for_deployment           = true
kv_public_network_access_enabled    = true
kv_bypass                     = "AzureServices"
kv_default_action             = "Deny"
kv_ip_rules                   = []

#self hosted vm network details
iac_vnet_name = "IAC-VNET01"
iac_vnet_rg   = "IAC01-RG-F-NETWORK"
iac_subnet_name ="IAC-VNET01-INT01"
iac_shortlocation = "SWC"

# DNS entry details
dns_shortlocation       = "WE"
private_dns_zone_rgName = "HUB01-RG-F-DNS"
sta_dns_zone_name       = "privatelink.blob.core.windows.net"
kv_dns_zone_name        = "privatelink.vaultcore.azure.net"
###-----------------------------------Private Endpoint-----------------------------------------------
pvt_endpoints = {
    "pe_kv_z1a" = {
        "pe_name"                               = "GLBZ1A-PREP-KV-001"
        "resource_group"                        = "RG_app"
        "subnet_name"                           = "z1a_edmz_pvtend01"
        "key_vault_name"                        = "kv_glb"
        "is_manual_connection"                  = false
        "subresource_names"                     = ["vault"]
        "pe_tags"                               = {
            "remark"        = ""
        }
    },
    "pe_kv_z1b" = {
        "pe_name"                               = "GLBZ1B-PREP-KV-001"
        "resource_group"                        = "RG_app"
        "subnet_name"                           = "z1b_edmz_pvtend01"
        "key_vault_name"                        = "kv_glb"
        "is_manual_connection"                  = false
        "subresource_names"                     = ["vault"]
        "pe_tags"                               = {
            "remark"        = ""
        }
    },
    "pe_kv_z1c" = {
        "pe_name"                               = "GLBZ1C-PREP-KV-001"
        "resource_group"                        = "RG_app"
        "subnet_name"                           = "z1c_edmz_pvtend01"
        "key_vault_name"                        = "kv_glb"
        "is_manual_connection"                  = false
        "subresource_names"                     = ["vault"]
        "pe_tags"                               = {
            "remark"        = ""
        }
    },
    "pe_kv_z3" = {
        "pe_name"                               = "GLBZ3-PREP-KV-001"
        "resource_group"                        = "RG_app"
        "subnet_name"                           = "z3_edmz_pvtend01"
        "key_vault_name"                        = "kv_glb"
        "is_manual_connection"                  = false
        "subresource_names"                     = ["vault"]
        "pe_tags"                               = {
            "remark"        = ""
        }
    }
}

# ####-------------------Key Vault Key ----------------------------
keyvault_key       ={
    "kv_key_disk"   ={
        kv_key_name = "diskencryptkey"
        kv_name     = "kv_glb"
        kvk_tags    ={}
    },
    "kv_key_storage"   ={
        kv_key_name = "storageencryptkey"
        kv_name     = "kv_glb"
        kvk_tags    ={}
    }
}

  kv_key_type        = "RSA"
  kv_key_opts        = ["decrypt", "encrypt", "sign", "unwrapKey", "verify", "wrapKey"]
  kv_key_size        = "2048"
  expiration_date = null

###---------------------------------------Role Assignemnt------------------------------------
role_assign_kv = {
    role_kv = {
        "role_definition_name" = "Key Vault Administrator"
    }
}

role_assign_sta = {
    role_sta_z1a = {
        "role_definition_name" = "Key Vault Crypto Service Encryption User"
        "kv_name"              = "kv_glb"
        "sta_name"             = "sta_glb_z1a"
    }
    role_sta_z1b = {
        "role_definition_name" = "Key Vault Crypto Service Encryption User"
        "kv_name"              = "kv_glb"
        "sta_name"             = "sta_glb_z1b"
    }
    role_sta_z1c = {
        "role_definition_name" = "Key Vault Crypto Service Encryption User"
        "kv_name"              = "kv_glb"
        "sta_name"             = "sta_glb_z1c"
    }
    role_sta_z3 = {
        "role_definition_name" = "Key Vault Crypto Service Encryption User"
        "kv_name"              = "kv_glb"
        "sta_name"             = "sta_glb_z3"
    }
}

#-----------------------------------------Diagnostic settings ----------------------
enable_logs         = true
enabled_metric      = false
workspace_rs_id     = ""

#------------------------------------Storage Accounts-------------------------------
storage_accounts        = {
    "sta_glb_z1a"  = {
       "sta_name"                         = "glbz1astablbcv01"
       "resource_group"                   = "RG_cv"
       "tags"  = {   
           "remark" = ""
        }
    },
    "sta_glb_z1b"  = {
       "sta_name"                         = "glbz1bstablbcv01"
       "resource_group"                   = "RG_cv"
       "tags"  = {   
           "remark" = ""
        }
    },
    "sta_glb_z1c"  = {
       "sta_name"                         = "glbz1cstablbcv01"
       "resource_group"                   = "RG_cv"
       "tags"  = {   
           "remark" = ""
        }
    },
    "sta_glb_z3"  = {
       "sta_name"                         = "glbz3stablbcv01"
       "resource_group"                   = "RG_cv"
       "tags"  = {   
           "remark" = ""
        }
    }
}

account_tier                      = "Standard"
access_tier                       = "Cool"
account_replication_type          = "LRS"
cross_tenant_replication_enabled  = false
is_hns_enabled                    = false
delete_retention_days             = 7
container_delete_retention_days   = 0
allow_blob_public_access          = false
public_network_access_enabled     = true
infrastructure_encryption_enabled = true
shared_access_key_enabled         = true
versioning_enabled                = false
large_file_share_enabled          = true
min_tls_version                   = "TLS1_2"

###-----------------------------------Private Endpoint-----------------------------------------------
pvt_endpoints_sta = {
    "pe_sta_z1a" = {
        "pe_name"                         = "GLBZ1A-PREP-CVSTA-001"
        "resource_group"                  = "RG_cv"
        "subnet_name"                     = "z1a_edmz_pvtend01"
        "sta_name"                        = "sta_glb_z1a"
        "is_manual_connection"            = false
        "subresource_names"               = ["blob"]
        "pe_tags"                         = {
            "remark"        = ""
        }
    },
    "pe_sta_z1b" = {
        "pe_name"                         = "GLBZ1B-PREP-CVSTA-001"
        "resource_group"                  = "RG_cv"
        "subnet_name"                     = "z1b_edmz_pvtend01"
        "sta_name"                        = "sta_glb_z1b"
        "is_manual_connection"            = false
        "subresource_names"               = ["blob"]
        "pe_tags"                         = {
            "remark"        = ""
        }
    },
    "pe_sta_z1c" = {
        "pe_name"                         = "GLBZ1C-PREP-CVSTA-001"
        "resource_group"                  = "RG_cv"
        "subnet_name"                     = "z1c_edmz_pvtend01"
        "sta_name"                        = "sta_glb_z1c"
        "is_manual_connection"            = false
        "subresource_names"               = ["blob"]
        "pe_tags"                         = {
            "remark"        = ""
        }
    },
    "pe_sta_z3" = {
        "pe_name"                         = "GLBZ3-PREP-CVSTA-001"
        "resource_group"                  = "RG_cv"
        "subnet_name"                     = "z3_edmz_pvtend01"
        "sta_name"                        = "sta_glb_z3"
        "is_manual_connection"            = false
        "subresource_names"               = ["blob"]
        "pe_tags"                         = {
            "remark"        = ""
        }
    }

}

sta_ip_rules    = {
    "sta_rules_z1a" = {
        "storage_account_name"      = "sta_glb_z1a"
        "default_action"            = "Deny"
        "ip_rules"                  = []
        "subnet_name"               = ["z1a_int01","z1a_idmz01","z1a_edmz01","z1a_edmz_pvtend01","z1a_cv01"]
        "bypass"                    = ["AzureServices"]
    },
    "sta_rules_z1b" = {
        "storage_account_name"      = "sta_glb_z1b"
        "default_action"            = "Deny"
        "ip_rules"                  = []
        "subnet_name"               = ["z1b_int01","z1b_idmz01","z1b_edmz01","z1b_edmz_pvtend01","z1b_int_sox01","z1b_idmz_sox01","z1b_edmz_sox01","z1b_cv01"]
        "bypass"                    = ["AzureServices"]
    },
    "sta_rules_z1c" = {
        "storage_account_name"      = "sta_glb_z1c"
        "default_action"            = "Deny"
        "ip_rules"                  = []
        "subnet_name"               = ["z1c_int01","z1c_idmz01","z1c_edmz01","z1c_edmz_pvtend01","z1c_cv01","z1c_sl01","z1c_sccm01"]
        "bypass"                    = ["AzureServices"]
    },
    "sta_rules_z3" = {
        "storage_account_name"      = "sta_glb_z3"
        "default_action"            = "Deny"
        "ip_rules"                  = []
        "subnet_name"               = ["z3_int01","z3_idmz01","z3_edmz01","z3_cv01","z3_edmz_pvtend01"]
        "bypass"                    = ["AzureServices"]
    }
}

#------------------------------------- Lifecycle Management of Storage Account-----------------------
management_policies = {
    "sta_policy_z1a" = {
        rule_name = "glbz1astablbcv01"
        storage_account_name = "sta_glb_z1a"
    },
    "sta_policy_z1b" = {
        rule_name = "glbz1bstablbcv01"
        storage_account_name = "sta_glb_z1b"
    },
    "sta_policy_z1c" = {
        rule_name = "glbz1cstablbcv01"
        storage_account_name = "sta_glb_z1c"
    },
    "sta_policy_z3" = {
        rule_name = "glbz3stablbcv01"
        storage_account_name = "sta_glb_z3"
    }
}

rule_enabled = true
blob_types = ["blockBlob"]
delete_after_days_since_modification_greater_than = 90
delete_after_days_since_creation_greater_than = 90

#---------------------------------- Customer Managed Key - Storage Account -----------------
cmk_sta = {
    "cmk_sta_z1a" = {
        "sta_name" = "sta_glb_z1a"
        "kv_name"  = "kv_glb"
        "key_name" = "storageencryptkey"
    },
    "cmk_sta_z1b" = {
        "sta_name" = "sta_glb_z1b"
        "kv_name"  = "kv_glb"
        "key_name" = "storageencryptkey"
    },
    "cmk_sta_z1c" = {
        "sta_name" = "sta_glb_z1c"
        "kv_name"  = "kv_glb"
        "key_name" = "storageencryptkey"
    },
    "cmk_sta_z3" = {
        "sta_name" = "sta_glb_z3"
        "kv_name"  = "kv_glb"
        "key_name" = "storageencryptkey"
    }
}

###------------------------------------Diagnostic Storage Accounts-------------------------------
storage_accounts_diag        = {
    "sta_glb_diag"  = {
       "sta_name"                         = "glbprddiags1"
       "resource_group"                   = "RG_mgmt"
       "tags"  = {   
           "remark" = ""
        }
    }
}

delete_retention_days_01         = 0
access_tier_diag                     = "Hot"
###-----------------------------------Diagnostic Private Endpoint-----------------------------------------------
pvt_endpoints_sta_diag = {
    "pe_sta_diag" = {
        "pe_name"                         = "GLB-PROD-PREP-DIAGSTA-001"
        "resource_group"                  = "RG_mgmt"
        "subnet_name"                     = "z1a_edmz_pvtend01"
        "sta_name"                        = "sta_glb_diag"
        "is_manual_connection"            = false
        "subresource_names"               = ["blob"]
        "pe_tags"                         = {
            "remark"        = ""
        }
    }

}

sta_ip_rules_diag   = {
    "sta_rules_diag" = {
        "storage_account_name"      = "sta_glb_diag"
        "default_action"            = "Deny"
        "ip_rules"                  = ["20.91.100.236", "51.12.22.174", "51.12.22.175", "51.12.22.204", "51.12.72.222", "51.12.72.223", "51.12.73.92", "172.160.216.6"]
        "subnet_name"               = ["z1a_int01","z1a_idmz01","z1a_edmz01","z1a_edmz_pvtend01","z1a_cv01","z1b_int01","z1b_idmz01","z1b_edmz01","z1b_edmz_pvtend01","z1b_int_sox01","z1b_idmz_sox01","z1b_edmz_sox01","z1b_cv01","z1c_int01","z1c_idmz01","z1c_edmz01","z1c_edmz_pvtend01","z1c_cv01","z1c_sl01","z1c_sccm01","z3_int01","z3_idmz01","z3_edmz01","z3_cv01","z3_edmz_pvtend01"]
        "bypass"                    = ["AzureServices"]
    }
}

#------------------------------------- Lifecycle Management of Storage Account-----------------------
management_policies_diag = {
    "sta_management_policy_diag" = {
        rule_name = "glbprddiags1"
        storage_account_name = "sta_glb_diag"
    }
}

###---------------------------------------Role Assignemnt------------------------------------
role_assign_sta_diag = {
    role_sta_diag = {
        "role_definition_name" = "Key Vault Crypto Service Encryption User"
        "kv_name"              = "kv_glb"
        "sta_name"             = "sta_glb_diag"
    }
}

#---------------------------------- Customer Managed Key - Storage Account -----------------
cmk_sta_diag = {
    "cmk_sta_diag" = {
        "sta_name" = "sta_glb_diag"
        "kv_name"  = "kv_glb"
        "key_name" = "storageencryptkey"
    }
}

###-------------------------------------- Disk Encryption Set ---------------------------------
cv_des = {
    cv_des_01 = {
        des_name       = "GLBPROD01"
        resource_group = "RG_app"
        kv_key_name    = "kv_key_disk"
        kv_name        = "kv_glb"
        tags           = {}
    }
}
role_definition_name = "Key Vault Crypto Service Encryption User"

###------------------------------------- Network Interface --------------------------------------
cv_nics = {
    "cv_nic_01" = {
        nic_name = "ZWCV001"
        resource_group = "RG_cv"
        subnet_name = "z1a_cv01"
        ip_configs = [{
            ip_config_name = "ipconfig1"
            private_ip_address_allocation = "Dynamic"
            primary = true
        }]
        tags = {}
        },

    "cv_nic_02" = {
        nic_name = "ZWCV002"
        resource_group = "RG_cv"
        subnet_name = "z1a_cv01"
        ip_configs = [{
            ip_config_name = "ipconfig1"
            private_ip_address_allocation = "Dynamic"
            primary = true
        }]
        tags ={}
    },
    "cv_nic_03" = {
        nic_name = "ZWCV003"
        resource_group = "RG_cv"
        subnet_name = "z1b_cv01"
        ip_configs = [{
            ip_config_name = "ipconfig1"
            private_ip_address_allocation = "Dynamic"
            primary = true
        }]
        tags ={}
    },
    "cv_nic_04" = {
        nic_name = "ZWCV004"
        resource_group = "RG_cv"
        subnet_name = "z1b_cv01"
        ip_configs = [{
            ip_config_name = "ipconfig1"
            private_ip_address_allocation = "Dynamic"
            primary = true
        }]
        tags ={}
    },
    "cv_nic_05" = {
        nic_name = "ZWCV005"
        resource_group = "RG_cv"
        subnet_name = "z1c_cv01"
        ip_configs = [{
            ip_config_name = "ipconfig1"
            private_ip_address_allocation = "Dynamic"
            primary = true
        }]
        tags ={}
    },
    "cv_nic_06" = {
        nic_name = "ZWCV006"
        resource_group = "RG_cv"
        subnet_name = "z1c_cv01"
        ip_configs = [{
            ip_config_name = "ipconfig1"
            private_ip_address_allocation = "Dynamic"
            primary = true
        }]
        tags ={}
    },
    "cv_nic_07" = {
        nic_name = "ZWCV007"
        resource_group = "RG_cv"
        subnet_name = "z3_cv01"
        ip_configs = [{
            ip_config_name = "ipconfig1"
            private_ip_address_allocation = "Dynamic"
            primary = true
        }]
        tags ={}
    },
    "cv_nic_08" = {
        nic_name = "ZWCV008"
        resource_group = "RG_cv"
        subnet_name = "z3_cv01"
        ip_configs = [{
            ip_config_name = "ipconfig1"
            private_ip_address_allocation = "Dynamic"
            primary = true
        }]
        tags ={}
    }
}

accelerated_networking_enabled = true
###-----------------------------------Disk access and Private endpoint-----------------------------

disk_access_vms = {
    "disk_access_01" = {
        "disk_name"         = "Commvault-GLB-PROD-DiskAccess"
        "resource_group"    = "RG_cv"
        "tags"              = {}
    }
}

pvt_endpoints_disk_access = {
    "PE_disk_z1a" = {
        "pe_name"               = "GLBZ1A-PREP-DA-001"
        "disk_name"             = "disk_access_01"
        "subnet_name"           = "z1a_edmz_pvtend01"
        "resource_group"        = "RG_cv"
        "is_manual_connection"  = false
        "subresource_names"     = ["disks"]
        "pe_tags"               = {}
    },
    "PE_disk_z1b" = {
        "pe_name"               = "GLBZ1B-PREP-DA-001"
        "disk_name"             = "disk_access_01"
        "subnet_name"           = "z1b_edmz_pvtend01"
        "resource_group"        = "RG_cv"
        "is_manual_connection"  = false
        "subresource_names"     = ["disks"]
        "pe_tags"               = {}
    },
    "PE_disk_z1c" = {
        "pe_name"               = "GLBZ1C-PREP-DA-001"
        "disk_name"             = "disk_access_01"
        "subnet_name"           = "z1c_edmz_pvtend01"
        "resource_group"        = "RG_cv"
        "is_manual_connection"  = false
        "subresource_names"     = ["disks"]
        "pe_tags"               = {}
    },
    "PE_disk_z3" = {
        "pe_name"               = "GLBZ3-PREP-DA-001"
        "disk_name"             = "disk_access_01"
        "subnet_name"           = "z3_edmz_pvtend01"
        "resource_group"        = "RG_cv"
        "is_manual_connection"  = false
        "subresource_names"     = ["disks"]
        "pe_tags"               = {}
    }
}

###----------------------------------- Windows Virtual Machine ---------------------------------
cv_vms = {
    "cv_vm_01" = {
        cv_vm_names    = "ZWCV001"
        resource_group = "RG_cv"
        nic_name       = "cv_nic_01"
        avset_name     = ""
        zone           = "1"
        des_name       = "cv_des_01"
        sta_name       = "sta_glb_diag"
        tags           = {}

    },
    "cv_vm_02" = {
        cv_vm_names    = "ZWCV002"
        resource_group = "RG_cv"
        nic_name       = "cv_nic_02"
        avset_name     = ""
        zone           = "2"
        des_name       = "cv_des_01"
        sta_name       = "sta_glb_diag"
        tags           = {}
    },
    "cv_vm_03" = {
        cv_vm_names    = "ZWCV003"
        resource_group = "RG_cv"
        nic_name       = "cv_nic_03"
        avset_name     = ""
        zone           = "1"
        des_name       = "cv_des_01"
        sta_name       = "sta_glb_diag"
        tags           = {}

    },
    "cv_vm_04" = {
        cv_vm_names    = "ZWCV004"
        resource_group = "RG_cv"
        nic_name       = "cv_nic_04"
        avset_name     = ""
        zone           = "2"
        des_name       = "cv_des_01"
        sta_name       = "sta_glb_diag"
        tags           = {}
    },
    "cv_vm_05" = {
        cv_vm_names    = "ZWCV005"
        resource_group = "RG_cv"
        nic_name       = "cv_nic_05"
        avset_name     = ""
        zone           = "1"
        des_name       = "cv_des_01"
        sta_name       = "sta_glb_diag"
        tags           = {}

    },
    "cv_vm_06" = {
        cv_vm_names    = "ZWCV006"
        resource_group = "RG_cv"
        nic_name       = "cv_nic_06"
        avset_name     = ""
        zone           = "2"
        des_name       = "cv_des_01"
        sta_name       = "sta_glb_diag"
        tags           = {}
    },
    "cv_vm_07" = {
        cv_vm_names    = "ZWCV007"
        resource_group = "RG_cv"
        nic_name       = "cv_nic_07"
        avset_name     = ""
        zone           = "1"
        des_name       = "cv_des_01"
        sta_name       = "sta_glb_diag"
        tags           = {}

    },
    "cv_vm_08" = {
        cv_vm_names    = "ZWCV008"
        resource_group = "RG_cv"
        nic_name       = "cv_nic_08"
        avset_name     = ""
        zone           = "2"
        des_name       = "cv_des_01"
        sta_name       = "sta_glb_diag"
        tags           = {}
    }
}

cv_vm_instance_type = "Standard_D2s_v5"
encryption_at_host_enabled = true
secure_boot_enabled       = false
vtpm_enabled              = false 
license_type              = "Windows_Server" 
disk_controller_type      = "SCSI"
disk_storage_account_type = "StandardSSD_LRS"
vm_os_disk_name            = null
vm_extension_name          = "IaaSAntimalware"
publisher                  = "Microsoft.Azure.Security"
type                       = "IaaSAntimalware"
type_handler_version       = "1.7"
auto_upgrade_minor_version = true
identity_type              = "SystemAssigned"
identity_ids               = []
vm_source_image_reference   = null
plan_details                = null
golden_win_name                = "1.0.4"
golden_win_image_name          = "Windows_2022"
golden_win_gallery_name        = "Cloud_Golden_Images_New"
golden_win_shortlocation       = "et"
golden_win_rg                  = "01-rg-c-9aag026594"
###------------------------------------Data Disks ----------------------------------
cv_data_disks = {
    "cv01_data_disk_01" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 512
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_01"
        "disk_name"      = "disk_access_01"
        "lun"            = 0 
        "tags"           = {}
    },
    "cv01_data_disk_02" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 1024
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_01"
        "disk_name"      = "disk_access_01"
        "lun"            = 1 
        "tags"           = {}
    },
    "cv01_data_disk_03" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 1024
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_01"
        "disk_name"      = "disk_access_01"
        "lun"            = 2 
        "tags"           = {}
    },
    "cv02_data_disk_01" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 512
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_02"
        "disk_name"      = "disk_access_01"
        "lun"            = 0 
        "tags"           = {}
    },
    "cv02_data_disk_02" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 1024
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_02"
        "disk_name"      = "disk_access_01"
        "lun"            = 1 
        "tags"           = {}
    },
    "cv02_data_disk_03" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 1024
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_02"
        "disk_name"      = "disk_access_01"
        "lun"            = 2 
        "tags"           = {}
    },
    "cv03_data_disk_01" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 512
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_03"
        "disk_name"      = "disk_access_01"
        "lun"            = 0 
        "tags"           = {}
    },
    "cv03_data_disk_02" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 1024
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_03"
        "disk_name"      = "disk_access_01"
        "lun"            = 1 
        "tags"           = {}
    },
    "cv03_data_disk_03" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 1024
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_03"
        "disk_name"      = "disk_access_01"
        "lun"            = 2 
        "tags"           = {}
    },
    "cv04_data_disk_01" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 512
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_04"
        "disk_name"      = "disk_access_01"
        "lun"            = 0 
        "tags"           = {}
    },
    "cv04_data_disk_02" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 1024
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_04"
        "disk_name"      = "disk_access_01"
        "lun"            = 1 
        "tags"           = {}
    },
    "cv04_data_disk_03" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 1024
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_04"
        "disk_name"      = "disk_access_01"
        "lun"            = 2 
        "tags"           = {}
    },
    "cv05_data_disk_01" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 512
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_05"
        "disk_name"      = "disk_access_01"
        "lun"            = 0 
        "tags"           = {}
    },
    "cv05_data_disk_02" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 1024
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_05"
        "disk_name"      = "disk_access_01"
        "lun"            = 1 
        "tags"           = {}
    },
    "cv05_data_disk_03" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 1024
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_05"
        "disk_name"      = "disk_access_01"
        "lun"            = 2 
        "tags"           = {}
    },
    "cv06_data_disk_01" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 512
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_06"
        "disk_name"      = "disk_access_01"
        "lun"            = 0 
        "tags"           = {}
    },
    "cv06_data_disk_02" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 1024
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_06"
        "disk_name"      = "disk_access_01"
        "lun"            = 1 
        "tags"           = {}
    },
    "cv06_data_disk_03" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 1024
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_06"
        "disk_name"      = "disk_access_01"
        "lun"            = 2 
        "tags"           = {}
    },
    "cv07_data_disk_01" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 512
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_07"
        "disk_name"      = "disk_access_01"
        "lun"            = 0 
        "tags"           = {}
    },
    "cv07_data_disk_02" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 1024
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_07"
        "disk_name"      = "disk_access_01"
        "lun"            = 1 
        "tags"           = {}
    },
    "cv07_data_disk_03" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 1024
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_07"
        "disk_name"      = "disk_access_01"
        "lun"            = 2 
        "tags"           = {}
    },
    "cv08_data_disk_01" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 512
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_08"
        "disk_name"      = "disk_access_01"
        "lun"            = 0 
        "tags"           = {}
    },
    "cv08_data_disk_02" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 1024
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_08"
        "disk_name"      = "disk_access_01"
        "lun"            = 1 
        "tags"           = {}
    },
    "cv08_data_disk_03" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 1024
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_08"
        "disk_name"      = "disk_access_01"
        "lun"            = 2 
        "tags"           = {}
    }
}

data_disk_sa_type       = "Premium_LRS"
data_disk_create_option = "Empty"
data_disk_caching        = "None"
data_disk_write_accelerator = false
public_network_access_enabled_disks = false
network_access_policy_data_disk = "AllowPrivate"

####-------------------------------------SCCM VMs----------------------------------------

sccm_nics = {
    "sccm_nic_01" = {
        nic_name = "ZWDP026"
        resource_group = "RG_sccm"
        subnet_name = "z1c_sccm01"
        ip_configs = [{
            ip_config_name = "ipconfig1"
            private_ip_address_allocation = "Dynamic"
            primary = true
        }]
        tags = {}
        },
        "sccm_nic_02" = {
        nic_name = "ZWDP027"
        resource_group = "RG_sccm"
        subnet_name = "z1c_sccm01"
        ip_configs = [{
            ip_config_name = "ipconfig1"
            private_ip_address_allocation = "Dynamic"
            primary = true
        }]
        tags = {}
        }
}

disk_access_vms_sccm = {

     "disk_access_sccm" = {
        "disk_name"         = "SCCM-GLB-PROD-DiskAccess"
        "resource_group"    = "RG_sccm"
        "tags"              = {}
    }
}

pvt_endpoints_disk_access_sccm = {
    "PE_disk_sccm" = {
        "pe_name"               = "PREP-DA-001"
        "disk_name"             = "disk_access_sccm"
        "subnet_name"           = "z1c_edmz_pvtend01"
        "resource_group"        = "RG_sccm"
        "is_manual_connection"  = false
        "subresource_names"     = ["disks"]
        "pe_tags"               = {}
    }
}
sccm_vms = {
    "sccm_vm_01" = {
        "sccm_vm_names"                           = "ZWDP026"
        "resource_group"                          = "RG_sccm"
        "nic_name"                                = "sccm_nic_01"
        "avset_name"                              = ""
        "des_name"                                = "cv_des_01"
        "sta_name"                                = "sta_glb_diag"
        "tags"                                    = {}
        "zone"                                    = "1"
        "encryption_at_host_enabled"              = true
        "secure_boot_enabled"                     = false
        "vtpm_enabled"                            = false 
        "license_type"                            = "Windows_Server" 
        "disk_storage_account_type"               = "StandardSSD_LRS"
        "vm_os_disk_name"                         = null
        "vm_extension_name"                       = "IaaSAntimalware"
        "publisher"                               = "Microsoft.Azure.Security"
        "type"                                    = "IaaSAntimalware"
        "type_handler_version"                    = "1.7"
        "auto_upgrade_minor_version"              = true
        "identity_type"                           = "SystemAssigned"
        "identity_ids"                            = []

    },
    "sccm_vm_02" = {
        "sccm_vm_names"                           = "ZWDP027"
        "resource_group"                          = "RG_sccm"
        "nic_name"                                = "sccm_nic_02"
        "avset_name"                              = ""
        "des_name"                                = "cv_des_01"
        "sta_name"                                = "sta_glb_diag"
        "tags"                                    = {}
        "zone"                                    = "2"
        "encryption_at_host_enabled"              = true
        "secure_boot_enabled"                     = false
        "vtpm_enabled"                            = false 
        "license_type"                            = "Windows_Server" 
        "disk_storage_account_type"               = "StandardSSD_LRS"
        "vm_os_disk_name"                         = null
        "vm_extension_name"                       = "IaaSAntimalware"
        "publisher"                               = "Microsoft.Azure.Security"
        "type"                                    = "IaaSAntimalware"
        "type_handler_version"                    = "1.7"
        "auto_upgrade_minor_version"              = true
        "identity_type"                           = "SystemAssigned"
        "identity_ids"                            = []
    }
}

sccm_vm_instance_type = "Standard_D2s_v5"
sccm_data_disks = {
    "sccm01_data_disk_01" = {
        "resource_group" = "RG_sccm"
        "disk_size_gb"   = 256
        "des_id"         = "cv_des_01"
        "vm_name"        = "sccm_vm_01"
        "disk_name"      = "disk_access_sccm"
        "public_network_access_enabled" = false
        "network_access_policy" = "AllowPrivate"
        "lun"            = 0 
        "tags"           = {}
    },
    "sccm01_data_disk_02" = {
        "resource_group" = "RG_sccm"
        "disk_size_gb"   = 256
        "des_id"         = "cv_des_01"
        "vm_name"        = "sccm_vm_02"
        "disk_name"      = "disk_access_sccm"
        "public_network_access_enabled" = false
        "network_access_policy" = "AllowPrivate"
        "lun"            = 0 
        "tags"           = {}
    }
}

###------------------------------------------SL NIC------------------------------------------------
sl_nics = {
    "sl_nic_01" = {
        nic_name = "ZLSL019"
        resource_group = "RG_sl"
        subnet_name = "z1c_sl01"
        ip_configs = [{
            ip_config_name = "ipconfig1"
            private_ip_address_allocation = "Dynamic"
            primary = true
        }]
        tags = {}
    },
    "sl_nic_02" = {
        nic_name = "ZLSL020"
        resource_group = "RG_sl"
        subnet_name = "z1c_sl01"
        ip_configs = [{
            ip_config_name = "ipconfig1"
            private_ip_address_allocation = "Dynamic"
            primary = true
        }]
        tags = {}
    }
}

###-----------------------------Disk access and Private endpoints for SL-------------------------------
disk_access_vms_sl = {

     "disk_access_sl" = {
        "disk_name"         = "ScienceLogic-GLB-PROD-DiskAccess"
        "resource_group"    = "RG_sl"
        "tags"              = {}
    }
}

pvt_endpoints_disk_access_sl = {
    "PE_disk_sl" = {
        "pe_name"               = "PREP-DA-001"
        "disk_name"             = "disk_access_sl"
        "subnet_name"           = "z1c_edmz_pvtend01"
        "resource_group"        = "RG_sl"
        "is_manual_connection"  = false
        "subresource_names"     = ["disks"]
        "pe_tags"               = {}
    }
}
sl_vms = {
    "sl_vm_01" = {
        "sl_vm_names"                             = "ZLSL019"
        "resource_group"                          = "RG_sl"
        "nic_name"                                = "sl_nic_01"
        "avset_name"                              = ""
        "des_name"                                = "cv_des_01"
        "sta_name"                                = "sta_glb_diag"
        "tags"                                    = {}
        "zone"                                    = "1"
        "encryption_at_host_enabled"              = true
        "disable_password_authentication"         = false
        "secure_boot_enabled"                     = false
        "vtpm_enabled"                            = false
        "vm_os_disk_name"                         = null
        "identity_type"                           = "SystemAssigned"
        "identity_ids"                            = []
    },
    "sl_vm_02" = {
        "sl_vm_names"                             = "ZLSL020"
        "resource_group"                          = "RG_sl"
        "nic_name"                                = "sl_nic_02"
        "avset_name"                              = ""
        "des_name"                                = "cv_des_01"
        "sta_name"                                = "sta_glb_diag"
        "tags"                                    = {}
        "zone"                                    = "2"
        "encryption_at_host_enabled"              = true
        "disable_password_authentication"         = false
        "secure_boot_enabled"                     = false
        "vtpm_enabled"                            = false
        "vm_os_disk_name"                         = null
        "identity_type"                           = "SystemAssigned"
        "identity_ids"                            = []
    }
}

sl_vm_instance_type     = "Standard_D2s_v5"
storage_account_type_sl = "StandardSSD_LRS"
vhd_name                = "0.0.1"
vhd_image_name          = "SLImage1Aug25"
gallery_name            = "SLImages"
vhd_shortlocation       = "WE"
vhd_rg                  = "GLBPROD01-RG-F-MGMT"
###---------------------------------------Role Assignemnt------------------------------------
kv_role_definition_names       = ["Key Vault Purge Operator"]
role_definition_name_cv_vm     = "Contributor"
role_definition_name_cv_vm_sta = "Storage Blob Data Owner"

####--------------------------------------- Application Security Group --------------------------------
cv_asgs = {
 "cv_z1a_asgs" = {
    asg_name = "CV-Z1A"
    resource_group = "RG_mgmt"
    asg_tags       = {  
           "remark" = ""
        }
  },
  "cv_z1b_asgs" = {
    asg_name = "CV-Z1B"
    resource_group = "RG_mgmt"
    asg_tags       = {  
           "remark" = ""
        }
  },
  "cv_z1c_asgs" = {
    asg_name = "CV-Z1C"
    resource_group = "RG_mgmt"
    asg_tags       = {  
           "remark" = ""
        }
  },
  "cv_z3_asgs" = {
    asg_name = "CV-Z3"
    resource_group = "RG_mgmt"
    asg_tags       = {  
           "remark" = ""
        }
  }
}

### ------------------------------- Application Security Group - Network Interface Association ---------------------------
cv_asgs_nic_association = {
  "asg_nic_01" = {
    asg_name = "cv_z1a_asgs"
    nic_name = "cv_nic_01"
  },
  "asg_nic_02" = {
    asg_name = "cv_z1a_asgs"
    nic_name = "cv_nic_02"
  },
  "asg_nic_03" = {
    asg_name = "cv_z1b_asgs"
    nic_name = "cv_nic_03"
  },
  "asg_nic_04" = {
    asg_name = "cv_z1b_asgs"
    nic_name = "cv_nic_04"
  },
  "asg_nic_05" = {
    asg_name = "cv_z1c_asgs"
    nic_name = "cv_nic_05"
  },
  "asg_nic_06" = {
    asg_name = "cv_z1c_asgs"
    nic_name = "cv_nic_06"
  },
  "asg_nic_07" = {
    asg_name = "cv_z3_asgs"
    nic_name = "cv_nic_07"
  },
  "asg_nic_08" = {
    asg_name = "cv_z3_asgs"
    nic_name = "cv_nic_08"
  }
}

##--------------------------------------- Application Security Group - SL --------------------------------
sl_asgs = {
 "sl_z1c_asgs" = {
    asg_name = "SL-Z1C"
    resource_group = "RG_mgmt"
    asg_tags       = {  
           "remark" = ""
        }
 }
}

### ------------------------------- Application Security Group - Network Interface Association ---------------------------
sl_asgs_nic_association = {
  "asg_sl_nic_01" = {
    asg_name = "sl_z1c_asgs"
    nic_name = "sl_nic_01"
  },
  "asg_sl_nic_02" = {
    asg_name = "sl_z1c_asgs"
    nic_name = "sl_nic_02"
  }
}

swc_sl_nic_names     = []
inc_sl_nic_names     = []
sl_nic_rg_name       = "GLBPROD01-RG-C-9AAG029945"