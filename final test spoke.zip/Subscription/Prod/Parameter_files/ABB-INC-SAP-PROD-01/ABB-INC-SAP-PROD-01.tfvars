###------------------------------------------- Subscription ----------------------------------
subscription_name           = "SAP-PROD-01"
billing_account_name        = "5099306"
enrollment_account_name     = "264764"
management_group_id         = "PROD-MGMTGRP"
subscription_billing_scope  = "/providers/Microsoft.Billing/billingAccounts/5099306/enrollmentAccounts/264764"
workload                    = "Production"
tags_sub ={
    remark              = ""
    environment         = ""
    model               = "application"
    application         = ""
    costcenter          = "r220900"
    costcenterowner     = "tomasz.repinski1@pl.abb.com"
    country             = "global"
    owningbusinessarea  = "zc"
    owningdivision      = "zcgs"
    owningcompany       = "chgpl"
}
###------------------------------------------ Location ---------------------------------------
location        = "CentralIndia"
shortlocation   = "INC"
mgshortlocation = "INC"
###------------------------------------------- Tags------ --------------------------------------
   rg_tags = {
    itsmnr              = "WO1173"
    remark              = ""
    environment         = ""
    model               = "application"
    igar                = "9aag026594"
    application         = "cloud hosting service infrastructure"
    costcenter          = "52013300"
    costcenterowner     = "tomasz.repinski1@pl.abb.com"
    country             = "global"
    owningbusinessarea  = "zc"
    owningdivision      = "zcgs"
    owningcompany       = "chgpl"
}

cv_tags = {
    itsmnr                  = "WO1173"
    remark                  = ""
    environment             = ""
    model                   = "application"
    igar                    = "9aag029946"
    application             = "commvault"
    costcenter              = "52013004"
    costcenterowner         = "lars.helmersson@se.abb.com"
    country                 = "global"
    owningbusinessarea      = "zc"
    owningdivision          = "zcgs"
    owningcompany           = "chgpl"
}

ntw_watch_tags = {
    itsmnr    = "ritm5066418"
    remark = "BizTalk - required for whitlisting"
    environment = ""
    model = "application"
    igar = "9aag026594"
    application = "cloud hosting service infrastructure"
    costcenter = "52013300"
    costcenterowner = "tomasz.repinski1@pl.abb.com"
    country = "global"
    owningbusinessarea = "zc"
    owningdivision = "zcgs"
    owningcompany = "chgpl"
}
###-------------------------------------Resource Groups------------------------------------------
resource_groups = {
    "RG_ntw"          =   {
        "name" = "SAPPROD01-RG-F-NETWORK"
    },
    "RG_app" =   {
        "name" = "SAPPROD01-RG-F-APP-01"
    },
    "RG_mgmt" =   {
        "name" = "SAPPROD01-RG-F-MGMT"
    }
}

resource_groups_cv = {
    "RG_cv" =   {
        "name" = "SAPPROD01-RG-C-9AAG029946"
    }
}

rg_ntw_watch = {
    "ntw_watch" = {
        "name" = "NetworkWatcherRG"
    }
}

#---------------------------------------Network Watcher----------------------------------------
network_watchers = {
    "networkwatcher" = {
    "nwr_name"            = "NetworkWatcher"
    "resource_group"      = "ntw_watch"
}
}
###---------------------------------------------- Vnets -------------------------------------------
vnets = {
    "vnet_sap" =  {
        "vnet_name"           = "SAP-PROD-SAP-VNET01",
        "vnet_address_space"  = ["10.224.168.0/21"],
        "resource_group"      = "RG_ntw"
        "dns_servers"         = ["10.16.7.12", "10.17.106.6", "168.63.129.16", "10.16.114.10", "10.16.113.6"]
        "vnet_tags"           = {
            "remark" = ""
        }
    }
}
####--------------------------DDos Plan details in Hub-------------------------
ddos_protection_plan_enabled = true
ddos_shortlocation = "SWC"
ddos_name = "DDoS-01"
ddos_rg = "RG-F-NETWORK"
inc_hub_subscription_identifier = "HUB02"
swc_hub_subscription_identifier = "HUB01"
###-------------------------------------------- Subnets -------------------------------------------
subnets = {
    "sap_int01" = {
        "snet_name"          = "SAP-PROD-SAP-VNET01-INT01"
        "newbits"            = 3
        "netnum"             = 0
        "vnet_name"          = "vnet_sap"
        "resource_group"     = "RG_ntw"  
        "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"] 
    },
    "sap_idmz01" = {
        "snet_name"          = "SAP-PROD-SAP-VNET01-IDMZ01"
        "newbits"            = 6
        "netnum"             = 32
        "vnet_name"          = "vnet_sap"
        "resource_group"     = "RG_ntw"  
        "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"]
    },
    "sap_edmz01" = {
        "snet_name"          = "SAP-PROD-SAP-VNET01-EDMZ01"
        "newbits"            = 6
        "netnum"             = 48
        "vnet_name"          = "vnet_sap"
        "resource_group"     = "RG_ntw"  
        "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"]
    },
    "sap_edmz_pvtend01" = {
        "snet_name"          = "SAP-PROD-SAP-VNET01-EDMZ-PVTEND01"
        "newbits"            = 7
        "netnum"             = 127
        "vnet_name"          = "vnet_sap"
        "resource_group"     = "RG_ntw"  
        "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"]
    },
    "sap_cv01" = {
        "snet_name"          = "SAP-PROD-SAP-VNET01-CV01"
        "newbits"            = 7
        "netnum"             = 63
        "vnet_name"          = "vnet_sap"
        "resource_group"     = "RG_ntw"  
        "service_endpoints"  = ["Microsoft.KeyVault","Microsoft.Storage"]
    }
}
###--------------------------------------Route table---------------------------------------
route_table_names = {
    "sap_edmz01" = {
        "name"           = "SAP-PROD-SAP-VNET01-EDMZ01-UDR01"
        "resource_group" = "RG_ntw"
        "rt_tags"        = { 
            "remark"     = ""   
        }
    },
    "sap_idmz01" = {
        "name"           = "SAP-PROD-SAP-VNET01-IDMZ01-UDR01"
        "resource_group" = "RG_ntw"
        "rt_tags"        = {
            "remark"     = ""   
        }
    },
    "sap_int01" = {
        "name"           = "SAP-PROD-SAP-VNET01-INT01-UDR01"
        "resource_group" = "RG_ntw"
        "rt_tags"        = {
           "remark"      = ""   
        }
    },
    "sap_cv01" = {
        "name"           = "SAP-PROD-SAP-VNET01-CV01-UDR01"
        "resource_group" = "RG_ntw"
        "rt_tags"        = {
            "remark"     = ""
        }
    }
}

bgp_route_propagation_enabled = false

###-----------------------------------Route table - Subnet Associations---------------------------------------
RouteTableSubnetAssociations = {
    "sap_edmz01" = {
        "route_table_name"       = "sap_edmz01"
        "subnet_name"            = "sap_edmz01"
    },
    "sap_idmz01" = {
        "route_table_name"       = "sap_idmz01"
        "subnet_name"            = "sap_idmz01"
    },
    "sap_int01" = {
        "route_table_name"       = "sap_int01"
        "subnet_name"            = "sap_int01"
    },
    "sap_cv01" = {
        "route_table_name"       = "sap_cv01"
        "subnet_name"            = "sap_cv01"
    }
}
###--------------------------------------------Routes---------------------------------------
###--------------------------------------------Hub GLB FW and ZScaler details----------------------------------
glb-fw-lb-name = "backend-lb"
glb_fw_lb_rg = "RG-F-GLBFW"
zscaler-lb-name = "LLB-9AAG028759-01"
zscaler-rg = "RG-C-9AAG028759"
routes = {
"sap_int01_abbnw01" = {
        "name"                    = "RTB-ABBNW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "10.0.0.0/8"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_int01_abbnw02" = {
        "name"                    = "RTB-ABBNW-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "138.224.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_int01_abbnw03" = {
        "name"                    = "RTB-ABBNW-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "138.222.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
   "sap_int01_abbnw04" = {
        "name"                    = "RTB-ABBNW-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "138.226.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_int01_abbnw05" = {
        "name"                    = "RTB-ABBNW-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "172.16.0.0/12"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "sap_int01_abbnw06" = {
        "name"                    = "RTB-ABBNW-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "130.110.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_int01_abbnw07" = {
        "name"                    = "RTB-ABBNW-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "137.133.128.0/17"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_int01_abbnw08" = {
        "name"                    = "RTB-ABBNW-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "138.221.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_int01_abbnw09" = {
        "name"                    = "RTB-ABBNW-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "138.223.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "sap_int01_abbnw10" = {
        "name"                    = "RTB-ABBNW-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "138.227.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "sap_int01_abbnw11" = {
        "name"                    = "RTB-ABBNW-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "138.228.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "sap_int01_abbnw12" = {
        "name"                    = "RTB-ABBNW-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "192.125.60.0/22"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "sap_int01_abbnw13" = {
        "name"                    = "RTB-ABBNW-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "100.64.0.0/10"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_int01_abbnw14" = {
        "name"                    = "RTB-ABBNW-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "193.45.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
    "sap_int01_abbnw15" = {
        "name"                    = "RTB-ABBNW-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "193.71.72.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
  "sap_int01_abbnw16" = {
        "name"                    = "RTB-ABBNW-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "193.75.73.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_int01_abbnw17" = {
        "name"                    = "RTB-ABBNW-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "193.164.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_int01_abbnw18" = {
        "name"                    = "RTB-ABBNW-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "198.113.64.0/18"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_int01_abbnw19" = {
        "name"                    = "RTB-ABBNW-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "129.35.205.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_int01_abbnw20" = {
        "name"                    = "RTB-ABBNW-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "129.35.207.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "sap_int01_abbnw21" = {
        "name"                    = "RTB-ABBNW-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "80.75.192.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "sap_int01_abbnw22" = {
        "name"                    = "RTB-ABBNW-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "80.75.195.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_int01_abbnw23" = {
        "name"                    = "RTB-ABBNW-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "145.241.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_int01_abbnw24" = {
        "name"                    = "RTB-ABBNW-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "204.231.112.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_int01_abbnw25" = {
        "name"                    = "RTB-ABBNW-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "206.208.208.0/23"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_int01_abbnw26" = {
        "name"                    = "RTB-ABBNW-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "210.24.147.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_int01_abbnw27" = {
        "name"                    = "RTB-ABBNW-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "193.164.24.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_int01_abbnw28" = {
        "name"                    = "RTB-ABBNW-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "193.164.31.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_idmz01_abbnw01" = {
        "name"                    = "RTB-ABBNW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "10.0.0.0/8"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_idmz01_abbnw02" = {
        "name"                    = "RTB-ABBNW-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "138.224.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_idmz01_abbnw03" = {
        "name"                    = "RTB-ABBNW-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "138.222.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
   "sap_idmz01_abbnw04" = {
        "name"                    = "RTB-ABBNW-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "138.226.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_idmz01_abbnw05" = {
        "name"                    = "RTB-ABBNW-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "172.16.0.0/12"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "sap_idmz01_abbnw06" = {
        "name"                    = "RTB-ABBNW-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "130.110.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_idmz01_abbnw07" = {
        "name"                    = "RTB-ABBNW-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "137.133.128.0/17"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_idmz01_abbnw08" = {
        "name"                    = "RTB-ABBNW-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "138.221.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_idmz01_abbnw09" = {
        "name"                    = "RTB-ABBNW-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "138.223.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "sap_idmz01_abbnw10" = {
        "name"                    = "RTB-ABBNW-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "138.227.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "sap_idmz01_abbnw11" = {
        "name"                    = "RTB-ABBNW-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "138.228.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "sap_idmz01_abbnw12" = {
        "name"                    = "RTB-ABBNW-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "192.125.60.0/22"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "sap_idmz01_abbnw13" = {
        "name"                    = "RTB-ABBNW-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "100.64.0.0/10"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_idmz01_abbnw14" = {
        "name"                    = "RTB-ABBNW-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "193.45.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
    "sap_idmz01_abbnw15" = {
        "name"                    = "RTB-ABBNW-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "193.71.72.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
  "sap_idmz01_abbnw16" = {
        "name"                    = "RTB-ABBNW-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "193.75.73.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_idmz01_abbnw17" = {
        "name"                    = "RTB-ABBNW-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "193.164.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_idmz01_abbnw18" = {
        "name"                    = "RTB-ABBNW-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "198.113.64.0/18"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_idmz01_abbnw19" = {
        "name"                    = "RTB-ABBNW-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "129.35.205.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_idmz01_abbnw20" = {
        "name"                    = "RTB-ABBNW-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "129.35.207.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "sap_idmz01_abbnw21" = {
        "name"                    = "RTB-ABBNW-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "80.75.192.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "sap_idmz01_abbnw22" = {
        "name"                    = "RTB-ABBNW-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "80.75.195.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_idmz01_abbnw23" = {
        "name"                    = "RTB-ABBNW-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "145.241.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_idmz01_abbnw24" = {
        "name"                    = "RTB-ABBNW-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "204.231.112.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_idmz01_abbnw25" = {
        "name"                    = "RTB-ABBNW-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "206.208.208.0/23"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_idmz01_abbnw26" = {
        "name"                    = "RTB-ABBNW-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "210.24.147.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_idmz01_abbnw27" = {
        "name"                    = "RTB-ABBNW-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "193.164.24.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_idmz01_abbnw28" = {
        "name"                    = "RTB-ABBNW-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "193.164.31.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_cv01_abbnw01" = {
        "name"                    = "RTB-ABBNW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "10.0.0.0/8"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_cv01_abbnw02" = {
        "name"                    = "RTB-ABBNW-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "138.224.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_cv01_abbnw03" = {
        "name"                    = "RTB-ABBNW-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "138.222.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
   "sap_cv01_abbnw04" = {
        "name"                    = "RTB-ABBNW-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "138.226.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_cv01_abbnw05" = {
        "name"                    = "RTB-ABBNW-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "172.16.0.0/12"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "sap_cv01_abbnw06" = {
        "name"                    = "RTB-ABBNW-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "130.110.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_cv01_abbnw07" = {
        "name"                    = "RTB-ABBNW-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "137.133.128.0/17"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_cv01_abbnw08" = {
        "name"                    = "RTB-ABBNW-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "138.221.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_cv01_abbnw09" = {
        "name"                    = "RTB-ABBNW-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "138.223.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "sap_cv01_abbnw10" = {
        "name"                    = "RTB-ABBNW-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "138.227.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "sap_cv01_abbnw11" = {
        "name"                    = "RTB-ABBNW-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "138.228.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "sap_cv01_abbnw12" = {
        "name"                    = "RTB-ABBNW-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "192.125.60.0/22"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "sap_cv01_abbnw13" = {
        "name"                    = "RTB-ABBNW-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "100.64.0.0/10"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_cv01_abbnw14" = {
        "name"                    = "RTB-ABBNW-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "193.45.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
    "sap_cv01_abbnw15" = {
        "name"                    = "RTB-ABBNW-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "193.71.72.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
  "sap_cv01_abbnw16" = {
        "name"                    = "RTB-ABBNW-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "193.75.73.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_cv01_abbnw17" = {
        "name"                    = "RTB-ABBNW-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "193.164.16.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_cv01_abbnw18" = {
        "name"                    = "RTB-ABBNW-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "198.113.64.0/18"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_cv01_abbnw19" = {
        "name"                    = "RTB-ABBNW-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "129.35.205.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_cv01_abbnw20" = {
        "name"                    = "RTB-ABBNW-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "129.35.207.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "sap_cv01_abbnw21" = {
        "name"                    = "RTB-ABBNW-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "80.75.192.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
 "sap_cv01_abbnw22" = {
        "name"                    = "RTB-ABBNW-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "80.75.195.0/26"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_cv01_abbnw23" = {
        "name"                    = "RTB-ABBNW-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "145.241.0.0/16"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_cv01_abbnw24" = {
        "name"                    = "RTB-ABBNW-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "204.231.112.0/20"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_cv01_abbnw25" = {
        "name"                    = "RTB-ABBNW-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "206.208.208.0/23"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_cv01_abbnw26" = {
        "name"                    = "RTB-ABBNW-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "210.24.147.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_cv01_abbnw27" = {
        "name"                    = "RTB-ABBNW-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "193.164.24.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_cv01_abbnw28" = {
        "name"                    = "RTB-ABBNW-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "193.164.31.0/24"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "GLB-FW-FrontendIP"
    },
"sap_edmz01_akamai01" = {
        "name"                    = "RTB-AKAMAI-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "104.64.0.0/10"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai02" = {
        "name"                    = "RTB-AKAMAI-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "118.214.0.0/16"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai03" = {
        "name"                    = "RTB-AKAMAI-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "124.40.41.200/29"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai04" = {
        "name"                    = "RTB-AKAMAI-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "125.252.224.36/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai05" = {
        "name"                    = "RTB-AKAMAI-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "125.56.219.52/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai06" = {
        "name"                    = "RTB-AKAMAI-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "173.205.7.116/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai07" = {
        "name"                    = "RTB-AKAMAI-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "173.222.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai08" = {
        "name"                    = "RTB-AKAMAI-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "184.24.0.0/13"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai09" = {
        "name"                    = "RTB-AKAMAI-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "184.50.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai10" = {
        "name"                    = "RTB-AKAMAI-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "184.84.0.0/14"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai11" = {
        "name"                    = "RTB-AKAMAI-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "192.204.11.4/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai12" = {
        "name"                    = "RTB-AKAMAI-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "193.108.155.118/32"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai13" = {
        "name"                    = "RTB-AKAMAI-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "2.16.0.0/13"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai14" = {
        "name"                    = "RTB-AKAMAI-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "201.33.187.68/30"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai15" = {
        "name"                    = "RTB-AKAMAI-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "203.69.138.120/30"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai16" = {
        "name"                    = "RTB-AKAMAI-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "204.1.136.238/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai17" = {
        "name"                    = "RTB-AKAMAI-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "204.2.159.68/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai18" = {
        "name"                    = "RTB-AKAMAI-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "204.2.160.182/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai19" = {
        "name"                    = "RTB-AKAMAI-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "204.201.160.246/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai20" = {
        "name"                    = "RTB-AKAMAI-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "205.185.205.132/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai21" = {
        "name"                    = "RTB-AKAMAI-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "207.126.104.118/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai22" = {
        "name"                    = "RTB-AKAMAI-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "209.107.208.188/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai23" = {
        "name"                    = "RTB-AKAMAI-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "209.249.98.36/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai24" = {
        "name"                    = "RTB-AKAMAI-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "220.90.198.178/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai25" = {
        "name"                    = "RTB-AKAMAI-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.0.0.0/12"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai26" = {
        "name"                    = "RTB-AKAMAI-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.192.0.0/11"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai27" = {
        "name"                    = "RTB-AKAMAI-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.32.0.0/11"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai28" = {
        "name"                    = "RTB-AKAMAI-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.64.0.0/14"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai29" = {
        "name"                    = "RTB-AKAMAI-29"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.72.0.0/13"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai30" = {
        "name"                    = "RTB-AKAMAI-30"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "60.254.173.30/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai31" = {
        "name"                    = "RTB-AKAMAI-31"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "61.111.58.82/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai32" = {
        "name"                    = "RTB-AKAMAI-32"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "63.217.211.110/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai33" = {
        "name"                    = "RTB-AKAMAI-33"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "63.217.211.116/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai34" = {
        "name"                    = "RTB-AKAMAI-34"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "63.235.21.192/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai35" = {
        "name"                    = "RTB-AKAMAI-35"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "64.145.89.236/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai36" = {
        "name"                    = "RTB-AKAMAI-36"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "65.124.174.194/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai37" = {
        "name"                    = "RTB-AKAMAI-37"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "66.198.26.68/30"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai38" = {
        "name"                    = "RTB-AKAMAI-38"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "66.198.8.167/32"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai39" = {
        "name"                    = "RTB-AKAMAI-39"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "66.198.8.168/32"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai40" = {
        "name"                    = "RTB-AKAMAI-40"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "67.220.143.216/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai41" = {
        "name"                    = "RTB-AKAMAI-41"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "69.192.0.0/16"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai42" = {
        "name"                    = "RTB-AKAMAI-42"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "69.31.121.20/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai43" = {
        "name"                    = "RTB-AKAMAI-43"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "69.31.138.100/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai44" = {
        "name"                    = "RTB-AKAMAI-44"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "72.246.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai45" = {
        "name"                    = "RTB-AKAMAI-45"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "77.67.85.52/31"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai46" = {
        "name"                    = "RTB-AKAMAI-46"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "8.18.43.199/32"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai47" = {
        "name"                    = "RTB-AKAMAI-47"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "8.18.43.240/32"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai48" = {
        "name"                    = "RTB-AKAMAI-48"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "88.221.0.0/16"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai49" = {
        "name"                    = "RTB-AKAMAI-49"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "92.122.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai50" = {
        "name"                    = "RTB-AKAMAI-50"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "95.100.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai51" = {
        "name"                    = "RTB-AKAMAI-51"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "96.16.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_akamai52" = {
        "name"                    = "RTB-AKAMAI-52"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "96.6.0.0/15"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },

"sap_edmz01_EDMZ01" = {
        "name"                    = "RTB-EDMZ-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "184.31.1.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ02" = {
        "name"                    = "RTB-EDMZ-02"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "184.50.85.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ03" = {
        "name"                    = "RTB-EDMZ-03"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "2.17.112.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ04" = {
        "name"                    = "RTB-EDMZ-04"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "2.21.22.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ05" = {
        "name"                    = "RTB-EDMZ-05"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "2.21.33.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ06" = {
        "name"                    = "RTB-EDMZ-06"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "2.22.121.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ07" = {
        "name"                    = "RTB-EDMZ-07"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "2.22.30.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ08" = {
        "name"                    = "RTB-EDMZ-08"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "2.22.54.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ09" = {
        "name"                    = "RTB-EDMZ-09"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.10.249.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ10" = {
        "name"                    = "RTB-EDMZ-10"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.15.178.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ11" = {
        "name"                    = "RTB-EDMZ-11"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.198.5.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ12" = {
        "name"                    = "RTB-EDMZ-12"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.200.142.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ13" = {
        "name"                    = "RTB-EDMZ-13"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.203.249.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ14" = {
        "name"                    = "RTB-EDMZ-14"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.3.88.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ15" = {
        "name"                    = "RTB-EDMZ-15"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.35.110.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ16" = {
        "name"                    = "RTB-EDMZ-16"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.35.111.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ17" = {
        "name"                    = "RTB-EDMZ-17"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.44.4.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ18" = {
        "name"                    = "RTB-EDMZ-18"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.48.94.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ19" = {
        "name"                    = "RTB-EDMZ-19"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.55.36.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ20" = {
        "name"                    = "RTB-EDMZ-20"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.56.109.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ21" = {
        "name"                    = "RTB-EDMZ-21"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.61.244.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ22" = {
        "name"                    = "RTB-EDMZ-22"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "72.246.97.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ23" = {
        "name"                    = "RTB-EDMZ-23"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "80.67.72.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ24" = {
        "name"                    = "RTB-EDMZ-24"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "84.53.138.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ25" = {
        "name"                    = "RTB-EDMZ-25"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "92.122.193.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ26" = {
        "name"                    = "RTB-EDMZ-26"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "92.122.215.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ27" = {
        "name"                    = "RTB-EDMZ-27"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "92.122.54.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ28" = {
        "name"                    = "RTB-EDMZ-28"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "92.123.107.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ29" = {
        "name"                    = "RTB-EDMZ-29"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "92.123.78.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMsap0" = {
        "name"                    = "RTB-EDMZ-30"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "95.100.169.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMsap1" = {
        "name"                    = "RTB-EDMZ-31"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "95.100.97.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMsap2" = {
        "name"                    = "RTB-EDMZ-32"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "95.101.143.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMsap3" = {
        "name"                    = "RTB-EDMZ-33"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "95.101.230.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMsap4" = {
        "name"                    = "RTB-EDMZ-34"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "96.17.180.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMsap5" = {
        "name"                    = "RTB-EDMZ-35"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "104.103.71.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMsap6" = {
        "name"                    = "RTB-EDMZ-36"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "104.104.52.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMsap7" = {
        "name"                    = "RTB-EDMZ-37"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "104.107.216.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMsap8" = {
        "name"                    = "RTB-EDMZ-38"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "104.107.217.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMsap9" = {
        "name"                    = "RTB-EDMZ-39"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "104.120.139.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ40" = {
        "name"                    = "RTB-EDMZ-40"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "104.124.56.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ41" = {
        "name"                    = "RTB-EDMZ-41"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "104.70.235.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ42" = {
        "name"                    = "RTB-EDMZ-42"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "173.222.148.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ43" = {
        "name"                    = "RTB-EDMZ-43"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "184.28.199.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ44" = {
        "name"                    = "RTB-EDMZ-44"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "184.28.229.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ45" = {
        "name"                    = "RTB-EDMZ-45"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "104.109.250.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ46" = {
        "name"                    = "RTB-EDMZ-46"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "184.28.194.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ47" = {
        "name"                    = "RTB-EDMZ-47"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "184.50.112.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ48" = {
        "name"                    = "RTB-EDMZ-48"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.10.252.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ49" = {
        "name"                    = "RTB-EDMZ-49"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.192.164.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ150" = {
        "name"                    = "RTB-EDMZ-50"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.195.73.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ51" = {
        "name"                    = "RTB-EDMZ-51"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.206.170.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ52" = {
        "name"                    = "RTB-EDMZ-52"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.212.108.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ53" = {
        "name"                    = "RTB-EDMZ-53"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.217.99.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ54" = {
        "name"                    = "RTB-EDMZ-54"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.55.170.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ55" = {
        "name"                    = "RTB-EDMZ-55"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.64.122.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ56" = {
        "name"                    = "RTB-EDMZ-56"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.67.40.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ57" = {
        "name"                    = "RTB-EDMZ-57"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "23.72.253.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ58" = {
        "name"                    = "RTB-EDMZ-58"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "88.221.24.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ59" = {
        "name"                    = "RTB-EDMZ-59"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "88.221.25.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ60" = {
        "name"                    = "RTB-EDMZ-60"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "92.123.122.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_edmz01_EDMZ61" = {
        "name"                    = "RTB-EDMZ-61"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_edmz01"
        "route_address_prefix"    = "95.100.193.0/24"
        "next_hop_type"           = "Internet"
        "next_hop_in_ip_address"  = ""
    },
"sap_int01_intfw01" = {
        "name"                    = "RTB-INTFW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_int01"
        "route_address_prefix"    = "0.0.0.0/0"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "Zscaler-FrontendIP"
    },
"sap_idmz01_intfw01" = {
        "name"                    = "RTB-INTFW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_idmz01"
        "route_address_prefix"    = "0.0.0.0/0"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "Zscaler-FrontendIP"
    },
"sap_cv01_intfw01" = {
        "name"                    = "RTB-INTFW-01"
        "resource_group"          = "RG_ntw"
        "route_table_name"        = "sap_cv01"
        "route_address_prefix"    = "0.0.0.0/0"
        "next_hop_type"           = "VirtualAppliance"
        "next_hop_in_ip_address"  = "Zscaler-FrontendIP"
    }
}

#------------------------------------------------- NSGs ---------------------------------------
nsgs = {
    "sap_int01" =   {
        "nsg_name"           = "SAP-PROD-SAP-VNET01-INT01"
        "resource_group"     = "RG_ntw"
        "nsg_tags"           = { 
           "remark"          = ""
        }
    },
    "sap_idmz01" =   {
        "nsg_name"           = "SAP-PROD-SAP-VNET01-IDMZ01"
        "resource_group"     = "RG_ntw"
        "nsg_tags"           = {
            "remark"         = ""
        }
    },
    "sap_edmz01" =   {
        "nsg_name"           = "SAP-PROD-SAP-VNET01-EDMZ01"
        "resource_group"     = "RG_ntw"
        "nsg_tags"           = {
            "remark"         = ""
        }
    },
    "sap_edmz_pvtend01" =   {
        "nsg_name"           = "SAP-PROD-SAP-VNET01-EDMZ-PVTEND01"
        "resource_group"     = "RG_ntw"
        "nsg_tags"           = {
           "remark"          = ""
        }
    },
    "sap_cv01" =   {
        "nsg_name"           = "SAP-PROD-SAP-VNET01-CV01"
        "resource_group"     = "RG_ntw"
        "nsg_tags"           = {
           "remark" = ""
        }
    }
}
#-----------------------------------NSG - Subnet Associations---------------------------------------

nsgAssociationSubnet = {
    "sap_edmz01" = {
        "nsg_name"       = "sap_edmz01"
        "subnet_name"    = "sap_edmz01"
    },
    "sap_idmz01" = {
        "nsg_name"       = "sap_idmz01"
        "subnet_name"    = "sap_idmz01"
    },
    "sap_int01" = {
        "nsg_name"       = "sap_int01"
        "subnet_name"    = "sap_int01"
    },
    "sap_cv01" = {
        "nsg_name"       = "sap_cv01"
        "subnet_name"    = "sap_cv01"
    },
    "sap_edmz_pvtend01" = {
        "nsg_name"       = "sap_edmz_pvtend01"
        "subnet_name"    = "sap_edmz_pvtend01"
    }
}     
#--------------------------------------------NSG Rules-------------------------------------------
sl_asg_name     = "SL"
sl_asg_rg_name  = "GLBPROD01-RG-C-9AAG029945"
nsg_rules = {
"sap_int01_01" = {
        "nsr_name" = "In-Allow-SAPCommvault01"
        "nsg" = "sap_int01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["8400","8401","8403","445","135","443","1434","1433","8111","8112","902","111","2049","9400","9401","5000","3306","1521","10000","22","8090"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_sap"],
        "nsr_priority" = "3202"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["cv_sap_asgs"]
    },
    "sap_int01_02" = {
        "nsr_name" = "In-Allow-ScienceLogic"
        "nsg" = "sap_int01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["22","5985","5986"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["sl_nics"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_sap"],
        "nsr_priority" = "3204"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_int01_03" = {
        "nsr_name" = "In-Allow-Azure-GLBSAP-VNET01-INT01"
        "nsg" = "sap_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["sap_int01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["sap_int01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_int01_04" = {
        "nsr_name" = "In-Deny-Azure-GLBSAP-VNET-01"
        "nsg" = "sap_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_sap"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_sap"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_int01_05" = {
        "nsr_name" = "In-Allow-ABBnetwork-01"
        "nsg" = "sap_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "VirtualNetwork",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_int01_06" = {
        "nsr_name" = "In-Allow-LBHealthProbe"
        "nsg" = "sap_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_sap"],
        "nsr_priority" = "3999"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_int01_07" = {
        "nsr_name" = "DenyAllInbound"
        "nsg" = "sap_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_int01_08" = {
        "nsr_name" = "Out-Allow-SAPCommvault01"
        "nsg" = "sap_int01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["8400","8403","8401","445","135","443","1434 ","433","8111","8112","902","111","2049","9400","9401","5000","3306","1521","10000","22","8090","8091","8097","81","53"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_sap"],
        "nsr_priority" = "3202"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["cv_sap_asgs"]
    },
    "sap_int01_09" = {
        "nsr_name" = "Out-Allow-Azure-GLBSAP-VNET01-INT01"
        "nsg" = "sap_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["sap_int01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["sap_int01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_int01_10" = {
        "nsr_name" = "Out-Deny-Azure-GLBSAP-VNET-01"
        "nsg" = "sap_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_sap"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_sap"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_int01_11" = {
        "nsr_name" = "Out-Allow-ABBnetwork-01"
        "nsg" = "sap_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_int01_12" = {
        "nsr_name" = "Out-Allow-LBHealthProbe"
        "nsg" = "sap_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3999"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_int01_13" = {
        "nsr_name" = "DenyAllOutBound"
        "nsg" = "sap_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    }, 
    "sap_idmz01_01" = {
        "nsr_name" = "In-Allow-SAPCommvault01"
        "nsg" = "sap_idmz01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["8400","8401","8403","445","135","443","1434","1433","8111","8112","902","111","2049","9400","9401","5000","3306","1521","10000","22","8090"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["sap_idmz01"],
        "nsr_priority" = "3202"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["cv_sap_asgs"]
    },
    "sap_idmz01_02" = {
        "nsr_name" = "In-Allow-ScienceLogic"
        "nsg" = "sap_idmz01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["22","5985","5986"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["sl_nics"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_sap"],
        "nsr_priority" = "3204"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_idmz01_03" = {
        "nsr_name" = "In-Allow-Azure-GLBSAP-VNET01-IDMZ01"
        "nsg" = "sap_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["sap_idmz01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["sap_idmz01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_idmz01_04" = {
        "nsr_name" = "In-Deny-Azure-GLBSAP-VNET-01"
        "nsg" = "sap_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_sap"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_sap"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_idmz01_05" = {
        "nsr_name" = "In-Allow-ABBnetwork-01"
        "nsg" = "sap_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "VirtualNetwork",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_idmz01_06" = {
        "nsr_name" = "In-Allow-LBHealthProbe"
        "nsg" = "sap_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_sap"],
        "nsr_priority" = "3999"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_idmz01_07" = {
        "nsr_name" = "DenyAllInbound"
        "nsg" = "sap_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
       "sap_idmz01_08" = {
        "nsr_name" = "Out-Allow-Azure-GLBSAP-VNET01-IDMZ01"
        "nsg" = "sap_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["sap_idmz01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["sap_idmz01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_idmz01_9" = {
        "nsr_name" = "Out-Deny-Azure-GLBSAP-VNET-01"
        "nsg" = "sap_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_sap"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_sap"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_idmz01_10" = {
        "nsr_name" = "Out-Allow-ABBnetwork-01"
        "nsg" = "sap_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_idmz01_11" = {
        "nsr_name" = "Out-Allow-LBHealthProbe"
        "nsg" = "sap_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3999"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_idmz01_12" = {
        "nsr_name" = "DenyAllOutBound"
        "nsg" = "sap_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
	"sap_edmz01_01" = {
        "nsr_name" = "In-Allow-SAPCommvault01"
        "nsg" = "sap_edmz01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["8400","8401","8403","445","135","443","1434","1433","8111","8112","902","111","2049","9400","9401","5000","3306","1521","10000","22","8090"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["sap_edmz01"],
        "nsr_priority" = "3202"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = ["cv_sap_asgs"]
    },
    "sap_edmz01_02" = {
        "nsr_name" = "In-Allow-ScienceLogic"
        "nsg" = "sap_edmz01"
        "nsr_protocol" = "Tcp"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = null,
        "nsr_destination_port_ranges" = ["22","5985","5986"],
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["sl_nics"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_sap"],
        "nsr_priority" = "3204"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_edmz01_03" = {
        "nsr_name" = "In-Allow-Azure-GLBSAP-VNET01-EDMZ01"
        "nsg" = "sap_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["sap_edmz01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["sap_edmz01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_edmz01_04" = {
        "nsr_name" = "In-Deny-Azure-GLBSAP-VNET-01"
        "nsg" = "sap_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_sap"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_sap"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_edmz01_05" = {
        "nsr_name" = "In-Allow-ABBnetwork-01"
        "nsg" = "sap_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "VirtualNetwork",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_edmz01_06" = {
        "nsr_name" = "In-Allow-LBHealthProbe"
        "nsg" = "sap_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_sap"],
        "nsr_priority" = "3999"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_edmz01_07" = {
        "nsr_name" = "DenyAllInbound"
        "nsg" = "sap_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
       "sap_edmz01_08" = {
        "nsr_name" = "Out-Allow-Azure-GLBSAP-VNET01-EDMZ01"
        "nsg" = "sap_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["sap_edmz01"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["sap_edmz01"],
        "nsr_priority" = "3990"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_edmz01_9" = {
        "nsr_name" = "Out-Deny-Azure-GLBSAP-VNET-01"
        "nsg" = "sap_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_sap"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["vnet_sap"],
        "nsr_priority" = "3997"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_edmz01_10" = {
        "nsr_name" = "Out-Allow-ABBnetwork-01"
        "nsg" = "sap_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3998"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_edmz01_11" = {
        "nsr_name" = "Out-Allow-LBHealthProbe"
        "nsg" = "sap_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "AzureLoadBalancer",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "VirtualNetwork",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3999"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_edmz01_12" = {
        "nsr_name" = "DenyAllOutBound"
        "nsg" = "sap_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = "*",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "4096"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },

    "sap_edmz_pvtend01_01" = {
        "nsr_name" = "In-Allow-ASR-PREP-01"
        "nsg" = "sap_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["vnet_sap"],
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["sap_edmz_pvtend01"],
        "nsr_priority" = "3206"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_edmz_pvtend01_02" = {
        "nsr_name" = "Out-Allow-ASR-PREP-01"
        "nsg" = "sap_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["sap_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "Storage",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3206"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_edmz_pvtend01_03" = {
        "nsr_name" = "Out-Allow-ASR-PREP-02"
        "nsg" = "sap_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["sap_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "AzureActiveDirectory",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3207"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_edmz_pvtend01_04" = {
        "nsr_name" = "Out-Allow-ASR-PREP-03"
        "nsg" = "sap_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["sap_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "EventHub",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3208"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_edmz_pvtend01_05" = {
        "nsr_name" = "Out-Allow-ASR-PREP-04"
        "nsg" = "sap_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["sap_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "AzureSiteRecovery",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3209"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_edmz_pvtend01_06" = {
        "nsr_name" = "Out-Allow-ASR-PREP-05"
        "nsg" = "sap_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["sap_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "AzureKeyVault",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3210"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_edmz_pvtend01_07" = {
        "nsr_name" = "Out-Allow-ASR-PREP-06"
        "nsg" = "sap_edmz_pvtend01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = "*",
        "nsr_source_port_ranges" = null,
        "nsr_destination_port_range" = "433",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = null,
        "nsr_source_address_prefixes" = ["sap_edmz_pvtend01"],
        "nsr_destination_address_prefix" = "GuestAndHybridManagement",
        "nsr_destination_address_prefixes" = null,
        "nsr_priority" = "3211"
        "nsr_direction" = "Outbound"
        "nsr_access" = "Allow"
        "resource_group" = "RG_ntw"
        "nsr_source_application_security_group_ids" = null
    },
    "sap_edmz01_13" = {
        "nsr_name" = "In-Deny-WIZ-Ports"
        "nsg" = "sap_edmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = null,
        "nsr_source_port_ranges" = ["5984","7473","7474","110","995","8080","28015","29015","8087","8098","7574","8983","1024","7000","7001","7199","9042", "9142","9160","137","138","445","139","445","53","9200","9300","2379","20","21","80","443","5601","11211","27017-27020","4333","1433","1434","3306","1521", "1830","2483","2484","5432","3389","6379","135","445","25","22","23","5500","5800","5900"]
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["sap_edmz01"],
        "nsr_priority" = "3800"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
	    "nsr_source_application_security_group_ids" = null
    },
    "sap_idmz01_13" = {
        "nsr_name" = "In-Deny-WIZ-Ports"
        "nsg" = "sap_idmz01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = null,
        "nsr_source_port_ranges" = ["5984","7473","7474","110","995","8080","28015","29015","8087","8098","7574","8983","1024","7000","7001","7199","9042", "9142","9160","137","138","445","139","445","53","9200","9300","2379","20","21","80","443","5601","11211","27017-27020","4333","1433","1434","3306","1521", "1830","2483","2484","5432","3389","6379","135","445","25","22","23","5500","5800","5900"]
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["sap_idmz01"],
        "nsr_priority" = "3800"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
	    "nsr_source_application_security_group_ids" = null
    },
    "sap_int01_14" = {
        "nsr_name" = "In-Deny-WIZ-Ports"
        "nsg" = "sap_int01"
        "nsr_protocol" = "*"
        "nsr_source_port_range" = null,
        "nsr_source_port_ranges" = ["5984","7473","7474","110","995","8080","28015","29015","8087","8098","7574","8983","1024","7000","7001","7199","9042", "9142","9160","137","138","445","139","445","53","9200","9300","2379","20","21","80","443","5601","11211","27017-27020","4333","1433","1434","3306","1521", "1830","2483","2484","5432","3389","6379","135","445","25","22","23","5500","5800","5900"]
        "nsr_destination_port_range" = "*",
        "nsr_destination_port_ranges" = null,
        "nsr_source_address_prefix" = "*",
        "nsr_source_address_prefixes" = null,
        "nsr_destination_address_prefix" = null,
        "nsr_destination_address_prefixes" = ["sap_int01"],
        "nsr_priority" = "3800"
        "nsr_direction" = "Inbound"
        "nsr_access" = "Deny"
        "resource_group" = "RG_ntw"
	    "nsr_source_application_security_group_ids" = null
    }
}

#---------------------------------Azure Virtual Network Manager---------------------------
avnm_shortlocation = "SWC"
avnm_subscription_name = "HUB-01"
ntw_group_name = "ALL-VNETs"
ntw_manager_name = "AVNM01"
static_members = {
    "static_member_01" = {
        avnm_static_member_name = "SAP-PROD-Vnet"
        vnet_name = "vnet_sap"
    }
}

avnm_rules = {
    "avnm_rule_01" = {
        avnm_rule_name = "RTB-SAPPROD-VNET-01"
        vnet_name = "vnet_sap"
        type = "AddressPrefix"
        nextHopType = "VirtualAppliance"
        lb_name = "glb_fw"
    }
}

avnm_rule_collection_name = "VNET01-GW01-UDR01-RC01"
avnm_routing_name = "VNET01-GW01-UDR01"
glb_fw = {
    "glb_fw" = {
        glb-fw-lb-name = "backend-lb"
        glb_fw_lb_rg = "RG-F-GLBFW"
    }
}

###----------------------------------------- Vnet Flow logs ----------------------------------------
sta_name          = "glbprdstalog02"
sta_rg            = "RG-F-MGMT"
law_name          = "LA-01"
law_rg            = "RG-F-MGMT"
enabled               = true
flow_log_version      = 2
retention_days        = 31
traffic_analytics_enabled   = true
interval_in_minutes   = 10

##------------------------------------ Key Vault Creation --------------------------
keyvault = {
    "kv_sap"    = {
        key_vault_name ="sapprd-kv-03"
        resource_group_name ="RG_app"
        subnet_name         = ["sap_int01","sap_idmz01","sap_edmz01","sap_edmz_pvtend01","sap_cv01"]
        tags                ={}
        dlog_name           = "kv-cv01"
    }
}
kv_sku_name                     = "standard"
kv_purge_protection_enabled     = true
kv_soft_delete_retention_days   = 30
kv_enable_rbac_authorization    = true
kv_enabled_for_disk_encryption  = true
kv_enabled_for_template_deployment  = true
kv_enabled_for_deployment           = true
kv_public_network_access_enabled    = true
kv_bypass                     = "AzureServices"
kv_default_action             = "Deny"
kv_ip_rules                   = []

#self hosted vm network details
iac_vnet_name = "IAC-VNET01"
iac_vnet_rg   = "IAC01-RG-F-NETWORK"
iac_subnet_name ="IAC-VNET01-INT01"
iac_shortlocation = "SWC"

# DNS entry details
dns_shortlocation       = "WE"
private_dns_zone_rgName = "HUB01-RG-F-DNS"
sta_dns_zone_name       = "privatelink.blob.core.windows.net"
kv_dns_zone_name        = "privatelink.vaultcore.azure.net"
###-----------------------------------Private Endpoint-----------------------------------------------
pvt_endpoints = {
    "pe_kv" = {
        "pe_name"                               = "SAPPRD-PREP-KV-001"
        "resource_group"                        = "RG_app"
        "subnet_name"                           = "sap_edmz_pvtend01"
        "key_vault_name"                        = "kv_sap"
        "is_manual_connection"                  = false
        "subresource_names"                     = ["vault"]
        "pe_tags"                               = {
            "remark"        = ""
        }
    }
}

# ####-------------------Key Vault Key ----------------------------
keyvault_key       ={
    "kv_key_disk"   ={
        kv_key_name = "diskencryptkey"
        kv_name     ="kv_sap"
        kvk_tags    ={}
    },
    "kv_key_storage"   ={
        kv_key_name = "storageencryptkey"
        kv_name     = "kv_sap"
        kvk_tags    ={}
    }
}

 kv_key_type        = "RSA"
 kv_key_opts        = ["decrypt", "encrypt", "sign", "unwrapKey", "verify", "wrapKey"]
 kv_key_size        = "2048"
 expiration_date = null

###---------------------------------------Role Assignemnt------------------------------------
role_assign_kv = {
    role_kv = {
        "role_definition_name" = "Key Vault Administrator"
    }
}

role_assign_sta = {
    role_sta = {
        "role_definition_name" = "Key Vault Crypto Service Encryption User"
        "kv_name"              = "kv_sap"
        "sta_name"             = "sta_sap"
    }
}

###-----------------------------------------Diagnostic settings ----------------------
enable_logs         = true
enabled_metric      = false
workspace_rs_id     = ""

#------------------------------------Storage Accounts-------------------------------
storage_accounts        = {
    "sta_sap"  = {
       "sta_name"                         = "sapprdstablbcv01"
       "resource_group"                   = "RG_cv"
       "tags"  = {   
           "remark" = ""
        }
    }
}

account_tier                      = "Standard"
access_tier                       = "Cool"
account_replication_type          = "LRS"
cross_tenant_replication_enabled  = false
is_hns_enabled                    = false
delete_retention_days             = 7
container_delete_retention_days   = 0
allow_blob_public_access          = false
public_network_access_enabled     = true
infrastructure_encryption_enabled = true
shared_access_key_enabled         = true
versioning_enabled                = false
large_file_share_enabled          = true
min_tls_version                   = "TLS1_2"

###-----------------------------------Private Endpoint-----------------------------------------------
pvt_endpoints_sta = {
    "pe_sta" = {
        "pe_name"                         = "SAPPROD-PREP-CVSTA-001"
        "resource_group"                  = "RG_cv"
        "subnet_name"                     = "sap_edmz_pvtend01"
        "sta_name"                        = "sta_sap"
        "is_manual_connection"            = false
        "subresource_names"               = ["blob"]
        "pe_tags"                         = {
            "remark"        = ""
        }
    }
}

sta_ip_rules    = {
    "sta_rules" = {
        "storage_account_name"      = "sta_sap"
        "default_action"            = "Deny"
        "ip_rules"                  = []
        "subnet_name"               = ["sap_int01","sap_idmz01","sap_edmz01","sap_edmz_pvtend01","sap_cv01"]
        "bypass"                    = ["AzureServices"]
    }
}

#------------------------------------- Lifecycle Management of Storage Account-----------------------
 management_policies = {
    "sta_management_policy" = {
        rule_name = "sapprdstablbcv01"
        storage_account_name = "sta_sap"
    }
}

rule_enabled = true
blob_types   = ["blockBlob"]
delete_after_days_since_modification_greater_than = 90
delete_after_days_since_creation_greater_than = 90

#---------------------------------- Customer Managed Key - Storage Account -----------------
cmk_sta = {
    "cmk_sta" = {
        "sta_name" = "sta_sap"
        "kv_name"  = "kv_sap"
        "key_name" = "storageencryptkey"
    }
}

##------------------------------------- Commvault Configuration --------------------------------------------
###------------------------------------Diagnostic Storage Accounts-------------------------------
storage_accounts_diag        = {
    "sta_sap_diag"  = {
       "sta_name"                         = "sapprddiags1"
       "resource_group"                   = "RG_mgmt"
       "tags"  = {   
           "remark" = ""
        }
    }
}

delete_retention_days_01             = 0
access_tier_diag                     = "Hot"
###-----------------------------------Diagnostic Private Endpoint-----------------------------------------------
pvt_endpoints_sta_diag = {
    "pe_sta_diag" = {
        "pe_name"                         = "SAP-PROD-PREP-DIAGSTA-001"
        "resource_group"                  = "RG_mgmt"
        "subnet_name"                     = "sap_edmz_pvtend01"
        "sta_name"                        = "sta_sap_diag"
        "is_manual_connection"            = false
        "subresource_names"               = ["blob"]
        "pe_tags"                         = {
            "remark"        = ""
        }
    }

}

sta_ip_rules_diag   = {
    "sta_rules_diag" = {
        "storage_account_name"      = "sta_sap_diag"
        "default_action"            = "Deny"
        "ip_rules"                  = ["4.187.107.68", "20.192.47.134", "20.192.47.135", "20.192.152.150", "20.192.152.151", "20.192.153.104", "20.207.175.96", "52.172.82.199", "98.70.20.180"]
        "subnet_name"               = ["sap_int01","sap_idmz01","sap_edmz01","sap_edmz_pvtend01","sap_cv01"]
        "bypass"                    = ["AzureServices"]
    }
}

#------------------------------------- Lifecycle Management of Storage Account-----------------------
management_policies_diag = {
    "sta_management_policy_diag" = {
        rule_name = "sapprddiags1"
        storage_account_name = "sta_sap_diag"
    }
}

###---------------------------------------Role Assignemnt------------------------------------
role_assign_sta_diag = {
    role_sta_diag = {
        "role_definition_name" = "Key Vault Crypto Service Encryption User"
        "kv_name"              = "kv_sap"
        "sta_name"             = "sta_sap_diag"
    }
}

#---------------------------------- Customer Managed Key - Storage Account -----------------
cmk_sta_diag = {
    "cmk_sta_diag" = {
        "sta_name" = "sta_sap_diag"
        "kv_name"  = "kv_sap"
        "key_name" = "storageencryptkey"
    }
}

###-------------------------------------- Disk Encryption Set ---------------------------------
cv_des = {
    cv_des_01 = {
        des_name       = "SAPPROD01"
        resource_group = "RG_app"
        kv_key_name    = "kv_key_disk"
        kv_name        = "kv_sap"
        tags           = {}
    }
}
role_definition_name = "Key Vault Crypto Service Encryption User"


###------------------------------------- Network Interface --------------------------------------
cv_nics = {
    "cv_nic_01" = {
        nic_name = "ZWCV025"
        resource_group = "RG_cv"
        subnet_name = "sap_cv01"
        ip_configs = [{
            ip_config_name = "ipconfig1"
            private_ip_address_allocation = "Dynamic"
            primary = true
        }]
        tags = {}
        },

    "cv_nic_02" = {
        nic_name = "ZWCV026"
        resource_group = "RG_cv"
        subnet_name = "sap_cv01"
        ip_configs = [{
            ip_config_name = "ipconfig1"
            private_ip_address_allocation = "Dynamic"
            primary = true
        }]
        tags ={}
    }
}

accelerated_networking_enabled = true

###-----------------------------------Disk access and Private endpoint-----------------------------

disk_access_vms = {
    "disk_access_01" = {
        "disk_name"         = "Commvault-SAP-PROD-DiskAccess"
        "resource_group"    = "RG_cv"
        "tags"              = {}
    }
}

pvt_endpoints_disk_access = {
    "PE_disk" = {
        "pe_name"               = "PREP-DA-001"
        "disk_name"             = "disk_access_01"
        "subnet_name"           = "sap_edmz_pvtend01"
        "resource_group"        = "RG_cv"
        "is_manual_connection"  = false
        "subresource_names"     = ["disks"]
        "pe_tags"               = {}
    }
}
###----------------------------------- Windows Virtual Machine ---------------------------------
cv_vms = {
    "cv_vm_01" = {
        cv_vm_names    = "ZWCV025"
        resource_group = "RG_cv"
        nic_name       = "cv_nic_01"
        avset_name     = ""
        zone           = "1"
        des_name       = "cv_des_01"
        sta_name       = "sta_sap_diag"
        tags           = {}

    },
    "cv_vm_02" = {
        cv_vm_names    = "ZWCV026"
        resource_group = "RG_cv"
        nic_name       = "cv_nic_02"
        avset_name     = ""
        zone           = "2"
        des_name       = "cv_des_01"
        sta_name       = "sta_sap_diag"
        tags           = {}
    }
}

cv_vm_instance_type = "Standard_D2s_v5"
encryption_at_host_enabled = true
secure_boot_enabled       = false
vtpm_enabled              = false 
license_type              = "Windows_Server" 
disk_controller_type      = "SCSI"
disk_storage_account_type = "StandardSSD_LRS"
vm_os_disk_name            = null
vm_extension_name          = "IaaSAntimalware"
publisher                  = "Microsoft.Azure.Security"
type                       = "IaaSAntimalware"
type_handler_version       = "1.7"
auto_upgrade_minor_version = true
identity_type              = "SystemAssigned"
identity_ids               = []
vm_source_image_reference   = null
plan_details                = null
golden_win_name                = "1.0.4"
golden_win_image_name          = "Windows_2022"
golden_win_gallery_name        = "Cloud_Golden_Images_New"
golden_win_shortlocation       = "et"
golden_win_rg                  = "01-rg-c-9aag026594"
###------------------------------------Data Disks ----------------------------------
cv_data_disks = {
    "cv01_data_disk_01" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 512
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_01"
        "disk_name"      = "disk_access_01"
        "lun"            = 0 
        "tags"           = {}
    },
    "cv01_data_disk_02" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 1024
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_01"
        "disk_name"      = "disk_access_01"
        "lun"            = 1 
        "tags"           = {}
    },
    "cv01_data_disk_03" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 1024
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_01"
        "disk_name"      = "disk_access_01"
        "lun"            = 2 
        "tags"           = {}
    },
    "cv02_data_disk_01" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 512
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_02"
        "disk_name"      = "disk_access_01"
        "lun"            = 0 
        "tags"           = {}
    },
    "cv02_data_disk_02" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 1024
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_02"
        "disk_name"      = "disk_access_01"
        "lun"            = 1 
        "tags"           = {}
    },
    "cv03_data_disk_03" = {
        "resource_group" = "RG_cv"
        "disk_size_gb"   = 1024
        "des_id"         = "cv_des_01"
        "vm_name"        = "cv_vm_02"
        "disk_name"      = "disk_access_01"
        "lun"            = 2 
        "tags"           = {}
    }
}

data_disk_sa_type       = "Premium_LRS"
data_disk_create_option = "Empty"
data_disk_caching        = "None"
data_disk_write_accelerator = false
public_network_access_enabled_disks = false
network_access_policy_data_disk = "AllowPrivate"

####-------------------------------------SCCM VMs----------------------------------------
resource_groups_sccm        = {}
sccm_tags                   = {}
sccm_nics                   = {}
sccm_vms                    = {}
sccm_vm_instance_type       = "Standard_D2s_v5"
sccm_data_disks             = {}
disk_access_vms_sccm        = {}
pvt_endpoints_disk_access_sccm = {}
###------------------------------------SL VMs-----------------------------------------
resource_groups_sl              = {}
sl_tags                         = {}
sl_nics                         = {}
sl_vms                          = {}
sl_vm_instance_type             = "Standard_D2s_v5"
storage_account_type_sl         = "StandardSSD_LRS"
disk_access_vms_sl              = {}
pvt_endpoints_disk_access_sl    = {}
vhd_name                = "0.0.1"
vhd_image_name          = "SLImage1Aug25"
gallery_name            = "SLImages"
vhd_shortlocation       = "WE"
vhd_rg                  = "GLBPROD01-RG-F-MGMT"
###---------------------------------------Role Assignemnt------------------------------------
kv_role_definition_names       = ["Key Vault Purge Operator"]
role_definition_name_cv_vm     = "Contributor"
role_definition_name_cv_vm_sta = "Storage Blob Data Owner"

### ------------------------------- Application Security Group Creation -------------------------
cv_asgs = {
"cv_sap_asgs" = {
    asg_name = "CV-SAPPRD"
    resource_group = "RG_mgmt"
    asg_tags       = {  
           "remark" = ""
        }
  }
}

### ------------------------------- Application Security Group - Network Interface Association ---------------------------
cv_asgs_nic_association = {
  "asg_nic_01" = {
    asg_name = "cv_sap_asgs"
    nic_name = "cv_nic_01"
  },
  "asg_nic_02" = {
    asg_name = "cv_sap_asgs"
    nic_name = "cv_nic_02"
}
}
####--------------------------------------- Application Security Group - SL --------------------------------
sl_asgs = {}

### ------------------------------- Application Security Group - Network Interface Association ---------------------------
sl_asgs_nic_association = {}

swc_sl_nic_names     = [ "ZLSL019" ,"ZLSL020" ]
inc_sl_nic_names     = [ "ZLSL023" ,"ZLSL024" ]
sl_nic_rg_name  = "GLBPROD01-RG-C-9AAG029945"