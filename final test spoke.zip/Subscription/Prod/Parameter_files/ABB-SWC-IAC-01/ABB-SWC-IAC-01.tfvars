###------------------------------------------- Subscription ----------------------------------
subscription_name           = "IAC-01"
billing_account_name        = "5099306"
enrollment_account_name     = "264764"
management_group_id         = "PROD-MGMTGRP"
subscription_billing_scope  = "/providers/Microsoft.Billing/billingAccounts/5099306/enrollmentAccounts/264764"
workload                    = "Production"
tags_sub ={
    remark              = ""
    environment         = ""
    model               = "application"
    application         = ""
    costcenter          = "r220900"
    costcenterowner     = "tomasz.repinski1@pl.abb.com"
    country             = "global"
    owningbusinessarea  = "zc"
    owningdivision      = "zcgs"
    owningcompany       = "chgpl"
}
###------------------------------------------- Location ---------------------------------------
location        = "SwedenCentral"
shortlocation   = "SWC"
mgshortlocation = "SWC"
###------------------------------------------- Tags------ --------------------------------------
rg_tags = {
    itsmnr              = "WO1173"
    remark              = ""
    environment         = ""
    model               = "application"
    igar                = "9aag026594"
    application         = "cloud hosting service infrastructure"
    costcenter          = "52013300"
    costcenterowner     = "tomasz.repinski1@pl.abb.com"
    country             = "global"
    owningbusinessarea  = "zc"
    owningdivision      = "zcgs"
    owningcompany       = "chgpl"
}

cv_tags = {}

ntw_watch_tags = {
    itsmnr    = "ritm5066418"
    remark = "BizTalk - required for whitlisting"
    environment = ""
    model = "application"
    igar = "9aag026594"
    application = "cloud hosting service infrastructure"
    costcenter = "52013300"
    costcenterowner = "tomasz.repinski1@pl.abb.com"
    country = "global"
    owningbusinessarea = "zc"
    owningdivision = "zcgs"
    owningcompany = "chgpl"
}
###-------------------------------------Resource Groups------------------------------------------
resource_groups = {
    "RG_ntw"    =   {
        "name"  = "IAC01-RG-F-NETWORK"
    }
}

resource_groups_cv = {
}

rg_ntw_watch = {
    "ntw_watch" = {
        "name" = "NetworkWatcherRG"
    }
}

#---------------------------------------Network Watcher----------------------------------------
network_watchers = {
    "networkwatcher" = {
    "nwr_name"            = "NetworkWatcher"
    "resource_group"      = "ntw_watch"
}
}
###---------------------------------------------- Vnets -------------------------------------------
vnets = {
    "vnet_iac"  =  {
        "vnet_name"           = "IAC-VNET01",
        "vnet_address_space"  = ["10.234.188.0/22"],
        "resource_group"      = "RG_ntw"
        "dns_servers"         = ["10.16.7.12", "10.17.106.6", "168.63.129.16", "10.16.114.10", "10.16.113.6"]
        "vnet_tags"           = {    
        "remark"              = ""     
        }
    }
}
####--------------------------DDos Plan details in Hub-------------------------
ddos_protection_plan_enabled = true
ddos_shortlocation = "SWC"
ddos_name = "DDoS-01"
ddos_rg = "RG-F-NETWORK"
inc_hub_subscription_identifier = "HUB02"
swc_hub_subscription_identifier = "HUB01"
###-------------------------------------------- Subnets -------------------------------------------
subnets = {
    "iac_int01" = {
        "snet_name"          = "IAC-VNET01-INT01"
        "newbits"            = 5
        "netnum"             = 0
        "vnet_name"          = "vnet_iac"
        "resource_group"     = "RG_ntw" 
        "service_endpoints"  = ["Microsoft.KeyVault"] 
    },
    "iac_idmz01" = {
        "snet_name"          = "IAC-VNET01-IDMZ01"
        "newbits"            = 5
        "netnum"             = 16
        "vnet_name"          = "vnet_iac"
        "resource_group"     = "RG_ntw" 
        "service_endpoints"  = []  
    },
    "iac_edmz01" = {
        "snet_name"          = "IAC-VNET01-EDMZ01"
        "newbits"            = 5
        "netnum"             = 24
        "vnet_name"          = "vnet_iac"
        "resource_group"     = "RG_ntw"  
        "service_endpoints"  = [] 
    }
}
###---------------------Route table, RouteTable--SubnetAssociations, Routes-------------------------------
route_table_names = {}
bgp_route_propagation_enabled = false
RouteTableSubnetAssociations = {}
glb-fw-lb-name = "backend-lb"
glb_fw_lb_rg = "RG-F-GLBFW"
zscaler-lb-name = "LLB-9AAG028759-01"
zscaler-rg = "RG-C-9AAG028759"
routes = {}
###------------------------------------------------- NSGs ---------------------------------------
nsgs = {
    "iac_int01"                =   {
        "nsg_name"           = "IAC-VNET01-INT01"
        "resource_group"     = "RG_ntw"
        "nsg_tags"           = {
            "remark" = ""
        }
    },
    "iac_idmz01"                =   {
        "nsg_name"           = "IAC-VNET01-IDMZ01"
        "resource_group"     = "RG_ntw"
        "nsg_tags"           = {
            "remark" = ""
        }
    },
    "iac_edmz01"                =   {
        "nsg_name"           = "IAC-VNET01-EDMZ01"
        "resource_group"     = "RG_ntw"
        "nsg_tags"           = {
            "remark" = ""
        }
    }
}
###-----------------------------------NSG - Subnet Associations---------------------------------------
nsgAssociationSubnet = {
    "iac_edmz01" = {
        "nsg_name"       = "iac_edmz01"
        "subnet_name"    = "iac_edmz01"
    },
    "iac_idmz01" = {
        "nsg_name"       = "iac_idmz01"
        "subnet_name"    = "iac_idmz01"
    },
    "iac_int01" = {
        "nsg_name"       = "iac_int01"
        "subnet_name"    = "iac_int01"
    }
}  

#--------------------------------------------NSG Rules-------------------------------------------
sl_asg_name     = "SL"
sl_asg_rg_name  = "GLBPROD01-RG-C-9AAG029945"
nsg_rules       = {}

#---------------------------------Azure Virtual Network Manager---------------------------
avnm_shortlocation = "SWC"
avnm_subscription_name = "HUB-01"
ntw_group_name = "ALL-VNETs"
ntw_manager_name = "AVNM01"
static_members = {
    "static_member_01" = {
        avnm_static_member_name = "IAC-Vnet"
        vnet_name = "vnet_iac"
    }
}
avnm_rules = {}

avnm_rule_collection_name = "VNET01-GW01-UDR01-RC01"
avnm_routing_name = "VNET01-GW01-UDR01"
glb_fw = {
    "glb_fw" = {
        glb-fw-lb-name = "backend-lb"
        glb_fw_lb_rg = "RG-F-GLBFW"
    }
}

###----------------------------------------- Vnet Flow logs ----------------------------------------
sta_name          = "glbprdstalog02"
sta_rg            = "RG-F-MGMT"
law_name          = "LA-01"
law_rg            = "RG-F-MGMT"
enabled               = true
flow_log_version      = 2
retention_days        = 31
traffic_analytics_enabled = true
interval_in_minutes   = 10

####---------------------------------Key Vault Creation ---------------------------------
keyvault                            = {}
kv_sku_name                         = "standard"
kv_purge_protection_enabled         = true
kv_soft_delete_retention_days       = 30
kv_enable_rbac_authorization        = true
kv_enabled_for_disk_encryption      = true
kv_enabled_for_template_deployment  = true
kv_enabled_for_deployment           = true
kv_public_network_access_enabled    = true
kv_bypass                     = "AzureServices"
kv_default_action             = "Deny"
kv_ip_rules                   = []

#self hosted vm network details
iac_vnet_name = "IAC-VNET01"
iac_vnet_rg   = "IAC01-RG-F-NETWORK"
iac_subnet_name ="IAC-VNET01-INT01"
iac_shortlocation = "SWC"

# DNS entry details
dns_shortlocation       = "WE"
private_dns_zone_rgName = "HUB01-RG-F-DNS"
sta_dns_zone_name       = "privatelink.blob.core.windows.net"
kv_dns_zone_name        = "privatelink.vaultcore.azure.net"
###-----------------------------------Private Endpoint-----------------------------------------------
pvt_endpoints = {}

# ####-------------------Key Vault Key ----------------------------
keyvault_key           = {}
kv_key_type            = "RSA"
kv_key_opts            = ["decrypt", "encrypt", "sign", "unwrapKey", "verify", "wrapKey"]
kv_key_size            = "2048"
expiration_date = null

###---------------------------------------Role Assignemnt------------------------------------
role_assign_kv  = {}
role_assign_sta = {}

#####------------------------------Diagnostic settings----------------------------------------
enable_logs         = true
enabled_metric      = false
workspace_rs_id     = ""

#------------------------------------Storage Accounts-------------------------------
storage_accounts                  = {}
account_tier                      = "Standard"
access_tier                       = "Cool"
account_replication_type          = "LRS"
cross_tenant_replication_enabled  = false
is_hns_enabled                    = false
delete_retention_days             = 7
container_delete_retention_days   = 0
allow_blob_public_access          = false
public_network_access_enabled     = true
infrastructure_encryption_enabled = true
shared_access_key_enabled         = true
versioning_enabled                = false
large_file_share_enabled          = true
min_tls_version                   = "TLS1_2"

###-----------------------------------Private Endpoint-----------------------------------------------
pvt_endpoints_sta = {}
sta_ip_rules      = {}

#------------------------------------- Lifecycle Management of Storage Account-----------------------
management_policies = {}

rule_enabled = true
blob_types   = ["blockBlob"]
delete_after_days_since_modification_greater_than = 90
delete_after_days_since_creation_greater_than = 90

#---------------------------------- Customer Managed Key - Storage Account -----------------
cmk_sta = {}

##------------------------------------- Commvault Configuration --------------------------------------------
###------------------------------------Diagnostic Storage Accounts-------------------------------
storage_accounts_diag        = {}
delete_retention_days_01     = 0
access_tier_diag             = "Hot"
###-----------------------------------Diagnostic Private Endpoint-----------------------------------------------
pvt_endpoints_sta_diag = {}
sta_ip_rules_diag      = {}

#------------------------------------- Lifecycle Management of Storage Account-----------------------
management_policies_diag = {}

###---------------------------------------Role Assignemnt------------------------------------
role_assign_sta_diag = {}

#---------------------------------- Customer Managed Key - Storage Account -----------------
cmk_sta_diag = {}

###-------------------------------------- Disk Encryption Set ---------------------------------
cv_des               = {}
role_definition_name = "Key Vault Crypto Service Encryption User"


###------------------------------------- Network Interface --------------------------------------
cv_nics                        = {}
accelerated_networking_enabled = true

###-----------------------------------Disk access and Private endpoint-----------------------------
disk_access_vms           = {}
pvt_endpoints_disk_access = {}

###----------------------------------- Windows Virtual Machine ---------------------------------
cv_vms = {}
cv_vm_instance_type = "Standard_E4s_v6"
encryption_at_host_enabled = true
secure_boot_enabled       = true
vtpm_enabled              = true 
license_type              = "Windows_Server" 
disk_controller_type      = "SCSI"
disk_storage_account_type = "StandardSSD_LRS"
vm_os_disk_name            = null
vm_extension_name          = "IaaSAntimalware"
publisher                  = "Microsoft.Azure.Security"
type                       = "IaaSAntimalware"
type_handler_version       = "1.7"
auto_upgrade_minor_version = true
identity_type              = "SystemAssigned"
identity_ids               = []
vm_source_image_reference   = null
plan_details                = null
golden_win_name                = "1.0.4"
golden_win_image_name          = "Windows_2022"
golden_win_gallery_name        = "Cloud_Golden_Images_New"
golden_win_shortlocation       = "et"
golden_win_rg                  = "01-rg-c-9aag026594"
###------------------------------------Data Disks ----------------------------------
cv_data_disks                       = {}
data_disk_sa_type                   = "Premium_LRS"
data_disk_create_option             = "Empty"
data_disk_caching                   = "None"
data_disk_write_accelerator         = false
public_network_access_enabled_disks = false
network_access_policy_data_disk     = "AllowPrivate"

####-------------------------------------SCCM VMs----------------------------------------
resource_groups_sccm = {}
sccm_tags            = {}
sccm_nics            = {}
sccm_vms             = {}
sccm_vm_instance_type = "Standard_D2s_v4"
sccm_data_disks       = {}
disk_access_vms_sccm  = {}
pvt_endpoints_disk_access_sccm = {}

###------------------------------------SL VMs-----------------------------------------
resource_groups_sl              = {}
sl_tags                         = {}
sl_nics                         = {}
sl_vms                          = {}
sl_vm_instance_type             = "Standard_D2s_v5"
storage_account_type_sl         = "StandardSSD_LRS"
disk_access_vms_sl              = {}
pvt_endpoints_disk_access_sl    = {}
vhd_name                = "0.0.1"
vhd_image_name          = "SLImage1Aug25"
gallery_name            = "SLImages"
vhd_shortlocation       = "WE"
vhd_rg                  = "GLBPROD01-RG-F-MGMT"
###---------------------------------------Role Assignemnt------------------------------------
kv_role_definition_names       = ["Key Vault Purge Operator"]
role_definition_name_cv_vm     = "Contributor"
role_definition_name_cv_vm_sta = "Storage Blob Data Owner"

####--------------------------------------- Application Security Group --------------------------------
cv_asgs = {}

### ------------------------------- Application Security Group - Network Interface Association ---------------------------
cv_asgs_nic_association = {}

####--------------------------------------- Application Security Group - SL --------------------------------
sl_asgs = {}

### ------------------------------- Application Security Group - Network Interface Association ---------------------------
sl_asgs_nic_association = {}

swc_sl_nic_names     = [ "ZLSL019" ,"ZLSL020" ]
inc_sl_nic_names     = [ "ZLSL023" ,"ZLSL024" ]
sl_nic_rg_name  = "GLBPROD01-RG-C-9AAG029945"