locals {
  subscription_alias_name = "ABB-${var.shortlocation}-${var.subscription_name}"
}
