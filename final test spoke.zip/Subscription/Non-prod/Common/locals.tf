locals {
#####-----------------------------NSG rules ---------------------------------------
subnet_prefix       = { for k, s in module.snet : k => s.subnet_address_prefix }
vnet_address_space  = { for key, vnet in var.vnets: key => vnet.vnet_address_space[0] }
sl_nics_glb_prod_ids = {
  "sl_nics" = (var.shortlocation == "SWC" ? try(join(",", data.azurerm_network_interface.swc_glb_sl_nic[*].private_ip_address), null) : 
                var.shortlocation == "INC" ? try(join(",", data.azurerm_network_interface.inc_glb_sl_nic[*].private_ip_address), null) : null)
}
vnet_subnet_address      = merge(local.subnet_prefix, local.vnet_address_space, local.sl_nics_glb_prod_ids)
#####-----------------------------Application security group ids ---------------------------------------
cv_asg_ids                     = { for k, csg in module.cv_asg : k => csg.asg_id }
application_security_group_ids = merge(local.cv_asg_ids)

nsg_rules = {
  for key, nsr in var.nsg_rules: key => merge(nsr, {
    nsr_source_address_prefix                 = alltrue([(nsr.nsr_source_address_prefix != null), (nsr.nsr_source_address_prefix != "*")]) ? (try(local.vnet_subnet_address[nsr.nsr_source_address_prefix], nsr.nsr_source_address_prefix)) : nsr.nsr_source_address_prefix
    nsr_destination_address_prefix            = alltrue([(nsr.nsr_destination_address_prefix != null), (nsr.nsr_destination_address_prefix != "*")]) ? (try(local.vnet_subnet_address[nsr.nsr_destination_address_prefix], nsr.nsr_destination_address_prefix)) : nsr.nsr_destination_address_prefix
    nsr_source_address_prefixes               = (nsr.nsr_source_address_prefixes != null) ? try(split(",", local.vnet_subnet_address[nsr.nsr_source_address_prefixes[0]]), nsr.nsr_source_address_prefixes) : nsr.nsr_source_address_prefixes
    nsr_destination_address_prefixes          = (nsr.nsr_destination_address_prefixes != null) ? try(split(",", local.vnet_subnet_address[nsr.nsr_destination_address_prefixes[0]]), nsr.nsr_destination_address_prefixes) : nsr.nsr_destination_address_prefixes
    nsr_source_application_security_group_ids = alltrue([(nsr.nsr_source_address_prefix == null), (nsr.nsr_source_address_prefixes == null)]) ? (try([local.application_security_group_ids[nsr.nsr_source_application_security_group_ids[0]]], nsr.nsr_source_application_security_group_ids)) : nsr.nsr_source_application_security_group_ids
  }) 
}

#####-----------------------------Routes ---------------------------------------
route_data = {
  "GLB-FW-FrontendIP"  = (var.shortlocation == "SWC" ? try(data.azurerm_lb.swc_glb_fw_lb[0].private_ip_address,null) : 
                          var.shortlocation == "INC" ? try(data.azurerm_lb.inc_glb_fw_lb[0].private_ip_address, null) : null)

  "Zscaler-FrontendIP" = (var.shortlocation == "SWC" ? try(data.azurerm_lb.swc_zscaler_lb[0].private_ip_address,null) : 
                          var.shortlocation == "INC" ? try(data.azurerm_lb.inc_zscaler_lb[0].private_ip_address, null) : null)
} 

routes = {
  for key, rts in var.routes: key => merge(rts, {
    next_hop_in_ip_address = (rts.next_hop_type == "VirtualAppliance") ? (try(local.route_data[rts.next_hop_in_ip_address], rts.next_hop_in_ip_address)) : rts.next_hop_in_ip_address
    route_address_prefix   = (try(local.route_data[rts.route_address_prefix], rts.route_address_prefix)) 
  })
}

#####-----------------------------Hub vnet flowlog storage account ---------------------------------------
sta_id       =   ( var.shortlocation == "SWC" ? data.azurerm_storage_account.swc_stgacc[0].id :
                 var.shortlocation == "INC" ? data.azurerm_storage_account.inc_stgacc[0].id : null)

#####-----------------------------Hub Log analytics workspace ---------------------------------------
workspace =  ( var.shortlocation == "SWC" ? data.azurerm_log_analytics_workspace.swc_law[0] :
                 var.shortlocation == "INC" ? data.azurerm_log_analytics_workspace.inc_law[0] : null)

#####-----------------------------Hub avnm rule ---------------------------------------
avnm_rule_next_hop_address = ( var.shortlocation == "SWC" ? values(data.azurerm_lb.swc_glb_fw_lb_avnm)[0].private_ip_address : 
                              var.shortlocation == "INC" ? values(data.azurerm_lb.inc_glb_fw_lb_avnm)[0].private_ip_address : null)
}