# For DDoS
data "azurerm_network_ddos_protection_plan" "ddosp" {
    provider            = azurerm.swc_hub_sub_id
    count               = var.ddos_shortlocation == "SWC" ? 1 : 0
    name                = "ABBIS${var.ddos_shortlocation}${var.swc_hub_subscription_identifier}-${var.ddos_name}"
    resource_group_name = "IS${var.ddos_shortlocation}${var.swc_hub_subscription_identifier}-${var.ddos_rg}"
}
data "azurerm_client_config" "current" {}
#self hosted vm subnet
data "azurerm_subnet" "swc_iac_subnet" {
    provider             = azurerm.swc_iac_sub_id
    name                 = "${var.iac_shortlocation}-${var.iac_subnet_name}"
    virtual_network_name = "${var.iac_shortlocation}-${var.iac_vnet_name}"
    resource_group_name  = "IS${var.iac_shortlocation}${var.iac_vnet_rg}"
}
#windows vm image
data "azurerm_shared_image_version" "golden_win_image" {
    provider = azurerm.golden_win_image
    name                = var.golden_win_name
    image_name          = var.golden_win_image_name
    gallery_name        = var.golden_win_gallery_name
    resource_group_name = "is${var.golden_win_shortlocation}${var.golden_win_rg}"
}

###---For SWC Resources in other subscriptions--------------------
data "azurerm_storage_account" "swc_stgacc" {
    provider            = azurerm.swc_hub_sub_id
    count               = var.shortlocation == "SWC" ? 1 : 0
    name                = "abbis${lower(var.shortlocation)}${var.sta_name}" 
    resource_group_name = "IS${var.shortlocation}${var.swc_hub_subscription_identifier}-${var.sta_rg}"
}
data "azurerm_log_analytics_workspace" "swc_law" {
    provider            = azurerm.swc_hub_sub_id
    count               = var.shortlocation == "SWC" ? 1 : 0
    name                = "IS${var.shortlocation}${var.swc_hub_subscription_identifier}-${var.shortlocation}-${var.law_name}"
    resource_group_name = "IS${var.shortlocation}${var.swc_hub_subscription_identifier}-${var.law_rg}"
}
data "azurerm_lb" "swc_glb_fw_lb" {
    provider            = azurerm.swc_hub_sub_id
    count               = var.shortlocation == "SWC" ? 1 : 0
    name                = var.glb-fw-lb-name
    resource_group_name = "IS${var.shortlocation}${var.swc_hub_subscription_identifier}-${var.glb_fw_lb_rg}"
}
data "azurerm_lb" "swc_zscaler_lb" {
    provider            = azurerm.swc_hub_sub_id
    count                = var.shortlocation == "SWC" ? 1 : 0
    name                = "IS${var.shortlocation}${var.swc_hub_subscription_identifier}-${var.shortlocation}-${var.zscaler-lb-name}"
    resource_group_name = "IS${var.shortlocation}${var.swc_hub_subscription_identifier}-${var.zscaler-rg}"
}
data "azurerm_lb" "swc_glb_fw_lb_avnm" {
    provider            = azurerm.swc_hub_sub_id
    for_each            = var.shortlocation == "SWC" ? var.glb_fw : {}
    name                = each.value.glb-fw-lb-name
    resource_group_name = "IS${var.shortlocation}${var.swc_hub_subscription_identifier}-${each.value.glb_fw_lb_rg}"
}
data "azurerm_network_interface" "swc_glb_sl_nic" {
  provider            = azurerm.swc_glb_sub_id
  count               = alltrue([var.shortlocation == "SWC", var.swc_sl_nic_names != null]) ? length(var.swc_sl_nic_names) : 0
  name                = "XC-S-${var.swc_sl_nic_names[count.index]}-nic01"
  resource_group_name = "IS${var.shortlocation}${var.sl_nic_rg_name}" 
}
#--------------------------------- Azure Virtual Network Manager ---------------------------

data "azurerm_network_manager" "avnm" { 
  provider            = azurerm.network_manager_id
  name                = "IS${var.avnm_shortlocation}${var.avnm_subscription_name}-${var.ntw_manager_name}"
  resource_group_name = "IS${var.avnm_shortlocation}${var.avnm_subscription_name}-RG-F-AVNM"
}
data "azurerm_network_manager_network_group" "avnm_ntw_group" {
  provider            = azurerm.network_manager_id
  name                = "${var.shortlocation}-${var.ntw_group_name}"
  network_manager_id  = data.azurerm_network_manager.avnm.id
}
data "azapi_resource" "avnm_routing" {
    type      = "Microsoft.Network/networkManagers/routingConfigurations@2024-05-01"
    name      = "AVNM-${var.shortlocation}-HUB-${var.avnm_routing_name}"
    parent_id = data.azurerm_network_manager.avnm.id
}

data "azapi_resource" "avnm_rule_collection" {
    type      = "Microsoft.Network/networkManagers/routingConfigurations/ruleCollections@2024-05-01"
    name      = "AVNM-${var.shortlocation}-HUB-${var.avnm_rule_collection_name}"
    parent_id = data.azapi_resource.avnm_routing.id
}

## For INC resources in other subscriptions--------------------
data "azurerm_storage_account" "inc_stgacc" {
    provider            = azurerm.inc_hub_sub_id
    count               = alltrue([var.shortlocation == "INC", var.sta_name != null]) ? 1 : 0
    name                = "abbis${lower(var.shortlocation)}${var.sta_name}" 
    resource_group_name = "IS${var.shortlocation}${var.inc_hub_subscription_identifier}-${var.sta_rg}"
}
data "azurerm_log_analytics_workspace" "inc_law" {
    provider            = azurerm.inc_hub_sub_id
    count               = alltrue([var.shortlocation == "INC", var.law_name != null]) ? 1 : 0
    name                = "IS${var.shortlocation}${var.inc_hub_subscription_identifier}-${var.shortlocation}-${var.law_name}"
    resource_group_name = "IS${var.shortlocation}${var.inc_hub_subscription_identifier}-${var.law_rg}"
}
data "azurerm_lb" "inc_glb_fw_lb" {
    provider            = azurerm.inc_hub_sub_id
    count               = alltrue([var.shortlocation == "INC", var.glb_fw_lb_rg != null ]) ? 1 : 0
    name                = var.glb-fw-lb-name
    resource_group_name = "IS${var.shortlocation}${var.inc_hub_subscription_identifier}-${var.glb_fw_lb_rg}"
}
data "azurerm_lb" "inc_zscaler_lb" {
    provider            = azurerm.inc_hub_sub_id
    count                = alltrue([var.shortlocation == "INC", var.zscaler-lb-name != null]) ? 1 : 0
    name                = "IS${var.shortlocation}${var.inc_hub_subscription_identifier}-${var.shortlocation}-${var.zscaler-lb-name}"
    resource_group_name = "IS${var.shortlocation}${var.inc_hub_subscription_identifier}-${var.zscaler-rg}"
}
data "azurerm_lb" "inc_glb_fw_lb_avnm" {
    provider            = azurerm.inc_hub_sub_id
    for_each            = var.shortlocation == "INC" ? var.glb_fw : {}
    name                = each.value.glb-fw-lb-name
    resource_group_name = "IS${var.shortlocation}${var.inc_hub_subscription_identifier}-${each.value.glb_fw_lb_rg}"
}
data "azurerm_network_interface" "inc_glb_sl_nic" {
  provider            = azurerm.inc_glb_sub_id
  count               = alltrue([var.shortlocation == "INC", var.inc_sl_nic_names != null]) ? length(var.inc_sl_nic_names) : 0
  name                = "XC-S-${var.inc_sl_nic_names[count.index]}-nic01"
  resource_group_name = "IS${var.shortlocation}${var.sl_nic_rg_name}" 
}