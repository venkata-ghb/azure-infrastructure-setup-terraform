variable "location" {
  description = "Specifies the location of the Resource"
  type = string
}
variable "sa_subscription_id" {
  description = "Specifies the storage account subscription id"
  type = string
}
variable "subscription_id" {
  description = "Specifies the subscription id"
  type = string
}
variable "shortlocation" {
  description = "Specifies the short location as an identification"
  type = string
}
###--------------------------------------------Provider Block Variables ----------------------------------
## For SWC resources from other Subscriptions
variable "swc_hub_subscription_id" {
  description = "Specifies the SWC-HUB subscription id"
  type = string
}
variable "swc_glb_subscription_id" {
  description = "Specifies the SWC-GLB-PROD subscription id"
  type = string
}
variable "swc_iac_subscription_id" {
  description = "Specifies the SWC-IAC subscription id"
  type = string
}
variable "network_manager_id" {
  description = "Specifies network manager subscription id"
  type = string
}
variable "golden_win_subscription_id" {
  description = "Specifies golden images subscription id"
  type = string
}
## For INC resources from other Subscriptions
variable "inc_hub_subscription_id" {
  description = "Specifies INC-HUB subscription id"
  type = string
}
variable "inc_glb_subscription_id" {
  description = "Specifies INC-GLB-PROD subscription id"
  type = string
}
###---------------------------------------------Data Block variables-----------------------------------
variable "ddos_shortlocation" {
  description = "Specifies the ddos short location"
  type = string
}
variable "ddos_name" {
  description = "Specifies the ddos name"
  type = string
}
variable "ddos_rg" {
  description = "Specifies the ddos resource group name"
  type = string
}
variable "sta_name" {
  description = "Specifies the SWC-HUB storage account name"
  type = string
}
variable "sta_rg" {
  description = "Specifies the SWC-HUB storage account resource group name"
  type = string
}
variable "law_name" {
  description = "Specifies the SWC-HUB Log analytics workspace name"
  type = string
}
variable "law_rg" {
  description = "Specifies the SWC-HUB Log analytics workspace resource group name"
  type = string
}
#self hosted vm network details
variable "iac_vnet_name" {
  description = "Specifies the IAC VNET name"
  type = string
}
variable "iac_vnet_rg" {
  description = "Specifies the IAC VNET Resource group name"
  type = string
}
variable "iac_subnet_name" {
  description = "Specifies the IAC subnet name"
  type = string
}
variable "iac_shortlocation" {
  description = "Specifies the IAC short location where the self hosted VMs are created"
  type = string
}

variable "glb-fw-lb-name" {
  description = "Specifies the GLB Firewall load balancer name"
  type = string
}
variable "glb_fw_lb_rg" {
  description = "Specifies the GLB Firewall load balancer resource group name"
  type = string
}
variable "zscaler-lb-name" {
  description = "Specifies the Zscaler Could connector load balancer name"
  type = string
}
variable "zscaler-rg" {
  description = "Specifies the Zscaler Could connector load balancer resource group name"
  type = string
}
variable "avnm_shortlocation" {
  description = "Specifies the AVNM Short location"
  type = string
}
variable "avnm_subscription_name" {
  description = "Specifies the AVNM subscription name"
  type = string
}
variable "ntw_group_name" {
  description = "Specifies the Network Group name"
  type = string
}
variable "ntw_manager_name" {
  description = "Specifies the Network manager name"
  type = string
}
variable "golden_win_name" {
  description = "Specifies the golden Image version"
  type = string
}
variable "golden_win_image_name" {
  description = "Specifies the Golden Image name"
  type = string
}
variable "golden_win_gallery_name" {
  description = "Specifies the golden Image gallery name"
  type = string
}
variable "golden_win_shortlocation" {
  description = "Specifies the golden Image short location"
  type = string
}
variable "golden_win_rg" {
  description = "Specifies the golden Image resource group name"
  type = string
}

variable "swc_sl_nic_names" {
  description = "Specifies the Network Interface of Science Logic VM in GLB-PROD subscription"
  type = list(string)
}
variable "inc_sl_nic_names" {
  description = "Specifies the Network Interface of Science Logic VM in GLB-PROD subscription"
  type = list(string)
}
variable "sl_nic_rg_name" {
  description = "Specifies the resource group of Network Interface of Science Logic VM in GLB-PROD subscription"
  type = string
}
variable "inc_hub_subscription_identifier" {
  description = "Specifies the INC-HUB subscription identifier"
  type = string
}
variable "swc_hub_subscription_identifier" {
  description = "Specifies the SWC-HUB subscription identifier"
  type = string
}
###-----------------------------------Resource Groups ----------------------------------------
variable "resource_groups"{
  description = "The name of the  network resource group."
  type = map(object({
    name = string 
  }))
}
variable "rg_tags" {
  description = "A mapping of tags to all the resources."
  type       = map(string)
}
variable "rg_ntw_watch" {
  description = "The name of the  network watcher resource group."
  type = map(object({
    name = string 
  }))
}
variable "ntw_watch_tags" {
  description = "A mapping of tags to the network watcher resource."
  type       = map(string)
}
variable "resource_groups_cv"{
  description = "The name of the  commvault resource group."
  type = map(object({
    name = string 
  }))
}
variable "cv_tags" {
  description = "A mapping of tags to all the commvault resources."
  type       = map(string)
}
# #---------------------------------------Network Watcher----------------------------------------
 variable "network_watchers" {
  description = "Specifies the network watcher"
  type = map(object({
    nwr_name            = string
    resource_group      = string
  }))
 }
###---------------------------------------Vnets -----------------------------------------------
variable "vnets" {
  description = "Specifies the Virtual network"
  type = map(object({
    vnet_name           = string
    vnet_address_space  = list(string)
    resource_group      = string
    dns_servers         = list(string)
    vnet_tags           = map(string)
  }))
}
variable "ddos_protection_plan_enabled" {
  description = "Specifies the DDoS protection plan"
  type = bool
}
###--------------------------------------Subnets ----------------------------------------------
variable "subnets"{
  description = "Specifies the Subnets"
  type = map(object({
    snet_name          = string
    newbits            = number
    netnum             = number
    vnet_name          = string
    resource_group     = string 
    service_endpoints  = list(string)
  }))
}
###---------------------Route table, Subnet Associations, Routes-------------------------------
variable "route_table_names" {
  description = "Specifies the Route tables"
  type = map(object({
    name           = string
    resource_group = string
    rt_tags        = map(string) 
  }))
}

variable "bgp_route_propagation_enabled" {
  description = "(Optional) Boolean flag which controls propagation of routes learned by BGP on that route table. Defaults to true."
  type        = bool
}

variable "RouteTableSubnetAssociations" {
  description = "Specifies the Route tables association with subnets"
  type = map(object({
    route_table_name       = string
    subnet_name            = string
  }))
}
variable "routes" {
  description = "Specifies the Routes"
  type = map(object({
    name                    = string
    resource_group          = string
    route_table_name        = string
    route_address_prefix    = string
    next_hop_type           = string
    next_hop_in_ip_address  = string
  }))
}
###------------------------  NSG/NSG Subnet Association/NSG Rules------------------------------
variable "nsgs"{
  description = "Specifies the Network security groups"
  type = map(object({
    nsg_name       = string
    resource_group = string
    nsg_tags       = map(string) 
  }))
}
variable "nsgAssociationSubnet" {
  description = "Specifies the NSGs association with Subnets"
  type = map(object({
    nsg_name       = string
    subnet_name    = string
  }))
}
variable "nsg_rules" {
  description = "Specifies the network security rules to the NSGs"
  type = map(object({
    nsr_name                    = string
    nsg                         = string
    nsr_protocol                = string
    nsr_source_port_range       = string
    nsr_source_port_ranges      = list(string)
    nsr_destination_port_range  = string
    nsr_destination_port_ranges = list(string)
    nsr_source_address_prefix   = string
    nsr_source_address_prefixes = list(string)
    nsr_destination_address_prefix   = string
    nsr_destination_address_prefixes = list(string)
    nsr_priority                = string
    nsr_direction               = string
    nsr_access                  = string
    resource_group              = string
    nsr_source_application_security_group_ids = list(string)
  }))
}

#------------------------------ Azure Virtual Network Manager --------------------------------------
variable "static_members" {
  description = "Specifies the static members to the avnm"
  type = map(object({
    avnm_static_member_name = string
    vnet_name = string
  }))
}


variable "avnm_rules" {
  description = "Specifies the AVNM Rules"
   type = map(object({
    avnm_rule_name  = string
    vnet_name       = string
    type            = string
    nextHopType     = string
    lb_name         = string
  }))
}

variable "avnm_rule_collection_name" {
  description = "Specifies the AVNM Rule Collection name"
  type = string
}

variable "avnm_routing_name" {
  description = "Specifies the AVNM routing name"
  type = string
}

variable "glb_fw" {
  description = "Specifies the GLB Firewall"
  type = map(object({
    glb-fw-lb-name = string
    glb_fw_lb_rg = string
  }))
}

###----------------------------------------- Vnet Flow logs ----------------------------------------
variable "enabled" {
  description = "Should Network Flow Logging be Enabled?"
  type = bool
}
variable "traffic_analytics_enabled" {
  description = "Boolean flag to enable/disable traffic analytics."
  type = bool
}
variable "flow_log_version" {
  description = "Specifies the flow log version"
  type = number
}
variable "retention_days" {
  description = "Specifies the retention days"
  type = number
}
variable "interval_in_minutes" {
  description = "Specifies the interval in minutes"
  type = number
}

###--------------------------------- Key Vault -------------------------------------------
variable "keyvault" {
  description = "Specifies the Key Vaults"
  type = map(object({
    key_vault_name      = string
    resource_group_name = string
    subnet_name         = list(string)
    tags                = map(string)
    dlog_name           = string
  }))
}

variable "kv_sku_name" {
  description = "The Name of the SKU used for this Key Vault. Possible values are standard and premium."
  type = string
}

variable "kv_enabled_for_deployment" {
  description = "Boolean flag to specify whether Azure Virtual Machines are permitted to retrieve certificates stored as secrets from the key vault. defaults to false."
  type        = bool
}

variable "kv_enabled_for_disk_encryption" {
  description = "Boolean flag to specify whether Azure Disk Encryption is permitted to retrieve secrets from the vault and unwrap keys. Defaults to false."
  type        = bool
}

variable "kv_enabled_for_template_deployment" {
  description = "Boolean flag to specify whether Azure Resource Manager is permitted to retrieve secrets from the key vault. Defaults to false."
  type        = bool
}

variable "kv_purge_protection_enabled" {
  description = "Is Purge Protection enabled for this Key Vault? Defaults to false. Once Purge Protection has been Enabled it's not possible to Disable it."
  type        = bool
}

variable "kv_soft_delete_retention_days" {
  description = "The number of days that items should be retained for once soft-deleted. This value can be between 7 and 90 (the Default) days."
  type        = number
}

variable "kv_enable_rbac_authorization" {
  description = "Boolean flag to specify whether Azure Key Vault uses Role Based Access Control (RBAC) for authorization of data actions. Defaults to false."
  type        = bool
}

variable "kv_default_action" {
  type = string
  description = "The Default Action to use when no rules match from ip_rules / virtual_network_subnet_ids. Possible values are Allow and Deny."
}

variable "kv_ip_rules" {
  type = list(string)
  description = "One or more IP Addresses, or CIDR Blocks which should be able to access the Key Vault."
}

variable "kv_bypass" {
  type = string
  description = "Specifies which traffic can bypass the network rules. Possible values are AzureServices and None"
}

variable "kv_public_network_access_enabled" {
  description = "Whether public network access is allowed for this Key Vault. Defaults to true."
  type = bool
}

####-----------------------------------Private Endpoint-----------------------------------------------
variable "pvt_endpoints" {
  description = "Specifies the Private endpoints"
  type = map(object({
    pe_name                               = string
    resource_group                        = string
    subnet_name                           = string
    key_vault_name                        = string
    is_manual_connection                  = bool
    subresource_names                     = list(string)
    pe_tags                               = map(string)
  }))
}

variable "dns_shortlocation" {
  description = "Specifies the dns short location"
  type = string
}
variable "private_dns_zone_subscription_id" {
  description = "Specifies the private dns zone subscription id"
  type = string
}
variable "private_dns_zone_rgName" {
  description = "Specifies the private dns zone resource group name"
  type = string
}
variable "sta_dns_zone_name" {
  description = "Specifies the private dns zone name for storage account"
  type = string
}
variable "kv_dns_zone_name" {
  description = "Specifies the private dns zone name for key vault"
  type = string
}
#####---------------------Key Vault Key ##########################
variable "keyvault_key" {
  description = "Specifies the key vault key"
  type = map(object({
    kv_key_name = string
    kv_name     = string
    kvk_tags    = map(string)
  }))
}

variable "kv_key_type" {
  description = "Specifies the Key Type to use for this Key Vault Key. Possible values are EC (Elliptic Curve), EC-HSM, Oct (Octet), RSA and RSA-HSM. Changing this forces a new resource to be created."
  type        = string
}

variable "kv_key_opts" {
  default     = ["decrypt", "encrypt", "sign", "unwrapKey", "verify", "wrapKey"]
  description = "A list of JSON web key operations. Possible values include: decrypt, encrypt, sign, unwrapKey, verify and wrapKey. Please note these values are case sensitive."
  type        = list(string)
}

variable "kv_key_size" {
  default     = null
  description = "Specifies the Size of the RSA key to create in bytes. For example, 1024 or 2048. Note: This field is required if key_type is RSA or RSA-HSM. Changing this forces a new resource to be created."
  type        = number
}

variable "expiration_date" {
  default     = null
  description = "Expiration UTC datetime (Y-m-d'T'H:M:S'Z')."
  type        = string
}

# ##---------------------------------------Role Assignment------------------------------------
variable "role_assign_kv" {
  description = "The role assignment details include scope and role definition name"
  type = map(object({
    role_definition_name = string
  }))

}

variable "role_assign_sta" {
  description = "The role assignment details include scope and role definition name"
  type = map(object({
    role_definition_name = string
    kv_name              = string
    sta_name             = string
  }))
}
#----------------------------------- Diagnostic Settings----------------------------------------
variable "enable_logs" {
  type = bool
  description = "enable logs for the diagnostic settings"
}
 
variable "enabled_metric" {
  type = bool
  description = "enable metrics for the diagnostic settings"
}
 
variable "workspace_rs_id" {
  description = "Specifies the ID of a Log Analytics Workspace where Diagnostics Data should be sent."
  type        = string
}
 
#--------------------------------------- Storage Account ----------------------------

variable "storage_accounts" {
  description = "Specifies the Storage accounts"
  type = map(object({
    sta_name          = string
    resource_group    = string
    tags              = map(string)  
  }))
}

variable "cross_tenant_replication_enabled" {
  description = "Specifies the type of replication to use for the storage account. Valid options are LRS, GRS, RAGRS, ZRS, GZRS and RAGZRS."
  type        =  bool
}

variable "delete_retention_days" {
  description = "Specifies the number of days that the container should be retained, between 1 and 365 days. Defaults to 7."
  type        = number
}

variable "is_hns_enabled" {
   description = "Is Hierarchical Namespace enabled? This can be used with Azure Data Lake Storage Gen 2 (see here for more information). Changing this forces a new resource to be created."
  type        = bool
}

variable "container_delete_retention_days" {
  default = null
  description = "Specifies the number of days that the container should be retained, between 1 and 365 days. Defaults to 7."
  type        = number
}

variable "allow_blob_public_access" {
  description = "Allow or disallow public access to all blobs or containers in the storage account. Defaults to false."
  type        = bool
}
 
variable "public_network_access_enabled" {
  description = "Specifies whether the public network access is enabled or not. Defaults to true."
  type        = bool
}
 
variable "infrastructure_encryption_enabled" {
  description = "Specifies if the infrastructure encryption enabled or not.Changing this forces a new resource to be created. Defaults to false."
  type        = bool
  default     = null
}
variable "shared_access_key_enabled" {
  type        = bool
  description = "Indicates whether the storage account permits requests to be authorized with the account access key via Shared Key. If false, then all requests, including shared access signatures, must be authorized with Azure Active Directory (Azure AD). Defaults to true"
}

variable "versioning_enabled" {
  description = "Specifies if the versioning enabled or not.Default to false"
  type        = bool
}

variable "large_file_share_enabled" {
  type = string
  description = "Are Large File Shares Enabled? Defaults to false."
}

variable "account_tier" {
  description = "Specifies the tier to use for the storage account. Valid options are Standard and Premium."
  type        = string
}

variable "access_tier" {
  type        = string
  description = "Specifies the tier to use for the storage account. Valid options are Hot, Cool, Cold and Archive."
}

variable "account_replication_type" {
  description = "Specifies the type of replication to use for the storage account. Valid options are LRS, GRS, RAGRS, ZRS, GZRS and RAGZRS."
  type        =  string
}

variable "min_tls_version" {
  description = "The minimum supported TLS version for the storage account. Possible values are TLS1_0, TLS1_1, and TLS1_2. Defaults to TLS1_2 for new storage accounts."
  type        = string
}
#----------------------------- Private Endpoint - Storage Account-------------
variable "pvt_endpoints_sta" {
  description = "Specifies the private endpoints for storage account"
  type = map(object({
    pe_name                         = string
    resource_group                  = string
    subnet_name                     = string
    sta_name                        = string
    is_manual_connection            = bool
    subresource_names               = list(string)
    pe_tags                         = map(string)
  }))
}

variable "sta_ip_rules" {
  description = "Specifies the Storage account ip rules"
  type = map(object({
    storage_account_name      = string
    default_action            = string
    ip_rules                  = list(string)
    subnet_name               = list(string)
    bypass                    = list(string)
  }))
}

#------------------------------------- Lifecycle Management of Storage Account-----------------------
variable "blob_types" {
  description = "specifies the blob type for the lifecycle management policy"
  type        = list(string)
}

variable "rule_enabled" {
   description = "specifies the rule enabled for the lifecycle management policy"
  type        = bool
}

variable "delete_after_days_since_modification_greater_than" {
  description = "The age in days after last modification to delete the blob. Must be at least 0."
  type        = number
}

variable "delete_after_days_since_creation_greater_than" {
  description = "The age in days after create to delete the snaphot. Must be at least 0."
  type        = number
}
#------------------------------------- Lifecycle Management of Storage Account-----------------------
variable "management_policies" {
  description = "Specifies the Management policies for Storage accounts"
  type = map(object({
    rule_name = string
    storage_account_name = string
  }))
}

#------------------------------ Customer Managed Key - Storage Account ------------------
variable "cmk_sta" {
  description = "Specifies Customer managed keys for storage accounts"
  type = map(object({
    sta_name = string
    kv_name  = string
    key_name = string
  }))
}

###################################  Commvault Configurations #############################################
###---------------------------Diagnostic settings Storage account --------------------------
variable "storage_accounts_diag" {
  description = "Specifies the disgnostic settings to the storage accounts"
  type = map(object({
    sta_name                         = string
    resource_group                   = string
    tags                             = map(string)
  }))
}
variable "access_tier_diag" {
  description = "Specifies the tier to use for the storage account. Valid options are Hot, Cool, Cold and Archive."
  type        = string
}
variable "delete_retention_days_01" {
  description = "Specifies the number of days that the container should be retained, between 1 and 365 days. Defaults to 7."
  type        = number
}

variable "sta_ip_rules_diag" {
  description = "Specifies the ip rules for the diagnostic settings storage account"
  type = map(object({
    storage_account_name      = string
    default_action            = string
    ip_rules                  = list(string)
    subnet_name               = list(string)
    bypass                    = list(string)
  }))
}
####--------------------------Diagnostic settings private endpoint -----------------------------
variable "pvt_endpoints_sta_diag" {
  description = "Specifies the private endpoints for the daignostic settings storage account"
  type = map(object({
    pe_name                         = string
    resource_group                  = string
    subnet_name                     = string
    sta_name                        = string
    is_manual_connection            = bool
    subresource_names               = list(string)
    pe_tags                         = map(string)
  }))
}

#------------------------------------- Lifecycle Management of Storage Account-----------------------

variable "management_policies_diag" {
  description = "Specifies the Management policies for dignostic settings Storage accounts"
  type = map(object({
    rule_name = string
    storage_account_name = string
  }))
}

# ##---------------------------------------Role Assignemnt-----------------------------------
variable "role_assign_sta_diag" {
  description = "The role assignment details include scope and role definition name"
  type = map(object({
    role_definition_name = string
    kv_name              = string
    sta_name             = string
  }))
}
#------------------------------ Customer Managed Key - Storage Account ------------------
variable "cmk_sta_diag" {
  description = "Specifies Customer managed keys for diagnostic settings storage accounts"
  type = map(object({
    sta_name = string
    kv_name  = string
    key_name = string
  }))
}

###--------------------------------- Network Interface ---------------------------------------
variable "cv_nics" {
  description = "Specifies the network interfaces to the CommVault VMs"
  type = map(object({
    nic_name        = string
    resource_group  = string
    subnet_name     = string
    ip_configs = list(object({
      ip_config_name = string
      private_ip_address_allocation = string
      primary = bool 
    }))
    tags = map(string)
  }))
}
variable "accelerated_networking_enabled" {
  type        = bool
  description = "Enable/Disable accelerated networking support on all Cloud Connector service interfaces"
}

#------------------------------------------ Disk Encryption Set ----------------------------
variable "cv_des" {
  description = "Specifies the disk encryption settings to the key vaults"
  type = map(object({
    des_name       = string
    resource_group = string
    kv_key_name    = string
    kv_name        = string
    tags           = map(string)
  }))
}
variable "role_definition_name" {
  type = string
  description = "The name of a built-in Role. Changing this forces a new resource to be created."
}

###------------------------------Disk access and Private endpoint--------------------------------------

variable "disk_access_vms" {
  description = "Specifies the disk access vms for commvault servers"
  type = map(object({
    disk_name         = string
    resource_group    = string
    tags              = map(string)
  }))
}
variable "pvt_endpoints_disk_access" {
  description = "Specifies the private endpoints for the disk access Commvault VMs"
  type = map(object({
    pe_name               = string
    disk_name             = string
    subnet_name           = string
    resource_group        = string
    is_manual_connection  = bool
    subresource_names     = list(string)
    pe_tags               = map(string)
  }))
}

# ####---------------------------------- Commvault Windows VM -------------------------------------
variable "cv_vms" {
  description = "Specifies the commvault virtual machines"
  type = map(object({
    cv_vm_names    = string
    resource_group = string
    nic_name       = string
    avset_name     = string
    des_name       = string
    sta_name       = string
    zone           = string
    tags           = map(string)
  }))
}

variable "cv_vm_instance_type" {
  type        = string
  description = "Cloud Connector Image size"
}

variable "admin_password" {
  type        = string
  description = "The Password which should be used for the local-administrator on this Virtual Machine. Changing this forces a new resource to be created."
}

variable "admin_username" {
  type        = string
  description = "Default Cloud Connector admin/root username"
}

variable "vtpm_enabled" {
  type        = bool
  description = "Specifies if vTPM (virtual Trusted Platform Module) and Trusted Launch is enabled for the Virtual Machine. Changing this forces a new resource to be created."
}

variable "secure_boot_enabled" {
  type        = bool
  description = "Specifies if Secure Boot and Trusted Launch is enabled for the Virtual Machine. Changing this forces a new resource to be created."
}
variable "vm_os_disk_name" {
  type        = string
  description = "The name of the VM OS Disk."
}

variable "license_type" {
  type        = string
  description = "Specifies the type of on-premise license (also known as Azure Hybrid Use Benefit) which should be used for this Virtual Machine. Possible values are None, Windows_Client and Windows_Server."
}

variable "disk_controller_type" {
  type        = string
  description = "Specifies the Disk Controller Type used for this Virtual Machine. Possible values are SCSI and NVMe."
}

variable "disk_storage_account_type" {
  type        = string
  description = "The Type of Storage Account which should back this the Internal OS Disk. Possible values are Standard_LRS, StandardSSD_LRS, Premium_LRS, StandardSSD_ZRS and Premium_ZRS. Changing this forces a new resource to be created."
}

variable "encryption_at_host_enabled" {
  type        = bool
  description = "User input for enabling or disabling host encryption"
}

variable "vm_extension_name" {
    description = "The name of the virtual machine extension peering. Changing this forces a new resource to be created."
    type        = string
}

variable "publisher" {
    description = "The publisher of the extension, available publishers can be found by using the Azure CLI. Changing this forces a new resource to be created."
    type        = string
}

variable "type" {
    description = "The type of extension, available types for a publisher can be found using the Azure CLI."
    type        = string
}

variable "type_handler_version" {
    description = "Specifies the version of the extension to use, available versions can be found using the Azure CLI."
    type        = string
}

variable "auto_upgrade_minor_version" {
    description = "Specifies if the platform deploys the latest minor version update to the type_handler_version specified."
    type        = bool
}
variable "identity_type" {
  description = "Specifies the identity type for the virtual machines"
  type = string
}
variable "identity_ids" {
  description = "Specifies the identity ids for the virtual machines"
  type = list(string)
  default = []
}
variable "vm_source_image_reference" {
  description = "Specifies the vm source image reference"
  type = list(object({
    vm_image_publisher = string
    vm_image_offer     = string
    vm_image_version   = string
    vm_image_sku       = string
  }))
}
variable "plan_details" {
  description = "Specifies the plan details to the virtual machines"
  type = list(object({
    publisher = string
    name      = string
    product   = string
  }))
}
# # ###------------------------------------Data Disk Attachment-----------------------------------------------------
variable "cv_data_disks" {
  description = "Specifies the data disks to the commvault servers"
  type = map(object({
    resource_group = string
    disk_size_gb   = number
    des_id         = string
    vm_name        = string
    disk_name      = string
    lun            = number
    tags           = map(string)
  }))
}

variable "data_disk_sa_type" {
  description = "Specifies the storage account type of additional data disk"
  type        = string
}

variable "data_disk_create_option" {
  description = "The method to use when creating the managed disk. Changing this forces a new resource to be created."
  type        = string
}

variable "data_disk_caching" {
  description = "Specifies the caching requirements for this Data Disk. Possible values include None, ReadOnly and ReadWrite."
  type        = string
}

variable "data_disk_write_accelerator" {
  description = "Boolean flag to notify whether write accelerator for data disk enabled."
  type        = bool
}
variable "public_network_access_enabled_disks" {
  description = "Whether it is allowed to access the disk via public network. Defaults to true."
  type = bool
}
variable "network_access_policy_data_disk" {
  type = string
  description = "Policy for accessing the disk via network. Allowed values are AllowAll, AllowPrivate, and DenyAll."
}
# ##---------------------------------------Role Assignemnt------------------------------------
variable "kv_role_definition_names" {
  type        = set(string)
  description = "The names of a built-in Role. Changing this forces a new resource to be created."
}
variable "role_definition_name_cv_vm" {
  type = string
  description = "The name of a built-in Role. Changing this forces a new resource to be created."
}
variable "role_definition_name_cv_vm_sta" {
  type = string
  description = "The name of a built-in Role. Changing this forces a new resource to be created."
}
### ------------------------------- Application Security Group Creation---------------------------
variable "cv_asgs" {
description = "Specifies the Application Security Groups of Commvault VMs"
  type = map(object({
    asg_name = string 
    resource_group = string
    asg_tags       = map(string)
  }))
}

### ------------------------------- Application Security Group - Network Interface Association ---------------------------
variable "cv_asgs_nic_association" {
description = "Specifies the Association of Application Security Groups and Network Interface of Commvault VMs"
  type = map(object({
    asg_name = string 
    nic_name = string
  }))
}