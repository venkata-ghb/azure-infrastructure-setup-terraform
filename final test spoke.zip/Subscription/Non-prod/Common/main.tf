###------------------------------------------- Resource Groups ---------------------------------------
module "rg" {
  providers = {
    azurerm = azurerm.current_sub
  }
  for_each            = var.resource_groups
  source              = "../../../Terraform_Modules/ResourceGroup"
  resource_group_name = "IS${var.shortlocation}${each.value.name}"
  location            = var.location
  tags                = var.rg_tags
}

module "rg_cv" {
  providers = {
    azurerm = azurerm.current_sub
  }
  for_each            = var.resource_groups_cv
  source              = "../../../Terraform_Modules/ResourceGroup"
  resource_group_name = "IS${var.shortlocation}${each.value.name}"
  location            = var.location
  tags                = var.cv_tags
}

#--------------------------------------------Ntw watcher Resource Groups ---------------------------------------

module "rg_ntw_watch" {
    providers = {
        azurerm = azurerm.current_sub
    }
        for_each            = var.rg_ntw_watch
        source              = "../../../Terraform_Modules/ResourceGroup"
        resource_group_name = each.value.name
        location            = var.location
        tags                = var.ntw_watch_tags 
}
#---------------------------------------Network Watcher----------------------------------------

module "network_watcher" {
  providers = {
        azurerm = azurerm.current_sub
    }
    for_each                    = var.network_watchers
    source                      = "../../../Terraform_Modules/NetworkWatcher"
    nwr_name                    = "${each.value.nwr_name}_${var.location}" 
    location                    = var.location
    resource_group_name         = module.rg_ntw_watch[each.value.resource_group].rg_name
    tags_NWR                    = var.ntw_watch_tags
    depends_on                  = [ module.rg_ntw_watch ]
} 
###----------------------------------------Virtual Network ---------------------------------------------
module "vnet" {
  providers = {
    azurerm = azurerm.current_sub
  }
  for_each                      = var.vnets
  source                        = "../../../Terraform_Modules/VirtualNetwork"
  vnt_name                      = "${var.shortlocation}-${each.value.vnet_name}"
  location                      = var.location
  resource_group_name           = module.rg[each.value.resource_group].rg_name
  vnt_address_space             = each.value.vnet_address_space
  dns_servers                   = each.value.dns_servers
  ddos_protection_plan_id       = data.azurerm_network_ddos_protection_plan.ddosp[0].id
  ddos_protection_plan_enabled  = var.ddos_protection_plan_enabled
  tags            	            = merge(var.rg_tags, each.value.vnet_tags)
  depends_on                    = [ module.rg, module.network_watcher ] 
}      

###-------------------------------------------- Subnets ---------------------------------------------
module "snet"{
  providers = {
    azurerm = azurerm.current_sub
  }
  for_each               = var.subnets
  source                 = "../../../Terraform_Modules/Subnet"
  snt_name               = each.value.snet_name == "GatewaySubnet" ? each.value.snet_name : "${var.shortlocation}-${each.value.snet_name}"
  resource_group_name    = module.rg[each.value.resource_group].rg_name
  vnt_name               = module.vnet[each.value.vnet_name].vnet_name
  address_space          = [cidrsubnet(module.vnet[each.value.vnet_name].first_vnet_address_space, each.value.newbits, each.value.netnum)] 
  service_endpoints      = each.value.service_endpoints != [] ? each.value.service_endpoints : null
  depends_on             = [ module.rg, module.vnet ] 
}

###----------------------------------------------Route table------------------------------------------
module "route_table" {
  providers = {
    azurerm = azurerm.current_sub
  }
  for_each                      = var.route_table_names
  source                        = "../../../Terraform_Modules/RouteTable"
  route_table_name              = "${var.shortlocation}-${each.value.name}"
  location                      = var.location
  resource_group_name           = module.rg[each.value.resource_group].rg_name
  bgp_route_propagation_enabled = var.bgp_route_propagation_enabled
  tags                          = merge(var.rg_tags,each.value.rt_tags)
  depends_on                    = [ module.rg ]
}

###------------------------Route table Association Subnet---------------------------------------

module "rt_association" {
  providers = {
    azurerm = azurerm.current_sub
  }
  for_each                  = var.RouteTableSubnetAssociations
  source                    = "../../../Terraform_Modules/RouteTableAssociateSubnet"
  route_table_name_id       = module.route_table[each.value.route_table_name].route_table_id
  subnet_id                 = module.snet[each.value.subnet_name].subnet_id
  depends_on                = [ module.route_table, module.snet ]
}

###------------------------Routes --------------------------------------------------------------

module "route" {
  providers = {
    azurerm = azurerm.current_sub
  }
  for_each               = local.routes
  source                 = "../../../Terraform_Modules/Routes"
  route_names            = "${var.shortlocation}-${each.value.name}" 
  resource_group_name    = module.rg[each.value.resource_group].rg_name
  route_table_name       = module.route_table[each.value.route_table_name].route_table_name
  route_address_prefix   = each.value.route_address_prefix
  next_hop_type          = each.value.next_hop_type
  next_hop_in_ip_address = each.value.next_hop_in_ip_address
  depends_on             = [ module.rg, module.route_table ]
}

###----------------------------------------------NSG---------------------------------------------

module "nsg"{
  providers = {
    azurerm = azurerm.current_sub
  }
  for_each            = var.nsgs
  source              = "../../../Terraform_Modules/NSG"
  nsg_name            = "${var.shortlocation}-NSG-${var.shortlocation}-${each.value.nsg_name}"
  resource_group_name = module.rg[each.value.resource_group].rg_name
  location            = var.location
  tags_NSG            = merge(var.rg_tags,each.value.nsg_tags)
  depends_on          = [ module.rg ]
}
###---------------------------------NSG Association Subnet------------------------------------------

module "nsg_subnet"{
  providers = {
    azurerm = azurerm.current_sub
  }
  for_each                        = var.nsgAssociationSubnet
  source                          = "../../../Terraform_Modules/NsgAssociateSubnet"
  sng_subnet_id                   = module.snet[each.value.subnet_name].subnet_id
  sng_network_security_group_id   = module.nsg[each.value.nsg_name].nsg_id
  depends_on                      = [ module.snet, module.nsg ]
}

###--------------------------------------------NSG Rules-------------------------------------------

module "nsg_rules" {
  providers = {
    azurerm = azurerm.current_sub
  }
  for_each                                    = local.nsg_rules
  source                                      = "../../../Terraform_Modules/NsgRule"
  nsr_name                                    = each.value.nsr_name
  nsr_resource_group_name                     = module.rg[each.value.resource_group].rg_name
  nsr_nsg_name                                = module.nsg[each.value.nsg].nsg_name
  nsr_protocol                                = each.value.nsr_protocol
  nsr_source_port_range                       = each.value.nsr_source_port_range
  nsr_source_port_ranges                      = each.value.nsr_source_port_ranges
  nsr_destination_port_range                  = each.value.nsr_destination_port_range
  nsr_destination_port_ranges                 = each.value.nsr_destination_port_ranges
  nsr_source_address_prefix                   = each.value.nsr_source_address_prefix
  nsr_source_address_prefixes                 = each.value.nsr_source_address_prefixes
  nsr_destination_address_prefix              = each.value.nsr_destination_address_prefix
  nsr_destination_address_prefixes            = each.value.nsr_destination_address_prefixes
  nsr_source_application_security_group_ids   = each.value.nsr_source_application_security_group_ids
  nsr_priority                                = each.value.nsr_priority
  nsr_direction                               = each.value.nsr_direction
  nsr_access                                  = each.value.nsr_access
  depends_on                                  = [ module.rg, module.nsg, module.cv_asg ]
}

#------------------------------ Azure Virtual Network Manager-------------------------
module "avnm_static_member" {
  for_each                  = var.static_members  
  source                    = "../../../Terraform_Modules/AVNMStaticMemberAzapi"
  avnm_static_member_name   = each.value.avnm_static_member_name
  parent_id       = data.azurerm_network_manager_network_group.avnm_ntw_group.id
  vnet_id         = module.vnet[each.value.vnet_name].vnet_id
  depends_on      = [ module.vnet ]
}

module "avnm_rule" {
    for_each        = var.avnm_rules
    source          = "../../../Terraform_Modules/AVNMRulesAzapi"
    avnm_rule_name  = "${var.shortlocation}-${each.value.avnm_rule_name}"
    parent_id       = data.azapi_resource.avnm_rule_collection.id
    destinationAddress = module.vnet[each.value.vnet_name].first_vnet_address_space 
    type            = each.value.type
    nextHopAddress  = local.avnm_rule_next_hop_address
    nextHopType     = each.value.nextHopType
    depends_on      = [ module.vnet ]
}

###----------------------------------------- Vnet Flow logs ----------------------------------------
module "flow_log_vnet" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each              = var.vnets
  source                = "../../../Terraform_Modules/VNetFlowLogs"
  network_watcher_name  = values(module.network_watcher)[0].network_watcher_name
  resource_group_name   = values(module.rg_ntw_watch)[0].rg_name
  flow_log_name         = "${module.vnet[each.key].vnet_name}-${lower(module.vnet[each.key].vnet_rg_name)}-flowlog"
  vnet_id               = module.vnet[each.key].vnet_id
  sta_id                = local.sta_id
  enabled               = var.enabled
  flow_log_version      = var.flow_log_version
  retention_days        = var.retention_days
  traffic_analytics_enabled   = var.traffic_analytics_enabled
  workspace_id          = local.workspace.workspace_id
  workspace_location    = local.workspace.location
  workspace_resource_id = local.workspace.id
  interval_in_minutes   = var.interval_in_minutes
  tags                  = merge(var.ntw_watch_tags, each.value.vnet_tags)
  depends_on            = [ module.rg_ntw_watch, module.network_watcher, module.vnet ]
}

#------------------------------------ Key vault Creation ---------------------------------
module "keyvault" {
  providers = {
    azurerm = azurerm.current_sub
  }    
  for_each        = var.keyvault
  source          = "../../../Terraform_Modules/KeyVault"
  key_vault_name                  = "is-${lower(var.shortlocation)}-${each.value.key_vault_name}" 
  location                           = var.location
  resource_group_name                = module.rg[each.value.resource_group_name].rg_name
  tenant_id                          = data.azurerm_client_config.current.tenant_id 
  kv_sku_name                        = var.kv_sku_name
  kv_purge_protection_enabled        = var.kv_purge_protection_enabled
  kv_soft_delete_retention_days      = var.kv_soft_delete_retention_days
  kv_enable_rbac_authorization       = var.kv_enable_rbac_authorization
  kv_enabled_for_disk_encryption     = var.kv_enabled_for_disk_encryption
  kv_enabled_for_template_deployment = var.kv_enabled_for_template_deployment
  kv_enabled_for_deployment          = var.kv_enabled_for_deployment
  kv_public_network_access_enabled   = var.kv_public_network_access_enabled
  bypass                             = var.kv_bypass
  default_action                     = var.kv_default_action
  ip_rules                           = var.kv_ip_rules
  virtual_network_subnet_ids         = concat(values(module.snet)[*].subnet_id, [data.azurerm_subnet.swc_iac_subnet.id])
  tags                               = merge(var.rg_tags, each.value.tags) 
  depends_on                         = [ module.rg, module.snet ]    
}

###-----------------------------------Private Endpoint-----------------------------------------------

module "pvtendpoint"{
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each                              = var.pvt_endpoints
  source                                = "../../../Terraform_Modules/PrivateEndpoint"
  location                              = var.location
  pe_name                               = "IS${var.shortlocation}-${each.value.pe_name}"
  resource_group_name                   = module.rg[each.value.resource_group].rg_name
  subnet_id                             = module.snet[each.value.subnet_name].subnet_id
  custom_network_interface_name         = "IS${var.shortlocation}-${each.value.pe_name}-nic"
  is_manual_connection                  = each.value.is_manual_connection
  private_service_connection_name       = "IS${var.shortlocation}-${each.value.pe_name}-Connection"
  private_connection_resource_id        = module.keyvault[each.value.key_vault_name].kv_id
  subresource_names                     = each.value.subresource_names
  private_dns_zone_ids                  = ["/subscriptions/${var.private_dns_zone_subscription_id}/resourceGroups/IS${var.dns_shortlocation}${var.private_dns_zone_rgName}/providers/Microsoft.Network/privateDnsZones/${var.kv_dns_zone_name}"]
  tags                                  = merge(var.rg_tags, each.value.pe_tags)
  depends_on                            = [ module.rg, module.snet, module.keyvault ]
}

#---------------------------------Key Vault Key -------------------------------
module "keyvault_key"{
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each        = var.keyvault_key
  source          = "../../../Terraform_Modules/KeyVaultKey"
  kv_key_name     = each.value.kv_key_name
  key_vault_id    = module.keyvault[each.value.kv_name].kv_id
  kv_key_type     = var.kv_key_type
  kv_key_opts     = var.kv_key_opts
  kv_key_size     = var.kv_key_size
  expiration_date = var.expiration_date
  tags            = merge( var.rg_tags, each.value.kvk_tags )
  depends_on      = [ module.keyvault, module.role_assign ]
 }

###---------------------------------------Role Assignemnt------------------------------------
module "role_assign" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each        = var.role_assign_kv
  source          = "../../../Terraform_Modules/RoleAssignment"
  scope           = "/subscriptions/${var.subscription_id}"
  principal_id    = data.azurerm_client_config.current.object_id
  role_definition_name = each.value.role_definition_name
}

####--------------------------------------Diagnostic settings-----------------------------
module "diagnostic_settings_kv" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each                = var.keyvault
  source                  = "../../../Terraform_Modules/DiagnosticsSettings" 
  dlog_name               = "is-${lower(var.shortlocation)}-${each.value.dlog_name}-diag"
  target_id               = module.keyvault[each.key].kv_id
  enable_logs             = var.enable_logs
  enabled_metric         = var.enabled_metric
  storage_acc_id          = values(module.storage_account)[0].stgaccount_id
  workspace_rs_id         = var.workspace_rs_id
  depends_on = [ module.keyvault, module.storage_account ]
}

#------------------------------------Storage Account -----------------------------------------
module "storage_account" {
  
  providers = {
      azurerm = azurerm.current_sub
    }
    for_each                          = var.storage_accounts
    source                            = "../../../Terraform_Modules/StorageAccount"
    resource_group_name               = module.rg_cv[each.value.resource_group].rg_name
    location                          = var.location
    name                 	            = "abbis${lower(var.shortlocation)}${each.value.sta_name}"
    account_tier                      = var.account_tier
    access_tier                       = var.access_tier
    account_replication_type          = var.account_replication_type
    allow_blob_public_access          = var.allow_blob_public_access
    public_network_access_enabled     = var.public_network_access_enabled
    infrastructure_encryption_enabled = var.infrastructure_encryption_enabled
    shared_access_key_enabled         = var.shared_access_key_enabled
    cross_tenant_replication_enabled  = var.cross_tenant_replication_enabled
    versioning_enabled                = var.versioning_enabled
    delete_retention_days             = var.delete_retention_days
    is_hns_enabled                    = var.is_hns_enabled
    tags 					                    = merge(var.cv_tags, each.value.tags)
    container_delete_retention_days   = var.container_delete_retention_days
    large_file_share_enabled          = var.large_file_share_enabled
    min_tls_version                   = var.min_tls_version
    depends_on                        = [module.rg_cv, module.snet]
}

###-----------------------------------Private Endpoint - Storage Account-----------------------------------------------

module "pvtendpoint_sta"{
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each                              = var.pvt_endpoints_sta
  source                                = "../../../Terraform_Modules/PrivateEndpoint"
  location                              = var.location
  pe_name                               = "IS${var.shortlocation}-${each.value.pe_name}"
  resource_group_name                   = module.rg_cv[each.value.resource_group].rg_name
  subnet_id                             = module.snet[each.value.subnet_name].subnet_id
  custom_network_interface_name         = "IS${var.shortlocation}-${each.value.pe_name}-nic"
  is_manual_connection                  = each.value.is_manual_connection
  private_service_connection_name       = "IS${var.shortlocation}-${each.value.pe_name}-Connection"
  private_connection_resource_id        = module.storage_account[each.value.sta_name].stgaccount_id
  subresource_names                     = each.value.subresource_names
  private_dns_zone_ids                  = ["/subscriptions/${var.private_dns_zone_subscription_id}/resourceGroups/IS${var.dns_shortlocation}${var.private_dns_zone_rgName}/providers/Microsoft.Network/privateDnsZones/${var.sta_dns_zone_name}"]
  tags                                  = merge(var.cv_tags, each.value.pe_tags)
  depends_on                            = [ module.rg_cv, module.snet, module.storage_account]
}

#----------------------------------Storage Account Network rules--------------------------------
module "sta_ip_rules" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each                    = var.sta_ip_rules
  source                      = "../../../Terraform_Modules/StaNetworkRules"
  sta_id                      = module.storage_account[each.value.storage_account_name].stgaccount_id
  default_action              = each.value.default_action
  ip_rules                    = each.value.ip_rules
  virtual_network_subnet_ids  = [ for subnet_key in each.value.subnet_name : module.snet[subnet_key].subnet_id]
  bypass                      = each.value.bypass
  depends_on                  = [ module.storage_account, module.snet]
}

####------------------------------------- Lifecycle Management of Storage Account-----------------------
module "management_policy" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each              = var.management_policies
  source                = "../../../Terraform_Modules/LifecycleManagementPolicy"
  rule_name             = "LCM-xc${lower(var.shortlocation)}${each.value.rule_name}"
  rule_name_01          = "xc${lower(var.shortlocation)}${each.value.rule_name}-Snap-LC01"
  rule_enabled          = var.rule_enabled
  storage_account_id    = module.storage_account[each.value.storage_account_name].stgaccount_id
  blob_types            = var.blob_types
  delete_after_days_since_modification_greater_than = var.delete_after_days_since_modification_greater_than
  delete_after_days_since_creation_greater_than = var.delete_after_days_since_creation_greater_than 
  depends_on            = [ module.storage_account, module.keyvault_key ]
}

###---------------------------------------Role Assignment------------------------------------
module "role_assign_sta" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each        = var.role_assign_sta
  source          = "../../../Terraform_Modules/RoleAssignment"
  scope           = module.keyvault[each.value.kv_name].kv_id
  principal_id    = module.storage_account[each.value.sta_name].principal_id
  role_definition_name = each.value.role_definition_name
}

##------------------------------------- Customer Managed Key - Storage Account ------------------

module "cmk_sta" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each           = var.cmk_sta
  source             = "../../../Terraform_Modules/CustomerManagedKey"
  storage_account_id = module.storage_account[each.value.sta_name].stgaccount_id
  key_vault_id       = module.keyvault[each.value.kv_name].kv_id
  key_vault_key_name = each.value.key_name
  depends_on      = [ module.storage_account, module.keyvault, module.keyvault_key, module.role_assign_sta ]
}

##-------------------------------------- Commvault VM ----------------------------------------------
##------------------------------------Diagnostic settings-Storage Account -----------------------------------------
module "storage_account_diag" {
  
  providers = {
      azurerm = azurerm.current_sub
    }
    for_each                          = var.storage_accounts_diag
    source                            = "../../../Terraform_Modules/StorageAccount"
    resource_group_name               = module.rg[each.value.resource_group].rg_name
    location                          = var.location
    name                 	            = "abbis${lower(var.shortlocation)}${each.value.sta_name}"
    account_tier                      = var.account_tier
    access_tier                       = var.access_tier_diag
    account_replication_type          = var.account_replication_type
    allow_blob_public_access          = var.allow_blob_public_access
    public_network_access_enabled     = var.public_network_access_enabled
    infrastructure_encryption_enabled = var.infrastructure_encryption_enabled
    shared_access_key_enabled         = var.shared_access_key_enabled
    cross_tenant_replication_enabled  = var.cross_tenant_replication_enabled
    versioning_enabled                = var.versioning_enabled
    delete_retention_days             = var.delete_retention_days_01
    is_hns_enabled                    = var.is_hns_enabled
    tags 					                    = merge(var.rg_tags, each.value.tags)
    container_delete_retention_days   = var.container_delete_retention_days
    large_file_share_enabled          = var.large_file_share_enabled
    min_tls_version                   = var.min_tls_version
    depends_on                        = [module.rg, module.snet]
}

###-----------------------------------Diagnostic settings - Private Endpoint - Storage Account-----------------------------------------------

module "pvtendpoint_sta_diag"{
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each                              = var.pvt_endpoints_sta_diag
  source                                = "../../../Terraform_Modules/PrivateEndpoint"
  location                              = var.location
  pe_name                               = "IS${var.shortlocation}-${each.value.pe_name}"
  resource_group_name                   = module.rg[each.value.resource_group].rg_name
  subnet_id                             = module.snet[each.value.subnet_name].subnet_id
  custom_network_interface_name         = "IS${var.shortlocation}-${each.value.pe_name}-nic"
  is_manual_connection                  = each.value.is_manual_connection
  private_service_connection_name       = "IS${var.shortlocation}-${each.value.pe_name}-Connection"
  private_connection_resource_id        = module.storage_account_diag[each.value.sta_name].stgaccount_id
  subresource_names                     = each.value.subresource_names
  private_dns_zone_ids                  = ["/subscriptions/${var.private_dns_zone_subscription_id}/resourceGroups/IS${var.dns_shortlocation}${var.private_dns_zone_rgName}/providers/Microsoft.Network/privateDnsZones/${var.sta_dns_zone_name}"]
  tags                                  = merge(var.rg_tags, each.value.pe_tags)
  depends_on                            = [ module.rg, module.snet, module.storage_account_diag]
}

#----------------------------------Diagnostic Storage Account Network rules--------------------------------
module "sta_ip_rules_diag" {
    providers = {
      azurerm = azurerm.current_sub
    }
  for_each                    = var.sta_ip_rules_diag
  source                      = "../../../Terraform_Modules/StaNetworkRules"
  sta_id                      = module.storage_account_diag[each.value.storage_account_name].stgaccount_id
  default_action              = each.value.default_action
  ip_rules                    = each.value.ip_rules
  virtual_network_subnet_ids  = [ for subnet_key in each.value.subnet_name : module.snet[subnet_key].subnet_id]
  bypass                      = each.value.bypass
  depends_on                  = [ module.storage_account_diag, module.snet]
}

####------------------------------------- Lifecycle Management of Storage Account-----------------------
module "management_policy_diag" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each              = var.management_policies_diag
  source                = "../../../Terraform_Modules/LifecycleManagementPolicyV2"
  rule_name             = "LCM-xc${lower(var.shortlocation)}${each.value.rule_name}"
  rule_enabled          = var.rule_enabled
  storage_account_id    = module.storage_account_diag[each.value.storage_account_name].stgaccount_id
  blob_types            = var.blob_types
  delete_after_days_since_modification_greater_than = var.delete_after_days_since_modification_greater_than
  depends_on            = [ module.storage_account_diag, module.keyvault_key ]
}

###---------------------------------------Role Assignment------------------------------------
module "role_assign_sta_diag" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each        = var.role_assign_sta_diag
  source          = "../../../Terraform_Modules/RoleAssignment"
  scope           = module.keyvault[each.value.kv_name].kv_id
  principal_id    = module.storage_account_diag[each.value.sta_name].principal_id
  role_definition_name = each.value.role_definition_name
}

##------------------------------------- Customer Managed Key - Storage Account ------------------

module "cmk_sta_diag" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each           = var.cmk_sta_diag
  source             = "../../../Terraform_Modules/CustomerManagedKey"
  storage_account_id = module.storage_account_diag[each.value.sta_name].stgaccount_id
  key_vault_id       = module.keyvault[each.value.kv_name].kv_id
  key_vault_key_name = each.value.key_name
  depends_on      = [ module.storage_account_diag, module.keyvault, module.keyvault_key, module.role_assign_sta_diag ]
}

#--------------------------------------- Disk Encryption Set ---------------------------------
module "des_cv" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each              = var.cv_des
  source                = "../../../Terraform_Modules/DiskEncryptionSet"
  disk_encryption_set_name  = "IS${var.shortlocation}${each.value.des_name}-${var.shortlocation}-des-01"
  resource_group_name       = module.rg[each.value.resource_group].rg_name
  location                  = var.location
  key_vault_key_id          = module.keyvault_key[each.value.kv_key_name].kvk_id
  role_definition_name      = var.role_definition_name
  key_vault_id              = module.keyvault[each.value.kv_name].kv_id 
  tags                      = merge(var.rg_tags, each.value.tags)
  depends_on                = [ module.keyvault_key, module.rg, module.keyvault ]
}

###------------------------------------ Network Interface --------------------------------------

module "nic_cv" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each            = var.cv_nics
  source              = "../../../Terraform_Modules/NetworkInterface"
  nic_name            = "XC-S-${each.value.nic_name}-nic01"  
  location            = var.location
  resource_group_name = module.rg_cv[each.value.resource_group].rg_name
  ip_configs          = each.value.ip_configs
  subnet_id           = module.snet[each.value.subnet_name].subnet_id
  accelerated_networking_enabled   = var.accelerated_networking_enabled
  tags                = merge(var.cv_tags, each.value.tags)
  depends_on          = [ module.rg_cv, module.snet ]
}
###------------------------------Disk access and Private endpoint--------------------------------------

module "disk_access" {
   providers = {
      azurerm = azurerm.current_sub
    }
    for_each                      = var.disk_access_vms
    source                        = "../../../Terraform_Modules/DiskAccess"  
    location                      = var.location
    disk_name                     = each.value.disk_name
    resource_group_name           = module.rg_cv[each.value.resource_group].rg_name
    tags                          = merge(var.cv_tags, each.value.tags)
    depends_on                    = [ module.rg_cv ]
}

module "pvtendpoint_disk"{
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each                              = var.pvt_endpoints_disk_access
  source                                = "../../../Terraform_Modules/PrivateEndpoint"
  location                              = var.location
  pe_name                               = "${module.disk_access[each.value.disk_name].disk_name}-${each.value.pe_name}"
  resource_group_name                   = module.rg_cv[each.value.resource_group].rg_name
  subnet_id                             = module.snet[each.value.subnet_name].subnet_id
  custom_network_interface_name         = "${module.disk_access[each.value.disk_name].disk_name}-${each.value.pe_name}-nic"
  is_manual_connection                  = each.value.is_manual_connection
  private_service_connection_name       = "${module.disk_access[each.value.disk_name].disk_name}-${each.value.pe_name}-Connection"
  private_connection_resource_id        = module.disk_access[each.value.disk_name].disk_id
  subresource_names                     = each.value.subresource_names
  private_dns_zone_ids                  = ["/subscriptions/${var.private_dns_zone_subscription_id}/resourceGroups/IS${var.dns_shortlocation}${var.private_dns_zone_rgName}/providers/Microsoft.Network/privateDnsZones/${var.sta_dns_zone_name}"]
  tags                                  = merge(var.cv_tags, each.value.pe_tags)
  depends_on                            = [ module.rg_cv, module.snet, module.disk_access]
}
###------------------------------------------ Windows VM ------------------------------------------
module "winvm_cv" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each                  = var.cv_vms
  source                     = "../../../Terraform_Modules/WindowsVirtualMachine"
  vm_name                    = "XC-S-${each.value.cv_vm_names}"
  location                   = var.location
  resource_group_name        = module.rg_cv[each.value.resource_group].rg_name
  vm_instance_type           = var.cv_vm_instance_type
  admin_username             = var.admin_username
  admin_password             = var.admin_password
  zone                       = each.value.zone
  encryption_at_host_enabled = var.encryption_at_host_enabled
  network_interface_ids      = module.nic_cv[each.value.nic_name].nic_ids
  availability_set_id        = each.value.avset_name
  secure_boot_enabled        = var.secure_boot_enabled 
  vtpm_enabled               = var.vtpm_enabled 
  license_type               = var.license_type
  disk_controller_type       = var.disk_controller_type  
  vm_os_disk_name            = var.vm_os_disk_name 
  disk_storage_account_type  = var.disk_storage_account_type
  disk_encryption_set_id    = module.des_cv[each.value.des_name].des_id
  vm_source_image_id        = data.azurerm_shared_image_version.golden_win_image.id
  vm_source_image_reference = var.vm_source_image_reference
  plan_details              = var.plan_details
  storage_account_uri       = module.storage_account_diag[each.value.sta_name].stgaccount_primary_blob_endpoint
  tags                      = merge(var.cv_tags, each.value.tags)
  vm_extension_name          = var.vm_extension_name
  publisher                  = var.publisher
  type                       = var.type
  type_handler_version       = var.type_handler_version
  identity_ids               = var.identity_ids
  identity_type              = var.identity_type
  auto_upgrade_minor_version = var.auto_upgrade_minor_version
  depends_on       = [ module.rg_cv, module.nic_cv, module.storage_account_diag, module.des_cv]
}

##----------------------------------- Data Disk Attachment --------------------------------------

module "winvm_data_disks_cv" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each                       = var.cv_data_disks
  source                         = "../../../Terraform_Modules/DataDiskAttach"
  disk_name                      = "${module.winvm_cv[each.value.vm_name].vm_name}-datadisk${format("%02d", each.value.lun +1)}"
  location                       = var.location 
  resource_group_name            = module.rg_cv[each.value.resource_group].rg_name 
  data_disk_sa_type              = var.data_disk_sa_type
  data_disk_create_option        = var.data_disk_create_option
  disk_size_gb                   = each.value.disk_size_gb
  public_network_access_enabled  = var.public_network_access_enabled_disks
  network_access_policy          = var.network_access_policy_data_disk
  disk_access_id                 = module.disk_access[each.value.disk_name].disk_id
  disk_encryption_set_id         = module.des_cv[each.value.des_id].des_id
  zone                           = module.winvm_cv[each.value.vm_name].vm_zone
  tags                           = merge(var.cv_tags, each.value.tags)
  vm_id                          = module.winvm_cv[each.value.vm_name].vm_id
  data_disk_caching              = var.data_disk_caching
  lun                            = each.value.lun
  data_disk_write_accelerator    = var.data_disk_write_accelerator
  depends_on                     = [ module.rg_cv, module.des_cv, module.winvm_cv, module.disk_access ]
}

##------------------------------- KeyVault - Role Assignment----------------------------------------------

module "role_assign_kv" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each             = var.kv_role_definition_names
  source               = "../../../Terraform_Modules/RoleAssignment"
  scope                = "/subscriptions/${var.subscription_id}"
  principal_id         = data.azurerm_client_config.current.object_id
  role_definition_name = each.key
}

###---------------------------------------Role Assignemnt------------------------------------
module "role_assign_cv_vm" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each             = var.cv_vms
  source               = "../../../Terraform_Modules/RoleAssignment"
  scope                = "/subscriptions/${var.subscription_id}"
  principal_id         = module.winvm_cv[each.key].vm_principal_id
  role_definition_name = var.role_definition_name_cv_vm
  depends_on           = [ module.winvm_cv ]
}

module "role_assign_cv_vm_sta" {
  providers = {
      azurerm = azurerm.current_sub
    }
  for_each             = var.cv_vms
  source               = "../../../Terraform_Modules/RoleAssignment"
  scope                = "/subscriptions/${var.subscription_id}"
  principal_id         = module.winvm_cv[each.key].vm_principal_id
  role_definition_name = var.role_definition_name_cv_vm_sta
  depends_on           = [ module.winvm_cv ]
}

### ------------------------------- Application Security Group Creation --------------------------
module "cv_asg"{
  providers = {
    azurerm = azurerm.current_sub
  }
  for_each            = var.cv_asgs
  source              = "../../../Terraform_Modules/ApplicationSecurityGroup"
  asg_name            = "${var.shortlocation}-ASG-${each.value.asg_name}-VM01"
  resource_group_name = module.rg[each.value.resource_group].rg_name
  location            = var.location
  tags                = merge(var.rg_tags,each.value.asg_tags)
  depends_on          = [ module.rg ]
}

### ------------------------------- Application Security Group - Network Interface Association ---------------------------
module "cv_asg_nic_association"{
  providers = {
    azurerm = azurerm.current_sub
  }
  for_each         = var.cv_asgs_nic_association
  source           = "../../../Terraform_Modules/ASGNetworkInterfaceAssociation"
  nic_id           = module.nic_cv[each.value.nic_name].nic_id
  asg_id           = module.cv_asg[each.value.asg_name].asg_id
  depends_on       = [ module.nic_cv, module.cv_asg ]
}