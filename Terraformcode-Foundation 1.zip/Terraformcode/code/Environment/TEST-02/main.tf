terraform {
  required_version = "0.13.5"
}

# ---------------------------------------- resource group for SAP-TEST --------------------------------------#
module "rg_module_sap_test_01" {
  source= "../../module/rg_creation"
  resourcegrp_name=var.sap_test_rg_01_name
  location=var.location
  tags=var.tags
}
module "rg_module_sap_test_02" {
  source= "../../module/rg_creation"
  resourcegrp_name=var.sap_test_rg_01_name01
  location=var.location
  tags=var.tags_mgmt
}
module "rg_module_sn_sap_test_3" {
  source= "../../module/rg_creation"
  resourcegrp_name=var.resource_group_name03
  location=var.location
  tags=var.tags_recovery_services
}
module "rg_module_sn_sap_test_4" {
  source= "../../module/rg_creation"  
  resourcegrp_name=var.resource_group_name04
  location=var.location
  tags=var.tags_app
}
# ......................storage account................................
module "storageaccount_module_sap_test_01" {
  source = "../../module/storageaccount_creation"
  storageaccountname=var.storageaccountname01
  location=module.rg_module_sap_test_02.rg_location
  resourcegrp_name=module.rg_module_sap_test_02.rg_name
  storage_account_type=var.strg_acc_type01
  account_kind=var.acc_kind01 
  access_tier=var.access_tier01
  tags=var.tags_mgmt
}
# ---------------------------------------- virtual network for SAP-TEST -------------------------------------#
module "vnet_module_sap_test_01" {
  source= "../../module/vnet_creation"
  resourcegrp_name=module.rg_module_sap_test_01.rg_name
  vnet_name=var.sap_test_vnet_01_name
  vnet_address_prefix=var.sap_test_vnet_01_address_space
  location=module.rg_module_sap_test_01.rg_location
  tags_vnet=var.tags
  depends_on=[module.rg_module_sap_test_01]
   address_dnsservers=var.dnsservers01
}
# ...............existingvnet..................................
module "existingvnetsnhubvnet01" {
  providers={
    azurerm=azurerm.sn_hub
  }
source = "../../module/existing_vnet"
  existingvnet=var.existingvnetsnhubvnet01
  rg_name=var.existingresourcegroupsn_hubvnet01
  
}
module "existingvnetsnhubvnet02" {
  providers={
    azurerm=azurerm.sn_hub
  }
source = "../../module/existing_vnet"
  existingvnet=var.existingvnetsnhubvnet02
  rg_name=var.existingresourcegroupsn_hubvnet01
  
}
module "existingvnetsapprodvnet03" {
  providers={
    azurerm=azurerm.sapprod
  }
source = "../../module/existing_vnet"
  existingvnet=var.existingvnetsapprodvnet03
  rg_name=var.existingresourcegroupsnsapprodvnet03
}
module "existingvnetwesaptestvnet01" {
  providers={
    azurerm=azurerm.we_saptest
  }
source = "../../module/existing_vnet"
  existingvnet=var.existingvnetwesaptestvnet01
  rg_name=var.existingresourcegroupwesaptestvnet01
}
# .........cross region peering..............
module "sn_sap_test_crossregion_vnet_peering_module1" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.sn_sap_test_cross_vnet_peering_name_01
  resourcegrp_name=module.rg_module_sap_test_01.rg_name
  vnet_name=module.vnet_module_sap_test_01.vnet_name
  vnet_remote_id=module.existingvnetwesaptestvnet01.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_10
  use_remote_gateways=var.use_remote_gateways_10
}
#........................ vnetpeeing...................
#sap test to vnet01
 module "sn_sap_test_vnet_peering_module1" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.sn_sap_test_vnet_peering_name_01
  resourcegrp_name=module.rg_module_sap_test_01.rg_name
  vnet_name=module.vnet_module_sap_test_01.vnet_name
  vnet_remote_id=module.existingvnetsnhubvnet01.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_01
  use_remote_gateways=var.use_remote_gateways_01
}
# sap test to vnet02
module "sn_sap_test_vnet_peering_module2" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.sn_sap_test_vnet_peering_name_02
  resourcegrp_name=module.rg_module_sap_test_01.rg_name
  vnet_name=module.vnet_module_sap_test_01.vnet_name
  vnet_remote_id=module.existingvnetsnhubvnet02.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_02
  use_remote_gateways=var.use_remote_gateways_02
}
# sap test to sap prod
module "sn_sap_test_vnet_peering_module3" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.sn_sap_test_vnet_peering_name_03
  resourcegrp_name=module.rg_module_sap_test_01.rg_name
  vnet_name=module.vnet_module_sap_test_01.vnet_name
  vnet_remote_id=module.existingvnetsapprodvnet03.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_03
  use_remote_gateways=var.use_remote_gateways_03
}

# -------------------------------------------- subnet for SAP-TEST ------------------------------------------#
module "subnet_module_sap_test_int" {
  source= "../../module/subnet_creation"
  resourcegrp_name=module.rg_module_sap_test_01.rg_name
  subnet_name=var.sap_test_subnet_int_name
  vnet_name=module.vnet_module_sap_test_01.vnet_name
  address_space=var.sap_test_subnet_int_address_space
  depends_on=[module.rg_module_sap_test_01,module.vnet_module_sap_test_01]
}

module "subnet_module_sap_test_edmz" {
  source= "../../module/subnet_creation"
  resourcegrp_name=module.rg_module_sap_test_01.rg_name
  subnet_name=var.sap_test_subnet_edmz_name
  vnet_name=module.vnet_module_sap_test_01.vnet_name
  address_space=var.sap_test_subnet_edmz_address_space
  depends_on=[module.rg_module_sap_test_01,module.vnet_module_sap_test_01]  
}

module "subnet_module_sap_test_idmz" {
  source= "../../module/subnet_creation"
  resourcegrp_name=module.rg_module_sap_test_01.rg_name
  subnet_name=var.sap_test_subnet_idmz_name
  vnet_name=module.vnet_module_sap_test_01.vnet_name
  address_space=var.sap_test_subnet_idmz_address_space
  depends_on=[module.rg_module_sap_test_01,module.vnet_module_sap_test_01]   
}

# --------------------------------------------- NSG for SAP-TEST ---------------------------------------------#
#NSG for SAP-test-INT
module "nsg_module_sap_test_int" {
  source= "../../module/nsg_creation"
  resourcegrp_name=module.rg_module_sap_test_01.rg_name
  location=module.rg_module_sap_test_01.rg_location
  nsg_name=var.sap_test_subnet_int_nsg_name
  tags_nsg=var.tags
  depends_on=[module.rg_module_sap_test_01] 
}

#NSG for SAP-test-EDMZ
module "nsg_module_sap_test_edmz" {
  source= "../../module/nsg_creation"
  resourcegrp_name=module.rg_module_sap_test_01.rg_name
  location=module.rg_module_sap_test_01.rg_location
  nsg_name=var.sap_test_subnet_edmz_nsg_name
  tags_nsg=var.tags
  depends_on=[module.rg_module_sap_test_01] 
}

#NSG for SAP-test-IDMZ
module "nsg_module_sap_test_idmz" {
  source= "../../module/nsg_creation"
  resourcegrp_name=module.rg_module_sap_test_01.rg_name
  location=module.rg_module_sap_test_01.rg_location
  nsg_name=var.sap_test_subnet_idmz_nsg_name
  tags_nsg=var.tags
  depends_on=[module.rg_module_sap_test_01]  
}

#--------------------------------------- NSG association for SAP-TEST ----------------------------------------#
# NSG association to SAP-test-INT subnet
module "nsgToSubnet_module_sap_test_int" {
  source="../../module/nsg_subnet_association"
  subnet_id=module.subnet_module_sap_test_int.subnet_id
  nsg_id=module.nsg_module_sap_test_int.nsg_id 
  depends_on=[module.subnet_module_sap_test_int,module.nsg_module_sap_test_int]
}

# # NSG association to SAP-test-EDMZ subnet
module "nsgToSubnet_module_sap_test_edmz" {
  source="../../module/nsg_subnet_association"
  subnet_id=module.subnet_module_sap_test_edmz.subnet_id
  nsg_id=module.nsg_module_sap_test_edmz.nsg_id 
  depends_on=[module.subnet_module_sap_test_edmz,module.nsg_module_sap_test_edmz]
}

# # NSG association to SAP-test-IDMZ subnet
module "nsgToSubnet_module_sap_test_idmz" {
  source="../../module/nsg_subnet_association"
  subnet_id=module.subnet_module_sap_test_idmz.subnet_id
  nsg_id=module.nsg_module_sap_test_idmz.nsg_id 
  depends_on=[module.subnet_module_sap_test_idmz,module.nsg_module_sap_test_idmz]
}

#--------------------------------------routable creation for SAP-TEST ----------------------------------------#
# Route table SAP-test-INT
module "routeTable_module_sap_test_int" {
  source="../../module/route_table_creation"
  route_table_name=var.sap_test_routeTableName_int
  location=module.rg_module_sap_test_01.rg_location
  resource_group_name=module.rg_module_sap_test_01.rg_name
  bgp_route_propagation=var.bgp_route_propagations
  route_tags=var.tags
  depends_on=[module.rg_module_sap_test_01]
}

# Route table SAP-test-EDMZ
module "routeTable_module_sap_test_edmz" {
  source="../../module/route_table_creation"
  route_table_name=var.sap_test_routeTableName_edmz
  location=module.rg_module_sap_test_01.rg_location
  resource_group_name=module.rg_module_sap_test_01.rg_name
  bgp_route_propagation=var.bgp_route_propagations
  route_tags=var.tags
  depends_on=[module.rg_module_sap_test_01]
}

# Route table SAP-test-IDMZ
module "routeTable_module_sap_test_idmz" {
  source="../../module/route_table_creation"
  route_table_name=var.sap_test_routeTableName_idmz
  location=module.rg_module_sap_test_01.rg_location
  resource_group_name=module.rg_module_sap_test_01.rg_name
  bgp_route_propagation=var.bgp_route_propagations
  route_tags=var.tags
  depends_on=[module.rg_module_sap_test_01]
}
# .........................routetable association.........................................
#Route table association to SAP-test-INT subnet
module "routeTableAstn_module_sap_test_int" {
  source="../../module/route_table_association"
  subnet_id=module.subnet_module_sap_test_int.subnet_id
  route_table_id=module.routeTable_module_sap_test_int.route_table_id
  depends_on=[module.subnet_module_sap_test_int,module.routeTable_module_sap_test_int]
}

#Route table association to SAP-test-EDMZ subnet
module "routeTableAstn_module_sap_test_edmz" {
  source="../../module/route_table_association"
  subnet_id=module.subnet_module_sap_test_edmz.subnet_id
  route_table_id=module.routeTable_module_sap_test_edmz.route_table_id
  depends_on=[module.subnet_module_sap_test_edmz,module.routeTable_module_sap_test_edmz]
}

#Route table association to SAP-test-IDMZ subnet
module "routeTableAstn_module_sap_test_idmz" {
  source="../../module/route_table_association"
  subnet_id=module.subnet_module_sap_test_idmz.subnet_id
  route_table_id=module.routeTable_module_sap_test_idmz.route_table_id
  depends_on=[module.subnet_module_sap_test_idmz,module.routeTable_module_sap_test_idmz]  
}
# ................................routable routes......................................................
# .......iboss...................................
# Route table routes for SAP-test-INT route table
module "routes_module_sn_sap_test_int_iboss" {
  source = "../../module/route_table_routes"
  route_name=var.route_name_sn_sap_test_iboss
  resource_group_name=module.rg_module_sap_test_01.rg_name
  route_table_name=module.routeTable_module_sap_test_int.route_table_name_output 
  route_address_prefix=var.route_addressPrefix_sn_sap_test_iboss
  next_hop_type=var.route_nextHopType_sn_sap_test_iboss
  depends_on =[module.rg_module_sap_test_01,module.routeTable_module_sap_test_int]
}

# Route table routes for SAP-test-EDMZ route table
module "routes_module_sn_sap_test_edmz_iboss" {
  source = "../../module/route_table_routes"
  route_name=var.route_name_sn_sap_test_iboss
  resource_group_name=module.rg_module_sap_test_01.rg_name 
  route_table_name=module.routeTable_module_sap_test_edmz.route_table_name_output 
  route_address_prefix=var.route_addressPrefix_sn_sap_test_iboss
  next_hop_type=var.route_nextHopType_sn_sap_test_iboss
  depends_on =[module.rg_module_sap_test_01,module.routeTable_module_sap_test_edmz]
}

# Route table routes for SAP-test-IDMZ route table
module "routes_module_sn_sap_test_idmz_iboss" {
  source = "../../module/route_table_routes"
  route_name=var.route_name_sn_sap_test_iboss
  resource_group_name=module.rg_module_sap_test_01.rg_name
  route_table_name=module.routeTable_module_sap_test_idmz.route_table_name_output 
  route_address_prefix=var.route_addressPrefix_sn_sap_test_iboss
  next_hop_type=var.route_nextHopType_sn_sap_test_iboss
  depends_on =[module.rg_module_sap_test_01,module.routeTable_module_sap_test_idmz]
}
# ........................cp routes.................................
module "routes_module_sn_sap_test_int_cp" {
source = "../../module/routetable_route_nxthop"
route_name=var.route_name_sn_sap_test_cp
resource_group_name=module.rg_module_sap_test_01.rg_name
route_table_name=module.routeTable_module_sap_test_int.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_sap_cp
next_hop_type=var.route_nextHopType_sn_sap_test_cp
nexthop_in_ip_address=var.nxthopip_cp
depends_on =[module.rg_module_sap_test_01,module.routeTable_module_sap_test_int]
}
module "routes_module_sn_sap_test_edmz_cp" {
source = "../../module/routetable_route_nxthop"
route_name=var.route_name_sn_sap_test_cp
resource_group_name=module.rg_module_sap_test_01.rg_name
route_table_name=module.routeTable_module_sap_test_edmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_sap_cp
next_hop_type=var.route_nextHopType_sn_sap_test_cp
nexthop_in_ip_address=var.nxthopip_cp
depends_on =[module.rg_module_sap_test_01,module.routeTable_module_sap_test_edmz]
}
module "routes_module_sn_sap_test_idmz_cp" {
source = "../../module/routetable_route_nxthop"
route_name=var.route_name_sn_sap_test_cp
resource_group_name=module.rg_module_sap_test_01.rg_name
route_table_name=module.routeTable_module_sap_test_idmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_sap_cp
next_hop_type=var.route_nextHopType_sn_sap_test_cp
nexthop_in_ip_address=var.nxthopip_cp
depends_on =[module.rg_module_sap_test_01,module.routeTable_module_sap_test_idmz]
}
# ...........intfw......................
module "routes_module_sn_sap_test_int_cp_intfw" {
source = "../../module/routable_route_nxh"
route_name=var.route_name_sn_sap_test_cp_intfw
resource_group_name=module.rg_module_sap_test_01.rg_name
route_table_name=module.routeTable_module_sap_test_int.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_sap_cp_intfw
next_hop_type=var.route_nextHopType_sn_sap_test_cp_intfw
nexthop_in_ip_address=var.nxthopip_cp_intfw
depends_on =[module.rg_module_sap_test_01,module.routeTable_module_sap_test_int]
}
module "routes_module_sn_sap_test_edmz_cp_intfw" {
source = "../../module/routable_route_nxh"
route_name=var.route_name_sn_sap_test_cp_intfw
resource_group_name=module.rg_module_sap_test_01.rg_name
route_table_name=module.routeTable_module_sap_test_edmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_sap_cp_intfw
next_hop_type=var.route_nextHopType_sn_sap_test_cp_intfw
nexthop_in_ip_address=var.nxthopip_cp_intfw
depends_on =[module.rg_module_sap_test_01,module.routeTable_module_sap_test_edmz]
}
module "routes_module_sn_sap_test_idmz_cp_intfw" {
source = "../../module/routable_route_nxh"
route_name=var.route_name_sn_sap_test_cp_intfw
resource_group_name=module.rg_module_sap_test_01.rg_name
route_table_name=module.routeTable_module_sap_test_idmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_sap_cp_intfw
next_hop_type=var.route_nextHopType_sn_sap_test_cp_intfw
nexthop_in_ip_address=var.nxthopip_cp_intfw
depends_on =[module.rg_module_sap_test_01,module.routeTable_module_sap_test_idmz]
}
# ...................route abbnw.........................
module "routes_module_sn_sap_test_int_cp_abbnetwork" {
source = "../../module/routable_route_nxh"
route_name=var.route_name_sn_sap_test_cp_abbnetwork
resource_group_name=module.rg_module_sap_test_01.rg_name
route_table_name=module.routeTable_module_sap_test_int.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_sap_cp_abbnetwork
next_hop_type=var.route_nextHopType_sn_sap_test_cp_abbnetwork
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork
depends_on =[module.rg_module_sap_test_01,module.routeTable_module_sap_test_int]
}
module "routes_module_sn_sap_test_edmz_cp_abbnetwork" {
source = "../../module/routable_route_nxh"
route_name=var.route_name_sn_sap_test_cp_abbnetwork
resource_group_name=module.rg_module_sap_test_01.rg_name
route_table_name=module.routeTable_module_sap_test_edmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_sap_cp_abbnetwork
next_hop_type=var.route_nextHopType_sn_sap_test_cp_abbnetwork
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork
depends_on =[module.rg_module_sap_test_01,module.routeTable_module_sap_test_edmz]
}
module "routes_module_sn_sap_test_idmz_cp_abbnetwork" {
source = "../../module/routable_route_nxh"
route_name=var.route_name_sn_sap_test_cp_abbnetwork
resource_group_name=module.rg_module_sap_test_01.rg_name
route_table_name=module.routeTable_module_sap_test_idmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_sap_cp_abbnetwork
next_hop_type=var.route_nextHopType_sn_sap_test_cp_abbnetwork
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork
depends_on =[module.rg_module_sap_test_01,module.routeTable_module_sap_test_idmz]
}
# .................abb nw 02...........................
module "routes_module_sn_sap_test_int_cp_abbnetwork01" {
source = "../../module/routetable_route_nxthop"
route_name=var.route_name_sn_sap_test_cp_abbnetwork01
resource_group_name=module.rg_module_sap_test_01.rg_name
route_table_name=module.routeTable_module_sap_test_int.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_sap_cp_abbnetwork01
next_hop_type=var.route_nextHopType_sn_sap_test_cp_abbnetwork01
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork01
depends_on =[module.rg_module_sap_test_01,module.routeTable_module_sap_test_int]
}
module "routes_module_sn_sap_test_edmz_cp_abbnetwork02" {
source = "../../module/routetable_route_nxthop"
route_name=var.route_name_sn_sap_test_cp_abbnetwork01
resource_group_name=module.rg_module_sap_test_01.rg_name
route_table_name=module.routeTable_module_sap_test_edmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_sap_cp_abbnetwork01
next_hop_type=var.route_nextHopType_sn_sap_test_cp_abbnetwork01
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork01
depends_on =[module.rg_module_sap_test_01,module.routeTable_module_sap_test_edmz]
}
module "routes_module_sn_sap_test_idmz_cp_abbnetwork03" {
source = "../../module/routetable_route_nxthop"
route_name=var.route_name_sn_sap_test_cp_abbnetwork01
resource_group_name=module.rg_module_sap_test_01.rg_name
route_table_name=module.routeTable_module_sap_test_idmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_sap_cp_abbnetwork01
next_hop_type=var.route_nextHopType_sn_sap_test_cp_abbnetwork01
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork01
depends_on =[module.rg_module_sap_test_01,module.routeTable_module_sap_test_idmz]
}
# .....................edmz rules........................................
module "routes_module_sn_sap_edmz_rules" {
  source = "../../module/route_table_routes"
  route_name=var.route_name_sn_sap_edmz
  resource_group_name=module.rg_module_sap_test_01.rg_name
  route_table_name=module.routeTable_module_sap_test_edmz.route_table_name_output 
  route_address_prefix=var.route_addressPrefix_sn_sap_edmz
  next_hop_type=var.route_nextHopType_sn_sap_edmz
}
module "logaalyticsworkspace_reuse"{
  providers={
    azurerm=azurerm.sn_hub
  }
  source="../../module/law_reuse"
  law_name=var.loganalytics_name
  law_rg=var.loganalytics_rg
}
module "nsgflowlog_01"{
source = "../../module/nsg_flowlog"
networkwatcher_name=var.networkwatcher_name
nw_resourcegroup_name=var.networkwatcher_rg
nsg_id=[module.nsg_module_sap_test_int.nsg_id,module.nsg_module_sap_test_edmz.nsg_id,module.nsg_module_sap_test_idmz.nsg_id]
storage_account_id=module.storageaccount_module_sap_test_01.sta_id
retention_days=var.retention_days
flow_version=var.fversion
workspace_id=module.logaalyticsworkspace_reuse.law
location=module.rg_module_sap_test_02.rg_location
workspace_rs_id=module.logaalyticsworkspace_reuse.workspace_resource_id
minutes=var.flow_analytics
}

module "nsg_rules_module_01" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_01
  priority_number=var.prioritynumber_01
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_deny01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_01
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_01
  resource_group_name=module.rg_module_sap_test_01.rg_name
  nsg_name=[module.nsg_module_sap_test_int.nsg_name_out,module.nsg_module_sap_test_edmz.nsg_name_out,module.nsg_module_sap_test_idmz.nsg_name_out]
}

module "nsg_rules_module_02" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_02
  priority_number=var.prioritynumber_01
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_deny01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_01
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_01
  resource_group_name=module.rg_module_sap_test_01.rg_name
  nsg_name=[module.nsg_module_sap_test_int.nsg_name_out,module.nsg_module_sap_test_edmz.nsg_name_out,module.nsg_module_sap_test_idmz.nsg_name_out]
}

module "nsg_rules_module_03" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_03
  priority_number=var.prioritynumber_02
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_01
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_02
  resource_group_name=module.rg_module_sap_test_01.rg_name
  nsg_name=[module.nsg_module_sap_test_int.nsg_name_out,module.nsg_module_sap_test_edmz.nsg_name_out,module.nsg_module_sap_test_idmz.nsg_name_out]
}

module "nsg_rules_module_04" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_04
  priority_number=var.prioritynumber_02
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_02
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_01
  resource_group_name=module.rg_module_sap_test_01.rg_name
  nsg_name=[module.nsg_module_sap_test_int.nsg_name_out,module.nsg_module_sap_test_edmz.nsg_name_out,module.nsg_module_sap_test_idmz.nsg_name_out]
}

# module "nsg_rules_module_05" {
#   source = "../../module/nsg_rules_creation"
#   nsg_rule_name=var.nsgrule_name_05
#   priority_number=var.prioritynumber_03
#   nsg_direction=var.nsg_direction_inbound01
#   nsg_accesstype=var.accesstype_deny01
#   nsg_protocol=var.protocol_01
#   nsg_source_port_range=var.source_port_range_01
#   nsg_destination_port_range=var.nsg_destination_port_range01
#   nsg_source_address_prefixe=var.nsg_source_address_prefixe_03
#   nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_01
#   resource_group_name=module.rg_module_sap_test_01.rg_name
#   nsg_name=[module.nsg_module_sap_test_int.nsg_name_out,module.nsg_module_sap_test_edmz.nsg_name_out,module.nsg_module_sap_test_idmz.nsg_name_out]
# }
# module "nsg_rules_module_06" {
#   source = "../../module/nsg_rules_creation"
#   nsg_rule_name=var.nsgrule_name_06
#   priority_number=var.prioritynumber_03
#   nsg_direction=var.nsg_direction_outbound01
#   nsg_accesstype=var.accesstype_deny01
#   nsg_protocol=var.protocol_01
#   nsg_source_port_range=var.source_port_range_01
#   nsg_destination_port_range=var.nsg_destination_port_range01
#   nsg_source_address_prefixe=var.nsg_source_address_prefixe_01
#   nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_03
#   resource_group_name=module.rg_module_sap_test_01.rg_name
#   nsg_name=[module.nsg_module_sap_test_int.nsg_name_out,module.nsg_module_sap_test_edmz.nsg_name_out,module.nsg_module_sap_test_idmz.nsg_name_out]
# }

module "recovery_service_vault"{
source= "../../module/recovery_services_vault_creation"
  recovery_vault_name              = var.recovery_serv_vault_name
  location                         = module.rg_module_sn_sap_test_3.rg_location
  resource_group_name              = module.rg_module_sn_sap_test_3.rg_name
  vault_sku_name                   = var.recovery_serv_vault_sku_name
  tags                             = var.tags_recovery_services
}
module "nsg_rules_module_07" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_07
  priority_number=var.prioritynumber_04
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_deny01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_04
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_04
  resource_group_name=module.rg_module_sap_test_01.rg_name
  nsg_name=[module.nsg_module_sap_test_int.nsg_name_out,module.nsg_module_sap_test_edmz.nsg_name_out,module.nsg_module_sap_test_idmz.nsg_name_out]
}
module "nsg_rules_module_08" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_08
  priority_number=var.prioritynumber_04
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_deny01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_04
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_04
  resource_group_name=module.rg_module_sap_test_01.rg_name
  nsg_name=[module.nsg_module_sap_test_int.nsg_name_out,module.nsg_module_sap_test_edmz.nsg_name_out,module.nsg_module_sap_test_idmz.nsg_name_out]
}

#.............................rdgw...............................................
module "nsg_rules_module_11" {
  source = "../../module/nsgrule_creation_list"
  nsg_rule_name=var.nsgrule_name_11
  priority_number=var.prioritynumber_06
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_rdgw
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_rdgw
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_04
  resource_group_name=module.rg_module_sap_test_01.rg_name
  nsg_name=[module.nsg_module_sap_test_int.nsg_name_out,module.nsg_module_sap_test_edmz.nsg_name_out,module.nsg_module_sap_test_idmz.nsg_name_out]
}
# ............jumbbox............
module "nsg_rules_module_12" {
  source = "../../module/nsgrule_creation_list"
  nsg_rule_name=var.nsgrule_name_12
  priority_number=var.prioritynumber_07
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_jmpbox
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_jmpbox
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_04
  resource_group_name=module.rg_module_sap_test_01.rg_name
  nsg_name=[module.nsg_module_sap_test_int.nsg_name_out,module.nsg_module_sap_test_edmz.nsg_name_out,module.nsg_module_sap_test_idmz.nsg_name_out]
}
# .............loadbalancer health probe.....................................
module "nsg_rules_module_13" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_13
  priority_number=var.prioritynumber_08
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_lb
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_04
  resource_group_name=module.rg_module_sap_test_01.rg_name
  nsg_name=[module.nsg_module_sap_test_int.nsg_name_out,module.nsg_module_sap_test_edmz.nsg_name_out,module.nsg_module_sap_test_idmz.nsg_name_out]
}
module "nsg_rules_module_14" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_14
  priority_number=var.prioritynumber_08
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_lb
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_01
  resource_group_name=module.rg_module_sap_test_01.rg_name
  nsg_name=[module.nsg_module_sap_test_int.nsg_name_out,module.nsg_module_sap_test_edmz.nsg_name_out,module.nsg_module_sap_test_idmz.nsg_name_out]
}
#......................sl............................................
module "nsg_rules_module_15" {
  source = "../../module/nsgrule_creation_list2"
  nsg_rule_name=var.nsgrule_name_15
  priority_number=var.prioritynumber_09
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_sl
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_sl
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_04
  resource_group_name=module.rg_module_sap_test_01.rg_name
  nsg_name=[module.nsg_module_sap_test_int.nsg_name_out,module.nsg_module_sap_test_edmz.nsg_name_out,module.nsg_module_sap_test_idmz.nsg_name_out]
}
# ..........commvault....................................
#.....tcp.................
module "nsg_rules_module_16" {
  source = "../../module/nsgrule_creation_list2"
  nsg_rule_name=var.nsgrule_name_16
  priority_number=var.prioritynumber_10
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_cv_tcp
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_cv
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_04
  resource_group_name=module.rg_module_sap_test_01.rg_name
  nsg_name=[module.nsg_module_sap_test_int.nsg_name_out,module.nsg_module_sap_test_edmz.nsg_name_out,module.nsg_module_sap_test_idmz.nsg_name_out]
}
#.....udp.................
module "nsg_rules_module_17" {
  source = "../../module/nsgrule_creation_list2"
  nsg_rule_name=var.nsgrule_name_17
  priority_number=var.prioritynumber_11
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_udp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_cv_udp
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_cv
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_04
  resource_group_name=module.rg_module_sap_test_01.rg_name
  nsg_name=[module.nsg_module_sap_test_int.nsg_name_out,module.nsg_module_sap_test_edmz.nsg_name_out,module.nsg_module_sap_test_idmz.nsg_name_out]
}
#.....outbound.................
#.....tcp.................
module "nsg_rules_module_18" {
  source = "../../module/nsgrule_creation_list4"
  nsg_rule_name=var.nsgrule_name_18
  priority_number=var.prioritynumber_10
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_cv_tcp
  nsg_source_address_prefix=var.nsg_source_address_prefixe_04
  nsg_destination_address_prefixes=var.nsg_destination_address_prefixe_cv
  resource_group_name=module.rg_module_sap_test_01.rg_name
  nsg_name=[module.nsg_module_sap_test_int.nsg_name_out,module.nsg_module_sap_test_edmz.nsg_name_out,module.nsg_module_sap_test_idmz.nsg_name_out]
}
#.....udp.................
module "nsg_rules_module_19" {
  source = "../../module/nsgrule_creation_list4"
  nsg_rule_name=var.nsgrule_name_19
  priority_number=var.prioritynumber_11
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_udp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_cv_udp
  nsg_source_address_prefix=var.nsg_source_address_prefixe_04
  nsg_destination_address_prefixes=var.nsg_destination_address_prefixe_cv
  resource_group_name=module.rg_module_sap_test_01.rg_name
  nsg_name=[module.nsg_module_sap_test_int.nsg_name_out,module.nsg_module_sap_test_edmz.nsg_name_out,module.nsg_module_sap_test_idmz.nsg_name_out]
}
#.....cylance outbound.................
module "nsg_rules_module_20" {
  source = "../../module/nsgrule_creation_list3"
  nsg_rule_name=var.nsgrule_name_20
  priority_number=var.prioritynumber_12
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_cy
  nsg_source_address_prefix=var.nsg_source_address_prefixe_04
  nsg_destination_address_prefixes=var.nsg_destination_address_prefixe_cy
  resource_group_name=module.rg_module_sap_test_01.rg_name
  nsg_name=[module.nsg_module_sap_test_int.nsg_name_out,module.nsg_module_sap_test_edmz.nsg_name_out,module.nsg_module_sap_test_idmz.nsg_name_out]
}
#.....iboss outbound.................
module "nsg_rules_module_21" {
  source = "../../module/nsgrule_creation_list4"
  nsg_rule_name=var.nsgrule_name_21
  priority_number=var.prioritynumber_13
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_iboss
  nsg_source_address_prefix=var.nsg_source_address_prefixe_04
  nsg_destination_address_prefixes=var.nsg_destination_address_prefixe_iboss
  resource_group_name=module.rg_module_sap_test_01.rg_name
  nsg_name=[module.nsg_module_sap_test_int.nsg_name_out,module.nsg_module_sap_test_edmz.nsg_name_out,module.nsg_module_sap_test_idmz.nsg_name_out]
}
# ........rdrw udp................................................
module "nsg_rules_module_22" {
  source = "../../module/nsgrule_creation_list"
  nsg_rule_name=var.nsgrule_name_22
  priority_number=var.prioritynumber_15
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_udp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_rdgw
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_rdgw
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_04
 resource_group_name=module.rg_module_sap_test_01.rg_name
  nsg_name=[module.nsg_module_sap_test_int.nsg_name_out,module.nsg_module_sap_test_edmz.nsg_name_out,module.nsg_module_sap_test_idmz.nsg_name_out]
}
# ................idmz rules ..............................................................................
# .....int.................................................................................................
module "nsg_rules_module_23" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_23
  priority_number=var.prioritynumber_14
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_10
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_10
  resource_group_name=module.rg_module_sap_test_01.rg_name
  nsg_name=[module.nsg_module_sap_test_int.nsg_name_out]
}
module "nsg_rules_module_24" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_24
  priority_number=var.prioritynumber_14
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_10
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_10
  resource_group_name=module.rg_module_sap_test_01.rg_name
  nsg_name=[module.nsg_module_sap_test_int.nsg_name_out]
}
# ............idmz.....................................................................
module "nsg_rules_module_25" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_25
  priority_number=var.prioritynumber_14
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_11
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_11
  resource_group_name=module.rg_module_sap_test_01.rg_name
  nsg_name=[module.nsg_module_sap_test_idmz.nsg_name_out]
}
module "nsg_rules_module_26" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_26
  priority_number=var.prioritynumber_14
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_11
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_11
  resource_group_name=module.rg_module_sap_test_01.rg_name
  nsg_name=[module.nsg_module_sap_test_idmz.nsg_name_out]
}
# ............edmz.....................................................................
module "nsg_rules_module_27" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_27
  priority_number=var.prioritynumber_14
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_12
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_12
  resource_group_name=module.rg_module_sap_test_01.rg_name
  nsg_name=[module.nsg_module_sap_test_edmz.nsg_name_out]
}
module "nsg_rules_module_28" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_28
  priority_number=var.prioritynumber_14
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_12
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_12
  resource_group_name=module.rg_module_sap_test_01.rg_name
  nsg_name=[module.nsg_module_sap_test_edmz.nsg_name_out]
}
# .............keyvault.....................................................

  module "keyvault_creation" {
  source ="../../module/keyvault_creation"
  rg_name=module.rg_module_sn_sap_test_4.rg_name
  location=module.rg_module_sn_sap_test_4.rg_location
  object_id= var.object_id
  keyvault_name=var.keyvault_name
  sku_name=var.sku
  tags=var.tags_app
  soft_delete_retention_days=var.soft_retention_days
  }
  module "accesspolicy_keyvault"{
    source ="../../module/add_accesspolicies"
    object_ids= var.object_id_01
    keyvault_id=module.keyvault_creation.keyvault_id
    depends_on=[module.keyvault_creation]
  }

  module "accesspolicy_keyvault01"{
    source ="../../module/add_accesspolicies"
    object_ids= var.object_id_02
    keyvault_id=module.keyvault_creation.keyvault_id
    depends_on=[module.keyvault_creation]
  }
  # .............diagnostic settings......................................................................
# ................nsg.....................................
module "nsg_diagnostics"{
source = "../../module/diagnosticsettings"
resource_id=[module.nsg_module_sap_test_int.nsg_id,module.nsg_module_sap_test_edmz.nsg_id,module.nsg_module_sap_test_idmz.nsg_id]
dlog_name=var.diagnosticsettings_nsg
target_id=[module.nsg_module_sap_test_int.nsg_id,module.nsg_module_sap_test_edmz.nsg_id,module.nsg_module_sap_test_idmz.nsg_id]
storage_acc_id =module.storageaccount_module_sap_test_01.sta_id
workspace_rs_id =module.logaalyticsworkspace_reuse.workspace_resource_id
}
module "rsv_diagnostics"{
source = "../../module/diagnosticsettings"
resource_id=[module.recovery_service_vault.rsv_id]
dlog_name=var.diagnosticsettings_rsv
target_id=[module.recovery_service_vault.rsv_id]
storage_acc_id =module.storageaccount_module_sap_test_01.sta_id
workspace_rs_id =module.logaalyticsworkspace_reuse.workspace_resource_id
}