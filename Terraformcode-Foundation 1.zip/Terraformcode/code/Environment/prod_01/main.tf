terraform {
  required_version = "0.13.5"
}
# -------------------------------------------------------sn glb prod resource Group creation-------------------------------------------------------
#output variables for this block is {rg_name,rg_id and rg_location}
module "rg_module_sn_glb_prod_1" {
  source= "../../module/rg_creation"
  resourcegrp_name=var.resource_group_name
  location=var.location
  tags=var.tags
}
module "rg_module_sn_glb_prod_2" {
  source= "../../module/rg_creation"  
  resourcegrp_name=var.resource_group_name01
  location=var.location
  tags=var.tags_app
}
module "rg_module_sn_glb_prod_3" {
  source= "../../module/rg_creation"
  resourcegrp_name=var.resource_group_name02
  location=var.location
  tags=var.tags_mgmt
}
module "rg_module_sn_glb_prod_4" {
  source= "../../module/rg_creation"
  resourcegrp_name=var.resource_group_name03
  location=var.location
  tags=var.tags_recovery_services
}
# ......................storage account................................
# module "storageaccount_module_glb_prod_01" {
#   source = "../../module/storageaccount_creation"
#   storageaccountname=var.storageaccountname01
#   location=module.rg_module_sn_glb_prod_3.rg_location
#   resourcegrp_name=module.rg_module_sn_glb_prod_3.rg_name
#   storage_account_type=var.strg_acc_type
#   account_kind=var.acc_kind 
#   access_tier=var.access_tier
#   tags=var.tags_mgmt
# }
module "storageaccount_module_glb_prod_02" {
  source = "../../module/storageaccount_creation"
  storageaccountname=var.storageaccountname02
  location=module.rg_module_sn_glb_prod_3.rg_location
  resourcegrp_name=module.rg_module_sn_glb_prod_3.rg_name
  storage_account_type=var.strg_acc_type01
  account_kind=var.acc_kind01
  access_tier=var.access_tier01
  tags=var.tags_mgmt
}
#----------------------------------------------------------------------SN glb prod vnet creation---------------------------------------------------------
#output variables for this block is {vnet_id and vnet_name}
module "vnet_module_sn_glb_prod_z1a" {
  source ="../../module/vnet_creation"
  vnet_name=var.vnet_name_sn_glb_prod_z1a
  location=module.rg_module_sn_glb_prod_1.rg_location
  address_dnsservers=var.dnsservers01
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  vnet_address_prefix=var.vnet_addr_prefix_sn_glb_prod_z1a
  tags_vnet=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}     
module "vnet_module_sn_glb_prod_z1b" {
  source ="../../module/vnet_creation"
  address_dnsservers=var.dnsservers01
  vnet_name=var.vnet_name_sn_glb_prod_z1b
  location=module.rg_module_sn_glb_prod_1.rg_location
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  vnet_address_prefix=var.vnet_addr_prefix_sn_glb_prod_z1b
  tags_vnet=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}    
module "vnet_module_sn_glb_prod_z3" {
  source ="../../module/vnet_creation"
  vnet_name=var.vnet_name_sn_glb_prod_z3
  address_dnsservers=var.dnsservers01
  location=module.rg_module_sn_glb_prod_1.rg_location
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  vnet_address_prefix=var.vnet_addr_prefix_sn_glb_prod_z3
  tags_vnet=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}    
module "vnet_module_sn_glb_prod_z1c" {
  source ="../../module/vnet_creation"
  vnet_name=var.vnet_name_sn_glb_prod_z1c
  address_dnsservers=var.dnsservers02
  location=module.rg_module_sn_glb_prod_1.rg_location
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  vnet_address_prefix=var.vnet_addr_prefix_sn_glb_prod_z1c
  tags_vnet=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}    
# ...............existingvnet..................................
module "existingvnetsnhubvnet01" {
  providers={
    azurerm=azurerm.sn_hub
  }
source = "../../module/existing_vnet"
  existingvnet=var.existingvnetsnhubvnet01
  rg_name=var.existingresourcegroupsn_hubvnet01
  
}
module "existingvnetsnhubvnet02" {
  providers={
    azurerm=azurerm.sn_hub
  }
source = "../../module/existing_vnet"
  existingvnet=var.existingvnetsnhubvnet02
  rg_name=var.existingresourcegroupsn_hubvnet01
  
}
# .....cross region peering.........................
# z1a
module "existingvnetweglbprodvnet01" {
  providers={
    azurerm=azurerm.we_glbprod
  }
source = "../../module/existing_vnet"
  existingvnet=var.existingweglbvnet01
  rg_name=var.existingresourcegroupswe_glbprod01
  
}
# z1b
module "existingvnetweglbprodvnet02" {
  providers={
    azurerm=azurerm.we_glbprod
  }
source = "../../module/existing_vnet"
  existingvnet=var.existingweglbvnet02
  rg_name=var.existingresourcegroupswe_glbprod01
  
}
# z1c
module "existingvnetweglbprodvnet03" {
  providers={
    azurerm=azurerm.we_glbprod
  }
source = "../../module/existing_vnet"
  existingvnet=var.existingweglbvnet03
  rg_name=var.existingresourcegroupswe_glbprod01
  
}
# z3
module "existingvnetweglbprodvnet04" {
  providers={
    azurerm=azurerm.we_glbprod
  }
source = "../../module/existing_vnet"
  existingvnet=var.existingweglbvnet04
  rg_name=var.existingresourcegroupswe_glbprod01
  
}
# ................crosss region peering............................
# z1a to z1a
module "sn_glb_prod_cross_vnet_peering_module1" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.sn_glb_prod_cross_vnet_peering_name_01
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  vnet_name=module.vnet_module_sn_glb_prod_z1a.vnet_name
  vnet_remote_id=module.existingvnetweglbprodvnet01.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_10
  use_remote_gateways=var.use_remote_gateways_10
}
# z1b-z1b
module "sn_glb_prod_cross_vnet_peering_module2" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.sn_glb_prod_cross_vnet_peering_name_02
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  vnet_name=module.vnet_module_sn_glb_prod_z1b.vnet_name
  vnet_remote_id=module.existingvnetweglbprodvnet02.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_10
  use_remote_gateways=var.use_remote_gateways_10
}
# z1c to z1c
module "sn_glb_prod_cross_vnet_peering_module3" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.sn_glb_prod_cross_vnet_peering_name_03
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  vnet_name=module.vnet_module_sn_glb_prod_z1c.vnet_name
  vnet_remote_id=module.existingvnetweglbprodvnet03.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_10
  use_remote_gateways=var.use_remote_gateways_10
}
# z3 to z3
module "sn_glb_prod_cross_vnet_peering_module4" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.sn_glb_prod_cross_vnet_peering_name_04
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  vnet_name=module.vnet_module_sn_glb_prod_z3.vnet_name
  vnet_remote_id=module.existingvnetweglbprodvnet04.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_10
  use_remote_gateways=var.use_remote_gateways_10
}
#........................ vnetpeeing...................
# vnet01 to z1a
 module "sn_glb_prod_vnet_peering_module1" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.sn_glb_prod_vnet_peering_name_01
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  vnet_name=module.vnet_module_sn_glb_prod_z1a.vnet_name
  vnet_remote_id=module.existingvnetsnhubvnet01.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_01
  use_remote_gateways=var.use_remote_gateways_01
}
# vnet01 to z1b
module "sn_glb_prod_vnet_peering_module2" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.sn_glb_prod_vnet_peering_name_02
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  vnet_name=module.vnet_module_sn_glb_prod_z1b.vnet_name
  vnet_remote_id=module.existingvnetsnhubvnet01.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_02
  use_remote_gateways=var.use_remote_gateways_02
}
# vnet01 to z3
module "sn_glb_prod_vnet_peering_module3" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.sn_glb_prod_vnet_peering_name_03
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  vnet_name=module.vnet_module_sn_glb_prod_z3.vnet_name
  vnet_remote_id=module.existingvnetsnhubvnet01.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_03
  use_remote_gateways=var.use_remote_gateways_03
}
# vnet01 to z1c
module "sn_glb_prod_vnet_peering_module4" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.sn_glb_prod_vnet_peering_name_04
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  vnet_name=module.vnet_module_sn_glb_prod_z1c.vnet_name
  vnet_remote_id=module.existingvnetsnhubvnet01.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_04
  use_remote_gateways=var.use_remote_gateways_04
}
# vnet02 to z1a
module "sn_glb_prod_vnet_peering_module5" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.sn_glb_prod_vnet_peering_name_05
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  vnet_name=module.vnet_module_sn_glb_prod_z1a.vnet_name
  vnet_remote_id=module.existingvnetsnhubvnet02.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_05
  use_remote_gateways=var.use_remote_gateways_05
}
# vnet02 to z1b
module "sn_glb_prod_vnet_peering_module6" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.sn_glb_prod_vnet_peering_name_06
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  vnet_name=module.vnet_module_sn_glb_prod_z1b.vnet_name
  vnet_remote_id=module.existingvnetsnhubvnet02.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_06
  use_remote_gateways=var.use_remote_gateways_06
}
# vnet02 to z3
module "sn_glb_prod_vnet_peering_module7" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.sn_glb_prod_vnet_peering_name_07
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  vnet_name=module.vnet_module_sn_glb_prod_z3.vnet_name
  vnet_remote_id=module.existingvnetsnhubvnet02.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_07
  use_remote_gateways=var.use_remote_gateways_07
}
# vnet02 to z1c
module "sn_glb_prod_vnet_peering_module8" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.sn_glb_prod_vnet_peering_name_08
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  vnet_name=module.vnet_module_sn_glb_prod_z1c.vnet_name
  vnet_remote_id=module.existingvnetsnhubvnet02.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_08
  use_remote_gateways=var.use_remote_gateways_08
}

# #---------------------------------------------------------------SN glb prod subnet creation-----------------------------------------------------------------
# #output variables for this block is {subnet_id and subnet_address_prefix}
#----------------------------z1a subnet creation---------------------
module "subnet_module_sn_glb_prod_z1a_int" {
  source = "../../module/subnet_creation"
  subnet_name=var.subnet_name_sn_glb_prod_z1a_int
  vnet_name=module.vnet_module_sn_glb_prod_z1a.vnet_name
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  address_space=var.addr_space_sn_glb_prod_z1a_int
  depends_on =[module.vnet_module_sn_glb_prod_z1a]
}
module "subnet_module_sn_glb_prod_z1a_idmz" {
  source = "../../module/subnet_creation"
  subnet_name=var.subnet_name_sn_glb_prod_z1a_idmz
  vnet_name=module.vnet_module_sn_glb_prod_z1a.vnet_name
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  address_space=var.addr_space_sn_glb_prod_z1a_idmz
  depends_on =[module.vnet_module_sn_glb_prod_z1a]
}
module "subnet_module_sn_glb_prod_z1a_edmz" {
  source = "../../module/subnet_creation"
  subnet_name=var.subnet_name_sn_glb_prod_z1a_edmz
  vnet_name=module.vnet_module_sn_glb_prod_z1a.vnet_name
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  address_space=var.addr_space_sn_glb_prod_z1a_edmz
  depends_on =[module.vnet_module_sn_glb_prod_z1a]
}
#---------------------------- z1b subnet creation-----------------
module "subnet_module_sn_glb_prod_z1b_int" {
  source = "../../module/subnet_creation"
  subnet_name=var.subnet_name_sn_glb_prod_z1b_int
  vnet_name=module.vnet_module_sn_glb_prod_z1b.vnet_name
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  address_space=var.addr_space_sn_glb_prod_z1b_int
  depends_on =[module.vnet_module_sn_glb_prod_z1b]
}
module "subnet_module_sn_glb_prod_z1b_idmz" {
  source = "../../module/subnet_creation"
  subnet_name=var.subnet_name_sn_glb_prod_z1b_idmz
  vnet_name=module.vnet_module_sn_glb_prod_z1b.vnet_name
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  address_space=var.addr_space_sn_glb_prod_z1b_idmz
  depends_on =[module.vnet_module_sn_glb_prod_z1b]
}
module "subnet_module_sn_glb_prod_z1b_edmz" {
  source = "../../module/subnet_creation"
  subnet_name=var.subnet_name_sn_glb_prod_z1b_edmz
  vnet_name=module.vnet_module_sn_glb_prod_z1b.vnet_name
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  address_space=var.addr_space_sn_glb_prod_z1b_edmz
  depends_on =[module.vnet_module_sn_glb_prod_z1b]
}
# module "subnet_module_sn_glb_prod_z1b_sox" {
#   source = "../../module/subnet_creation"
#   subnet_name=var.subnet_name_sn_glb_prod_z1b_sox
#   vnet_name=module.vnet_module_sn_glb_prod_z1b.vnet_name
#   resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
#   address_space=var.addr_space_sn_glb_prod_z1b_sox
#   depends_on =[module.vnet_module_sn_glb_prod_z1b]
# }

#-------------------------z3 subnet creation-------------------
module "subnet_module_sn_glb_prod_z3_int" {
  source = "../../module/subnet_creation"
  subnet_name=var.subnet_name_sn_glb_prod_z3_int
  vnet_name=module.vnet_module_sn_glb_prod_z3.vnet_name
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  address_space=var.addr_space_sn_glb_prod_z3_int
  depends_on =[module.vnet_module_sn_glb_prod_z3]
}
module "subnet_module_sn_glb_prod_z3_idmz" {
  source = "../../module/subnet_creation"
  subnet_name=var.subnet_name_sn_glb_prod_z3_idmz
  vnet_name=module.vnet_module_sn_glb_prod_z3.vnet_name
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  address_space=var.addr_space_sn_glb_prod_z3_idmz
  depends_on =[module.vnet_module_sn_glb_prod_z3]
}
module "subnet_module_sn_glb_prod_z3_edmz" {
  source = "../../module/subnet_creation"
  subnet_name=var.subnet_name_sn_glb_prod_z3_edmz
  vnet_name=module.vnet_module_sn_glb_prod_z3.vnet_name
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  address_space=var.addr_space_sn_glb_prod_z3_edmz
  depends_on =[module.vnet_module_sn_glb_prod_z3]
}

#-------------------------- z1c subnet creation-------------
module "subnet_module_sn_glb_prod_z1c_int" {
  source = "../../module/subnet_creation"
  subnet_name=var.subnet_name_sn_glb_prod_z1c_int
  vnet_name=module.vnet_module_sn_glb_prod_z1c.vnet_name
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  address_space=var.addr_space_sn_glb_prod_z1c_int
  depends_on =[module.vnet_module_sn_glb_prod_z1c]
}
module "subnet_module_sn_glb_prod_z1c_idmz" {
  source = "../../module/subnet_creation"
  subnet_name=var.subnet_name_sn_glb_prod_z1c_idmz
  vnet_name=module.vnet_module_sn_glb_prod_z1c.vnet_name
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  address_space=var.addr_space_sn_glb_prod_z1c_idmz
  depends_on =[module.vnet_module_sn_glb_prod_z1c]
}
module "subnet_module_sn_glb_prod_z1c_edmz" {
  source = "../../module/subnet_creation"
  subnet_name=var.subnet_name_sn_glb_prod_z1c_edmz
  vnet_name=module.vnet_module_sn_glb_prod_z1c.vnet_name
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  address_space=var.addr_space_sn_glb_prod_z1c_edmz
  depends_on =[module.vnet_module_sn_glb_prod_z1c]
}
# module "subnet_module_sn_glb_prod_z1c_mgmt" {
#   source = "../../module/subnet_creation"
#   subnet_name=var.subnet_name_sn_glb_prod_z1c_mgmt
#   vnet_name=module.vnet_module_sn_glb_prod_z1c.vnet_name
#   resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
#   address_space=var.addr_space_sn_glb_prod_z1c_mgmt
#   depends_on =[module.vnet_module_sn_glb_prod_z1c]
# }
# module "subnet_module_sn_glb_prod_z1c_ad" {
#   source = "../../module/subnet_creation"
#   subnet_name=var.subnet_name_sn_glb_prod_z1c_ad
#   vnet_name=module.vnet_module_sn_glb_prod_z1c.vnet_name
#   resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
#   address_space=var.addr_space_sn_glb_prod_z1c_ad
#   depends_on =[module.vnet_module_sn_glb_prod_z1c]
# }
#--------------------------------------------------------------SN glb prod nsg creation---------------------------------------------------------------------
# output variables for this block is {nsg_id and nsg_name}
#-----------------------------Z1a nsg-------------------------
module "nsg_module_sn_glb_prod_z1a_int" {
  source = "../../module/nsg_creation"
  nsg_name=var.nsg_name_sn_glb_prod_z1a_int
  location=module.rg_module_sn_glb_prod_1.rg_location
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  tags_nsg=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
module "nsg_module_sn_glb_prod_z1a_idmz" {
  source = "../../module/nsg_creation"
  nsg_name=var.nsg_name_sn_glb_prod_z1a_idmz
  location=module.rg_module_sn_glb_prod_1.rg_location
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  tags_nsg=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
module "nsg_module_sn_glb_prod_z1a_edmz" {
  source = "../../module/nsg_creation"
  nsg_name=var.nsg_name_sn_glb_prod_z1a_edmz
  location=module.rg_module_sn_glb_prod_1.rg_location
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  tags_nsg=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}

#-----------------------------Z1b nsg-------------------------
module "nsg_module_sn_glb_prod_z1b_int" {
  source = "../../module/nsg_creation"
  nsg_name=var.nsg_name_sn_glb_prod_z1b_int
  location=module.rg_module_sn_glb_prod_1.rg_location
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  tags_nsg=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
module "nsg_module_sn_glb_prod_z1b_idmz" {
  source = "../../module/nsg_creation"
  nsg_name=var.nsg_name_sn_glb_prod_z1b_idmz
  location=module.rg_module_sn_glb_prod_1.rg_location
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  tags_nsg=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
module "nsg_module_sn_glb_prod_z1b_edmz" {
  source = "../../module/nsg_creation"
  nsg_name=var.nsg_name_sn_glb_prod_z1b_edmz
  location=module.rg_module_sn_glb_prod_1.rg_location
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  tags_nsg=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
module "nsg_module_sn_glb_prod_z1b_sox" {
  source = "../../module/nsg_creation"
  nsg_name=var.nsg_name_sn_glb_prod_z1b_sox
  location=module.rg_module_sn_glb_prod_1.rg_location
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  tags_nsg=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}

#-----------------------------Z3 nsg-------------------------
module "nsg_module_sn_glb_prod_z3_int" {
  source = "../../module/nsg_creation"
  nsg_name=var.nsg_name_sn_glb_prod_z3_int
  location=module.rg_module_sn_glb_prod_1.rg_location
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  tags_nsg=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
module "nsg_module_sn_glb_prod_z3_idmz" {
  source = "../../module/nsg_creation"
  nsg_name=var.nsg_name_sn_glb_prod_z3_idmz
  location=module.rg_module_sn_glb_prod_1.rg_location
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  tags_nsg=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
module "nsg_module_sn_glb_prod_z3_edmz" {
  source = "../../module/nsg_creation"
  nsg_name=var.nsg_name_sn_glb_prod_z3_edmz
  location=module.rg_module_sn_glb_prod_1.rg_location
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  tags_nsg=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}

#-----------------------------Z1c nsg-------------------------
module "nsg_module_sn_glb_prod_z1c_int" {
  source = "../../module/nsg_creation"
  nsg_name=var.nsg_name_sn_glb_prod_z1c_int
  location=module.rg_module_sn_glb_prod_1.rg_location
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  tags_nsg=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
module "nsg_module_sn_glb_prod_z1c_idmz" {
  source = "../../module/nsg_creation"
  nsg_name=var.nsg_name_sn_glb_prod_z1c_idmz
  location=module.rg_module_sn_glb_prod_1.rg_location
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  tags_nsg=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
module "nsg_module_sn_glb_prod_z1c_edmz" {
  source = "../../module/nsg_creation"
  nsg_name=var.nsg_name_sn_glb_prod_z1c_edmz
  location=module.rg_module_sn_glb_prod_1.rg_location
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  tags_nsg=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
module "nsg_module_sn_glb_prod_z1c_mgmt" {
  source = "../../module/nsg_creation"
  nsg_name=var.nsg_name_sn_glb_prod_z1c_mgmt
  location=module.rg_module_sn_glb_prod_1.rg_location
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  tags_nsg=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
module "nsg_module_sn_glb_prod_z1c_ad" {
  source = "../../module/nsg_creation"
  nsg_name=var.nsg_name_sn_glb_prod_z1c_ad
  location=module.rg_module_sn_glb_prod_1.rg_location
  resourcegrp_name=module.rg_module_sn_glb_prod_1.rg_name
  tags_nsg=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
 #-----------------------------------------------------------SN GLB Prod nsg association--------------------------------------------------------------------
#----------------z1a Nsg assocition-------------------------------------------
module "nsg_association_module_glb_prod_z1a_int" {
  source = "../../module/nsg_subnet_association"
  subnet_id=module.subnet_module_sn_glb_prod_z1a_int.subnet_id
  nsg_id=module.nsg_module_sn_glb_prod_z1a_int.nsg_id
  depends_on =[module.nsg_module_sn_glb_prod_z1a_int,module.subnet_module_sn_glb_prod_z1a_int]
    
}
module "nsg_association_module_glb_prod_z1a_idmz" {
  source = "../../module/nsg_subnet_association"
  subnet_id=module.subnet_module_sn_glb_prod_z1a_idmz.subnet_id
  nsg_id=module.nsg_module_sn_glb_prod_z1a_idmz.nsg_id
  depends_on =[module.nsg_module_sn_glb_prod_z1a_idmz,module.subnet_module_sn_glb_prod_z1a_idmz]
    
}
module "nsg_association_module_glb_prod_z1a_edmz" {
  source = "../../module/nsg_subnet_association"
  subnet_id=module.subnet_module_sn_glb_prod_z1a_edmz.subnet_id
  nsg_id=module.nsg_module_sn_glb_prod_z1a_edmz.nsg_id
  depends_on =[module.nsg_module_sn_glb_prod_z1a_edmz,module.subnet_module_sn_glb_prod_z1a_edmz]
    
}
#----------z1b Nsg association-------------------------------------------------
module "nsg_association_module_glb_prod_z1b_int" {
  source = "../../module/nsg_subnet_association"
  subnet_id=module.subnet_module_sn_glb_prod_z1b_int.subnet_id
  nsg_id=module.nsg_module_sn_glb_prod_z1b_int.nsg_id
  depends_on =[module.nsg_module_sn_glb_prod_z1b_int,module.subnet_module_sn_glb_prod_z1b_int]
    
}
module "nsg_association_module_glb_prod_z1b_idmz" {
  source = "../../module/nsg_subnet_association"
  subnet_id=module.subnet_module_sn_glb_prod_z1b_idmz.subnet_id
  nsg_id=module.nsg_module_sn_glb_prod_z1b_idmz.nsg_id
  depends_on =[module.nsg_module_sn_glb_prod_z1b_idmz,module.subnet_module_sn_glb_prod_z1b_idmz]
    
}
module "nsg_association_module_glb_prod_z1b_edmz" {
  source = "../../module/nsg_subnet_association"
  subnet_id=module.subnet_module_sn_glb_prod_z1b_edmz.subnet_id
  nsg_id=module.nsg_module_sn_glb_prod_z1b_edmz.nsg_id
  depends_on =[module.nsg_module_sn_glb_prod_z1b_edmz,module.subnet_module_sn_glb_prod_z1b_edmz]
    
}
# module "nsg_association_module_glb_prod_z1b_sox" {
#   source = "../../module/nsg_subnet_association"
#   subnet_id=module.subnet_module_sn_glb_prod_z1b_sox.subnet_id
#   nsg_id=module.nsg_module_sn_glb_prod_z1b_sox.nsg_id
#   depends_on =[module.nsg_module_sn_glb_prod_z1b_sox,module.subnet_module_sn_glb_prod_z1b_sox]
    
# }
#----------z3 Nsg association-------------------------------------------------
module "nsg_association_module_glb_prod_z3_int" {
  source = "../../module/nsg_subnet_association"
  subnet_id=module.subnet_module_sn_glb_prod_z3_int.subnet_id
  nsg_id=module.nsg_module_sn_glb_prod_z3_int.nsg_id
  depends_on =[module.nsg_module_sn_glb_prod_z3_int,module.subnet_module_sn_glb_prod_z3_int]
    
}
module "nsg_association_module_glb_prod_z3_idmz" {
  source = "../../module/nsg_subnet_association"
  subnet_id=module.subnet_module_sn_glb_prod_z3_idmz.subnet_id
  nsg_id=module.nsg_module_sn_glb_prod_z3_idmz.nsg_id
  depends_on =[module.nsg_module_sn_glb_prod_z3_idmz,module.subnet_module_sn_glb_prod_z3_idmz]
    
}
module "nsg_association_module_glb_prod_z3_edmz" {
  source = "../../module/nsg_subnet_association"
  subnet_id=module.subnet_module_sn_glb_prod_z3_edmz.subnet_id
  nsg_id=module.nsg_module_sn_glb_prod_z3_edmz.nsg_id
  depends_on =[module.nsg_module_sn_glb_prod_z3_edmz,module.subnet_module_sn_glb_prod_z3_edmz]
    
}
#----------z1b Nsg association-------------------------------------------------
module "nsg_association_module_glb_prod_z1c_int" {
  source = "../../module/nsg_subnet_association"
  subnet_id=module.subnet_module_sn_glb_prod_z1c_int.subnet_id
  nsg_id=module.nsg_module_sn_glb_prod_z1c_int.nsg_id
  depends_on =[module.nsg_module_sn_glb_prod_z1c_int,module.subnet_module_sn_glb_prod_z1c_int]
    
}
module "nsg_association_module_glb_prod_z1c_idmz" {
  source = "../../module/nsg_subnet_association"
  subnet_id=module.subnet_module_sn_glb_prod_z1c_idmz.subnet_id
  nsg_id=module.nsg_module_sn_glb_prod_z1c_idmz.nsg_id
  depends_on =[module.nsg_module_sn_glb_prod_z1c_idmz,module.subnet_module_sn_glb_prod_z1c_idmz]
    
}
module "nsg_association_module_glb_prod_z1c_edmz" {
  source = "../../module/nsg_subnet_association"
  subnet_id=module.subnet_module_sn_glb_prod_z1c_edmz.subnet_id
  nsg_id=module.nsg_module_sn_glb_prod_z1c_edmz.nsg_id
  depends_on =[module.nsg_module_sn_glb_prod_z1c_edmz,module.subnet_module_sn_glb_prod_z1c_edmz]
    
}
# module "nsg_association_module_glb_prod_z1c_mgmt" {
#   source = "../../module/nsg_subnet_association"
#   subnet_id=module.subnet_module_sn_glb_prod_z1c_mgmt.subnet_id
#   nsg_id=module.nsg_module_sn_glb_prod_z1c_mgmt.nsg_id
#   depends_on =[module.nsg_module_sn_glb_prod_z1c_mgmt,module.subnet_module_sn_glb_prod_z1c_mgmt]
    
# }
# module "nsg_association_module_glb_prod_z1c_ad" {
#   source = "../../module/nsg_subnet_association"
#   subnet_id=module.subnet_module_sn_glb_prod_z1c_ad.subnet_id
#   nsg_id=module.nsg_module_sn_glb_prod_z1c_ad.nsg_id
#   depends_on =[module.nsg_module_sn_glb_prod_z1c_ad,module.subnet_module_sn_glb_prod_z1c_ad]
    
# }
# #--------------------------------------------------------------SN GLB Prod Route table creation---------------------------------------------------------------
# #output variables for this block is {route_table_name_output and route_table_id}
##-------Z1a route table-------------------------------------------------------------------------------
module "route_table_module_glb_prod_z1a_int" {
  source = "../../module/route_table_creation"
  route_table_name=var.route_table_name_glb_prod_z1a_int
  location=module.rg_module_sn_glb_prod_1.rg_location
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  bgp_route_propagation=var.bgp_route_propagations
  route_tags=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
module "route_table_module_glb_prod_z1a_idmz" {
  source = "../../module/route_table_creation"
  route_table_name=var.route_table_name_glb_prod_z1a_idmz
  location=module.rg_module_sn_glb_prod_1.rg_location
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  bgp_route_propagation=var.bgp_route_propagations
  route_tags=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
module "route_table_module_glb_prod_z1a_edmz" {
  source = "../../module/route_table_creation"
  route_table_name=var.route_table_name_glb_prod_z1a_edmz
  location=module.rg_module_sn_glb_prod_1.rg_location
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  bgp_route_propagation=var.bgp_route_propagations
  route_tags=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
##-------Z1b route table-------------------------------------------------------
module "route_table_module_glb_prod_z1b_int" {
  source = "../../module/route_table_creation"
  route_table_name=var.route_table_name_glb_prod_z1b_int
  location=module.rg_module_sn_glb_prod_1.rg_location
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  bgp_route_propagation=var.bgp_route_propagations
  route_tags=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
module "route_table_module_glb_prod_z1b_idmz" {
  source = "../../module/route_table_creation"
  route_table_name=var.route_table_name_glb_prod_z1b_idmz
  location=module.rg_module_sn_glb_prod_1.rg_location
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  bgp_route_propagation=var.bgp_route_propagations
  route_tags=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
module "route_table_module_glb_prod_z1b_edmz" {
  source = "../../module/route_table_creation"
  route_table_name=var.route_table_name_glb_prod_z1b_edmz
  location=module.rg_module_sn_glb_prod_1.rg_location
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  bgp_route_propagation=var.bgp_route_propagations
  route_tags=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
module "route_table_module_glb_prod_z1b_sox" {
  source = "../../module/route_table_creation"
  route_table_name=var.route_table_name_glb_prod_z1b_sox
  location=module.rg_module_sn_glb_prod_1.rg_location
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  bgp_route_propagation=var.bgp_route_propagations
  route_tags=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
##-------Z3 route table-------------------------------------------------------------------------------
module "route_table_module_glb_prod_z3_int" {
  source = "../../module/route_table_creation"
  route_table_name=var.route_table_name_glb_prod_z3_int
  location=module.rg_module_sn_glb_prod_1.rg_location
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  bgp_route_propagation=var.bgp_route_propagations
  route_tags=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
module "route_table_module_glb_prod_z3_idmz" {
  source = "../../module/route_table_creation"
  route_table_name=var.route_table_name_glb_prod_z3_idmz
  location=module.rg_module_sn_glb_prod_1.rg_location
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  bgp_route_propagation=var.bgp_route_propagations
  route_tags=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
module "route_table_module_glb_prod_z3_edmz" {
  source = "../../module/route_table_creation"
  route_table_name=var.route_table_name_glb_prod_z3_edmz
  location=module.rg_module_sn_glb_prod_1.rg_location
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  bgp_route_propagation=var.bgp_route_propagations
  route_tags=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
##-------Z1c route table---------------------------------------------------------------------------------
module "route_table_module_glb_prod_z1c_int" {
  source = "../../module/route_table_creation"
  route_table_name=var.route_table_name_glb_prod_z1c_int
  location=module.rg_module_sn_glb_prod_1.rg_location
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  bgp_route_propagation=var.bgp_route_propagations
  route_tags=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
module "route_table_module_glb_prod_z1c_idmz" {
  source = "../../module/route_table_creation"
  route_table_name=var.route_table_name_glb_prod_z1c_idmz
  location=module.rg_module_sn_glb_prod_1.rg_location
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  bgp_route_propagation=var.bgp_route_propagations
  route_tags=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
module "route_table_module_glb_prod_z1c_edmz" {
  source = "../../module/route_table_creation"
  route_table_name=var.route_table_name_glb_prod_z1c_edmz
  location=module.rg_module_sn_glb_prod_1.rg_location
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  bgp_route_propagation=var.bgp_route_propagations
  route_tags=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
module "route_table_module_glb_prod_z1c_mgmt" {
  source = "../../module/route_table_creation"
  route_table_name=var.route_table_name_glb_prod_z1c_mgmt
  location=module.rg_module_sn_glb_prod_1.rg_location
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  bgp_route_propagation=var.bgp_route_propagations
  route_tags=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
module "route_table_module_glb_prod_z1c_ad" {
  source = "../../module/route_table_creation"
  route_table_name=var.route_table_name_glb_prod_z1c_ad
  location=module.rg_module_sn_glb_prod_1.rg_location
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  bgp_route_propagation=var.bgp_route_propagations
  route_tags=var.tags
  depends_on =[module.rg_module_sn_glb_prod_1]
}
#---------------------------------------------------------SN GLB Prod Route table association-------------------------------------------------------------
#------------Z1a Route Table Association--------------------------------------------------
module "route_table_association_module_glb_prod_z1a_int" {
  source = "../../module/route_table_association"
  subnet_id=module.subnet_module_sn_glb_prod_z1a_int.subnet_id
  route_table_id=module.route_table_module_glb_prod_z1a_int.route_table_id
  depends_on = [module.route_table_module_glb_prod_z1a_int,module.subnet_module_sn_glb_prod_z1a_int]
}
module "route_table_association_module_glb_prod_z1a_idmz" {
  source = "../../module/route_table_association"
  subnet_id=module.subnet_module_sn_glb_prod_z1a_idmz.subnet_id
  route_table_id=module.route_table_module_glb_prod_z1a_idmz.route_table_id
  depends_on = [module.route_table_module_glb_prod_z1a_idmz,module.subnet_module_sn_glb_prod_z1a_idmz]
}
module "route_table_association_module_glb_prod_z1a_edmz" {
  source = "../../module/route_table_association"
  subnet_id=module.subnet_module_sn_glb_prod_z1a_edmz.subnet_id
  route_table_id=module.route_table_module_glb_prod_z1a_edmz.route_table_id
  depends_on = [module.route_table_module_glb_prod_z1a_edmz,module.subnet_module_sn_glb_prod_z1a_edmz]
}
#------------Z1b Route Table Association--------------------------------------------------
module "route_table_association_module_glb_prod_z1b_int" {
  source = "../../module/route_table_association"
  subnet_id=module.subnet_module_sn_glb_prod_z1b_int.subnet_id
  route_table_id=module.route_table_module_glb_prod_z1b_int.route_table_id
  depends_on = [module.route_table_module_glb_prod_z1b_int,module.subnet_module_sn_glb_prod_z1b_int]
}
module "route_table_association_module_glb_prod_z1b_idmz" {
  source = "../../module/route_table_association"
  subnet_id=module.subnet_module_sn_glb_prod_z1b_idmz.subnet_id
  route_table_id=module.route_table_module_glb_prod_z1b_idmz.route_table_id
  depends_on = [module.route_table_module_glb_prod_z1b_idmz,module.subnet_module_sn_glb_prod_z1b_idmz]
}
module "route_table_association_module_glb_prod_z1b_edmz" {
  source = "../../module/route_table_association"
  subnet_id=module.subnet_module_sn_glb_prod_z1b_edmz.subnet_id
  route_table_id=module.route_table_module_glb_prod_z1b_edmz.route_table_id
  depends_on = [module.route_table_module_glb_prod_z1b_edmz,module.subnet_module_sn_glb_prod_z1b_edmz]
}
#------------Z3 Route Table Association--------------------------------------------------
module "route_table_association_module_glb_prod_z3_int" {
  source = "../../module/route_table_association"
  subnet_id=module.subnet_module_sn_glb_prod_z3_int.subnet_id
  route_table_id=module.route_table_module_glb_prod_z3_int.route_table_id
  depends_on = [module.route_table_module_glb_prod_z3_int,module.subnet_module_sn_glb_prod_z3_int]
}
module "route_table_association_module_glb_prod_z3_idmz" {
  source = "../../module/route_table_association"
  subnet_id=module.subnet_module_sn_glb_prod_z3_idmz.subnet_id
  route_table_id=module.route_table_module_glb_prod_z3_idmz.route_table_id
  depends_on = [module.route_table_module_glb_prod_z3_idmz,module.subnet_module_sn_glb_prod_z3_idmz]
}
module "route_table_association_module_glb_prod_z3_edmz" {
  source = "../../module/route_table_association"
  subnet_id=module.subnet_module_sn_glb_prod_z3_edmz.subnet_id
  route_table_id=module.route_table_module_glb_prod_z3_edmz.route_table_id
  depends_on = [module.route_table_module_glb_prod_z3_edmz,module.subnet_module_sn_glb_prod_z3_edmz]
}
#------------Z1c Route Table Association--------------------------------------------------
module "route_table_association_module_glb_prod_z1c_int" {
  source = "../../module/route_table_association"
  subnet_id=module.subnet_module_sn_glb_prod_z1c_int.subnet_id
  route_table_id=module.route_table_module_glb_prod_z1c_int.route_table_id
  depends_on = [module.route_table_module_glb_prod_z1c_int,module.subnet_module_sn_glb_prod_z1c_int]
}
module "route_table_association_module_glb_prod_z1c_idmz" {
  source = "../../module/route_table_association"
  subnet_id=module.subnet_module_sn_glb_prod_z1c_idmz.subnet_id
  route_table_id=module.route_table_module_glb_prod_z1c_idmz.route_table_id
  depends_on = [module.route_table_module_glb_prod_z1c_idmz,module.subnet_module_sn_glb_prod_z1c_idmz]
}
module "route_table_association_module_glb_prod_z1c_edmz" {
  source = "../../module/route_table_association"
  subnet_id=module.subnet_module_sn_glb_prod_z1c_edmz.subnet_id
  route_table_id=module.route_table_module_glb_prod_z1c_edmz.route_table_id
  depends_on = [module.route_table_module_glb_prod_z1c_edmz,module.subnet_module_sn_glb_prod_z1c_edmz]
}
# module "route_table_association_module_glb_prod_z1c_mgmt" {
#   source = "../../module/route_table_association"
#   subnet_id=module.subnet_module_sn_glb_prod_z1c_mgmt.subnet_id
#   route_table_id=module.route_table_module_glb_prod_z1c_mgmt.route_table_id
#   depends_on = [module.route_table_module_glb_prod_z1c_mgmt,module.subnet_module_sn_glb_prod_z1c_mgmt]
# }
# module "route_table_association_module_glb_prod_z1c_ad" {
#   source = "../../module/route_table_association"
#   subnet_id=module.subnet_module_sn_glb_prod_z1c_ad.subnet_id
#   route_table_id=module.route_table_module_glb_prod_z1c_ad.route_table_id
#   depends_on = [module.route_table_module_glb_prod_z1c_ad,module.subnet_module_sn_glb_prod_z1c_ad]
# }
# ..................ROUTABLE ROUTES..................................................
# z1a
module "routes_module_sn_glb_prod_z1A_int_iboss" {
  source = "../../module/route_table_routes"
  route_name=var.route_name_sn_glb_prod_iboss
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  route_table_name=module.route_table_module_glb_prod_z1a_int.route_table_name_output 
  route_address_prefix=var.route_addressPrefix_sn_glb_prod_iboss
  next_hop_type=var.route_nextHopType_sn_glb_prod_iboss
  depends_on =[module.rg_module_sn_glb_prod_1.rg_name,module.route_table_module_glb_prod_z1a_int]
}
module "routes_module_sn_glb_prod_z1A_idmz_iboss" {
  source = "../../module/route_table_routes"
  route_name=var.route_name_sn_glb_prod_iboss
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  route_table_name=module.route_table_module_glb_prod_z1a_idmz.route_table_name_output 
  route_address_prefix=var.route_addressPrefix_sn_glb_prod_iboss
  next_hop_type=var.route_nextHopType_sn_glb_prod_iboss
  depends_on =[module.rg_module_sn_glb_prod_1.rg_name,module.route_table_module_glb_prod_z1a_idmz]
}
module "routes_module_sn_glb_prod_z1A_edmz_iboss" {
  source = "../../module/route_table_routes"
  route_name=var.route_name_sn_glb_prod_iboss
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  route_table_name=module.route_table_module_glb_prod_z1a_edmz.route_table_name_output 
  route_address_prefix=var.route_addressPrefix_sn_glb_prod_iboss
  next_hop_type=var.route_nextHopType_sn_glb_prod_iboss
  depends_on =[module.rg_module_sn_glb_prod_1.rg_name,module.route_table_module_glb_prod_z1a_edmz]
}
# z1b
module "routes_module_sn_glb_prod_z1b_int_iboss" {
  source = "../../module/route_table_routes"
  route_name=var.route_name_sn_glb_prod_iboss
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  route_table_name=module.route_table_module_glb_prod_z1b_int.route_table_name_output 
  route_address_prefix=var.route_addressPrefix_sn_glb_prod_iboss
  next_hop_type=var.route_nextHopType_sn_glb_prod_iboss
  depends_on =[module.rg_module_sn_glb_prod_1.rg_name,module.route_table_module_glb_prod_z1b_int]
}
module "routes_module_sn_glb_prod_z1b_idmz_iboss" {
  source = "../../module/route_table_routes"
  route_name=var.route_name_sn_glb_prod_iboss
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  route_table_name=module.route_table_module_glb_prod_z1b_idmz.route_table_name_output 
  route_address_prefix=var.route_addressPrefix_sn_glb_prod_iboss
  next_hop_type=var.route_nextHopType_sn_glb_prod_iboss
  depends_on =[module.rg_module_sn_glb_prod_1.rg_name,module.route_table_module_glb_prod_z1b_idmz]
}
module "routes_module_sn_glb_prod_z1b_edmz_iboss" {
  source = "../../module/route_table_routes"
  route_name=var.route_name_sn_glb_prod_iboss
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  route_table_name=module.route_table_module_glb_prod_z1b_edmz.route_table_name_output 
  route_address_prefix=var.route_addressPrefix_sn_glb_prod_iboss
  next_hop_type=var.route_nextHopType_sn_glb_prod_iboss
  depends_on =[module.rg_module_sn_glb_prod_1.rg_name,module.route_table_module_glb_prod_z1b_edmz]
}
# z3
module "routes_module_sn_glb_prod_z3_int_iboss" {
  source = "../../module/route_table_routes"
  route_name=var.route_name_sn_glb_prod_iboss
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  route_table_name=module.route_table_module_glb_prod_z3_int.route_table_name_output 
  route_address_prefix=var.route_addressPrefix_sn_glb_prod_iboss
  next_hop_type=var.route_nextHopType_sn_glb_prod_iboss
  depends_on =[module.rg_module_sn_glb_prod_1.rg_name,module.route_table_module_glb_prod_z3_int]
}
module "routes_module_sn_glb_prod_z3_idmz_iboss" {
  source = "../../module/route_table_routes"
  route_name=var.route_name_sn_glb_prod_iboss
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  route_table_name=module.route_table_module_glb_prod_z3_idmz.route_table_name_output 
  route_address_prefix=var.route_addressPrefix_sn_glb_prod_iboss
  next_hop_type=var.route_nextHopType_sn_glb_prod_iboss
  depends_on =[module.rg_module_sn_glb_prod_1.rg_name,module.route_table_module_glb_prod_z3_idmz]
}
module "routes_module_sn_glb_prod_z3_edmz_iboss" {
  source = "../../module/route_table_routes"
  route_name=var.route_name_sn_glb_prod_iboss
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  route_table_name=module.route_table_module_glb_prod_z3_edmz.route_table_name_output 
  route_address_prefix=var.route_addressPrefix_sn_glb_prod_iboss
  next_hop_type=var.route_nextHopType_sn_glb_prod_iboss
  depends_on =[module.rg_module_sn_glb_prod_1.rg_name,module.route_table_module_glb_prod_z3_edmz]
}
# z1c
module "routes_module_sn_glb_prod_z1c_int_iboss" {
  source = "../../module/route_table_routes"
  route_name=var.route_name_sn_glb_prod_iboss
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  route_table_name=module.route_table_module_glb_prod_z1c_int.route_table_name_output 
  route_address_prefix=var.route_addressPrefix_sn_glb_prod_iboss
  next_hop_type=var.route_nextHopType_sn_glb_prod_iboss
  depends_on =[module.rg_module_sn_glb_prod_1.rg_name,module.route_table_module_glb_prod_z1c_int]
}
module "routes_module_sn_glb_prod_z1c_idmz_iboss" {
  source = "../../module/route_table_routes"
  route_name=var.route_name_sn_glb_prod_iboss
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  route_table_name=module.route_table_module_glb_prod_z1c_idmz.route_table_name_output 
  route_address_prefix=var.route_addressPrefix_sn_glb_prod_iboss
  next_hop_type=var.route_nextHopType_sn_glb_prod_iboss
  depends_on =[module.rg_module_sn_glb_prod_1.rg_name,module.route_table_module_glb_prod_z1c_idmz]
}
module "routes_module_sn_glb_prod_z1c_edmz_iboss" {
  source = "../../module/route_table_routes"
  route_name=var.route_name_sn_glb_prod_iboss
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  route_table_name=module.route_table_module_glb_prod_z1c_edmz.route_table_name_output 
  route_address_prefix=var.route_addressPrefix_sn_glb_prod_iboss
  next_hop_type=var.route_nextHopType_sn_glb_prod_iboss
  depends_on =[module.rg_module_sn_glb_prod_1.rg_name,module.route_table_module_glb_prod_z1c_edmz]
}
# .............keyvault creation........................................
module "keyvault_creation" {
  source ="../../module/keyvault_creation"
  rg_name=module.rg_module_sn_glb_prod_2.rg_name
  location=module.rg_module_sn_glb_prod_2.rg_location
  object_id= var.object_id
  keyvault_name=var.keyvault_name
  sku_name=var.sku
  tags=var.tags_app
  soft_delete_retention_days=var.soft_retention_days
  }
  # module "keyvault_creation01" {
  # source ="../../module/keyvault_creation"
  # rg_name=module.rg_module_sn_glb_prod_2.rg_name
  # location=module.rg_module_sn_glb_prod_2.rg_location
  # object_id= var.object_id
  # keyvault_name=var.keyvault_name01
  # sku_name=var.sku
  # tags=var.tags_app
  # soft_delete_retention_days=var.soft_retention_days
  # }
  module "accesspolicy_keyvault"{
    source ="../../module/add_accesspolicies"
    object_ids= var.object_id_01
    keyvault_id=module.keyvault_creation.keyvault_id
    depends_on=[module.keyvault_creation]
  }

  module "accesspolicy_keyvault01"{
    source ="../../module/add_accesspolicies"
    object_ids= var.object_id_02
    keyvault_id=module.keyvault_creation.keyvault_id
    depends_on=[module.keyvault_creation]
  }
  # .....................routetableroute....................................................
module "routes_module_sn_glb_prod_z1a_int_cp" {
source ="../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_prod_cp
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1a_int.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_z1a_cp
next_hop_type=var.route_nextHopType_sn_glb_prod_cp
nexthop_in_ip_address=var.nxthopip_cp
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1a_int]
}
module "routes_module_sn_glb_prod_z1a_idmz_cp" {
source="../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_prod_cp
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1a_idmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_z1a_cp
next_hop_type=var.route_nextHopType_sn_glb_prod_cp
nexthop_in_ip_address=var.nxthopip_cp
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1a_idmz]
}
module "routes_module_sn_glb_prod_z1a_edmz_cp" {
source = "../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_prod_cp
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1a_edmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_z1a_cp
next_hop_type=var.route_nextHopType_sn_glb_prod_cp
nexthop_in_ip_address=var.nxthopip_cp
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1a_edmz]
}
# .............zone1b..............................................
module "routes_module_sn_glb_prod_z1b_int_cp" {
source ="../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_prod_cp
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1b_int.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_z1b_cp
next_hop_type=var.route_nextHopType_sn_glb_prod_cp
nexthop_in_ip_address=var.nxthopip_cp
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1b_int]
}
module "routes_module_sn_glb_prod_z1b_idmz_cp" {
source ="../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_prod_cp
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1b_idmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_z1b_cp
next_hop_type=var.route_nextHopType_sn_glb_prod_cp
nexthop_in_ip_address=var.nxthopip_cp
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1b_idmz]
}
module "routes_module_sn_glb_prod_z1b_edmz_cp" {
source = "../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_prod_cp
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1b_edmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_z1b_cp
next_hop_type=var.route_nextHopType_sn_glb_prod_cp
nexthop_in_ip_address=var.nxthopip_cp
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1b_edmz]
}
# .............zone3..............................................
module "routes_module_sn_glb_prod_z3_int_cp" {
source ="../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_prod_cp
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z3_int.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_z3_cp
next_hop_type=var.route_nextHopType_sn_glb_prod_cp
nexthop_in_ip_address=var.nxthopip_cp
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z3_int]
}
module "routes_module_sn_glb_prod_z3_idmz_cp" {
source ="../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_prod_cp
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z3_idmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_z3_cp
next_hop_type=var.route_nextHopType_sn_glb_prod_cp
nexthop_in_ip_address=var.nxthopip_cp
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z3_idmz]
}
module "routes_module_sn_glb_prod_z3_edmz_cp" {
source = "../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_prod_cp
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z3_edmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_z3_cp
next_hop_type=var.route_nextHopType_sn_glb_prod_cp
nexthop_in_ip_address=var.nxthopip_cp
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z3_edmz]
}
# .............zone1c..............................................
module "routes_module_sn_glb_prod_z1c_int_cp" {
source ="../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_prod_cp
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1c_int.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_z1c_cp
next_hop_type=var.route_nextHopType_sn_glb_prod_cp
nexthop_in_ip_address=var.nxthopip_cp
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1c_int]
}
module "routes_module_sn_glb_prod_z1c_idmz_cp" {
source ="../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_prod_cp
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1c_idmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_z1c_cp
next_hop_type=var.route_nextHopType_sn_glb_prod_cp
nexthop_in_ip_address=var.nxthopip_cp
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1c_idmz]
}
module "routes_module_sn_glb_prod_z1c_edmz_cp" {
source = "../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_prod_cp
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1c_edmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_z1c_cp
next_hop_type=var.route_nextHopType_sn_glb_prod_cp
nexthop_in_ip_address=var.nxthopip_cp
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1c_edmz]
}
# .............intfw................................................

module "routes_module_sn_glb_prod_z1a_int_cp_intfw" {
source ="../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_prod_cp_intfw
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1a_int.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_intfw
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_intfw
nexthop_in_ip_address=var.nxthopip_cp_intfw
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1a_int]
}
module "routes_module_sn_glb_prod_z1a_idmz_cp_intfw" {
source="../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_prod_cp_intfw
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1a_idmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_intfw
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_intfw
nexthop_in_ip_address=var.nxthopip_cp_intfw
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1a_idmz]
}
module "routes_module_sn_glb_prod_z1a_edmz_cp_intfw" {
source = "../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_prod_cp_intfw
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1a_edmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_intfw
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_intfw
nexthop_in_ip_address=var.nxthopip_cp_intfw
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1a_edmz]
}
# .............zone1b..............................................
module "routes_module_sn_glb_prod_z1b_int_cp_intfw" {
source ="../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_prod_cp_intfw
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1b_int.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_intfw
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_intfw
nexthop_in_ip_address=var.nxthopip_cp_intfw
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1b_int]
}
module "routes_module_sn_glb_prod_z1b_idmz_cp_intfw" {
source ="../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_prod_cp_intfw
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1b_idmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_intfw
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_intfw
nexthop_in_ip_address=var.nxthopip_cp_intfw
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1b_idmz]
}
module "routes_module_sn_glb_prod_z1b_edmz_cp_intfw" {
source = "../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_prod_cp_intfw
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1b_edmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_intfw
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_intfw
nexthop_in_ip_address=var.nxthopip_cp_intfw
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1b_edmz]
}
# # .............zone3..............................................
module "routes_module_sn_glb_prod_z3_int_cp_intfw" {
source ="../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_prod_cp_intfw
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z3_int.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_intfw
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_intfw
nexthop_in_ip_address=var.nxthopip_cp_intfw
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z3_int]
}
module "routes_module_sn_glb_prod_z3_idmz_cp_intfw" {
source ="../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_prod_cp_intfw
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z3_idmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_intfw
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_intfw
nexthop_in_ip_address=var.nxthopip_cp_intfw
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z3_idmz]
}
module "routes_module_sn_glb_prod_z3_edmz_cp_intfw" {
source = "../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_prod_cp_intfw
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z3_edmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_intfw
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_intfw
nexthop_in_ip_address=var.nxthopip_cp_intfw
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z3_edmz]
}
# # .............zone1c..............................................
module "routes_module_sn_glb_prod_z1c_int_cp_intfw" {
source ="../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_prod_cp_intfw
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1c_int.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_intfw
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_intfw
nexthop_in_ip_address=var.nxthopip_cp_intfw
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1c_int]
}
module "routes_module_sn_glb_prod_z1c_idmz_cp_intfw" {
source ="../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_prod_cp_intfw
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1c_idmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_intfw
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_intfw
nexthop_in_ip_address=var.nxthopip_cp_intfw
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1c_idmz]
}
module "routes_module_sn_glb_prod_z1c_edmz_cp_intfw" {
source = "../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_prod_cp_intfw
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1c_edmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_intfw
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_intfw
nexthop_in_ip_address=var.nxthopip_cp_intfw
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1c_edmz]
}
# .......................ROUTABLE ROUTES ABB NETWORK...................................
module "routes_module_sn_glb_prod_z1a_int_cp_abbnetwork" {
source ="../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_prod_cp_abbnetwork
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1a_int.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_abbnetwork
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_abbnetwork
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1a_int]
}
module "routes_module_sn_glb_prod_z1a_idmz_cp_abbnetwork" {
source="../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_prod_cp_abbnetwork
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1a_idmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_abbnetwork
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_abbnetwork
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1a_idmz]
}
module "routes_module_sn_glb_prod_z1a_edmz_cp_abbnetwork" {
source = "../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_prod_cp_abbnetwork
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1a_edmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_abbnetwork
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_abbnetwork
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1a_edmz]
}
# .............zone1b..............................................
module "routes_module_sn_glb_prod_z1b_int_cp_abbnetwork" {
source ="../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_prod_cp_abbnetwork
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1b_int.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_abbnetwork
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_abbnetwork
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1b_int]
}
module "routes_module_sn_glb_prod_z1b_idmz_cp_abbnetwork" {
source ="../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_prod_cp_abbnetwork
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1b_idmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_abbnetwork
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_abbnetwork
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1b_idmz]
}
module "routes_module_sn_glb_prod_z1b_edmz_cp_abbnetwork" {
source = "../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_prod_cp_abbnetwork
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1b_edmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_abbnetwork
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_abbnetwork
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1b_edmz]
}
# .............zone3..............................................
module "routes_module_sn_glb_prod_z3_int_cp_abbnetwork" {
source ="../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_prod_cp_abbnetwork
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z3_int.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_abbnetwork
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_abbnetwork
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z3_int]
}
module "routes_module_sn_glb_prod_z3_idmz_cp_abbnetwork" {
source ="../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_prod_cp_abbnetwork
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z3_idmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_abbnetwork
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_abbnetwork
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z3_idmz]
}
module "routes_module_sn_glb_prod_z3_edmz_cp_abbnetwork" {
source = "../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_prod_cp_abbnetwork
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z3_edmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_abbnetwork
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_abbnetwork
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z3_edmz]
}
# .............zone1c..............................................
module "routes_module_sn_glb_prod_z1c_int_cp_abbnetwork" {
source ="../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_prod_cp_abbnetwork
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1c_int.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_abbnetwork
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_abbnetwork
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1c_int]
}
module "routes_module_sn_glb_prod_z1c_idmz_cp_abbnetwork" {
source ="../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_prod_cp_abbnetwork
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1c_idmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_abbnetwork
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_abbnetwork
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1c_idmz]
}
module "routes_module_sn_glb_prod_z1c_edmz_cp_abbnetwork" {
source = "../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_prod_cp_abbnetwork
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1c_edmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_abbnetwork
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_abbnetwork
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1c_edmz]
}
# .....................abbnw02....................................
module "routes_module_sn_glb_prod_z1a_int_cp_abbnetwork01" {
source ="../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_prod_cp_abbnetwork01
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1a_int.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_abbnetwork01
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_abbnetwork01
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork01
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1a_int]
}
module "routes_module_sn_glb_prod_z1a_idmz_cp_abbnetwork01" {
source="../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_prod_cp_abbnetwork01
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1a_idmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_abbnetwork01
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_abbnetwork01
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork01
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1a_idmz]
}
module "routes_module_sn_glb_prod_z1a_edmz_cp_abbnetwork01" {
source = "../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_prod_cp_abbnetwork01
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1a_edmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_abbnetwork01
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_abbnetwork01
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork01
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1a_edmz]
}
# .............zone1b..............................................
module "routes_module_sn_glb_prod_z1b_int_cp_abbnetwork01" {
source ="../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_prod_cp_abbnetwork01
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1b_int.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_abbnetwork01
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_abbnetwork01
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork01
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1b_int]
}
module "routes_module_sn_glb_prod_z1b_idmz_cp_abbnetwork01" {
source ="../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_prod_cp_abbnetwork01
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1b_idmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_abbnetwork01
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_abbnetwork01
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork01
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1b_idmz]
}
module "routes_module_sn_glb_prod_z1b_edmz_cp_abbnetwork01" {
source = "../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_prod_cp_abbnetwork01
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1b_edmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_abbnetwork01
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_abbnetwork01
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork01
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1b_edmz]
}
# .............zone3..............................................
module "routes_module_sn_glb_prod_z3_int_cp_abbnetwork01" {
source ="../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_prod_cp_abbnetwork01
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z3_int.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_abbnetwork01
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_abbnetwork01
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork01
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z3_int]
}
module "routes_module_sn_glb_prod_z3_idmz_cp_abbnetwork01" {
source ="../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_prod_cp_abbnetwork01
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z3_idmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_abbnetwork01
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_abbnetwork01
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork01
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z3_idmz]
}
module "routes_module_sn_glb_prod_z3_edmz_cp_abbnetwork01" {
source = "../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_prod_cp_abbnetwork01
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z3_edmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_abbnetwork01
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_abbnetwork01
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork01
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z3_edmz]
}
# .............zone1c..............................................
module "routes_module_sn_glb_prod_z1c_int_cp_abbnetwork01" {
source ="../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_prod_cp_abbnetwork01
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1c_int.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_abbnetwork01
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_abbnetwork01
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork01
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1c_int]
}
module "routes_module_sn_glb_prod_z1c_idmz_cp_abbnetwork01" {
source ="../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_prod_cp_abbnetwork01
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1c_idmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_abbnetwork01
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_abbnetwork01
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork01
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1c_idmz]
}
module "routes_module_sn_glb_prod_z1c_edmz_cp_abbnetwork01" {
source = "../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_prod_cp_abbnetwork01
resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
route_table_name=module.route_table_module_glb_prod_z1c_edmz.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_prod_cp_abbnetwork01
next_hop_type=var.route_nextHopType_sn_glb_prod_cp_abbnetwork01
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork01
depends_on =[module.rg_module_sn_glb_prod_1,module.route_table_module_glb_prod_z1c_edmz]
}
# ...........log analytics workspace reuse.........................................
module "logaalyticsworkspace_reuse"{
  providers={
    azurerm=azurerm.sn_hub
  }
  source="../../module/law_reuse"
  law_name=var.loganalytics_name
  law_rg=var.loganalytics_rg
}
# ...................nsg flow log.....................................................................
module "nsgflowlog_01"{
source = "../../module/nsg_flowlog"
networkwatcher_name=var.networkwatcher_name
nw_resourcegroup_name=var.networkwatcher_rg
nsg_id=[module.nsg_module_sn_glb_prod_z1a_int.nsg_id,module.nsg_module_sn_glb_prod_z1a_idmz.nsg_id,module.nsg_module_sn_glb_prod_z1a_edmz.nsg_id,module.nsg_module_sn_glb_prod_z1b_int.nsg_id,module.nsg_module_sn_glb_prod_z1b_idmz.nsg_id,module.nsg_module_sn_glb_prod_z1b_edmz.nsg_id,module.nsg_module_sn_glb_prod_z3_int.nsg_id,module.nsg_module_sn_glb_prod_z3_idmz.nsg_id,module.nsg_module_sn_glb_prod_z3_edmz.nsg_id,module.nsg_module_sn_glb_prod_z1c_int.nsg_id,module.nsg_module_sn_glb_prod_z1c_idmz.nsg_id,module.nsg_module_sn_glb_prod_z1c_edmz.nsg_id]
storage_account_id=module.storageaccount_module_glb_prod_02.sta_id
retention_days=var.retention_days
flow_version=var.fversion
workspace_id=module.logaalyticsworkspace_reuse.law
location=module.rg_module_sn_glb_prod_3.rg_location
workspace_rs_id=module.logaalyticsworkspace_reuse.workspace_resource_id
minutes=var.flow_analytics
}
# .............diagnostic settings......................................................................
# ................nsg.....................................
module "nsg_diagnostics"{
source = "../../module/diagnosticsettings"
resource_id=[module.nsg_module_sn_glb_prod_z1a_int.nsg_id,module.nsg_module_sn_glb_prod_z1a_idmz.nsg_id,module.nsg_module_sn_glb_prod_z1a_edmz.nsg_id,module.nsg_module_sn_glb_prod_z1b_int.nsg_id,module.nsg_module_sn_glb_prod_z1b_idmz.nsg_id,module.nsg_module_sn_glb_prod_z1b_edmz.nsg_id,module.nsg_module_sn_glb_prod_z3_int.nsg_id,module.nsg_module_sn_glb_prod_z3_idmz.nsg_id,module.nsg_module_sn_glb_prod_z3_edmz.nsg_id,module.nsg_module_sn_glb_prod_z1c_int.nsg_id,module.nsg_module_sn_glb_prod_z1c_idmz.nsg_id,module.nsg_module_sn_glb_prod_z1c_edmz.nsg_id]
dlog_name=var.diagnosticsettings_nsg
target_id=[module.nsg_module_sn_glb_prod_z1a_int.nsg_id,module.nsg_module_sn_glb_prod_z1a_idmz.nsg_id,module.nsg_module_sn_glb_prod_z1a_edmz.nsg_id,module.nsg_module_sn_glb_prod_z1b_int.nsg_id,module.nsg_module_sn_glb_prod_z1b_idmz.nsg_id,module.nsg_module_sn_glb_prod_z1b_edmz.nsg_id,module.nsg_module_sn_glb_prod_z3_int.nsg_id,module.nsg_module_sn_glb_prod_z3_idmz.nsg_id,module.nsg_module_sn_glb_prod_z3_edmz.nsg_id,module.nsg_module_sn_glb_prod_z1c_int.nsg_id,module.nsg_module_sn_glb_prod_z1c_idmz.nsg_id,module.nsg_module_sn_glb_prod_z1c_edmz.nsg_id]
storage_acc_id =module.storageaccount_module_glb_prod_02.sta_id
workspace_rs_id =module.logaalyticsworkspace_reuse.workspace_resource_id
}
module "rsv_diagnostics"{
source = "../../module/diagnosticsettings"
resource_id=[module.recovery_service_vault.rsv_id]
dlog_name=var.diagnosticsettings_rsv
target_id=[module.recovery_service_vault.rsv_id]
storage_acc_id =module.storageaccount_module_glb_prod_02.sta_id
workspace_rs_id =module.logaalyticsworkspace_reuse.workspace_resource_id
}
# ............nsgrule.......................................
module "nsg_rules_module_01" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_01
  priority_number=var.prioritynumber_01
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_deny01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_01
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_01
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1a_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_edmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_edmz.nsg_name_out,module.nsg_module_sn_glb_prod_z3_int.nsg_name_out,module.nsg_module_sn_glb_prod_z3_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z3_edmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_edmz.nsg_name_out]
}

module "nsg_rules_module_02" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_02
  priority_number=var.prioritynumber_01
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_deny01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_01
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_01
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1a_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_edmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_edmz.nsg_name_out,module.nsg_module_sn_glb_prod_z3_int.nsg_name_out,module.nsg_module_sn_glb_prod_z3_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z3_edmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_edmz.nsg_name_out]
}
module "nsg_rules_module_03" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_03
  priority_number=var.prioritynumber_02
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_01
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_02
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1a_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_edmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_edmz.nsg_name_out,module.nsg_module_sn_glb_prod_z3_int.nsg_name_out,module.nsg_module_sn_glb_prod_z3_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z3_edmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_edmz.nsg_name_out]
}

module "nsg_rules_module_04" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_04
  priority_number=var.prioritynumber_02
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_02
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_01
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1a_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_edmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_edmz.nsg_name_out,module.nsg_module_sn_glb_prod_z3_int.nsg_name_out,module.nsg_module_sn_glb_prod_z3_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z3_edmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_edmz.nsg_name_out]
}
# module "nsg_rules_module_05" {
#   source = "../../module/nsg_rules_creation"
#   nsg_rule_name=var.nsgrule_name_05
#   priority_number=var.prioritynumber_03
#   nsg_direction=var.nsg_direction_inbound01
#   nsg_accesstype=var.accesstype_deny01
#   nsg_protocol=var.protocol_01
#   nsg_source_port_range=var.source_port_range_01
#   nsg_destination_port_range=var.nsg_destination_port_range01
#   nsg_source_address_prefixe=var.nsg_source_address_prefixe_03
#   nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_01
#   resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
#   nsg_name=[module.nsg_module_sn_glb_prod_z1a_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_edmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_edmz.nsg_name_out,module.nsg_module_sn_glb_prod_z3_int.nsg_name_out,module.nsg_module_sn_glb_prod_z3_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z3_edmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_edmz.nsg_name_out]
# }
# module "nsg_rules_module_06" {
#   source = "../../module/nsg_rules_creation"
#   nsg_rule_name=var.nsgrule_name_06
#   priority_number=var.prioritynumber_03
#   nsg_direction=var.nsg_direction_outbound01
#   nsg_accesstype=var.accesstype_deny01
#   nsg_protocol=var.protocol_01
#   nsg_source_port_range=var.source_port_range_01
#   nsg_destination_port_range=var.nsg_destination_port_range01
#   nsg_source_address_prefixe=var.nsg_source_address_prefixe_01
#   nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_03
#   resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
#   nsg_name=[module.nsg_module_sn_glb_prod_z1a_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_edmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_edmz.nsg_name_out,module.nsg_module_sn_glb_prod_z3_int.nsg_name_out,module.nsg_module_sn_glb_prod_z3_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z3_edmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_edmz.nsg_name_out]
# }
module "recovery_service_vault"{
source= "../../module/recovery_services_vault_creation"
  recovery_vault_name              = var.recovery_serv_vault_name
  location                         = module.rg_module_sn_glb_prod_4.rg_location
  resource_group_name              = module.rg_module_sn_glb_prod_4.rg_name
  vault_sku_name                   = var.recovery_serv_vault_sku_name
  tags                             = var.tags_recovery_services
}
# .................z1a.............................
module "nsg_rules_module_07" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_07
  priority_number=var.prioritynumber_04
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_deny01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_04
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_04
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1a_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_edmz.nsg_name_out]
}
module "nsg_rules_module_08" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_08
  priority_number=var.prioritynumber_04
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_deny01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_04
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_04
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1a_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_edmz.nsg_name_out]
}

# ..........................Z1B.........................................
module "nsg_rules_module_09" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_09
  priority_number=var.prioritynumber_04
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_deny01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_05
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_05
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1b_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_edmz.nsg_name_out]
}
module "nsg_rules_module_10" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_10
  priority_number=var.prioritynumber_04
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_deny01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_05
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_05
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1b_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_edmz.nsg_name_out]
}
# ........................Z1C...................................

module "nsg_rules_module_11" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_11
  priority_number=var.prioritynumber_04
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_deny01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_06
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_06
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1c_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_edmz.nsg_name_out]
}
module "nsg_rules_module_12" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_12
  priority_number=var.prioritynumber_04
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_deny01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_06
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_06
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1c_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_edmz.nsg_name_out]
}

# .......................Z3..........................................
module "nsg_rules_module_13" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_13
  priority_number=var.prioritynumber_04
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_deny01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_07
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_07
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z3_int.nsg_name_out,module.nsg_module_sn_glb_prod_z3_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z3_edmz.nsg_name_out]
}
module "nsg_rules_module_14" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_14
  priority_number=var.prioritynumber_04
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_deny01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_07
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_07
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z3_int.nsg_name_out,module.nsg_module_sn_glb_prod_z3_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z3_edmz.nsg_name_out]
}

# .....................rdgw..........................................................
# .................z1a.............................
module "nsg_rules_module_15" {
  source = "../../module/nsgrule_creation_list"
  nsg_rule_name=var.nsgrule_name_15
  priority_number=var.prioritynumber_05
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_rdgw
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_rdgw
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_04
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1a_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_edmz.nsg_name_out]
}

# ..........................Z1B.........................................
module "nsg_rules_module_16" {
  source = "../../module/nsgrule_creation_list"
  nsg_rule_name=var.nsgrule_name_15
  priority_number=var.prioritynumber_05
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_rdgw
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_rdgw
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_05
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1b_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_edmz.nsg_name_out]
}

# ........................Z1C...................................

module "nsg_rules_module_17" {
  source = "../../module/nsgrule_creation_list"
  nsg_rule_name=var.nsgrule_name_15
  priority_number=var.prioritynumber_05
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_rdgw
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_rdgw
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_06
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1c_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_edmz.nsg_name_out]
}
module "nsg_rules_module_18" {
  source = "../../module/nsgrule_creation_list"
  nsg_rule_name=var.nsgrule_name_16
  priority_number=var.prioritynumber_05
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_rdgw
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_rdgw
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_01
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1c_int.nsg_name_out]
}

# .......................Z3..........................................
module "nsg_rules_module_19" {
  source = "../../module/nsgrule_creation_list"
  nsg_rule_name=var.nsgrule_name_15
  priority_number=var.prioritynumber_05
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_rdgw
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_rdgw
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_07
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z3_int.nsg_name_out,module.nsg_module_sn_glb_prod_z3_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z3_edmz.nsg_name_out]
}
# .............jumpbox rule....................................


# .................z1a.............................
module "nsg_rules_module_20" {
  source = "../../module/nsgrule_creation_list"
  nsg_rule_name=var.nsgrule_name_17
  priority_number=var.prioritynumber_06
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_jmp
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_jmp
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_04
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1a_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_edmz.nsg_name_out]
}

# ..........................Z1B.........................................
module "nsg_rules_module_21" {
  source = "../../module/nsgrule_creation_list"
  nsg_rule_name=var.nsgrule_name_17
  priority_number=var.prioritynumber_06
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_jmp
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_jmp
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_05
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1b_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_edmz.nsg_name_out]
}

# ........................Z1C...................................

module "nsg_rules_module_22" {
  source = "../../module/nsgrule_creation_list"
  nsg_rule_name=var.nsgrule_name_17
  priority_number=var.prioritynumber_06
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_jmp
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_jmp
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_06
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1c_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_edmz.nsg_name_out]
}
module "nsg_rules_module_23" {
  source = "../../module/nsgrule_creation_list"
  nsg_rule_name=var.nsgrule_name_18
  priority_number=var.prioritynumber_06
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_jmp
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_jmp
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_01
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1c_int.nsg_name_out]
}

# .......................Z3..........................................
module "nsg_rules_module_24" {
  source = "../../module/nsgrule_creation_list"
  nsg_rule_name=var.nsgrule_name_17
  priority_number=var.prioritynumber_06
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_jmp
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_jmp
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_07
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z3_int.nsg_name_out,module.nsg_module_sn_glb_prod_z3_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z3_edmz.nsg_name_out]
}

# .............lb rule...........................................................
# .................z1a.............................
module "nsg_rules_module_25" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_19
  priority_number=var.prioritynumber_07
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_lb
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_04
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1a_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_edmz.nsg_name_out]
}
module "nsg_rules_module_26" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_20
  priority_number=var.prioritynumber_07
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_lb
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_01
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1a_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_edmz.nsg_name_out]
}

# ..........................Z1B.........................................
module "nsg_rules_module_27" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_19
  priority_number=var.prioritynumber_07
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_lb
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_05
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1b_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_edmz.nsg_name_out]
}
module "nsg_rules_module_28" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_20
  priority_number=var.prioritynumber_07
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_lb
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_01
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1b_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_edmz.nsg_name_out]
}
# ........................Z1C...................................

module "nsg_rules_module_29" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_19
  priority_number=var.prioritynumber_07
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_lb
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_06
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1c_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_edmz.nsg_name_out]
}
module "nsg_rules_module_30" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_20
  priority_number=var.prioritynumber_07
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_lb
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_01
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1c_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_edmz.nsg_name_out]
}
# .....z1c int.......
module "nsg_rules_module_31" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_19
  priority_number=var.prioritynumber_07
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_lb
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_06
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1c_int.nsg_name_out]
}
module "nsg_rules_module_32" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_20
  priority_number=var.prioritynumber_07
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_lb
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_01
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1c_int.nsg_name_out]
}
# .......................Z3..........................................
module "nsg_rules_module_33" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_19
  priority_number=var.prioritynumber_07
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_lb
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_07
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z3_int.nsg_name_out,module.nsg_module_sn_glb_prod_z3_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z3_edmz.nsg_name_out]
}
module "nsg_rules_module_34" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_20
  priority_number=var.prioritynumber_07
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_lb
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_01
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z3_int.nsg_name_out,module.nsg_module_sn_glb_prod_z3_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z3_edmz.nsg_name_out]
}
#.................sl.....................
# .................z1a.............................
module "nsg_rules_module_35" {
  source = "../../module/nsgrule_creation_list2"
  nsg_rule_name=var.nsgrule_name_21
  priority_number=var.prioritynumber_08
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_sl
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_sl
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_04
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1a_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_edmz.nsg_name_out]
}

# ..........................Z1B.........................................
module "nsg_rules_module_36" {
  source = "../../module/nsgrule_creation_list2"
  nsg_rule_name=var.nsgrule_name_21
  priority_number=var.prioritynumber_08
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_sl
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_sl
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_05
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1b_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_edmz.nsg_name_out]
}

# ........................Z1C...................................

module "nsg_rules_module_37" {
  source = "../../module/nsgrule_creation_list2"
  nsg_rule_name=var.nsgrule_name_21
  priority_number=var.prioritynumber_08
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_sl
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_sl
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_06
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1c_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_edmz.nsg_name_out]
}


# .......................Z3..........................................
module "nsg_rules_module_38" {
  source = "../../module/nsgrule_creation_list2"
  nsg_rule_name=var.nsgrule_name_21
  priority_number=var.prioritynumber_08
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_sl
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_sl
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_07
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z3_int.nsg_name_out,module.nsg_module_sn_glb_prod_z3_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z3_edmz.nsg_name_out]
}

# ..........commvault....................................
#z1a
#.....tcp.................
module "nsg_rules_module_39" {
  source = "../../module/nsgrule_creation_list2"
  nsg_rule_name=var.nsgrule_name_22
  priority_number=var.prioritynumber_10
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_cv_tcp
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_cv
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_04
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1a_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_edmz.nsg_name_out]
}
#.....udp.................
module "nsg_rules_module_40" {
  source = "../../module/nsgrule_creation_list2"
  nsg_rule_name=var.nsgrule_name_23
  priority_number=var.prioritynumber_11
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_udp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_cv_udp
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_cv
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_04
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1a_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_edmz.nsg_name_out]
}
#.....outbound.................
#.....tcp.................
module "nsg_rules_module_41" {
  source = "../../module/nsgrule_creation_list4"
  nsg_rule_name=var.nsgrule_name_24
  priority_number=var.prioritynumber_10
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_cv_tcp
  nsg_source_address_prefix=var.nsg_source_address_prefixe_04
  nsg_destination_address_prefixes=var.nsg_destination_address_prefixe_cv
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1a_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_edmz.nsg_name_out]
}
#.....udp.................
module "nsg_rules_module_42" {
  source = "../../module/nsgrule_creation_list4"
  nsg_rule_name=var.nsgrule_name_25
  priority_number=var.prioritynumber_11
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_udp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_cv_udp
  nsg_source_address_prefix=var.nsg_source_address_prefixe_04
  nsg_destination_address_prefixes=var.nsg_destination_address_prefixe_cv
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1a_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_edmz.nsg_name_out]
}
#z1b
#.....tcp.................
module "nsg_rules_module_43" {
  source = "../../module/nsgrule_creation_list2"
  nsg_rule_name=var.nsgrule_name_22
  priority_number=var.prioritynumber_10
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_cv_tcp
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_cv
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_05
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1b_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_edmz.nsg_name_out]
}
#.....udp.................
module "nsg_rules_module_44" {
  source = "../../module/nsgrule_creation_list2"
  nsg_rule_name=var.nsgrule_name_23
  priority_number=var.prioritynumber_11
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_udp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_cv_udp
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_cv
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_05
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1b_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_edmz.nsg_name_out]
}
#.....outbound.................
#.....tcp.................
module "nsg_rules_module_45" {
  source = "../../module/nsgrule_creation_list4"
  nsg_rule_name=var.nsgrule_name_24
  priority_number=var.prioritynumber_10
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_cv_tcp
  nsg_source_address_prefix=var.nsg_source_address_prefixe_05
  nsg_destination_address_prefixes=var.nsg_destination_address_prefixe_cv
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1b_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_edmz.nsg_name_out]
}
#.....udp.................
module "nsg_rules_module_46" {
  source = "../../module/nsgrule_creation_list4"
  nsg_rule_name=var.nsgrule_name_25
  priority_number=var.prioritynumber_11
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_udp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_cv_udp
  nsg_source_address_prefix=var.nsg_source_address_prefixe_05
  nsg_destination_address_prefixes=var.nsg_destination_address_prefixe_cv
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1b_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_edmz.nsg_name_out]
}

#z1c
#.....tcp.................
module "nsg_rules_module_47" {
  source = "../../module/nsgrule_creation_list2"
  nsg_rule_name=var.nsgrule_name_22
  priority_number=var.prioritynumber_10
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_cv_tcp
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_cv
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_06
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1c_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_edmz.nsg_name_out]
}
#.....udp.................
module "nsg_rules_module_48" {
  source = "../../module/nsgrule_creation_list2"
  nsg_rule_name=var.nsgrule_name_23
  priority_number=var.prioritynumber_11
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_udp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_cv_udp
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_cv
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_06
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1c_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_edmz.nsg_name_out]
}
#.....outbound.................
#.....tcp.................
module "nsg_rules_module_49" {
  source = "../../module/nsgrule_creation_list4"
  nsg_rule_name=var.nsgrule_name_24
  priority_number=var.prioritynumber_10
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_cv_tcp
  nsg_source_address_prefix=var.nsg_source_address_prefixe_06
  nsg_destination_address_prefixes=var.nsg_destination_address_prefixe_cv
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1c_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_edmz.nsg_name_out]
}
#.....udp.................
module "nsg_rules_module_50" {
  source = "../../module/nsgrule_creation_list4"
  nsg_rule_name=var.nsgrule_name_25
  priority_number=var.prioritynumber_11
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_udp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_cv_udp
  nsg_source_address_prefix=var.nsg_source_address_prefixe_06
  nsg_destination_address_prefixes=var.nsg_destination_address_prefixe_cv
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1c_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_edmz.nsg_name_out]
}
#z3
#.....tcp.................
module "nsg_rules_module_51" {
  source = "../../module/nsgrule_creation_list2"
  nsg_rule_name=var.nsgrule_name_22
  priority_number=var.prioritynumber_10
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_cv_tcp
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_cv
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_07
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z3_int.nsg_name_out,module.nsg_module_sn_glb_prod_z3_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z3_edmz.nsg_name_out]
}
#.....udp.................
module "nsg_rules_module_52" {
  source = "../../module/nsgrule_creation_list2"
  nsg_rule_name=var.nsgrule_name_23
  priority_number=var.prioritynumber_11
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_udp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_cv_udp
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_cv
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_07
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z3_int.nsg_name_out,module.nsg_module_sn_glb_prod_z3_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z3_edmz.nsg_name_out]
}
#.....outbound.................
#.....tcp.................
module "nsg_rules_module_53" {
  source = "../../module/nsgrule_creation_list4"
  nsg_rule_name=var.nsgrule_name_24
  priority_number=var.prioritynumber_10
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_cv_tcp
  nsg_source_address_prefix=var.nsg_source_address_prefixe_07
  nsg_destination_address_prefixes=var.nsg_destination_address_prefixe_cv
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z3_int.nsg_name_out,module.nsg_module_sn_glb_prod_z3_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z3_edmz.nsg_name_out]
}
#.....udp.................
module "nsg_rules_module_54" {
  source = "../../module/nsgrule_creation_list4"
  nsg_rule_name=var.nsgrule_name_25
  priority_number=var.prioritynumber_11
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_udp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_cv_udp
  nsg_source_address_prefix=var.nsg_source_address_prefixe_07
  nsg_destination_address_prefixes=var.nsg_destination_address_prefixe_cv
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z3_int.nsg_name_out,module.nsg_module_sn_glb_prod_z3_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z3_edmz.nsg_name_out]
}
#z1a
#.....cylance outbound.................
module "nsg_rules_module_55" {
  source = "../../module/nsgrule_creation_list3"
  nsg_rule_name=var.nsgrule_name_26
  priority_number=var.prioritynumber_12
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_cy
  nsg_source_address_prefix=var.nsg_source_address_prefixe_04
  nsg_destination_address_prefixes=var.nsg_destination_address_prefixe_cy
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1a_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_edmz.nsg_name_out]
}
#.....iboss outbound.................
module "nsg_rules_module_56" {
  source = "../../module/nsgrule_creation_list4"
  nsg_rule_name=var.nsgrule_name_27
  priority_number=var.prioritynumber_13
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_iboss
  nsg_source_address_prefix=var.nsg_source_address_prefixe_04
  nsg_destination_address_prefixes=var.nsg_destination_address_prefixe_iboss
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1a_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_edmz.nsg_name_out]
}

#z1b
#.....cylance outbound.................
module "nsg_rules_module_57" {
  source = "../../module/nsgrule_creation_list3"
  nsg_rule_name=var.nsgrule_name_26
  priority_number=var.prioritynumber_12
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_cy
  nsg_source_address_prefix=var.nsg_source_address_prefixe_05
  nsg_destination_address_prefixes=var.nsg_destination_address_prefixe_cy
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1b_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_edmz.nsg_name_out]
}
#.....iboss outbound.................
module "nsg_rules_module_58" {
  source = "../../module/nsgrule_creation_list4"
  nsg_rule_name=var.nsgrule_name_27
  priority_number=var.prioritynumber_13
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_iboss
  nsg_source_address_prefix=var.nsg_source_address_prefixe_05
  nsg_destination_address_prefixes=var.nsg_destination_address_prefixe_iboss
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1b_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_edmz.nsg_name_out]
}

#z1c
#.....cylance outbound.................
module "nsg_rules_module_59" {
  source = "../../module/nsgrule_creation_list3"
  nsg_rule_name=var.nsgrule_name_26
  priority_number=var.prioritynumber_12
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_cy
  nsg_source_address_prefix=var.nsg_source_address_prefixe_06
  nsg_destination_address_prefixes=var.nsg_destination_address_prefixe_cy
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1c_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_edmz.nsg_name_out]
}
#.....iboss outbound.................
module "nsg_rules_module_60" {
  source = "../../module/nsgrule_creation_list4"
  nsg_rule_name=var.nsgrule_name_27
  priority_number=var.prioritynumber_13
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_iboss
  nsg_source_address_prefix=var.nsg_source_address_prefixe_06
  nsg_destination_address_prefixes=var.nsg_destination_address_prefixe_iboss
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1c_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_edmz.nsg_name_out]
}
#z3
#.....cylance outbound.................
module "nsg_rules_module_61" {
  source = "../../module/nsgrule_creation_list3"
  nsg_rule_name=var.nsgrule_name_26
  priority_number=var.prioritynumber_12
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_cy
  nsg_source_address_prefix=var.nsg_source_address_prefixe_07
  nsg_destination_address_prefixes=var.nsg_destination_address_prefixe_cy
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z3_int.nsg_name_out,module.nsg_module_sn_glb_prod_z3_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z3_edmz.nsg_name_out]
}
#.....iboss outbound.................
module "nsg_rules_module_62" {
  source = "../../module/nsgrule_creation_list4"
  nsg_rule_name=var.nsgrule_name_27
  priority_number=var.prioritynumber_13
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_iboss
  nsg_source_address_prefix=var.nsg_source_address_prefixe_07
  nsg_destination_address_prefixes=var.nsg_destination_address_prefixe_iboss
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z3_int.nsg_name_out,module.nsg_module_sn_glb_prod_z3_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z3_edmz.nsg_name_out]
}

# .......rdgw udp...................................
# .................z1a.............................
module "nsg_rules_module_63" {
  source = "../../module/nsgrule_creation_list"
  nsg_rule_name=var.nsgrule_name_28
  priority_number=var.prioritynumber_14
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_udp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_rdgw
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_rdgw
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_04
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1a_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1a_edmz.nsg_name_out]
}

# ..........................Z1B.........................................
module "nsg_rules_module_64" {
  source = "../../module/nsgrule_creation_list"
  nsg_rule_name=var.nsgrule_name_28
  priority_number=var.prioritynumber_14
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_udp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_rdgw
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_rdgw
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_05
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1b_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1b_edmz.nsg_name_out]
}

# ........................Z1C...................................

module "nsg_rules_module_65" {
  source = "../../module/nsgrule_creation_list"
  nsg_rule_name=var.nsgrule_name_28
  priority_number=var.prioritynumber_14
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
 nsg_protocol=var.protocol_udp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_rdgw
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_rdgw
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_06
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1c_int.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z1c_edmz.nsg_name_out]
}
module "nsg_rules_module_66" {
  source = "../../module/nsgrule_creation_list"
  nsg_rule_name=var.nsgrule_name_29
  priority_number=var.prioritynumber_14
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_udp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_rdgw
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_rdgw
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_01
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1c_int.nsg_name_out]
}

# .......................Z3..........................................
module "nsg_rules_module_67" {
  source = "../../module/nsgrule_creation_list"
  nsg_rule_name=var.nsgrule_name_28
  priority_number=var.prioritynumber_14
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_udp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_rdgw
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_rdgw
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_07
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z3_int.nsg_name_out,module.nsg_module_sn_glb_prod_z3_idmz.nsg_name_out,module.nsg_module_sn_glb_prod_z3_edmz.nsg_name_out]
}
# .......................................................................................
# ................idmz rules ..............................................................................
# z1a..................................
# .....int.................................................................................................
module "nsg_rules_module_68" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_68
  priority_number=var.prioritynumber_20
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_20
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_20
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1a_int.nsg_name_out]
}
module "nsg_rules_module_69" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_69
  priority_number=var.prioritynumber_20
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_20
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_20
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1a_int.nsg_name_out]
}
# ............idmz.....................................................................
module "nsg_rules_module_70" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_70
  priority_number=var.prioritynumber_20
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_21
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_21
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1a_idmz.nsg_name_out]
}
module "nsg_rules_module_71" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_71
  priority_number=var.prioritynumber_20
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_21
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_21
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1a_idmz.nsg_name_out]
}
# ............edmz.....................................................................
module "nsg_rules_module_72" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_72
  priority_number=var.prioritynumber_20
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_22
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_22
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1a_edmz.nsg_name_out]
}
module "nsg_rules_module_73" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_73
  priority_number=var.prioritynumber_20
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_22
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_22
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1a_edmz.nsg_name_out]
}

# .......................................................................................
# ................idmz rules ..............................................................................
# .....int.................................................................................................
module "nsg_rules_module_74" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_68
  priority_number=var.prioritynumber_20
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_23
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_23
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1b_int.nsg_name_out]
}
module "nsg_rules_module_75" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_69
  priority_number=var.prioritynumber_20
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_23
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_23
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1b_int.nsg_name_out]
}
# ............idmz.....................................................................
module "nsg_rules_module_76" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_70
  priority_number=var.prioritynumber_20
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_24
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_24
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1b_idmz.nsg_name_out]
}
module "nsg_rules_module_77" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_71
  priority_number=var.prioritynumber_20
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_24
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_24
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1b_idmz.nsg_name_out]
}
# ............edmz.....................................................................
module "nsg_rules_module_78" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_72
  priority_number=var.prioritynumber_20
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_25
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_25
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1b_edmz.nsg_name_out]
}
module "nsg_rules_module_79" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_73
  priority_number=var.prioritynumber_20
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_25
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_25
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1b_edmz.nsg_name_out]
}
# .......................................................................................
# ................idmz rules ..............................................................................
# .....int.................................................................................................
module "nsg_rules_module_80" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_80
  priority_number=var.prioritynumber_20
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_26
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_26
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1c_int.nsg_name_out]
}
module "nsg_rules_module_81" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_81
  priority_number=var.prioritynumber_20
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_26
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_26
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1c_int.nsg_name_out]
}
# ............idmz.....................................................................
module "nsg_rules_module_82" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_82
  priority_number=var.prioritynumber_20
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_27
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_27
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1c_idmz.nsg_name_out]
}
module "nsg_rules_module_83" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_83
  priority_number=var.prioritynumber_20
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_27
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_27
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1c_idmz.nsg_name_out]
}
# ............edmz.....................................................................
module "nsg_rules_module_84" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_84
  priority_number=var.prioritynumber_20
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_28
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_28
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1c_edmz.nsg_name_out]
}
module "nsg_rules_module_85" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_85
  priority_number=var.prioritynumber_20
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_28
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_28
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z1c_edmz.nsg_name_out]
}
# .......................................................................................
# ................idmz rules ..............................................................................
# .....int.................................................................................................
module "nsg_rules_module_86" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_86
  priority_number=var.prioritynumber_20
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_29
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_29
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z3_int.nsg_name_out]
}
module "nsg_rules_module_87" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_87
  priority_number=var.prioritynumber_20
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_29
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_29
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z3_int.nsg_name_out]
}
# ............idmz.....................................................................
module "nsg_rules_module_88" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_88
  priority_number=var.prioritynumber_20
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_30
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_30
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z3_idmz.nsg_name_out]
}
module "nsg_rules_module_89" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_89
  priority_number=var.prioritynumber_20
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_30
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_30
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z3_idmz.nsg_name_out]
}
# ............edmz.....................................................................
module "nsg_rules_module_90" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_90
  priority_number=var.prioritynumber_20
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_31
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_31
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z3_edmz.nsg_name_out]
}
module "nsg_rules_module_91" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_89
  priority_number=var.prioritynumber_20
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_31
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_31
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_prod_z3_edmz.nsg_name_out]
}

# ..................edmz routes........................................
module "routes_module_sn_glb_prod_z1a_edmz_rules" {
  source = "../../module/route_table_routes"
  route_name=var.route_name_sn_glb_prod_edmz
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  route_table_name=module.route_table_module_glb_prod_z1a_edmz.route_table_name_output 
  route_address_prefix=var.route_addressPrefix_sn_glb_prod_edmz
  next_hop_type=var.route_nextHopType_sn_glb_prod_edmz
  }
module "routes_module_sn_glb_prod_z1b_edmz_rules" {
  source = "../../module/route_table_routes"
  route_name=var.route_name_sn_glb_prod_edmz
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  route_table_name=module.route_table_module_glb_prod_z1b_edmz.route_table_name_output 
  route_address_prefix=var.route_addressPrefix_sn_glb_prod_edmz
  next_hop_type=var.route_nextHopType_sn_glb_prod_edmz
  }
module "routes_module_sn_glb_prod_z1c_edmz_rules" {
  source = "../../module/route_table_routes"
  route_name=var.route_name_sn_glb_prod_edmz
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  route_table_name=module.route_table_module_glb_prod_z1c_edmz.route_table_name_output 
  route_address_prefix=var.route_addressPrefix_sn_glb_prod_edmz
  next_hop_type=var.route_nextHopType_sn_glb_prod_edmz
  }
  module "routes_module_sn_glb_prod_z3_edmz_rules" {
  source = "../../module/route_table_routes"
  route_name=var.route_name_sn_glb_prod_edmz
  resource_group_name=module.rg_module_sn_glb_prod_1.rg_name
  route_table_name=module.route_table_module_glb_prod_z3_edmz.route_table_name_output 
  route_address_prefix=var.route_addressPrefix_sn_glb_prod_edmz
  next_hop_type=var.route_nextHopType_sn_glb_prod_edmz
  }











