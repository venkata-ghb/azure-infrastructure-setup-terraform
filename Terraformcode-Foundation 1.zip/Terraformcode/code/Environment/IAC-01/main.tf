terraform {
  required_version = "0.13.5"
}

# -------------------------------------------------------SN resource Group creation-------------------------------------------------------
#output variables for this block is {rg_name,rg_id and rg_location}
module "rg_module_sn_iac_1" {
  source= "../../module/rg_creation"
  resourcegrp_name=var.resource_group_name
  location=var.location
  tags=var.tags
}

module "rg_module_sn_iac_2" {
  source= "../../module/rg_creation"
  resourcegrp_name=var.resource_group_name01
  location=var.location
  tags=var.tags_recovery_services
}
module "rg_module_sn_iac_3" {
  source= "../../module/rg_creation"
  resourcegrp_name=var.resource_group_name02
  location=var.location
  tags=var.tags_mgmt
}
module "rg_module_sn_iac_4" {
  source= "../../module/rg_creation"
  resourcegrp_name=var.resource_group_name03
  location=var.location
  tags=var.tags_nw
}
module "storageaccount_module01" {
  source = "../../module/storageaccount_creation"
  storageaccountname=var.storageaccountname01
  location=module.rg_module_sn_iac_3.rg_location
  resourcegrp_name=module.rg_module_sn_iac_3.rg_name
 storage_account_type="Standard_LRS"
  account_kind="StorageV2"
  access_tier="Hot"
  tags=var.tags_mgmt
}
module "keyvault_creation" {
  source ="../../module/keyvault_creation"
  rg_name=module.rg_module_sn_iac_1.rg_name
  location=module.rg_module_sn_iac_1.rg_location
  object_id= var.object_id
  keyvault_name=var.keyvault_name
  sku_name=var.sku
  tags=var.tags
  soft_delete_retention_days=var.soft_retention_days
  }
  module "accesspolicy_keyvault"{
    source ="../../module/add_accesspolicies"
    object_ids= var.object_id_01
    keyvault_id=module.keyvault_creation.keyvault_id
    depends_on=[module.keyvault_creation]
  }

  module "accesspolicy_keyvault01"{
    source ="../../module/add_accesspolicies"
    object_ids= var.object_id_02
    keyvault_id=module.keyvault_creation.keyvault_id
    depends_on=[module.keyvault_creation]
  }

  # .......................vnet...........................................
  #------------------------------------------------------ vnet creation---------------------------------------------------------
#output variables for this block is {vnet_id and vnet_name}
module "vnet_module_iac_1" {
source ="../../module/vnet_creation"
address_dnsservers=var.dnsservers01
vnet_name=var.vnet_name_iac_01
location=module.rg_module_sn_iac_4.rg_location
resourcegrp_name=module.rg_module_sn_iac_4.rg_name
vnet_address_prefix=var.vnet_addr_prefix_iac_1
tags_vnet=var.tags_nw
}
module "subnet_module_iac1" {
  source = "../../module/subnet_creation"
  subnet_name=var.subnet_name_iac1
  vnet_name=module.vnet_module_iac_1.vnet_name
  resourcegrp_name=module.rg_module_sn_iac_4.rg_name
  address_space=var.addr_space_iac1
  
}
module "subnet_module_iac2" {
  source = "../../module/subnet_creation"
  subnet_name=var.subnet_name_iac2
  vnet_name=module.vnet_module_iac_1.vnet_name
  resourcegrp_name=module.rg_module_sn_iac_4.rg_name
  address_space=var.addr_space_iac2
  
}
module "subnet_module_iac3" {
  source = "../../module/subnet_creation"
  subnet_name=var.subnet_name_iac3
  vnet_name=module.vnet_module_iac_1.vnet_name
  resourcegrp_name=module.rg_module_sn_iac_4.rg_name
  address_space=var.addr_space_iac3
 
}

module "rg_module_sn_iac_rsv" {
source= "../../module/rg_creation"
resourcegrp_name=var.rg_module_sn_iac_rsv
location=var.location
tags=var.tags_recovery_services
}
module "recovery_service_vault"{
source= "../../module/recovery_services_vault_creation"
recovery_vault_name              = var.recovery_serv_vault_name
location                         = module.rg_module_sn_iac_rsv.rg_location
resource_group_name              = module.rg_module_sn_iac_rsv.rg_name
vault_sku_name                   = var.recovery_serv_vault_sku_name
tags                             = var.tags_recovery_services
}
# ...........log analytics workspace reuse.....................................
module "logaalyticsworkspace_reuse"{
  providers={
    azurerm=azurerm.sn_hub
  }
  source="../../module/law_reuse"
  law_name=var.loganalytics_name
  law_rg=var.loganalytics_rg
}

module "rsv_diagnostics"{
source = "../../module/diagnosticsettings"
resource_id=[module.recovery_service_vault.rsv_id]
dlog_name=var.diagnosticsettings_rsv
target_id=[module.recovery_service_vault.rsv_id]
storage_acc_id =module.storageaccount_module01.sta_id
workspace_rs_id =module.logaalyticsworkspace_reuse.workspace_resource_id
}