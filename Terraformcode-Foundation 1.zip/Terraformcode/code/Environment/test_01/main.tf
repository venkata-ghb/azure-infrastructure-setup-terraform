terraform {
required_version = "0.13.5"
}

# -------------------------------------------------------SN glb_test resource Group creation-------------------------------------------------------
#output variables for this block is {rg_name,rg_id and rg_location}
module "rg_module_sn_glb_test_1" {
source= "../../module/rg_creation"
resourcegrp_name=var.resource_group_name
location=var.location
tags=var.tags
}
module "rg_module_sn_glb_test_2" {
source= "../../module/rg_creation"
resourcegrp_name=var.resource_group_name02
location=var.location
tags=var.tags_mgmt
}
module "rg_module_sn_glb_test_3" {
source= "../../module/rg_creation"
resourcegrp_name=var.resource_group_name03
location=var.location
tags=var.tags_recovery_services
}

module "rg_module_sn_glb_test_4" {
source= "../../module/rg_creation"  
resourcegrp_name=var.resource_group_name04
location=var.location
tags=var.tags_app
}
# ......................storage account................................
module "storageaccount_module_glb_test_01" {
source = "../../module/storageaccount_creation"
storageaccountname=var.storageaccountname01
location=module.rg_module_sn_glb_test_2.rg_location
resourcegrp_name=module.rg_module_sn_glb_test_2.rg_name
storage_account_type=var.strg_acc_type01
account_kind=var.acc_kind01
access_tier=var.access_tier01
tags=var.tags_mgmt
}
#--------------------------------------------------------SN glb_test vnet creation---------------------------------------------------------
#output variables for this block is {vnet_id and vnet_name}
module "vnet_module_sn_glb_test_1" {
source ="../../module/vnet_creation"
address_dnsservers=var.dnsservers01
vnet_name=var.vnet_name_sn_glb_test_1
location=module.rg_module_sn_glb_test_1.rg_location
resourcegrp_name=module.rg_module_sn_glb_test_1.rg_name
vnet_address_prefix=var.vnet_addr_prefix_sn_glb_test_1
tags_vnet=var.tags
depends_on =[module.rg_module_sn_glb_test_1]
} 
# ...............existingvnet..................................
module "existingvnetsnhubvnet01" {
providers={
    azurerm=azurerm.sn_hub
  }
source = "../../module/existing_vnet"
  existingvnet=var.existingvnetsnhubvnet01
  rg_name=var.existingresourcegroupsn_hubvnet01
  
}
module "existingvnetsnhubvnet02" {
providers={
    azurerm=azurerm.sn_hub
  }
source = "../../module/existing_vnet"
existingvnet=var.existingvnetsnhubvnet02
rg_name=var.existingresourcegroupsn_hubvnet01
  
} 
# ............cross region vnet......................
module "existingvnetweglbtest" {
  providers={
    azurerm=azurerm.we_glbtest
  }
source = "../../module/existing_vnet"
existingvnet=var.existingvnetweglbtest
rg_name=var.existingresourcegroupsn_weglbtest
} 
# ............cross region peering..........................
# z1d to z1d
module "sn_glb_test_cross_vnet_peering_module1" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.sn_glb_test_cross_vnet_peering_name_01
  resourcegrp_name=module.rg_module_sn_glb_test_1.rg_name
  vnet_name=module.vnet_module_sn_glb_test_1.vnet_name
  vnet_remote_id=module.existingvnetweglbtest.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_10
  use_remote_gateways=var.use_remote_gateways_10
}
# ............................vnet peering...............................
# vnetzid to vnet01
module "sn_glb_test_vnet_peering_module1" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.sn_glb_test_vnet_peering_name_01
  resourcegrp_name=module.rg_module_sn_glb_test_1.rg_name
  vnet_name=module.vnet_module_sn_glb_test_1.vnet_name
  vnet_remote_id=module.existingvnetsnhubvnet01.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_01
  use_remote_gateways=var.use_remote_gateways_01
}
# vnet1d to vnet2
module "sn_glb_test_vnet_peering_module2" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.sn_glb_test_vnet_peering_name_02
  resourcegrp_name=module.rg_module_sn_glb_test_1.rg_name
  vnet_name=module.vnet_module_sn_glb_test_1.vnet_name
  vnet_remote_id=module.existingvnetsnhubvnet02.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_02
  use_remote_gateways=var.use_remote_gateways_02
}
#-----------------------------------------------------------SN glb_test subnet creation-----------------------------------------------------------------
#output variables for this block is {subnet_id and subnet_address_prefix}
module "subnet_module_sn_glb_test_1" {
  source = "../../module/subnet_creation"
  subnet_name=var.subnet_name_sn_glb_test_1
  vnet_name=module.vnet_module_sn_glb_test_1.vnet_name
  resourcegrp_name=module.rg_module_sn_glb_test_1.rg_name
  address_space=var.addr_space_sn_glb_test_1
  depends_on =[module.vnet_module_sn_glb_test_1]
}
module "subnet_module_sn_glb_test_2" {
  source = "../../module/subnet_creation"
  subnet_name=var.subnet_name_sn_glb_test_2
  vnet_name=module.vnet_module_sn_glb_test_1.vnet_name
  resourcegrp_name=module.rg_module_sn_glb_test_1.rg_name
  address_space=var.addr_space_sn_glb_test_2
  depends_on =[module.vnet_module_sn_glb_test_1]
}
module "subnet_module_sn_glb_test_3" {
  source = "../../module/subnet_creation"
  subnet_name=var.subnet_name_sn_glb_test_3
  vnet_name=module.vnet_module_sn_glb_test_1.vnet_name
  resourcegrp_name=module.rg_module_sn_glb_test_1.rg_name
  address_space=var.addr_space_sn_glb_test_3
  depends_on =[module.vnet_module_sn_glb_test_1]
}
#--------------------------------------------------------------SN glb_test nsg creation---------------------------------------------------------------------
# output variables for this block is {nsg_id and nsg_name}
module "nsg_module_sn_glb_test_1" {
  source = "../../module/nsg_creation"
  nsg_name=var.nsg_name_sn_glb_test_1
  location=module.rg_module_sn_glb_test_1.rg_location
  resourcegrp_name=module.rg_module_sn_glb_test_1.rg_name
  tags_nsg=var.tags
  depends_on =[module.rg_module_sn_glb_test_1]
}
module "nsg_module_sn_glb_test_2" {
  source = "../../module/nsg_creation"
  nsg_name=var.nsg_name_sn_glb_test_2
  location=module.rg_module_sn_glb_test_1.rg_location
  resourcegrp_name=module.rg_module_sn_glb_test_1.rg_name
  tags_nsg=var.tags
  depends_on =[module.rg_module_sn_glb_test_1]
}
module "nsg_module_sn_glb_test_3" {
  source = "../../module/nsg_creation"
  nsg_name=var.nsg_name_sn_glb_test_3
  location=module.rg_module_sn_glb_test_1.rg_location
  resourcegrp_name=module.rg_module_sn_glb_test_1.rg_name
  tags_nsg=var.tags
  depends_on =[module.rg_module_sn_glb_test_1]
}

#-----------------------------------------------------------SN glb_test  nsg association--------------------------------------------------------------------
module "nsg_association_module_sn_glb_test_1" {
  source = "../../module/nsg_subnet_association"
  subnet_id=module.subnet_module_sn_glb_test_1.subnet_id
  nsg_id=module.nsg_module_sn_glb_test_1.nsg_id
  depends_on =[module.nsg_module_sn_glb_test_1,module.subnet_module_sn_glb_test_1]
}
module "nsg_association_module_sn_glb_test_2" {
  source = "../../module/nsg_subnet_association"
  subnet_id=module.subnet_module_sn_glb_test_2.subnet_id
  nsg_id=module.nsg_module_sn_glb_test_2.nsg_id
  depends_on =[module.nsg_module_sn_glb_test_2,module.subnet_module_sn_glb_test_2]
}
module "nsg_association_module_sn_glb_test_3" {
  source = "../../module/nsg_subnet_association"
  subnet_id=module.subnet_module_sn_glb_test_3.subnet_id
  nsg_id=module.nsg_module_sn_glb_test_3.nsg_id
  depends_on =[module.nsg_module_sn_glb_test_3,module.subnet_module_sn_glb_test_3]
}

#--------------------------------------------------------------SN glb_test Route table creation---------------------------------------------------------------
#output variables for this block is {route_table_name_output and route_table_id}
module "route_table_module_sn_glb_test_1" {
  source = "../../module/route_table_creation"
  route_table_name=var.route_table_name_sn_glb_test_1
  location=module.rg_module_sn_glb_test_1.rg_location
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  bgp_route_propagation=var.bgp_route_propagations
  route_tags=var.tags
  depends_on =[module.rg_module_sn_glb_test_1]
}
module "route_table_module_sn_glb_test_2" {
  source = "../../module/route_table_creation"
  route_table_name=var.route_table_name_sn_glb_test_2
  location=module.rg_module_sn_glb_test_1.rg_location
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  bgp_route_propagation=var.bgp_route_propagations
  route_tags=var.tags
  depends_on =[module.rg_module_sn_glb_test_1]
}
module "route_table_module_sn_glb_test_3" {
  source = "../../module/route_table_creation"
  route_table_name=var.route_table_name_sn_glb_test_3
  location=module.rg_module_sn_glb_test_1.rg_location
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  bgp_route_propagation=var.bgp_route_propagations
  route_tags=var.tags
  depends_on =[module.rg_module_sn_glb_test_1]
}

#---------------------------------------------------------SN glb_test Route table association-------------------------------------------------------------
module "route_table_association_module_sn_glb_test_1" {
  source = "../../module/route_table_association"
  subnet_id=module.subnet_module_sn_glb_test_1.subnet_id
  route_table_id=module.route_table_module_sn_glb_test_1.route_table_id
  depends_on = [module.route_table_module_sn_glb_test_1,module.subnet_module_sn_glb_test_1]
}
module "route_table_association_module_sn_glb_test_2" {
  source = "../../module/route_table_association"
  subnet_id=module.subnet_module_sn_glb_test_2.subnet_id
  route_table_id=module.route_table_module_sn_glb_test_2.route_table_id
  depends_on = [module.route_table_module_sn_glb_test_2,module.subnet_module_sn_glb_test_2]
}
module "route_table_association_module_sn_glb_test_3" {
  source = "../../module/route_table_association"
  subnet_id=module.subnet_module_sn_glb_test_3.subnet_id
  route_table_id=module.route_table_module_sn_glb_test_3.route_table_id
  depends_on = [module.route_table_module_sn_glb_test_3,module.subnet_module_sn_glb_test_3]
}
# .............................routetable routes..........................................................................
# ......iboss.......................... 
 module "routes_module_sn_glb_test_z1d_int_iboss" {
  source = "../../module/route_table_routes"
  route_name=var.route_name_sn_glb_test_z1d_iboss
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  route_table_name=module.route_table_module_sn_glb_test_1.route_table_name_output 
  route_address_prefix=var.route_addressPrefix_sn_glb_test_z1d_iboss
  next_hop_type=var.route_nextHopType_sn_glb_test_z1d_iboss
  depends_on =[module.rg_module_sn_glb_test_1,module.route_table_module_sn_glb_test_1]
}
module "routes_module_sn_glb_test_z1d_idmz_iboss" {
  source = "../../module/route_table_routes"
  route_name=var.route_name_sn_glb_test_z1d_iboss
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  route_table_name=module.route_table_module_sn_glb_test_2.route_table_name_output 
  route_address_prefix=var.route_addressPrefix_sn_glb_test_z1d_iboss
  next_hop_type=var.route_nextHopType_sn_glb_test_z1d_iboss
  depends_on =[module.rg_module_sn_glb_test_1,module.route_table_module_sn_glb_test_2]
}
module "routes_module_sn_glb_test_z1d_edmz_iboss" {
  source = "../../module/route_table_routes"
  route_name=var.route_name_sn_glb_test_z1d_iboss
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  route_table_name=module.route_table_module_sn_glb_test_3.route_table_name_output 
  route_address_prefix=var.route_addressPrefix_sn_glb_test_z1d_iboss
  next_hop_type=var.route_nextHopType_sn_glb_test_z1d_iboss
  depends_on =[module.rg_module_sn_glb_test_1,module.route_table_module_sn_glb_test_3]
}
# .....checkpoint routes..........................
# ......removed due to longest prefix algorithm................
module "routes_module_sn_glb_test_z1d_int_cp" {
source = "../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_test_z1d_cp
resource_group_name=module.rg_module_sn_glb_test_1.rg_name
route_table_name=module.route_table_module_sn_glb_test_1.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_test_z1d_cp
next_hop_type=var.route_nextHopType_sn_glb_test_z1d_cp
nexthop_in_ip_address=var.nxthopip_cp
depends_on =[module.rg_module_sn_glb_test_1,module.route_table_module_sn_glb_test_1]
}
module "routes_module_sn_glb_test_z1d_idmz_cp" {
source = "../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_test_z1d_cp
resource_group_name=module.rg_module_sn_glb_test_1.rg_name
route_table_name=module.route_table_module_sn_glb_test_2.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_test_z1d_cp
next_hop_type=var.route_nextHopType_sn_glb_test_z1d_cp
nexthop_in_ip_address=var.nxthopip_cp
depends_on =[module.rg_module_sn_glb_test_1,module.route_table_module_sn_glb_test_2]
}
module "routes_module_sn_glb_test_z1d_edmz_cp" {
source = "../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_test_z1d_cp
resource_group_name=module.rg_module_sn_glb_test_1.rg_name
route_table_name=module.route_table_module_sn_glb_test_3.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_test_z1d_cp
next_hop_type=var.route_nextHopType_sn_glb_test_z1d_cp
nexthop_in_ip_address=var.nxthopip_cp
depends_on =[module.rg_module_sn_glb_test_1,module.route_table_module_sn_glb_test_3]
}
# ....intranet.....................
module "routes_module_sn_glb_test_z1d_int_cp_infw" {
source = "../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_test_z1d_cp_infw
resource_group_name=module.rg_module_sn_glb_test_1.rg_name
route_table_name=module.route_table_module_sn_glb_test_1.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_test_z1d_cp_infw
next_hop_type=var.route_nextHopType_sn_glb_test_z1d_cp_infw
nexthop_in_ip_address=var.nxthopip_cp_intfw
depends_on =[module.rg_module_sn_glb_test_1,module.route_table_module_sn_glb_test_1]
}
module "routes_module_sn_glb_test_z1d_idmz_cp_infw" {
source = "../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_test_z1d_cp_infw
resource_group_name=module.rg_module_sn_glb_test_1.rg_name
route_table_name=module.route_table_module_sn_glb_test_2.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_test_z1d_cp_infw
next_hop_type=var.route_nextHopType_sn_glb_test_z1d_cp_infw
nexthop_in_ip_address=var.nxthopip_cp_intfw
depends_on =[module.rg_module_sn_glb_test_1,module.route_table_module_sn_glb_test_2]
}
module "routes_module_sn_glb_test_z1d_edmz_cp_infw" {
source = "../../module/routable_route_nxh"
route_name=var.route_name_sn_glb_test_z1d_cp_infw
resource_group_name=module.rg_module_sn_glb_test_1.rg_name
route_table_name=module.route_table_module_sn_glb_test_3.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_test_z1d_cp_infw
next_hop_type=var.route_nextHopType_sn_glb_test_z1d_cp_infw
nexthop_in_ip_address=var.nxthopip_cp_intfw
depends_on =[module.rg_module_sn_glb_test_1,module.route_table_module_sn_glb_test_3]
}
# ...........log analytics workspace reuse.....................................
module "logaalyticsworkspace_reuse"{
  providers={
    azurerm=azurerm.sn_hub
  }
  source="../../module/law_reuse"
  law_name=var.loganalytics_name
  law_rg=var.loganalytics_rg
}
# ...................nsg flow log.....................................................................
module "nsgflowlog_01"{
source = "../../module/nsg_flowlog"
networkwatcher_name=var.networkwatcher_name
nw_resourcegroup_name=var.networkwatcher_rg
nsg_id=[module.nsg_module_sn_glb_test_1.nsg_id,module.nsg_module_sn_glb_test_2.nsg_id,module.nsg_module_sn_glb_test_3.nsg_id]
storage_account_id=module.storageaccount_module_glb_test_01.sta_id
retention_days=var.retention_days
flow_version=var.fversion
workspace_id=module.logaalyticsworkspace_reuse.law
location=module.rg_module_sn_glb_test_1.rg_location
workspace_rs_id=module.logaalyticsworkspace_reuse.workspace_resource_id
minutes=var.flow_analytics
}
# .............diagnostic settings......................................................................
# ................nsg.....................................
module "nsg_diagnostics"{
source = "../../module/diagnosticsettings"
resource_id=[module.nsg_module_sn_glb_test_1.nsg_id,module.nsg_module_sn_glb_test_2.nsg_id,module.nsg_module_sn_glb_test_3.nsg_id]
dlog_name=var.diagnosticsettings_nsg
target_id=[module.nsg_module_sn_glb_test_1.nsg_id,module.nsg_module_sn_glb_test_2.nsg_id,module.nsg_module_sn_glb_test_3.nsg_id]
storage_acc_id =module.storageaccount_module_glb_test_01.sta_id
workspace_rs_id =module.logaalyticsworkspace_reuse.workspace_resource_id
}
module "rsv_diagnostics"{
source = "../../module/diagnosticsettings"
resource_id=[module.recovery_service_vault.rsv_id]
dlog_name=var.diagnosticsettings_rsv
target_id=[module.recovery_service_vault.rsv_id]
storage_acc_id =module.storageaccount_module_glb_test_01.sta_id
workspace_rs_id =module.logaalyticsworkspace_reuse.workspace_resource_id
}
# ............keyvault................................
# module "keyvault_diagnostics"{
# source = "../../module/diagnosticsettings"
# resource_id=[module.keyvault_creation.keyvault_id]
# dlog_name=var.diagnosticsettings_keyvault
# target_id=[module.keyvault_creation.keyvault_id]
# storage_acc_id =module.storageaccount_module_glb_test_01.sta_id
# workspace_rs_id =module.logaalyticsworkspace_reuse.workspace_resource_id
# }

# .............................routes abb network................................................................
module "routes_module_sn_glb_test_z1d_int_cp_abbnetwork" {
source = "../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_test_z1d_cp_abbnetwork
resource_group_name=module.rg_module_sn_glb_test_1.rg_name
route_table_name=module.route_table_module_sn_glb_test_1.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_test_z1d_cp_abbnetwork
next_hop_type=var.route_nextHopType_sn_glb_test_z1d_cp_abbnetwork
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork
depends_on =[module.rg_module_sn_glb_test_1,module.route_table_module_sn_glb_test_1]
}
module "routes_module_sn_glb_test_z1d_idmz_cp_abbnetwork" {
source = "../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_test_z1d_cp_abbnetwork
resource_group_name=module.rg_module_sn_glb_test_1.rg_name
route_table_name=module.route_table_module_sn_glb_test_2.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_test_z1d_cp_abbnetwork
next_hop_type=var.route_nextHopType_sn_glb_test_z1d_cp_abbnetwork
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork
depends_on =[module.rg_module_sn_glb_test_1,module.route_table_module_sn_glb_test_2]
}
module "routes_module_sn_glb_test_z1d_edmz_cp_abbnetwork" {
source = "../../module/routetable_route_nxthop"
route_name=var.route_name_sn_glb_test_z1d_cp_abbnetwork
resource_group_name=module.rg_module_sn_glb_test_1.rg_name
route_table_name=module.route_table_module_sn_glb_test_3.route_table_name_output 
route_address_prefix=var.route_addressPrefix_sn_glb_test_z1d_cp_abbnetwork
next_hop_type=var.route_nextHopType_sn_glb_test_z1d_cp_abbnetwork
nexthop_in_ip_address=var.nxthopip_cp_abbnetwork
depends_on =[module.rg_module_sn_glb_test_1,module.route_table_module_sn_glb_test_3]
}
# ..................edmz routes........................................
module "routes_module_sn_glb_test_z1d_edmz_rules" {
  source = "../../module/route_table_routes"
  route_name=var.route_name_sn_glb_test_z1d_edmz
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  route_table_name=module.route_table_module_sn_glb_test_3.route_table_name_output 
  route_address_prefix=var.route_addressPrefix_sn_glb_test_z1d_edmz
  next_hop_type=var.route_nextHopType_sn_glb_test_z1d_edmz
  depends_on =[module.rg_module_sn_glb_test_1,module.route_table_module_sn_glb_test_3]
}

module "nsg_rules_module_01" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_01
  priority_number=var.prioritynumber_01
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_deny01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_01
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_01
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_test_1.nsg_name_out,module.nsg_module_sn_glb_test_2.nsg_name_out,module.nsg_module_sn_glb_test_3.nsg_name_out]
}

module "nsg_rules_module_02" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_02
  priority_number=var.prioritynumber_01
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_deny01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_01
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_01
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_test_1.nsg_name_out,module.nsg_module_sn_glb_test_2.nsg_name_out,module.nsg_module_sn_glb_test_3.nsg_name_out]
}
module "nsg_rules_module_03" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_03
  priority_number=var.prioritynumber_02
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_01
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_02
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_test_1.nsg_name_out,module.nsg_module_sn_glb_test_2.nsg_name_out,module.nsg_module_sn_glb_test_3.nsg_name_out]
}
module "nsg_rules_module_04" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_04
  priority_number=var.prioritynumber_02
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_02
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_01
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_test_1.nsg_name_out,module.nsg_module_sn_glb_test_2.nsg_name_out,module.nsg_module_sn_glb_test_3.nsg_name_out]
}
# module "nsg_rules_module_05" {
#   source = "../../module/nsg_rules_creation"
#   nsg_rule_name=var.nsgrule_name_05
#   priority_number=var.prioritynumber_03
#   nsg_direction=var.nsg_direction_inbound01
#   nsg_accesstype=var.accesstype_deny01
#   nsg_protocol=var.protocol_01
#   nsg_source_port_range=var.source_port_range_01
#   nsg_destination_port_range=var.nsg_destination_port_range01
#   nsg_source_address_prefixe=var.nsg_source_address_prefixe_03
#   nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_01
#   resource_group_name=module.rg_module_sn_glb_test_1.rg_name
#   nsg_name=[module.nsg_module_sn_glb_test_1.nsg_name_out,module.nsg_module_sn_glb_test_2.nsg_name_out,module.nsg_module_sn_glb_test_3.nsg_name_out]
# }
# module "nsg_rules_module_06" {
#   source = "../../module/nsg_rules_creation"
#   nsg_rule_name=var.nsgrule_name_06
#   priority_number=var.prioritynumber_03
#   nsg_direction=var.nsg_direction_outbound01
#   nsg_accesstype=var.accesstype_deny01
#   nsg_protocol=var.protocol_01
#   nsg_source_port_range=var.source_port_range_01
#   nsg_destination_port_range=var.nsg_destination_port_range01
#   nsg_source_address_prefixe=var.nsg_source_address_prefixe_01
#   nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_03
#   resource_group_name=module.rg_module_sn_glb_test_1.rg_name
#   nsg_name=[module.nsg_module_sn_glb_test_1.nsg_name_out,module.nsg_module_sn_glb_test_2.nsg_name_out,module.nsg_module_sn_glb_test_3.nsg_name_out]
# }
module "recovery_service_vault"{
source= "../../module/recovery_services_vault_creation"
  recovery_vault_name              = var.recovery_serv_vault_name
  location                         = module.rg_module_sn_glb_test_3.rg_location
  resource_group_name              = module.rg_module_sn_glb_test_3.rg_name
  vault_sku_name                   = var.recovery_serv_vault_sku_name
  tags                             = var.tags_recovery_services
}
module "nsg_rules_module_07" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_07
  priority_number=var.prioritynumber_04
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_deny01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_04
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_04
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_test_1.nsg_name_out,module.nsg_module_sn_glb_test_2.nsg_name_out,module.nsg_module_sn_glb_test_3.nsg_name_out]
}
module "nsg_rules_module_08" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_08
  priority_number=var.prioritynumber_04
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_deny01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_04
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_04
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_test_1.nsg_name_out,module.nsg_module_sn_glb_test_2.nsg_name_out,module.nsg_module_sn_glb_test_3.nsg_name_out]
}
#.............................rdgw...............................................
module "nsg_rules_module_11" {
  source = "../../module/nsgrule_creation_list"
  nsg_rule_name=var.nsgrule_name_11
  priority_number=var.prioritynumber_06
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_rdgw
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_rdgw
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_04
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_test_1.nsg_name_out,module.nsg_module_sn_glb_test_2.nsg_name_out,module.nsg_module_sn_glb_test_3.nsg_name_out]
}
# ............jumbbox............
module "nsg_rules_module_12" {
  source = "../../module/nsgrule_creation_list"
  nsg_rule_name=var.nsgrule_name_12
  priority_number=var.prioritynumber_07
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_jmpbox
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_jmpbox
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_04
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_test_1.nsg_name_out,module.nsg_module_sn_glb_test_2.nsg_name_out,module.nsg_module_sn_glb_test_3.nsg_name_out]
}
# .............loadbalancer health probe.....................................
module "nsg_rules_module_13" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_13
  priority_number=var.prioritynumber_08
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_lb
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_04
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_test_1.nsg_name_out,module.nsg_module_sn_glb_test_2.nsg_name_out,module.nsg_module_sn_glb_test_3.nsg_name_out]
}
module "nsg_rules_module_14" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_14
  priority_number=var.prioritynumber_08
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_lb
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_01
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_test_1.nsg_name_out,module.nsg_module_sn_glb_test_2.nsg_name_out,module.nsg_module_sn_glb_test_3.nsg_name_out]
}
# ..........science logic....................................
module "nsg_rules_module_15" {
  source = "../../module/nsgrule_creation_list2"
  nsg_rule_name=var.nsgrule_name_15
  priority_number=var.prioritynumber_09
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_sl
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_sl
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_04
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_test_1.nsg_name_out,module.nsg_module_sn_glb_test_2.nsg_name_out,module.nsg_module_sn_glb_test_3.nsg_name_out]
}
# ..........commvault....................................
#.....tcp.........................
module "nsg_rules_module_16" {
  source = "../../module/nsgrule_creation_list2"
  nsg_rule_name=var.nsgrule_name_16
  priority_number=var.prioritynumber_10
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_cv_tcp
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_cv
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_04
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_test_1.nsg_name_out,module.nsg_module_sn_glb_test_2.nsg_name_out,module.nsg_module_sn_glb_test_3.nsg_name_out]
}
#.....udp........................................
module "nsg_rules_module_17" {
  source = "../../module/nsgrule_creation_list2"
  nsg_rule_name=var.nsgrule_name_17
  priority_number=var.prioritynumber_11
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_udp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_cv_udp
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_cv
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_04
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_test_1.nsg_name_out,module.nsg_module_sn_glb_test_2.nsg_name_out,module.nsg_module_sn_glb_test_3.nsg_name_out]
}
#.....outbound...................................................
# .....tcp....................................................
module "nsg_rules_module_18" {
  source = "../../module/nsgrule_creation_list4"
  nsg_rule_name=var.nsgrule_name_18
  priority_number=var.prioritynumber_10
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_cv_tcp
  nsg_source_address_prefix=var.nsg_source_address_prefixe_04
  nsg_destination_address_prefixes=var.nsg_destination_address_prefixe_cv
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_test_1.nsg_name_out,module.nsg_module_sn_glb_test_2.nsg_name_out,module.nsg_module_sn_glb_test_3.nsg_name_out]
}
#.....udp...........................................................................
module "nsg_rules_module_19" {
  source = "../../module/nsgrule_creation_list4"
  nsg_rule_name=var.nsgrule_name_19
  priority_number=var.prioritynumber_11
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_udp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_cv_udp
  nsg_source_address_prefix=var.nsg_source_address_prefixe_04
  nsg_destination_address_prefixes=var.nsg_destination_address_prefixe_cv
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_test_1.nsg_name_out,module.nsg_module_sn_glb_test_2.nsg_name_out,module.nsg_module_sn_glb_test_3.nsg_name_out]
}
#.....cylance outbound.............................................................
module "nsg_rules_module_20" {
  source = "../../module/nsgrule_creation_list3"
  nsg_rule_name=var.nsgrule_name_20
  priority_number=var.prioritynumber_12
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_cy
  nsg_source_address_prefix=var.nsg_source_address_prefixe_04
  nsg_destination_address_prefixes=var.nsg_destination_address_prefixe_cy
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_test_1.nsg_name_out,module.nsg_module_sn_glb_test_2.nsg_name_out,module.nsg_module_sn_glb_test_3.nsg_name_out]
}
#.....iboss outbound..................................................
module "nsg_rules_module_21" {
  source = "../../module/nsgrule_creation_list4"
  nsg_rule_name=var.nsgrule_name_21
  priority_number=var.prioritynumber_13
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_tcp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_ranges=var.nsg_destination_port_range_iboss
  nsg_source_address_prefix=var.nsg_source_address_prefixe_04
  nsg_destination_address_prefixes=var.nsg_destination_address_prefixe_iboss
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_test_1.nsg_name_out,module.nsg_module_sn_glb_test_2.nsg_name_out,module.nsg_module_sn_glb_test_3.nsg_name_out]
}
# ........rdrw udp................................................
module "nsg_rules_module_22" {
  source = "../../module/nsgrule_creation_list"
  nsg_rule_name=var.nsgrule_name_22
  priority_number=var.prioritynumber_14
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_udp
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range_rdgw
  nsg_source_address_prefixes=var.nsg_source_address_prefixe_rdgw
  nsg_destination_address_prefix=var.nsg_destination_address_prefixe_04
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_test_1.nsg_name_out,module.nsg_module_sn_glb_test_2.nsg_name_out,module.nsg_module_sn_glb_test_3.nsg_name_out]
}
# .......................................................................................
# ................idmz rules ..............................................................................
# .....int.................................................................................................
module "nsg_rules_module_23" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_23
  priority_number=var.prioritynumber_15
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_10
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_10
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_test_1.nsg_name_out]
}
module "nsg_rules_module_24" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_24
  priority_number=var.prioritynumber_15
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_10
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_10
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_test_1.nsg_name_out]
}
# ............idmz.....................................................................
module "nsg_rules_module_25" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_25
  priority_number=var.prioritynumber_15
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_11
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_11
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_test_2.nsg_name_out]
}
module "nsg_rules_module_26" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_26
  priority_number=var.prioritynumber_15
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_11
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_11
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_test_2.nsg_name_out]
}
# ............edmz.....................................................................
module "nsg_rules_module_27" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_27
  priority_number=var.prioritynumber_15
  nsg_direction=var.nsg_direction_inbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_12
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_12
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_test_3.nsg_name_out]
}
module "nsg_rules_module_28" {
  source = "../../module/nsg_rules_creation"
  nsg_rule_name=var.nsgrule_name_28
  priority_number=var.prioritynumber_15
  nsg_direction=var.nsg_direction_outbound01
  nsg_accesstype=var.accesstype_allow01
  nsg_protocol=var.protocol_01
  nsg_source_port_range=var.source_port_range_01
  nsg_destination_port_range=var.nsg_destination_port_range01
  nsg_source_address_prefixe=var.nsg_source_address_prefixe_12
  nsg_destination_address_prefixe=var.nsg_destination_address_prefixe_12
  resource_group_name=module.rg_module_sn_glb_test_1.rg_name
  nsg_name=[module.nsg_module_sn_glb_test_3.nsg_name_out]
}

# .............keyvault.................................................................
   module "keyvault_creation" {
  source ="../../module/keyvault_creation"
  rg_name=module.rg_module_sn_glb_test_4.rg_name
  location=module.rg_module_sn_glb_test_4.rg_location
  object_id= var.object_id
  keyvault_name=var.keyvault_name
  sku_name=var.sku
  tags=var.tags_app
  soft_delete_retention_days=var.soft_retention_days
  }
  module "accesspolicy_keyvault"{
    source ="../../module/add_accesspolicies"
    object_ids= var.object_id_01
    keyvault_id=module.keyvault_creation.keyvault_id
    depends_on=[module.keyvault_creation]
  }

  module "accesspolicy_keyvault01"{
    source ="../../module/add_accesspolicies"
    object_ids= var.object_id_02
    keyvault_id=module.keyvault_creation.keyvault_id
    depends_on=[module.keyvault_creation]
  }
