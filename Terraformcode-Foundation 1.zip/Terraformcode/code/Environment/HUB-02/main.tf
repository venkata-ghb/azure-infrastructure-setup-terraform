terraform {
  required_version ="0.13.5"
 } 
# -------------------------------------------------------we hub resource Group creation-------------------------------------------------------
#output variables for this block is {rg_name,rg_id and rg_location}
module "rg_module_we_hub_1" {
  source= "../../module/rg_creation"
  resourcegrp_name=var.resource_group_name
  location=var.location
  tags=var.tags
}
module "rg_module_we_hub_2" {
  source= "../../module/rg_creation"
  resourcegrp_name=var.resource_group_name01
  location=var.location
  tags=var.tags_recovery_services
}
module "rg_module_we_hub_3" {
  source= "../../module/rg_creation"
  resourcegrp_name=var.resource_group_name02
  location=var.location
  tags=var.tags_mgmt
}
module "rg_module_sn_hub_4" {
  source= "../../module/rg_creation"
  resourcegrp_name=var.resource_group_name03
  location=var.location
  tags=var.tags_app
}
# ....................vnet modules..................................................................
module "vnet_module_we_hub_1" {
source ="../../module/vnet_creation_hub"
vnet_name=var.vnet_name_we_hub_1
location=module.rg_module_we_hub_1.rg_location
resourcegrp_name=module.rg_module_we_hub_1.rg_name
vnet_address_prefix=var.vnet_addr_prefix_we_hub_1
tags_vnet=var.tags
depends_on =[module.rg_module_we_hub_1]
} 
module "vnet_module_we_hub_2" {
  source ="../../module/vnet_creation_hub"
  vnet_name=var.vnet_name_we_hub_2
  location=module.rg_module_we_hub_1.rg_location
  resourcegrp_name=module.rg_module_we_hub_1.rg_name
  vnet_address_prefix=var.vnet_addr_prefix_we_hub_2
  tags_vnet=var.tags
  depends_on =[module.rg_module_we_hub_1]
} 
# ................subnet modules...........................................................
module "subnet_module_we_hub_1" {
  source = "../../module/subnet_creation"
  subnet_name=var.subnet_name_we_hub_1
  vnet_name=module.vnet_module_we_hub_1.vnet_name
  resourcegrp_name=module.rg_module_we_hub_1.rg_name
  address_space=var.addr_space_we_hub_1
  depends_on =[module.vnet_module_we_hub_1]
}
# ...................expressroute circuit....................................................
module "module_expressroute_circuit" {
source = "../../module/expressroute"
expressckt_name=var.circuit_name
rg_name=module.rg_module_we_hub_1.rg_name
location=module.rg_module_we_hub_1.rg_location
service_provider=var.service_provider
peering_location=var.peering_location
bandwidth=var.bandwidth01
service_tier=var.service_tier01  
billing_mode=var.billing  
tags_er=var.tags_er
}
# ................express route gateway...............................................................
module "module_expressroute_gateway01"{
source="../../module/er_gateway"
er_gateway=var.expressroute_gateway
location=module.rg_module_we_hub_1.rg_location
resource_group=module.rg_module_we_hub_1.rg_name
ipconfig=var.ipconfig 
sku=var.sku
gateway_type=var.gateway_type01
publicip=module.module_publicip01.public_ip_id
subnet_id=module.subnet_module_we_hub_1.subnet_id
private_ip_address_allocation=var.private_ip_allocation
tags=var.tags_er
}
# .................public ip...................................................................
module "module_publicip01"{
source="../../module/publicip_creation"
public_ip_name=var.public_ip
location=module.rg_module_we_hub_1.rg_location
rg_name=module.rg_module_we_hub_1.rg_name
public_ip_allocation=var.public_ipallloc
sku=var.sku_publicip
tags=var.tags_er
}

# #-------------------------------------WE hub subnet creation-----------------------------------------------------------------
# #output variables for this block is {subnet_id and subnet_address_prefix}
# subnet in hubvnet01
# module "subnet_module_we_hub_1" {
#   source = "../../module/subnet_creation"
#   subnet_name=var.subnet_name_we_hub_1
#   vnet_name=module.vnet_module_we_hub_1.vnet_name
#   resourcegrp_name=module.rg_module_we_hub_1.rg_name
#   address_space=var.addr_space_we_hub_1
#   depends_on =[module.vnet_module_we_hub_1]
# }
module "subnet_module_we_hub_2" {
  source = "../../module/subnet_creation"
  subnet_name=var.subnet_name_we_hub_2
  vnet_name=module.vnet_module_we_hub_1.vnet_name
  resourcegrp_name=module.rg_module_we_hub_1.rg_name
  address_space=var.addr_space_we_hub_2
  depends_on =[module.vnet_module_we_hub_1]
}

module "subnet_module_we_hub_3" {
  source = "../../module/subnet_creation"
  subnet_name=var.subnet_name_we_hub_3
  vnet_name=module.vnet_module_we_hub_1.vnet_name
  resourcegrp_name=module.rg_module_we_hub_1.rg_name
  address_space=var.addr_space_we_hub_3
  depends_on =[module.vnet_module_we_hub_1]
}
module "subnet_module_we_hub_4" {
  source = "../../module/subnet_creation"
  subnet_name=var.subnet_name_we_hub_4
  vnet_name=module.vnet_module_we_hub_1.vnet_name
  resourcegrp_name=module.rg_module_we_hub_1.rg_name
  address_space=var.addr_space_we_hub_4
  depends_on =[module.vnet_module_we_hub_1]
}
module "subnet_module_we_hub_5" {
  source = "../../module/subnet_creation"
  subnet_name=var.subnet_name_we_hub_5
  vnet_name=module.vnet_module_we_hub_1.vnet_name
  resourcegrp_name=module.rg_module_we_hub_1.rg_name
  address_space=var.addr_space_we_hub_5
  depends_on =[module.vnet_module_we_hub_1]
}
#subnet in hubvnet02
module "subnet_module_we_hub_6" {
  source = "../../module/subnet_creation"
  subnet_name=var.subnet_name_we_hub_6
  vnet_name=module.vnet_module_we_hub_2.vnet_name
  resourcegrp_name=module.rg_module_we_hub_1.rg_name
  address_space=var.addr_space_we_hub_6
  depends_on =[module.vnet_module_we_hub_2]
}
module "subnet_module_we_hub_7" {
  source = "../../module/subnet_creation"
  subnet_name=var.subnet_name_we_hub_7
  vnet_name=module.vnet_module_we_hub_2.vnet_name
  resourcegrp_name=module.rg_module_we_hub_1.rg_name
  address_space=var.addr_space_we_hub_7
  depends_on =[module.vnet_module_we_hub_2]
}
# ................................existing vnet..................................................................................
# ...............glbtest................................
module "existingvnetglbtest" {
  providers={
    azurerm=azurerm.glbtest
  }
  source = "../../module/existing_vnet"
  existingvnet=var.existingvnetglbtest01
  rg_name=var.existingresourcegroupglbtest01
  }
# ............... glbprod............................
module "existingvnetglbprodZ1A" {
  providers={
    azurerm=azurerm.glbprod
  }
source = "../../module/existing_vnet"
  existingvnet=var.existingvnetglbprodZ1A01
  rg_name=var.existingresourcegroupglbprodZ1A01
  
}
module "existingvnetglbprodZ1B" {
  providers={
    azurerm=azurerm.glbprod
  }
  source = "../../module/existing_vnet"
  existingvnet=var.existingvnetglbprodZ1B01
  rg_name=var.existingresourcegroupglbprodZ1B01
  
}
module "existingvnetglbprodZ3" {
  providers={
    azurerm=azurerm.glbprod
  }
  source = "../../module/existing_vnet"
  existingvnet=var.existingvnetglbprodZ301
  rg_name=var.existingresourcegroupglbprodZ301
  
}
module "existingvnetglbprodZ1C" {
  providers={
    azurerm=azurerm.glbprod
  }
  source = "../../module/existing_vnet"
  existingvnet=var.existingvnetglbprodZ1C01
  rg_name=var.existingresourcegroupglbprodZ1C01
}
# sapprod
module "existingvnetsapprod" {
  providers={
    azurerm=azurerm.sapprod
  }
  source = "../../module/existing_vnet"
  existingvnet=var.existingvnetsapprod01
  rg_name=var.existingresourcegroupsapprod01
}
# saptest
module "existingvnetsaptest" {
  providers={
    azurerm=azurerm.saptest
  }
  source = "../../module/existing_vnet"
  existingvnet=var.existingvnetsaptest01
  rg_name=var.existingresourcegroupsaptest01
}
#sn_hub
module "existingvnetsnhubvnet01" {
  providers={
    azurerm=azurerm.sn_hub
  }
source = "../../module/existing_vnet"
  existingvnet=var.existingvnetsnhubvnet01
  rg_name=var.existingresourcegroupsn_hubvnet01
  
}
module "existingvnetsnhubvnet02" {
  providers={
    azurerm=azurerm.sn_hub
  }
source = "../../module/existing_vnet"
  existingvnet=var.existingvnetsnhubvnet02
  rg_name=var.existingresourcegroupsn_hubvnet01
  
}
#......................vnetpeering ...........................................................
# we-hub-vnet01 to we-hub-vnet02
 module "we_hub_vnet_peering_module1" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.we_hub_vnet_peering_name_01
  resourcegrp_name=module.rg_module_we_hub_1.rg_name
  vnet_name=module.vnet_module_we_hub_1.vnet_name
  vnet_remote_id=module.vnet_module_we_hub_2.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_01
  use_remote_gateways=var.use_remote_gateways_01
}
# we_hub_vnet02 to we_hub_vnet01
module "we_hub_vnet_peering_module2" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.we_hub_vnet_peering_name_02
  resourcegrp_name=module.rg_module_we_hub_1.rg_name
  vnet_name=module.vnet_module_we_hub_2.vnet_name
  vnet_remote_id=module.vnet_module_we_hub_1.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_02
  use_remote_gateways=var.use_remote_gateways_02
}
# vnet01 to spoke vnets
# glbtest
module "we_hub_vnet_peering_module3" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.we_hub_vnet_peering_name_03
  resourcegrp_name=module.rg_module_we_hub_1.rg_name
  vnet_name=module.vnet_module_we_hub_1.vnet_name
  vnet_remote_id=module.existingvnetglbtest.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_03
  use_remote_gateways=var.use_remote_gateways_03
}
# glbprod-Z1A
module "we_hub_vnet_peering_module4" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.we_hub_vnet_peering_name_04
  resourcegrp_name=module.rg_module_we_hub_1.rg_name
  vnet_name=module.vnet_module_we_hub_1.vnet_name
  vnet_remote_id=module.existingvnetglbprodZ1A.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_04
  use_remote_gateways=var.use_remote_gateways_04
}
# glbprod-Z1B
module "we_hub_vnet_peering_module5" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.we_hub_vnet_peering_name_05
  resourcegrp_name=module.rg_module_we_hub_1.rg_name
  vnet_name=module.vnet_module_we_hub_1.vnet_name
  vnet_remote_id=module.existingvnetglbprodZ1B.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_05
  use_remote_gateways=var.use_remote_gateways_05
}
# glbprod-Z3
module "we_hub_vnet_peering_module6" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.we_hub_vnet_peering_name_06
  resourcegrp_name=module.rg_module_we_hub_1.rg_name
  vnet_name=module.vnet_module_we_hub_1.vnet_name
  vnet_remote_id=module.existingvnetglbprodZ3.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_06
  use_remote_gateways=var.use_remote_gateways_06
}
# glbprod-Z1C
module "we_hub_vnet_peering_module7" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.we_hub_vnet_peering_name_07
  resourcegrp_name=module.rg_module_we_hub_1.rg_name
  vnet_name=module.vnet_module_we_hub_1.vnet_name
  vnet_remote_id=module.existingvnetglbprodZ1C.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_07
  use_remote_gateways=var.use_remote_gateways_07
}
# SAPPROD
module "we_hub_vnet_peering_module8" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.we_hub_vnet_peering_name_08
  resourcegrp_name=module.rg_module_we_hub_1.rg_name
  vnet_name=module.vnet_module_we_hub_1.vnet_name
  vnet_remote_id=module.existingvnetsapprod.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_08
  use_remote_gateways=var.use_remote_gateways_08
}
# SAPTEST
module "we_hub_vnet_peering_module9" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.we_hub_vnet_peering_name_09
  resourcegrp_name=module.rg_module_we_hub_1.rg_name
  vnet_name=module.vnet_module_we_hub_1.vnet_name
  vnet_remote_id=module.existingvnetsaptest.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_09
  use_remote_gateways=var.use_remote_gateways_09
}
# ......VNET02 TO SPOKE VNETS
# glbtest
module "we_hub_vnet_peering_module10" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.we_hub_vnet_peering_name_10
  resourcegrp_name=module.rg_module_we_hub_1.rg_name
  vnet_name=module.vnet_module_we_hub_2.vnet_name
  vnet_remote_id=module.existingvnetglbtest.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_10
  use_remote_gateways=var.use_remote_gateways_10
}
# glbprodz1a
module "we_hub_vnet_peering_module11" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.we_hub_vnet_peering_name_11
  resourcegrp_name=module.rg_module_we_hub_1.rg_name
  vnet_name=module.vnet_module_we_hub_2.vnet_name
  vnet_remote_id=module.existingvnetglbprodZ1A.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_11
  use_remote_gateways=var.use_remote_gateways_11
}
# glbprodz1b
module "we_hub_vnet_peering_module12" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.we_hub_vnet_peering_name_12
  resourcegrp_name=module.rg_module_we_hub_1.rg_name
  vnet_name=module.vnet_module_we_hub_2.vnet_name
  vnet_remote_id=module.existingvnetglbprodZ1B.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_12
  use_remote_gateways=var.use_remote_gateways_12
}
# glbprodz3
module "we_hub_vnet_peering_module13" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.we_hub_vnet_peering_name_13
  resourcegrp_name=module.rg_module_we_hub_1.rg_name
  vnet_name=module.vnet_module_we_hub_2.vnet_name
  vnet_remote_id=module.existingvnetglbprodZ3.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_13
  use_remote_gateways=var.use_remote_gateways_13
}
# glbprodz1c
module "we_hub_vnet_peering_module14" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.we_hub_vnet_peering_name_14
  resourcegrp_name=module.rg_module_we_hub_1.rg_name
  vnet_name=module.vnet_module_we_hub_2.vnet_name
  vnet_remote_id=module.existingvnetglbprodZ1C.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_14
  use_remote_gateways=var.use_remote_gateways_14
}
# SAP PROD
module "we_hub_vnet_peering_module15" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.we_hub_vnet_peering_name_15
  resourcegrp_name=module.rg_module_we_hub_1.rg_name
  vnet_name=module.vnet_module_we_hub_2.vnet_name
  vnet_remote_id=module.existingvnetsapprod.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_15
  use_remote_gateways=var.use_remote_gateways_15
}
# SAP TEST
module "we_hub_vnet_peering_module16" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.we_hub_vnet_peering_name_16
  resourcegrp_name=module.rg_module_we_hub_1.rg_name
  vnet_name=module.vnet_module_we_hub_2.vnet_name
  vnet_remote_id=module.existingvnetsaptest.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_16
  use_remote_gateways=var.use_remote_gateways_16
}
# WE VNET01 to SN VNET01
module "we_hub_vnet_peering_module17" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.we_hub_vnet_peering_name_17
  resourcegrp_name=module.rg_module_we_hub_1.rg_name
  vnet_name=module.vnet_module_we_hub_1.vnet_name
  vnet_remote_id=module.existingvnetsnhubvnet01.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_17
  use_remote_gateways=var.use_remote_gateways_17
}
# WE VNET02 to SN VNET02
module "we_hub_vnet_peering_module18" {
  source = "../../module/vnet_peering"
  vnet_peer_name=var.we_hub_vnet_peering_name_18
  resourcegrp_name=module.rg_module_we_hub_1.rg_name
  vnet_name=module.vnet_module_we_hub_2.vnet_name
  vnet_remote_id=module.existingvnetsnhubvnet01.vnet_id
  allow_virtual_network_access=var.allow_virtual_network_access
  allow_forwarded_traffic=var.allow_forwarded_traffic
  allow_gateway_transit=var.allow_gateway_transit_18
  use_remote_gateways=var.use_remote_gateways_18
}
#----------------------------Recovery Service Vault-----------------------
module "recovery_service_vault"{
source= "../../module/recovery_services_vault_creation"
  recovery_vault_name              = var.recovery_serv_vault_name
  location                         = module.rg_module_we_hub_2.rg_location
  resource_group_name              = module.rg_module_we_hub_2.rg_name
  vault_sku_name                   = var.recovery_serv_vault_sku_name
  tags                             = var.tags_recovery_services
}
#--------------------Log Analytics-----------------------------
module "log_analytics"{
source= "../../module/loganalytics_creation"
log_workspace_name=var.log_analytics_workspace_name
location= module.rg_module_we_hub_3.rg_location
resource_group_name=module.rg_module_we_hub_3.rg_name
log_workspace_sku_name=var.log_workspace_sku_name
log_workspace_retention=var.log_workspace_retention
tags_logs=var.tags_mgmt
}
#------storageaccount--------------------------------------
module "storageaccount_module01" {
  source = "../../module/storageaccount_creation"
  storageaccountname=var.storageaccountname01
  location=module.rg_module_we_hub_3.rg_location
  resourcegrp_name=module.rg_module_we_hub_3.rg_name
 storage_account_type="Standard_LRS"
  account_kind="StorageV2"
  access_tier="Hot"
  tags=var.tags_mgmt
}
module "route_table_module_we_hub_2" {
  source = "../../module/route_table_creation"
  route_table_name=var.route_table_name_we_hub_2
  location=module.rg_module_we_hub_1.rg_location
  resource_group_name=module.rg_module_we_hub_1.rg_name
  bgp_route_propagation=var.bgp_route_propagations01
  route_tags=var.tags
  depends_on =[module.rg_module_we_hub_1]
}
module "route_table_module_we_hub_3" {
  source = "../../module/route_table_creation"
  route_table_name=var.route_table_name_we_hub_3
  location=module.rg_module_we_hub_1.rg_location
  resource_group_name=module.rg_module_we_hub_1.rg_name
  bgp_route_propagation=var.bgp_route_propagations01
  route_tags=var.tags
  depends_on =[module.rg_module_we_hub_1]
}
module "route_table_module_we_hub_4" {
  source = "../../module/route_table_creation"
  route_table_name=var.route_table_name_we_hub_4
  location=module.rg_module_we_hub_1.rg_location
  resource_group_name=module.rg_module_we_hub_1.rg_name
  bgp_route_propagation=var.bgp_route_propagations01
  route_tags=var.tags
  depends_on =[module.rg_module_we_hub_1]
}
# ..............ROUTE....................................................
module "routes_module_we_gW" {
source ="../../module/routetable_route_nxthop"
route_name=var.route_name_gw
resource_group_name=module.rg_module_we_hub_1.rg_name
route_table_name=module.route_table_module_we_hub_4.route_table_name_output 
route_address_prefix=var.route_addressPrefix_we_gw
next_hop_type=var.route_nextHopType_we_gw
nexthop_in_ip_address=var.nxthopip_cp_gw
}
module "routes_module_we_gW01" {
source ="../../module/routetable_route_nxthop"
route_name=var.route_name_gw01
resource_group_name=module.rg_module_we_hub_1.rg_name
route_table_name=module.route_table_module_we_hub_4.route_table_name_output 
route_address_prefix=var.route_addressPrefix_we_gw01
next_hop_type=var.route_nextHopType_we_gw01
nexthop_in_ip_address=var.nxthopip_cp_gw01
}
module "routes_module_we_glb" {
source ="../../module/routetable_route_nxthop"
route_name=var.route_name_glb
resource_group_name=module.rg_module_we_hub_1.rg_name
route_table_name=module.route_table_module_we_hub_2.route_table_name_output 
route_address_prefix=var.route_addressPrefix_we_glb
next_hop_type=var.route_nextHopType_we_glb
nexthop_in_ip_address=var.nxthopip_cp_glb
}
module "routes_module_we_glb_we" {
source ="../../module/routetable_route_nxthop"
route_name=var.route_name_glb_we
resource_group_name=module.rg_module_we_hub_1.rg_name
route_table_name=module.route_table_module_we_hub_2.route_table_name_output 
route_address_prefix=var.route_addressPrefix_we_glb_we
next_hop_type=var.route_nextHopType_we_glb_we
nexthop_in_ip_address=var.nxthopip_cp_glb_we
}
module "routes_module_we_sap" {
source ="../../module/routetable_route_nxthop"
route_name=var.route_name_sap
resource_group_name=module.rg_module_we_hub_1.rg_name
route_table_name=module.route_table_module_we_hub_3.route_table_name_output 
route_address_prefix=var.route_addressPrefix_we_sap
next_hop_type=var.route_nextHopType_we_sap
nexthop_in_ip_address=var.nxthopip_cp_sap
}
module "routes_module_we_sap_we" {
source ="../../module/routetable_route_nxthop"
route_name=var.route_name_sap_we
resource_group_name=module.rg_module_we_hub_1.rg_name
route_table_name=module.route_table_module_we_hub_3.route_table_name_output 
route_address_prefix=var.route_addressPrefix_we_sap_we
next_hop_type=var.route_nextHopType_we_sap_we
nexthop_in_ip_address=var.nxthopip_cp_sap_we
}

# .............keyvault.....................................................

  module "keyvault_creation" {
  source ="../../module/keyvault_creation"
  rg_name=module.rg_module_sn_hub_4.rg_name
  location=module.rg_module_sn_hub_4.rg_location
  object_id= var.object_id
  keyvault_name=var.keyvault_name
  sku_name=var.sku01
  tags=var.tags_app
  soft_delete_retention_days=var.soft_retention_days
  }
  module "accesspolicy_keyvault"{
    source ="../../module/add_accesspolicies"
    object_ids= var.object_id_01
    keyvault_id=module.keyvault_creation.keyvault_id
    depends_on=[module.keyvault_creation]
  }

  module "accesspolicy_keyvault01"{
    source ="../../module/add_accesspolicies"
    object_ids= var.object_id_02
    keyvault_id=module.keyvault_creation.keyvault_id
    depends_on=[module.keyvault_creation]
  }
module "rsv_diagnostics"{
source = "../../module/diagnosticsettings"
resource_id=[module.recovery_service_vault.rsv_id]
dlog_name=var.diagnosticsettings_rsv
target_id=[module.recovery_service_vault.rsv_id]
storage_acc_id =module.storageaccount_module01.sta_id
workspace_rs_id =module.log_analytics.workspace_resource_id
}

module "publicip_diagnostics"{
source = "../../module/diagnosticsettings"
resource_id=[module.module_publicip01.public_ip_id]
dlog_name=var.diagnosticsettings_pubip
target_id=[module.module_publicip01.public_ip_id]
storage_acc_id =module.storageaccount_module01.sta_id
workspace_rs_id =module.log_analytics.workspace_resource_id
}