variable "route_table_name" {
  description="The name of the route table."
  type=string
}

variable "location" {
  description="Specifies the supported Azure location where the resource exists."
  type=string
}
variable "resource_group_name" {
   description="The name of the resource group in which to create the route table."
  type=string
}
variable "bgp_route_propagation" {
   description="Boolean flag which controls propagation of routes learned by BGP on that route table. True means disable."
  type=string
}
variable "route_tags" {
   description=" A mapping of tags to assign to the resource."
  type=map(string)
}
