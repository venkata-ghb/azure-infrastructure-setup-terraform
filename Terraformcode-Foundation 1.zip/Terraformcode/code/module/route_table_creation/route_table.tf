resource azurerm_route_table routetable {
  name                          = var.route_table_name
  location                      = var.location
  resource_group_name           = var.resource_group_name
  disable_bgp_route_propagation = var.bgp_route_propagation
  tags = var.route_tags
  
}
 output route_table_name_output {
  value = azurerm_route_table.routetable.name
}
output route_table_id{
    value=azurerm_route_table.routetable.id
}