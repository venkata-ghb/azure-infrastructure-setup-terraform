resource azurerm_network_security_rule nsgrules {
 count= length(var.nsg_name)
  name                        = var.nsg_rule_name
  priority                    = var.priority_number
  direction                   = var.nsg_direction
  access                      = var.nsg_accesstype
  protocol                    = var.nsg_protocol
  source_port_range          = var.nsg_source_port_range
  destination_port_range     = var.nsg_destination_port_range
  source_address_prefix      = var.nsg_source_address_prefix
  destination_address_prefixes= var.nsg_destination_address_prefixes
  resource_group_name         = var.resource_group_name
  network_security_group_name =var.nsg_name[count.index]
}
