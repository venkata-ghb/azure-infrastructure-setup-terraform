variable "workspace_rs_id" {
  description="name of the network security group"
}

variable "dlog_name" {
  description="location of the network security group"
  type=list(string)
}
variable "target_id" {
  description="name of the resource group for network security group"
  type=list(string)
}
variable "storage_acc_id" {
  description="name of the resource group for network security group"
}
variable "resource_id" {
  description="name of the resource group for network security group"
  type=list(string)
}