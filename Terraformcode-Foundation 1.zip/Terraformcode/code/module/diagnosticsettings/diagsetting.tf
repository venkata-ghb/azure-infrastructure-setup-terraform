data "azurerm_monitor_diagnostic_categories" "names" {
  count       = length(var.resource_id)
  resource_id = var.resource_id[count.index]
}
resource "azurerm_monitor_diagnostic_setting" "diag_name" {
  count                      = length(var.dlog_name)
  name                       = var.dlog_name[count.index]
  target_resource_id         = var.target_id[count.index]
  storage_account_id         = var.storage_acc_id 
  log_analytics_workspace_id = var.workspace_rs_id 
  dynamic "log" {
    for_each = [for lg in data.azurerm_monitor_diagnostic_categories.names[count.index].logs : {
      lg_name = lg
      }
    ]
    content {
      category = log.value.lg_name
      enabled  = true
      retention_policy {
        enabled = true
        days=30
      }
    }
  }
}