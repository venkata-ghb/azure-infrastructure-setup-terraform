
variable "subnet_id" {
  description="id of the subnet to associate to nsg"
}
variable "nsg_id" {
  description="id of the nsg for associating subnets"
}
