variable "recovery_vault_name" {
  description="The Name of the Recovery Service Vault"
}
variable "location" {
  description=" The location where the resource exists"
}
variable "resource_group_name" {
  description="The name of the resource group in which the recovery service vault is created"
}
variable "vault_sku_name" {
  description="Specifies the Sku of the Recovery Service Vault"
}
variable "tags" {
  description="A mapping of tags to assign to the resource"
}