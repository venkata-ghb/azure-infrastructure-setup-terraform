resource "azurerm_recovery_services_vault" "recovery_vault" {
  name                 = var.recovery_vault_name
  location             = var.location
  resource_group_name  = var.resource_group_name
  sku                  = var.vault_sku_name
  tags                 = var.tags
}
output rsv_id {
  value =azurerm_recovery_services_vault.recovery_vault.id
}
