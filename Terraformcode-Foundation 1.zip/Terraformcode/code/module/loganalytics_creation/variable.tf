variable "log_workspace_name" {
  description="The Name of the Log Analytics Workspace"
  type=string
}
variable "location" {
  description=" The location where the resource exists"
  type=string
}
variable "resource_group_name" {
  description="The name of the resource group in which the Log Analytics workspace is created"
  type=string
}
variable "log_workspace_sku_name" {
  type=string
  description="Specifies the Sku of the Log Analytics Workspace. Possible values are Free, PerNode, Premium, Standard, Standalone, Unlimited, and PerGB2018"
}
variable "log_workspace_retention" {
  type=number
  description="The workspace data retention in days. Possible values range between 30 and 730"
}
variable "tags_logs" {
  description="A mapping of tags to assign to the resource"
  type=map(string)
}
