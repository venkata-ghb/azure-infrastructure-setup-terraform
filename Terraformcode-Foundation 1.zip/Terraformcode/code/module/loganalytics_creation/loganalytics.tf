resource "azurerm_log_analytics_workspace" log_analytics_workspace {
  name                = var.log_workspace_name
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = var.log_workspace_sku_name
  retention_in_days   = var.log_workspace_retention
  tags                = var.tags_logs
}

output "law" {
  value =azurerm_log_analytics_workspace.log_analytics_workspace.workspace_id
}
output "law_name" {
  value =azurerm_log_analytics_workspace.log_analytics_workspace.name
}
output "primary_shared_key" {
  value =azurerm_log_analytics_workspace.log_analytics_workspace.primary_shared_key
}
output "workspace_resource_id" {
  value =azurerm_log_analytics_workspace.log_analytics_workspace.id
}
