variable "storage_account_container_name" {
    type=string
    }
variable "storage_account_name" {
  description = "name of the storage account"
  type=string
}
variable "access_type" {
  description = "Storage account type for storage container"
  type=string
}

