variable "expressckt_name"{
    type=string
}
variable "rg_name"{
    type=string
}
variable "location"{
    type=string
}
variable "service_provider"{
    type=string
}
variable "service_tier"{
    type=string
}
variable "billing_mode"{
    type=string
}
variable "tags_er"{
    type=map(string)
}
variable "bandwidth"{
    type=number
}
variable "peering_location"{
    type=string
}