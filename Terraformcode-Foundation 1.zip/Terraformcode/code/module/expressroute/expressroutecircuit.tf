resource "azurerm_express_route_circuit" "expressroute" {
  name                  = var.expressckt_name
  resource_group_name   = var.rg_name
  location              = var.location
  service_provider_name = var.service_provider
  peering_location      = var.peering_location
  bandwidth_in_mbps     = var.bandwidth

  sku {
    tier   = var.service_tier
    family =var.billing_mode
  }

  tags =var.tags_er
}
output "rg_id" {
  value = azurerm_express_route_circuit.expressroute.id
}
