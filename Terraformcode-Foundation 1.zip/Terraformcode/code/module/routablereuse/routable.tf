data "azurerm_route_table" "example" {
  name                = var.routable_name
  resource_group_name = var.resource_group_name
}

output route_id{
  value = azurerm_resource_group.rg_name.id
}