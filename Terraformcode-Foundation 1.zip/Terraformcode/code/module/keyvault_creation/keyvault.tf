data "azurerm_client_config" "current"{}
resource "azurerm_key_vault" "keyvault_creation" {
  name                        = var.keyvault_name
  location                    = var.location
  resource_group_name         = var.rg_name
  enabled_for_disk_encryption = true
  enabled_for_template_deployment=true
  enabled_for_deployment=true
  soft_delete_enabled=true
  soft_delete_retention_days=var.soft_delete_retention_days
  tenant_id = data.azurerm_client_config.current.tenant_id
  sku_name = var.sku_name
 
  access_policy {
    tenant_id =data.azurerm_client_config.current.tenant_id
    
    object_id = var.object_id

    key_permissions = [
       "backup",
      "create",
      "decrypt",
      "delete",
      "encrypt",
      "get",
      "import",
      "list",
      "recover",
      "restore",
      "sign",
      "unwrapKey",
      "update",
      "verify",
      "wrapKey",
    ]

    secret_permissions = [
     "backup",
      "delete",
      "get",
      "list",
      "set",
    ]

    storage_permissions = [
      "get",
      "list",
      "delete",
    ]
     certificate_permissions = [
      "create",
      "delete",
      "deleteissuers",
      "get",
      "getissuers",
      "import",
      "list",
      "listissuers",
      "managecontacts",
      "manageissuers",
      "setissuers",
      "update",
    ]
  }
tags =var.tags
}
output "tenantid" {
  value =data.azurerm_client_config.current.tenant_id
}

output "vault_uri" {
  value =azurerm_key_vault.keyvault_creation.vault_uri
}
output "keyvault_id" {
  value =azurerm_key_vault.keyvault_creation.id
}
