variable "rg_name" {
  description="The name of the resource group in which to create the Key Vault"
}
variable "location" {
  description="Specifies the supported Azure location where the resource exists"
}
variable "keyvault_name" {
 description="Specifies the name of the Key Vault"
}
variable "object_id" {
  type=string
  description="The object ID of a user,service principal or security group in the Azure Active Directory tenant for the vault"
}
variable "sku_name" {
  description="The Name of the SKU used for this Key Vault.Possible values are standard and premium"
}
variable "soft_delete_retention_days" {
type=number
}
variable "tags" {
  description="A mapping of tags to assign to the resource"
  type=map(string)
}