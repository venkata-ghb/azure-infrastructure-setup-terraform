
resource azurerm_virtual_network vnet {
  name                = var.vnet_name
  location            = var.location
  resource_group_name = var.resourcegrp_name
  address_space       = var.vnet_address_prefix
  #  dns_servers=var.address_dnsservers
  tags=var.tags_vnet
 
}

output vnet_id {
  value = azurerm_virtual_network.vnet.id
}
output vnet_name {
  value = azurerm_virtual_network.vnet.name
}
