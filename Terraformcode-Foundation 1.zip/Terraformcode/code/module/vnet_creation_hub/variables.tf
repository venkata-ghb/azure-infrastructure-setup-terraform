
variable "vnet_name" {
  description="The name of the virtual network"
}
variable "location" {
 description="The location/region where the virtual network is created"
}
variable "resourcegrp_name" {
   description="The name of the  resource group in which to create the virtual network"
  }

variable "vnet_address_prefix" {
  description="The address prefix to use for the vnet"
  type=list(string)
}
# variable "address_dnsservers" {
#   description="List of IP addresses of DNS servers"
#   type=list(string)
# }

variable "tags_vnet" {
  type=map(string)
  description="A mapping of tags to assign to the resource"
}


