data azurerm_subscription current {
}

output current_subscription_id {
  value = data.azurerm_subscription.current.id
}