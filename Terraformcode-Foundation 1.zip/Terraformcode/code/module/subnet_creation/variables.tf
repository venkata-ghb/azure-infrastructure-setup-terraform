
variable "subnet_name" {
   description="The name of the subnet"
   
}
variable "vnet_name" {
   description="The name of the virtual network"
}


variable "resourcegrp_name" {
     description="The name of the  resource group in which to create the virtual network peering"
}

variable "address_space" {
    description="The address space that is used for the subnet"
   
}





