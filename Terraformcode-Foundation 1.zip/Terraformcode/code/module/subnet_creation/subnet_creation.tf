
resource "azurerm_subnet" "subnet" {
  name                = var.subnet_name
  virtual_network_name = var.vnet_name
  resource_group_name = var.resourcegrp_name
  address_prefix      = var.address_space

}
output subnet_id {
  value = azurerm_subnet.subnet.id
}
output subnet_address_prefix {
  value = azurerm_subnet.subnet.address_prefix
}
