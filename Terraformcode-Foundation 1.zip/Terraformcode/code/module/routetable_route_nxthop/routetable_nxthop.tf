resource "azurerm_route" "routetableroute" {
  count                  = length(var.route_name)
  name                   = var.route_name[count.index]
  resource_group_name    = var.resource_group_name
  route_table_name       = var.route_table_name
  address_prefix         = var.route_address_prefix[count.index]
  next_hop_type          = var.next_hop_type
  next_hop_in_ip_address = var.nexthop_in_ip_address
}