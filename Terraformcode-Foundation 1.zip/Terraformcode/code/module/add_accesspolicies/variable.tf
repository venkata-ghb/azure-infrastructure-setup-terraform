variable "object_ids"{
  description="The obj id array"
  type=string
}

variable "keyvault_id"{
  description="The key vault id"
  type=string
}