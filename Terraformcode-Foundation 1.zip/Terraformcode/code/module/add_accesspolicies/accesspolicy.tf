data "azurerm_client_config" "current"{}
resource "azurerm_key_vault_access_policy" "accesspolicy_keyvault" {
  #count = length(var.object_id)
 # object_id = var.object_id[count.index]
   object_id = var.object_ids

  key_vault_id = var.keyvault_id 
  tenant_id = data.azurerm_client_config.current.tenant_id

  key_permissions = [
    "backup",
      "create",
      "decrypt",
      "delete",
      "encrypt",
      "get",
      "import",
      "list",
      "recover",
      "restore",
      "sign",
      "unwrapKey",
      "update",
      "verify",
      "wrapKey",
  ]

  secret_permissions = [
    "backup",
      "delete",
      "get",
      "list",
      "set",
  ]
  storage_permissions = [
      "get",
      "list",
      "delete",
    ]
     certificate_permissions = [
      "create",
      "delete",
      "deleteissuers",
      "get",
      "getissuers",
      "import",
      "list",
      "listissuers",
      "managecontacts",
      "manageissuers",
      "setissuers",
      "update",
    ]
}