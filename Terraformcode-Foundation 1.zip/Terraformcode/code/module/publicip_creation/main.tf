resource "azurerm_public_ip" "publicip" {
  name                = var.public_ip_name
  location            =var.location
  resource_group_name =var.rg_name
  allocation_method   =var.public_ip_allocation
  sku=var.sku
  tags =var.tags
  }
output "public_ip_id" {
  value =azurerm_public_ip.publicip.id
}
output "publi_ip_address" {
  value =azurerm_public_ip.publicip.ip_address
}
