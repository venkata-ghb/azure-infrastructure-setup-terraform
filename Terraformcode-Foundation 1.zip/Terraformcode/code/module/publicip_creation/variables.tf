variable "public_ip_name" {
 description="Specifies the name of the Public IP resource"
 type="string" 
}
variable "location" {
description="Specifies the supported Azure location where the resource exists"
 type="string"
}
variable "rg_name" {
description="The name of the resource group in which to create the public ip"
 type="string"
}
variable "public_ip_allocation" {
description="Defines the allocation method for this IP address. Possible values are Static or Dynamic."
 type="string"
}
variable "sku" {
description="The SKU of the Public IP. Accepted values are Basic and Standard. Defaults to Basic."
 type="string"
}
variable "tags" {
description="The SKU of the Public IP. Accepted values are Basic and Standard. Defaults to Basic."
 type=map(string)
}