variable "nsg_name"{
  type=list(string)
  
}
variable "resource_group_name" {
  type=string
  description="name of the resource group"
}

variable "nsg_rule_name" {
   type=string
  description="The name of the security rule."
}
variable "priority_number" {
  type=string
  description="Specifies the priority of the rule. The value can be between 100 and 4096."
}

variable "nsg_direction" {
  type=string
  description="The direction specifies if rule will be evaluated on incoming or outgoing traffic. Possible values are Inbound and Outbound."
}

variable "nsg_accesstype" {
  type=string
  description="Specifies whether network traffic is allowed or denied. Possible values are Allow and Deny."
}

variable "nsg_protocol" {
  type=string
  description=" Network protocol this rule applies to. Possible values include Tcp, Udp or * (which matches both)."
}
variable "nsg_source_port_range" {
  type=string
  description="Source Port or Range. Integer or range between 0 and 65535 or * to match any. This is required if nsg_source_port_ranges is not specified"
}
variable "nsg_destination_port_range" {
  description="Destination Port or Range. Integer or range between 0 and 65535 or * to match any. This is required if nsg_destination_port_ranges is not specified."
type=string
}
variable "nsg_source_address_prefixe" {
  description="CIDR or source IP range or * to match any IP. Tags such as VirtualNetwork, AzureLoadBalancer and Internet can also be used. This is required if nsg_source_address_prefixes is not specified."
 type=string
}
variable "nsg_destination_address_prefixe" {
  description="CIDR or destination IP range or * to match any IP. Tags such as VirtualNetwork, AzureLoadBalancer and Internet can also be used. This is required if nsg_destination_address_prefixes is not specified. "
  type=string
}
# variable "nsg_destination_address_prefixes" {
#   description="CIDR or destination IP range or * to match any IP. Tags such as VirtualNetwork, AzureLoadBalancer and Internet can also be used. This is required if nsg_destination_address_prefixes is not specified. "
#   type=list(string)
# }