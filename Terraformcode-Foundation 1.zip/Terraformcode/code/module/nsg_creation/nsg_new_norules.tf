resource "azurerm_network_security_group" "nsg" {
  name                = var.nsg_name
  location            = var.location
  resource_group_name = var.resourcegrp_name
  tags=var.tags_nsg
}
output "nsg_id"{
  value=azurerm_network_security_group.nsg.id
}
output "nsg_name_out"{
  value=azurerm_network_security_group.nsg.name
}