

variable "nsg_name" {
  description="name of the network security group"
  
}

variable "location" {
  description="location of the network security group"
}
variable "resourcegrp_name" {
  description="name of the resource group for network security group"
}
variable "tags_nsg" {
  description="tags for nsg"
  type=map(string)
}
