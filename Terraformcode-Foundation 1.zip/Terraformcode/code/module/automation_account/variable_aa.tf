variable "resource_group_name" {
  description = "The resource group name where instances are created."
  type        = "string"
}
variable "location" {
  description="The region where the automation account exists."
   type        = "string"
}

variable "automation_account_name" {
  description = "The name of the automation account for which update configuration has to set."
  type        = "string"
}
variable "sku_name" {
  description = "The name of the automation account for which update configuration has to set."
  type        = "string"
  
}

variable "tags_aa" {
  description = "A mapping of tags to assign to the resource."
  type        = "map"
}



