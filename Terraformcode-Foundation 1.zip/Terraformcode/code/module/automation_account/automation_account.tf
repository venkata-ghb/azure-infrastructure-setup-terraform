#creation of Automation account
resource "azurerm_automation_account" "automation_account" {
  name                = var.automation_account_name
  location            = var.location
  resource_group_name = var.resource_group_name

  sku_name = var.sku_name
  
 tags = var.tags_aa
}

output "aa_id" {
  value =azurerm_automation_account.automation_account.id
}

