
variable "er_gateway"{
    type=string
}
variable "location"{
    type=string
}
variable "resource_group"{
    type=string
}
variable "ipconfig"{
    type=string
}
variable "publicip"{
    type=string
}
variable "subnet_id"{
    type=string
}
variable "sku"{
    type=string
}
variable "tags"{
    type=map(string)
}
 
variable "gateway_type"{
    type=string
}
variable "private_ip_address_allocation"{
    type=string
}