resource "azurerm_virtual_network_gateway" "ergw" {
  name =var.er_gateway
  location =var.location
  resource_group_name =var.resource_group
  type=var.gateway_type    
  sku=var.sku  
  tags=var.tags         
  ip_configuration {
    name =var.ipconfig
    public_ip_address_id =var.publicip
    private_ip_address_allocation =var.private_ip_address_allocation  
    subnet_id =var.subnet_id
}
}