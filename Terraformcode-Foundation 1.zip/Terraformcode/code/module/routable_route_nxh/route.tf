resource "azurerm_route" "routetableroute" {
  name                   = var.route_name
  resource_group_name    = var.resource_group_name
  route_table_name       = var.route_table_name
  address_prefix         = var.route_address_prefix
  next_hop_type          = var.next_hop_type
  next_hop_in_ip_address = var.nexthop_in_ip_address
}