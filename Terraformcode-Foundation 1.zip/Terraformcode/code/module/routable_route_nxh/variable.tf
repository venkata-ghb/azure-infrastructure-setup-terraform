variable "resource_group_name" {
   description = "The name of the  resource group in which to create the virtual network"
   type = string
}
variable "route_name" {
  description = "The name of the route."
  type =string
}
variable "route_address_prefix" {
  description = "The destination CIDR to which the route applies"
  type =string
}
variable "next_hop_type" {
  description = "The type of Azure hop the packet should be sent to. Possible values are VirtualNetworkGateway, VnetLocal, Internet, VirtualAppliance and None"
  type = string
}
variable "nexthop_in_ip_address" {
  description = "Contains the IP address packets should be forwarded to. Next hop values are only allowed in routes where the next hop type is VirtualAppliance."
  type = string
}
variable "route_table_name" {
  description = "The name of the route table."
  type = string
}