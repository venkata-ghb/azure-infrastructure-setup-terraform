resource "azurerm_log_analytics_linked_service" "link" {
  resource_group_name = var.resource_group_name
  workspace_name      = var.workspace_name
  resource_id         = var.automationaccount_id
}