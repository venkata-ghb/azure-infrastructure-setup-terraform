variable "resource_group_name" {
  description="The name of the resource group in which the Log Analytics Linked Service is created."
}
variable "workspace_name" {
  description="Name of the Log Analytics Workspace that will contain the linkedServices resource"
}
variable "automationaccount_id" {
  description="The resource id of the resource that will be linked to the workspace"
}
