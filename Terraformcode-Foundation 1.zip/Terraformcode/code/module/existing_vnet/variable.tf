variable "existingvnet" {
    description="The name of the  existing vnet virtual network "
  
}
variable "rg_name" {
    description="The name of the resource group"
}
