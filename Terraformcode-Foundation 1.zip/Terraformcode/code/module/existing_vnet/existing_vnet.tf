data "azurerm_virtual_network" "vnet" {
  name                = var.existingvnet
  resource_group_name = var.rg_name
}
output "vnet_id" {
  value = data.azurerm_virtual_network.vnet.id
}
