data "azurerm_log_analytics_workspace" "log_analytics_workspace" {
  name                = var.law_name
  resource_group_name = var.law_rg
}

output "law" {
  value = data.azurerm_log_analytics_workspace.log_analytics_workspace.workspace_id
}
output "law_name" {
  value = data.azurerm_log_analytics_workspace.log_analytics_workspace.name
}
output "primary_shared_key" {
  value =data.azurerm_log_analytics_workspace.log_analytics_workspace.primary_shared_key
}
output "workspace_resource_id" {
  value =data.azurerm_log_analytics_workspace.log_analytics_workspace.id
}
