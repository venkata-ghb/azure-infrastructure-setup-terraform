variable "law_name"{
    type=string
}
variable "law_rg"{
    type=string
}