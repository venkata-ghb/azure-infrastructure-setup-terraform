
variable "subnet_id" {
  description="The ID of the Subnet."
  type=string
}
variable "route_table_id" {
   description="The ID of the Route Table which should be associated with the Subnet. "
  type=string
}
