resource "azurerm_network_watcher_flow_log" "nsg_flowlogs" {
  count       = length(var.nsg_id)
  network_watcher_name      = var.networkwatcher_name 
  resource_group_name       = var.nw_resourcegroup_name 
  network_security_group_id = var.nsg_id[count.index]
  storage_account_id        = var.storage_account_id 
  enabled                   = true
  version=var.flow_version
  retention_policy {
    enabled = true
    days    = var.retention_days 
  }
  traffic_analytics {
    enabled               = true
    workspace_id          = var.workspace_id 
    workspace_region      = var.location 
    workspace_resource_id = var.workspace_rs_id 
    interval_in_minutes   = var.minutes
  }
}