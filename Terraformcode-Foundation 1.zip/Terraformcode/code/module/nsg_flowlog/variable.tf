variable "networkwatcher_name" {
  description = "The name of the Network Watcher."
  type = string
}
variable "nw_resourcegroup_name" {
  description = "The name of the resource group in which the Network Watcher was deployed. "
  type = string
}
variable "nsg_id" {
  description = "The ID of the nsg"
  type = list(string)
}
variable "storage_account_id" {
  description = "The ID of the storage account"
  type = string
}
variable "workspace_id" {
  description = "The ID of the Log analytics workspace"
  type = string
}
variable "workspace_rs_id" {
  description="The resource ID of the Log analytics workspace"
  type = string
}
variable "flow_version"{
  type=number
}
variable "retention_days" {
  description = "The number of days to retain flow log records."
  type = number
}
variable "minutes" {
  description = "The minutes of interval in nsg flowlogs for traffic analytics  "
  type = number
}
variable "location" {
  description = "The minutes of interval in nsg flowlogs for traffic analytics  "
  type = string
}