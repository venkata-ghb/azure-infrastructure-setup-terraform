
resource azurerm_storage_account storageaccount {
name                     = var.storageaccountname
resource_group_name      =var.resourcegrp_name
location                 = var.location
account_kind=var.account_kind
access_tier=var.access_tier
account_tier             = element(split("_", var.storage_account_type), 0)
account_replication_type = element(split("_", var.storage_account_type), 1)
tags = var.tags
}
output "storage_account_name" {
  value = azurerm_storage_account.storageaccount.name
}
output "sta_id" {
  value = azurerm_storage_account.storageaccount.id
}
