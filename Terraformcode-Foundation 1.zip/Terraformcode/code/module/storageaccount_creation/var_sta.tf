variable "storageaccountname"{
description="Specifies the name of the storage account."
type=string
}
variable "resourcegrp_name"{
description="The name of the resource group "
type=string
}

variable "location"{
description=" Specifies the supported Azure location where the resource exists"
type=string
}

variable "storage_account_type"{
description="account type and replication type"
type=string
}
variable "account_kind"{
description="Defines the Kind of account"
type=string
}
variable "access_tier"{
description="Defines the access tier "
type=string
}
variable "tags" {
  type=map(string)
}


