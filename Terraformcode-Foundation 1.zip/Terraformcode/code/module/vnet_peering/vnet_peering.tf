
resource azurerm_virtual_network_peering vnet_peering {
  name                      = var.vnet_peer_name
  resource_group_name       = var.resourcegrp_name
  virtual_network_name      = var.vnet_name
  remote_virtual_network_id = var.vnet_remote_id
   allow_virtual_network_access = var.allow_virtual_network_access
    allow_forwarded_traffic   = var.allow_forwarded_traffic
    allow_gateway_transit     = var.allow_gateway_transit
    use_remote_gateways       = var.use_remote_gateways
  
 
}                                        

