
variable "vnet_peer_name" {
    description="The name of the virtual network peering"
  
}
variable "vnet_name" {
    description="The name of the virtual network"
}
variable "resourcegrp_name" {
    description="The name of the  resource group in which to create the virtual network peering"
}

variable "vnet_remote_id" {
  description="The full Azure resource ID of the remote virtual network"
}

variable "allow_virtual_network_access" {
    description="Controls if the VMs in the remote virtual network can access VMs in the local virtual network.possible values are true/false"
}
variable "allow_forwarded_traffic" {
    description="Controls if forwarded traffic from VMs in the remote virtual network is allowed.possible values are true/false"
}
variable "allow_gateway_transit" {
    description="Controls gatewayLinks can be used in the remote virtual network’s link to the local virtual network.possible values are true/false"
}
variable "use_remote_gateways" {
    description="Controls if remote gateways can be used on the local virtual network.possible values are true/false"
}








