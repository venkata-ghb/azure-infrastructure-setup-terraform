terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
    }
  }

  required_version = ">= 0.14.9"
}

resource "azurerm_resource_group" "rg" {
  name     = var.resource_group_name
  location = var.location
  tags     = var.tags
}

resource "azurerm_user_assigned_identity" "mi" {
  location            = var.location
  name                = var.aks_mi_name
  resource_group_name = azurerm_resource_group.rg.name
}

resource "azurerm_role_assignment" "network_contributor" {
  scope                = var.network_rg_id
  role_definition_name = "Network Contributor"
  principal_id         = azurerm_user_assigned_identity.mi.principal_id
  skip_service_principal_aad_check = true
}

resource "azurerm_role_assignment" "acr_pull" {
  role_definition_name = "AcrPull"
  scope                = var.container_registry_id
  principal_id         = var.kubelet_identity_object_id
  skip_service_principal_aad_check = true
}
