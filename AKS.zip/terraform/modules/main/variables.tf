variable "location" {
  description = "Specifies the location for the resource group and all the resources"
  default     = "westeurope"
  type        = string
}

variable "tags" {
  description = "Specifies tags for all the resources"
  default     = {
    createdWith = "Terraform"
  }
}

variable "resource_group_name" {
  description = "Specifies the resource group name"
  default     = "aks-rg"
  type        = string
}

variable "aks_mi_name" {
  description = "Specifies the name of the managed identity of the AKS cluster"
  type        = string
}

variable "network_rg_id" {
  description = "Specifies the resource group id of the virtual network"
  type        = string
}

variable "container_registry_id" {
  description = "Specifies the resource id of the container registry."
  type        = string
}

variable "kubelet_identity_object_id" {
  type        = string
}
