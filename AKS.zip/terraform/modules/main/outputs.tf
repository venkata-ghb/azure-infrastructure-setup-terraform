output "rg_name" {
  value = azurerm_resource_group.rg.name
  description = "Specifies the name of the RG."
}

output "rg_id" {
  value = azurerm_resource_group.rg.id
  description = "Specifies the resource id of the RG."
}

output "mi_id" {
  value = azurerm_user_assigned_identity.mi.id
  description = "Specifies the resource id of the MI."
}