# AKS Solution Module

![AKS Solution Module Overview](Overview.png)

This solution helps in deploying a fully private AKS cluster onto a landing zone in the ACE Platform. To allow for a quick start solution that is ready to be used it deploys the following:

- Subnets:
  - node pool subnet
  - vm subnet
- Private AKS Cluster with Azure CNI Overlay
- KeyVault with private endpoint
- Container Registry with private endpoint
- User Assigned Managed Identity
- RBAC assignements

In a private AKS cluster, everything is intrageted into the private network, this means the API server endpoint is exposed on a private IP address as well. Therefore KeyVault and Azure Container registry are also integrated into the private network with private endpoint.  

To be able to connect into the AKS cluster following options can be used:

- Create a virtual machine (with bastion) or DevOps selfhosted agent in the same Azure Virtual Network (VNet) as the AKS cluster.
- Use on-premises connectivity. Dependency on proper FW rule configuration to allow connectivity

**NOTE**
If a VM subnet is already provisioned from another deployment a change will need to be done to remove the subnet deployment from the TF code and only inject the resource ID for referencing it in the respective modules. The private endpoints are deployed into this VM subnet.

## Azure Pipeline | Terraform

The included pipeline has a set of variables/parameters that will need to be updated for your specific configuration. These are in place for the creation of the storage account for the Terraform state file. The pipeline includes the following steps:

- Create state storage
- Add Microsoft hosted agent IP to storage account FW
- TF Init
- TF Validate
- TF Plan
- TF Apply (based on parameter set on pipeline run)
- Remove Microsoft hosted agent IP to storage account FW

## Platform Prerequisites

Deploying this solution onto the ACE Platform has some prerequisites intermediate steps that will need to be executed by the platform team due to the more restricted access from the landing zone service principles. These will need to be configured:

- Default Route table for successfull creation of AKS cluster
- Managed Identity access on Azure Private DNS zone for AKS
- Default Firewall Rules for the AKS service communication to the Azure platform

These prerequisites will only be able to be provided after a first deployment run due to the fact they are created inside of the Terraform deployment.

### Default Route Table

When deploying a fully private AKS cluster there is a requirement to have a route table with a default route assigned to the default node pool subnet. If not the AKS cluster will remain in a failed state. Even when in the ACE platform, leveraging Azure vWAN, this will remain unused. Once the cluster is deployed this can be removed again.

To allow the platform team to create and assign the route table the resource ID of the default node pool subnet needs to be provided.

### AKS Managed Identity Access

Due to the fact this is a private AKS cluster there is a tight integration with the platform Azure Private DNS setup to enable proper resolution. An AKS cluster manages outside resources like the network and a private DNS zone through a managed identity that needs to have the proper access. Due to the fact that these private DNS zones are managed centrally access for this MI needs to be assigned by the platform team.

To allow the platform team to assign the *"Private DNS Zone Contributor"* role to the MI the object ID of this needs to be provided.

## Module Variables

Within this example the main variables that are deployment specific are managed through a terraform .tfvars file:

- resource_group_name          = *"RG name for AKS"*
- aks_cluster_name             = *"AKS Cluster Name"*
- acr_name                     = *"Container registry Name. To be globally unique"*
- key_vault_name               = *"KeyVault Name"*
- aks_mi_name                  = *"Name for AKS Managed Identity"*
- network_rg_name              = *"Resource group name of the rg containing the vNET"*
- network_rg_id                = *"Resource id of the rg containing the vNET"*
- aks_vnet_name                = *"name of the LZ vNET"*
- vm_subnet_name               = *"name of the subnet for hosting a jumpbox or selfhosted agent VM"*
- vm_subnet_address_prefix     = *["prefix to be used for vm subnet: 10.230.11.128/26"]*
- default_node_pool_subnet_address_prefix = *["prefix to be used for AKS default node pool subnet: 10.230.11.192/26"]*
- admin_group_object_ids       = *["Object ID of the Azure Security Group that will be used for Kubernetes admin access"]*

Other more sensitive variables like the *ssh_public_key* will need to be injected from the pipeline after retrieval from secure storage (eg. KeyVault). This can be done with the help of variable groups in the Azure DevOps project or adding a secret retrieval step in the pipeline.

## Deployment steps

1. Adjust variables in pipeline .yaml
2. Adjust variables in terraform .tfvar
3. Run pipeline
4. Provide required information to platform team for prereq deployment (Managed Identity object ID and subnet Resource ID of default node pool)
5. Delete failed AKS Cluster manually on LZ
6. Rerun when prerequisited are in place and validate successfull deployment
7. Delete "dummy" default Route table

## Next Steps

Once the solution is successfully deployed and the cluster is healthy the Kubernetes control plane needs to be further configured as well as having workloads deployed. To be able to perform these next steps a selfhosted DevOps agent will be required, preferably in the same vNET, to be able to perform these actions
