output "deployment_id" {
  description = "The ID of the Network Manager Admin Rule Collection"
  value       = azurerm_network_manager_deployment.avnm_deployment.id
}