
variable "network_manager_id" {
  description = "(Required) Specifies the ID of the Network Manager. Changing this forces a new Network Manager Deployment to be created."
  type        = string
}

variable "location" {
  description = "(Required) Specifies the location which the configurations will be deployed to. Changing this forces a new Network Manager Deployment to be created."
  type        = string
}

variable "scope_access" {
  description = "(Required) Specifies the configuration deployment type. Possible values are Connectivity, SecurityAdmin and Routing. Changing this forces a new Network Manager Deployment to be created."
  type        = string
}

variable "configuration_ids" {
  description = "(Required) A list of Network Manager Configuration IDs which should be aligned with scope_access."
  type        = list(string)
  }

