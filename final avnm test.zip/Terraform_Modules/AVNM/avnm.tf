resource "azurerm_network_manager" "ntw_manager" {
  name                = var.ntw_manager_name
  location            = var.location
  resource_group_name = var.resource_group_name
  scope {
    management_group_ids  = var.management_group_ids 
  }
  scope_accesses = var.scope_accesses
  description    = var.description
   tags = merge(var.tags, {name = var.ntw_manager_name})

  lifecycle {
      ignore_changes = []
   }
}
