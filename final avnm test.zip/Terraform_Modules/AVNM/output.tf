output "avnm_id" {
  description = "The ID of the Network Manager."
  value       = azurerm_network_manager.ntw_manager.id
}