
variable "ntw_manager_name" {
  description = "(Required) Specifies the name which should be used for this Network Manager. Changing this forces a new Network Manager to be created."
  type        = string
}

variable "location" {
  description = "(Required) Specifies the supported Azure location where the resource exists. Changing this forces a new resource to be created."
  type        = string
}

variable "resource_group_name" {
  description = "(Required) The name of the resource group in which to create the network security group. Changing this forces a new resource to be created."
  type        = string
}

variable "management_group_ids" {
  description = "(Optional) A list of management group IDs."
  type        = list(string)
}

variable "scope_accesses" {
  description = "(Optional) A list of configuration deployment types. Possible values are Connectivity, SecurityAdmin and Routing, which specify whether Connectivity Configuration, Security Admin Configuration or Routing Configuration are allowed for the Network Manager."
  type        = list(string)
}

variable "description" {
   description = "(Optional) A description of the Network Manager."
  type         = string
}

variable "tags" {
  description = "(Optional) A mapping of tags to assign to the resource."
  type        = map(string)
}