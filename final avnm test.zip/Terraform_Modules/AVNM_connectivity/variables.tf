
variable "avnm_connectivity" {
  description = "(Required) Specifies the name which should be used for this Network Manager Connectivity Configuration. Changing this forces a new Network Manager Connectivity Configuration to be created."
  type        = string
}

variable "network_manager_id" {
  description = "(Required) Specifies the ID of the Network Manager. Changing this forces a new Network Manager Connectivity Configuration to be created."
  type        = string
}

variable "connectivity_topology" {
  description = "(Required) Specifies the connectivity topology type. Possible values are HubAndSpoke and Mesh."
  type        = string
}

variable "resource_id" {
  description = "(Required) Specifies the resource ID used as hub in Hub And Spoke topology."
  type        = string
}

variable "network_group_id" {
  description = "(Required) Specifies the resource ID of Network Group which the configuration applies to."
  type        = string
}

variable "use_hub_gateway" {
  description = "(Optional) Indicates whether the hub gateway is used. Possible values are true and false."
  type        = string
}

