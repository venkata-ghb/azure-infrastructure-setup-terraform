output "connectivity_id" {
  description = "The ID of the Network Manager Connectivity Configuration."
  value       = azurerm_network_manager_connectivity_configuration.avnm_connectivity.id
}