resource "azurerm_network_manager_connectivity_configuration" "avnm_connectivity" {
  name                  = var.avnm_connectivity
  network_manager_id    = var.network_manager_id
  connectivity_topology = var.connectivity_topology
  delete_existing_peering_enabled = false

applies_to_group {

      group_connectivity = "None"
      network_group_id   = var.network_group_id
      global_mesh_enabled  = false
      use_hub_gateway = var.use_hub_gateway
  }

  hub {
    resource_id   = var.resource_id
    resource_type = "Microsoft.Network/virtualNetworks"
  }
}