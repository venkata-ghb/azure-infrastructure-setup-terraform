
output "avnm_rule_collection_id" {
  description = "The ID of the Network Manager Rule Collection."
  value       = azapi_resource.avnm_rule_collection.id
}