variable "avnm_rule_collection_name" {
   description = "(Required) Specifies the name which should be used for this Network Manager Network Group. Changing this forces a new Network Manager Network Group to be created."
  type        = string
}

variable "parent_id" {
   description = "(Optional) A description of the Network Manager Network Group."
  type        = string
}

variable "network_group_id" {
   description = " (Required) Specifies the ID of the Network Manager. Changing this forces a new Network Manager Network Group to be created."
  type        = string
}

variable "disable_bgp_route_propagation" {
   description = " (Required) Specifies the ID of the Network Manager. Changing this forces a new Network Manager Network Group to be created."
  type        = string
}
