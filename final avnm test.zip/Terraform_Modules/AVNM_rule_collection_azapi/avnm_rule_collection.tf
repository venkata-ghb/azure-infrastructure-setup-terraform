resource "azapi_resource" "avnm_rule_collection" {
  type = "Microsoft.Network/networkManagers/routingConfigurations/ruleCollections@2024-05-01"
  name = var.avnm_rule_collection_name
  parent_id = var.parent_id
  body = {
    properties = {
      appliesTo = [
        {
          networkGroupId = var.network_group_id
        }
      ]
      disableBgpRoutePropagation = var.disable_bgp_route_propagation
    }
  }
  schema_validation_enabled = false
  lifecycle {
    ignore_changes = [ body.properties.disableBgpRoutePropagation, output ]
  }
}