resource "azurerm_network_manager_routing_configuration" "avnm_routing" {
  name               = var.avnm_routing_name
  network_manager_id = var.network_manager_id
}