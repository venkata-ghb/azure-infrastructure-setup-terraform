
variable "avnm_routing_name" {
  description = "(Required) The name which should be used for this Network Manager Routing Configuration. Changing this forces a new Network Manager Routing Configuration to be created."
  type        = string
}

variable "network_manager_id" {
  description = "(Required) The ID of the Network Manager. Changing this forces a new Network Manager Routing Configuration to be created."
  type        = string
}

