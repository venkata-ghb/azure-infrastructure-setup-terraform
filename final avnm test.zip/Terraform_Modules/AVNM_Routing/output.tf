output "avnm_routing_id" {
  description = "The ID of the Network Manager Routing Configuration.."
  value       = azurerm_network_manager_routing_configuration.avnm_routing.id
}