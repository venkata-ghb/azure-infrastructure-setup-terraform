resource "azapi_resource" "ntw_group" {
  type = "Microsoft.Network/networkManagers/networkGroups@2024-07-01"
  name = var.ntw_group_name
  parent_id = var.parent_id
  body = {
    properties = {
      memberType = var.member_type
      description = var.description
    }
  }
}