
output "avnm_group_id" {
  description = "The ID of the Network Manager Network Group."
  value       = azapi_resource.ntw_group.id
}