
output "avnm_rules_id" {
  description = "The ID of the Network Manager Rule."
  value       = azapi_resource.avnm_rules.id
}