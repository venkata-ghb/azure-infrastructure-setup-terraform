resource "azapi_resource" "avnm_rules" {
  type = "Microsoft.Network/networkManagers/routingConfigurations/ruleCollections/rules@2024-09-01-preview"
  name = var.avnm_rule_name
  parent_id = var.parent_id
  body = {
    properties = {
      destination = {
        destinationAddress = var.destinationAddress
        type = var.type
      }
      nextHop = {
        nextHopAddress = var.nextHopAddress
        nextHopType = var.nextHopType
      }
    }
  }
}