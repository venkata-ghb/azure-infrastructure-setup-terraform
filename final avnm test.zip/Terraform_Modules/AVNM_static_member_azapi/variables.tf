variable "avnm_static_member_name" {
  description = "(Required) Specifies the name which should be used for this Network Manager Static Member. Changing this forces a new Network Manager Static Member to be created."
  type        = string
}

variable "parent_id" {
  description = "(Required) Specifies the ID of the Network Manager Group. Changing this forces a new Network Manager Static Member to be created."
  type        = string
}

variable "subnet_id" {
  description = "(Required) Specifies the Resource ID of the Virtual Network using as the Static Member. Changing this forces a new Network Manager Static Member to be created."
  type        = string
}

