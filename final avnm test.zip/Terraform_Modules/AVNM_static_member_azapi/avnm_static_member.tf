resource "azapi_resource" "avnm_static_member" {
  type = "Microsoft.Network/networkManagers/networkGroups/staticMembers@2024-07-01"
  name = var.avnm_static_member_name
  parent_id = var.parent_id
  body = {
    properties = {
      resourceId = var.subnet_id
    }
  }
}
 