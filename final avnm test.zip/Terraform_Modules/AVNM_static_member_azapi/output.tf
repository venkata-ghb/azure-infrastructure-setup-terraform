output "avnm_id" {
  description = "The ID of the Network Manager Static Member."
  value       = azapi_resource.avnm_static_member.id
}