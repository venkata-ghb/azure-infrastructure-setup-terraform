# ##----------------------------------- Azure Virtual Network Manager -----------------------------------

module "avnm_rg" {
    providers = {
        azurerm = azurerm.current_sub
    }   
        count               =  var.avnm_required ? 1 : 0
        source              = "../../Terraform_Modules/ResourceGroup"
        resource_group_name = "IS${var.shortlocation}${var.subscription_name}-RG-F-AVNM" 
        location            = var.location
        tags                = var.avnm_tags
}

module "avnm_creation" {
  providers = {
      azurerm = azurerm.current_sub
    }
  count                =  var.avnm_required ? 1 : 0
  source               = "../../Terraform_Modules/AVNM"
  ntw_manager_name     = "IS${var.shortlocation}${var.subscription_name}-${var.ntw_manager_name}"   
  location             = var.location
  resource_group_name  = "IS${var.shortlocation}${var.subscription_name}-RG-F-AVNM"
  management_group_ids = var.management_group_ids 
  scope_accesses       = var.scope_accesses
  description          = var.description
  tags                 = var.avnm_tags
  depends_on           = [ module.avnm_rg ]
}

module "avnm_network_group" {
  for_each          =  var.network_groups
  source            = "../../Terraform_Modules/AVNM_NW_Group_creation_azapi"
  ntw_group_name    = "${var.shortlocation}-${each.value.ntw_group_name}"
  parent_id         = var.avnm_required == true ? module.avnm_creation[0].avnm_id : data.azurerm_network_manager.ntw_manager["existing_ntw_manager"].id
  member_type       = each.value.member_type
  description       = "${each.value.description}${var.location}"  
  depends_on        = [ module.avnm_creation ]
}

module "avnm_static_member" {
  for_each                  = var.static_members  
  source                    = "../../Terraform_Modules/AVNM_static_member_azapi"
  avnm_static_member_name   = each.value.avnm_static_member_name
  parent_id         = module.avnm_network_group[each.value.avnm_network_group].avnm_group_id
  subnet_id         = data.azurerm_subnet.hub_subnet["gateway"].id   
  depends_on        = [ module.avnm_network_group ]
  }


module "avnm_connectivity_configuration" {
  for_each                 = var.avnm_connectivity 
  source                   = "../../Terraform_Modules/AVNM_connectivity"
  avnm_connectivity        = "${var.shortlocation}-HUB-VNET01-V2V-${var.shortlocation}-${each.value.avnm_connectivity_name}"
  network_manager_id       = var.avnm_required == true ? module.avnm_creation[0].avnm_id : data.azurerm_network_manager.ntw_manager["existing_ntw_manager"].id
  connectivity_topology    = var.connectivity_topology
  network_group_id         = module.avnm_network_group[each.value.avnm_network_group].avnm_group_id
  use_hub_gateway          = var.use_hub_gateway
  resource_id              = data.azurerm_virtual_network.hub_vnet["hub_vnet_01"].id 
  depends_on               = [ module.avnm_creation, module.avnm_network_group ]
}


module "avnm_deploy_connectivity_configuration" {
  source               = "../../Terraform_Modules/AVNM_deployment"
  network_manager_id   = var.avnm_required == true ? module.avnm_creation[0].avnm_id : data.azurerm_network_manager.ntw_manager["existing_ntw_manager"].id
  location             = var.location
  scope_access         = "Connectivity"
  configuration_ids    = [module.avnm_connectivity_configuration["avnm_conn_01"].connectivity_id]
  depends_on           = [ module.avnm_creation, module.avnm_connectivity_configuration]
}

module "avnm_routing" {  

  #--------- (condition as true)-------------------
   providers = {
      azurerm = azurerm.current_sub
    }
  for_each             = var.avnm_required ? var.avnm_routing : {}
  source               = "../../Terraform_Modules/AVNM_Routing"
  avnm_routing_name    = "AVNM-${var.shortlocation}-HUB-${each.value.avnm_routing_name}"
  network_manager_id   = module.avnm_creation[0].avnm_id
  depends_on           = [ module.avnm_rg, module.avnm_creation ]
}

module "avnm_routing_01" {  

  #---------  (condition as false)-------------------
   providers = {
      azurerm = azurerm.network_manager_id
    }
  for_each             = var.avnm_required == false ? var.avnm_routing_01 : {}
  source               = "../../Terraform_Modules/AVNM_Routing"
  avnm_routing_name    = "AVNM-${var.shortlocation}-HUB-${each.value.avnm_routing_name}"
  network_manager_id   = data.azurerm_network_manager.ntw_manager["existing_ntw_manager"].id
  depends_on           = [ module.avnm_rg, module.avnm_creation ]
}

module "avnm_rule_collection" {
    source    = "../../Terraform_Modules/AVNM_rule_collection_azapi"
    avnm_rule_collection_name = "AVNM-${var.shortlocation}-HUB-${var.avnm_rule_collection_name}"
    parent_id                 = var.avnm_required == true ? module.avnm_routing["avnm_routing"].avnm_routing_id : module.avnm_routing_01["avnm_routing"].avnm_routing_id
    network_group_id          = module.avnm_network_group["avnm_group_02"].avnm_group_id
    disable_bgp_route_propagation = var.disable_bgp_route_propagation
    depends_on = [ module.avnm_routing, module.avnm_network_group, module.avnm_routing_01 ]
}  

module "avnm_rule" {
    for_each        = var.avnm_rules
    source          = "../../Terraform_Modules/AVNM_rules_azapi"
    avnm_rule_name  = "${var.shortlocation}-${each.value.avnm_rule_name}"
    parent_id       = module.avnm_rule_collection.avnm_rule_collection_id
    destinationAddress = each.value.destinationAddress
    type            = each.value.type
    nextHopAddress  = each.value.nextHopAddress
    nextHopType     = each.value.nextHopType
    depends_on = [  module.avnm_rule_collection ]
}

module "avnm_deployment_routing" { 
  source             = "../../Terraform_Modules/AVNM_deployment"
  network_manager_id = var.avnm_required == true ? module.avnm_creation[0].avnm_id : data.azurerm_network_manager.ntw_manager["existing_ntw_manager"].id
  location           = var.location
  scope_access       =  "Routing"
  configuration_ids  = var.avnm_required == true ? [module.avnm_routing["avnm_routing"].avnm_routing_id] : [module.avnm_routing_01["avnm_routing"].avnm_routing_id]
  depends_on         = [ module.avnm_creation, module.avnm_rule_collection, module.avnm_rule, module.avnm_routing_01, module.avnm_routing ]
}