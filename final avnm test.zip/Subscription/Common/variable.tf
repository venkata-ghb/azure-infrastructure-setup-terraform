variable "location" {
  type        = string
  description = "The location/region where the resources are created."
}

variable "sa_subscription_id" {
  type        = string
  description = "The GUID of the storage account where the backend tffiles are stored"
}

variable "subscription_id" {
  type        = string
  description = "The GUID of the current subscription"
}

variable "shortlocation" {
  type        = string
  description = "The short location of the currenr subscription"
}

##---------------------Azure Virtual Network Manager-----------------------------------

variable "subscription_name" {
  description = "(Required) The Name of the Subscription. This is the Display Name in the portal."
  type        = string
}

variable "ntw_manager_name" {
  type = string
  description = "(Required) Specifies the name which should be used for this Network Manager. Changing this forces a new Network Manager to be created."
}

variable "avnm_required" {
  type        = bool
  description = "Specifies if the AVNM has to be created in the current region or not"
}

variable "avnm_tags" {
  description = "(Optional) A mapping of tags to assign to the resource."
  type        = map(string)
}

variable "management_group_ids" {
  description = "(Optional) A list of management group IDs."
  type        = list(string)
}

variable "scope_accesses" {
  description = "(Optional) A list of configuration deployment types. Possible values are Connectivity, SecurityAdmin and Routing, which specify whether Connectivity Configuration, Security Admin Configuration or Routing Configuration are allowed for the Network Manager."
  type        = list(string)
}

variable "description" {
  description = "(Optional) A description of the Network Manager."
  type        = string
}

variable "network_groups" {
  description = "(Required) Specifies the Network group details of the Network Manager."
  type = map(object({
    ntw_group_name = string
    member_type    = string
    description    = string
  }))
}

variable "static_members" {
  description = "(Required) Specifies the static member details of the Network Manager."
  type = map(object({
    avnm_static_member_name = string
    avnm_network_group = string
  }
  ))
}

variable "avnm_connectivity" {
  description = "(Required) Specifies the AVNM connectivity configuraiton details of the Network Manager."
  type = map(object({
    avnm_connectivity_name = string
    avnm_network_group     = string
  }))
}

variable "connectivity_topology" {
  description = "(Required) Specifies the connectivity topology type. Possible values are HubAndSpoke and Mesh."
  type        = string
}

variable "use_hub_gateway" {
  description = " (Optional) Indicates whether the hub gateway is used. Possible values are true and false."
  type        = bool
}

variable "avnm_rule_collection_name" {
  type        = string
  description = "(Required) Specifies the name which should be used for this Network Manager Network Group. Changing this forces a new Network Manager Network Group to be created."
}

 variable "disable_bgp_route_propagation" {
  type        = bool
  description = "(Required) Specifies the ID of the Network Manager. Changing this forces a new Network Manager Network Group to be created."
 }

 variable "avnm_rules" {
    description = "Specifies the rules for an Azure Virtual Network Manager."
    type = map(object({
      avnm_rule_name = string
      destinationAddress = string
      type = string
      nextHopAddress = string
      nextHopType = string
    }))
 }

#------------------------- Data Sources - AVNM------------------------------------------
variable "vnets" {
  description = "(Required) Specifies the vNet details of the Network Manager connectivity configuration."
  type = map(object({
    vnet_name   = string
    rg_name     = string
  }))
}

variable "subnets" {
  description = "(Required) Specifies the subnet details of the Network Manager static members"
  type = map(object({
    subnet_name = string
    vnet_name   = string
    rg_name     = string
  }))
}

variable "existing_ntw_manager" {
  description = "(Required) Specifies the Network Manager details"
  type = map(object({
    ntw_manager_name = string
  }))
}

variable "network_manager_id" {
  type        = string
  description = "The GUID of the subscription where the AVNM is created"
}

variable "ntw_manager_shortlocation" {
  type        = string
  description = "The short location of the subscription where the AVNM is created"
}

variable "avnm_routing" {
  description = "Network Manager routing configuration details"
  type = map(object({
    avnm_routing_name = string
  }))
}

variable "avnm_routing_01" {
  description = "Network Manager routing configuration details"
  type = map(object({
    avnm_routing_name = string
  }))
}