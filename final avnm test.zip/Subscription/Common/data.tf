data "azurerm_network_manager" "ntw_manager" {
  for_each      =  var.avnm_required ? {} : var.existing_ntw_manager
  provider            = azurerm.network_manager_id
  name                = "IS${var.ntw_manager_shortlocation}${var.subscription_name}-${each.value.ntw_manager_name}"
  resource_group_name = "IS${var.ntw_manager_shortlocation}${var.subscription_name}-RG-F-AVNM"
}

data "azurerm_subnet" "hub_subnet" {
  provider    = azurerm.current_sub
  for_each             = var.subnets
  name                 = each.value.subnet_name
  resource_group_name  = "IS${var.shortlocation}${each.value.rg_name}"
  virtual_network_name = "${var.shortlocation}-${each.value.vnet_name}"
}

data "azurerm_virtual_network" "hub_vnet" {
  provider    = azurerm.current_sub
  for_each             = var.vnets
  name                 = "${var.shortlocation}-${each.value.vnet_name}"
  resource_group_name  = "IS${var.shortlocation}${each.value.rg_name}"
}
