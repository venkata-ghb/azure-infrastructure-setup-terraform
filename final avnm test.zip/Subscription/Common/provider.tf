provider "azurerm" {
	features {}
	subscription_id = var.sa_subscription_id
	resource_provider_registrations = "none"
}
 provider "azurerm" {
 	features {}
 	alias = "current_sub"
   subscription_id = var.subscription_id
   storage_use_azuread = true
 }

provider "azapi" {
   alias 			= "azapi"
}

 provider "azurerm" {
   alias 			= "network_manager_id"
   subscription_id  = var.network_manager_id
   features {}
}

