#------------------------------------------- Location ---------------------------------------------

location = "SwedenCentral"
shortlocation = "SWC"

#------------------------------------ Data Source - Azure Virtual Network Manager------------------
vnets = {
    "hub_vnet_01"            =  {
    "vnet_name"           = "HUB-VNET01"
    "rg_name"      = "HUB01-RG-F-NETWORK"
}
}
subnets = {
    "gateway"         = {
        "subnet_name" = "GatewaySubnet"
        "vnet_name"   = "HUB-VNET01"
        "rg_name"     = "HUB01-RG-F-NETWORK"
        }
}

#-------------------------------------Azure Virtual Network Manager----------------------------------
avnm_required = true 
ntw_manager_shortlocation = "SWC"
avnm_tags = {
    itsmnr    = "WO1173"
    remark = ""
    environment = ""
    model = "Application"
    igar = "9AAG026594"
    application = "cloud hosting service infrastructure"
    costcenter = "52013300"
    costcenterowner = "tomasz.repinski1@pl.abb.com"
    country = "global"
    owningbusinessarea = "zc"
    owningdivision = "zcgs"
    owningcompany = "chgpl"
}

ntw_manager_name = "AVNM01"
subscription_name    = "HUB-01"
management_group_ids = ["/providers/Microsoft.Management/managementGroups/ABB-SWC-MGMTGRP", "/providers/Microsoft.Management/managementGroups/ABB-INC-MGMTGRP"] #["/providers/Microsoft.Management/managementGroups/ABB-GBS-SUBSCRIPTIONS"]
scope_accesses = ["Connectivity", "Routing"]
description = "Cloud Hosting Infrastructure for managing Virtual Networks"

network_groups = {
    "avnm_group_01" = {
       ntw_group_name = "ALL-VNETs"
       member_type = "VirtualNetwork"
       description = "Manages All hub-spoke VNets for " 
    }
    "avnm_group_02" = {
       ntw_group_name = "HUB-GW-subnet"
       member_type = "Subnet"
       description = "Manages the Gateway Subnet of "
    }
}

static_members = {
    "static_member" = {
        avnm_static_member_name = "Gateway"
        avnm_network_group = "avnm_group_02"
    }
}

avnm_connectivity = {
    "avnm_conn_01" = {
        avnm_connectivity_name = "SPOKES01"
        avnm_network_group = "avnm_group_01"
    }
}
connectivity_topology = "HubAndSpoke"
use_hub_gateway = true

existing_ntw_manager = {
    "existing_ntw_manager" = {
        "ntw_manager_name" = "AVNM01"
    }
}

avnm_rule_collection_name = "VNET01-GW01-UDR01-RC01"
disable_bgp_route_propagation = false

avnm_rules = {}

avnm_routing = {
    "avnm_routing" ={
        avnm_routing_name = "VNET01-GW01-UDR01"
    }
}
avnm_routing_01 = {
     "avnm_routing" ={
        avnm_routing_name = "VNET01-GW01-UDR01"
    }
}